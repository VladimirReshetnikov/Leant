-- |
-- Bounded instantiation of hypothesis-side rank-N foralls.
--
-- LJT search is propositional: a quantified type is one opaque proposition.
-- A hypothesis of type @forall as. t@ nevertheless justifies every instance
-- @t[as := ss]@. Generated Haskell normally uses the hypothesis expression
-- directly and lets GHC instantiate it implicitly. A loaded scheme with a
-- binder absent from its residual body instead retains a bounded visible type
-- application: frontends may have erased the constraint which originally
-- determined that binder. This module turns both cases into premise axioms
-- @Opaque(forall as. t) -> compile(t[as := ss])@ over a finite candidate set:
-- the sequent's type variables (including skolems introduced by opened
-- positive foralls), every quantified atom the sequent already mentions,
-- and—for separate additive tails—closed forall-free subtrees of checked
-- queries and value signatures. Quantified candidates give guarded
-- impredicative instantiation; closed candidates may have any kind, but the
-- complete substituted body is kind-checked before compilation.
--
-- Each axiom is a self-contained semantic truth about Haskell types, so
-- adding them can only enlarge the set of provable goals; they never
-- threaten negative evidence. Boundedness loses completeness only, and the
-- query translation and retained non-target loaded schemes report the
-- corresponding incompleteness, so exhausting bounded plans cannot justify a
-- refutation.
module Djinn.Internal.Instantiation
    ( InstantiationAxioms
    , ProviderInstantiationPremises
    , instantiationAxioms
    , queryCorrelatedInstantiationAxioms
    , queryDirectedInstantiationAxioms
    , queryCarrierInstantiationAxioms
    , formulaFunctionCarriers
    , queryConstructedInstantiationAxioms
    , scopedConstructionInstantiationAxioms
    , queryClosedInstantiationAxioms
    , loadedInstantiationAxioms
    , providerInstantiationPremises
    , providerInstantiationAssignmentPremises
    , closedMonotypeSubtrees
    , instantiationAxiomPremises
    , instantiationAxiomSymbols
    , instantiationVisibleApplications
    , providerInstantiationPremiseBindings
    , providerInstantiationApplications
    , rewriteProviderInstantiationEvidence
    , usesInstantiationEvidence
    , independentConstructionScopes
    , eliminateInstantiationEvidence
    ) where

import Control.Monad (replicateM)
import Data.List (isPrefixOf, sort, sortOn)
import qualified Data.Map.Strict as Map
import qualified Data.Set as Set
import Numeric.Natural (Natural)

import Djinn.Internal.InstantiationEvidence
    ( eliminateInstantiationEvidence
    , usesInstantiationEvidence
    , independentConstructionScopes
    )
import Djinn.Internal.LJTFormula
import Djinn.Internal.DirectedInstantiation (directedInstantiationTuples)
import Language.Haskell.Synthesis.Collection (distinctOn)
import Language.Haskell.Synthesis.Constraint (constraintArguments)
import qualified Language.Haskell.Synthesis.Type as SharedType
import qualified Language.Haskell.Synthesis.TypeAtom as SharedTypeAtom
import qualified Language.Haskell.Synthesis.TypeRender as SharedTypeRender
import qualified Language.Haskell.Synthesis.Generated as SharedGenerated
import qualified Language.Haskell.Synthesis.Query as SharedQuery

-- Instantiating a leading chain replaces every binder at once, mirroring
-- Exference's provider rule. Keep this eligibility boundary aligned with the
-- shared exact-assignment contract; longer chains multiply the candidate tuple
-- space and stay opaque.
maxInstantiationBinders :: Int
maxInstantiationBinders =
    SharedQuery.maximumProviderInstantiationArguments

-- The original one- through three-binder rule enumerated a lexically sorted
-- Cartesian product. Keep that exact prefix so widening the rule cannot
-- perturb already documented candidates or rankings.
maxCartesianInstantiationBinders :: Int
maxCartesianInstantiationBinders = 3

-- Axioms are premises in every plan of one instantiation family, so their
-- count bounds both formula size and search branching. The caps are deliberate
-- completeness boundaries, never soundness ones: a dropped axiom can only
-- cause a miss, and misses in this fragment already report 'NoEvidence'.
maxInstantiationAxioms :: Int
maxInstantiationAxioms = 64

maxInstantiationAttempts :: Int
maxInstantiationAttempts = 512

-- Each scheme has a smaller distinct-axiom allowance. Loaded jobs also
-- interleave tuple attempts, so duplicate or ill-kinded tuples from one scheme
-- cannot starve its siblings under the family attempt cap.
maxInstantiationAxiomsPerScheme :: Int
maxInstantiationAxiomsPerScheme = 16

-- Keep direct provider evidence within the same global bound as the public
-- candidate association list, even when several candidates form tuples for a
-- multiply quantified provider.
maxProviderInstantiationPremises :: Int
maxProviderInstantiationPremises = 32

-- | The generated axiom premises together with their reserved proof symbols.
-- The symbols use Djinn's private @$@ namespace, so they cannot collide with
-- declared functions. Ordinary inferable evidence is erased before code
-- generation. Query-local or loaded evidence whose vacuous binders require a
-- visible choice is retained in 'instantiationVisibleApplications' until proof
-- conversion.
data InstantiationAxioms = InstantiationAxioms
    { instantiationAxiomPremises :: [(Symbol, Formula)]
    , instantiationAxiomSymbols :: Set.Set Symbol
    , instantiationVisibleApplications ::
        Map.Map Symbol [SharedGenerated.VisibleTypeArgument]
    , instantiationConstructionSkolems :: Map.Map Symbol [String]
    , instantiationConstructionTranslator :: Maybe
        (Set.Set String -> Natural -> SharedType.Type String ->
            Either String (Formula, [String]))
    }

-- | Provider-local specializations justified by caller-supplied evidence.
--
-- Unlike an ordinary instantiation axiom, each premise is the already
-- specialized provider result rather than an implication from a scheme atom.
-- Its synthetic proof symbol remains paired with the one exact provider whose
-- external environment established the choice. Proof checking sees only the
-- specialized premise; generated lowering later expands a use into an
-- application of the synthetic evidence to that provider.
data ProviderInstantiationPremises = ProviderInstantiationPremises
    { providerInstantiationPremiseBindings :: [(Symbol, Formula)]
    , providerInstantiationApplications ::
        Map.Map Symbol (Symbol, [SharedGenerated.VisibleTypeArgument])
    }

-- Structural lowering may erase a caller-supplied type argument before proof
-- search sees it. The prepared environment marks the complete simultaneous
-- substitution, then checks every reached datatype-argument boundary. This
-- catches phantom loss inside an argument and through a higher-kinded head
-- without rejecting constructor fields which do preserve the choice. Nominal
-- lowering preserves the full application and therefore passes no checker. A
-- wholly vacuous vector remains accepted because no marker reaches the body.
type ProviderInstantiationFidelity =
    [String]
    -> [SharedType.Type String]
    -> SharedType.Type String
    -> Either String Bool

retainsProviderInstantiationFidelity
    :: Maybe ProviderInstantiationFidelity
    -> InstantiationScheme
    -> [SharedType.Type String]
    -> Bool
retainsProviderInstantiationFidelity fidelityTranslator scheme arguments =
    case fidelityTranslator of
        Nothing -> True
        Just checkFidelity -> case checkFidelity
                (schemeBinders scheme)
                arguments
                (schemeBody scheme) of
            Right retainedFidelity -> retainedFidelity
            Left _ -> False

-- One retained logical axiom plus the explicit type arguments required when
-- its proof evidence cannot safely collapse to an implicitly instantiated
-- occurrence. The latter retains a necessary visible prefix when an image
-- cannot be inferred from an occurrence outside nested quantification,
-- including vacuous binders.
data InstantiationAxiom = InstantiationAxiom
    { instantiationAxiomFormula :: Formula
    , instantiationAxiomVisibleArguments ::
        Maybe [SharedGenerated.VisibleTypeArgument]
    , instantiationAxiomSkolems :: [String]
    }
    deriving (Eq, Ord)

-- Whether a subformula position provides data to the prover or demands it.
-- A premise root is hypothesis-side; a goal root is obligation-side; each
-- implication domain flips the side; every other connective preserves it.
data SequentSide = HypothesisSide | ObligationSide
    deriving Eq

flipSide :: SequentSide -> SequentSide
flipSide side = case side of
    HypothesisSide -> ObligationSide
    ObligationSide -> HypothesisSide

sidedAtomSymbols :: SequentSide -> Formula -> [(SequentSide, Symbol)]
sidedAtomSymbols side formula = case formula of
    Conj children -> concatMap (sidedAtomSymbols side) children
    Disj alternatives ->
        concatMap (sidedAtomSymbols side . snd) alternatives
    Empty _ -> []
    argument :-> result ->
        sidedAtomSymbols (flipSide side) argument ++
        sidedAtomSymbols side result
    PVar symbol -> [(side, symbol)]

-- One instantiable hypothesis scheme: a context-free leading forall chain of
-- bounded length. Constrained chains stay opaque because Djinn has no
-- premise vocabulary for their class obligations.
data InstantiationScheme = InstantiationScheme
    { schemeSource :: SharedType.Type String
    , schemeBinders :: [String]
    , schemeBody :: SharedType.Type String
    }

instantiationScheme
    :: SharedType.Type String -> Maybe InstantiationScheme
instantiationScheme source = case SharedType.splitLeadingForalls source of
    (binders@(_ : _), [], body)
        | length binders <= maxInstantiationBinders ->
            Just $ InstantiationScheme source binders body
    _ -> Nothing

-- Demand matching does not enumerate a Cartesian power of the binder list,
-- so its eligibility is independent of the historical six-binder frontier.
directedInstantiationScheme
    :: SharedType.Type String -> Maybe InstantiationScheme
directedInstantiationScheme source = case SharedType.splitLeadingForalls source of
    (binders@(_ : _), [], body) ->
        Just $ InstantiationScheme source binders body
    _ -> Nothing

schemeKey :: InstantiationScheme -> SharedTypeAtom.TypeAtomKey String
schemeKey = SharedTypeAtom.alphaTypeKey . schemeSource

-- The atoms of one checked query: goal formulas enter at obligation side and
-- premise formulas at hypothesis side. Every axiom family below draws its
-- candidate vocabulary from this list.
queryAtomSymbols :: [Formula] -> [Formula] -> [(SequentSide, Symbol)]
queryAtomSymbols goalFormulas premiseFormulas =
    concatMap (sidedAtomSymbols ObligationSide) goalFormulas ++
    concatMap (sidedAtomSymbols HypothesisSide) premiseFormulas

-- The retained source types behind opaque atoms, in atom order.
opaqueAtomSources :: [(SequentSide, Symbol)] -> [SharedType.Type String]
opaqueAtomSources atoms =
    [ source
    | (_, symbol) <- atoms
    , Just source <- [opaqueSymbolSource symbol]
    ]

-- Candidate variables in the callers' first-occurrence order, deduplicated.
variableCandidatesOf :: [String] -> [SharedType.Type String]
variableCandidatesOf = map SharedType.TypeVariable . distinctOn id

-- Guarded quantified candidates: the closed quantified subtrees of the
-- opaque sources, in rendered order, one per alpha-equivalence class.
quantifiedCandidatesOf
    :: [SharedType.Type String] -> [SharedType.Type String]
quantifiedCandidatesOf =
    distinctOn SharedTypeAtom.alphaTypeKey .
    sortOn (SharedTypeRender.renderType id) .
    concatMap closedQuantifiedSubtrees

-- The distinct instantiation schemes seeded by hypothesis-side opaque atoms.
hypothesisSchemes :: [(SequentSide, Symbol)] -> [InstantiationScheme]
hypothesisSchemes atoms = distinctOn schemeKey
    [ scheme
    | (HypothesisSide, symbol) <- atoms
    , Just source <- [opaqueSymbolSource symbol]
    , Just scheme <- [instantiationScheme source]
    ]

-- | Build the bounded axiom set for one query.
--
-- The translator must be the sealed environment's opaque formula compiler:
-- instantiated bodies keep nested quantifiers as alpha-stable atoms, so an
-- axiom can chain into another axiom only through an atom the closure has
-- itself collected. Goal formulas enter at obligation side and premises at
-- hypothesis side; candidate variable spellings arrive from the source-level
-- goal and premise scopes plus every opened-forall skolem, so no rendered
-- atom spelling is ever parsed back into a type.
--
-- A failed instantiation or compilation drops that one axiom rather than the
-- query: the axioms are an optional capability, and every kept axiom is
-- checked by construction against the same formula vocabulary the sequent
-- uses.
instantiationAxioms
    :: (SharedType.Type String -> Either String Formula)
    -> (SharedType.Type String ->
        Maybe SharedGenerated.VisibleTypeArgument)
    -> [String]
    -> [Formula]
    -> [Formula]
    -> InstantiationAxioms
instantiationAxioms translator visibleArgument variableSpellings goalFormulas
        premiseFormulas =
    buildInstantiationAxioms "$djinn$instantiation$" translator
        False
        visibleArgument
        (\scheme -> historicalCandidateTuples
            historicalCandidates wideCandidates
            (length $ schemeBinders scheme))
        initialSchemes
  where
    atoms = queryAtomSymbols goalFormulas premiseFormulas
    sourceVariableCandidates = variableCandidatesOf variableSpellings
    historicalVariableCandidates = variableCandidatesOf $ sort variableSpellings
    quantifiedCandidates = quantifiedCandidatesOf $ opaqueAtomSources atoms
    historicalCandidates =
        historicalVariableCandidates ++ quantifiedCandidates
    -- The callers supply source first-occurrence order: goal variables first,
    -- then opened skolems and sealed premise scopes. Retain that order for the
    -- wide-binder heuristics so alpha-renaming cannot reshuffle useful
    -- source-ordered runs merely because their spellings sort differently.
    wideCandidates = sourceVariableCandidates ++ quantifiedCandidates
    initialSchemes = hypothesisSchemes atoms

-- | Build an additive positive-only family for a query-local scheme instance
-- whose complete result already occurs in the checked query.
--
-- The historical one- through three-binder family deliberately keeps its
-- lexical Cartesian prefix, which means its sixteen-axiom scheme allowance can
-- miss a later tuple of two different guarded quantified candidates.  This
-- tail preserves that prefix and instead fairly considers the same finite
-- variable/quantified vocabulary.  It retains only tuples which put a
-- quantified candidate in a result-relevant binder, produce a logical axiom
-- not already retained by the complete bounded historical run, and instantiate
-- the scheme body to an alpha-equal subtree of the exact query.
-- No type is invented and every surviving body still crosses the prepared
-- kind check, formula translator, proof checker, and evidence-erasure boundary.
queryCorrelatedInstantiationAxioms
    :: (SharedType.Type String -> Either String Formula)
    -> (SharedType.Type String ->
        Maybe SharedGenerated.VisibleTypeArgument)
    -> InstantiationAxioms
    -> [String]
    -> SharedType.Type String
    -> [Formula]
    -> [Formula]
    -> InstantiationAxioms
queryCorrelatedInstantiationAxioms translator visibleArgument
        historicalAxioms variableSpellings elaboratedGoal
        goalFormulas premiseFormulas =
    buildInstantiationAxiomsExcluding historicalAxiomSet
        "$djinn$query-correlated-instantiation$" translator True
        visibleArgument correlatedTuples initialSchemes
  where
    candidateAtoms = queryAtomSymbols goalFormulas premiseFormulas
    schemeAtoms = concatMap (sidedAtomSymbols ObligationSide) goalFormulas
    sourceVariableCandidates = variableCandidatesOf variableSpellings
    quantifiedCandidates =
        quantifiedCandidatesOf $ opaqueAtomSources candidateAtoms
    quantifiedCandidateKeys = Set.fromList $
        map SharedTypeAtom.alphaTypeKey quantifiedCandidates
    candidates = distinctOn SharedTypeAtom.alphaTypeKey $
        sourceVariableCandidates ++ quantifiedCandidates
    queryTargetKeys = Set.fromList $
        map SharedTypeAtom.alphaTypeKey $
        typeSubtrees $ SharedType.canonicalizeType elaboratedGoal
    historicalAxiomSet = Set.fromList
        [ InstantiationAxiom formula
            (Map.lookup symbol $ instantiationVisibleApplications historicalAxioms) []
        | (symbol, formula) <- instantiationAxiomPremises historicalAxioms
        ]
    correlatedTuples _ | null quantifiedCandidates = []
    correlatedTuples scheme =
        [ arguments
        | arguments <- take maxInstantiationAttempts $
            fairCandidateTuples candidates arity
        , or
            [ binder `Set.member` bodyVariables &&
                SharedTypeAtom.alphaTypeKey argument
                    `Set.member` quantifiedCandidateKeys
            | (binder, argument) <- zip (schemeBinders scheme) arguments
            ]
        , Right instantiated <- [instantiateSchemeBody scheme arguments]
        , SharedTypeAtom.alphaTypeKey instantiated
            `Set.member` queryTargetKeys
        ]
      where
        arity = length $ schemeBinders scheme
        bodyVariables = SharedType.freeVariables $ schemeBody scheme
    initialSchemes = hypothesisSchemes schemeAtoms

-- | Structural demand matching, excluding the earlier correlated family.
-- Unlike tuple guessing, matching selects arbitrarily many correlated
-- arguments in one traversal, including open monotypes and impredicative
-- subtrees. Search work remains bounded and positive-only. Demands never
-- expose a binder from beneath an unopened forall.
queryDirectedInstantiationAxioms
    :: (SharedType.Type String -> Either String Formula)
    -> (SharedType.Type String -> Maybe SharedGenerated.VisibleTypeArgument)
    -> InstantiationAxioms
    -> [String]
    -> SharedType.Type String
    -> [Formula]
    -> [Formula]
    -> InstantiationAxioms
queryDirectedInstantiationAxioms translator visibleArgument historicalAxioms
        variableSpellings elaboratedGoal goalFormulas premiseFormulas =
    directed
  where
    correlated = queryCorrelatedInstantiationAxioms translator visibleArgument
        historicalAxioms variableSpellings elaboratedGoal goalFormulas premiseFormulas
    excluded = Set.fromList
        [ InstantiationAxiom formula
            (Map.lookup symbol $ instantiationVisibleApplications family) []
        | family <- [historicalAxioms, correlated]
        , (symbol, formula) <- instantiationAxiomPremises family
        ]
    atoms = queryAtomSymbols goalFormulas premiseFormulas
    allowed = Set.fromList variableSpellings
    demands = distinctOn SharedTypeAtom.alphaTypeKey $
        variableCandidatesOf variableSpellings ++
        [ subtree
        | source <- elaboratedGoal : opaqueAtomSources atoms
        , subtree <- typeSubtrees source
        , SharedType.freeVariables subtree `Set.isSubsetOf` allowed
        ]
    schemes = distinctOn schemeKey
        [ scheme
        | (HypothesisSide, symbol) <- atoms
        , Just source <- [opaqueSymbolSource symbol]
        , Just scheme <- [directedInstantiationScheme source]
        ]
    directed = buildInstantiationAxiomsWithExclusions False True excluded
        "$djinn$query-directed-instantiation$" translator True visibleArgument
        (\scheme -> directedInstantiationTuples maxInstantiationAttempts
            (schemeSource scheme) demands demands)
        schemes

-- | Recover function carriers from the actual opened formula, rather than
-- guessing the spelling of a binder underneath an unopened source forall.
-- Only owned variable atoms and exact opaque source payloads are reversible.
-- A structural conjunction/disjunction is not evidence of a particular source
-- datatype, so those nodes contribute only their independently reversible
-- children. The checked compiler must reproduce the exact original arrow.
-- Residual results precede larger function types; raw carrier proposals are
-- bounded before alpha deduplication or compilation.
formulaFunctionCarriers
    :: (SharedType.Type String -> Either String Formula)
    -> [String]
    -> [Formula]
    -> [SharedType.Type String]
formulaFunctionCarriers translator variableSpellings formulas =
    distinctOn SharedTypeAtom.alphaTypeKey
        [ source
        | (formula, source) <- take maxInstantiationAttempts $
            concatMap (snd . recover) formulas
        , Right translated <- [translator source]
        , translated == formula
        ]
  where
    owned = Set.fromList variableSpellings
    recover formula = case formula of
        PVar symbol -> (atomSource symbol, [])
        argument :-> result ->
            let (argumentType, argumentCarriers) = recover argument
                (resultType, resultCarriers) = recover result
                source = SharedType.FunctionType <$> argumentType <*> resultType
            in (source, resultCarriers ++ argumentCarriers ++
                maybe [] (\ty -> [(formula, ty)]) source)
        Conj children -> (Nothing, concatMap (snd . recover) children)
        Disj children -> (Nothing, concatMap (snd . recover . snd) children)
        Empty _ -> (Nothing, [])
    atomSource symbol = case opaqueSymbolSource symbol of
        Just source
            | SharedType.freeVariables source `Set.isSubsetOf` owned -> Just source
        _ -> case symbol of
            Symbol spelling | spelling `Set.member` owned ->
                Just $ SharedType.TypeVariable spelling
            _ -> Nothing

-- | A separate positive-only family selects at least one residual function
-- carrier. It cannot consume the historical variable/quantified prefix, and
-- its focused plans may be scheduled independently when alternatives are
-- requested. In particular a fold's fresh output R permits the carrier R -> R
-- without making an unopened source binder R an ambient variable.
queryCarrierInstantiationAxioms
    :: (SharedType.Type String -> Either String Formula)
    -> (SharedType.Type String -> Maybe SharedGenerated.VisibleTypeArgument)
    -> [String]
    -> [Formula]
    -> [Formula]
    -> InstantiationAxioms
queryCarrierInstantiationAxioms translator visibleArgument variableSpellings
        goalFormulas premiseFormulas =
    buildInstantiationAxioms "$djinn$query-carrier-instantiation$" translator
        True visibleArgument carrierTuples (hypothesisSchemes atoms)
  where
    atoms = queryAtomSymbols goalFormulas premiseFormulas
    directCarriers = formulaFunctionCarriers translator variableSpellings
        (goalFormulas ++ premiseFormulas)
    -- An observed function can itself be the state of a continuation. For
    -- example an in-scope a -> a supports the carrier (a -> a) -> a -> a.
    -- Keep the existing proposals first and the same raw proposal bound.
    -- Only monomorphic, source-reversible arrows seed this one-step closure;
    -- the normal instantiated-body compiler still checks every resulting use.
    carriers = distinctOn SharedTypeAtom.alphaTypeKey $ take maxInstantiationAttempts $
        directCarriers ++
        [ SharedType.FunctionType carrier carrier
        | carrier <- directCarriers
        , not $ SharedType.containsForall carrier
        ]
    carrierKeys = Set.fromList $ map SharedTypeAtom.alphaTypeKey carriers
    vocabulary = variableCandidatesOf variableSpellings ++ carriers
    carrierTuples _ | null carriers = []
    carrierTuples scheme =
        [ arguments
        | arguments <- directedInstantiationTuples maxInstantiationAttempts
            (schemeSource scheme) carriers vocabulary
        , any ((`Set.member` carrierKeys) . SharedTypeAtom.alphaTypeKey) arguments
        ]

-- | A demand-directed, positive-only family which can construct a quantified
-- argument after choosing an impredicative provider instance. Unlike the
-- historical exact translator, the scoped translator opens obligation-side
-- foralls in the instantiated provider body. Fresh names are private to one
-- attempted axiom; only the separately checked scoped family below may use
-- them to specialize providers while constructing that argument.
queryConstructedInstantiationAxioms
    :: (Set.Set String -> Natural -> SharedType.Type String ->
        Either String (Formula, [String]))
    -> (Set.Set String -> SharedType.Type String -> Maybe SharedGenerated.VisibleTypeArgument)
    -> [String]
    -> SharedType.Type String
    -> [Formula]
    -> [Formula]
    -> InstantiationAxioms
queryConstructedInstantiationAxioms translator visibleArgument variableSpellings
        elaboratedGoal goalFormulas premiseFormulas = initial
        { instantiationConstructionTranslator = Just translator }
  where
    initial = buildInstantiationAxiomsWithScopedTranslator False True Set.empty
        "$djinn$query-constructed-instantiation$"
        (translator (Set.fromList variableSpellings) . fromIntegral) True
        (visibleArgument $ Set.fromList variableSpellings)
        (\scheme -> distinctOn (map SharedTypeAtom.alphaTypeKey) $
            directedInstantiationTuples maxInstantiationAttempts
                (schemeSource scheme) demands demands ++
            [ replicate (length $ schemeBinders scheme) image
            | image <- demands, SharedType.containsForall image
            ])
        schemes
    atoms = queryAtomSymbols goalFormulas premiseFormulas
    allowed = Set.fromList variableSpellings
    demands = distinctOn SharedTypeAtom.alphaTypeKey $
        variableCandidatesOf variableSpellings ++
        [ subtree
        | source <- elaboratedGoal : opaqueAtomSources atoms
        , subtree <- typeSubtrees source
        , SharedType.freeVariables subtree `Set.isSubsetOf` allowed
        ]
    schemes = distinctOn schemeKey
        [ scheme
        | (HypothesisSide, symbol) <- atoms
        , Just source <- [opaqueSymbolSource symbol]
        , Just scheme <- [directedInstantiationScheme source]
        ]

-- | Keep each argument introduction in a separate proof-search family. Its
-- private rigid variables may specialize original quantified assumptions,
-- enabling polymorphic composition inside the new argument, but never become
-- variables of the enclosing query or another construction family. Derived
-- premises retain ordinary checked instantiation evidence back to the exact
-- original scheme; none is an additional source assumption.
scopedConstructionInstantiationAxioms
    :: (Set.Set String -> SharedType.Type String -> Either String Formula)
    -> (Set.Set String -> SharedType.Type String -> Maybe SharedGenerated.VisibleTypeArgument)
    -> [String]
    -> [Formula]
    -> [Formula]
    -> InstantiationAxioms
    -> [InstantiationAxioms]
scopedConstructionInstantiationAxioms translator visibleArgument variableSpellings
        goalFormulas premiseFormulas constructions =
    [ grow (initial symbol formula skolems) $ jobsFor skolems formula
    | (symbol, formula) <- instantiationAxiomPremises constructions
    , Just skolems <- [Map.lookup symbol $
        instantiationConstructionSkolems constructions]
    ]
  where
    originalAtoms = queryAtomSymbols goalFormulas premiseFormulas
    originalSources = opaqueAtomSources originalAtoms
    originalSchemes = schemesOf originalAtoms
    originalSchemeKeys = Set.fromList $ map schemeKey originalSchemes
    schemesOf atoms = distinctOn schemeKey
        [ scheme
        | (HypothesisSide, symbol) <- atoms
        , Just source <- [opaqueSymbolSource symbol]
        , Just scheme <- [directedInstantiationScheme source]
        ]
    sourceConstructors = Map.fromList
        [ (SharedTypeRender.renderType id source, source)
        | containing <- originalSources
        , source@SharedType.TypeConstructor{} <- typeSubtrees containing
        ]
    initial symbol formula skolems = InstantiationAxioms
        [(symbol, formula)] (Set.singleton symbol)
        (Map.restrictKeys (instantiationVisibleApplications constructions) $
            Set.singleton symbol)
        (Map.singleton symbol skolems)
        (instantiationConstructionTranslator constructions)

    -- All descendants of one root share one attempt and premise allowance.
    -- Breadth-first scheduling lets sibling obligations and source schemes
    -- progress before a provider which can keep exposing another forall.
    grow beginning = loop 0 (maxInstantiationAxioms - 1) beginning
      where
        loop attempt allowance accumulated queue
            | attempt >= maxInstantiationAttempts || allowance <= 0 = accumulated
            | otherwise = case queue of
                [] -> accumulated
                ScopedInstantiationJob scope constructing scheme arguments : rest ->
                    let dependencies = Set.unions $ map SharedType.freeVariables $
                            schemeSource scheme : arguments
                        owners = sortOn (length . symbolSpelling)
                            [ owner
                            | (owner, names) <- Map.toList $
                                instantiationConstructionSkolems accumulated
                            , not $ Set.null $ Set.intersection dependencies $
                                Set.fromList names
                            ]
                        anchor = case reverse owners of
                            owner : _ -> Just owner
                            [] -> Nothing
                        constructionPrefix = case anchor of
                            Just owner -> symbolSpelling owner ++ "$nested$" ++
                                show attempt ++ "$"
                            Nothing -> "$djinn$query-constructed-instantiation$independent$" ++
                                show attempt ++ "$"
                        inherited = case anchor of
                            Nothing -> []
                            Just owner -> concat
                                [ names
                                | (ancestor, names) <- Map.toList $
                                    instantiationConstructionSkolems accumulated
                                , ancestor == owner ||
                                    (symbolSpelling ancestor ++ "$nested$")
                                        `isPrefixOf` symbolSpelling owner
                                ]
                        family = case (constructing,
                            instantiationConstructionTranslator constructions) of
                            (True, Just construct) ->
                                buildInstantiationAxiomsWithScopedTranslator
                                    False True Set.empty
                                    constructionPrefix
                                    (\_ -> construct owned $ fromIntegral $
                                        maxInstantiationAttempts + attempt)
                                    False (visibleArgument owned) (const [arguments]) [scheme]
                            (True, Nothing) -> InstantiationAxioms [] Set.empty
                                Map.empty Map.empty Nothing
                            (False, _) -> buildInstantiationAxiomsWithExclusions
                                False True Set.empty
                                ("$djinn$construction-scope$" ++ show attempt ++ "$")
                                (translator owned) False (visibleArgument owned)
                                (const [arguments]) [scheme]
                        owned = Set.fromList $ scope ++ variableSpellings
                        freshPremises =
                            [ premise
                            | premise@(_, formula) <- instantiationAxiomPremises family
                            , formula `notElem` map snd (instantiationAxiomPremises accumulated)
                            ]
                        retained = Set.fromList $ map fst freshPremises
                        next = accumulated
                            { instantiationAxiomPremises =
                                instantiationAxiomPremises accumulated ++ freshPremises
                            , instantiationAxiomSymbols =
                                instantiationAxiomSymbols accumulated `Set.union` retained
                            , instantiationVisibleApplications = Map.union
                                (instantiationVisibleApplications accumulated)
                                (Map.restrictKeys (instantiationVisibleApplications family) retained)
                            , instantiationConstructionSkolems = Map.union
                                (instantiationConstructionSkolems accumulated)
                                (Map.restrictKeys (instantiationConstructionSkolems family) retained)
                            }
                        children =
                            [ job
                            | (symbol, formula) <- freshPremises
                            , Just introduced <- [Map.lookup symbol $
                                instantiationConstructionSkolems family]
                            , job <- jobsFor (inherited ++ introduced) formula
                            ]
                    in loop (attempt + 1) (allowance - length freshPremises)
                        next (rest ++ children)

    jobsFor skolems formula = roundRobin $ concat
        [ [normalJobs scheme, constructionJobs scheme]
        | scheme <- scopedSchemes
        ]
      where
        fresh = Set.fromList skolems
        allowed = fresh `Set.union` Set.fromList variableSpellings
        body = case formula of _ :-> result -> result; _ -> formula
        bodyAtoms = sidedAtomSymbols HypothesisSide body
        scopedSchemes = distinctOn schemeKey $ originalSchemes ++ schemesOf bodyAtoms
        scopedSources = originalSources ++ opaqueAtomSources bodyAtoms
        vocabulary = distinctOn SharedTypeAtom.alphaTypeKey $
            variableCandidatesOf skolems ++
            [ subtree
            | source <- scopedSources
            , subtree <- typeSubtrees source
            , SharedType.freeVariables subtree `Set.isSubsetOf` allowed
            ]
        obligationTypes atoms = distinctOn SharedTypeAtom.alphaTypeKey
            [ source
            | (ObligationSide, symbol) <- atoms
            , source <- case opaqueSymbolSource symbol of
                Just supplied -> [supplied]
                Nothing | symbolSpelling symbol `Set.member` allowed ->
                    [SharedType.TypeVariable $ symbolSpelling symbol]
                Nothing -> maybe [] (: []) $ Map.lookup
                    (symbolSpelling symbol) sourceConstructors
            , SharedType.freeVariables source `Set.isSubsetOf` allowed
            ]
        obligations = obligationTypes bodyAtoms
        normalJobs scheme =
            [ ScopedInstantiationJob skolems False scheme arguments
            | arguments <- take maxInstantiationAttempts $
                distinctOn (map SharedTypeAtom.alphaTypeKey) $
                    [ replicate (length $ schemeBinders scheme) variable
                    | variable <- variableCandidatesOf skolems
                    ] ++ directedInstantiationTuples maxInstantiationAttempts (schemeSource scheme)
                        vocabulary vocabulary
            , any (not . Set.null . Set.intersection fresh . SharedType.freeVariables)
                arguments ||
                not (Set.null $ Set.intersection fresh $
                    SharedType.freeVariables $ schemeSource scheme) ||
                schemeKey scheme `Set.notMember` originalSchemeKeys
            ]
        constructionJobs scheme =
            [ ScopedInstantiationJob skolems True scheme arguments
            | arguments <- take maxInstantiationAttempts $
                directedInstantiationTuples maxInstantiationAttempts (schemeSource scheme)
                    (obligations ++
                        [ source
                        | schemeKey scheme `Set.notMember` originalSchemeKeys
                        , source <- obligationTypes $ queryAtomSymbols goalFormulas []
                        ]) vocabulary
            ]

-- Scope variables are available only while planning their lexical context.
-- A new construction retains precisely the ancestors mentioned by its source
-- scheme and selected images; a closed later stage can be independent.
data ScopedInstantiationJob = ScopedInstantiationJob
    [String] Bool InstantiationScheme [SharedType.Type String]

-- | Build an additive hypothesis-instantiation tail whose tuples use at
-- least one closed, forall-free subtree already present in the checked query.
--
-- The historical family above deliberately retains its exact candidate order
-- and proof-plan position.  Re-enumerating its expanded pool in place would
-- perturb established result prefixes, while enumerating all tuples again in
-- a second family would duplicate every historical axiom.  This family
-- therefore fairly schedules the combined pool but keeps only tuples which
-- contain a supplied closed candidate.  Mixed variable/quantified/closed
-- tuples remain available, and the existing per-scheme, family, and attempt
-- caps apply independently to this positive-only completeness extension.
queryClosedInstantiationAxioms
    :: (SharedType.Type String -> Either String Formula)
    -> (SharedType.Type String ->
        Maybe SharedGenerated.VisibleTypeArgument)
    -> [String]
    -> [SharedType.Type String]
    -> [Formula]
    -> [Formula]
    -> InstantiationAxioms
queryClosedInstantiationAxioms translator visibleArgument variableSpellings
        closedCandidates goalFormulas premiseFormulas =
    buildInstantiationAxioms "$djinn$query-closed-instantiation$" translator
        True
        visibleArgument
        candidateTuples
        initialSchemes
  where
    candidateAtoms = queryAtomSymbols goalFormulas premiseFormulas
    -- Only hypothesis-side schemes embedded in the requested goal belong to
    -- this local family. Exact loaded schemes have their own retained-source
    -- path; rediscovering global premise variants here would duplicate that
    -- path and could misclassify an ordinary safe local axiom as target-only
    -- diagnostic evidence.
    schemeAtoms = concatMap (sidedAtomSymbols ObligationSide) goalFormulas
    variableCandidates = variableCandidatesOf variableSpellings
    quantifiedCandidates =
        quantifiedCandidatesOf $ opaqueAtomSources candidateAtoms
    retainedClosedCandidates =
        distinctOn SharedTypeAtom.alphaTypeKey closedCandidates
    closedCandidateKeys = Set.fromList $
        map SharedTypeAtom.alphaTypeKey retainedClosedCandidates
    candidates = distinctOn SharedTypeAtom.alphaTypeKey $
        variableCandidates ++ quantifiedCandidates ++ retainedClosedCandidates
    candidateTuples scheme = filter containsClosedCandidate $
        fairCandidateTuples candidates $ length $ schemeBinders scheme
    containsClosedCandidate = any $ \candidate ->
        SharedTypeAtom.alphaTypeKey candidate `Set.member` closedCandidateKeys
    initialSchemes = hypothesisSchemes schemeAtoms

-- | Build the additive instantiation tail for polymorphic values retained from
-- the sealed environment. Unlike the historical hypothesis rule, this phase
-- extends the variable and guarded-impredicative candidates with closed
-- monotype subtrees supplied by the checked query and loaded signatures. Its
-- scheme seeds are explicit so ordinary query-local schemes are not
-- rediscovered under a second proof-symbol family.
loadedInstantiationAxioms
    :: (SharedType.Type String -> Either String Formula)
    -> (SharedType.Type String ->
        Maybe SharedGenerated.VisibleTypeArgument)
    -> [String]
    -> [SharedType.Type String]
    -> [Formula]
    -> [Formula]
    -> [Formula]
    -> InstantiationAxioms
loadedInstantiationAxioms translator visibleArgument variableSpellings
        closedCandidates goalFormulas premiseFormulas loadedSchemeFormulas =
    buildInstantiationAxioms "$djinn$loaded-instantiation$" translator
        True
        visibleArgument
        (\scheme -> fairCandidateTuples candidates $
            length $ schemeBinders scheme)
        initialSchemes
  where
    candidateAtoms = queryAtomSymbols goalFormulas premiseFormulas
    schemeAtoms = concatMap (sidedAtomSymbols HypothesisSide)
        loadedSchemeFormulas
    variableCandidates = variableCandidatesOf variableSpellings
    quantifiedCandidates =
        quantifiedCandidatesOf $ opaqueAtomSources candidateAtoms
    candidates = distinctOn SharedTypeAtom.alphaTypeKey $
        variableCandidates ++ quantifiedCandidates ++ closedCandidates
    initialSchemes = hypothesisSchemes schemeAtoms

-- | Build a bounded family of direct provider-local specialization premises.
--
-- Candidate associations have already crossed the checked public boundary:
-- their provider symbols name exact loaded schemes and each type is a closed,
-- context-free proper type with the retained visible argument supplied beside
-- it. Scheme order is the prepared environment's declaration order; candidate
-- order is the caller's first-occurrence order for that provider. A provider
-- receives no candidate associated with another provider, even when their
-- quantified schemes are alpha-equivalent. When a structural checker is
-- supplied, a completed Cartesian tuple is retained only if lowering preserves
-- that exact vector; nominal specialization supplies no checker.
providerInstantiationPremises
    :: String
    -> (SharedType.Type String -> Either String Formula)
    -> Maybe ProviderInstantiationFidelity
    -> [(Symbol, Formula)]
    -> [( Symbol
        , SharedType.Type String
        , SharedGenerated.VisibleTypeArgument
        )]
    -> ProviderInstantiationPremises
providerInstantiationPremises
        symbolPrefix translator fidelityTranslator schemes candidates =
    providerPremisesWith instantiationScheme
        symbolPrefix translator fidelityTranslator schemes
        (take maxInstantiationAxiomsPerScheme)
        vectorsFor
  where
    vectorsFor provider scheme =
        take maxInstantiationAttempts $
            replicateM (length $ schemeBinders scheme)
                [ (candidateType, visibleArgument)
                | (candidateProvider, candidateType, visibleArgument) <-
                    candidates
                , candidateProvider == provider
                ]

-- | Build direct provider-local premises from complete ordered assignments.
--
-- Each vector has already been checked against the exact provider scheme at
-- the public boundary.  In particular, its length is the leading-binder
-- arity, its arguments are closed types checked at their positional binder
-- kinds, and duplicate alpha-equivalent vectors for one provider have been
-- removed.  Consume the vector as one
-- correlated choice: unlike 'providerInstantiationPremises', this path never
-- reconstructs tuples through a Cartesian product and therefore does not use
-- the historical per-scheme attempt window.
providerInstantiationAssignmentPremises
    :: String
    -> (SharedType.Type String -> Either String Formula)
    -> Maybe ProviderInstantiationFidelity
    -> [(Symbol, Formula)]
    -> [( Symbol
        , [( SharedType.Type String
           , SharedGenerated.VisibleTypeArgument
           )]
        )]
    -> ProviderInstantiationPremises
providerInstantiationAssignmentPremises
        symbolPrefix translator fidelityTranslator schemes assignments =
    providerPremisesWith directedInstantiationScheme
        symbolPrefix translator fidelityTranslator schemes id
        vectorsFor
  where
    vectorsFor provider scheme =
        [ assignment
        | (assignmentProvider, assignment) <- assignments
        , assignmentProvider == provider
        , length assignment == length (schemeBinders scheme)
        ]

-- The two provider-premise families differ only in how a scheme's argument
-- vectors are enumerated (a bounded Cartesian window over per-provider
-- candidates, or the caller's checked complete assignments) and in whether a
-- per-scheme cap applies afterwards.  Everything else is shared here: each
-- vector is instantiated into the scheme body, translated, and kept only if it
-- survives the fidelity check; the retained specializations receive
-- synthetic premise symbols in order, and the visible arguments travel beside
-- them into the application table.
providerPremisesWith
    :: (SharedType.Type String -> Maybe InstantiationScheme)
    -> String
    -> (SharedType.Type String -> Either String Formula)
    -> Maybe ProviderInstantiationFidelity
    -> [(Symbol, Formula)]
    -> ([( Symbol, Formula, [SharedGenerated.VisibleTypeArgument])]
        -> [( Symbol, Formula, [SharedGenerated.VisibleTypeArgument])])
       -- per-scheme cap on the retained specializations
    -> (Symbol -> InstantiationScheme
        -> [[( SharedType.Type String
             , SharedGenerated.VisibleTypeArgument
             )]])
       -- argument vectors, each type paired with its visible argument
    -> ProviderInstantiationPremises
providerPremisesWith
        eligibleScheme symbolPrefix translator fidelityTranslator schemes retainPerScheme
        vectorsFor =
    ProviderInstantiationPremises premises applications
  where
    retained = take maxProviderInstantiationPremises $
        concatMap specialize schemes
    entries =
        [ (Symbol $ symbolPrefix ++ show index, provider, formula, arguments)
        | (index, (provider, formula, arguments)) <-
            zip [0 :: Int ..] retained
        ]
    premises =
        [ (synthetic, formula)
        | (synthetic, _, formula, _) <- entries
        ]
    applications = Map.fromList
        [ (synthetic, (provider, arguments))
        | (synthetic, provider, _, arguments) <- entries
        ]

    specialize (provider, schemeFormula) = case schemeSourceFromFormula
            schemeFormula >>= eligibleScheme of
        Nothing -> []
        Just scheme -> retainPerScheme
            [ (provider, formula, map snd vector)
            | vector <- vectorsFor provider scheme
            , Right instantiated <-
                [instantiateSchemeBody scheme $ map fst vector]
            , Right formula <- [translator instantiated]
            , retainsProviderInstantiationFidelity
                fidelityTranslator scheme (map fst vector)
            ]

    schemeSourceFromFormula formula = case formula of
        PVar symbol -> opaqueSymbolSource symbol
        _ -> Nothing

-- | Expand every free use of a provider-specialization premise into an
-- application to its exact provider. The synthetic head remains in place so
-- the existing visible-evidence converter can turn
-- @synthetic provider@ into @provider @T ...@. LJT reserves environment
-- symbols from binder allocation, but deleting a shadowed key keeps this
-- helper correct for independently constructed terms as well.
rewriteProviderInstantiationEvidence
    :: Map.Map Symbol
        (Symbol, [SharedGenerated.VisibleTypeArgument])
    -> Term
    -> Term
rewriteProviderInstantiationEvidence evidence = go evidence
  where
    go visible term = case term of
        Var synthetic
            | Just (provider, _) <- Map.lookup synthetic visible ->
                Apply (Var synthetic) (Var provider)
        Lam binder body -> Lam binder $ go (Map.delete binder visible) body
        Apply function argument -> Apply
            (go visible function) (go visible argument)
        Xsel index arity expression ->
            Xsel index arity $ go visible expression
        _ -> term

buildInstantiationAxioms
    :: String
    -> (SharedType.Type String -> Either String Formula)
    -> Bool
    -> (SharedType.Type String ->
        Maybe SharedGenerated.VisibleTypeArgument)
    -> (InstantiationScheme -> [[SharedType.Type String]])
    -> [InstantiationScheme]
    -> InstantiationAxioms
buildInstantiationAxioms =
    buildInstantiationAxiomsWithExclusions True False Set.empty

buildInstantiationAxiomsExcluding
    :: Set.Set InstantiationAxiom
    -> String
    -> (SharedType.Type String -> Either String Formula)
    -> Bool
    -> (SharedType.Type String ->
        Maybe SharedGenerated.VisibleTypeArgument)
    -> (InstantiationScheme -> [[SharedType.Type String]])
    -> [InstantiationScheme]
    -> InstantiationAxioms
buildInstantiationAxiomsExcluding =
    buildInstantiationAxiomsWithExclusions True True

buildInstantiationAxiomsWithExclusions
    :: Bool
    -> Bool
    -> Set.Set InstantiationAxiom
    -> String
    -> (SharedType.Type String -> Either String Formula)
    -> Bool
    -> (SharedType.Type String ->
        Maybe SharedGenerated.VisibleTypeArgument)
    -> (InstantiationScheme -> [[SharedType.Type String]])
    -> [InstantiationScheme]
    -> InstantiationAxioms
buildInstantiationAxiomsWithExclusions discoverNested deduplicateFormula excludedAxioms
        symbolPrefix translator interleaveSchemes
        visibleArgument candidateTuples schemes =
    buildInstantiationAxiomsWithScopedTranslator discoverNested deduplicateFormula
        excludedAxioms symbolPrefix (\_ source -> (\formula -> (formula, [])) <$> translator source) interleaveSchemes
        visibleArgument candidateTuples schemes

buildInstantiationAxiomsWithScopedTranslator
    :: Bool
    -> Bool
    -> Set.Set InstantiationAxiom
    -> String
    -> (Int -> SharedType.Type String -> Either String (Formula, [String]))
    -> Bool
    -> (SharedType.Type String ->
        Maybe SharedGenerated.VisibleTypeArgument)
    -> (InstantiationScheme -> [[SharedType.Type String]])
    -> [InstantiationScheme]
    -> InstantiationAxioms
buildInstantiationAxiomsWithScopedTranslator discoverNested deduplicateFormula excludedAxioms
        symbolPrefix translator interleaveSchemes
        visibleArgument candidateTuples schemes =
    InstantiationAxioms premises symbols visibleApplications constructionSkolems Nothing
  where
    entries =
        [ (Symbol $ symbolPrefix ++ show index, axiom)
        | (index, axiom) <- zip [0 :: Int ..] $
            buildAxiomFormulas discoverNested deduplicateFormula excludedAxioms
                interleaveSchemes translator visibleArgument
                candidateTuples schemes
        ]
    premises =
        [ (symbol, instantiationAxiomFormula axiom)
        | (symbol, axiom) <- entries
        ]
    symbols = Set.fromList $ map fst premises
    visibleApplications = Map.fromList
        [ (symbol, arguments)
        | (symbol, axiom) <- entries
        , Just arguments <- [instantiationAxiomVisibleArguments axiom]
        ]
    constructionSkolems = Map.fromList
        [ (symbol, skolems)
        | (symbol, axiom) <- entries
        , let skolems = instantiationAxiomSkolems axiom
        , not $ null skolems
        ]

-- | Enumerate every source subtree which is closed and contains no explicit
-- forall. Candidates may have any kind: a higher-kinded subtree can be the
-- correct image of a higher-kinded binder. The caller checks the complete
-- instantiated body in its prepared kind scope before retaining an axiom.
closedMonotypeSubtrees
    :: SharedType.Type String -> [SharedType.Type String]
closedMonotypeSubtrees = distinctOn SharedTypeAtom.alphaTypeKey .
    filter isClosedMonotype . typeSubtrees . SharedType.canonicalizeType
  where
    isClosedMonotype source =
        Set.null (SharedType.freeVariables source) &&
            not (SharedType.containsForall source)

typeSubtrees :: SharedType.Type String -> [SharedType.Type String]
typeSubtrees source = source : case source of
    SharedType.TypeVariable{} -> []
    SharedType.TypeConstructor{} -> []
    SharedType.TypeApplication function argument ->
        typeSubtrees function ++ typeSubtrees argument
    SharedType.FunctionType parameter result ->
        typeSubtrees parameter ++ typeSubtrees result
    SharedType.TupleType _ elements -> concatMap typeSubtrees elements
    SharedType.ForallType _ constraints body ->
        concatMap typeSubtrees (concatMap constraintArguments constraints) ++
            typeSubtrees body

-- Quantified subtrees and their impredicative wrappers are usable as
-- instantiation arguments. A nested forall whose body mentions an enclosing
-- binder is not a sequent-level type, so only subtrees closed under the whole
-- atom's free variables qualify.
closedQuantifiedSubtrees
    :: SharedType.Type String -> [SharedType.Type String]
closedQuantifiedSubtrees source =
    [ subtree
    | subtree <- quantifiedSubtrees source
    , SharedType.freeVariables subtree `Set.isSubsetOf` sourceFree
    ]
  where
    sourceFree = SharedType.freeVariables source

-- Every subtree which contains an explicit forall, including structural
-- ancestors such as @Maybe (forall a. a -> a)@. The containing wrapper is a
-- query-supplied type just as surely as the quantified atom itself; retaining
-- it lets guarded impredicative instantiation use the complete supplied shape
-- without guessing a new quantifier.
quantifiedSubtrees :: SharedType.Type String -> [SharedType.Type String]
quantifiedSubtrees source = case source of
    SharedType.TypeVariable{} -> []
    SharedType.TypeConstructor{} -> []
    SharedType.TypeApplication function argument ->
        containing source $
            quantifiedSubtrees function ++ quantifiedSubtrees argument
    SharedType.FunctionType parameter result ->
        containing source $
            quantifiedSubtrees parameter ++ quantifiedSubtrees result
    SharedType.TupleType _ elements -> containing source $
        concatMap quantifiedSubtrees elements
    SharedType.ForallType _ constraints body ->
        source :
            concatMap quantifiedSubtrees
                (concatMap constraintArguments constraints) ++
            quantifiedSubtrees body
  where
    containing wrapper nested
        | null nested = []
        | otherwise = wrapper : nested

-- Worklist over schemes. Instantiating a scheme can expose a strictly
-- shallower hypothesis-side forall in its own body; such discoveries join the
-- end of the queue. Loaded jobs are interleaved for attempt fairness, while
-- historical jobs retain their compatibility order.
data InstantiationJob
    = SchemeJob InstantiationScheme
    | AxiomJob InstantiationScheme Int [[SharedType.Type String]]

buildAxiomFormulas
    :: Bool
    -> Bool
    -> Set.Set InstantiationAxiom
    -> Bool
    -> (Int -> SharedType.Type String -> Either String (Formula, [String]))
    -> (SharedType.Type String ->
        Maybe SharedGenerated.VisibleTypeArgument)
    -> (InstantiationScheme -> [[SharedType.Type String]])
    -> [InstantiationScheme]
    -> [InstantiationAxiom]
buildAxiomFormulas discoverNested deduplicateFormula excludedAxioms interleaveSchemes
        translator visibleArgument candidateTuples initialSchemes = loop
    (Set.fromList $ map schemeKey startingSchemes)
    excludedAxioms
    maxInstantiationAttempts
    maxInstantiationAxioms
    (map SchemeJob startingSchemes)
  where
    -- A retained historical axiom can expose a shallower hypothesis scheme
    -- without the correlated tuple producer ever recreating that bridge (for
    -- example when the bridge itself uses no quantified argument). Seed those
    -- descendants directly; later duplicate attempts retain the same closure
    -- behavior for schemes exposed recursively by correlated formulas.
    startingSchemes = distinctOn schemeKey $
        initialSchemes ++
        concatMap
            (discoveredSchemes . instantiationAxiomFormula)
            (Set.toList excludedAxioms)

    loop seenSchemes seenAxioms attempts allowance queue = case queue of
        _ | attempts <= 0 || allowance <= 0 -> []
        [] -> []
        SchemeJob scheme : jobs -> loop seenSchemes seenAxioms attempts
            allowance $
                AxiomJob scheme maxInstantiationAxiomsPerScheme
                    (candidateTuples scheme)
                : jobs
        AxiomJob _ schemeAllowance _ : jobs
            | schemeAllowance <= 0 ->
                loop seenSchemes seenAxioms attempts allowance jobs
        AxiomJob _ _ [] : jobs ->
            loop seenSchemes seenAxioms attempts allowance jobs
        AxiomJob scheme schemeAllowance (arguments : tuples) : jobs
            | otherwise -> case schemeAxiom (maxInstantiationAttempts - attempts)
                    scheme arguments of
                Just axiom ->
                    let discovered = distinctOn schemeKey
                            [ found
                            | found <- discoveredSchemes
                                $ instantiationAxiomFormula axiom
                            , schemeKey found `Set.notMember` seenSchemes
                            ]
                        seenSchemes' = foldr (Set.insert . schemeKey)
                            seenSchemes discovered
                        next retainedAllowance =
                            reschedule
                                (AxiomJob scheme retainedAllowance tuples)
                                jobs ++ map SchemeJob discovered
                        alreadySeen =
                            axiom `Set.member` seenAxioms ||
                            ( deduplicateFormula && any
                                ((instantiationAxiomFormula axiom ==) .
                                    instantiationAxiomFormula)
                                (Set.toList seenAxioms)
                            )
                    in if alreadySeen
                        then loop seenSchemes' seenAxioms
                            (attempts - 1) allowance
                            (next schemeAllowance)
                        else axiom : loop seenSchemes'
                            (Set.insert axiom seenAxioms)
                            (attempts - 1)
                            (allowance - 1)
                            (next $ schemeAllowance - 1)
                _ -> loop seenSchemes seenAxioms (attempts - 1) allowance
                    (reschedule
                        (AxiomJob scheme schemeAllowance tuples) jobs)

    -- Historical query-local axioms retain their exact depth-first sequence.
    -- Loaded declarations instead take one tuple attempt per turn, so a
    -- vacuous or mostly ill-kinded early scheme cannot spend the global
    -- attempt allowance before a later provider receives its first chance.
    reschedule job jobs
        | interleaveSchemes = jobs ++ [job]
        | otherwise = job : jobs

    schemeAxiom index scheme arguments = do
        instantiated <- rightToMaybe $
            instantiateSchemeBody scheme arguments
        (bodyFormula, skolems) <- rightToMaybe $ translator index instantiated
        let hypothesis = PVar $ opaqueTypeSymbol $ schemeSource scheme
        if bodyFormula == hypothesis
            then Nothing
            else Just $ InstantiationAxiom
                (hypothesis :-> bodyFormula)
                (visibleArguments scheme arguments)
                skolems

    visibleArguments scheme arguments = case requiredPrefixLengths of
        [] -> Nothing
        lengths -> traverse retainArgument $
            take (last lengths) $ zip (schemeBinders scheme) arguments
      where
        bodyVariables = SharedType.freeVariables $ schemeBody scheme
        inferableVariables = outsideForallVariables $ schemeBody scheme
        needsPolytypeShape binder argument =
            binder `Set.notMember` inferableVariables &&
                SharedType.containsForall argument
        retainArgument (binder, argument)
            | needsPolytypeShape binder argument = rightToMaybe $
                SharedGenerated.partiallySpecifiedVisibleTypeArgument argument
            | binder `Set.member` bodyVariables =
                Just SharedGenerated.inferredVisibleTypeArgument
            | otherwise = visibleArgument argument
        -- Visible application is positional. Retain the shortest prefix that
        -- reaches every vacuous binder, using inferred placeholders for any
        -- earlier open choice; later binders remain implicit so GHC can still
        -- perform ordinary and guarded impredicative inference for them.
        requiredPrefixLengths =
            [ index
            | (index, (binder, argument)) <- zip [1 :: Int ..] $
                zip (schemeBinders scheme) arguments
            , binder `Set.notMember` bodyVariables || needsPolytypeShape binder argument
            ]

    -- GHC can infer ordinary impredicative arguments from an exposed result
    -- occurrence, but cannot discover a polytype through a nested forall.
    -- Preserve that quantified shape as visible syntax instead of erasing the
    -- checked instantiation. Ambient variables become inference holes.
    outsideForallVariables source = case source of
        SharedType.ForallType{} -> Set.empty
        SharedType.TypeVariable variable -> Set.singleton variable
        SharedType.TypeConstructor{} -> Set.empty
        SharedType.TypeApplication function argument ->
            outsideForallVariables function `Set.union` outsideForallVariables argument
        SharedType.FunctionType argument result ->
            outsideForallVariables argument `Set.union` outsideForallVariables result
        SharedType.TupleType _ fields -> Set.unions $ map outsideForallVariables fields

    -- The axiom itself acts as a premise: its domain atom becomes an
    -- obligation while its body joins the hypothesis side, so only body
    -- schemes feed the closure.
    discoveredSchemes axiom
        | not discoverNested = []
        | otherwise =
        [ scheme
        | (HypothesisSide, symbol) <-
            sidedAtomSymbols HypothesisSide axiom
        , Just source <- [opaqueSymbolSource symbol]
        , Just scheme <- [instantiationScheme source]
        ]

    rightToMaybe = either (const Nothing) Just

-- One- through three-binder query-local schemes retain their exact historical
-- lexical Cartesian order. Wider schemes use the source-order widening
-- introduced with the original bounded rule.
historicalCandidateTuples
    :: [SharedType.Type String]
    -> [SharedType.Type String]
    -> Int
    -> [[SharedType.Type String]]
historicalCandidateTuples historicalCandidates wideCandidates arity
    | arity <= maxCartesianInstantiationBinders =
        replicateM arity historicalCandidates
    | otherwise = fairCandidateTuplesWith False wideCandidates arity

-- Loaded declarations can be late in a standard session. Draw from both ends
-- and interleave useful tuple families for every arity so the bounded prefix
-- cannot be monopolized by unrelated earlier declarations.
fairCandidateTuples
    :: [SharedType.Type String]
    -> Int
    -> [[SharedType.Type String]]
fairCandidateTuples = fairCandidateTuplesWith True

fairCandidateTuplesWith
    :: Bool
    -> [SharedType.Type String]
    -> Int
    -> [[SharedType.Type String]]
fairCandidateTuplesWith recentFirst candidates arity =
    distinctOn id $ roundRobin
    [ prioritizeEdges recentFirst $ candidateWindows arity candidates
    , map (replicate arity) $ prioritizeEdges recentFirst candidates
    , roundRobin
        [ orderedSelections arity candidates
        , orderedSelections arity $ reverse candidates
        ]
    , replicateM arity candidates
    ]

candidateWindows :: Int -> [value] -> [[value]]
candidateWindows arity values
    | arity <= 0 = [[]]
    | otherwise = case splitAt arity values of
        (window, _)
            | length window == arity ->
                window : candidateWindows arity (drop 1 values)
        _ -> []

orderedSelections :: Int -> [value] -> [[value]]
orderedSelections 0 _ = [[]]
orderedSelections _ [] = []
orderedSelections count (value : values) =
    map (value :)
        (orderedSelections (count - 1) values) ++
    orderedSelections count values

edgeFirst :: Ord value => [value] -> [value]
edgeFirst values = distinctOn id $ roundRobin [values, reverse values]

-- Loaded declarations are commonly appended to the standard environment, so
-- give that recent edge the first slot while still alternating both ends.
lateEdgeFirst :: Ord value => [value] -> [value]
lateEdgeFirst values = distinctOn id $ roundRobin [reverse values, values]

prioritizeEdges :: Ord value => Bool -> [value] -> [value]
prioritizeEdges recentFirst
    | recentFirst = lateEdgeFirst
    | otherwise = edgeFirst

roundRobin :: [[value]] -> [value]
roundRobin streams = case
        [ (value, remaining)
        | value : remaining <- streams
        ] of
    [] -> []
    active -> map fst active ++ roundRobin (map snd active)

instantiateSchemeBody
    :: InstantiationScheme
    -> [SharedType.Type String]
    -> Either
        (SharedType.SubstitutionError String)
        (SharedType.Type String)
instantiateSchemeBody scheme arguments =
    SharedType.substituteTypeVariables freshVariable Set.empty
        (Map.fromList $ zip (schemeBinders scheme) arguments)
        (schemeBody scheme)
  where
    freshVariable reserved variable = Just $ choose $ variable ++ "'"
      where
        choose candidate
            | candidate `Set.member` reserved = choose $ candidate ++ "'"
            | otherwise = candidate
