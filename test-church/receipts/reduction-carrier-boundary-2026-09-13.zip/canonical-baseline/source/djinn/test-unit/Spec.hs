module Main (main) where

import Control.Monad (forM_, void)
import Control.Exception (evaluate)
import Data.List (findIndex, isInfixOf, isPrefixOf, isSuffixOf, nub, sort)
import qualified Data.Map.Strict as Map
import Data.Maybe (listToMaybe)
import qualified Data.Set as Set
import Data.Void (Void, absurd)
import Numeric.Natural (Natural)
import System.Timeout (timeout)
import Test.Tasty (defaultMain, testGroup)
import Test.Tasty.HUnit (Assertion, assertBool, assertEqual, testCase)
import Text.ParserCombinators.ReadP (ReadP, eof, readP_to_S, skipSpaces)
import Text.Read (readMaybe)

import Djinn.Core (
    Context, Declaration(..), DjinnCandidateDetails(..),
    DjinnQueryMetadata(..), DjinnResult, DjinnTypedResult,
    DjinnTermGraphAbsence(..),
    DjinnSourceProviderEvidence(..),
    DjinnDeclarationNameRole(..), QueryOutcome(..),
    DjinnQueryError(..), DjinnQueryOptionsError(..),
    SynthesisDeclarationError(..), SynthesisEnvironmentError(..),
    SynthesisTypeError(..),
    classDeclarations, declare, defaultQueryOptions, emptyEnvironment,
    functionDeclarations, generatedReportCandidates,
    generatedReportCompletion, generatedReportEvidence,
    generatedReportFormula, generatedReportProof,
    inhabit, inhabitGenerated, inhabitResult,
    inhabitGeneratedPrepared, inhabitResultPrepared,
    inhabitSynthesisResultPrepared, inhabitTypedSynthesisResultPrepared,
    inhabitTypedSynthesisResultPreparedWithSourceGoal,
    inhabitTypedSynthesisStreamPreparedWithSourceGoal,
    generatedReportCandidates,
    kArrow, kStar, optionAlternatives, optionBudget, optionCutoff, optionSorted,
    optionStrategy, optionRanking, optionProviderCosts,
    fromSynthesisDeclaration, fromSynthesisEnvironment,
    fromSynthesisKind, fromSynthesisType,
    mkContext, parseContextualHType, parseHKind, parseHType,
    prepareEnvironment, removeDeclaration,
    reportCompletion, reportGeneratedClauses, reportOutcome,
    resolveContext, resolveInstanceMethods, resolvePreparedContext,
    standardEnvironment, toSynthesisDeclaration, toSynthesisEnvironment,
    toSynthesisInventory,
    toSynthesisKind,
    toSynthesisType, typeDeclarations)
import Djinn.Internal.Environment (validateEnvironment)
import qualified Djinn.Internal.Environment as RawEnvironment
import qualified Djinn.Internal.CheckedCandidate as CheckedCandidate
import qualified Djinn.Internal.Generated as DjinnGenerated
import Djinn.Internal.GeneratedDeduplication
    (deduplicateEtaEquivalentClausesOn, etaNormalClauseExpression)
import Djinn.Internal.HCheck (
    htCheckEnv, htCheckType, htCheckTypeKind, htCheckTypesKinds,
    htInferClassKinds)
import Djinn.Internal.HIdentifier
import Djinn.Internal.HTypes hiding (fromSynthesisKind, toSynthesisKind)
import Djinn.Internal.LJT
import Djinn.Internal.PlanFamily (nextAdmittedPlanFamily)
import qualified Djinn.Internal.InstantiationEvidence as InstantiationEvidence
import Djinn.Internal.ProofCheck (checkProof)
import qualified Djinn.Internal.ProofCheck.Evidence as ProofEvidence
import Djinn.Internal.ProofEnv
import HCheckCompatibility (hCheckCompatibilityTests)
import HKindCompatibility (hKindCompatibilityTests)
import HTypeCompatibility (hTypeCompatibilityTests)
import qualified Language.Haskell.Djex.Djinn as Djex
import Language.Haskell.Synthesis.Constraint
    (Constraint(..), constraintArguments, constraintArity, constraintClass)
import qualified Language.Haskell.Synthesis.Candidate as SharedCandidate
import qualified Language.Haskell.Synthesis.CandidateQuality as SharedQuality
import qualified Language.Haskell.Synthesis.Diagnostic as SharedDiagnostic
import qualified Language.Haskell.Synthesis.Name as SharedName
import qualified Language.Haskell.Synthesis.Declaration as SharedDeclaration
import qualified Language.Haskell.Synthesis.Generated as SharedGenerated
import qualified Language.Haskell.Synthesis.Environment as SharedEnvironment
import qualified Language.Haskell.Synthesis.Inventory as SharedInventory
import qualified Language.Haskell.Synthesis.Kind as SharedKind
import qualified Language.Haskell.Synthesis.KindInference as SharedInference
import qualified Language.Haskell.Synthesis.Query as SharedQuery
import qualified Language.Haskell.Synthesis.Search as SharedSearch
import qualified Language.Haskell.Synthesis.Type as SharedType
import qualified Language.Haskell.Synthesis.TypeAtom as SharedTypeAtom
import qualified Language.Haskell.Synthesis.TypeRender as SharedTypeRender
import qualified Language.Haskell.Synthesis.TypeSynonym as SharedTypeSynonym
import qualified Language.Haskell.Synthesis.TypedCandidate
    as SharedTypedCandidate
import qualified Language.Haskell.Synthesis.TypedGenerated as SharedTypedGenerated

main :: IO ()
main = defaultMain $ testGroup "Djinn unit tests" $
    [testCase name action | (name, action) <- tests]

tests :: [(String, Assertion)]
tests =
    hKindCompatibilityTests ++
    hTypeCompatibilityTests ++
    hCheckCompatibilityTests ++
    [ ("structural provider quality precedes the raw proof cutoff", testCandidateQuality)
    , ("demand-directed rank-N instantiation", testDirectedRankN)
    , ("enumerate scoped residual carriers within explicit raw bounds", testResidualFunctionCarriers)
    , ("synthesize supplied-default reductions with nonassociative order", testReductionCarriers)
    , ("enumerate both endomorphism compositions within the original raw bounds", testEndomorphismCompositionAlternatives)
    , ("retain an ordinary first result at the one-proof carrier cutoff", testCarrierFirstResult)
    , ("retain exact choice fuel after the first proof prefix", testFirstProofPrefixBudget)
    , ("resume raw proof cursors without repeating proofs or refunding choices", testProofSearchCursor)
    , ("retain nested proof products and branch-local freshness", testNestedProofProduct)
    , ("enumerate reusable heads and exact partial-function spines", testNormalTermAlternatives)
    , ("finish proved finite normal layers while retaining recursive alternatives", testFiniteNormalLayers)
    , ("keep same-rendered residual atoms logically distinct", testNormalResidualIdentity)
    , ("retain repeated local and global heads across context extension", testNormalContextExtension)
    , ("interleave carriers without starving append and filter", testCarrierPlanFairness)
    , ("admit a later formula view beside a prolific proof cursor", testFormulaPlanAdmission)
    , ("skip suppressed formula families before forcing their generators", testLazyPlanFamilyAdmission)
    , ("deliver a streaming candidate before a poisoned global ranking and large tail", testCandidateStreamFirstDelivery)
    , ("retain cumulative streaming proof and choice allowances", testCandidateStreamBudgets)
    , ("bound supplied-fold constructor introductions in batch and streaming", testConstructorCompositionBudgets)
    , ("retain streaming source graph ownership and distinct graph keys", testCandidateStreamGraphs)
    , ("separate streaming terminal logical evidence from truncation", testCandidateStreamEvidence)
    , ("retain contextual streaming identity with exact unused Given authority", testCandidateStreamContext)
    , ("validate streaming requests before observing their search", testCandidateStreamValidation)
    , ("stream a demanded singleton bridge reused by alpha-equivalent quantified inputs", testCandidateStreamDemandedSingleton)
    , ("stream cooperating quantified bridges at the exact demanded result", testCandidateStreamDemandedGroup)
    , ("stream a quantified consumer at a function-valued accumulator", testCandidateStreamFunctionAccumulator)
    , ("retain finite proof fairness and exact choices under streaming normal priority", testStreamingNormalPriorityAccounting)
    , ("reuse one fold bridge on two distinct opaque inputs", testFoldBridgeReuse)
    , ("retain both binary compositions over the inner result", testBinaryCompositionWithOuterResult)
    , ("compose endomorphisms using the last result argument", testEndomorphismCompositionWithOuterResult)
    , ("construct impredicative arguments under fresh scopes", testConstructedRankN)
    , ("transport-directed rank-N opacity", testTransportRankN)
    , ("parse prefix function constructor", testPrefixArrowParsing)
    , ("parse maximal Djinn type and kind spines", testMaximalParserSpines)
    , ("render union prefixes without forcing field tails",
          testProductiveUnionRendering)
    , ("parse and render through the checked Djinn adapter",
          testCheckedDjinnAdapter)
    , ("reject residual constraints at the Djinn rendering boundary",
          testDjinnResidualRendering)
    , ("reuse checked shared Djinn requests across sessions",
          testCheckedDjinnRequestReuse)
    , ("rebuild immutable Djinn session indexes from neutral environments",
          testCheckedDjinnSessionRebuilding)
    , ("agree between ground and weakened edit transactions",
          testGroundEditAgreement)
    , ("kind-check intrinsic list syntax", testIntrinsicListKind)
    , ("render canonical units and kinds", testCanonicalRendering)
    , ("round-trip shared source types", testSharedTypeAdapter)
    , ("retain structural higher-kinded exact assignments",
          testStructuralHigherKindedAssignments)
    , ("infer simple positive rank-N types with an opaque fallback",
          testRankNTypeAtoms)
    , ("retain nominal parametric-data transport beside structural search",
          testNominalParametricDataPlans)
    , ("introduce recursive data without enabling recursive elimination",
          testRecursiveDataIntroduction)
    , ("preserve nominal parametric-data projection boundaries",
          testNominalDataProjectionBoundaries)
    , ("reach nominal parametric data behind a closed goal",
          testNominalClosedGoalReachability)
    , ("reach nominal data through closed aggregate providers",
          testNominalAggregateProviderReachability)
    , ("merge complementary rank-N formula plans within global bounds",
          testComplementaryRankNPlans)
    , ("deduplicate multi-argument eta expansions alpha-equivalently",
          testMultiArgumentEtaDeduplication)
    , ("round-trip shared declarations", testSharedDeclarationAdapter)
    , ("round-trip shared environments", testSharedEnvironmentAdapter)
    , ("normalize raw abstract definitions at every environment boundary",
          testRawAbstractDefinitionNormalization)
    , ("prepare neutral Djinn environments authoritatively",
          testNeutralDjinnPreparation)
    , ("cache prepared global premises in declaration order",
          testPreparedFunctionPremises)
    , ("compile prepared raw and shared types to identical formulas",
          testPreparedFormulaParity)
    , ("project raw Djinn kinds from the authoritative inventory",
          testRawDjinnPreparationKinds)
    , ("bound malformed Djinn context arity observation",
          testBoundedContextArity)
    , ("normalize aliases inside opaque formula atoms", testOpaqueAliasAtoms)
    , ("reject every raw recursive type-expansion graph finitely",
          testRawTypeExpansionCycles)
    , ("preserve raw expansion substitution semantics",
          testRawExpansionSubstitution)
    , ("prepare raw recursive data after alias expansion",
          testRawEnvironmentRecursionPreflight)
    , ("validate unused synonyms before recursion preflight",
          testPreparedSynonymValidationOwnership)
    , ("preserve raw operational synonym errors",
          testOperationalSynonymCompatibilityError)
    , ("separate synonym saturation from kind errors",
          testSynonymSaturationBoundary)
    , ("elaborate prepared query synonyms without changing compatibility views",
          testPreparedQuerySynonyms)
    , ("infer and reuse a higher-kinded synonym", testHigherKindedGrounding)
    , ("reject an ill-kinded higher-kinded application", testIllKindedApplication)
    , ("reject a higher-kinded synonym body", testHigherKindedSynonymBody)
    , ("infer and enforce class parameter kinds", testClassParameterKinds)
    , ("prove intuitionistic tautologies", testProvableBasics)
    , ("prove empty goals from contradictions", testEmptyGoalContradiction)
    , ("reject non-theorems", testNonTheorems)
    , ("honor search budgets and strategies", testSearchModes)
    , ("carry a query search strategy", testQueryOptionsStrategy)
    , ("prefer distinct evidence across adjacent curried domains",
          testDistinctCurriedArguments)
    , ("rotate fairly across three repeated-domain proofs",
          testThreeWayCurriedArguments)
    , ("bound repeated-domain fairness to the oldest three proofs",
          testWideCurriedArguments)
    , ("preserve row-major DFS outside binary endomorphisms",
          testNonEndomorphicCurriedArguments)
    , ("reach the repeated-domain fairness tail when interleaving",
          testInterleavedWideCurriedArguments)
    , ("use an assumption as its named proof", testNamedAssumption)
    , ("reject ambiguous raw proof environments",
          testCheckedProofSearchEnvironment)
    , ("do not capture a caller-supplied proof symbol", testCallerSymbolCapture)
    , ("keep disjunction continuation atoms fresh", testContinuationAtomCapture)
    , ("preserve residual application after Csplit", testCsplitResidualArguments)
    , ("preserve residual handler lambdas after Csplit",
          testCsplitResidualHandlerLambda)
    , ("preserve a whole product through Csplit", testCsplitProductIdentity)
    , ("bind unary constructor fields without tuple parentheses",
          testUnaryConstructorPattern)
    , ("preserve residual application after Ccases", testCcasesResidualArguments)
    , ("hoist mixed wildcard and live case binders safely",
          testMixedCaseLambdaBinders)
    , ("preserve tuple payloads in unary constructors", testUnaryTuplePayload)
    , ("merge tuple refinements across case branches", testBranchRefinements)
    , ("reconstruct whole constructor payloads", testWholeConstructorPayload)
    , ("resolve instance contexts in one kind scope",
          testResolveInstanceMethods)
    , ("justify self-reference diagnostics with proof evidence",
          testSelfReferenceEvidence)
    , ("isolate external proof identities", testProofEnvironment)
    , ("preserve proof-check compatibility through typed evidence",
          testCheckedProofEvidenceParity)
    , ("project sidecar-retaining results without compatibility drift",
          testValidatedCandidateResultParity)
    , ("project typed Djinn results through the retained association",
          testTypedDjinnCoreProjectionParity)
    , ("preserve monomorphic and quantified source goals through prepared search",
          testPreparedSourceGoalGraphs)
    , ("retain source aliases and jointly opened class contexts",
          testPreparedSourceContextCorrespondence)
    , ("reject unrelated prepared source goals before publishing evidence",
          testPreparedSourceGoalMismatch)
    , ("retain the first checked sidecar through eta de-duplication",
          testValidatedCandidateDeduplication)
    , ("move checked sidecars with stable candidate-detail sorting",
          testValidatedCandidateSorting)
    , ("allocate typed candidate keys after final ranking",
          testValidatedCandidateFinalKeys)
    , ("project compatibility candidates without forcing sidecars",
          testValidatedCandidateProjectionLaziness)
    , ("defer typed graph checking without forcing sidecars",
          testValidatedTypedProjectionLaziness)
    , ("retain production rank-N evidence before instantiation erasure",
          testValidatedRankNProductionEvidence)
    , ("retain checker-known rank-N proof source types",
          testCheckedProofRankNTypes)
    , ("retain impredicative proof application intermediate types",
          testCheckedProofImpredicativeApplications)
    , ("fully prune every retained proof-node type",
          testCheckedProofFinalPruning)
    , ("retain correlated unresolved intermediate proof types",
          testCheckedProofUnconstrainedIntermediate)
    , ("type-check generated proofs independently", testGeneratedProofsCheck)
    , ("allocate wide proof metavariable plans without reuse",
          testWideProofMetas)
    , ("reject malformed proof terms", testMalformedProofTerms)
    , ("preserve nominal empty types", testNominalEmptyTypes)
    , ("validate declaration mutations transactionally", testEnvironmentValidation)
    , ("keep the printed value namespace unambiguous",
          testPrintedValueNamespace)
    , ("reserve unit declarations for the standard environment",
          testTrustedUnitDeclaration)
    , ("retain only the exact intrinsic list declaration across source adapters",
          testIntrinsicListDeclaration)
    , ("render shadowing terms without capture", testScopeSafeRendering)
    , ("report malformed proof rendering", testMalformedRendering)
    , ("validate generated clauses at conversion", testGeneratedClauseBoundary)
    , ("respect declaration keyword token boundaries", testKeywordTokens)
    , ("accept only Haskell identifiers and operators", testIdentifiers)
    , ("validate every boundary of the Djinn.Core facade", testCoreFacade)
    ]

testCheckedDjinnAdapter :: IO ()
testCheckedDjinnAdapter = do
    session <- expectShownRight Djex.standardDjinnSession
    target <- expectShownRight $ SharedName.mkIdentifier "identity"
    request <- expectShownRight $ Djex.parseDjinnRequest
        session defaultQueryOptions target "identity-query.djinn"
        "Eq a => a -> a"
    let expectedGoal = SharedType.FunctionType
            (SharedType.TypeVariable "a")
            (SharedType.TypeVariable "a")
        expectedContexts =
            [Constraint (sharedName "Eq") [SharedType.TypeVariable "a"]]
        parsedQuery = Djex.djinnRequestQuery request
    SharedGenerated.definitionName (SharedQuery.requestTarget parsedQuery)
        `assertEqualReversed` target
    SharedQuery.requestGoal parsedQuery `assertEqualReversed` expectedGoal
    SharedQuery.requestContexts parsedQuery `assertEqualReversed`
        expectedContexts
    SharedQuery.requestOptions parsedQuery `assertEqualReversed`
        defaultQueryOptions

    -- Programmatic callers cross the same checked boundary as the parser;
    -- the opaque request preserves the shared query losslessly once sealed.
    checkedTarget <- expectShownRight $
        SharedGenerated.mkDefinitionName target
    checkedRequest <- expectShownRight $ Djex.parseDjinnRequestWithCheckedTarget
        session defaultQueryOptions checkedTarget "identity-query.djinn"
        "Eq a => a -> a"
    assertEqual "raw and checked-target Djinn parsers agree"
        request checkedRequest
    let programmaticQuery = SharedQuery.QueryRequest
            { SharedQuery.requestTarget = checkedTarget
            , SharedQuery.requestGoal = expectedGoal
            , SharedQuery.requestContexts = expectedContexts
            , SharedQuery.requestOptions = defaultQueryOptions
            }
    programmaticRequest <- expectShownRight $
        Djex.mkDjinnRequest programmaticQuery
    assertEqual "programmatic request round-trip"
        programmaticQuery (Djex.djinnRequestQuery programmaticRequest)
    assertEqual "request provenance does not affect equality"
        request programmaticRequest
    assertEqual "request provenance does not affect display"
        (show programmaticRequest) (show request)

    result <- expectShownRight $
        Djex.runDjinnQuery session programmaticRequest
    case SharedSearch.batchCandidates $ SharedQuery.resultSearch result of
        candidate : _ -> do
            assertEqual "Djinn candidates expose shared residual types"
                [] (SharedCandidate.candidateResidualConstraints candidate)
            assertEqual "the adapter renders a complete top-level definition"
                (Right "identity a = a")
                (Djex.renderDjinnCandidateDefinition
                    Djex.FullyQualified candidate)
            assertEqual "expression rendering reconstructs clause lambdas"
                (Right "\\a -> a")
                (Djex.renderDjinnCandidateExpression
                    Djex.FullyQualified candidate)
        [] -> fail "the checked Djinn adapter found no identity candidate"

    -- The public request remains the exact shared value supplied by its caller.
    -- In particular, sealing a saturated prefix arrow must not rewrite
    -- djinnRequestQuery even though execution later normalizes it to the
    -- structural FunctionType form.
    let noncanonicalGoal = SharedType.TypeApplication
            (SharedType.TypeApplication
                (SharedType.TypeConstructor SharedName.functionName)
                (SharedType.TypeVariable "a"))
            (SharedType.TypeVariable "a")
        noncanonicalQuery = programmaticQuery
            { SharedQuery.requestGoal = noncanonicalGoal
            , SharedQuery.requestContexts = []
            }
    noncanonicalRequest <- expectShownRight $
        Djex.mkDjinnRequest noncanonicalQuery
    assertEqual "request projection rewrote a noncanonical shared type"
        noncanonicalQuery (Djex.djinnRequestQuery noncanonicalRequest)
    nativeResult <- expectShownRight $
        Djex.runDjinnQuery session noncanonicalRequest
    prepared <- expectShownRight $ prepareEnvironment standardEnvironment
    rawResult <- expectShownRight $
        inhabitResultPrepared defaultQueryOptions prepared [] checkedTarget
            (HTArrow (HTVar "a") (HTVar "a"))
    nativeCoreResult <- expectShownRight $
        inhabitSynthesisResultPrepared defaultQueryOptions prepared []
            checkedTarget noncanonicalGoal
    assertEqual "native and raw prepared core query paths diverged"
        rawResult nativeCoreResult
    assertEqual "the stable adapter rebuilt the native core result"
        nativeCoreResult nativeResult

    let malformedSource = "Eq a => a -> a ;"
    case Djex.parseDjinnRequestWithCheckedTarget
            session defaultQueryOptions checkedTarget
            "malformed-query.djinn" malformedSource of
        Left failure -> do
            assertEqual "parse failures have a stable diagnostic code"
                (Just "DJEX_DJINN_PARSE")
                (SharedDiagnostic.diagnosticCode failure)
            assertEqual "parse failures retain their caller-supplied source"
                (Just "malformed-query.djinn")
                (SharedDiagnostic.diagnosticSource failure)
            assertEqual "parse failures retain their complete input span"
                (Just $ SharedDiagnostic.sourceTextSpan malformedSource)
                (SharedDiagnostic.diagnosticSpan failure)
        Right _ -> fail "the checked Djinn parser accepted trailing input"

    let unsupportedGoal = SharedType.TupleType SharedName.Unboxed
            [SharedType.TypeVariable "a"]
        unsupportedQuery = programmaticQuery
            { SharedQuery.requestGoal = unsupportedGoal }
    case Djex.mkDjinnRequest unsupportedQuery of
        Left failure -> assertEqual
            "unsupported shared types fail while sealing the request"
            (Just "DJEX_DJINN_LOWER")
            (SharedDiagnostic.diagnosticCode failure)
        Right _ -> fail "the Djinn request constructor accepted an unboxed tuple"

    qualifier <- expectShownRight $ SharedName.mkModuleName "External"
    invalidClass <- expectShownRight $
        SharedName.mkQualifiedIdentifier qualifier "Eq"
    let invalidClassQuery = programmaticQuery
            { SharedQuery.requestContexts =
                [Constraint invalidClass [SharedType.TypeVariable "a"]] }
    invalidClassFailure <- case Djex.mkDjinnRequest invalidClassQuery of
        Left failure -> do
            assertEqual "qualified classes fail while sealing the request"
                (Just "DJEX_DJINN_LOWER")
                (SharedDiagnostic.diagnosticCode failure)
            pure failure
        Right _ -> fail "the Djinn request constructor accepted a qualified class"
    let invalidEmbeddedClassQuery = programmaticQuery
            { SharedQuery.requestGoal = SharedType.ForallType []
                [Constraint invalidClass [SharedType.TypeVariable "a"]]
                expectedGoal
            , SharedQuery.requestContexts = []
            }
    case Djex.mkDjinnRequest invalidEmbeddedClassQuery of
        Left failure -> assertEqual
            "qualified embedded classes fail while sealing the request"
            (Just "DJEX_DJINN_LOWER")
            (SharedDiagnostic.diagnosticCode failure)
        Right _ -> fail
            "the Djinn request constructor accepted a qualified embedded class"
    let interContextPrecedenceQuery = programmaticQuery
            { SharedQuery.requestContexts =
                [ Constraint invalidClass [SharedType.TypeVariable "a"]
                , Constraint (sharedName "Eq") [unsupportedGoal]
                ]
            }
    case Djex.mkDjinnRequest interContextPrecedenceQuery of
        Left failure -> assertEqual
            "an earlier class failure was overtaken by a later context type"
            invalidClassFailure failure
        Right _ -> fail "the Djinn request constructor lost both context errors"

    invalidTarget <- expectShownRight $
        SharedName.mkQualifiedIdentifier qualifier "identity"
    case Djex.parseDjinnRequest session defaultQueryOptions invalidTarget
            "bad-target.djinn" "(" of
        Left failure -> do
            assertEqual "target validation precedes query parsing"
                (Just "DJEX_DJINN_TARGET")
                (SharedDiagnostic.diagnosticCode failure)
            assertEqual "a target error is not mislabeled as a source error"
                Nothing (SharedDiagnostic.diagnosticSource failure)
        Right _ -> fail "the checked Djinn parser accepted a qualified target"
  where
    -- Keep the visually useful expected value on the right without obscuring
    -- the field projected through the opaque request boundary.
    assertEqualReversed actual expected = assertEqual "parsed request field"
        expected actual

testDjinnResidualRendering :: IO ()
testDjinnResidualRendering = do
    target <- expectShownRight $ SharedName.mkIdentifier "identity"
    checkedTarget <- expectShownRight $
        SharedGenerated.mkDefinitionName target
    let output = SharedGenerated.FunctionClause checkedTarget
            [SharedGenerated.Bind "value"]
            (SharedGenerated.Local "value")
        residual = Constraint (sharedName "Eq")
            [SharedType.TypeVariable "a"]
        candidate = SharedCandidate.Candidate
            { SharedCandidate.candidateOutput = output
            , SharedCandidate.candidateResidualConstraints = [residual]
            , SharedCandidate.candidateDetails = DjinnCandidateDetails 0 0
            }
    assertEqual "the expression renderer presented an open Djinn candidate"
        (Left SharedGenerated.UnexpectedResidualConstraints)
        (Djex.renderDjinnCandidateExpression
            SharedGenerated.Unqualified candidate)
    assertEqual "the definition renderer presented an open Djinn candidate"
        (Left SharedGenerated.UnexpectedResidualConstraints)
        (Djex.renderDjinnCandidateDefinition
            SharedGenerated.Unqualified candidate)

testCheckedDjinnRequestReuse :: IO ()
testCheckedDjinnRequestReuse = do
    initial <- expectShownRight Djex.standardDjinnSession
    let selected body = SharedDeclaration.TypeSynonymDeclaration ()
            (sharedName "Selected") []
            (SharedType.TypeConstructor $ sharedName body)
    boolSession <- sealDjinnSessionFrom initial [selected "Bool"]
    voidSession <- sealDjinnSessionFrom initial [selected "Void"]
    target <- expectShownRight $ SharedName.mkIdentifier "selectedValue"
    checkedTarget <- expectShownRight $ SharedGenerated.mkDefinitionName target
    let query = SharedQuery.QueryRequest
            { SharedQuery.requestTarget = checkedTarget
            , SharedQuery.requestGoal =
                SharedType.TypeConstructor $ sharedName "Selected"
            , SharedQuery.requestContexts = []
            , SharedQuery.requestOptions = defaultQueryOptions
            }
    request <- expectShownRight $ Djex.mkDjinnRequest query
    boolResult <- expectShownRight $ Djex.runDjinnQuery boolSession request
    voidResult <- expectShownRight $ Djex.runDjinnQuery voidSession request
    assertBool "a request did not elaborate Selected against the Bool session"
        $ not $ null $ SharedSearch.batchCandidates
        $ SharedQuery.resultSearch boolResult
    assertEqual "a request retained the Bool meaning of Selected in another session"
        [] $ SharedSearch.batchCandidates $ SharedQuery.resultSearch voidResult
    assertEqual "the empty Selected session lost proof-backed evidence"
        SharedQuery.ProvedUninhabitable
        (SharedQuery.resultEvidence voidResult)

expectShownRight :: Show failure => Either failure value -> IO value
expectShownRight = either (fail . show) return

-- | Build a fresh immutable checked session from the exact neutral source of
-- another session plus additional declarations. Curated callers use this
-- route instead of the raw declaration editor retained by the historical REPL.
sealDjinnSessionFrom
    :: Djex.DjinnSession
    -> [SharedDeclaration.Declaration String Void ()]
    -> IO Djex.DjinnSession
sealDjinnSessionFrom initial additions = do
    environment <- expectShownRight $ SharedEnvironment.mkEnvironment $
        SharedEnvironment.environmentDeclarations
            (Djex.djinnSessionEnvironment initial) ++ additions
    expectShownRight $ Djex.mkDjinnSession environment

-- The historical editor has ground and kind-weakened entrances. Pin that
-- these compatibility transactions cannot drift even though neither is part
-- of the immutable curated session API.
testGroundEditAgreement :: IO ()
testGroundEditAgreement = do
    initial <- expectShownRight Djex.standardDjinnSession
    let groundEnv = Djex.djinnSessionEnvironment initial
        weakened = SharedEnvironment.mapEnvironmentKindVariables
            absurd groundEnv
        agreeDeclare label declaration = agree label
            (RawEnvironment.declareGroundSynthesisEnvironment
                declaration groundEnv)
            (RawEnvironment.declareSynthesisEnvironment declaration weakened)
        agreeRemove label name = agree label
            (RawEnvironment.removeGroundSynthesisDeclaration name groundEnv)
            (RawEnvironment.removeSynthesisDeclaration name weakened)
        assertProtectedUnit label result = case result of
            Left ProtectedSynthesisUnit -> return ()
            Left failure -> fail $ label ++ ": wrong failure: " ++ show failure
            Right _ -> fail $ label ++ ": unit deletion unexpectedly succeeded"
        agree label groundResult weakenedResult =
            case (groundResult, weakenedResult) of
                (Left groundFailure, Left weakenedFailure) -> assertEqual
                    (label ++ ": failure values diverged")
                    weakenedFailure groundFailure
                (Right (groundCandidate, groundPrepared),
                 Right (weakenedCandidate, weakenedPrepared)) -> do
                    assertEqual (label ++ ": edited environments diverged")
                        weakenedCandidate
                        (SharedEnvironment.mapEnvironmentKindVariables absurd
                            groundCandidate)
                    assertEqual (label ++ ": raw projections diverged")
                        (RawEnvironment.preparedEnvironmentSource
                            weakenedPrepared)
                        (RawEnvironment.preparedEnvironmentSource
                            groundPrepared)
                    assertEqual (label ++ ": sealed inventories diverged")
                        (SharedInventory.inventoryEnvironment
                            $ RawEnvironment.preparedEnvironmentInventory
                                weakenedPrepared)
                        (SharedInventory.inventoryEnvironment
                            $ RawEnvironment.preparedEnvironmentInventory
                                groundPrepared)
                (Left failure, Right _) -> fail $ label
                    ++ ": only the ground transaction failed: " ++ show failure
                (Right _, Left failure) -> fail $ label
                    ++ ": only the weakened transaction failed: "
                    ++ show failure
    agreeDeclare "declare a function"
        $ Function "probe" $ HTArrow (HTVar "a") (HTVar "a")
    agreeDeclare "declare a synonym"
        $ TypeSynonym "Probe" ["a"] $ HTVar "a"
    agreeDeclare "declare a class" $ ClassDecl "Probeable" ["a"]
        [("probeOut", HTVar "a")]
    agreeDeclare "reject the protected unit" $ DataType "()" [] [("()", [])]
    agreeDeclare "reject an unsolved kind"
        $ AbstractType "Mystery" $ KVar 0
    agreeRemove "remove a standalone datatype" "Either"
    agreeRemove "reject removing the unit" "()"
    agreeRemove "reject removing whitespace-normalized unit" " () "
    assertProtectedUnit "ground whitespace-normalized unit protection"
        $ RawEnvironment.removeGroundSynthesisDeclaration " () " groundEnv
    agreeRemove "reject removing a missing name" "missing"

testCheckedDjinnSessionRebuilding :: IO ()
testCheckedDjinnSessionRebuilding = do
    initial <- expectShownRight Djex.standardDjinnSession
    let proper = SharedKind.ProperTypeKind
        constructor name = SharedType.TypeConstructor $ sharedName name
        abstract name = SharedDeclaration.AbstractTypeDeclaration ()
            (sharedName name) proper
        selected destination = SharedDeclaration.TypeSynonymDeclaration ()
            (sharedName "Selected") [] (constructor destination)
        selectedValue = SharedDeclaration.ValueDeclaration $
            SharedDeclaration.ValueSignature () (sharedName "selected")
                (constructor "Selected")
    selectedA <- sealDjinnSessionFrom initial
        [abstract "A", abstract "B", selected "A", selectedValue]
    selectedB <- sealDjinnSessionFrom initial
        [abstract "A", abstract "B", selected "B", selectedValue]
    targetA <- expectShownRight $ SharedName.mkIdentifier "answerA"
    requestA <- expectShownRight $ Djex.parseDjinnRequest
        selectedA defaultQueryOptions targetA "synonym-cache.djinn" "A"
    beforeReplacement <- expectShownRight $
        Djex.runDjinnQuery selectedA requestA
    assertBool "the alias-backed premise did not initially prove A"
        $ hasCandidates beforeReplacement

    staleA <- expectShownRight $ Djex.runDjinnQuery selectedB requestA
    assertBool "a rebuilt session retained another session's alias formula"
        $ not $ hasCandidates staleA
    targetB <- expectShownRight $ SharedName.mkIdentifier "answerB"
    requestB <- expectShownRight $ Djex.parseDjinnRequest
        selectedB defaultQueryOptions targetB "synonym-cache.djinn" "B"
    freshB <- expectShownRight $ Djex.runDjinnQuery selectedB requestB
    assertBool "a fresh session did not compile its own alias formula"
        $ hasCandidates freshB

    let selectable method = SharedDeclaration.ClassDeclaration ()
            (sharedName "Selectable")
            [SharedDeclaration.TypeParameter "a" Nothing]
            []
            [ SharedDeclaration.ValueSignature () (sharedName method)
                (SharedType.TypeVariable "a")
            ]
    oldClass <- sealDjinnSessionFrom initial
        [abstract "Marker", selectable "oldMethod"]
    newClass <- sealDjinnSessionFrom initial
        [abstract "Marker", selectable "newMethod"]
    withoutClass <- sealDjinnSessionFrom initial [abstract "Marker"]
    target <- expectShownRight $ SharedName.mkIdentifier "selectedBool"
    checkedTarget <- expectShownRight $ SharedGenerated.mkDefinitionName target
    let classRequestSource = SharedQuery.QueryRequest
            { SharedQuery.requestTarget = checkedTarget
            , SharedQuery.requestGoal = constructor "Marker"
            , SharedQuery.requestContexts =
                [Constraint (sharedName "Selectable") [constructor "Marker"]]
            , SharedQuery.requestOptions = defaultQueryOptions
            }
    classRequest <- expectShownRight $ Djex.mkDjinnRequest classRequestSource
    oldResult <- expectShownRight $ Djex.runDjinnQuery oldClass classRequest
    newResult <- expectShownRight $ Djex.runDjinnQuery newClass classRequest
    assertEqual "a class method became an essential proof premise"
        [] $ SharedSearch.batchCandidates $ SharedQuery.resultSearch oldResult
    assertEqual "a rebuilt session changed dictionary-independent search"
        (SharedQuery.resultEvidence oldResult)
        (SharedQuery.resultEvidence newResult)
    assertEqual "an omitted essential class method produced false negative evidence"
        SharedQuery.NoEvidence $ SharedQuery.resultEvidence oldResult
    case Djex.runDjinnQuery withoutClass classRequest of
      Left failure -> assertBool "an absent class lost its lookup diagnostic"
            $ "Class not found: Selectable" `isInfixOf`
                unwords (SharedDiagnostic.diagnosticContext failure)
      Right result -> fail $ "an absent class produced a result: " ++ show result
  where
    hasCandidates = not . null . SharedSearch.batchCandidates .
        SharedQuery.resultSearch

-- The library facade must make invalid environments unrepresentable and
-- report search results honestly.
testCoreFacade :: IO ()
testCoreFacade = do
    -- Boundary validation of declarations.
    assertLeft "a lowercase type name is rejected"
        (declare (DataType "bad" [] []) emptyEnvironment)
    assertLeft "a duplicate type parameter is rejected"
        (declare (TypeSynonym "Pair" ["a", "a"]
            (HTTuple [HTVar "a", HTVar "a"])) emptyEnvironment)
    recursiveEnvironment <- expectRight $
        declare (DataType "Nat" []
            [("Zero", []), ("Succ", [HTCon "Nat"])]) emptyEnvironment
    recursiveReport <- expectRight $ inhabit defaultQueryOptions
        recursiveEnvironment [] "zeroNat" $ HTCon "Nat"
    case reportOutcome recursiveReport of
        Realized clauses -> assertBool
            "a recursive datatype lost its visible base constructor"
            $ any ("Zero" `isInfixOf`) clauses
        outcome -> fail $ "recursive constructor introduction failed: "
            ++ show outcome
    assertLeft "a constructor owned by another type is rejected"
        (declare (DataType "MyBool" [] [("True", [])])
            standardEnvironment)
    assertLeft "an unsolved kind variable cannot be declared"
        (declare (AbstractType "Mystery" (KVar 0)) emptyEnvironment)
    assertLeft "an ill-kinded function type is rejected"
        (declare (Function "f" (HTApp (HTCon "Bool") (HTVar "a")))
            standardEnvironment)
    assertLeft "a type synonym must be fully saturated in higher-kinded use" $ do
        environment <- declare
            (TypeSynonym "Pair" ["a", "b"]
                (HTTuple [HTVar "a", HTVar "b"]))
            standardEnvironment
        environment' <- declare
            (AbstractType "HK" $ kArrow (kArrow kStar kStar) kStar)
            environment
        let partialPair = HTApp (HTCon "Pair") (HTVar "a")
            wrapped = HTApp (HTCon "HK") partialPair
        inhabit defaultQueryOptions environment' [] "badSynonym"
            (HTArrow wrapped wrapped)
    assertLeft "a method-owning clash across classes is rejected"
        (declare (ClassDecl "Eq2" ["a"]
            [("==", HTVar "a")]) standardEnvironment)

    -- Removal is transactional and total.
    assertLeft "removing an undefined name is an error"
        (removeDeclaration "nosuch" standardEnvironment)
    assertLeft "removing a depended-upon type is rejected"
        (removeDeclaration "Void" standardEnvironment)
    case removeDeclaration "Not" standardEnvironment of
        Left message -> fail $ "removing a leaf synonym failed: " ++ message
        Right environment ->
            assertLeft "the removal must actually take effect"
                (removeDeclaration "Not" environment)

    -- Parsing consumes the whole input.
    assertEqual "parseHType parses ordinary types"
        (Right $ HTArrow (HTVar "a") (HTVar "a")) (parseHType "a -> a")
    assertLeft "trailing garbage is a parse error" (parseHType "a -> a ->")
    assertEqual "contextual parsing shares the complete compatibility grammar"
        (Right ([context "Eq" [HTVar "a"]],
            HTArrow (HTVar "a") (HTVar "a")))
        (parseContextualHType "Eq a => a -> a")
    assertLeft "contextual parsing rejects trailing input"
        (parseContextualHType "Eq a => a -> a ;")
    assertEqual "parseHKind parses higher kinds"
        (Right $ KArrow (KArrow KStar KStar) KStar)
        (parseHKind "(* -> *) -> *")

    -- Contexts use the shared nominal syntax while Djinn retains lookup and
    -- kind semantics behind its checked string bridge.
    let eqContext = context "Eq" [HTVar "a"]
    assertEqual "a shared context retains its nominal class"
        "Eq" (show $ constraintClass eqContext)
    assertEqual "a shared context retains its backend type arguments"
        [HTVar "a"] (constraintArguments eqContext)
    assertEqual "a shared context reports its arity" 1
        (constraintArity eqContext)
    assertEqual "a shared context has stable Haskell rendering"
        "Eq a" (show eqContext)
    assertLeft "a variable cannot name a class context"
        (mkContext "eq" [HTVar "a"])
    assertLeft "direct shared contexts still pass Djinn's class-name guard"
        (resolveContext standardEnvironment $
            Constraint (sharedName "eq") [HTVar "a"])

    -- Queries report honest outcomes.
    swap <- expectRight $ parseHType "(a, b) -> (b, a)"
    swapReport <- expectRight $
        inhabit defaultQueryOptions standardEnvironment [] "swap" swap
    assertEqual "swap is realized with the canonical clause"
        (Realized ["swap (a, b) = (b, a)"]) (reportOutcome swapReport)
    assertEqual "a completed realization reports finished exploration"
        SharedSearch.Finished (reportCompletion swapReport)
    case reportGeneratedClauses swapReport of
        [clause] -> assertEqual
            "rendered compatibility output derives from the shared clause"
            (Right "swap (a, b) = (b, a)")
            (SharedGenerated.renderFunctionClause
                (SharedGenerated.RenderOptions
                    SharedGenerated.FullyQualified id []) clause)
        clauses -> fail $ "unexpected structured swap candidates: " ++ show clauses
    peirce <- expectRight $ parseHType "((a -> b) -> a) -> a"
    peirceReport <- expectRight $
        inhabit defaultQueryOptions standardEnvironment [] "peirce" peirce
    assertEqual "Peirce's law is decided unrealizable"
        Unrealizable (reportOutcome peirceReport)
    assertEqual "logical refutation completed operationally"
        SharedSearch.Finished (reportCompletion peirceReport)
    starved <- expectRight $ inhabit
        defaultQueryOptions { optionBudget = Just 0 }
        standardEnvironment [] "peirce" peirce
    assertEqual "an expired budget is undecided, not unrealizable"
        Undecided (reportOutcome starved)
    assertEqual "budget exhaustion retains its operational reason"
        (SharedSearch.truncated SharedSearch.ChoicePointLimitReached)
        (reportCompletion starved)
    selfRef <- expectRight $ do
        environment <- declare (Function "token" (HTVar "a"))
            standardEnvironment
        inhabit defaultQueryOptions environment [] "token" (HTVar "a")
    assertEqual "a lone same-named assumption is flagged, not recursed"
        UnrealizableWithoutSelfReference (reportOutcome selfRef)

    -- Contexts resolve through inferred kinds.
    assertLeft "a kind-mismatched class argument is rejected"
        (resolveContext standardEnvironment $ context "Monad" [HTCon "Bool"])
    assertLeft "one variable cannot have inconsistent kinds across arguments" $ do
        environment <- declare
            (ClassDecl "ApplyToBool" ["f", "unused"]
                [("applyToBool", HTApp (HTVar "f") (HTCon "Bool"))])
            standardEnvironment
        resolveContext environment $ context "ApplyToBool"
            [HTVar "shared", HTVar "shared"]
    assertLeft "a context and goal must share kind assignments" $ do
        environment <- declare (ClassDecl "Value" ["a"] [])
            standardEnvironment
        let higherKinded = HTApp (HTVar "f") (HTCon "Bool")
        inhabit defaultQueryOptions environment [context "Value" [HTVar "f"]]
            "badKinds" (HTArrow higherKinded higherKinded)
    assertLeft "negative public search budgets are rejected" $
        inhabit defaultQueryOptions { optionBudget = Just (-1) }
            standardEnvironment [] "identity" (HTArrow (HTVar "a") (HTVar "a"))
    checkedIdentity <- expectShownRight $ SharedGenerated.mkDefinitionName $
        sharedName "identity"
    case inhabitResult defaultQueryOptions {optionCutoff = 0}
            standardEnvironment [] checkedIdentity
            (HTArrow (HTVar "a") (HTVar "a")) of
        Left (DjinnQueryOptionsFailure (NonPositiveCandidateCutoff 0)) ->
            return ()
        other -> fail $ "unexpected cutoff validation result: " ++ show other
    case inhabitResult defaultQueryOptions {optionBudget = Just (-7)}
            standardEnvironment [] checkedIdentity
            (HTArrow (HTVar "a") (HTVar "a")) of
        Left (DjinnQueryOptionsFailure (NegativeChoicePointBudget (-7))) ->
            return ()
        other -> fail $ "unexpected budget validation result: " ++ show other
    assertEqual "the historical option error text remains stable"
        (Left "optionCutoff must be positive")
        (inhabitGenerated defaultQueryOptions {optionCutoff = 0}
            standardEnvironment [] "identity"
            (HTArrow (HTVar "a") (HTVar "a")))
    assertEqual "the historical budget error text remains stable"
        (Left "optionBudget must be non-negative")
        (inhabitGenerated defaultQueryOptions {optionBudget = Just (-7)}
            standardEnvironment [] "identity"
            (HTArrow (HTVar "a") (HTVar "a")))
    reflexive <- expectRight $ inhabit defaultQueryOptions
        standardEnvironment [context "Eq" [HTVar "a"]] "reflexive"
        (HTArrow (HTVar "a") (HTCon "Bool"))
    case reportOutcome reflexive of
        Realized candidates -> do
            assertBool "an irrelevant context produced no inhabitant"
                $ not $ null candidates
            assertBool "a class method leaked into dictionary-independent search"
                $ all (not . isInfixOf "==") candidates
        other -> fail $ "reflexive was not realized: " ++ show other
    proofEnvironment <- expectRight $ do
        withProof <- declare (DataType "Proof" [] []) emptyEnvironment
        declare (ClassDecl "Witness" ["a"]
            [("witness", HTCon "Proof")]) withProof
    essentialA <- expectRight $ inhabit defaultQueryOptions proofEnvironment
        [context "Witness" [HTVar "a"]] "essential" (HTCon "Proof")
    essentialB <- expectRight $ inhabit defaultQueryOptions proofEnvironment
        [context "Witness" [HTVar "b"]] "essential" (HTCon "Proof")
    assertEqual "class-method omission became a source-level refutation"
        Undecided (reportOutcome essentialA)
    assertEqual "alpha-renaming a context changed its proof power"
        (reportOutcome essentialA) (reportOutcome essentialB)

expectRight :: Either String a -> IO a
expectRight = either fail return

context :: HSymbol -> [HType] -> Context
context className arguments =
    case mkContext className arguments of
        Left message -> error $
            "invalid context in Djinn regression suite: " ++ message
        Right result -> result

sharedName :: String -> SharedName.Name
sharedName source =
    case SharedName.parseName source of
        Left nameError -> error $
            "invalid shared name in Djinn regression suite: " ++
            SharedName.renderNameError nameError
        Right result -> result

testPrefixArrowParsing :: IO ()
testPrefixArrowParsing = do
    let expected = HTArrow (HTVar "a") (HTVar "b")
        parsed = readMaybe "(->) a b"
    assertEqual "prefix and infix arrows should have one representation"
        (Just expected) parsed
    assertEqual "the canonical rendering should use infix arrow syntax"
        "a -> b" (show expected)

testMaximalParserSpines :: IO ()
testMaximalParserSpines = do
    assertEqual "tuple and application parsing retains source association"
        (Right $ HTArrow
            (HTTuple [HTVar "a", HTVar "b"])
            (HTApp (HTApp (HTCon "Result") (HTVar "a")) (HTVar "b")))
        (parseHType "(a, b) -> Result a b")
    assertEqual "parenthesized contexts retain every constraint and argument"
        [ [ context "Eq" [HTVar "a"]
          , context "Monad" [HTVar "m"]
          ]
        ]
        (parseFully pHContext "(Eq a, Monad m) =>")
    assertEqual "datatype alternatives retain constructor field order"
        [HTUnion
            [ ("Nothing", [])
            , ("Just", [HTVar "a"])
            , ("Pair", [HTVar "a", HTVar "b"])
            ]]
        (parseFully pHDataType "Nothing | Just a | Pair a b")
    assertEqual "kind arrows remain right-associative"
        (Right $ KArrow KStar $ KArrow KStar KStar)
        (parseHKind "* -> * -> *")
    assertLeft "a trailing tuple separator remains invalid"
        (parseHType "(a,)")
    assertLeft "a trailing kind arrow remains invalid"
        (parseHKind "* ->")
    assertBool "a trailing context separator remains invalid" $
        null $ parseFully pHContext "(Eq a,) =>"
    assertBool "a trailing datatype separator remains invalid" $
        null $ parseFully pHDataType "Just a |"

    -- These parser-level counts are deterministic strictness regressions:
    -- ReadP's ordinary many/sepBy combinators would expose every shorter
    -- prefix even though this grammar has only one maximal token spine.
    assertEqual "a type application emits only its maximal parse" 1
        (length $ readP_to_S pHType $ unwords $ replicate 128 "F")
    assertEqual "an arrow kind emits only its maximal parse" 1
        (length $ readP_to_S pHKind $ unwords $ replicate 128 "* ->" ++ ["*"])

    let wideSize = 10000
        wideApplication = unwords $ "F" : replicate wideSize "a"
        wideKind = unwords $ replicate wideSize "* ->" ++ ["*"]
    parsedApplication <- expectRight $ parseHType wideApplication
    parsedKind <- expectRight $ parseHKind wideKind
    assertEqual "wide application parsing retains every argument"
        wideSize (applicationArgumentCount parsedApplication)
    assertEqual "wide kind parsing retains every arrow"
        wideSize (kindArrowCount parsedKind)
  where
    applicationArgumentCount = go 0
      where
        go count (HTApp function _) = go (count + 1) function
        go count _ = count

    kindArrowCount = go 0
      where
        go count (KArrow _ result) = go (count + 1) result
        go count _ = count

testProductiveUnionRendering :: IO ()
testProductiveUnionRendering = do
    let poisonedFields = HTCon "()" :
            error "union rendering forced the unrequested field tail"
        source = HTUnion [("Constructor", poisonedFields)]
    assertEqual "the constructor prefix is available independently"
        (Just 'C') (listToMaybe $ show source)
    assertEqual "finite union rendering retains field and alternative order"
        "Nothing | Just a | Pair a b"
        (show $ HTUnion
            [ ("Nothing", [])
            , ("Just", [HTVar "a"])
            , ("Pair", [HTVar "a", HTVar "b"])
            ])

testIntrinsicListKind :: IO ()
testIntrinsicListKind = do
    let listOfA = HTApp (HTCon "[]") (HTVar "a")
    assertEqual "list syntax should parse to the intrinsic [] constructor"
        (Just listOfA) (readMaybe "[a]")
    assertEqual "the intrinsic list constructor should render canonically"
        "[a]" (show listOfA)
    assertEqual "a list type should kind-check without an environment declaration"
        (Right ()) (htCheckType [] $ HTArrow listOfA listOfA)

testCanonicalRendering :: IO ()
testCanonicalRendering = do
    assertEqual "unit should not acquire an extra pair of parentheses"
        "()" (show $ HTCon "()")
    assertEqual "unit syntax permits ordinary token whitespace"
        (Just $ HTCon "()") (readMaybe "( )")
    assertEqual "kinds should use the syntax accepted by the parser"
        "(* -> *) -> * -> *"
        (show $ KArrow (KArrow KStar KStar) (KArrow KStar KStar))

testSharedTypeAdapter :: IO ()
testSharedTypeAdapter = do
    source <- expectRight $ parseHType "(a, [b]) -> Maybe a"
    shared <- either (fail . show) pure $ toSynthesisType source
    assertEqual "the shared type satisfies its own invariants"
        (Right ()) (SharedType.validateType shared)
    assertEqual "the shared renderer preserves Djinn source syntax"
        (show source) (SharedTypeRender.renderType id shared)
    assertEqual "ordinary Djinn types retain the native shared tree"
        (Just shared) (hTypeSynthesisStructure source)
    assertEqual "native shared trees wrap without recursive conversion"
        (Just source) (fromHTypeSynthesisStructure shared)
    assertEqual "Djinn's source-type subset round-trips losslessly"
        (Right source) (fromSynthesisType shared)
    unit <- either (fail . show) pure $ toSynthesisType $ HTCon "()"
    assertEqual "unit is the structural nullary tuple"
        (SharedType.TupleType SharedName.Boxed []) unit
    assertEqual "unit returns to Djinn's canonical constructor form"
        (Right $ HTCon "()") (fromSynthesisType unit)
    assertBool "a caller-built empty tuple retains its historical constructor"
        (HTTuple [] /= HTCon "()")
    assertEqual "nested canonical units project as constructor atoms"
        (Right $ HTTuple [HTCon "()", HTCon "()"])
        (fromSynthesisType $ SharedType.TupleType SharedName.Boxed
            [ SharedType.TupleType SharedName.Boxed []
            , SharedType.TupleType SharedName.Boxed []
            ])
    pairName <- expectShownRight $ SharedName.tupleName SharedName.Boxed 2
    let pairConstructor = SharedType.TypeConstructor pairName
            :: SharedType.Type String
        partialPair = SharedType.TypeApplication pairConstructor
            $ SharedType.TypeConstructor $ sharedName "Natural"
    projectedPair <- expectShownRight $ fromSynthesisType pairConstructor
    projectedPartialPair <- expectShownRight $ fromSynthesisType partialPair
    assertEqual "the native boxed pair constructor retains its shared identity"
        (Just pairConstructor) (hTypeSynthesisStructure projectedPair)
    assertEqual "the native boxed pair constructor renders without double parentheses"
        "(,)" (show projectedPair)
    assertEqual "a partially applied boxed pair renders as a higher-kinded type"
        "(,) Natural" (show projectedPartialPair)
    assertEqual "the native boxed pair constructor round-trips through Djinn"
        (Right pairConstructor) (toSynthesisType projectedPair)
    boxedTripleName <- expectShownRight $
        SharedName.tupleName SharedName.Boxed 3
    assertEqual "wider partial boxed tuple constructors remain unsupported"
        (Left $ PartialTupleConstructorUnsupported SharedName.Boxed 3)
        (fromSynthesisType $ SharedType.TypeConstructor boxedTripleName
            :: Either SynthesisTypeError HType)
    unboxedPairName <- expectShownRight $
        SharedName.tupleName SharedName.Unboxed 2
    assertEqual "partial unboxed tuple constructors remain unsupported"
        (Left $ PartialTupleConstructorUnsupported SharedName.Unboxed 2)
        (fromSynthesisType $ SharedType.TypeConstructor unboxedPairName
            :: Either SynthesisTypeError HType)
    let malformedConstructor = HTCon "not a type"
    assertEqual "malformed compatibility names stay outside the shared tree"
        Nothing (hTypeSynthesisStructure malformedConstructor)
    assertBool "malformed compatibility names retain checked diagnostics" $
        case toSynthesisType malformedConstructor of
            Left (InvalidHTypeName "not a type" _) -> True
            _ -> False
    assertEqual "declaration bodies cannot masquerade as source types"
        (Left $ DeclarationBodyIsNotSourceType $ HTUnion [])
        (toSynthesisType $ HTUnion [])
    let sharedForall = SharedType.ForallType ["a"] []
            $ SharedType.FunctionType
                (SharedType.TypeVariable "a")
                (SharedType.TypeVariable "a")
        compatibilityForall = HTForall ["a"] []
            $ HTArrow (HTVar "a") (HTVar "a")
    assertEqual "explicit foralls round-trip through the shared tree"
        (Right compatibilityForall) (fromSynthesisType sharedForall)
    assertEqual "shared binder errors are retained for explicit foralls"
        (Left $ InvalidSynthesisType
            $ SharedType.DuplicateForallVariable "a")
        (fromSynthesisType $ SharedType.ForallType ["a", "a"] []
            $ SharedType.TypeVariable "a")
    let oversizedTuple = HTTuple $ repeat $ HTVar "a"
    case oversizedTuple of
        HTTuple _ -> pure ()
        _ -> fail "an oversized compatibility tuple did not construct"
    assertEqual "oversized tuples stay outside the native unchecked fast path"
        Nothing (hTypeSynthesisStructure oversizedTuple)
    assertEqual "oversized compatibility tuples fail at the bounded arity"
        (Left $ InvalidSynthesisType
            $ SharedType.InvalidTupleTypeArity SharedName.Boxed
                $ SharedName.maximumTupleArity + 1)
        (toSynthesisType oversizedTuple)
    assertEqual "constructor-like strings cannot become Djinn type variables"
        (Left $ InvalidDjinnTypeVariable "A")
        (fromSynthesisType $ SharedType.TypeVariable "A")
    assertEqual "reserved strings cannot leave Djinn as type variables"
        (Left $ InvalidDjinnTypeVariable "case")
        (toSynthesisType $ HTVar "case")
    assertEqual "qualified strings cannot become Djinn type variables"
        (Left $ InvalidDjinnTypeVariable "M.a")
        (fromSynthesisType $ SharedType.TypeVariable "M.a")
    let typeOperator = sharedName "(:+:)"
    assertEqual "shared type operators cannot enter Djinn's prefix-only parser"
        (Left $ UnsupportedDjinnTypeConstructorName typeOperator)
        (fromSynthesisType $ SharedType.TypeConstructor typeOperator)
    assertEqual "raw Djinn type operators cannot cross the shared boundary"
        (Left $ UnsupportedDjinnTypeConstructorName typeOperator)
        (toSynthesisType $ HTCon "(:+:)")
    mapM_ assertSharedRendering
        [ HTCon "[]"
        , HTApp (HTCon "[]") (HTVar "a")
        , HTApp (HTApp (HTCon "[]") (HTVar "a")) (HTVar "b")
        , HTApp (HTCon "[]") $
            HTApp (HTCon "[]") (HTVar "a")
        ]
  where
    assertSharedRendering raw = do
        projected <- expectShownRight $ toSynthesisType raw
        assertEqual ("shared rendering changed " ++ show raw)
            (show raw) (SharedTypeRender.renderType id projected)

-- A boxed pair is structural when saturated, but an exact higher-kinded
-- assignment can also retain its bare constructor beneath an opaque nominal
-- application or in a nested class context. Exercise both non-vacuous paths
-- through the checked public adapter; a vacuous provider would prove only that
-- visible rendering can carry the argument without Djinn ever lowering it.
testStructuralHigherKindedAssignments :: IO ()
testStructuralHigherKindedAssignments = do
    targetName <- expectShownRight $
        SharedName.mkIdentifier "structuralHigherKindedResult"
    target <- expectShownRight $ SharedGenerated.mkDefinitionName targetName
    environment <- expectShownRight $
        SharedEnvironment.mkEnvironment declarations
    session <- expectShownRight $ Djex.mkDjinnSession environment
    directRequest <- request target directGoal
    directResult <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationAssignments session
            [assignment directProviderName
                [pairConstructor, partialEither]]
            directRequest
    directRendered <- render directResult
    assertBool
        ("Djinn lost the residual boxed-pair assignment: " ++
            show directRendered)
        $ any (allFragments
            [ "structuralProvider"
            , "@(,)"
            , "@(Either StructuralNatural)"
            ]) directRendered

    contextualRequest <- request target $ box contextualArgument
    contextualResult <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationAssignments session
            [assignment contextualProviderName [contextualArgument]]
            contextualRequest
    contextualRendered <- render contextualResult
    assertBool
        ("Djinn lost the non-vacuous structural contextual assignment: " ++
            show contextualRendered)
        $ any (allFragments
            [ "structuralContextProvider"
            , "StructuralContext (,) (Either StructuralNatural)"
            ]) contextualRendered
  where
    proper = SharedKind.ProperTypeKind
    unary = SharedKind.FunctionKind proper proper
    binary = SharedKind.FunctionKind proper unary
    pairName = expectName $ SharedName.tupleName SharedName.Boxed 2
    pairConstructor = SharedType.TypeConstructor pairName
    naturalName = sharedName "StructuralNatural"
    eitherName = sharedName "Either"
    envelopeName = sharedName "StructuralEnvelope"
    boxName = sharedName "StructuralContextBox"
    boxConstructorName = sharedName "MkStructuralContextBox"
    className = sharedName "StructuralContext"
    directProviderName = sharedName "structuralProvider"
    contextualProviderName = sharedName "structuralContextProvider"
    naturalType = SharedType.TypeConstructor naturalName
    eitherConstructor = SharedType.TypeConstructor eitherName
    partialEither = SharedType.TypeApplication eitherConstructor naturalType
    application2 function first second = SharedType.TypeApplication
        (SharedType.TypeApplication function first) second
    envelope first second = application2
        (SharedType.TypeConstructor envelopeName) first second
    box argument = SharedType.TypeApplication
        (SharedType.TypeConstructor boxName) argument
    directProviderType = SharedType.ForallType ["binary", "unary"] [] $
        envelope
            (SharedType.TypeVariable "binary")
            (SharedType.TypeVariable "unary")
    directGoal = envelope pairConstructor partialEither
    element = SharedType.TypeVariable "element"
    contextualArgument = SharedType.ForallType ["element"]
        [Constraint className [pairConstructor, partialEither]] $
            SharedType.FunctionType element element
    contextualProviderType = SharedType.ForallType ["selected"] [] $
        box $ SharedType.TypeVariable "selected"
    declarations :: [SharedDeclaration.Declaration String Void ()]
    declarations =
        [ SharedDeclaration.AbstractTypeDeclaration () naturalName proper
        , SharedDeclaration.AbstractTypeDeclaration () eitherName binary
        , SharedDeclaration.AbstractTypeDeclaration () envelopeName $
            SharedKind.FunctionKind binary $
                SharedKind.FunctionKind unary proper
        , SharedDeclaration.ClassDeclaration () className
            [ SharedDeclaration.TypeParameter "binary" $ Just binary
            , SharedDeclaration.TypeParameter "unary" $ Just unary
            ] [] []
        , SharedDeclaration.DataTypeDeclaration () boxName
            [SharedDeclaration.TypeParameter "boxed" Nothing]
            [SharedDeclaration.DataConstructor () boxConstructorName
                [SharedType.TypeVariable "boxed"]]
        , valueDeclaration directProviderName directProviderType
        , valueDeclaration contextualProviderName contextualProviderType
        ]

    valueDeclaration name valueType = SharedDeclaration.ValueDeclaration $
        SharedDeclaration.ValueSignature () name valueType

    assignment provider arguments =
        SharedQuery.ProviderInstantiationAssignment
            { SharedQuery.providerInstantiationAssignmentProvider = provider
            , SharedQuery.providerInstantiationAssignmentArguments = arguments
            }

    request target goal = expectShownRight $ Djex.mkDjinnRequest $
        SharedQuery.QueryRequest
            { SharedQuery.requestTarget = target
            , SharedQuery.requestGoal = goal
            , SharedQuery.requestContexts = []
            , SharedQuery.requestOptions = defaultQueryOptions
                { optionAlternatives = True
                , optionCutoff = 128
                }
            }

    render result = mapM
        (expectShownRight . Djex.renderDjinnCandidateDefinition
            SharedGenerated.Unqualified)
        $ SharedSearch.batchCandidates $ SharedQuery.resultSearch result

    allFragments fragments source = all (`isInfixOf` source) fragments

    expectName source = case source of
        Left failure -> error $ show failure
        Right name -> name

-- The raw compatibility formula keeps rank-N types as alpha-stable atoms.
-- Checked queries additionally try a polarized translation: positive foralls
-- open for dictionary-independent introduction, while an opaque fallback
-- retains exact polymorphic transport and unsupported searches stay
-- inconclusive.
testCandidateQuality :: IO ()
testCandidateQuality = do
    let token = HTCon "QualityToken"
        expensive = sharedName "aaQualityExpensive"
        cheap = sharedName "zzQualityCheap"
        options = defaultQueryOptions
            { optionAlternatives = True
            , optionSorted = False
            , optionCutoff = 1
            , optionBudget = Just 64
            , optionProviderCosts = Map.fromList
                [(expensive, 100), (cheap, 0)]
            }
    environment <- expectRight $ do
        types <- declare (AbstractType "QualityToken" KStar) emptyEnvironment
        first <- declare (Function "aaQualityExpensive" token) types
        declare (Function "zzQualityCheap" token) first
    ranked <- expectRight $ inhabit options environment [] "qualityResult" token
    assertEqual "the cheap source wins before the first raw-proof cutoff"
        (Realized ["qualityResult = zzQualityCheap"]) $ reportOutcome ranked
    reversed <- expectRight $ inhabit options
        {optionProviderCosts = Map.fromList [(expensive, 0), (cheap, 100)]}
        environment [] "qualityResult" token
    assertEqual "the preference follows costs rather than source order"
        (Realized ["qualityResult = aaQualityExpensive"]) $ reportOutcome reversed
    let legacy = options {optionRanking = SharedQuality.LegacyCandidateRanking}
    historical <- expectRight $ inhabit legacy environment [] "qualityResult" token
    assertEqual "legacy retains the original provider order"
        (Realized ["qualityResult = aaQualityExpensive"]) $ reportOutcome historical
    assertEqual "ranking does not refund or enlarge the raw candidate cutoff"
        (reportCompletion historical) (reportCompletion ranked)
    both <- expectRight $ inhabit options {optionCutoff = 2}
        environment [] "qualityResult" token
    assertEqual "quality ranking preserves structurally distinct provider alternatives"
        (Realized ["qualityResult = zzQualityCheap", "qualityResult = aaQualityExpensive"])
        $ reportOutcome both
    again <- expectRight $ inhabit options environment [] "qualityResult" token
    assertEqual "quality ordering is deterministic"
        (reportOutcome ranked) (reportOutcome again)
    -- An exact impredicative assignment has a synthetic proof identity.
    -- Its source name must survive before the raw cutoff, not only after
    -- generated visible applications have been reconstructed for display.
    polyEnvironment <- expectRight $ do
        types <- declare (AbstractType "QualityF" $ KArrow KStar KStar) emptyEnvironment
        let provider = HTForall ["a"] [] $ HTApp (HTCon "QualityF") (HTVar "a")
        first <- declare (Function "aaPolyQualityExpensive" provider) types
        declare (Function "zzPolyQualityCheap" provider) first
    neutral <- expectShownRight $ toSynthesisEnvironment polyEnvironment
    groundNeutral <- expectShownRight $ SharedEnvironment.groundEnvironmentKinds neutral
    session <- expectShownRight $ Djex.mkDjinnSession groundNeutral
    target <- expectShownRight $ SharedName.mkIdentifier "qualityPolyResult"
    let polyExpensive = sharedName "aaPolyQualityExpensive"
        polyCheap = sharedName "zzPolyQualityCheap"
        identity = SharedType.ForallType ["i"] [] $ SharedType.FunctionType
            (SharedType.TypeVariable "i") (SharedType.TypeVariable "i")
        assignments =
            [ SharedQuery.ProviderInstantiationAssignment provider [identity]
            | provider <- [polyExpensive, polyCheap]
            ]
        runExact costs = do
            request <- expectShownRight $ Djex.parseDjinnRequest session
                options {optionProviderCosts = costs} target
                "quality-exact.djinn" "QualityF (forall b. b -> b)"
            result <- expectShownRight $ Djex.runDjinnQueryWithInstantiationAssignments
                session assignments request
            mapM (expectShownRight . Djex.renderDjinnCandidateExpression
                SharedGenerated.Unqualified)
                $ SharedSearch.batchCandidates $ SharedQuery.resultSearch result
    exactCheap <- runExact $ Map.fromList [(polyExpensive, 100), (polyCheap, 0)]
    exactExpensive <- runExact $ Map.fromList [(polyExpensive, 0), (polyCheap, 100)]
    assertBool ("synthetic specialization lost the cheap source cost: " ++ show exactCheap)
        $ case exactCheap of
            [candidate] -> "zzPolyQualityCheap @" `isPrefixOf` candidate
            _ -> False
    assertBool ("synthetic specialization ignored reversed costs: " ++ show exactExpensive)
        $ case exactExpensive of
            [candidate] -> "aaPolyQualityExpensive @" `isPrefixOf` candidate
            _ -> False

testDirectedRankN :: IO ()
testDirectedRankN = do
    session <- expectShownRight Djex.standardDjinnSession
    let variables prefix = [prefix ++ show n | n <- [1 .. 12 :: Int]]
        tuple names = "(" ++ joinComma names ++ ")"
        joinComma [] = ""
        joinComma [x] = x
        joinComma (x : xs) = x ++ ", " ++ joinComma xs
        cases =
            [ ("directedTwelve", "(forall " ++ unwords (variables "a") ++ ". "
                ++ tuple (variables "a") ++ ") -> " ++ tuple (reverse $ variables "x"))
            , ("churchEither", "(a -> c) -> (b -> c) -> "
                ++ "(forall e. (a -> e) -> (b -> e) -> e) -> c")
            , ("openImpredicativeDemand", "(forall t. t -> t) -> "
                ++ "(forall b. a -> b -> a) -> (forall c. a -> c -> a)")
            ]
    mapM_ (check session) cases
  where
    check session (spelling, source) = do
        target <- expectShownRight $ SharedName.mkIdentifier spelling
        request <- expectShownRight $ Djex.parseDjinnRequest session
            defaultQueryOptions
                { optionSorted = False, optionCutoff = 1, optionBudget = Just 10000 }
            target "directed-instantiation" source
        result <- expectShownRight $ Djex.runDjinnQuery session request
        assertBool (spelling ++ " exhausted search without a candidate") $
            not $ null $ SharedSearch.batchCandidates $ SharedQuery.resultSearch result

-- Public generated candidates, interpreted only in this test's closed pure
-- lambda fragment. The behavioral oracle does not enter synthesis or supply a
-- target implementation. Distinct elements distinguish reversal from identity.
testResidualFunctionCarriers :: IO ()
testResidualFunctionCarriers = do
    source <- expectRight $ parseHType
        "forall a. (forall r. (a -> r -> r) -> r -> r) -> (forall r. (a -> r -> r) -> r -> r)"
    let options = defaultQueryOptions
            { optionAlternatives = True
            , optionSorted = False
            , optionCutoff = 4096
            , optionBudget = Just 100000
            , optionStrategy = Interleave
            }
        run configured = expectRight $ inhabitGenerated configured emptyEnvironment []
            "carrierResult" source
    historical <- run options {optionAlternatives = False}
    alternatives <- run options
    let clauses = map SharedCandidate.candidateOutput $
            generatedReportCandidates alternatives
        historicalClauses = map SharedCandidate.candidateOutput $
            generatedReportCandidates historical
        expressions = map SharedGenerated.functionClauseExpression clauses
        samples = [[], [7], [11, 29], [3, 1, 8]]
        reverses expression = all
            (\xs -> carrierListResult expression xs == Right (reverse xs)) samples
    let diagnostic = unlines
            [ "the carrier family did not produce a reversal with Interleave / 4096 raw proofs / 100000 choices"
            , "candidate count: " ++ show (length clauses)
            , "completion: " ++ show (generatedReportCompletion alternatives)
            , "evidence: " ++ show (generatedReportEvidence alternatives)
            , "formula: " ++ generatedReportFormula alternatives
            , "first proof: " ++ show (generatedReportProof alternatives)
            , "first expressions: " ++ show (take 8 expressions)
            , "sample observations: " ++ show
                [map (carrierListResult expression) samples | expression <- take 8 expressions]
            ]
    calibration <- if any reverses expressions then pure "" else do
        depth <- run options {optionCutoff = 256, optionStrategy = DepthFirst}
        fair <- run options {optionCutoff = 256}
        pure $ unlines
            [ "smaller-prefix diagnostic (256 raw proofs, unchanged 100000 choices): " ++ label ++
                "; count=" ++ show (length candidates) ++
                "; first reversal index=" ++ show
                    (findIndex (reverses . SharedGenerated.functionClauseExpression . SharedCandidate.candidateOutput)
                        candidates) ++
                "; completion=" ++ show (generatedReportCompletion report)
            | (label, report) <- [("depth-first", depth), ("interleave", fair)]
            , let candidates = generatedReportCandidates report
            ]
    assertBool (diagnostic ++ calibration) $
        any reverses expressions
    assertBool "carrier enumeration consumed the historical alternative family" $
        not (null historicalClauses) && all (`elem` clauses) historicalClauses
    assertBool "carrier enumeration exceeded the raw candidate cutoff" $
        length clauses <= optionCutoff options
    single <- run options {optionCutoff = 1}
    assertBool "a carrier rejection refilled the one-proof allowance" $
        length (generatedReportCandidates single) <= 1
    first <- run options {optionAlternatives = False, optionCutoff = 1}
    assertEqual "carrier enumeration changed first-only synthesis"
        historicalClauses $ map SharedCandidate.candidateOutput $
            generatedReportCandidates first
    impossible <- expectRight $ parseHType
        "forall a b. (forall r. (a -> r -> r) -> r -> r) -> b"
    negative <- expectRight $ inhabitGenerated
        options {optionCutoff = 8, optionBudget = Just 1000}
        emptyEnvironment [] "carrierMustNotCapture" impossible
    assertEqual "a residual carrier invented an unowned result inhabitant" 0 $
        length $ generatedReportCandidates negative

testReductionCarriers :: IO ()
testReductionCarriers = do
    source <- expectRight $ parseHType
        "forall a. a -> (a -> a -> a) -> (forall r. (a -> r -> r) -> r -> r) -> a"
    let configured = defaultQueryOptions
            { optionAlternatives = True, optionStrategy = Interleave
            , optionCutoff = 65536, optionBudget = Just 500000 }
    result <- expectRight $ inhabitGenerated configured emptyEnvironment []
        "reductionResult" source
    let expressions = map (SharedGenerated.functionClauseExpression . SharedCandidate.candidateOutput) $
            generatedReportCandidates result
        matches reduction expression = all
            (\(initial, operation, values) -> observe expression initial operation values ==
                Right (if null values then initial else reduction operation values))
            [(initial, operation, values)
            | initial <- [37, 91]
            , operation <- [(-), (\x y -> 10 * x + y), const, (\_ y -> y)]
            , values <- [[], [8], [8, 3], [8, 3, 1], [2, 7, 4, 9]]]
        left = findIndex (matches foldl1) expressions
        right = findIndex (matches foldr1) expressions
        diagnostic = "supplied-default reductions are absent from the original bounded search; " ++
            "left=" ++ show left ++ "; right=" ++ show right ++
            "; candidates=" ++ show (length expressions) ++
            "; completion=" ++ show (generatedReportCompletion result)
    assertBool diagnostic $ left /= Nothing && right /= Nothing
  where
    observe expression initial operation values = do
        candidate <- evaluateCarrierExpression 10000 Map.empty expression
        withDefault <- carrierTestApply candidate $ CarrierTestElement initial
        withStep <- carrierTestApply withDefault $ CarrierTestFunction $ \left ->
            Right $ CarrierTestFunction $ \right -> case (left, right) of
                (CarrierTestElement x, CarrierTestElement y) ->
                    Right $ CarrierTestElement $ operation x y
                _ -> Left "reduction supplied a non-element to its binary operation"
        folded <- carrierTestApply withStep $ carrierListEncode values
        case folded of
            CarrierTestElement value -> Right value
            _ -> Left "reduction returned a non-element"

testCarrierFirstResult :: IO ()
testCarrierFirstResult = do
    source <- expectRight $ parseHType
        "forall a. (forall r. (a -> r -> r) -> r -> r) -> (forall r. (a -> r -> r) -> r -> r)"
    let options = defaultQueryOptions
            { optionAlternatives = True, optionSorted = False
            , optionCutoff = 1, optionBudget = Just 100000
            }
        run configured = expectRight $ inhabitGenerated configured emptyEnvironment []
            "carrierFirstResult" source
    baseline <- run options {optionAlternatives = False}
    actual <- run options
    let clauses = map SharedCandidate.candidateOutput . generatedReportCandidates
    assertBool "the historical one-proof query had no candidate" $ not $ null $ clauses baseline
    assertEqual "carrier exploration lost the ordinary one-proof result"
        (clauses baseline) (clauses actual)

-- A successful first result is available without spending a choice. Its
-- alternative branch does spend choices, so forcing that tail would change
-- the returned budget and fail this test independently of candidate text.
testFirstProofPrefixBudget :: IO ()
testFirstProofPrefixBudget = do
    let atom = PVar $ Symbol "prefixR"
        goal = atom :-> atom
        proofContext = [(Symbol "prefixF", goal), (Symbol "prefixG", goal)]
        mode = (defaultSearchMode True)
            { searchBudget = Just 10
            , searchStrategy = Interleave, searchTermAlternatives = True
            , searchRanking = SharedQuality.defaultCandidateRankingPolicy
            }
    prefix <- expectRight $ proveFirstWithModeChecked mode proofContext goal
    full <- expectRight $ proveWithModeChecked mode proofContext goal
    assertEqual "the first-proof policy returned more than its first proof"
        (take 1 $ searchProofs full) (searchProofs prefix)
    assertEqual "the first-proof policy spent an unobserved tail's fuel"
        (Just 10) (remainingSearchBudget prefix)
    assertBool "the control did not have a choice-bearing alternative tail" $
        remainingSearchBudget full < Just 10
    assertBool "a successful first-proof policy reported choice exhaustion" $
        not $ searchExhausted prefix
    mapM_ (expectRight . checkProof proofContext goal) $ searchProofs prefix
    zero <- expectRight $ proveFirstWithModeChecked
        mode {searchBudget = Just 0} proofContext goal
    assertEqual "a zero-choice first proof forced an alternative branch"
        (searchProofs prefix, Just 0, False)
        (searchProofs zero, remainingSearchBudget zero, searchExhausted zero)

testProofSearchCursor :: IO ()
testProofSearchCursor = mapM_ check
    [(strategy, budget, nested) | strategy <- [DepthFirst, Interleave],
        budget <- [0, 1, 10, 100], nested <- [False, True]]
  where
    atom = PVar $ Symbol "cursorR"
    identityGoal = atom :-> atom
    identityContext = [(Symbol "cursorF", identityGoal), (Symbol "cursorG", identityGoal)]
    check (strategy, budget, nested) = do
        let (cursorContext, goal) = if nested then nestedProductSequent
                else (identityContext, identityGoal)
            mode = (defaultSearchMode True)
                { searchBudget = Just budget, searchStrategy = strategy
                , searchTermAlternatives = nested
                , searchRanking = SharedQuality.defaultCandidateRankingPolicy }
        full <- expectRight $ proveWithModeChecked mode cursorContext goal
        cursor <- expectRight $ startProofSearchChecked mode cursorContext goal
        let (proofs, exhausted, remainder) = consume budget cursor
        assertEqual "resumption changed the raw proof stream"
            (searchProofs full) proofs
        assertEqual "resumption duplicated or refunded a choice"
            (searchExhausted full, remainingSearchBudget full)
            (exhausted, Just remainder)
        mapM_ (expectRight . checkProof cursorContext goal) proofs
    consume budget cursor = case observeProofSearch cursor of
        ProofSearchFinished -> ([], False, budget)
        ProofSearchChoice rest
            | budget <= 0 -> ([], True, budget)
            | otherwise -> consume (budget - 1) rest
        ProofSearchResult proof rest ->
            let (proofs, exhausted, remainder) = consume budget rest
            in (proof : proofs, exhausted, remainder)

-- Both sides of this nested-implication product have independent choices.
-- Assumption names deliberately occupy the prover's ordinary fresh prefixes.
-- The four checked results must retain their own argument and continuation,
-- even when interleaving resumes another branch between those two searches.
nestedProductSequent :: ([(Symbol, Formula)], Formula)
nestedProductSequent = (premises, productD)
  where
    productA = PVar $ Symbol "productA"
    productB = PVar $ Symbol "productB"
    productC = PVar $ Symbol "productC"
    productD = PVar $ Symbol "productD"
    premises =
        [ (Symbol "x1", (productA :-> productB) :-> productC)
        , (Symbol "z1", productB), (Symbol "x2", productB)
        , (Symbol "z2", productC :-> productD), (Symbol "x3", productC :-> productD)
        ]

testNestedProofProduct :: IO ()
testNestedProofProduct = mapM_ check [DepthFirst, Interleave]
  where
    (premises, goal) = nestedProductSequent
    check strategy = do
        result <- expectRight $ proveWithModeChecked
            (defaultSearchMode True)
                { searchStrategy = strategy, searchTermAlternatives = True
                , searchBudget = Just 10000
                , searchRanking = SharedQuality.defaultCandidateRankingPolicy }
            premises goal
        mapM_ (expectRight . checkProof premises goal) $ searchProofs result
        pairs <- mapM pair $ searchProofs result
        assertEqual "nested search lost or crossed an argument/continuation branch"
            (sort [(Symbol consumer, Symbol argument)
                | consumer <- ["z2", "x3"], argument <- ["z1", "x2"]]) $
            sort $ nub pairs
    pair (Apply (Var consumer) (Apply (Var provider) (Lam _ (Var argument))))
        | provider == Symbol "x1" = pure (consumer, argument)
    pair proof = fail $ "the nested product emitted an unexpected proof: " ++ show proof

testNormalTermAlternatives :: IO ()
testNormalTermAlternatives = do
    let mode = (defaultSearchMode True)
            { searchStrategy = Interleave, searchTermAlternatives = True
            , searchBudget = Just 10000
            , searchRanking = SharedQuality.defaultCandidateRankingPolicy }
        resultAtom = PVar $ Symbol "normalR"
        reuseGoal = (resultAtom :-> resultAtom) :-> resultAtom :-> resultAtom
    reused <- expectRight $ proveWithModeChecked mode [] reuseGoal
    mapM_ (expectRight . checkProof [] reuseGoal) $ searchProofs reused
    assertBool "a reusable assumption could not form f (f x)" $
        any twice $ searchProofs reused
    let inputAtom = PVar $ Symbol "normalInput"
        argumentAtom = PVar $ Symbol "normalArgument"
        outputAtom = PVar $ Symbol "normalOutput"
        provider = Symbol "normalProvider"
        function = Symbol "normalFunction"
        input = Symbol "normalValue"
        functionType = argumentAtom :-> resultAtom
        premises = [(provider, functionType :-> outputAtom),
            (function, inputAtom :-> functionType), (input, inputAtom)]
        forwarded = Apply (Var provider) $ Apply (Var function) (Var input)
    partial <- expectRight $ proveWithModeChecked mode premises outputAtom
    mapM_ (expectRight . checkProof premises outputAtom) $ searchProofs partial
    assertBool "an exact residual function type could not be forwarded without eta expansion" $
        forwarded `elem` searchProofs partial
    -- No first LJT proof means no added size ladder and no altered evidence.
    original <- expectRight $ proveWithModeChecked mode {searchTermAlternatives = False} [] resultAtom
    impossible <- expectRight $ proveWithModeChecked mode [] resultAtom
    assertEqual "normal alternatives altered an unsuccessful historical prefix"
        (searchProofs original, searchExhausted original, remainingSearchBudget original)
        (searchProofs impossible, searchExhausted impossible, remainingSearchBudget impossible)
  where
    twice (Lam function (Lam input (Apply (Var outer) (Apply (Var inner) (Var value))))) =
        function == outer && function == inner && input == value
    twice _ = False

-- A plain atom and an opaque source atom may print identically while owning
-- different logical identities. Both zero-argument and applied heads must
-- retain that distinction throughout the additional normal proof stream.
testFiniteNormalLayers :: IO ()
testFiniteNormalLayers = do
    let finiteAtom = PVar $ Symbol "finiteNormalA"
        absentAtom = PVar $ Symbol "finiteNormalB"
        finalAtom = PVar $ Symbol "finiteNormalC"
        finiteValue = Symbol "finiteValue"
        blockedHead = Symbol "finiteBlocked"
        enumerationMode = (defaultSearchMode True)
            { searchStrategy = Interleave, searchTermAlternatives = True
            , searchBudget = Just 10000
            , searchRanking = SharedQuality.defaultCandidateRankingPolicy }
        inspectFiniteCase premises goal = do
            result <- expectRight $ proveWithModeChecked enumerationMode premises goal
            mapM_ (expectRight . checkProof premises goal) $ searchProofs result
            assertBool "a proved finite normal grammar exhausted its choice budget" $
                not $ searchExhausted result
            pure $ searchProofs result
    -- Same-typed lambda assumptions retain both term identities, although
    -- their types are a set only in the maximum-size analysis.
    projections <- inspectFiniteCase [] $ finiteAtom :-> finiteAtom :-> finiteAtom
    assertEqual "finite-layer stopping lost a same-typed lambda projection"
        [False, True] $ sort $ nub $ map projectedFirst projections
    -- A cyclic first argument is Unknown, but the unavailable second
    -- argument makes the entire head impossible. This case must be finite.
    blocked <- inspectFiniteCase
        [(blockedHead, finiteAtom :-> absentAtom :-> finiteAtom), (finiteValue, finiteAtom)]
        finiteAtom
    assertEqual "an impossible head argument invented or hid a proof"
        [Var finiteValue] $ nub blocked
    -- The finite maximum must include multi-head terms, not just projections.
    let firstLink = Symbol "finiteFirst"
        secondLink = Symbol "finiteSecond"
        premises = [(firstLink, finiteAtom :-> absentAtom),
            (secondLink, absentAtom :-> finalAtom), (finiteValue, finiteAtom)]
        expected = Apply (Var secondLink) $ Apply (Var firstLink) (Var finiteValue)
    chained <- inspectFiniteCase premises finalAtom
    assertBool "finite maximum discarded the end of an acyclic head chain" $
        expected `elem` chained
    -- A viable recursive state remains Unknown: no finite cap is fabricated.
    let recursiveHead = Symbol "finiteRecursive"
        recursivePremises = [(recursiveHead, finiteAtom :-> finiteAtom),
            (finiteValue, finiteAtom)]
        twiceApplied = Apply (Var recursiveHead) $
            Apply (Var recursiveHead) (Var finiteValue)
    recursive <- expectRight $ proveWithModeChecked enumerationMode recursivePremises finiteAtom
    mapM_ (expectRight . checkProof recursivePremises finiteAtom) $ searchProofs recursive
    assertBool "a viable cycle was incorrectly declared finite" $ searchExhausted recursive
    assertBool "cycle handling removed a reusable-head term" $
        twiceApplied `elem` searchProofs recursive
  where
    projectedFirst (Lam first (Lam _ (Var selected))) = first == selected
    projectedFirst proof = error $ "unexpected projection term: " ++ show proof

testNormalResidualIdentity :: IO ()
testNormalResidualIdentity = mapM_ check
    [(target, decoy, applied) | (target, decoy) <- [(plain, opaque), (opaque, plain)],
        applied <- [False, True]]
  where
    plain = PVar $ Symbol "indexedAtom"
    opaque = PVar $ opaqueTypeSymbol $ SharedType.TypeVariable "indexedAtom"
    inputAtom = PVar $ Symbol "indexedInput"
    correct = Symbol "indexedCorrect"
    wrong = Symbol "indexedWrong"
    input = Symbol "indexedValue"
    mode = (defaultSearchMode True)
        { searchStrategy = Interleave, searchTermAlternatives = True
        , searchBudget = Just 2000
        , searchRanking = SharedQuality.defaultCandidateRankingPolicy }
    check (target, decoy, applied) = do
        assertEqual "the residual identity control no longer shares display text"
            (show target) (show decoy)
        assertBool "the residual identity control collapsed its logical atoms" $
            target /= decoy
        let source result = if applied then inputAtom :-> result else result
            premises = [(wrong, source decoy), (correct, source target)] ++
                [(input, inputAtom) | applied]
            expected = if applied then Apply (Var correct) (Var input) else Var correct
        result <- expectRight $ proveWithModeChecked mode premises target
        mapM_ (expectRight . checkProof premises target) $ searchProofs result
        assertEqual "a residual lookup lost its owned head or admitted the same-rendered decoy"
            [expected] $ nub $ searchProofs result

-- The two external heads have the same type and occupy fresh-name prefixes;
-- the atom occupies the next prefix. Lambda introduction adds a third head
-- of that same type. All nine ordered two-head compositions must survive in
-- either source encounter order, with each proof checked in its own scope.
testNormalContextExtension :: IO ()
testNormalContextExtension = mapM_ check [False, True]
  where
    first = Symbol "n1"
    second = Symbol "n2"
    resultAtom = PVar $ Symbol "n3"
    functionType = resultAtom :-> resultAtom
    goal = functionType :-> resultAtom :-> resultAtom
    mode = (defaultSearchMode True)
        { searchStrategy = Interleave, searchTermAlternatives = True
        , searchBudget = Just 10000
        , searchRanking = SharedQuality.defaultCandidateRankingPolicy }
    expectedPairs = [(outer, inner) | outer <- [0 .. 2 :: Int], inner <- [0 .. 2 :: Int]]
    check reversed = do
        let heads = [(first, functionType), (second, functionType)]
            premises = if reversed then reverse heads else heads
            reserved = map fst premises ++ formulaSymbols goal
        result <- expectRight $ proveWithModeChecked mode premises goal
        mapM_ (expectRight . checkProof premises goal) $ searchProofs result
        let observed = [entry | Just entry <- map composition $ searchProofs result]
        assertEqual "context extension lost or conflated distinct reusable head choices"
            expectedPairs $ sort $ nub [pair | (_, _, pair) <- observed]
        assertBool "a normal lambda captured a source head or formula identity" $
            all (\(function, input, _) -> function /= input &&
                function `notElem` reserved && input `notElem` reserved) observed
    composition (Lam function (Lam input
            (Apply (Var outer) (Apply (Var inner) (Var value)))))
        | value == input = do
            outerChoice <- headChoice function outer
            innerChoice <- headChoice function inner
            pure (function, input, (outerChoice, innerChoice))
    composition _ = Nothing
    headChoice function name
        | name == first = Just 0
        | name == second = Just 1
        | name == function = Just 2
        | otherwise = Nothing

-- The historical list-fold opportunities must advance while a productive
-- carrier context still has thousands of alternatives. The oracles below
-- interpret emitted terms only; neither implementation enters the query.
testCarrierPlanFairness :: IO ()
testCarrierPlanFairness = do
    check "appendWhileExploringCarriers"
        "forall a. (forall r. (a -> r -> r) -> r -> r) -> (forall r. (a -> r -> r) -> r -> r) -> (forall r. (a -> r -> r) -> r -> r)"
        (\expression -> all (\(left, right) ->
            appendResult expression left right == Right (left ++ right))
            [(left, right) | left <- samples, right <- samples])
    check "filterWhileExploringCarriers"
        "forall a. (a -> (forall r. r -> r -> r)) -> (forall r. (a -> r -> r) -> r -> r) -> (forall r. (a -> r -> r) -> r -> r)"
        (\expression -> all (\(predicate, values) ->
            filterResult expression predicate values == Right (filter predicate values))
            [(predicate, values) | predicate <- [const True, const False, even, (< 0)],
                values <- samples])
  where
    samples = [[], [7], [11, 29], [-2, 1, 8, -2]]
    check name signature accepts = do
        source <- expectRight $ parseHType signature
        result <- expectRight $ inhabitGenerated
            defaultQueryOptions
                { optionAlternatives = True, optionSorted = False
                , optionStrategy = Interleave, optionCutoff = 65536
                , optionBudget = Just 500000 }
            emptyEnvironment [] name source
        let expressions = map (SharedGenerated.functionClauseExpression .
                SharedCandidate.candidateOutput) $ generatedReportCandidates result
        assertBool (name ++ ": no matching term in the shared 65536-proof / 500000-choice prefix; " ++
            "candidates=" ++ show (length expressions) ++
            "; completion=" ++ show (generatedReportCompletion result)) $
            any accepts expressions
    appendResult expression left right = do
        candidate <- evaluateCarrierExpression 10000 Map.empty expression
        partial <- carrierTestApply candidate $ carrierListEncode left
        folded <- carrierTestApply partial $ carrierListEncode right
        carrierListDecode folded
    filterResult expression predicate values = do
        candidate <- evaluateCarrierExpression 10000 Map.empty expression
        partial <- carrierTestApply candidate $ CarrierTestFunction $ \element ->
            case element of
                CarrierTestElement value -> Right $ CarrierTestFunction $ \yes ->
                    Right $ CarrierTestFunction $ \no -> Right $
                        if predicate value then yes else no
                _ -> Left "the predicate received a non-element"
        folded <- carrierTestApply partial $ carrierListEncode values
        carrierListDecode folded

-- A later exact-opaque view can forward the declared polymorphic provider.
-- Four independent fields each choose one of four ordinary inputs: the
-- opened view has 4^4 combinations before considering its two choice lambdas.
-- This Cartesian prefix does not depend on endomorphism reuse, local cuts,
-- or the extra normal-term lane. No provider body is supplied.
testFormulaPlanAdmission :: IO ()
testFormulaPlanAdmission = do
    choice <- expectRight $ parseHType "forall a. a -> a -> a"
    environment <- expectRight $ declare (Function "laterChoice" choice) emptyEnvironment
    source <- expectRight $ parseHType
        "forall r. r -> r -> r -> r -> (r, r, r, r, (forall a. a -> a -> a))"
    provider <- expectShownRight $ SharedName.parseName "laterChoice"
    let run strategy = expectRight $ inhabitGenerated
            defaultQueryOptions
                { optionAlternatives = True, optionSorted = False
                , optionStrategy = strategy, optionCutoff = 128
                , optionBudget = Just 10000 }
            environment [] "admitLaterView" source
        usesProvider = any (elem provider . SharedGenerated.expressionGlobals .
            SharedGenerated.functionClauseExpression . SharedCandidate.candidateOutput) .
            generatedReportCandidates
    depth <- run DepthFirst
    assertEqual "the prolific initial view did not fill the control prefix"
        (SharedSearch.truncated SharedSearch.CandidateLimitReached) $
        generatedReportCompletion depth
    assertBool "the depth-first control already reached the later provider view" $
        not $ usesProvider depth
    fair <- run Interleave
    assertBool ("a later formula view was starved by the first cursor; completion=" ++
        show (generatedReportCompletion fair)) $ usesProvider fair

testLazyPlanFamilyAdmission :: IO ()
testLazyPlanFamilyAdmission = do
    -- The first family represents an expensive optional instantiation
    -- generator. Its tag is sufficient to suppress it; even WHNF is forbidden.
    let families =
            [ (True, error "a suppressed family generator was forced")
            , (False, [17 :: Int])
            ]
    case nextAdmittedPlanFamily id families of
        Just (False, firstPlan : _, []) -> assertEqual "the later family was lost" 17 firstPlan
        _ -> fail "the admitted family did not preserve source order"
    -- A candidate bound may stop after the admitted head. Do not inspect
    -- either that family's remaining plans or the later family source.
    let lazyTail = (False, 23 : error "an admitted plan tail was forced") :
            error "an unobserved later family was forced"
    case nextAdmittedPlanFamily id lazyTail of
        Just (False, firstPlan : _, _) -> assertEqual "the admitted head changed" (23 :: Int) firstPlan
        _ -> fail "the first admitted family was unavailable"

testCandidateStreamFirstDelivery :: IO ()
testCandidateStreamFirstDelivery = do
    source <- expectRight (parseHType "(a -> a) -> a -> a") >>= expectShownRight . toSynthesisType
    prepared <- expectShownRight $ prepareEnvironment emptyEnvironment
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $ sharedName "streamFirst"
    let configured = defaultQueryOptions
            { optionAlternatives = True
            , optionSorted = error "streaming forced the final whole-pool sort policy"
            , optionStrategy = Interleave
            , optionCutoff = 1000000000
            , optionBudget = Just 1000000000 }
    stream <- expectShownRight $ inhabitTypedSynthesisStreamPreparedWithSourceGoal
        configured prepared source [] (DjinnSourceInstantiationCandidates []) target source
    -- A batch-sized search of this recursive normal-form language cannot
    -- consume its billion-proof allowance within this deliberately loose
    -- guard. Only the first observation and its own source graph are forced.
    delivered <- timeout 10000000 $ case stream of
        Right firstBatch : _ -> do
            assertEqual "the first candidate claimed terminal progress" SharedSearch.Continuing $
                SharedSearch.batchProgress $ SharedQuery.resultSearch firstBatch
            assertTypedCoreGraphs target source firstBatch
            evaluate $ length $ show $ SharedTypedCandidate.typedQueryResultCompatibility firstBatch
        Left failure : _ -> fail $ show failure
        [] -> fail "the streaming producer returned no observations"
    assertBool "the first candidate waited for the rest of its bounded pool" $ delivered /= Nothing
    identitySource <- expectRight (parseHType "a -> a") >>= expectShownRight . toSynthesisType
    identityFormula <- expectRight $
        RawEnvironment.preparedEnvironmentSynthesisFormulaTranslator prepared identitySource
    identityCursor <- expectRight $ startProofSearchChecked
        (defaultSearchMode True)
            { searchStrategy = Interleave, searchTermAlternatives = True
            , searchRanking = optionRanking configured }
        [] identityFormula
    -- Type introduction itself can consume choices. Measure the exact raw
    -- prefix rather than assuming an identity proof costs zero, then give the
    -- public producer precisely that allowance and no fuel for its tail.
    firstProofChoices <- measureFirstProofChoices 0 identityCursor
    exactFuel <- expectShownRight $ inhabitTypedSynthesisStreamPreparedWithSourceGoal
        configured {optionBudget = Just firstProofChoices} prepared identitySource []
        (DjinnSourceInstantiationCandidates []) target identitySource
    case exactFuel of
        Right firstBatch : tailObservations -> do
            assertEqual "exact-fuel first delivery consulted a later choice"
                SharedSearch.Continuing $ SharedSearch.batchProgress $ SharedQuery.resultSearch firstBatch
            assertTypedCoreGraphs target identitySource firstBatch
            terminal <- mapM expectShownRight tailObservations
            assertEqual "the later charged normal-form search was not observed on resumption"
                (SharedSearch.Completed $ SharedSearch.truncated SharedSearch.ChoicePointLimitReached) $
                SharedSearch.batchProgress $ SharedQuery.resultSearch $ last terminal
        Left failure : _ -> fail $ show failure
        [] -> fail "exact-fuel identity did not produce its measured first proof"
  where
    measureFirstProofChoices :: Integer -> ProofSearchCursor -> IO Integer
    measureFirstProofChoices charged cursor
        | charged > 1000 = fail "identity raw cursor did not reach its first proof within 1000 choices"
        | otherwise = case observeProofSearch cursor of
            ProofSearchFinished -> fail "identity raw cursor produced no proof"
            ProofSearchChoice rest -> measureFirstProofChoices (charged + 1) rest
            ProofSearchResult _ _ -> pure charged

-- Both quantified inputs denote the same source scheme after alpha
-- normalization. The query needs one exact-result instance, used once for
-- each input. An earlier constant/projection must not suppress that plan.
testCandidateStreamDemandedSingleton :: IO ()
testCandidateStreamDemandedSingleton = do
    let local = SharedGenerated.Local
        apply = SharedGenerated.Apply
        specialize value seed = apply (apply (local value) (local "step")) seed
        body = specialize "leftInput" $ specialize "rightInput" $ local "seed"
    assertCheckedStreamPrefix 128 "streamRepeatedScheme"
        "(forall leftResult. (item -> leftResult -> leftResult) -> leftResult -> leftResult) -> (forall rightResult. (item -> rightResult -> rightResult) -> rightResult -> rightResult) -> (forall result. (item -> result -> result) -> result -> result)"
        ["leftInput", "rightInput", "step", "seed"] body

-- Two distinct schemes cooperate at the goal's result: a selector's chosen
-- result must be the same exact atom as a consumer's accumulator. A common
-- result group supplies both existing bridges without mixing in other
-- available instantiation images or identifying the two source schemes.
testCandidateStreamDemandedGroup :: IO ()
testCandidateStreamDemandedGroup = do
    let local = SharedGenerated.Local
        apply = SharedGenerated.Apply
        apps = foldl apply
        selected = apps (local "predicate")
            [ local "element"
            , apps (local "step") [local "element", local "rest"]
            , local "rest"
            ]
        callback = SharedGenerated.Lambda
            [SharedGenerated.Bind "element", SharedGenerated.Bind "rest"] selected
        body = apps (local "input") [callback, local "seed"]
    assertCheckedStreamPrefix 128 "streamCooperatingSchemes"
        "(item -> (forall selected. selected -> selected -> selected)) -> (forall folded. (item -> folded -> folded) -> folded -> folded) -> (forall result. (item -> result -> result) -> result -> result)"
        ["predicate", "input", "step", "seed"] body

-- A quantified consumer also needs a live specialization whose accumulator
-- is a function, beyond the goal's direct result instances. Historical plan
-- admission must not dilute that carrier's continuation. This composition
-- traverses its input while accumulating a continuation for the final seed.
testCandidateStreamFunctionAccumulator :: IO ()
testCandidateStreamFunctionAccumulator = do
    let local = SharedGenerated.Local
        apps = foldl SharedGenerated.Apply
        callback = SharedGenerated.Lambda
            [SharedGenerated.Bind "element", SharedGenerated.Bind "rest", SharedGenerated.Bind "carry"] $
            apps (local "rest") [apps (local "step") [local "element", local "carry"]]
        identity = SharedGenerated.Lambda [SharedGenerated.Bind "carry"] $ local "carry"
        body = apps (local "input") [callback, identity]
    assertCheckedStreamPrefix 256 "streamFunctionAccumulator"
        "(forall folded. (item -> folded -> folded) -> folded -> folded) -> (forall result. (item -> result -> result) -> result -> result)"
        ["input", "step"] body

assertCheckedStreamPrefix
    :: Int -> String -> String -> [String] -> SharedGenerated.Expression String -> IO ()
assertCheckedStreamPrefix prefix name signature binders body = do
    source <- expectRight (parseHType signature) >>= expectShownRight . toSynthesisType
    prepared <- expectShownRight $ prepareEnvironment emptyEnvironment
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $ sharedName name
    let configured = defaultQueryOptions
            { optionAlternatives = True, optionSorted = False, optionStrategy = Interleave
            , optionCutoff = 65536, optionBudget = Just 500000 }
        expected = SharedGenerated.FunctionClause target (map SharedGenerated.Bind binders) body
        matches candidate = SharedGenerated.alphaEquivalentExpression
            (etaNormalClauseExpression expected) $
            etaNormalClauseExpression $ SharedCandidate.candidateOutput $
                SharedTypedCandidate.typedCandidateCompatibility candidate
    stream <- expectShownRight $ inhabitTypedSynthesisStreamPreparedWithSourceGoal
        configured prepared source [] (DjinnSourceInstantiationCandidates []) target source
    observations <- mapM expectShownRight $ take prefix stream
    case [observation | observation <- observations,
            any matches $ SharedSearch.batchCandidates $ SharedQuery.resultSearch observation] of
        matching : _ -> assertTypedCoreGraphs target source matching
        [] -> fail $ name ++ ": direct checked composition absent from first " ++ show prefix ++
            " streaming observations (observed " ++ show (length observations) ++ ")"

testStreamingNormalPriorityAccounting :: IO ()
testStreamingNormalPriorityAccounting = do
    let atom = PVar $ Symbol "streamScheduleAtom"
        goal = atom :-> atom :-> atom
        mode = (defaultSearchMode True)
            { searchStrategy = Interleave, searchTermAlternatives = True
            , searchRanking = SharedQuality.defaultCandidateRankingPolicy }
    ordinary <- expectRight $ proveWithModeChecked
        mode {searchTermAlternatives = False} [] goal
    cursor <- expectRight $ startProofSearchWithNormalPriorityChecked mode [] goal
    let (complete, completeChoices, completeRest) = consume 10000 cursor
        (prefix, prefixChoices, prefixRest) = consume 7 cursor
        (suffix, suffixChoices, suffixRest) = case prefixRest of
            Nothing -> ([], 0, Nothing)
            Just continuation -> consume (10000 - prefixChoices) continuation
    assertEqual "normal priority moved the first historical proof"
        (take 1 $ searchProofs ordinary) (take 1 complete)
    assertBool "normal priority starved a finite historical proof alternative" $
        all (`elem` complete) $ searchProofs ordinary
    assertBool "finite normal and historical lanes did not finish" $
        finished completeRest && finished suffixRest
    assertEqual "resumption lost or repeated a prioritized proof" complete (prefix ++ suffix)
    assertEqual "resumption refunded or duplicated prioritized choice work"
        completeChoices (prefixChoices + suffixChoices)
    mapM_ (expectRight . checkProof [] goal) complete
  where
    finished Nothing = True
    finished Just{} = False
    consume :: Integer -> ProofSearchCursor -> ([Proof], Integer, Maybe ProofSearchCursor)
    consume allowance cursor | allowance <= 0 = ([], 0, Just cursor)
    consume allowance cursor = case observeProofSearch cursor of
        ProofSearchFinished -> ([], 0, Nothing)
        ProofSearchChoice rest ->
            let (proofs, charged, continuation) = consume (allowance - 1) rest
            in (proofs, charged + 1, continuation)
        ProofSearchResult proof rest ->
            let (proofs, charged, continuation) = consume allowance rest
            in (proof : proofs, charged, continuation)

testCandidateStreamBudgets :: IO ()
testCandidateStreamBudgets = do
    source <- expectRight (parseHType "(a -> a) -> (a -> a) -> a -> a") >>= expectShownRight . toSynthesisType
    prepared <- expectShownRight $ prepareEnvironment emptyEnvironment
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $ sharedName "streamBudget"
    -- This fixture has one formula plan and no providers or polymorphic
    -- families. Its independent raw cursor exposes the precise work boundary;
    -- the sequential batch runner's overflow-proof lookahead may pass it.
    formula <- expectRight $ RawEnvironment.preparedEnvironmentSynthesisFormulaTranslator prepared source
    forM_ [(strategy, raw, fuel) | strategy <- [DepthFirst, Interleave],
            raw <- [1, 2, 8], fuel <- [0, 1, 4, 40, 200]] $ \(strategy, raw, fuel) -> do
        let configured = defaultQueryOptions
                { optionAlternatives = True, optionSorted = False, optionStrategy = strategy
                , optionCutoff = raw, optionBudget = Just fuel }
            atBounds message = message ++ " at " ++ show (strategy, raw, fuel)
        batch <- expectShownRight $ inhabitTypedSynthesisResultPreparedWithSourceGoal
            configured prepared source [] (DjinnSourceInstantiationCandidates []) target source
        observations <- expectShownRight (inhabitTypedSynthesisStreamPreparedWithSourceGoal
            configured prepared source [] (DjinnSourceInstantiationCandidates []) target source)
            >>= mapM expectShownRight
        rawCursor <- expectRight $ startProofSearchChecked
            (defaultSearchMode True)
                { searchStrategy = strategy, searchTermAlternatives = True
                , searchBudget = Just fuel, searchRanking = optionRanking configured }
            [] formula
        let clauses result = map (show . SharedCandidate.candidateOutput .
                SharedTypedCandidate.typedCandidateCompatibility) $
                SharedSearch.batchCandidates $ SharedQuery.resultSearch result
            allClauses = concatMap clauses observations
        assertEqual (atBounds "streaming restarted/refunded an allowance")
            (sort $ clauses batch) (sort allClauses)
        assertBool (atBounds "de-duplication failed across singleton batches") $
            length allClauses == length (nub allClauses)
        assertEqual (atBounds "streaming changed the exact observed raw/choice boundary")
            (SharedSearch.Completed $ cursorCompletion raw fuel rawCursor)
            (SharedSearch.batchProgress $ SharedQuery.resultSearch $ last observations)
        forM_ (init observations) $ \observation -> assertEqual
            (atBounds "a prefix batch reported an unobserved terminal result") SharedSearch.Continuing $
                SharedSearch.batchProgress $ SharedQuery.resultSearch observation
        assertEqual (atBounds "an empty terminal stream batch repeated positive candidate evidence")
            SharedQuery.NoEvidence $ SharedQuery.resultEvidence $ last observations
  where
    cursorCompletion remaining _ _ | remaining <= 0 =
        SharedSearch.truncated SharedSearch.CandidateLimitReached
    cursorCompletion remaining fuel cursor = case observeProofSearch cursor of
        ProofSearchFinished -> SharedSearch.Finished
        ProofSearchChoice rest
            | fuel <= 0 -> SharedSearch.truncated SharedSearch.ChoicePointLimitReached
            | otherwise -> cursorCompletion remaining (fuel - 1) rest
        ProofSearchResult _ rest -> cursorCompletion (remaining - 1) fuel rest

-- The supplied fold and intrinsic constructors activate multiple positive-only
-- plans. Unlike the one-plan test above, their batch/stream schedules need not
-- emit the same finite prefix. Both must honor the same explicit allowances,
-- retain exact candidate authority, and never turn truncation into refutation.
testConstructorCompositionBudgets :: IO ()
testConstructorCompositionBudgets = do
    let element = SharedType.TypeVariable "a"
        result = SharedType.TypeVariable "r"
        listOf = SharedType.TypeApplication $ SharedType.TypeConstructor SharedName.listName
        foldName = sharedName "foldList"
        foldType = SharedType.ForallType ["a", "r"] [] $
            SharedType.FunctionType (SharedType.FunctionType element $
                SharedType.FunctionType result result) $
            SharedType.FunctionType result $ SharedType.FunctionType (listOf element) result
        declarations =
            [ SharedDeclaration.DataTypeDeclaration () SharedName.listName
                [SharedDeclaration.TypeParameter "a" Nothing]
                [ SharedDeclaration.DataConstructor () SharedName.listName []
                , SharedDeclaration.DataConstructor () SharedName.consName [element, listOf element]
                ]
            , SharedDeclaration.ValueDeclaration $
                SharedDeclaration.ValueSignature () foldName foldType
            ]
    environment <- mkNeutralDjinnEnvironment declarations
    prepared <- expectShownRight $ RawEnvironment.prepareGroundSynthesisEnvironment environment
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $ sharedName "boundedFoldComposition"
    forM_ [(False, "forall a. [a] -> [a] -> [a]"),
           (True, "forall a. [a] -> a")] $ \(opaque, spelling) -> do
        source <- expectRight (parseHType spelling) >>= expectShownRight . toSynthesisType
        -- Mirror request preparation: preserve the explicit source signature,
        -- but pass its freshly implicitized body to the prepared search API.
        (implicit, _) <- expectShownRight $ SharedType.implicitizeLeadingForalls
            (const (Nothing :: Maybe ())) freshSourceVariable Set.empty source
        let (_, contexts, searchGoal) = SharedType.splitLeadingForalls implicit
        forM_ [(raw, fuel) | raw <- [1, 2, 8], fuel <- [0, 1, 2, 4, 40]] $ \(raw, fuel) -> do
            let configured = defaultQueryOptions
                    { optionAlternatives = True, optionSorted = False, optionStrategy = Interleave
                    , optionCutoff = raw, optionBudget = Just fuel }
                atBounds message = message ++ " at " ++ show (spelling, raw, fuel)
                runBatch = inhabitTypedSynthesisResultPreparedWithSourceGoal
                    configured prepared source contexts (DjinnSourceInstantiationCandidates []) target searchGoal
                runStream = inhabitTypedSynthesisStreamPreparedWithSourceGoal
                    configured prepared source contexts (DjinnSourceInstantiationCandidates []) target searchGoal
                candidates = SharedSearch.batchCandidates . SharedQuery.resultSearch
                checkResult resultBatch = do
                    let actual = candidates resultBatch
                        evidence = SharedQuery.resultEvidence resultBatch
                    assertBool (atBounds "a finite positive-only plan acquired negative evidence") $
                        evidence == SharedQuery.NoEvidence || evidence == SharedQuery.ValidatedCandidates
                    if opaque then do
                        assertEqual (atBounds "the empty recursive input acquired an element") [] actual
                        assertEqual (atBounds "opaque recursive search acquired logical evidence")
                            SharedQuery.NoEvidence evidence
                    else pure ()
                    forM_ actual $ \candidate -> do
                        graph <- expectShownRight $ SharedTypedCandidate.typedCandidateTermGraph candidate
                        let clause = SharedCandidate.candidateOutput $
                                SharedTypedCandidate.typedCandidateCompatibility candidate
                        assertEqual (atBounds "constructor composition changed its associated clause")
                            clause $ SharedTypedGenerated.eraseTermGraphToFunctionClause target graph
                        root <- maybe (fail $ atBounds "sealed candidate has no root") pure $
                            SharedTypedGenerated.lookupTermNode (SharedTypedGenerated.termGraphRoot graph) graph
                        assertBool (atBounds "opened inputs changed the exact source goal") $
                            SharedTypeAtom.alphaEquivalentClosedTypes source $ SharedTypedGenerated.termNodeType root
                        assertBool (atBounds "opened inputs captured or introduced a source global") $
                            all (`elem` [foldName, SharedName.listName, SharedName.consName]) $
                                SharedGenerated.expressionGlobals $ SharedTypedGenerated.eraseTermGraph graph
            batch <- expectShownRight runBatch
            checkResult batch
            assertBool (atBounds "batch exceeded the raw candidate allowance") $
                length (candidates batch) <= raw
            observations <- expectShownRight runStream >>= mapM expectShownRight
            mapM_ checkResult observations
            assertBool (atBounds "stream exceeded its cumulative raw candidate allowance") $
                sum (map (length . candidates) observations) <= raw
            case reverse observations of
                [] -> fail $ atBounds "stream omitted its terminal observation"
                terminal : earlier -> do
                    assertEqual (atBounds "terminal batch repeated a candidate") [] $ candidates terminal
                    assertEqual (atBounds "terminal batch repeated positive evidence")
                        SharedQuery.NoEvidence $ SharedQuery.resultEvidence terminal
                    case SharedSearch.batchProgress $ SharedQuery.resultSearch terminal of
                        SharedSearch.Continuing -> fail $ atBounds "finite stream did not finish"
                        SharedSearch.Completed _ -> pure ()
                    forM_ earlier $ \observation -> do
                        assertEqual (atBounds "prefix claimed completion before its tail")
                            SharedSearch.Continuing $ SharedSearch.batchProgress $ SharedQuery.resultSearch observation
                        assertBool (atBounds "stream combined more than one raw-proof result") $
                            length (candidates observation) <= 1
            if fuel == 0 then do
                let exhausted = SharedSearch.Completed $
                        SharedSearch.truncated SharedSearch.ChoicePointLimitReached
                assertEqual (atBounds "zero-choice batch bypassed its first charged step")
                    exhausted $ SharedSearch.batchProgress $ SharedQuery.resultSearch batch
                assertEqual (atBounds "zero-choice stream emitted a candidate") 0 $
                    sum $ map (length . candidates) observations
                case reverse observations of
                    terminal : _ -> assertEqual (atBounds "zero-choice stream bypassed its first charged step")
                        exhausted $ SharedSearch.batchProgress $ SharedQuery.resultSearch terminal
                    [] -> fail $ atBounds "zero-choice stream omitted its terminal observation"
            else pure ()
  where
    freshSourceVariable unavailable variable = Just $ choose $ variable ++ "'"
      where
        choose candidate
            | candidate `Set.member` unavailable = choose $ candidate ++ "'"
            | otherwise = candidate

testCandidateStreamGraphs :: IO ()
testCandidateStreamGraphs = do
    source <- expectRight (parseHType "a -> a -> a") >>= expectShownRight . toSynthesisType
    prepared <- expectShownRight $ prepareEnvironment emptyEnvironment
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $ sharedName "streamGraphs"
    let configured = defaultQueryOptions
            { optionAlternatives = True, optionSorted = False, optionStrategy = Interleave
            , optionCutoff = 32, optionBudget = Just 10000 }
    observations <- expectShownRight (inhabitTypedSynthesisStreamPreparedWithSourceGoal
        configured prepared source [] (DjinnSourceInstantiationCandidates []) target source)
        >>= mapM expectShownRight
    let candidates = concatMap (SharedSearch.batchCandidates . SharedQuery.resultSearch) observations
    assertEqual "the finite two-choice stream lost or duplicated a candidate" 2 $ length candidates
    graphs <- mapM (expectShownRight . SharedTypedCandidate.typedCandidateTermGraph) candidates
    let nodeIds = concatMap (map fst . SharedTypedGenerated.termGraphNodes) graphs
    assertEqual "singleton stream batches reused a candidate graph identity"
        (length nodeIds) (Set.size $ Set.fromList nodeIds)
    forM_ (zip candidates graphs) $ \(candidate, graph) -> assertEqual
        "a streamed source graph moved to another compatibility candidate"
        (SharedCandidate.candidateOutput $ SharedTypedCandidate.typedCandidateCompatibility candidate)
        (SharedTypedGenerated.eraseTermGraphToFunctionClause target graph)

testCandidateStreamEvidence :: IO ()
testCandidateStreamEvidence = do
    source <- expectRight (parseHType "a") >>= expectShownRight . toSynthesisType
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $ sharedName "streamEvidence"
    self <- expectRight $ declare (Function "streamEvidence" $ HTVar "a") emptyEnvironment
    unsupported <- expectRight (parseHType "((forall a. a) -> b) -> b") >>= expectShownRight . toSynthesisType
    forM_ [(strategy, name, environment, goal) | strategy <- [DepthFirst, Interleave],
            (name, environment, goal) <- [("uninhabited", emptyEnvironment, source),
                ("self-reference", self, source), ("unsupported", emptyEnvironment, unsupported)]] $
        \(strategy, name, environment, goal) -> do
            prepared <- expectShownRight $ prepareEnvironment environment
            let configured = defaultQueryOptions
                    { optionAlternatives = True, optionSorted = False, optionStrategy = strategy
                    , optionCutoff = 16, optionBudget = Just 1000 }
                atCase message = message ++ " at " ++ show (strategy, name)
            batch <- expectShownRight $ inhabitTypedSynthesisResultPreparedWithSourceGoal
                configured prepared goal [] (DjinnSourceInstantiationCandidates []) target goal
            observations <- expectShownRight (inhabitTypedSynthesisStreamPreparedWithSourceGoal
                configured prepared goal [] (DjinnSourceInstantiationCandidates []) target goal)
                >>= mapM expectShownRight
            assertEqual (atCase "a candidate-free stream invented a witness") 0 $ sum $
                map (length . SharedSearch.batchCandidates . SharedQuery.resultSearch) observations
            assertEqual (atCase "a terminal stream changed the established logical diagnostic")
                (SharedQuery.resultEvidence batch) $ SharedQuery.resultEvidence $ last observations
            assertEqual (atCase "a candidate-free stream changed operational termination")
                (SharedSearch.batchProgress $ SharedQuery.resultSearch batch)
                (SharedSearch.batchProgress $ SharedQuery.resultSearch $ last observations)
            assertBool (atCase "a candidate-free prefix exposed terminal negative evidence") $
                null $ filter ((/= SharedQuery.NoEvidence) . SharedQuery.resultEvidence) $ init observations
    prepared <- expectShownRight $ prepareEnvironment emptyEnvironment
    forM_ [DepthFirst, Interleave] $ \strategy -> do
        zero <- expectShownRight (inhabitTypedSynthesisStreamPreparedWithSourceGoal
            defaultQueryOptions {optionAlternatives = True, optionStrategy = strategy, optionBudget = Just 0}
            prepared unsupported [] (DjinnSourceInstantiationCandidates []) target unsupported)
            >>= mapM expectShownRight
        assertEqual ("zero-fuel streaming absence became a refutation at " ++ show strategy)
            SharedQuery.NoEvidence $ SharedQuery.resultEvidence $ last zero

testCandidateStreamValidation :: IO ()
testCandidateStreamValidation = do
    prepared <- expectShownRight $ prepareEnvironment emptyEnvironment
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $ sharedName "streamValidation"
    let poison = error "invalid streaming options inspected their query source"
    case inhabitTypedSynthesisStreamPreparedWithSourceGoal
            defaultQueryOptions {optionCutoff = 0} prepared poison []
            (DjinnSourceInstantiationCandidates []) target poison of
        Left (DjinnQueryOptionsFailure (NonPositiveCandidateCutoff 0)) -> pure ()
        Left failure -> fail $ "unexpected streaming validation error: " ++ show failure
        Right _ -> fail "invalid streaming cutoff crossed eager request validation"
    let variable = SharedType.TypeVariable
    case inhabitTypedSynthesisStreamPreparedWithSourceGoal defaultQueryOptions
            prepared (variable "a") [] (DjinnSourceInstantiationCandidates []) target (variable "b") of
        Left (DjinnInternalQueryFailure message) -> assertBool
            "streaming mismatch lost source ownership diagnostic" $
                "does not match its preserved source goal" `isInfixOf` message
        Left failure -> fail $ "unexpected source mismatch: " ++ show failure
        Right _ -> fail "unrelated streaming source goal acquired a lazy candidate stream"

testCandidateStreamContext :: IO ()
testCandidateStreamContext = do
    environment <- expectRight $ declare
        (ClassDecl "StreamContext" ["a"]
            [("streamContextMethod", HTArrow (HTVar "a") (HTVar "a"))]) emptyEnvironment
    prepared <- expectShownRight $ prepareEnvironment environment
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $ sharedName "streamContext"
    let variable = SharedType.TypeVariable "a"
        contexts = [Constraint (sharedName "StreamContext") [variable]]
        goal = SharedType.FunctionType variable variable
        source = SharedType.ForallType [] contexts goal
        configured = defaultQueryOptions
            { optionAlternatives = True, optionSorted = False, optionStrategy = Interleave
            , optionCutoff = 16, optionBudget = Just 1000 }
    batch <- expectShownRight $ inhabitTypedSynthesisResultPreparedWithSourceGoal
        configured prepared source contexts (DjinnSourceInstantiationCandidates []) target goal
    observations <- expectShownRight (inhabitTypedSynthesisStreamPreparedWithSourceGoal
        configured prepared source contexts (DjinnSourceInstantiationCandidates []) target goal)
        >>= mapM expectShownRight
    let candidates = concatMap (SharedSearch.batchCandidates . SharedQuery.resultSearch) observations
        compatibility = map SharedTypedCandidate.typedCandidateCompatibility
    assertEqual "streaming contextual synthesis changed compatible candidates"
        (compatibility $ SharedSearch.batchCandidates $ SharedQuery.resultSearch batch)
        (compatibility candidates)
    assertBool "the contextual identity fixture produced no candidates" $ not $ null candidates
    assertUnusedGivenIdentityGraphs target source (sharedName "StreamContext") batch
    forM_ observations $ assertUnusedGivenIdentityGraphs target source (sharedName "StreamContext")

testFoldBridgeReuse :: IO ()
testFoldBridgeReuse = do
    source <- expectRight $ parseHType
        "forall a r q. (q -> ((a -> r -> r) -> r -> r)) -> q -> q -> (a -> r -> r) -> r -> r"
    let options = defaultQueryOptions
            { optionAlternatives = True, optionSorted = False, optionStrategy = Interleave
            , optionCutoff = 512, optionBudget = Just 100000 }
        run configured = expectRight $ inhabitGenerated configured emptyEnvironment []
            "reuseOpaqueFoldBridge" source
        expressions = map (SharedGenerated.functionClauseExpression . SharedCandidate.candidateOutput) .
            generatedReportCandidates
        samples = [[], [7], [11, 29], [-2, 1, 8, -2]]
        appends expression = all (\(left, rightValues) ->
            observe expression left rightValues == Right (left ++ rightValues))
            [(left, rightValues) | left <- samples, rightValues <- samples]
    result <- run options
    assertBool ("the bridge was consumed before its second opaque input; candidates=" ++
        show (length $ expressions result) ++ "; completion=" ++
        show (generatedReportCompletion result)) $ any appends $ expressions result
    bounded <- run options {optionCutoff = 1}
    assertBool "finite bridge saturation refilled the one-proof allowance" $
        length (expressions bounded) <= 1
    zero <- run options {optionCutoff = 8, optionBudget = Just 0}
    assertEqual "bridge alternatives bypassed the zero-choice guard"
        (SharedSearch.truncated SharedSearch.ChoicePointLimitReached) $
        generatedReportCompletion zero
  where
    observe expression left rightValues = do
        candidate <- evaluateCarrierExpression 10000 Map.empty expression
        converted <- carrierTestApply candidate $ CarrierTestFunction Right
        firstInput <- carrierTestApply converted $ carrierListEncode left
        folded <- carrierTestApply firstInput $ carrierListEncode rightValues
        carrierListDecode folded

testBinaryCompositionWithOuterResult :: IO ()
testBinaryCompositionWithOuterResult = mapM_ check [False, True]
  where
    check withOuter = do
        source <- expectRight $ parseHType $
            "forall r. (r -> r -> r) -> (r -> r) -> " ++
            (if withOuter then "r -> r -> r" else "r -> r")
        result <- expectRight $ inhabitGenerated
            defaultQueryOptions
                { optionAlternatives = True, optionSorted = False, optionStrategy = Interleave
                , optionCutoff = 256, optionBudget = Just 100000 }
            emptyEnvironment [] "composeOverInnerResult" source
        let expressions = map (SharedGenerated.functionClauseExpression . SharedCandidate.candidateOutput) $
                generatedReportCandidates result
            cases = [(binary, unary, outer, inner)
                | binary <- [(\x y -> x + 3 * y), (\x y -> 7 * x - y)]
                , unary <- [(\x -> 2 * x + 1), negate, const 5]
                , outer <- [-2, 0, 7], inner <- [-1, 3]]
            accepts leftFirst expression = all (\(binary, unary, outer, inner) ->
                observe withOuter expression binary unary outer inner == Right
                    (if leftFirst then binary (unary inner) inner else binary inner (unary inner))) cases
        mapM_ (\leftFirst -> assertBool
            ("binary composition was lost with extra outer result=" ++ show withOuter ++
                ", transformed argument is first=" ++ show leftFirst ++
                "; completion=" ++ show (generatedReportCompletion result)) $
            any (accepts leftFirst) expressions) [False, True]
    observe withOuter expression binary unary outer inner = do
        candidate <- evaluateCarrierExpression 10000 Map.empty expression
        withBinary <- carrierTestApply candidate $ CarrierTestFunction $ \left ->
            Right $ CarrierTestFunction $ \rightValue -> case (left, rightValue) of
                (CarrierTestElement x, CarrierTestElement y) -> Right $ CarrierTestElement $ binary x y
                _ -> Left "binary function received a non-element"
        withUnary <- carrierTestApply withBinary $ CarrierTestFunction $ \value -> case value of
            CarrierTestElement x -> Right $ CarrierTestElement $ unary x
            _ -> Left "unary function received a non-element"
        withOuterValue <- if withOuter
            then carrierTestApply withUnary $ CarrierTestElement outer
            else pure withUnary
        result <- carrierTestApply withOuterValue $ CarrierTestElement inner
        case result of
            CarrierTestElement value -> Right value
            _ -> Left "composition returned a non-element"

data CarrierTestValue
    = CarrierTestFunction (CarrierTestValue -> Either String CarrierTestValue)
    | CarrierTestElement Int
    | CarrierTestList [Int]

carrierTestApply :: CarrierTestValue -> CarrierTestValue -> Either String CarrierTestValue
carrierTestApply (CarrierTestFunction function) argument = function argument
carrierTestApply _ _ = Left "the generated term applied a non-function"

-- This rank-one control separates composition enumeration from selection of a
-- rank-N carrier. The supplied endomorphisms record their exact application
-- order, so neither projection nor repeated use of one argument can pass.
testEndomorphismCompositionAlternatives :: IO ()
testEndomorphismCompositionAlternatives = do
    source <- expectRight $ parseHType
        "forall r. (r -> r) -> (r -> r) -> r -> r"
    let options = defaultQueryOptions
            { optionAlternatives = True, optionSorted = False
            , optionStrategy = Interleave
            , optionCutoff = 256, optionBudget = Just 10000
            }
        run configured = expectRight $ inhabitGenerated configured emptyEnvironment []
            "compositionResult" source
    alternatives <- run options
    first <- run options {optionAlternatives = False}
    singleton <- run options {optionAlternatives = False, optionCutoff = 1}
    let expressions = map (SharedGenerated.functionClauseExpression . SharedCandidate.candidateOutput) $
            generatedReportCandidates alternatives
        observed = map applicationOrder expressions
        diagnostic = unlines
            [ "both endomorphism compositions must remain reachable within 256 raw proofs / 10000 choices"
            , "candidate count: " ++ show (length expressions)
            , "completion: " ++ show (generatedReportCompletion alternatives)
            , "observed application orders: " ++ show observed
            , "first expressions: " ++ show (take 8 expressions)
            ]
    assertBool diagnostic $ all (`elem` observed) [Right [1, 2], Right [2, 1]]
    assertEqual "alternative composition changed first-only synthesis"
        (map SharedCandidate.candidateOutput $ generatedReportCandidates first)
        (map SharedCandidate.candidateOutput $ generatedReportCandidates singleton)
  where
    applicationOrder expression = do
        candidate <- evaluateCarrierExpression 10000 Map.empty expression
        first <- carrierTestApply candidate $ record 1
        second <- carrierTestApply first $ record 2
        result <- carrierTestApply second $ CarrierTestList []
        case result of
            CarrierTestList values -> Right values
            _ -> Left "the endomorphism result was not its supplied result type"
    record marker = CarrierTestFunction $ \value -> case value of
        CarrierTestList values -> Right $ CarrierTestList $ marker : values
        _ -> Left "the endomorphism received a different result type"

testEndomorphismCompositionWithOuterResult :: IO ()
testEndomorphismCompositionWithOuterResult = do
    source <- expectRight $ parseHType
        "forall r. r -> (r -> r) -> (r -> r) -> r -> r"
    result <- expectRight $ inhabitGenerated
        defaultQueryOptions
            { optionAlternatives = True, optionSorted = False
            , optionStrategy = Interleave
            , optionCutoff = 256, optionBudget = Just 10000
            }
        emptyEnvironment [] "compositionWithOuterResult" source
    let expressions = map (SharedGenerated.functionClauseExpression . SharedCandidate.candidateOutput) $
            generatedReportCandidates result
        observed = map applicationOrder expressions
    assertBool ("compositions over the last result argument were missing: " ++ show observed) $
        all (`elem` observed) [Right [1, 2, 9], Right [2, 1, 9]]
  where
    applicationOrder expression = do
        candidate <- evaluateCarrierExpression 10000 Map.empty expression
        outer <- carrierTestApply candidate $ CarrierTestList [8]
        first <- carrierTestApply outer $ record 1
        second <- carrierTestApply first $ record 2
        result <- carrierTestApply second $ CarrierTestList [9]
        case result of
            CarrierTestList values -> Right values
            _ -> Left "the endomorphism result did not preserve the supplied type"
    record marker = CarrierTestFunction $ \value -> case value of
        CarrierTestList values -> Right $ CarrierTestList $ marker : values
        _ -> Left "the endomorphism received a different result type"

carrierListResult :: SharedGenerated.Expression String -> [Int] -> Either String [Int]
carrierListResult expression inputs = do
    candidate <- evaluateCarrierExpression 10000 Map.empty expression
    folded <- carrierTestApply candidate $ carrierListEncode inputs
    carrierListDecode folded

carrierListDecode :: CarrierTestValue -> Either String [Int]
carrierListDecode folded = do
    withStep <- carrierTestApply folded cons
    result <- carrierTestApply withStep $ CarrierTestList []
    case result of
        CarrierTestList values -> Right values
        _ -> Left "the generated Church fold returned a non-list"
  where
    cons = CarrierTestFunction $ \element -> Right $ CarrierTestFunction $ \rest ->
        case (element, rest) of
            (CarrierTestElement value, CarrierTestList values) ->
                Right $ CarrierTestList $ value : values
            _ -> Left "the generated fold used a malformed list constructor"

carrierListEncode :: [Int] -> CarrierTestValue
carrierListEncode inputs = CarrierTestFunction $ \step -> Right $ CarrierTestFunction $ \zero ->
    foldValues step zero inputs
  where
    foldValues _ zero [] = Right zero
    foldValues step zero (value : values) = do
        rest <- foldValues step zero values
        applied <- carrierTestApply step $ CarrierTestElement value
        carrierTestApply applied rest
evaluateCarrierExpression :: Int -> Map.Map String CarrierTestValue
    -> SharedGenerated.Expression String -> Either String CarrierTestValue
evaluateCarrierExpression fuel environment expression'
    | fuel <= 0 = Left "the test interpreter exhausted its reduction depth"
    | otherwise = case expression' of
        SharedGenerated.Local name -> maybe
            (Left $ "unbound generated variable: " ++ name) Right $
            Map.lookup name environment
        SharedGenerated.Lambda [] body -> descend body
        SharedGenerated.Lambda (pattern' : rest) body ->
            Right $ CarrierTestFunction $ \argument -> do
                nested <- bind pattern' argument environment
                evaluateCarrierExpression (fuel - 1) nested $
                    SharedGenerated.Lambda rest body
        SharedGenerated.Apply function argument -> do
            callable <- descend function
            value <- descend argument
            carrierTestApply callable value
        SharedGenerated.VisibleTypeApplication function _ -> descend function
        SharedGenerated.Let pattern' value body -> do
            result <- descend value
            nested <- bind pattern' result environment
            evaluateCarrierExpression (fuel - 1) nested body
        _ -> Left "the generated term left the test's pure lambda fragment"
  where
    descend = evaluateCarrierExpression (fuel - 1) environment
    bind pattern' value bindings = case pattern' of
        SharedGenerated.Bind name -> Right $ Map.insert name value bindings
        SharedGenerated.Wildcard -> Right bindings
        _ -> Left "the generated term used a non-variable lambda pattern"

-- A selected impredicative image may itself require constructing a value.
-- Every opened argument scope remains rigid and isolated from ambient data.
testConstructedRankN :: IO ()
testConstructedRankN = do
    let construction = Symbol "$djinn$query-constructed-instantiation$guard"
        child = Symbol "$djinn$query-constructed-instantiation$guard$nested$0$0"
        sibling = Symbol "$djinn$query-constructed-instantiation$sibling"
        ordinary = Symbol "$djinn$instantiation$guard"
        input = Var $ Symbol "input"
        use symbol argument = Apply (Apply (Var symbol) input) argument
        evidence = Set.fromList [construction, child, sibling, ordinary]
    assertBool "sibling construction scopes remain independent" $
        InstantiationEvidence.independentConstructionScopes evidence $
            Apply (Apply (Ctuple 2) (use construction input)) (use construction input)
    assertBool "a construction scope cannot capture its own earlier introduction" $
        not $ InstantiationEvidence.independentConstructionScopes evidence $
            use construction (use construction input)
    assertBool "ordinary instantiation remains reusable" $
        InstantiationEvidence.independentConstructionScopes evidence $
            use ordinary (use ordinary input)
    assertBool "nested construction retains its lexical ancestor" $
        InstantiationEvidence.independentConstructionScopes evidence $
            use construction (use child input)
    assertBool "a child construction cannot escape its ancestor" $
        not $ InstantiationEvidence.independentConstructionScopes evidence $
            use child input
    assertBool "a sibling cannot authorize another construction's child" $
        not $ InstantiationEvidence.independentConstructionScopes evidence $
            use sibling (use child input)
    prepared <- expectShownRight $ prepareEnvironment standardEnvironment
    let rigid = "$djinn$skolem$construction$owned"
        otherRigid = "$djinn$skolem$construction$other"
        rigidType name = SharedType.TypeVariable name
        identityAt name = SharedType.FunctionType (rigidType name) (rigidType name)
        checkOwned = RawEnvironment.checkPreparedSynthesisTypesKindsWithRigids
            prepared (Set.singleton rigid)
    assertEqual "an owned rigid can cross the internal kind boundary" (Right ()) $
        checkOwned [(KStar, identityAt rigid)]
    assertConstructionRejected "source kind checking rejects a private rigid" $
        RawEnvironment.checkPreparedSynthesisTypesKinds prepared [(KStar, identityAt rigid)]
    assertConstructionRejected "another rigid is not authorized by the owned set" $
        checkOwned [(KStar, identityAt otherRigid)]
    assertConstructionRejected "owned rigid renaming retains kind consistency" $
        checkOwned [(KStar, SharedType.FunctionType (rigidType rigid) $
            SharedType.TypeApplication (rigidType rigid) $
                SharedType.TupleType SharedName.Boxed [])]
    session <- expectShownRight Djex.standardDjinnSession
    globalResult <- expectShownRight $ SharedName.mkIdentifier "ConstructedGlobal"
    globalProvider <- expectShownRight $ SharedName.mkIdentifier "constructedGlobalProvider"
    unitProvider <- expectShownRight $ SharedName.mkIdentifier "constructedUnitSeed"
    let proper = SharedKind.ProperTypeKind
        globalDeclarations = [SharedDeclaration.AbstractTypeDeclaration ()
            globalResult $ SharedKind.FunctionKind proper $
                SharedKind.FunctionKind proper proper]
    globalBaseEnvironment <- expectShownRight $ SharedEnvironment.mkEnvironment globalDeclarations
    globalBaseSession <- expectShownRight $ Djex.mkDjinnSession globalBaseEnvironment
    globalProviderRequest <- expectShownRight $ Djex.parseDjinnRequest globalBaseSession
        defaultQueryOptions globalProvider "constructed-global-provider"
        "forall a. a -> () -> forall b. b -> ConstructedGlobal a b"
    globalEnvironment <- expectShownRight $ SharedEnvironment.mkEnvironment $
        globalDeclarations ++
        [ SharedDeclaration.ValueDeclaration $ SharedDeclaration.ValueSignature () globalProvider $
            SharedQuery.requestGoal $ Djex.djinnRequestQuery globalProviderRequest
        , SharedDeclaration.ValueDeclaration $ SharedDeclaration.ValueSignature () unitProvider $
            SharedType.TupleType SharedName.Boxed []
        ]
    globalSession <- expectShownRight $ Djex.mkDjinnSession globalEnvironment
    check globalSession True ("constructLoadedAlternatingForalls",
        "ConstructedGlobal (forall a. a -> a) (forall a. a -> a)")
    layeredSeed <- expectShownRight $ SharedName.mkIdentifier "ConstructionSeed"
    layeredTwo <- expectShownRight $ SharedName.mkIdentifier "ConstructionTwo"
    layeredThree <- expectShownRight $ SharedName.mkIdentifier "ConstructionThree"
    let kindWithArguments count = foldr SharedKind.FunctionKind proper $
            replicate count proper
        layeredDeclarations =
            [ SharedDeclaration.AbstractTypeDeclaration () layeredSeed proper
            , SharedDeclaration.AbstractTypeDeclaration () layeredTwo $ kindWithArguments 2
            , SharedDeclaration.AbstractTypeDeclaration () layeredThree $ kindWithArguments 3
            ]
        layeredProviders =
            [ ("constructionSeed", "ConstructionSeed")
            , ("constructionMakerTwo", "ConstructionSeed -> forall a. a -> " ++
                "ConstructionSeed -> forall b. b -> ConstructionTwo a b")
            , ("constructionMakerThree", "ConstructionSeed -> forall a b. a -> b -> " ++
                "ConstructionSeed -> forall c. c -> ConstructionThree a b c")
            ]
    layeredBaseEnvironment <- expectShownRight $ SharedEnvironment.mkEnvironment layeredDeclarations
    layeredBaseSession <- expectShownRight $ Djex.mkDjinnSession layeredBaseEnvironment
    layeredValues <- mapM (\(spelling, source) -> do
        name <- expectShownRight $ SharedName.mkIdentifier spelling
        parsed <- expectShownRight $ Djex.parseDjinnRequest layeredBaseSession
            defaultQueryOptions name "construction-layered-provider" source
        pure $ SharedDeclaration.ValueDeclaration $ SharedDeclaration.ValueSignature () name $
            SharedQuery.requestGoal $ Djex.djinnRequestQuery parsed) layeredProviders
    layeredEnvironment <- expectShownRight $ SharedEnvironment.mkEnvironment $
        layeredDeclarations ++ layeredValues
    layeredSession <- expectShownRight $ Djex.mkDjinnSession layeredEnvironment
    -- Both factories are present for both queries: an unrelated available
    -- result constructor must not hide the useful residual quantified scheme.
    mapM_ (check layeredSession True)
        [ ("constructLoadedAfterSeedTwo",
            "ConstructionTwo (forall a. a -> a) (forall a. a -> a -> a)")
        , ("constructLoadedAfterSeedThree",
            "ConstructionThree (forall a. a -> a) " ++
            "(forall a. a -> a -> a) (forall a. a -> a)")
        ]
    mapM_ (check session True)
        [ ("constructPolyIdentity",
            "(forall a. a -> f a) -> f (forall b. b -> b)")
        , ("constructPolyComposition",
            "(forall a. a -> f a) -> (forall a. g a -> h a) -> " ++
            "(forall a. h a -> k a) -> f (forall a. g a -> k a)")
        , ("constructNestedPolyArgument",
            "(forall a. a -> f a) -> f (forall b. b -> f (forall c. c -> c))")
        , ("constructNestedAmbientPolyArgument",
            "(forall a. a -> f a) -> f (forall b. b -> f (forall c. b -> c -> b))")
        , ("constructDistinctPolyArguments",
            "(forall a b. a -> b -> f a b) -> " ++
            "f (forall x. x -> x) (forall y z. y -> z -> y)")
        , ("constructIdentityAndBoolean",
            "(forall a b. a -> b -> f a b) -> " ++
            "f (forall a. a -> a) (forall b. b -> b -> b)")
        , ("constructIdentityAndBooleanWithRepeatedBinders",
            "(forall a b. a -> b -> f a b) -> " ++
            "f (forall a. a -> a) (forall a. a -> a -> a)")
        , ("constructAmbientPolyArgument",
            "(forall a. a -> f a) -> f (forall b. x -> b -> x)")
        , ("constructHigherKindedPolyArgument",
            "(forall a. a -> f a) -> f (forall b. g b -> g b)")
        , ("constructAfterTermArgument",
            "(() -> forall a. a -> f a) -> f (forall b. b -> b)")
        , ("constructAlternatingForallSpine",
            "forall seed g. seed -> " ++
            "(seed -> forall a. a -> seed -> forall b. b -> g a b) -> " ++
            "g (forall c. c -> c) (forall d. d -> d)")
        , ("constructMixedArgumentsBeforeLaterForall",
            "forall seed f. seed -> " ++
            "(seed -> forall a b. a -> b -> seed -> forall c. c -> f a b c) -> " ++
            "f (forall a. a -> a) (forall a. a -> a -> a) (forall a. a -> a)")
        ]
    mapM_ (check session False)
        [ ("rejectEmptyPolyConstruction",
            "(forall a. a -> f a) -> f (forall b. b)")
        , ("rejectEscapingConstructionScope",
            "x -> (forall a. a -> f a) -> f (forall b. b)")
        , ("rejectCorrelatedEmptyScopes",
            "(forall a b. a -> b -> f a b) -> f (forall x. x) (forall y. y)")
        , ("rejectAlternatingScopeEscape",
            "forall seed x g. seed -> x -> " ++
            "(seed -> forall a. a -> seed -> forall b. b -> g a b) -> " ++
            "g (forall c. c -> c) (forall d. d)")
        , ("rejectMixedArgumentScopeEscape",
            "forall seed x f. seed -> x -> " ++
            "(seed -> forall a b. a -> b -> seed -> forall c. c -> f a b c) -> " ++
            "f (forall a. a -> a) (forall a. a -> a -> a) (forall a. a)")
        ]
  where
    assertConstructionRejected message result = case result of
        Left _ -> pure ()
        Right _ -> fail message
    check session expected (spelling, source) = do
        target <- expectShownRight $ SharedName.mkIdentifier spelling
        request <- expectShownRight $ Djex.parseDjinnRequest session
            defaultQueryOptions
                { optionSorted = False, optionCutoff = 1, optionBudget = Just 10000 }
            target "constructed-instantiation" source
        result <- expectShownRight $ Djex.runDjinnQuery session request
        let candidates = SharedSearch.batchCandidates $ SharedQuery.resultSearch result
        assertEqual (spelling ++ ": " ++ show (SharedQuery.resultSearch result))
            expected (not $ null candidates)

-- A coherent transport view must scale with the source rather than stopping
-- at the next middle layer of a fixed occurrence-subset frontier. The loaded
-- case additionally needs the query's available schemes while compiling a
-- provider's positive callback arguments.
testTransportRankN :: IO ()
testTransportRankN = do
    session <- expectShownRight Djex.standardDjinnSession
    mapM_ (checkLocal session) [8, 12]
    let results = ["TransportQ" ++ show n | n <- [1 .. 6 :: Int]]
        inputTypes = map (scheme "a") results
        outputTypes = map (scheme "b") results ++ replicate 6 identity
        consumerName = "consumeTransportTwelve"
    consumer <- expectRight $ parseHType $
        tuple outputTypes ++ " -> TransportResult"
    goal <- expectRight $ parseHType $
        arrows inputTypes "TransportResult"
    environment <- foldDeclarations standardEnvironment $
        map (\name -> AbstractType name KStar) ("TransportResult" : results) ++
            [Function consumerName consumer]
    report <- expectRight $ inhabit options environment []
        "loadedTransportTwelve" goal
    case reportOutcome report of
        Realized clauses -> assertBool
            "the exact loaded consumer was not used by the transport view" $
            any (consumerName `isInfixOf`) clauses
        outcome -> fail $ "loaded twelve-site transport failed: " ++ show outcome
  where
    options = defaultQueryOptions
        { optionSorted = False, optionCutoff = 1, optionBudget = Just 10000 }
    tuple values = "(" ++ joinComma values ++ ")"
    joinComma [] = ""
    joinComma [value] = value
    joinComma (value : rest) = value ++ ", " ++ joinComma rest
    arrows inputs result = foldr (\argument rest -> argument ++ " -> " ++ rest)
        result inputs
    scheme prefix result = "(forall " ++ unwords variables ++ ". " ++
        tuple variables ++ " -> " ++ result ++ ")"
      where variables = [prefix ++ show n | n <- [1 .. 7 :: Int]]
    identity = "(forall x. x -> x)"
    checkLocal session count = do
        let results = ["r" ++ show n | n <- [1 .. count]]
            source = arrows (map (scheme "a") results) $
                tuple $ map (scheme "b") results ++ replicate count identity
            spelling = "transport" ++ show (2 * count) ++ "Sites"
        target <- expectShownRight $ SharedName.mkIdentifier spelling
        request <- expectShownRight $ Djex.parseDjinnRequest session options
            target "transport-instantiation" source
        result <- expectShownRight $ Djex.runDjinnQuery session request
        assertBool (spelling ++ " exhausted search without a candidate") $
            not $ null $ SharedSearch.batchCandidates $ SharedQuery.resultSearch result
    foldDeclarations environment [] = pure environment
    foldDeclarations environment (declaration : rest) = do
        updated <- expectRight $ declare declaration environment
        foldDeclarations updated rest

testRankNTypeAtoms :: IO ()
testRankNTypeAtoms = do
    parsed <- expectRight $ parseHType
        "(forall a. Eq a => a -> a) -> [forall b. b -> b]"
    assertEqual "rendered higher-rank syntax parses back exactly"
        (Just parsed) (readMaybe $ show parsed)
    shared <- expectShownRight $ toSynthesisType parsed
    assertEqual "higher-rank HType/shared conversion is lossless"
        (Right parsed) (fromSynthesisType shared)
    assertEqual "higher-rank shared rendering remains parseable"
        (Just parsed) (readMaybe $ SharedTypeRender.renderType id shared)

    let poly binder = HTForall [binder] []
            $ HTArrow (HTVar binder) (HTVar binder)
        emptyScheme binder = HTForall [binder] [] $ HTVar binder
        list element = HTApp (HTCon "[]") element
        withFree binder free = HTForall [binder] []
            $ HTArrow (HTVar binder) (HTVar free)
    directIdentity <- expectRight $ hTypeToFormula []
        $ HTArrow (poly "a") (poly "renamed")
    case directIdentity of
        argument :-> result -> assertEqual
            "alpha-renamed direct rank-N types are the same atom"
            argument result
        other -> fail $ "rank-N arrow lost its outer structure: " ++ show other
    impredicativeIdentity <- expectRight $ hTypeToFormula []
        $ HTArrow (list $ poly "a") (list $ poly "renamed")
    case impredicativeIdentity of
        argument :-> result -> assertEqual
            "lists of alpha-renamed rank-N types are the same atom"
            argument result
        other -> fail $ "impredicative list lost its arrow: " ++ show other
    freeLeft <- expectRight $ hTypeToFormula [] $ withFree "a" "freeLeft"
    freeRight <- expectRight $ hTypeToFormula [] $ withFree "b" "freeRight"
    assertBool "free variables must remain part of opaque atom identity"
        $ freeLeft /= freeRight
    assertEqual "a syntactically vacuous forall is transparent"
        (hTypeToFormula [] $ HTVar "plain")
        (hTypeToFormula [] $ HTForall [] [] $ HTVar "plain")

    stableSession <- expectShownRight Djex.standardDjinnSession
    runStableIdentity stableSession "directRankN"
        "(forall a. a -> a) -> forall renamed. renamed -> renamed"
    runStableIdentity stableSession "impredicativeRankN"
        "[forall a. a -> a] -> [forall renamed. renamed -> renamed]"
    runStableIdentity stableSession "leadingForall"
        "forall a. a -> a"

    -- These are the first deliberately non-atomic rank-N cases. The first
    -- opens a forall in a function result; the second reaches positive
    -- position after crossing two function-parameter boundaries.
    runStableIdentity stableSession "introduceRankNResult"
        "c -> (forall a. a -> a)"
    runStableIdentity stableSession "passRankNArgument"
        "((forall a. a -> a) -> c) -> c"
    runStableIdentity stableSession "introduceRankNTuple"
        "c -> ((forall a. a -> a), (forall b. b -> b))"

    -- A positive contextual forall follows the same introduction rule. Djinn
    -- validates the context but deliberately withholds its methods, so these
    -- inhabitants must remain dictionary-independent.
    runStableIdentity stableSession "introduceContextualRankNResult"
        "c -> (forall a. Eq a => a -> a)"
    runStableIdentity stableSession "passContextualRankNArgument"
        "((forall a. Eq a => a -> a) -> c) -> c"

    -- The dual elimination stays opaque: using this hypothesis at @b@ would
    -- require evidence for @Eq b@, which Djinn neither resolves nor invents.
    constrainedHypothesis <- runStableQuery stableSession
        "keepConstrainedRankNHypothesisOpaque"
        "(forall a. Eq a => a) -> b"
    assertEqual "a constrained rank-N hypothesis was instantiated without evidence"
        [] $ SharedSearch.batchCandidates
            $ SharedQuery.resultSearch constrainedHypothesis
    assertEqual "an opaque constrained hypothesis produced false negative evidence"
        SharedQuery.NoEvidence $ SharedQuery.resultEvidence constrainedHypothesis

    -- Opening the contextual result must not make a class method available to
    -- LJT. Its omission also prevents a source-level refutation: the complete
    -- type is inhabited by \_ -> rankNWitness under the nested Given.
    let rankNInput = SharedDeclaration.AbstractTypeDeclaration ()
            (sharedName "RankNContextInput") SharedKind.ProperTypeKind
        rankNProof = SharedDeclaration.AbstractTypeDeclaration ()
            (sharedName "RankNContextProof") SharedKind.ProperTypeKind
        witnessClass = SharedDeclaration.ClassDeclaration ()
            (sharedName "RankNWitness")
            [SharedDeclaration.TypeParameter "a" Nothing]
            []
            [ SharedDeclaration.ValueSignature () (sharedName "rankNWitness")
                (SharedType.TypeConstructor $ sharedName "RankNContextProof")
            ]
    witnessSession <- sealDjinnSessionFrom stableSession
        [rankNInput, rankNProof, witnessClass]
    methodLeak <- runStableQuery witnessSession "doNotLeakNestedClassMethod"
        "RankNContextInput -> (forall a. RankNWitness a => RankNContextProof)"
    assertEqual "a nested contextual forall exposed its class method"
        [] $ SharedSearch.batchCandidates $ SharedQuery.resultSearch methodLeak
    assertEqual "an omitted class method produced false source negative evidence"
        SharedQuery.NoEvidence $ SharedQuery.resultEvidence methodLeak

    -- Positive opening alone cannot implement this transport: its argument
    -- stays opaque while its result opens with a fresh skolem. The legacy
    -- alpha-opaque plan is therefore retained as a sound fallback.
    runStableIdentity stableSession "transportEmptyPolytype"
        "(forall a. a) -> (forall b. b)"

    -- Bounded hypothesis instantiation realizes the classic negative-forall
    -- eliminations: the polymorphic hypothesis is used at sequent variables
    -- (including goal skolems), and the generated evidence is the hypothesis
    -- expression itself because GHC re-instantiates value occurrences.
    runStableIdentity stableSession "instantiateOpaqueRankN"
        "(forall a. a) -> b"
    runStableIdentity stableSession "applyPolymorphicIdentity"
        "(forall a. a -> a) -> b -> b"
    runStableIdentity stableSession "instantiateTwoSiblingInstances"
        "(forall a. a -> a) -> (b, c) -> (c, b)"
    runStableIdentity stableSession "instantiateAtGoalSkolem"
        "forall b. (forall a. a -> a) -> b -> b"
    runStableIdentity stableSession "instantiateAtImpredicativeWrapper"
        "(forall a. f a) -> f (Maybe (forall b. b -> b))"
    runStableIdentity stableSession "correlateGuardedImpredicativeInstances"
        $ "(forall a b. f a b) -> "
        ++ "f (forall x. x -> x) (forall y. y -> y -> y)"
    runStableIdentity stableSession "correlateThroughHistoricalNestedBridge"
        $ "(forall outer. outer -> (forall a b. g a b)) -> x -> "
        ++ "g (forall p. p -> p) (forall q. q -> q -> q)"

    let vacuousCorrelatedOptions = defaultQueryOptions
            { optionAlternatives = True
            , optionSorted = False
            , optionCutoff = 40
            }
    vacuousCorrelated <- runStableQueryWith vacuousCorrelatedOptions
        stableSession "ignoreVacuousCorrelatedChoice"
        $ "(forall a b. f a) -> u -> v -> w -> x -> y -> z -> "
        ++ "f (forall q. q -> q)"
    assertEqual
        "the correlated tail duplicated a historically retained specialization"
        1 $ length $ SharedSearch.batchCandidates
            $ SharedQuery.resultSearch vacuousCorrelated

    vacuousOnlyCorrelated <- runStableQueryWith vacuousCorrelatedOptions
        stableSession "ignoreVacuousOnlyCorrelatedChoices"
        $ "(forall p hidden. f p) -> "
        ++ "g (forall x. x -> x) -> h (forall y. y -> y -> y) -> "
        ++ "a -> c -> d -> e -> u -> v -> r -> (f v -> r) -> r"
    assertEqual
        "the directed fallback changed an already inhabited alternative stream"
        1 $ length $ SharedSearch.batchCandidates
            $ SharedQuery.resultSearch vacuousOnlyCorrelated

    -- A checked query-local hypothesis can instantiate at a closed monotype
    -- already present in the requested type. Keep that type in the indexed
    -- result: an unindexed result can instead be reached by impredicatively
    -- instantiating the provider at its own scheme and feeding it itself,
    -- which would not demonstrate closed-monotype discovery. The fixture is
    -- abstract so datatype construction cannot hide the required instance.
    let closedKind = SharedKind.ProperTypeKind
        closedName = sharedName "MonoClosed"
        tokenName = sharedName "MonoToken"
        resultName = sharedName "MonoResult"
        indexedName = sharedName "MonoIndexed"
        nominalEmptyName = sharedName "ProviderVoid"
        closedType = SharedType.TypeConstructor closedName
        tokenType = SharedType.TypeConstructor tokenName
        resultType = SharedType.TypeConstructor resultName
        indexedConstructor = SharedType.TypeConstructor indexedName
        indexedType element =
            SharedType.TypeApplication indexedConstructor element
        nominalEmptyType = SharedType.TypeConstructor nominalEmptyName
        abstractClosed name = SharedDeclaration.AbstractTypeDeclaration ()
            name closedKind
        closedScheme = SharedType.ForallType ["instanceType"] [] $
            SharedType.FunctionType
                (SharedType.FunctionType
                    (SharedType.TypeVariable "instanceType") tokenType)
                (SharedType.FunctionType
                    (SharedType.TypeVariable "instanceType") resultType)
        valueDeclaration spelling valueType =
            SharedDeclaration.ValueDeclaration $
                SharedDeclaration.ValueSignature ()
                    (sharedName spelling) valueType
        closedDeclarations =
            [ abstractClosed closedName
            , abstractClosed tokenName
            , abstractClosed resultName
            , SharedDeclaration.AbstractTypeDeclaration () indexedName $
                SharedKind.FunctionKind closedKind closedKind
            ]
    closedSession <- sealDjinnSessionFrom stableSession closedDeclarations

    queryTailPrefix <- runStableQueryWith firstCandidateOptions closedSession
        "preserveQueryClosedPrefixBeforeCorrelation" $
        "MonoClosed -> (forall a. f a) -> (forall a b. g a b) -> "
        ++ "Either (f MonoClosed) "
        ++ "(g (forall x. x -> x) (forall y. y -> y -> y))"
    queryTailPrefixRendered <- renderStableCandidates queryTailPrefix
    assertBool
        ("the correlated tail moved ahead of the established query-closed "
            ++ "prefix: " ++ show queryTailPrefixRendered)
        (not (null queryTailPrefixRendered) &&
            all ("Left" `isInfixOf`) queryTailPrefixRendered)

    runStableIdentity closedSession "composeCorrelatedAndClosedInstances" $
        "MonoClosed -> (forall a. f a) -> (forall a b. g a b) -> "
        ++ "(f MonoClosed, "
        ++ "g (forall x. x -> x) (forall y. y -> y -> y))"

    runStableIdentity closedSession "instantiateAtMentionedClosedMonotype" $
        "(forall a. (a -> MonoToken) -> a -> MonoIndexed a) -> "
        ++ "(MonoClosed -> MonoToken) -> MonoClosed -> "
        ++ "MonoIndexed MonoClosed"

    localVacuous <- runStableQuery closedSession
        "instantiateVacuousHypothesisAtClosedRankN" $
        "(forall selected. selected -> selected) -> "
        ++ "(forall hidden. MonoToken) -> MonoToken"
    localVacuousRendered <- renderStableCandidates localVacuous
    assertBool
        ("a query-local vacuous scheme lost its closed quantified choice: "
            ++ show localVacuousRendered)
        $ any
            ("@(forall a0_0. a0_0 -> a0_0)" `isInfixOf`)
            localVacuousRendered

    -- A vacuous local binder must retain the newly selected closed monotype
    -- explicitly: the result cannot tell GHC which query-supplied type made
    -- the bounded axiom available.  The older quantified choice above remains
    -- first, while multi-result collection reaches the additive closed tail.
    localClosedVacuous <- runStableQuery closedSession
        "instantiateVacuousHypothesisAtClosedMonotype" "MonoClosed -> (forall hidden. MonoToken) -> MonoToken"
    localClosedVacuousRendered <- renderStableCandidates localClosedVacuous
    assertBool
        ("a query-local vacuous scheme lost its closed monotype choice: "
            ++ show localClosedVacuousRendered)
        $ any ("@MonoClosed" `isInfixOf`) localClosedVacuousRendered

    -- The seed and consumer share MonoToken as their exact residual result,
    -- but require different visible-prefix lengths. A grouped bridge context
    -- must keep each full vector on its own local source occurrence.
    let groupedVisibleSource =
            "(forall selected. selected -> selected) -> " ++
            "(forall hidden. MonoToken) -> " ++
            "(forall first second. MonoToken -> MonoToken) -> MonoToken"
        groupedVisibleOptions = defaultQueryOptions
            { optionAlternatives = True
            , optionStrategy = Interleave
            , optionSorted = False
            , optionCutoff = 4096
            , optionBudget = Just 100000
            }
        groupedIdentity = SharedType.ForallType ["groupedIdentityType"] [] $
            SharedType.FunctionType
                (SharedType.TypeVariable "groupedIdentityType")
                (SharedType.TypeVariable "groupedIdentityType")
        groupedOccurrenceVectors expression = case SharedGenerated.expressionLambdaSpine $
                SharedGenerated.simplifyExpressionWithoutEtaBy id expression of
            ([_, SharedGenerated.Bind seed, SharedGenerated.Bind consumer],
                SharedGenerated.Apply
                    (SharedGenerated.VisibleTypeApplication
                        (SharedGenerated.VisibleTypeApplication
                            (SharedGenerated.Local usedConsumer) consumerFirst)
                        consumerSecond)
                    (SharedGenerated.VisibleTypeApplication
                        (SharedGenerated.Local usedSeed) seedArgument))
                | usedSeed == seed && usedConsumer == consumer && seed /= consumer ->
                    Just (seedArgument, consumerFirst, consumerSecond)
            _ -> Nothing
    groupedIdentityArgument <- expectShownRight $
        SharedGenerated.specifiedVisibleTypeArgument groupedIdentity
    groupedVisible <- runStableQueryWith groupedVisibleOptions closedSession
        "preserveGroupedLocalVisibleVectors" groupedVisibleSource
    let groupedVisibleCandidates = SharedSearch.batchCandidates $
            SharedQuery.resultSearch groupedVisible
        groupedVisibleExpressions = map
            (SharedGenerated.functionClauseExpression . SharedCandidate.candidateOutput)
            groupedVisibleCandidates
        groupedVisibleVectors =
            [vectors | Just vectors <- map groupedOccurrenceVectors groupedVisibleExpressions]
    assertBool
        ("cooperating local bridges lost or exchanged their one-/two-slot visible prefixes; " ++
            "candidate count=" ++ show (length groupedVisibleCandidates) ++
            "; progress=" ++ show (SharedSearch.batchProgress $ SharedQuery.resultSearch groupedVisible) ++
            "; observed vectors=" ++ show (take 8 groupedVisibleVectors)) $
        (groupedIdentityArgument, groupedIdentityArgument, groupedIdentityArgument)
            `elem` groupedVisibleVectors
    assertBool "grouped visible bridges exceeded their original raw candidate limit" $
        length groupedVisibleCandidates <= optionCutoff groupedVisibleOptions

    -- Loaded polymorphic values cross the same checked boundary.  The only
    -- possible inhabitant composes the three named globals, so this pins both
    -- closed-monotype discovery and post-check instantiation-evidence erasure.
    loadedSession <- sealDjinnSessionFrom stableSession $
        closedDeclarations ++
        [ valueDeclaration "monoToToken" $
            SharedType.FunctionType closedType tokenType
        , valueDeclaration "monoValue" closedType
        , valueDeclaration "monoPoly" closedScheme
        ]
    loaded <- runStableQuery loadedSession
        "instantiateLoadedAtMentionedClosedMonotype" "MonoResult"
    loadedRendered <- renderStableCandidates loaded
    assertBool
        ("a loaded polymorphic value was not instantiated at MonoClosed: "
            ++ show loadedRendered)
        $ any (\term -> all (`isInfixOf` term)
            ["monoPoly", "monoToToken", "monoValue"]) loadedRendered

    -- Closed candidates may come from the checked goal rather than a loaded
    -- monomorphic value. Pin both a result-only provider and an argument/result
    -- provider; the latter also carries a rank-N monotype through the same
    -- retained global scheme.
    let boxName = sharedName "MonoBox"
        boxKind = SharedKind.FunctionKind closedKind closedKind
        boxConstructor = SharedType.TypeConstructor boxName
        boxType element = SharedType.TypeApplication boxConstructor element
        boxDeclaration = SharedDeclaration.AbstractTypeDeclaration ()
            boxName boxKind
        defaultBoxScheme = SharedType.ForallType ["boxed"] [] $
            boxType $ SharedType.TypeVariable "boxed"
        sealedBoxScheme = SharedType.ForallType ["boxed"] [] $
            SharedType.FunctionType
                (SharedType.TypeVariable "boxed")
                (boxType $ SharedType.TypeVariable "boxed")
        implicitBoxScheme = SharedType.FunctionType
            (SharedType.TypeVariable "implicitBoxed")
            (boxType $ SharedType.TypeVariable "implicitBoxed")
        queryClosedConsumerScheme = SharedType.ForallType ["consumed"] [] $
            SharedType.FunctionType
                (boxType $ SharedType.TypeVariable "consumed")
                (indexedType $ SharedType.TypeVariable "consumed")
    defaultBoxSession <- sealDjinnSessionFrom stableSession $
        closedDeclarations ++ [boxDeclaration,
            valueDeclaration "defaultMonoBox" defaultBoxScheme]
    ambiguousTokenSession <- sealDjinnSessionFrom stableSession $
        closedDeclarations ++
        [ valueDeclaration "ambiguousMonoToken" $
            SharedType.ForallType ["chosen"] [] tokenType
        ]
    nominalEmptySession <- sealDjinnSessionFrom stableSession [ SharedDeclaration.DataTypeDeclaration () nominalEmptyName [] []
        , valueDeclaration "vacuousEmptyProvider" $
            SharedType.ForallType ["chosen"] [] nominalEmptyType
        ]
    prefixAmbiguousSession <- sealDjinnSessionFrom stableSession $
        closedDeclarations ++
        [ valueDeclaration "prefixAmbiguousMonoToken" $
            SharedType.ForallType ["hidden", "payload"] [] $
                SharedType.FunctionType
                    (SharedType.TypeVariable "payload") tokenType
        ]
    let higherKindName = sharedName "HigherKindConstructor"
        higherKindTripleName = sharedName "HigherKindTriple"
        higherOrderName = sharedName "HigherOrderConstructor"
        higherOrderBuilderName = sharedName "HigherOrderBuilder"
        higherKindArgumentName = sharedName "HigherKindArgument"
        higherKindType = SharedType.TypeConstructor higherKindName
        higherKindTripleType =
            SharedType.TypeConstructor higherKindTripleName
        partialHigherKindTriple = SharedType.TypeApplication
            higherKindTripleType closedType
        unaryKind = SharedKind.FunctionKind closedKind closedKind
        higherOrderKind =
            SharedKind.FunctionKind unaryKind closedKind
        higherOrderType = SharedType.TypeConstructor higherOrderName
        higherOrderBuilderType =
            SharedType.TypeConstructor higherOrderBuilderName
        partialHigherOrderBuilder = SharedType.TypeApplication
            higherOrderBuilderType closedType
        higherKindArgumentType =
            SharedType.TypeConstructor higherKindArgumentName
        mixedKindProvider = SharedType.ForallType ["f", "a", "hidden"] [] $
            SharedType.FunctionType
                (SharedType.TypeApplication
                    (SharedType.TypeVariable "f")
                    (SharedType.TypeVariable "a"))
                tokenType
    mixedKindSession <- sealDjinnSessionFrom stableSession $
        closedDeclarations ++
        [ SharedDeclaration.AbstractTypeDeclaration () higherKindName unaryKind
        , abstractClosed higherKindArgumentName
        , valueDeclaration "mixedKindAmbiguousMonoToken" mixedKindProvider
        ]
    vacuousHigherKindSession <- sealDjinnSessionFrom stableSession $
        closedDeclarations ++
        [ SharedDeclaration.AbstractTypeDeclaration () higherKindName $
            SharedKind.FunctionKind closedKind closedKind
        , SharedDeclaration.AbstractTypeDeclaration () higherKindTripleName $
            SharedKind.FunctionKind closedKind $
                SharedKind.FunctionKind closedKind $
                    SharedKind.FunctionKind closedKind closedKind
        , SharedDeclaration.AbstractTypeDeclaration () higherOrderName
            higherOrderKind
        , SharedDeclaration.AbstractTypeDeclaration () higherOrderBuilderName $
            SharedKind.FunctionKind closedKind higherOrderKind
        , valueDeclaration "vacuousHigherKindMonoToken" $
            SharedType.ForallType ["constructor"] [] tokenType
        , valueDeclaration "vacuousHigherKindsMonoToken" $
            SharedType.ForallType ["unary", "binary"] [] tokenType
        , valueDeclaration "vacuousHigherOrderMonoToken" $
            SharedType.ForallType ["higherOrder"] [] tokenType
        ]
    sealedBoxSession <- sealDjinnSessionFrom stableSession $
        closedDeclarations ++ [boxDeclaration,
            valueDeclaration "sealedMonoBox" sealedBoxScheme]
    implicitBoxSession <- sealDjinnSessionFrom stableSession $
        closedDeclarations ++ [boxDeclaration,
            valueDeclaration "implicitMonoBox" implicitBoxScheme]
    queryClosedCompositionSession <- sealDjinnSessionFrom stableSession $
        closedDeclarations ++
        [ boxDeclaration
        , valueDeclaration "consumeQueryClosedBox" queryClosedConsumerScheme
        ]

    -- The final additive plan carries the established loaded-scheme axioms as
    -- well as the new local family. Both providers must choose MonoClosed: the
    -- indexed result rules out self-instantiating either scheme at a quantified
    -- candidate, while the otherwise unused first argument puts the checked
    -- closed type in the query vocabulary.
    queryClosedComposition <- runStableQuery queryClosedCompositionSession
        "composeQueryClosedAndLoadedInstantiation" $
        "MonoClosed -> (forall a. MonoBox a) -> "
        ++ "MonoIndexed MonoClosed"
    queryClosedCompositionRendered <-
        renderStableCandidates queryClosedComposition
    assertBool
        ("query-local closed instantiation did not compose with a loaded " ++
            "scheme: " ++ show queryClosedCompositionRendered)
        $ any ("consumeQueryClosedBox" `isInfixOf`)
            queryClosedCompositionRendered

    -- A caller may supply a closed proper type justified by one exact loaded
    -- provider's originating environment. The quantified identity below does
    -- not occur in this goal or either provider scheme: only the evidence tail
    -- may produce that visible choice. The ordinary runner remains precisely
    -- the empty-evidence entrance.
    let quantifiedIdentity = SharedType.ForallType ["identityType"] [] $
            SharedType.FunctionType
                (SharedType.TypeVariable "identityType")
                (SharedType.TypeVariable "identityType")
        providerChoice providerName candidateType =
            SharedQuery.ProviderInstantiationCandidate
                { SharedQuery.providerInstantiationCandidateProvider =
                    sharedName providerName
                , SharedQuery.providerInstantiationCandidateType = candidateType
                }
        providerAssignment providerName arguments =
            SharedQuery.ProviderInstantiationAssignment
                { SharedQuery.providerInstantiationAssignmentProvider =
                    sharedName providerName
                , SharedQuery.providerInstantiationAssignmentArguments =
                    arguments
                }
        kindedProviderAssignment providerName arguments =
            SharedQuery.KindedProviderInstantiationAssignment
                { SharedQuery.kindedProviderInstantiationAssignmentProvider =
                    sharedName providerName
                , SharedQuery.kindedProviderInstantiationAssignmentArguments =
                    arguments
                }
        identityEvidence = providerChoice
            "ambiguousMonoToken" quantifiedIdentity
        identityAssignment = providerAssignment
            "ambiguousMonoToken" [quantifiedIdentity]
    evidenceTargetName <- expectShownRight $
        SharedName.mkIdentifier "instantiateFromProviderEvidence"
    evidenceRequest <- expectShownRight $ Djex.parseDjinnRequest
        ambiguousTokenSession defaultQueryOptions evidenceTargetName
        "provider-evidence.djinn" "MonoToken"
    evidenceBaseline <- expectShownRight $
        Djex.runDjinnQuery ambiguousTokenSession evidenceRequest
    explicitEmptyEvidence <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationCandidates
            ambiguousTokenSession [] evidenceRequest
    assertEqual "the empty provider-evidence runner changed Djinn results"
        evidenceBaseline explicitEmptyEvidence
    explicitEmptyAssignments <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationAssignments
            ambiguousTokenSession [] evidenceRequest
    assertEqual "the empty provider-assignment runner changed Djinn results"
        evidenceBaseline explicitEmptyAssignments
    explicitEmptyKindedAssignments <- expectShownRight $
        Djex.runDjinnQueryWithKindedInstantiationAssignments
            ambiguousTokenSession [] evidenceRequest
    assertEqual
        "the empty kinded provider-assignment runner changed Djinn results"
        evidenceBaseline explicitEmptyKindedAssignments
    evidenceBaselineRendered <- renderStableCandidates evidenceBaseline
    assertBool
        ("a quantified provider choice was invented without evidence: " ++
            show evidenceBaselineRendered)
        $ not $ any
            ("ambiguousMonoToken @(forall a0_0. a0_0 -> a0_0)" `isInfixOf`)
            evidenceBaselineRendered
    evidencedToken <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationCandidates
            ambiguousTokenSession [identityEvidence] evidenceRequest
    evidencedTokenRendered <- renderStableCandidates evidencedToken
    assertBool
        ("provider-local evidence did not retain its quantified choice: " ++
            show evidencedTokenRendered)
        $ any
            ("ambiguousMonoToken @(forall a0_0. a0_0 -> a0_0)" `isInfixOf`)
            evidencedTokenRendered
    assignedToken <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationAssignments
            ambiguousTokenSession [identityAssignment] evidenceRequest
    assignedTokenRendered <- renderStableCandidates assignedToken
    assertBool
        ("an exact provider assignment lost its quantified choice: " ++
            show assignedTokenRendered)
        $ any
            ("ambiguousMonoToken @(forall a0_0. a0_0 -> a0_0)" `isInfixOf`)
            assignedTokenRendered

    -- Constructor-field flow is strictly more precise than comparing the
    -- structural and nominal formulae wholesale.  Both correlated parameters
    -- below survive in fields, so the structural assignment may eliminate the
    -- box and recover MonoToken even though its nominal formula is opaque.
    let correlatedBoxName = sharedName "AssignedCorrelatedBox"
        correlatedConstructorName = sharedName "AssignedCorrelatedBoxValue"
        correlatedProviderName = "assignedCorrelatedProvider"
        selectedParameter =
            SharedDeclaration.TypeParameter "selectedParameter" Nothing
        hiddenParameter =
            SharedDeclaration.TypeParameter "hiddenParameter" Nothing
        correlatedBox left right = SharedType.TypeApplication
            (SharedType.TypeApplication
                (SharedType.TypeConstructor correlatedBoxName) left)
            right
        correlatedDeclaration = SharedDeclaration.DataTypeDeclaration ()
            correlatedBoxName [selectedParameter, hiddenParameter]
            [ SharedDeclaration.DataConstructor () correlatedConstructorName
                [ SharedType.TypeVariable "selectedParameter"
                , SharedType.TypeVariable "hiddenParameter"
                ]
            ]
        correlatedProviderScheme =
            SharedType.ForallType ["selected", "hidden"] [] $
                correlatedBox
                    (SharedType.TypeVariable "selected")
                    (SharedType.TypeVariable "hidden")
    correlatedSession <- sealDjinnSessionFrom stableSession $
        closedDeclarations ++
        [ correlatedDeclaration
        , valueDeclaration correlatedProviderName correlatedProviderScheme
        ]
    correlatedTarget <- expectShownRight $
        SharedName.mkIdentifier "useFaithfulCorrelatedAssignment"
    correlatedRequest <- expectShownRight $ Djex.parseDjinnRequest
        correlatedSession
        defaultQueryOptions
            { optionAlternatives = True
            , optionCutoff = 64
            }
        correlatedTarget
        "faithful-correlated-provider-assignment.djinn"
        "MonoToken"
    correlatedResult <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationAssignments correlatedSession
            [providerAssignment correlatedProviderName
                [tokenType, quantifiedIdentity]]
            correlatedRequest
    correlatedRendered <- renderStableCandidates correlatedResult
    assertBool
        ("a faithful correlated assignment was lost to nominal/structural " ++
            "formula inequality: " ++ show correlatedRendered)
        $ any (\term -> all (`isInfixOf` term)
            [ correlatedProviderName ++ " @MonoToken"
            , "@(forall a0_0. a0_0 -> a0_0)"
            ]) correlatedRendered
    correlatedScalarResult <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationCandidates correlatedSession
            [ providerChoice correlatedProviderName tokenType
            , providerChoice correlatedProviderName quantifiedIdentity
            ]
            correlatedRequest
    correlatedScalarRendered <-
        renderStableCandidates correlatedScalarResult
    assertBool
        ("a faithful scalar provider tuple was lost to structural fidelity " ++
            "checking: " ++ show correlatedScalarRendered)
        $ any (\term -> all (`isInfixOf` term)
            [ correlatedProviderName ++ " @MonoToken"
            , "@(forall a0_0. a0_0 -> a0_0)"
            ]) correlatedScalarRendered

    -- The priority plan exposes an exact vacuous choice before a bare provider
    -- can shadow it, but it must not replace the historical provider superset.
    -- This tuple pins a single proof which uses the same provider once through
    -- the external rank-N assignment and once through ordinary instantiation.
    mixedUseTarget <- expectShownRight $
        SharedName.mkIdentifier "composeExactAndOrdinaryProviderUses"
    mixedUseRequest <- expectShownRight $ Djex.parseDjinnRequest
        ambiguousTokenSession
        defaultQueryOptions
            { optionAlternatives = True
            , optionCutoff = 128
            }
        mixedUseTarget
        "mixed-provider-assignment.djinn" "(MonoToken, MonoToken)"
    mixedUse <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationAssignments ambiguousTokenSession
            [identityAssignment] mixedUseRequest
    mixedUseRendered <- renderStableCandidates mixedUse
    let exactUse =
            "ambiguousMonoToken @(forall a0_0. a0_0 -> a0_0)"
        compact = filter (`notElem` " \n\r\t")
        mixedProviderUse term =
            let rendered = compact term
                exact = compact exactUse
            in (("(" ++ exact ++ ",ambiguousMonoToken)")
                    `isInfixOf` rendered) ||
                (("(ambiguousMonoToken," ++ exact ++ ")")
                    `isInfixOf` rendered)
    assertBool
        ("exact and ordinary uses of one provider did not compose: " ++
            show mixedUseRendered)
        $ any mixedProviderUse mixedUseRendered

    -- Nominal-empty identity commits to the first premise of the exact empty
    -- type. The assignment specialization must therefore precede the ordinary
    -- vacuous provider scheme, or the only direct candidate is an
    -- uninstantiated provider name that its caller cannot elaborate.
    nominalEmptyTarget <- expectShownRight $
        SharedName.mkIdentifier "instantiateVacuousEmptyProvider"
    nominalEmptyRequest <- expectShownRight $ Djex.parseDjinnRequest
        nominalEmptySession defaultQueryOptions nominalEmptyTarget
        "provider-empty-assignment.djinn" "ProviderVoid"
    assignedNominalEmpty <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationAssignments nominalEmptySession
            [providerAssignment "vacuousEmptyProvider" [quantifiedIdentity]]
            nominalEmptyRequest
    assignedNominalEmptyRendered <-
        renderStableCandidates assignedNominalEmpty
    assertBool
        ("a vacuous nominal-empty provider shadowed its exact assignment: " ++
            show assignedNominalEmptyRendered)
        $ "vacuousEmptyProvider @(forall a0_0. a0_0 -> a0_0)"
            `elem` assignedNominalEmptyRendered
    let renamedQuantifiedIdentity =
            SharedType.ForallType ["renamedIdentity"] [] $
                SharedType.FunctionType
                    (SharedType.TypeVariable "renamedIdentity")
                    (SharedType.TypeVariable "renamedIdentity")
        renamedIdentityAssignment = providerAssignment
            "ambiguousMonoToken" [renamedQuantifiedIdentity]
    duplicateAssignedToken <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationAssignments
            ambiguousTokenSession
            [identityAssignment, renamedIdentityAssignment]
            evidenceRequest
    assertEqual "alpha-equivalent assignment vectors were not de-duplicated"
        assignedToken duplicateAssignedToken

    -- Two providers may erase to alpha-identical schemes. Evidence for the
    -- first still cannot specialize the second merely because their logical
    -- scheme atoms compare equal.
    localitySession <- sealDjinnSessionFrom ambiguousTokenSession
        [ valueDeclaration "sameSchemeWithoutEvidence" $
            SharedType.ForallType ["otherChoice"] [] tokenType
        ]
    localityToken <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationCandidates
            localitySession [identityEvidence] evidenceRequest
    localityRendered <- renderStableCandidates localityToken
    assertBool
        ("provider evidence was donated across an alpha-identical scheme: " ++
            show localityRendered)
        $ not $ any
            ("sameSchemeWithoutEvidence @(forall a0_0. a0_0 -> a0_0)"
                `isInfixOf`)
            localityRendered
    assignedLocalityToken <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationAssignments
            localitySession [identityAssignment] evidenceRequest
    assignedLocalityRendered <- renderStableCandidates assignedLocalityToken
    assertBool
        ("a complete assignment was donated to an alpha-identical provider: " ++
            show assignedLocalityRendered)
        $ not $ any
            ("sameSchemeWithoutEvidence @(forall a0_0. a0_0 -> a0_0)"
                `isInfixOf`)
            assignedLocalityRendered

    -- The evidence tail must extend the richest historical instantiation plan,
    -- not replace it.  The novel quantified choice specializes both the box and
    -- finisher providers, while the finisher's second argument independently
    -- requires the loaded carrier at MonoClosed.  A candidate containing all
    -- three globals therefore consumes both evidence channels in one checked
    -- proof.
    let novelQuantifiedChoice =
            SharedType.ForallType ["choiceLeft", "choiceRight"] [] $
                SharedType.FunctionType
                    (SharedType.TypeVariable "choiceLeft") $
                    SharedType.FunctionType
                        (SharedType.TypeVariable "choiceRight")
                        (SharedType.TypeVariable "choiceLeft")
        carrierName = sharedName "MonoCarrier"
        carrierConstructor = SharedType.TypeConstructor carrierName
        carrierType element =
            SharedType.TypeApplication carrierConstructor element
        carrierDeclaration = SharedDeclaration.AbstractTypeDeclaration ()
            carrierName boxKind
        historicalCarrierScheme =
            SharedType.ForallType ["historicalChoice"] [] $
                carrierType $ SharedType.TypeVariable "historicalChoice"
        mixedFinishScheme = SharedType.ForallType ["externalChoice"] [] $
            SharedType.FunctionType
                (boxType $ SharedType.TypeVariable "externalChoice") $
                SharedType.FunctionType
                    (carrierType closedType)
                    resultType
    mixedEvidenceEnvironment <- mkNeutralDjinnEnvironment $
        closedDeclarations ++
        [ boxDeclaration, carrierDeclaration
        , valueDeclaration "externalChoiceBox" defaultBoxScheme
        , valueDeclaration "historicalChoiceCarrier" historicalCarrierScheme
        , valueDeclaration "finishMixedEvidence" mixedFinishScheme
        ]
    mixedEvidenceSession <- expectShownRight $
        Djex.mkDjinnSession mixedEvidenceEnvironment
    mixedEvidenceTarget <- expectShownRight $
        SharedName.mkIdentifier "composeProviderAndLoadedEvidence"
    mixedEvidenceRequest <- expectShownRight $ Djex.parseDjinnRequest
        mixedEvidenceSession
        defaultQueryOptions
            { optionAlternatives = True
            , optionCutoff = 128
            }
        mixedEvidenceTarget
        "mixed-provider-evidence.djinn" "MonoResult"
    mixedEvidence <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationCandidates
            mixedEvidenceSession
            [ providerChoice "externalChoiceBox" novelQuantifiedChoice
            , providerChoice "finishMixedEvidence" novelQuantifiedChoice
            ]
            mixedEvidenceRequest
    mixedEvidenceRendered <- renderStableCandidates mixedEvidence
    assertBool
        ("provider-local and loaded instantiation evidence did not compose: " ++
            show mixedEvidenceRendered ++ "; progress: " ++ show
                (SharedSearch.batchProgress $
                    SharedQuery.resultSearch mixedEvidence))
        $ any (\term -> all (`isInfixOf` term)
            [ "finishMixedEvidence @(forall a0_0 a0_1. " ++
                "a0_0 -> a0_1 -> a0_0)"
            , "externalChoiceBox @(forall a0_0 a0_1. " ++
                "a0_0 -> a0_1 -> a0_0)"
            , "historicalChoiceCarrier"
            ]) mixedEvidenceRendered
    mixedAssignments <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationAssignments
            mixedEvidenceSession
            [ providerAssignment "externalChoiceBox" [novelQuantifiedChoice]
            , providerAssignment "finishMixedEvidence" [novelQuantifiedChoice]
            ]
            mixedEvidenceRequest
    mixedAssignmentsRendered <- renderStableCandidates mixedAssignments
    assertBool
        ("ordered assignments did not compose with historical evidence: " ++
            show mixedAssignmentsRendered ++ "; progress: " ++ show
                (SharedSearch.batchProgress $
                    SharedQuery.resultSearch mixedAssignments))
        $ any (\term -> all (`isInfixOf` term)
            [ "finishMixedEvidence @(forall a0_0 a0_1. " ++
                "a0_0 -> a0_1 -> a0_0)"
            , "externalChoiceBox @(forall a0_0 a0_1. " ++
                "a0_0 -> a0_1 -> a0_0)"
            , "historicalChoiceCarrier"
            ]) mixedAssignmentsRendered

    -- Candidate failures are independent of a parsed request's source: the
    -- evidence came from an external environment, not that source buffer.
    let expectCandidateFailure description supplied = case
            Djex.runDjinnQueryWithInstantiationCandidates
                ambiguousTokenSession supplied evidenceRequest of
          Left failure -> do
            assertEqual (description ++ " diagnostic code")
                (Just "DJEX_DJINN_CANDIDATE")
                (SharedDiagnostic.diagnosticCode failure)
            assertEqual (description ++ " source provenance")
                Nothing (SharedDiagnostic.diagnosticSource failure)
          Right result -> fail $ description ++ " was accepted: " ++ show result
    expectCandidateFailure "an open provider candidate"
        [providerChoice "ambiguousMonoToken" $ SharedType.TypeVariable "open"]
    expectCandidateFailure "a contextual provider candidate"
        [providerChoice "ambiguousMonoToken" $
            SharedType.ForallType ["constrained"]
                [Constraint (sharedName "Eq")
                    [SharedType.TypeVariable "constrained"]]
                (SharedType.FunctionType
                    (SharedType.TypeVariable "constrained")
                    (SharedType.TypeVariable "constrained"))]
    expectCandidateFailure "a higher-kinded provider candidate"
        [providerChoice "ambiguousMonoToken" $
            SharedType.TypeConstructor SharedName.listName]
    expectCandidateFailure "an unknown provider association"
        [providerChoice "missingProvider" quantifiedIdentity]
    expectCandidateFailure "an over-wide provider candidate list" $
        replicate
            (SharedQuery.maximumProviderInstantiationCandidates + 1)
            (error "provider candidate element forced before width rejection")

    -- Complete assignments have their own source-free failure boundary.  Both
    -- the outer list and every inner vector are observed only one cell beyond
    -- their bounds before any caller-owned element is entered.
    let expectAssignmentFailure description session request supplied = case
            Djex.runDjinnQueryWithInstantiationAssignments
                session supplied request of
          Left failure -> do
            assertEqual (description ++ " diagnostic code")
                (Just "DJEX_DJINN_ASSIGNMENT")
                (SharedDiagnostic.diagnosticCode failure)
            assertEqual (description ++ " source provenance")
                Nothing (SharedDiagnostic.diagnosticSource failure)
          Right result -> fail $ description ++ " was accepted: " ++ show result
        expectKindedAssignmentFailure description session request supplied = do
            outcome <- timeout 2000000 $ evaluate $
                Djex.runDjinnQueryWithKindedInstantiationAssignments
                    session supplied request
            case outcome of
              Nothing -> fail $ description ++ " did not terminate"
              Just (Left failure) -> do
                assertEqual (description ++ " diagnostic code")
                    (Just "DJEX_DJINN_ASSIGNMENT")
                    (SharedDiagnostic.diagnosticCode failure)
                assertEqual (description ++ " source provenance")
                    Nothing (SharedDiagnostic.diagnosticSource failure)
              Just (Right result) ->
                fail $ description ++ " was accepted: " ++ show result
        cyclicAssignments =
            error "assignment element forced before outer bound rejection" :
                cyclicAssignments
        cyclicArguments =
            error "assignment argument forced before inner bound rejection" :
                cyclicArguments
        cyclicKindedAssignments =
            error "kinded assignment forced before outer bound rejection" :
                cyclicKindedAssignments
        cyclicKindedArguments =
            error "kinded argument forced before inner bound rejection" :
                cyclicKindedArguments
        cyclicGroundKind = SharedKind.FunctionKind
            cyclicGroundKind SharedKind.ProperTypeKind
        cyclicKindedAssignment = kindedProviderAssignment
            "ambiguousMonoToken"
            [ ( cyclicGroundKind
              , error "paired type forced before cyclic kind rejection"
              )
            ]
        validKindedAssignment = kindedProviderAssignment
            "ambiguousMonoToken" [(closedKind, closedType)]
    expectAssignmentFailure "a cyclic provider assignment list"
        ambiguousTokenSession evidenceRequest cyclicAssignments
    expectAssignmentFailure "a cyclic provider argument vector"
        ambiguousTokenSession evidenceRequest
        [providerAssignment "ambiguousMonoToken" cyclicArguments]
    expectKindedAssignmentFailure "a cyclic kinded provider assignment list"
        ambiguousTokenSession evidenceRequest cyclicKindedAssignments
    expectKindedAssignmentFailure "a cyclic kinded provider argument vector"
        ambiguousTokenSession evidenceRequest
        [kindedProviderAssignment "ambiguousMonoToken"
            cyclicKindedArguments]
    expectKindedAssignmentFailure "a cyclic provider assignment kind"
        ambiguousTokenSession evidenceRequest [cyclicKindedAssignment]
    expectKindedAssignmentFailure
        "a cyclic kind before same-provider kind-vector comparison"
        ambiguousTokenSession evidenceRequest
        [validKindedAssignment, cyclicKindedAssignment]
    expectAssignmentFailure "an empty provider argument vector"
        ambiguousTokenSession evidenceRequest
        [providerAssignment "ambiguousMonoToken" []]
    expectAssignmentFailure "a wrong-arity provider argument vector"
        ambiguousTokenSession evidenceRequest
        [providerAssignment "ambiguousMonoToken" $
            replicate 2
                (error "argument forced before exact arity rejection")]
    expectAssignmentFailure "an open provider assignment argument"
        ambiguousTokenSession evidenceRequest
        [providerAssignment "ambiguousMonoToken"
            [SharedType.TypeVariable "openAssignment"]]
    let contextualAssignmentArgument =
            SharedType.ForallType ["constrainedAssignment"]
                [Constraint (sharedName "Eq")
                    [SharedType.TypeVariable "constrainedAssignment"]]
                (SharedType.FunctionType
                    (SharedType.TypeVariable "constrainedAssignment")
                    (SharedType.TypeVariable "constrainedAssignment"))
        contextualAssignment = providerAssignment
            "ambiguousMonoToken" [contextualAssignmentArgument]
    contextualAssignedToken <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationAssignments
            ambiguousTokenSession [contextualAssignment] evidenceRequest
    contextualAssignedRendered <- renderStableCandidates contextualAssignedToken
    assertBool
        ("an exact contextual assignment lost its specified polytype: " ++
            show contextualAssignedRendered)
        $ any
            (("ambiguousMonoToken @(forall a0_0. " ++
                "(Eq a0_0) => a0_0 -> a0_0)") `isInfixOf`)
            contextualAssignedRendered
    expectAssignmentFailure "an unknown-class contextual assignment argument"
        ambiguousTokenSession evidenceRequest
        [providerAssignment "ambiguousMonoToken"
            [SharedType.ForallType ["unknownClassArgument"]
                [Constraint (sharedName "MissingAssignmentClass")
                    [SharedType.TypeVariable "unknownClassArgument"]]
                (SharedType.TypeVariable "unknownClassArgument")]]
    expectAssignmentFailure "a higher-kinded provider assignment argument"
        ambiguousTokenSession evidenceRequest
        [providerAssignment "ambiguousMonoToken"
            [SharedType.TypeConstructor SharedName.listName]]

    -- A caller-retained ground kind can specialize a genuinely vacuous binder
    -- without changing the compatibility runner's Type default.  Keep a
    -- visible application in the result so acceptance cannot be confused with
    -- an ignored assignment.
    vacuousHigherKindTarget <- expectShownRight $
        SharedName.mkIdentifier "instantiateVacuousHigherKindAssignment"
    vacuousHigherKindRequest <- expectShownRight $ Djex.parseDjinnRequest
        vacuousHigherKindSession
        defaultQueryOptions
            { optionAlternatives = True
            , optionCutoff = 128
            }
        vacuousHigherKindTarget
        "vacuous-higher-kind-provider-assignment.djinn"
        "MonoToken"
    let constructorKind =
            SharedKind.FunctionKind closedKind closedKind
        vacuousHigherKindAssignment = kindedProviderAssignment
            "vacuousHigherKindMonoToken"
            [(constructorKind, higherKindType)]
        vacuousProperKindAssignment = kindedProviderAssignment
            "vacuousHigherKindMonoToken"
            [(closedKind, closedType)]
    vacuousHigherKindResult <- expectShownRight $
        Djex.runDjinnQueryWithKindedInstantiationAssignments
            vacuousHigherKindSession
            [vacuousHigherKindAssignment]
            vacuousHigherKindRequest
    vacuousHigherKindRendered <-
        renderStableCandidates vacuousHigherKindResult
    assertBool
        ("a vacuous higher-kinded assignment lost its visible application: " ++
            show vacuousHigherKindRendered)
        $ any
            ("vacuousHigherKindMonoToken @HigherKindConstructor" `isInfixOf`)
            vacuousHigherKindRendered
    expectAssignmentFailure
        "the compatibility runner's vacuous Type default"
        vacuousHigherKindSession vacuousHigherKindRequest
        [providerAssignment "vacuousHigherKindMonoToken" [higherKindType]]
    expectKindedAssignmentFailure
        "a proper argument at a caller-supplied higher kind"
        vacuousHigherKindSession vacuousHigherKindRequest
        [kindedProviderAssignment "vacuousHigherKindMonoToken"
            [(constructorKind, closedType)]]
    _ <- expectShownRight $
        Djex.runDjinnQueryWithKindedInstantiationAssignments
            vacuousHigherKindSession
            [vacuousProperKindAssignment]
            vacuousHigherKindRequest
    expectKindedAssignmentFailure
        "conflicting kind vectors for one provider"
        vacuousHigherKindSession vacuousHigherKindRequest
        [ vacuousHigherKindAssignment
        , vacuousProperKindAssignment
        ]

    -- Preserve a whole source-proved vector when multiple binders are vacuous.
    -- The second argument is a partially applied ternary constructor with two
    -- arrows remaining, so this also pins recursive kind checking and visible
    -- argument order beyond the unary case.
    let binaryConstructorKind =
            SharedKind.FunctionKind closedKind constructorKind
        vacuousHigherKindsAssignment = kindedProviderAssignment
            "vacuousHigherKindsMonoToken"
            [ (constructorKind, higherKindType)
            , (binaryConstructorKind, partialHigherKindTriple)
            ]
    vacuousHigherKindsResult <- expectShownRight $
        Djex.runDjinnQueryWithKindedInstantiationAssignments
            vacuousHigherKindSession
            [vacuousHigherKindsAssignment]
            vacuousHigherKindRequest
    vacuousHigherKindsRendered <-
        renderStableCandidates vacuousHigherKindsResult
    assertBool
        ("a multi-vacuous higher-kinded vector lost its partial constructor " ++
            "or positional order: " ++ show vacuousHigherKindsRendered)
        $ any
            (("vacuousHigherKindsMonoToken @HigherKindConstructor " ++
                "@(HigherKindTriple MonoClosed)") `isInfixOf`)
            vacuousHigherKindsRendered

    -- One exact provider may retain multiple independent source proofs at the
    -- same genuinely higher-order kind.  A duplicate of the first vector must
    -- not suppress the distinct partially applied alternative.
    let higherOrderAssignment argument = kindedProviderAssignment
            "vacuousHigherOrderMonoToken"
            [(higherOrderKind, argument)]
        firstHigherOrderAssignment = higherOrderAssignment higherOrderType
        secondHigherOrderAssignment =
            higherOrderAssignment partialHigherOrderBuilder
    higherOrderAlternatives <- expectShownRight $
        Djex.runDjinnQueryWithKindedInstantiationAssignments
            vacuousHigherKindSession
            [ firstHigherOrderAssignment
            , secondHigherOrderAssignment
            , firstHigherOrderAssignment
            ]
            vacuousHigherKindRequest
    higherOrderRendered <- renderStableCandidates higherOrderAlternatives
    mapM_
      (\expected ->
        assertEqual
          ("a distinct same-kind higher-order assignment was lost or " ++
              "duplicated: " ++ show higherOrderRendered)
          1
          (length $ filter (expected `isInfixOf`) higherOrderRendered))
        [ "vacuousHigherOrderMonoToken @HigherOrderConstructor"
        , "vacuousHigherOrderMonoToken @(HigherOrderBuilder MonoClosed)"
        ]

    let higherKindGoal = SharedType.FunctionType
            (SharedType.TypeApplication
                higherKindType higherKindArgumentType)
            tokenType
    higherKindTarget <- expectShownRight $
        SharedName.mkIdentifier "instantiateAtHigherKindAssignment"
    higherKindRequest <- expectShownRight $ Djex.parseDjinnRequest
        mixedKindSession
        defaultQueryOptions
            { optionAlternatives = True
            , optionCutoff = 128
            }
        higherKindTarget
        "higher-kind-provider-assignment.djinn"
        (SharedTypeRender.renderType id higherKindGoal)
    expectKindedAssignmentFailure
        "a supplied proper kind conflicting with the retained provider body"
        mixedKindSession higherKindRequest
        [kindedProviderAssignment "mixedKindAmbiguousMonoToken"
            [ (closedKind,
                error "argument forced before supplied-kind/body rejection")
            , (closedKind,
                error "argument forced before supplied-kind/body rejection")
            , (closedKind,
                error "argument forced before supplied-kind/body rejection")
            ]]
    let higherKindAssignment = providerAssignment
            "mixedKindAmbiguousMonoToken"
            [higherKindType, higherKindArgumentType, closedType]
        mixedKindAssignment = providerAssignment
            "mixedKindAmbiguousMonoToken"
            [higherKindType, higherKindArgumentType, quantifiedIdentity]
    higherKindAssigned <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationAssignments
            mixedKindSession [higherKindAssignment] higherKindRequest
    higherKindAssignedRendered <- renderStableCandidates higherKindAssigned
    assertBool
        ("a sound higher-kinded assignment was not retained: " ++
            show higherKindAssignedRendered)
        $ any
            (("mixedKindAmbiguousMonoToken @HigherKindConstructor " ++
                "@HigherKindArgument @MonoClosed") `isInfixOf`)
            higherKindAssignedRendered
    mixedKindAssigned <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationAssignments
            mixedKindSession [mixedKindAssignment] higherKindRequest
    mixedKindAssignedRendered <- renderStableCandidates mixedKindAssigned
    assertBool
        ("a mixed higher-kinded/impredicative assignment was not retained " ++
            "in order: " ++ show mixedKindAssignedRendered)
        $ any
            (("mixedKindAmbiguousMonoToken @HigherKindConstructor " ++
                "@HigherKindArgument @(forall a0_0. a0_0 -> a0_0)")
                    `isInfixOf`)
            mixedKindAssignedRendered
    expectAssignmentFailure
        "a proper type at a higher-kinded provider binder"
        mixedKindSession higherKindRequest
        [providerAssignment "mixedKindAmbiguousMonoToken"
            [closedType, higherKindArgumentType, quantifiedIdentity]]
    expectAssignmentFailure "an unknown assignment provider"
        ambiguousTokenSession evidenceRequest
        [providerAssignment "missingProvider" [quantifiedIdentity]]
    expectAssignmentFailure "a monomorphic assignment provider"
        loadedSession evidenceRequest
        [providerAssignment "monoValue" [quantifiedIdentity]]

    -- A complete four-binder vector can retain correlations beyond the old
    -- per-provider Cartesian prefix.  With four supplied candidate types the
    -- requested [q1,q2,q3,q4] tuple is Cartesian index 27 and therefore absent
    -- from the historical first-16 window; the assignment path consumes it
    -- directly and retains all four visible applications in source order.
    let quantifiedFirst = SharedType.ForallType ["first"] [] $
            SharedType.FunctionType
                (SharedType.TypeVariable "first")
                (SharedType.TypeVariable "first")
        quantifiedKeepFirst =
            SharedType.ForallType ["keepFirst", "discardSecond"] [] $
                SharedType.FunctionType
                    (SharedType.TypeVariable "keepFirst") $
                    SharedType.FunctionType
                        (SharedType.TypeVariable "discardSecond")
                        (SharedType.TypeVariable "keepFirst")
        quantifiedKeepSecond =
            SharedType.ForallType ["discardFirst", "keepSecond"] [] $
                SharedType.FunctionType
                    (SharedType.TypeVariable "discardFirst") $
                    SharedType.FunctionType
                        (SharedType.TypeVariable "keepSecond")
                        (SharedType.TypeVariable "keepSecond")
        quantifiedKeepOfThree = SharedType.ForallType
            ["keepOfThree", "middleOfThree", "lastOfThree"] [] $
                SharedType.FunctionType
                    (SharedType.TypeVariable "keepOfThree") $
                    SharedType.FunctionType
                        (SharedType.TypeVariable "middleOfThree") $
                        SharedType.FunctionType
                            (SharedType.TypeVariable "lastOfThree")
                            (SharedType.TypeVariable "keepOfThree")
        orderedArguments =
            [ quantifiedFirst
            , quantifiedKeepFirst
            , quantifiedKeepSecond
            , quantifiedKeepOfThree
            ]
        orderedScheme = SharedType.ForallType
            ["orderedFirst", "orderedSecond", "orderedThird", "orderedFourth"]
            [] tokenType
        orderedApplication =
            "orderedFourProvider @(forall a0_0. a0_0 -> a0_0)" ++
            " @(forall a0_0 a0_1. a0_0 -> a0_1 -> a0_0)" ++
            " @(forall a0_0 a0_1. a0_0 -> a0_1 -> a0_1)" ++
            " @(forall a0_0 a0_1 a0_2. " ++
                "a0_0 -> a0_1 -> a0_2 -> a0_0)"
        orderedSiblingApplication =
            "orderedFourSibling" ++
                drop (length "orderedFourProvider") orderedApplication
    orderedEnvironment <- mkNeutralDjinnEnvironment $
        closedDeclarations ++
        [ valueDeclaration "orderedFourProvider" orderedScheme
        , valueDeclaration "orderedFourSibling" orderedScheme
        ]
    orderedSession <- expectShownRight $ Djex.mkDjinnSession orderedEnvironment
    orderedTarget <- expectShownRight $
        SharedName.mkIdentifier "retainOrderedFourAssignment"
    orderedRequest <- expectShownRight $ Djex.parseDjinnRequest
        orderedSession
        defaultQueryOptions
            { optionAlternatives = True
            , optionCutoff = 128
            }
        orderedTarget "ordered-provider-assignment.djinn" "MonoToken"
    cartesianPrefix <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationCandidates
            orderedSession
            (map (providerChoice "orderedFourProvider") orderedArguments)
            orderedRequest
    cartesianPrefixRendered <- renderStableCandidates cartesianPrefix
    assertBool
        ("the regression tuple unexpectedly entered the old Cartesian prefix: " ++
            show cartesianPrefixRendered)
        $ not $ any (orderedApplication `isInfixOf`) cartesianPrefixRendered
    orderedResult <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationAssignments
            orderedSession
            [providerAssignment "orderedFourProvider" orderedArguments]
            orderedRequest
    orderedRendered <- renderStableCandidates orderedResult
    assertBool
        ("the exact four-argument assignment was not retained in order: " ++
            show orderedRendered)
        $ any (orderedApplication `isInfixOf`) orderedRendered
    assertBool
        ("the exact assignment leaked to a sibling provider: " ++
            show orderedRendered)
        $ not $ any (orderedSiblingApplication `isInfixOf`) orderedRendered

    defaultBox <- runStableQuery defaultBoxSession
        "instantiateLoadedResultProvider"
        "MonoBox MonoClosed"
    defaultBoxRendered <- renderStableCandidates defaultBox
    assertBool
        ("a result-only loaded scheme ignored the goal monotype: " ++
            show defaultBoxRendered)
        $ any ("defaultMonoBox" `isInfixOf`) defaultBoxRendered
    ambiguousToken <- runStableQuery ambiguousTokenSession
        "instantiateLoadedAmbiguousProvider"
        "MonoClosed -> MonoToken"
    ambiguousTokenRendered <- renderStableCandidates ambiguousToken
    assertBool
        ("a vacuous loaded scheme erased its selected goal monotype: " ++
            show ambiguousTokenRendered)
        $ any ("ambiguousMonoToken @MonoClosed" `isInfixOf`)
            ambiguousTokenRendered
    assertBool
        ("identical logical axioms collapsed distinct visible choices: " ++
            show ambiguousTokenRendered)
        $ any ("ambiguousMonoToken @MonoToken" `isInfixOf`)
            ambiguousTokenRendered
    ambiguousOpen <- runStableQuery ambiguousTokenSession
        "retainInferredAmbiguousProviderEvidence"
        "forall goal. goal -> MonoToken"
    ambiguousOpenRendered <- renderStableCandidates ambiguousOpen
    assertBool
        ("an open vacuous choice lost its explicit evidence: " ++
            show ambiguousOpenRendered)
        $ any ("ambiguousMonoToken @_" `isInfixOf`)
            ambiguousOpenRendered
    ambiguousRankN <- runStableQuery ambiguousTokenSession
        "instantiateLoadedAmbiguousProviderAtClosedRankN"
        "(forall selected. selected -> selected) -> MonoToken"
    ambiguousRankNRendered <- renderStableCandidates ambiguousRankN
    assertBool
        ("a closed quantified choice was downgraded to inferred evidence: " ++
            show ambiguousRankNRendered)
        $ any
            ("ambiguousMonoToken @(forall a0_0. a0_0 -> a0_0)"
                `isInfixOf`)
            ambiguousRankNRendered
    prefixAmbiguous <- runStableQuery prefixAmbiguousSession
        "retainShortestVisibleProviderPrefix"
        "MonoClosed -> MonoToken"
    prefixAmbiguousRendered <- renderStableCandidates prefixAmbiguous
    assertBool
        ("a leading vacuous binder was not selected explicitly: " ++
            show prefixAmbiguousRendered)
        $ any ("prefixAmbiguousMonoToken @MonoClosed" `isInfixOf`)
            prefixAmbiguousRendered
    assertBool
        ("a later inferable binder was selected visibly: " ++
            show prefixAmbiguousRendered)
        $ not $ any
            ("prefixAmbiguousMonoToken @MonoClosed @" `isInfixOf`)
            prefixAmbiguousRendered
    mixedKind <- runStableQuery mixedKindSession
        "retainMixedKindVisibleProviderPrefix" $
        SharedTypeRender.renderType id
            (SharedType.FunctionType
                (SharedType.TypeApplication
                    higherKindType higherKindArgumentType)
                tokenType)
    mixedKindRendered <- renderStableCandidates mixedKind
    assertBool
        ("higher-kinded prefix choices discarded vacuous evidence: " ++
            show mixedKindRendered)
        $ any ("mixedKindAmbiguousMonoToken @_ @_ @" `isInfixOf`)
            mixedKindRendered
    irrelevant <- runStableQuery defaultBoxSession
        "doNotRefuteIrrelevantLoadedScheme" "MonoResult"
    assertEqual "an irrelevant loaded scheme produced a candidate"
        [] $ SharedSearch.batchCandidates $ SharedQuery.resultSearch irrelevant
    assertEqual "an irrelevant retained scheme was ignored by evidence"
        SharedQuery.NoEvidence $ SharedQuery.resultEvidence irrelevant
    sealedBox <- runStableQuery sealedBoxSession "instantiateLoadedArrowProvider"
        "MonoClosed -> MonoBox MonoClosed"
    sealedBoxRendered <- renderStableCandidates sealedBox
    assertBool
        ("an explicit loaded scheme ignored the goal monotype: " ++
            show sealedBoxRendered)
        $ any ("sealedMonoBox" `isInfixOf`) sealedBoxRendered
    implicitBox <- runStableQuery implicitBoxSession
        "instantiateImplicitlyQuantifiedLoadedProvider"
        "MonoClosed -> MonoBox MonoClosed"
    implicitBoxRendered <- renderStableCandidates implicitBox
    assertBool
        ("an implicitly quantified loaded signature was not retained: " ++
            show implicitBoxRendered)
        $ any ("implicitMonoBox" `isInfixOf`) implicitBoxRendered
    let aliasName = sharedName "MonoClosedAlias"
        aliasDeclaration = SharedDeclaration.TypeSynonymDeclaration ()
            aliasName [] closedType
        aliasType = SharedType.TypeConstructor aliasName
    aliasBoxSession <- sealDjinnSessionFrom stableSession $
        closedDeclarations ++
        [ boxDeclaration
        , aliasDeclaration
        , valueDeclaration "monoAliasValue" aliasType
        , valueDeclaration "sealedAliasBox" sealedBoxScheme
        ]
    aliasBox <- runStableQuery aliasBoxSession
        "instantiateFromExpandedLoadedAlias" "MonoBox MonoClosed"
    aliasBoxRendered <- renderStableCandidates aliasBox
    assertBool
        ("a synonym-expanded loaded candidate was not discovered: " ++
            show aliasBoxRendered)
        $ any (\term -> all (`isInfixOf` term)
            ["sealedAliasBox", "monoAliasValue"]) aliasBoxRendered
    rankNBox <- runStableQuery sealedBoxSession
        "instantiateLoadedAtRankNCargo"
        $ "(forall x. x -> x) -> "
        ++ "MonoBox (forall x. x -> x)"
    rankNBoxRendered <- renderStableCandidates rankNBox
    assertBool
        ("a loaded scheme lost its guarded impredicative instance: " ++
            show rankNBoxRendered)
        $ any ("sealedMonoBox" `isInfixOf`) rankNBoxRendered

    -- One global occurrence is independently instantiated each time it is
    -- used. Duplicate restored proof names must therefore retain distinct
    -- internal premise identities until after proof checking.
    let familyName = sharedName "MonoFamily"
        leftName = sharedName "MonoLeft"
        rightName = sharedName "MonoRight"
        pairResultName = sharedName "MonoPairResult"
        familyType element = SharedType.TypeApplication
            (SharedType.TypeConstructor familyName) element
        makeScheme = SharedType.ForallType ["made"] [] $
            SharedType.FunctionType
                (SharedType.TypeVariable "made")
                (familyType $ SharedType.TypeVariable "made")
        finishType = SharedType.FunctionType
            (familyType $ SharedType.TypeConstructor leftName) $
            SharedType.FunctionType
                (familyType $ SharedType.TypeConstructor rightName)
                (SharedType.TypeConstructor pairResultName)
        familyDeclarations =
            [ SharedDeclaration.AbstractTypeDeclaration () familyName boxKind
            , abstractClosed leftName
            , abstractClosed rightName
            , abstractClosed pairResultName
            , valueDeclaration "monoLeft" $
                SharedType.TypeConstructor leftName
            , valueDeclaration "monoRight" $
                SharedType.TypeConstructor rightName
            , valueDeclaration "monoMake" makeScheme
            , valueDeclaration "monoFinish" finishType
            ]
    familySession <- sealDjinnSessionFrom stableSession familyDeclarations
    familyResult <- runStableQuery familySession
        "instantiateLoadedProviderTwice" "MonoPairResult"
    familyRendered <- renderStableCandidates familyResult
    assertBool
        ("one loaded scheme was not used at two monotypes: " ++
            show familyRendered)
        $ any (\term ->
            occurrenceCount "monoMake" term >= 2 &&
            all (`isInfixOf` term) ["monoFinish", "monoLeft", "monoRight"])
            familyRendered

    -- Candidate subtrees are not restricted to kind @Type@: a higher-kinded
    -- constructor is the required image here. Ill-kinded earlier tuples are
    -- discarded by checking the complete instantiated body, not by aborting
    -- the optional capability.
    let higherName = sharedName "MonoHigher"
        higherInputName = sharedName "MonoHigherInput"
        higherResultName = sharedName "MonoHigherResult"
        higherConstructor = SharedType.TypeConstructor higherName
        higherInput = SharedType.TypeConstructor higherInputName
        higherResult = SharedType.TypeConstructor higherResultName
        higherApplied = SharedType.TypeApplication higherConstructor higherInput
        higherConsumer = SharedType.ForallType ["constructor"] [] $
            SharedType.FunctionType
                (SharedType.TypeApplication
                    (SharedType.TypeVariable "constructor") higherInput)
                higherResult
    higherSession <- sealDjinnSessionFrom stableSession
        [ SharedDeclaration.AbstractTypeDeclaration () higherName boxKind
        , abstractClosed higherInputName
        , abstractClosed higherResultName
        , valueDeclaration "monoHigherValue" higherApplied
        , valueDeclaration "monoHigherConsumer" higherConsumer
        ]
    higher <- runStableQuery higherSession
        "instantiateLoadedHigherKindedBinder" "MonoHigherResult"
    higherRendered <- renderStableCandidates higher
    assertBool
        ("a higher-kinded closed candidate was not instantiated safely: " ++
            show higherRendered)
        $ any (\term -> all (`isInfixOf` term)
            ["monoHigherConsumer", "monoHigherValue"]) higherRendered

    -- Five leading binders now share the bounded instantiation route used by
    -- query-local hypotheses and exact provider evidence.  Every argument is
    -- selected together, so the resulting proof must retain the provider and
    -- all five loaded values.
    let fiveNames = map (sharedName . ("MonoFive" ++) . show)
            ([1 .. 5] :: [Int])
        fiveResultName = sharedName "MonoFiveResult"
        fiveVariables = map (("five" ++) . show) ([1 .. 5] :: [Int])
        fiveProviderType = SharedType.ForallType fiveVariables [] $
            foldr SharedType.FunctionType
                (SharedType.TypeConstructor fiveResultName)
                (map SharedType.TypeVariable fiveVariables)
        fiveDeclarations =
            map abstractClosed (fiveNames ++ [fiveResultName]) ++
            zipWith
                (\index name -> valueDeclaration ("monoFiveValue" ++ show index)
                    $ SharedType.TypeConstructor name)
                ([1 ..] :: [Int]) fiveNames ++
            [valueDeclaration "monoFiveProvider" fiveProviderType]
    fiveSession <- sealDjinnSessionFrom stableSession fiveDeclarations
    fiveLoaded <- runStableQuery fiveSession
        "instantiateFiveBinderLoadedScheme" "MonoFiveResult"
    fiveLoadedRendered <- renderStableCandidates fiveLoaded
    assertBool
        ("a five-binder loaded scheme was not instantiated: " ++
            show fiveLoadedRendered)
        $ any (\term -> all (`isInfixOf` term) $
            "monoFiveProvider" :
                map (("monoFiveValue" ++) . show) ([1 .. 5] :: [Int]))
            fiveLoadedRendered
    fiveAssignmentTarget <- expectShownRight $
        SharedName.mkIdentifier "retainFiveBinderAssignment"
    fiveAssignmentRequest <- expectShownRight $ Djex.parseDjinnRequest
        fiveSession defaultQueryOptions fiveAssignmentTarget
        "five-provider-assignment.djinn" "MonoFiveResult"
    fiveAssigned <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationAssignments
            fiveSession
            [providerAssignment "monoFiveProvider" $
                map SharedType.TypeConstructor fiveNames]
            fiveAssignmentRequest
    fiveAssignedRendered <- renderStableCandidates fiveAssigned
    assertBool
        ("an exact five-binder assignment was not retained: " ++
            show fiveAssignedRendered)
        $ any
            (("monoFiveProvider @MonoFive1 @MonoFive2 @MonoFive3 " ++
                "@MonoFive4 @MonoFive5") `isInfixOf`)
            fiveAssignedRendered

    -- Six leading binders use the same bounded route. This is the first
    -- successor case, so cover both loaded reconstruction and one exact
    -- assignment before moving the conservative boundary outward.
    let sixNames = map (sharedName . ("MonoSix" ++) . show)
            ([1 .. 6] :: [Int])
        sixResultName = sharedName "MonoSixResult"
        sixVariables = map (("six" ++) . show) ([1 .. 6] :: [Int])
        sixProviderType = SharedType.ForallType sixVariables [] $
            foldr SharedType.FunctionType
                (SharedType.TypeConstructor sixResultName)
                (map SharedType.TypeVariable sixVariables)
        sixDeclarations =
            map abstractClosed (sixNames ++ [sixResultName]) ++
            zipWith
                (\index name -> valueDeclaration ("monoSixValue" ++ show index)
                    $ SharedType.TypeConstructor name)
                ([1 ..] :: [Int]) sixNames ++
            [valueDeclaration "monoSixProvider" sixProviderType]
    sixSession <- sealDjinnSessionFrom stableSession sixDeclarations
    sixLoaded <- runStableQuery sixSession
        "instantiateSixBinderLoadedScheme" "MonoSixResult"
    sixLoadedRendered <- renderStableCandidates sixLoaded
    assertBool
        ("a six-binder loaded scheme was not instantiated: " ++
            show sixLoadedRendered)
        $ any (\term -> all (`isInfixOf` term) $
            "monoSixProvider" :
                map (("monoSixValue" ++) . show) ([1 .. 6] :: [Int]))
            sixLoadedRendered
    sixAssignmentTarget <- expectShownRight $
        SharedName.mkIdentifier "retainSixBinderAssignment"
    sixAssignmentRequest <- expectShownRight $ Djex.parseDjinnRequest
        sixSession defaultQueryOptions sixAssignmentTarget
        "six-provider-assignment.djinn" "MonoSixResult"
    sixAssigned <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationAssignments
            sixSession
            [providerAssignment "monoSixProvider" $
                map SharedType.TypeConstructor sixNames]
            sixAssignmentRequest
    sixAssignedRendered <- renderStableCandidates sixAssigned
    assertBool
        ("an exact six-binder assignment was not retained: " ++
            show sixAssignedRendered)
        $ any
            (("monoSixProvider @MonoSix1 @MonoSix2 @MonoSix3 " ++
                "@MonoSix4 @MonoSix5 @MonoSix6") `isInfixOf`)
            sixAssignedRendered

    -- Automatic directed instances can now use a retained wide source without
    -- an explicit vector. Its complete polytype is itself an available value,
    -- so impredicative self-application supplies all seven independent inputs.
    let sevenNames = map (sharedName . ("MonoSeven" ++) . show)
            ([1 .. 7] :: [Int])
        sevenResultName = sharedName "MonoSevenResult"
        sevenVariables = map (("seven" ++) . show) ([1 .. 7] :: [Int])
        sevenProviderType = SharedType.ForallType sevenVariables [] $
            foldr SharedType.FunctionType
                (SharedType.TypeConstructor sevenResultName)
                (map SharedType.TypeVariable sevenVariables)
        sevenDeclarations =
            map abstractClosed (sevenNames ++ [sevenResultName]) ++
            zipWith
                (\index name ->
                    valueDeclaration ("monoSevenValue" ++ show index) $
                        SharedType.TypeConstructor name)
                ([1 ..] :: [Int]) sevenNames ++
            [valueDeclaration "monoSevenProvider" sevenProviderType]
    sevenSession <- sealDjinnSessionFrom stableSession sevenDeclarations
    sevenLoaded <- runStableQueryWith
        firstCandidateOptions {optionBudget = Just 10000} sevenSession
        "instantiateSevenBinderLoadedScheme" "MonoSevenResult"
    assertBool "a directed seven-binder loaded scheme produced no candidate" $
        not $ null $ SharedSearch.batchCandidates $ SharedQuery.resultSearch sevenLoaded
    assertEqual "the directed wide instance lost positive evidence"
        SharedQuery.ValidatedCandidates $ SharedQuery.resultEvidence sevenLoaded
    sevenAssignmentTarget <- expectShownRight $
        SharedName.mkIdentifier "retainSevenBinderAssignment"
    sevenAssignmentRequest <- expectShownRight $ Djex.parseDjinnRequest
        sevenSession defaultQueryOptions sevenAssignmentTarget
        "seven-provider-assignment.djinn" "MonoSevenResult"
    sevenAssigned <- expectShownRight $
        Djex.runDjinnQueryWithInstantiationAssignments
        sevenSession
        [providerAssignment "monoSevenProvider" $
            map SharedType.TypeConstructor sevenNames]
        sevenAssignmentRequest
    sevenAssignedRendered <- renderStableCandidates sevenAssigned
    assertBool "an exact seven-binder assignment was absent" $
        any (("monoSevenProvider @MonoSeven1 @MonoSeven2 @MonoSeven3 " ++
                "@MonoSeven4 @MonoSeven5 @MonoSeven6 @MonoSeven7") `isInfixOf`)
            sevenAssignedRendered

    -- Four-binder chains remain practical under the existing per-scheme and
    -- per-query attempt caps. The generated evidence is still the original
    -- hypothesis occurrence; GHC performs its ordinary implicit instantiation.
    runStableIdentity stableSession "instantiateFourBinderRankN"
        $ "(forall a b c d. a -> b -> c -> d -> result) -> "
        ++ "w -> x -> y -> z -> result"
    let properKind = SharedKind.ProperTypeKind
        fourArgumentKind = foldr SharedKind.FunctionKind properKind $
            replicate 4 properKind
        fourArgumentConstructor =
            SharedDeclaration.AbstractTypeDeclaration ()
                (sharedName "RankNFour") fourArgumentKind
    fourBinderSession <- sealDjinnSessionFrom stableSession
        [fourArgumentConstructor]
    -- The abstract result cannot be synthesized structurally, so this pins
    -- the non-lexical source-order window rather than merely observing some
    -- other proof of an isomorphic tuple.
    runStableIdentity fourBinderSession "instantiateFourBinderInSourceOrder"
        $ "(forall a b c d. RankNFour a b c d) -> "
        ++ "RankNFour z y x w"
    runStableIdentity stableSession "instantiateFourBinderDiagonally"
        $ "(forall a b c d. a -> b -> c -> d -> (u, v, w, result)) -> "
        ++ "x -> (u, v, w, result)"
    runStableIdentity stableSession "instantiateFourBinderSparseOrder"
        $ "(forall p q r s. p -> q -> r -> s -> "
        ++ "((p, q, r, s), (a, b, c, d, e))) -> "
        ++ "a -> b -> c -> e -> ((a, b, c, e), (a, b, c, d, e))"
    let decoyArrows = concatMap ((++ " -> ") . ("t" ++) . show)
            ([1 .. 20] :: [Int])
    runStableIdentity fourBinderSession "instantiateFourBinderAfterDecoys"
        $ "(forall a b c d. RankNFour a b c d) -> "
        ++ decoyArrows ++ "RankNFour u u u u"

    -- Five-binder query-local chains use the same bounded fair scheduler.  The
    -- abstract result pins a non-lexical source-order tuple rather than an
    -- isomorphic structural proof.
    runStableIdentity stableSession "instantiateFiveBinderRankN"
        $ "(forall a b c d e. a -> b -> c -> d -> e -> result) -> "
        ++ "v -> w -> x -> y -> z -> result"
    let fiveArgumentKind = foldr SharedKind.FunctionKind properKind $
            replicate 5 properKind
        fiveArgumentConstructor =
            SharedDeclaration.AbstractTypeDeclaration ()
                (sharedName "RankNFive") fiveArgumentKind
    fiveBinderSession <- sealDjinnSessionFrom stableSession
        [fiveArgumentConstructor]
    runStableIdentity fiveBinderSession "instantiateFiveBinderInSourceOrder"
        $ "(forall a b c d e. RankNFive a b c d e) -> "
        ++ "RankNFive z y x w v"

    -- The fair wide scheduler is arity-generic, so six-binder query-local
    -- hypotheses retain both ordinary and non-lexical source-order uses.
    runStableIdentity stableSession "instantiateSixBinderRankN"
        $ "(forall a b c d e f. a -> b -> c -> d -> e -> f -> result) -> "
        ++ "u -> v -> w -> x -> y -> z -> result"
    let sixArgumentKind = foldr SharedKind.FunctionKind properKind $
            replicate 6 properKind
        sixArgumentConstructor =
            SharedDeclaration.AbstractTypeDeclaration ()
                (sharedName "RankNSix") sixArgumentKind
    sixBinderSession <- sealDjinnSessionFrom stableSession
        [sixArgumentConstructor]
    runStableIdentity sixBinderSession "instantiateSixBinderInSourceOrder"
        $ "(forall a b c d e f. RankNSix a b c d e f) -> "
        ++ "RankNSix z y x w v u"

    -- The historical Cartesian family still stops at six, but directed
    -- matching can use a longer hypothesis without enumerating its tuples.
    supported <- runStableQuery stableSession "sevenBinderDirectedRankN"
        $ "(forall a b c d e f g. "
        ++ "a -> b -> c -> d -> e -> f -> g -> result) -> "
        ++ "t -> u -> v -> w -> x -> y -> z -> result"
    assertBool "a seven-binder rank-N chain was not instantiated"
        $ not $ null $ SharedSearch.batchCandidates $ SharedQuery.resultSearch supported
    assertEqual "a synthesized longer chain did not retain positive evidence"
        SharedQuery.ValidatedCandidates $ SharedQuery.resultEvidence supported

    -- One occurrence-local opaque choice can now coexist with structural
    -- introduction at a sibling forall. This is the first compositional
    -- rank-N goal that neither former whole-query plan could inhabit.
    runStableIdentity stableSession "mixedRankNStrategies"
        "(forall a. a) -> ((forall b. b), (forall c. c -> c))"
    runStableIdentity stableSession "mixedNestedRankNStrategies"
        $ "(forall a. a) -> forall outer. "
        ++ "((forall b. b), outer -> outer)"

    -- Equal-looking sites keep distinct occurrence paths. With alternatives
    -- enabled, either result can transport the argument while its sibling is
    -- introduced structurally; collapsing the sites would lose one clause.
    duplicateSites <- expectRight $ inhabit
        defaultQueryOptions {optionAlternatives = True}
        emptyEnvironment [] "duplicateRankNSites"
        $ HTArrow (poly "input")
        $ HTTuple [poly "left", poly "right"]
    duplicateSiteClauses <- case reportOutcome duplicateSites of
        Realized clauses -> pure clauses
        outcome -> fail $ "duplicated rank-N sites failed: " ++ show outcome
    -- The historical four combinations of {opaque transport, structural
    -- introduction} per site remain, and the axiom plans add the guarded
    -- impredicative self-applications @a a@ at either or both sites.
    assertEqual "alpha-equal forall sites were not occurrence-distinct"
        9 $ length duplicateSiteClauses

    -- Definition expansion must retain the same occurrence identity. The
    -- synonym rearranges its parameters, and the datatype stores the two
    -- strategies in fields, so neither direct query-tree paths nor binder
    -- spelling alone can identify the selected opaque site.
    let flipBody = HTTuple [HTVar "second", HTVar "first"]
        flipType first second = HTApp
            (HTApp (HTCon "RankNFlip") first) second
        hybridResult = HTCon "RankNHybrid"
    hybridEnvironment <- expectRight $ do
        withFlip <- declare
            (TypeSynonym "RankNFlip" ["first", "second"] flipBody)
            standardEnvironment
        declare
            (DataType "RankNHybrid" []
                [("RankNHybrid", [emptyScheme "stored", poly "identity"])])
            withFlip
    assertRealized "rank-N strategy through a rearranging synonym"
        =<< expectRight (inhabit defaultQueryOptions hybridEnvironment []
            "mixedRankNSynonym" $ HTArrow (emptyScheme "input")
                $ flipType (poly "identity") (emptyScheme "output"))
    assertRealized "rank-N strategy through datatype fields"
        =<< expectRight (inhabit defaultQueryOptions hybridEnvironment []
            "mixedRankNDatatype" $ HTArrow (emptyScheme "input") hybridResult)

    -- The dual linear frontier opens one occurrence while retaining all of its
    -- independent siblings opaquely.  For three sites this completes the full
    -- choice cube without constructing a general power set.
    runStableIdentity stableSession "twoOpaqueRankNHoles"
        $ "(forall a. a) -> (forall b. b -> q) -> "
        ++ "((forall c. c), (forall d. d -> q), (forall e. e -> e))"

    -- Reaching a selected nested site must also open its enclosing forall.
    -- The two transport siblings remain opaque while both nodes on the nested
    -- structural branch open.
    runStableIdentity stableSession "nestedDualRankNFrontier"
        $ "(forall a. a) -> (forall b. b -> q) -> "
        ++ "((forall c. c), forall outer. "
        ++ "((forall d. d -> q), (forall e. e -> e)))"

    -- Four independent sites have a middle layer outside the two linear
    -- frontiers, but instantiable hypotheses now rescue this example: every
    -- transport component is derivable by instantiating a hypothesis at the
    -- opened siblings' skolems, so the appended axiom plans realize it.
    runStableIdentity stableSession "middleOpacityRankNGap"
        $ "(forall a. a) -> (forall b. b -> q) -> "
        ++ "((forall c. c), (forall d. d -> q), "
        ++ "(forall e. e -> e), (forall f. f -> f))"

    -- Seven-binder hypotheses stay beyond the instantiation-axiom bound, so
    -- this inhabitant specifically needs the pairwise frontier: two components
    -- use exact opaque transport while two sibling identities open
    -- structurally.
    runStableIdentity stableSession "wideMiddleOpacityRankNPair"
        $ "(forall a b c d e f g. (a, b, c, d, e, f, g)) -> "
        ++ "(forall s t u v w x y. (s, t, u, v, w, x, y) -> q) -> "
        ++ "((forall v w x y z u t. (v, w, x, y, z, u, t)), "
        ++ "(forall s t u v w x y. (s, t, u, v, w, x, y) -> q), "
        ++ "(forall e. e -> e), (forall f. f -> f))"

    -- The dual pairwise frontier is independently necessary at five sites:
    -- three schemes remain opaque while exactly two identities open. Together
    -- with the historical extremes and singleton frontiers, this completes
    -- every independent choice subset through five sites.
    runStableIdentity stableSession "dualWideMiddleOpacityRankNPair"
        $ "(forall a b c d e f g. (a, b, c, d, e, f, g)) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> q) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> r) -> "
        ++ "((forall v w x y z u t. (v, w, x, y, z, u, t)), "
        ++ "(forall v w x y z u t. (v, w, x, y, z, u, t) -> q), "
        ++ "(forall v w x y z u t. (v, w, x, y, z, u, t) -> r), "
        ++ "(forall e. e -> e), (forall f. f -> f))"

    -- Selecting two nested targets opens both of their required ancestor
    -- chains. The three wide siblings must remain exact, so neither a singleton
    -- plan nor a pair selection which forgets ancestry can inhabit this type.
    runStableIdentity stableSession "nestedWideMiddleOpacityRankNPair"
        $ "(forall a b c d e f g. (a, b, c, d, e, f, g)) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> q) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> r) -> "
        ++ "((forall v w x y z u t. (v, w, x, y, z, u, t)), "
        ++ "(forall v w x y z u t. (v, w, x, y, z, u, t) -> q), "
        ++ "(forall v w x y z u t. (v, w, x, y, z, u, t) -> r), "
        ++ "(forall outer. (outer -> outer, "
        ++ "forall inner. inner -> inner)), "
        ++ "(forall other. (other -> other, "
        ++ "forall deep. deep -> deep)))"

    -- The cubic frontier closes the first former pairwise gap. Seven-binder
    -- hypotheses stay beyond the instantiation-axiom bound, so three exact
    -- transports plus three structural identities specifically require a 3/3
    -- selection.
    runStableIdentity stableSession "sixSiteCentralOpacityRankNTriple"
        $ "(forall a b c d e f g. (a, b, c, d, e, f, g)) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> q) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> r) -> "
        ++ "((forall v w x y z u t. (v, w, x, y, z, u, t)), "
        ++ "(forall v w x y z u t. (v, w, x, y, z, u, t) -> q), "
        ++ "(forall v w x y z u t. (v, w, x, y, z, u, t) -> r), "
        ++ "(forall e. e -> e), (forall f. f -> f), "
        ++ "(forall g. g -> g))"

    -- At seven sites the dual triple frontier is independently necessary:
    -- four schemes remain exact while exactly three identities open. Together
    -- with the historical, singleton, and pair frontiers this completes every
    -- independent choice subset through seven sites.
    runStableIdentity stableSession "sevenSiteTripleOpenRankN"
        $ "(forall a b c d e f g. (a, b, c, d, e, f, g)) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> q) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> r) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> z) -> "
        ++ "((forall v w x y u t s. (v, w, x, y, u, t, s)), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> q), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> r), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> z), "
        ++ "(forall e. e -> e), (forall f. f -> f), "
        ++ "(forall g. g -> g))"

    -- Selecting three nested targets opens their shared enclosing forall as
    -- well. This reaches a four-open/four-opaque formula at eight recorded
    -- sites without adding an unrestricted fourth-order frontier.
    runStableIdentity stableSession "nestedTripleRankNFrontier"
        $ "(forall a b c d e f g. (a, b, c, d, e, f, g)) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> q) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> r) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> z) -> "
        ++ "((forall v w x y u t s. (v, w, x, y, u, t, s)), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> q), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> r), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> z), "
        ++ "(forall outer. ((forall e. e -> e), "
        ++ "(forall f. f -> f), (forall g. g -> g))))"

    -- The quartic frontier closes the next balanced gap. Seven-binder
    -- hypotheses remain beyond the instantiation-axiom bound, so four exact
    -- transports beside four structural identities specifically require a
    -- flat 4/4 selection.
    runStableIdentity stableSession "eightSiteCentralOpacityRankNQuartic"
        $ "(forall a b c d e f g. (a, b, c, d, e, f, g)) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> q) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> r) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> z) -> "
        ++ "((forall v w x y u t s. (v, w, x, y, u, t, s)), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> q), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> r), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> z), "
        ++ "(forall e. e -> e), (forall f. f -> f), "
        ++ "(forall g. g -> g), (forall h. h -> h))"

    -- At nine sites the dual quartic frontier is independently necessary:
    -- five schemes remain exact while exactly four identities open. Together
    -- with the earlier frontiers this completes every independent choice
    -- subset through nine sites.
    runStableIdentity stableSession "nineSiteQuarticOpenRankN"
        $ "(forall a b c d e f g. (a, b, c, d, e, f, g)) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> q) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> r) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> z) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> m) -> "
        ++ "((forall v w x y u t s. (v, w, x, y, u, t, s)), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> q), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> r), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> z), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> m), "
        ++ "(forall e. e -> e), (forall f. f -> f), "
        ++ "(forall g. g -> g), (forall h. h -> h))"

    -- Selecting four nested targets opens their shared enclosing forall as
    -- well. This reaches a five-open/five-opaque formula at ten recorded
    -- sites while leaving an independent 5/5 selection outside the quartic
    -- bound.
    runStableIdentity stableSession "nestedQuarticRankNFrontier"
        $ "(forall a b c d e f g. (a, b, c, d, e, f, g)) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> q) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> r) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> z) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> m) -> "
        ++ "((forall v w x y u t s. (v, w, x, y, u, t, s)), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> q), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> r), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> z), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> m), "
        ++ "(forall outer. ((forall e. e -> e), "
        ++ "(forall f. f -> f), (forall g. g -> g), "
        ++ "(forall h. h -> h))))"

    -- The bounded quintic tail closes the ten-site central layer. Five exact
    -- transports beside five structural identities specifically require a
    -- flat 5/5 selection. The final transport is separated from its first
    -- four siblings so this is not merely the first source-order quintuple.
    runFirstStableIdentity stableSession "tenSiteCentralOpacityRankNQuintic"
        $ "(forall a b c d e f g. (a, b, c, d, e, f, g)) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> q) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> r) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> z) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> m) -> "
        ++ "((forall v w x y u t s. (v, w, x, y, u, t, s)), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> q), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> r), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> z), "
        ++ "(forall e. e -> e), (forall f. f -> f), "
        ++ "(forall g. g -> g), (forall h. h -> h), "
        ++ "(forall i. i -> i), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> m))"

    -- At eleven independent sites the dual quintic layer is separately
    -- necessary: six schemes remain exact while five separated identity sites
    -- open. Together with the earlier layers this covers every subset through
    -- eleven sites.
    runFirstStableIdentity stableSession "elevenSiteQuintupleOpenRankN"
        $ "(forall a b c d e f g. (a, b, c, d, e, f, g)) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> q) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> r) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> z) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> m) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> n) -> "
        ++ "((forall e. e -> e), (forall f. f -> f), "
        ++ "(forall g. g -> g), (forall h. h -> h), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s)), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> q), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> r), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> z), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> m), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> n), "
        ++ "(forall i. i -> i))"

    -- Twelve independent sites expose the next omitted balanced layer. The
    -- demand-aware transport view retains the six supplied schemes and opens
    -- the six identity obligations without enumerating the missing 6/6 layer.
    sexticOpacityGap <- runStableQueryWith firstCandidateOptions stableSession
        "twelveSiteCentralOpacityRankNGap"
        $ "(forall a b c d e f g. (a, b, c, d, e, f, g)) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> q) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> r) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> z) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> m) -> "
        ++ "(forall a b c d e f g. (a, b, c, d, e, f, g) -> n) -> "
        ++ "((forall v w x y u t s. (v, w, x, y, u, t, s)), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> q), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> r), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> z), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> m), "
        ++ "(forall v w x y u t s. (v, w, x, y, u, t, s) -> n), "
        ++ "(forall e. e -> e), (forall f. f -> f), "
        ++ "(forall g. g -> g), (forall h. h -> h), "
        ++ "(forall i. i -> i), (forall j. j -> j))"
    assertBool "the transport view missed six independent exact schemes"
        $ not $ null $ SharedSearch.batchCandidates
            $ SharedQuery.resultSearch sexticOpacityGap

    -- Prepared global premises cache the same pairwise views as a goal.  The
    -- only route to the abstract result is to call this loaded consumer with
    -- two exact wide schemes and two structurally introduced identities.
    let wideValue = "(forall a b c d e f g. (a, b, c, d, e, f, g))"
        wideConsumer =
            "(forall s t u v w x y. (s, t, u, v, w, x, y) -> PairwisePremiseQ)"
        pairArgument = "(" ++ wideValue ++ ", " ++ wideConsumer
            ++ ", (forall e. e -> e), (forall f. f -> f))"
    pairConsumer <- expectRight $ parseHType
        $ pairArgument ++ " -> PairwisePremiseResult"
    pairGoal <- expectRight $ parseHType
        $ wideValue ++ " -> " ++ wideConsumer
        ++ " -> PairwisePremiseResult"
    pairEnvironment <- expectRight $ do
        withQ <- declare (AbstractType "PairwisePremiseQ" KStar)
            standardEnvironment
        withResult <- declare
            (AbstractType "PairwisePremiseResult" KStar) withQ
        declare (Function "consumePairwise" pairConsumer) withResult
    pairReport <- expectRight $ inhabit defaultQueryOptions pairEnvironment []
        "usePairwisePreparedPremise" pairGoal
    pairClauses <- case reportOutcome pairReport of
        Realized clauses -> pure clauses
        outcome -> fail $ "pairwise prepared premise failed: " ++ show outcome
    assertBool "the pairwise prepared premise was not used"
        $ any ("consumePairwise" `isInfixOf`) pairClauses

    -- Prepared global premises retain the cubic views too. The consumer needs
    -- three exact seven-binder values and three structurally introduced
    -- identities, so no historical or pairwise premise variant can call it.
    let wideConsumerR =
            "(forall s t u v w x y. (s, t, u, v, w, x, y) -> TriplePremiseR)"
        tripleArgument = "(" ++ wideValue ++ ", " ++ wideConsumer ++ ", "
            ++ wideConsumerR ++ ", (forall e. e -> e), "
            ++ "(forall f. f -> f), (forall g. g -> g))"
    tripleConsumer <- expectRight $ parseHType
        $ tripleArgument ++ " -> TriplePremiseResult"
    tripleGoal <- expectRight $ parseHType
        $ wideValue ++ " -> " ++ wideConsumer ++ " -> " ++ wideConsumerR
        ++ " -> TriplePremiseResult"
    tripleEnvironment <- expectRight $ do
        withQ <- declare (AbstractType "PairwisePremiseQ" KStar)
            standardEnvironment
        withR <- declare (AbstractType "TriplePremiseR" KStar) withQ
        withResult <- declare
            (AbstractType "TriplePremiseResult" KStar) withR
        declare (Function "consumeTriple" tripleConsumer) withResult
    tripleReport <- expectRight $ inhabit defaultQueryOptions tripleEnvironment []
        "useTriplePreparedPremise" tripleGoal
    tripleClauses <- case reportOutcome tripleReport of
        Realized clauses -> pure clauses
        outcome -> fail $ "triple prepared premise failed: " ++ show outcome
    assertBool "the triple prepared premise was not used"
        $ any ("consumeTriple" `isInfixOf`) tripleClauses

    -- Prepared global premises retain quartic views too. Four exact
    -- seven-binder values and four structurally introduced identities make the
    -- loaded consumer unavailable through every earlier premise variant.
    let wideConsumerZ =
            "(forall s t u v w x y. (s, t, u, v, w, x, y) -> QuarticPremiseZ)"
        quarticArgument = "(" ++ wideValue ++ ", " ++ wideConsumer ++ ", "
            ++ wideConsumerR ++ ", " ++ wideConsumerZ
            ++ ", (forall e. e -> e), (forall f. f -> f), "
            ++ "(forall g. g -> g), (forall h. h -> h))"
    quarticConsumer <- expectRight $ parseHType
        $ quarticArgument ++ " -> QuarticPremiseResult"
    quarticGoal <- expectRight $ parseHType
        $ wideValue ++ " -> " ++ wideConsumer ++ " -> " ++ wideConsumerR
        ++ " -> " ++ wideConsumerZ ++ " -> QuarticPremiseResult"
    quarticEnvironment <- expectRight $ do
        withQ <- declare (AbstractType "PairwisePremiseQ" KStar)
            standardEnvironment
        withR <- declare (AbstractType "TriplePremiseR" KStar) withQ
        withZ <- declare (AbstractType "QuarticPremiseZ" KStar) withR
        withResult <- declare
            (AbstractType "QuarticPremiseResult" KStar) withZ
        declare (Function "consumeQuartic" quarticConsumer) withResult
    quarticReport <- expectRight $ inhabit defaultQueryOptions
        quarticEnvironment [] "useQuarticPreparedPremise" quarticGoal
    quarticClauses <- case reportOutcome quarticReport of
        Realized clauses -> pure clauses
        outcome -> fail $ "quartic prepared premise failed: " ++ show outcome
    assertBool "the quartic prepared premise was not used"
        $ any ("consumeQuartic" `isInfixOf`) quarticClauses

    -- The fifth-order cached views remain available to reusable functions.
    -- Five exact schemes and five introduced identities make this consumer
    -- unreachable through any earlier premise variant.
    let wideConsumerM =
            "(forall s t u v w x y. (s, t, u, v, w, x, y) -> QuinticPremiseM)"
        quinticArgument = "(" ++ wideValue ++ ", " ++ wideConsumer ++ ", "
            ++ wideConsumerR ++ ", " ++ wideConsumerZ ++ ", "
            ++ "(forall e. e -> e), "
            ++ "(forall f. f -> f), (forall g. g -> g), "
            ++ "(forall h. h -> h), (forall i. i -> i), "
            ++ wideConsumerM ++ ")"
    quinticConsumer <- expectRight $ parseHType
        $ quinticArgument ++ " -> QuinticPremiseResult"
    quinticGoal <- expectRight $ parseHType
        $ wideValue ++ " -> " ++ wideConsumer ++ " -> " ++ wideConsumerR
        ++ " -> " ++ wideConsumerZ ++ " -> " ++ wideConsumerM
        ++ " -> QuinticPremiseResult"
    quinticEnvironment <- expectRight $ do
        withQ <- declare (AbstractType "PairwisePremiseQ" KStar)
            standardEnvironment
        withR <- declare (AbstractType "TriplePremiseR" KStar) withQ
        withZ <- declare (AbstractType "QuarticPremiseZ" KStar) withR
        withM <- declare (AbstractType "QuinticPremiseM" KStar) withZ
        withResult <- declare
            (AbstractType "QuinticPremiseResult" KStar) withM
        declare (Function "consumeQuintic" quinticConsumer) withResult
    quinticReport <- expectRight $ inhabit firstCandidateOptions
        quinticEnvironment [] "useQuinticPreparedPremise" quinticGoal
    quinticClauses <- case reportOutcome quinticReport of
        Realized clauses -> pure clauses
        outcome -> fail $ "quintic prepared premise failed: " ++ show outcome
    assertBool "the quintic prepared premise was not used"
        $ any ("consumeQuintic" `isInfixOf`) quinticClauses

    -- Goal and premise translation are separate skolem scopes. Reusing the
    -- same internal proposition for both would admit the ill-typed proof
    -- @\_ x -> consumePoly x@.
    let proper = SharedKind.ProperTypeKind
        constructor name = SharedType.TypeConstructor $ sharedName name
        abstract name = SharedDeclaration.AbstractTypeDeclaration ()
            (sharedName name) proper
        emptyPoly binder = SharedType.ForallType [binder] []
            $ SharedType.TypeVariable binder
        consumePoly = SharedDeclaration.ValueDeclaration $
            SharedDeclaration.ValueSignature () (sharedName "consumePoly") $
                SharedType.FunctionType (emptyPoly "a")
                    (constructor "RankNResult")
    scopedSession <- sealDjinnSessionFrom stableSession
        [abstract "RankNInput", abstract "RankNResult", consumePoly]
    scoped <- runStableQuery scopedSession "doNotCaptureRankNSkolem"
        "RankNInput -> (forall b. b -> RankNResult)"
    assertEqual "premise and goal forall skolems were accidentally shared"
        [] $ SharedSearch.batchCandidates $ SharedQuery.resultSearch scoped
    assertEqual "a complete polarized search lost its negative evidence"
        SharedQuery.ProvedUninhabitable $ SharedQuery.resultEvidence scoped

    -- Substituting the free alias parameter @a := r@ must freshen the bound
    -- @r@ before the quantified body is sealed. The same operation occurs in
    -- a datatype field, covering the declaration expansion path as well as a
    -- direct synonym application.
    let churchBody = church "r" $ HTVar "a"
        church binder element = HTForall [binder] []
            $ HTArrow
                (HTArrow element
                    $ HTArrow (HTVar binder) (HTVar binder))
                (HTArrow (HTVar binder) (HTVar binder))
        apply name argument = HTApp (HTCon name) argument
        explicitChurch = church "s" $ HTVar "r"
        definitions =
            [ ("Church", (["a"], churchBody, ()))
            , ("ChurchBox", (["a"], HTUnion
                [("ChurchBox", [apply "Church" $ HTVar "a"])], ()))
            ]
    substituted <- expectRight $ hTypeToFormula definitions
        $ apply "Church" $ HTVar "r"
    explicit <- expectRight $ hTypeToFormula [] explicitChurch
    assertEqual "synonym substitution under forall avoids capture"
        explicit substituted
    boxed <- expectRight $ hTypeToFormula definitions
        $ apply "ChurchBox" $ HTVar "r"
    assertEqual "datatype parameters reach quantified fields capture-safely"
        (Disj [(ConsDesc "ChurchBox" 1, Conj [explicit])]) boxed

    environment <- expectRight $ do
        withChurch <- declare
            (TypeSynonym "Church" ["a"] churchBody)
            standardEnvironment
        declare
            (DataType "ChurchBox" ["a"]
                [("ChurchBox", [apply "Church" $ HTVar "a"])])
            withChurch
    listReport <- expectRight $ inhabit defaultQueryOptions environment []
        "churches" $ HTArrow
            (list $ apply "Church" $ HTVar "r")
            (list explicitChurch)
    assertRealized "impredicative Church-list identity" listReport
    unboxReport <- expectRight $ inhabit defaultQueryOptions environment []
        "unboxChurch" $ HTArrow
            (apply "ChurchBox" $ HTVar "r") explicitChurch
    assertRealized "rank-N datatype field elimination" unboxReport
  where
    assertRealized description report = case reportOutcome report of
        Realized clauses -> assertBool
            (description ++ " produced no rendered candidate")
            $ not $ null clauses
        outcome -> fail $ description ++ " was not realized: " ++ show outcome

    firstCandidateOptions = defaultQueryOptions
        { optionAlternatives = False
        , optionSorted = False
        , optionCutoff = 1
        }

    runStableIdentity = runStableIdentityWith defaultQueryOptions

    runFirstStableIdentity = runStableIdentityWith firstCandidateOptions

    runStableIdentityWith options session targetSpelling source = do
        result <- runStableQueryWith options session targetSpelling source
        assertBool (targetSpelling ++ " produced no candidate")
            $ not $ null $ SharedSearch.batchCandidates
            $ SharedQuery.resultSearch result

    runStableQuery = runStableQueryWith defaultQueryOptions

    runStableQueryWith options session targetSpelling source = do
        target <- expectShownRight $ SharedName.mkIdentifier targetSpelling
        request <- expectShownRight $ Djex.parseDjinnRequest session
            options target (targetSpelling ++ ".djinn") source
        completed <- timeout 30000000 $ do
            result <- expectShownRight $ Djex.runDjinnQuery session request
            _ <- evaluate $ length $ SharedSearch.batchCandidates $
                SharedQuery.resultSearch result
            pure result
        maybe (fail $ targetSpelling ++ " exceeded the 30-second regression bound")
            pure completed

    renderStableCandidates result = mapM
        (expectShownRight . Djex.renderDjinnCandidateExpression
            SharedGenerated.Unqualified)
        $ SharedSearch.batchCandidates $ SharedQuery.resultSearch result

    occurrenceCount :: String -> String -> Int
    occurrenceCount needle = go
      where
        go [] = 0
        go source@(_ : suffix) =
            (if needle `isPrefixOf` source then 1 else 0) + go suffix

-- Recursive datatypes retain real constructor introduction in the bounded
-- positive projection. Recursive inputs and every recursive field below that
-- first layer remain opaque, so forwarding is available through the
-- complementary exact plan but case elimination and logical refutation are
-- deliberately withheld.
testRecursiveDataIntroduction :: IO ()
testRecursiveDataIntroduction = do
    let recursiveName = sharedName "RecursiveBox"
        doneName = sharedName "Done"
        againName = sharedName "Again"
        seedName = sharedName "RecursiveSeed"
        parameter = SharedDeclaration.TypeParameter "parameter" Nothing
        parameterType = SharedType.TypeVariable "parameter"
        recursive element = SharedType.TypeApplication
            (SharedType.TypeConstructor recursiveName) element
        polymorphic binder = SharedType.ForallType [binder] [] $
            SharedType.FunctionType
                (SharedType.FunctionType
                    (SharedType.TypeConstructor seedName)
                    (SharedType.TypeVariable binder))
                (SharedType.TypeVariable binder)
        recursiveDeclaration = SharedDeclaration.DataTypeDeclaration ()
            recursiveName [parameter]
            [ SharedDeclaration.DataConstructor () doneName [parameterType]
            , SharedDeclaration.DataConstructor () againName
                [recursive parameterType]
            ]
        seedDeclaration = SharedDeclaration.AbstractTypeDeclaration ()
            seedName SharedKind.ProperTypeKind
    environment <- mkNeutralDjinnEnvironment
        [seedDeclaration, recursiveDeclaration]
    session <- expectShownRight $ Djex.mkDjinnSession environment

    introduced <- run session "introduceRecursiveRankN" $
        SharedType.FunctionType (polymorphic "source")
            (recursive $ polymorphic "target")
    introducedSources <- renderCandidates introduced
    assertBool
        ("recursive constructor lost impredicative forwarding: "
            ++ show introducedSources)
        $ any (`elem` introducedSources) ["Done", "\\a -> Done a"]

    forwarded <- run session "forwardRecursive" $
        SharedType.FunctionType
            (recursive $ polymorphic "source")
            (recursive $ polymorphic "target")
    forwardedSources <- renderCandidates forwarded
    assertBool
        ("the exact recursive-opaque plan lost identity: "
            ++ show forwardedSources)
        $ "\\a -> a" `elem` forwardedSources

    eliminated <- run session "eliminateRecursive" $
        SharedType.FunctionType
            (recursive $ SharedType.TypeConstructor seedName)
            (SharedType.TypeConstructor seedName)
    assertUndecided "recursive elimination" eliminated

    seedless <- run session "seedlessRecursive" $
        recursive $ SharedType.TypeConstructor seedName
    assertUndecided "seedless recursive introduction" seedless

    sameComponentNested <- run session "sameComponentNested" $
        SharedType.FunctionType (SharedType.TypeConstructor seedName)
            (recursive $ recursive $ SharedType.TypeConstructor seedName)
    assertUndecided "same recursive component through a type argument"
        sameComponentNested

    let peirceA = SharedType.TypeVariable "a"
        peirceB = SharedType.TypeVariable "b"
        peirce = SharedType.FunctionType
            (SharedType.FunctionType
                (SharedType.FunctionType peirceA peirceB) peirceA)
            peirceA
    baselineEnvironment <- mkNeutralDjinnEnvironment [seedDeclaration]
    baselineSession <- expectShownRight $
        Djex.mkDjinnSession baselineEnvironment
    baselinePeirce <- run baselineSession "baselinePeirce" peirce
    unrelatedPeirce <- run session "unrelatedRecursivePeirce" peirce
    mapM_ (\(description, result) -> do
        assertEqual (description ++ " lost negative evidence")
            SharedQuery.ProvedUninhabitable $ SharedQuery.resultEvidence result
        assertEqual (description ++ " did not finish operationally")
            (SharedSearch.Completed SharedSearch.Finished)
            $ SharedSearch.batchProgress $ SharedQuery.resultSearch result)
        [ ("baseline Peirce search", baselinePeirce)
        , ("unrelated recursive SCC", unrelatedPeirce)
        ]

    let loopName = sharedName "Loop"
        loopType = SharedType.TypeConstructor loopName
        loopDeclaration = SharedDeclaration.DataTypeDeclaration () loopName []
            [SharedDeclaration.DataConstructor () (sharedName "MkLoop")
                [loopType]]
    loopEnvironment <- mkNeutralDjinnEnvironment [loopDeclaration]
    loopSession <- expectShownRight $ Djex.mkDjinnSession loopEnvironment
    loop <- run loopSession "seedlessLoop" loopType
    assertUndecided "cyclic-only recursive introduction" loop

    let evenName = sharedName "EvenLoop"
        oddName = sharedName "OddLoop"
        mutualAliasName = sharedName "MutualIdentity"
        mutualParameter = SharedDeclaration.TypeParameter "mutual" Nothing
        evenType = SharedType.TypeConstructor evenName
        oddType = SharedType.TypeConstructor oddName
        hiddenOddType = SharedType.TypeApplication
            (SharedType.TypeConstructor mutualAliasName) oddType
        mutualAliasDeclaration = SharedDeclaration.TypeSynonymDeclaration ()
            mutualAliasName [mutualParameter] $
                SharedType.TypeVariable "mutual"
        evenDeclaration = SharedDeclaration.DataTypeDeclaration () evenName []
            [SharedDeclaration.DataConstructor () (sharedName "ToEven")
                [hiddenOddType]]
        oddDeclaration = SharedDeclaration.DataTypeDeclaration () oddName []
            [ SharedDeclaration.DataConstructor () (sharedName "ToOdd")
                [evenType]
            , SharedDeclaration.DataConstructor () (sharedName "OddFromSeed")
                [SharedType.TypeConstructor seedName]
            ]
    mutualEnvironment <- mkNeutralDjinnEnvironment
        [ seedDeclaration
        , mutualAliasDeclaration
        , evenDeclaration
        , oddDeclaration
        ]
    mutualSession <- expectShownRight $ Djex.mkDjinnSession mutualEnvironment
    mutualIntroduced <- run mutualSession "introduceMutual" $
        SharedType.FunctionType oddType evenType
    mutualSources <- renderCandidates mutualIntroduced
    assertBool
        ("mutual recursion lost one-layer constructor introduction: "
            ++ show mutualSources)
        $ any (`elem` mutualSources) ["ToEven", "\\a -> ToEven a"]
    mutual <- run mutualSession "seedlessMutual" evenType
    assertUndecided "mutually recursive introduction" mutual
    mutualFromSeed <- run mutualSession "mutualFromSeed" $
        SharedType.FunctionType (SharedType.TypeConstructor seedName) evenType
    assertUndecided "same mutual component through a distinct head"
        mutualFromSeed

    -- Independent recursive components may each contribute one positive
    -- constructor layer.  Treating the first recursive head as a global path
    -- stop loses this finite inhabitant even though neither component is
    -- reopened.
    let innerName = sharedName "NestedInner"
        innerType = SharedType.TypeConstructor innerName
        innerBaseName = sharedName "InnerBase"
        innerAgainName = sharedName "InnerAgain"
        innerDeclaration = SharedDeclaration.DataTypeDeclaration ()
            innerName []
            [ SharedDeclaration.DataConstructor () innerBaseName []
            , SharedDeclaration.DataConstructor () innerAgainName [innerType]
            ]
        outerName = sharedName "NestedOuter"
        outerType = SharedType.TypeConstructor outerName
        outerFromInnerName = sharedName "OuterFromInner"
        outerAgainName = sharedName "OuterAgain"
        outerDeclaration = SharedDeclaration.DataTypeDeclaration ()
            outerName []
            [ SharedDeclaration.DataConstructor () outerFromInnerName
                [innerType]
            , SharedDeclaration.DataConstructor () outerAgainName [outerType]
            ]
    nestedEnvironment <- mkNeutralDjinnEnvironment
        [recursiveDeclaration, innerDeclaration, outerDeclaration]
    nestedSession <- expectShownRight $ Djex.mkDjinnSession nestedEnvironment
    nested <- run nestedSession "introduceNestedRecursive" outerType
    nestedSources <- renderCandidates nested
    assertBool
        ("independent recursive components did not compose one layer each: "
            ++ show nestedSources)
        $ "OuterFromInner InnerBase" `elem` nestedSources
    assertBool
        ("the outer recursive component reopened below its constructor layer: "
            ++ show nestedSources)
        $ not $ any ("OuterAgain" `isInfixOf`) nestedSources

    -- A query-side polymorphic observer mirrors the generic and impredicative
    -- occurrence shape used by clients such as Leant without supplying a
    -- result.  The payload premise must still pass through exactly one layer
    -- from each independent SCC; bounded instantiation must not turn the exact
    -- recursive fallback into a way to reopen either component.
    let nestedParameter =
            SharedDeclaration.TypeParameter "nestedParameter" Nothing
        nestedParameterType = SharedType.TypeVariable "nestedParameter"
        parameterInnerName = sharedName "ParameterInner"
        parameterInner element = SharedType.TypeApplication
            (SharedType.TypeConstructor parameterInnerName) element
        parameterInnerDeclaration = SharedDeclaration.DataTypeDeclaration ()
            parameterInnerName [nestedParameter]
            [ SharedDeclaration.DataConstructor ()
                (sharedName "ParameterInnerDone") [nestedParameterType]
            , SharedDeclaration.DataConstructor ()
                (sharedName "ParameterInnerAgain")
                [parameterInner nestedParameterType]
            ]
        parameterOuterName = sharedName "ParameterOuter"
        parameterOuter element = SharedType.TypeApplication
            (SharedType.TypeConstructor parameterOuterName) element
        parameterOuterDeclaration = SharedDeclaration.DataTypeDeclaration ()
            parameterOuterName [nestedParameter]
            [ SharedDeclaration.DataConstructor ()
                (sharedName "ParameterOuterWrap")
                [parameterInner nestedParameterType]
            , SharedDeclaration.DataConstructor ()
                (sharedName "ParameterOuterAgain")
                [parameterOuter nestedParameterType]
            ]
        polymorphicBottom binder = SharedType.ForallType [binder] [] $
            SharedType.TypeVariable binder
        observer = SharedType.ForallType ["observed"] [] $
            SharedType.FunctionType
                (parameterOuter $ SharedType.TypeVariable "observed")
                (SharedType.TypeConstructor seedName)
    parameterNestedEnvironment <- mkNeutralDjinnEnvironment
        [ seedDeclaration
        , parameterInnerDeclaration
        , parameterOuterDeclaration
        ]
    parameterNestedSession <- expectShownRight $
        Djex.mkDjinnSession parameterNestedEnvironment
    parameterNestedRankN <- run parameterNestedSession
        "introduceParameterNestedRankN" $
        SharedType.FunctionType observer $
            SharedType.FunctionType (polymorphicBottom "source") $
                parameterOuter $ polymorphicBottom "target"
    parameterNestedRankNSources <- renderCandidates parameterNestedRankN
    assertBool
        ("independent parameterized recursive components lost rank-N "
            ++ "construction: " ++ show parameterNestedRankNSources)
        $ any (\source ->
            "ParameterOuterWrap" `isInfixOf` source &&
            "ParameterInnerDone" `isInfixOf` source)
            parameterNestedRankNSources
    assertBool
        ("rank-N instantiation reopened the outer recursive component: "
            ++ show parameterNestedRankNSources)
        $ all (\source -> sum
            [ substringCount constructor source
            | constructor <-
                ["ParameterOuterWrap", "ParameterOuterAgain"]
            ] <= 1) parameterNestedRankNSources
    assertBool
        ("rank-N instantiation reopened the inner recursive component: "
            ++ show parameterNestedRankNSources)
        $ all (\source -> sum
            [ substringCount constructor source
            | constructor <-
                ["ParameterInnerDone", "ParameterInnerAgain"]
            ] <= 1) parameterNestedRankNSources

    parameterNested <- run nestedSession "introduceArgumentRecursive" $
        recursive innerType
    parameterNestedSources <- renderCandidates parameterNested
    assertBool
        ("a distinct recursive type argument lost its own layer: "
            ++ show parameterNestedSources)
        $ "Done InnerBase" `elem` parameterNestedSources

    -- A fixed total component-layer budget keeps duplicated independent
    -- recursion from expanding exponentially before the query's search budget
    -- can take effect.  The base remains deliberately beyond that boundary.
    let lastLayer = 12 :: Int
        layerName index = sharedName $ "RecursiveLayer" ++ show index
        layerType index = SharedType.TypeConstructor $ layerName index
        layerDeclaration index = SharedDeclaration.DataTypeDeclaration ()
            (layerName index) [] $
            if index == lastLayer
              then
                [ SharedDeclaration.DataConstructor ()
                    (sharedName "RecursiveLayerBase") []
                , SharedDeclaration.DataConstructor ()
                    (sharedName "RecursiveLayerLastAgain") [layerType index]
                ]
              else
                [ SharedDeclaration.DataConstructor ()
                    (sharedName $ "RecursiveLayerStep" ++ show index)
                    [layerType (index + 1), layerType (index + 1)]
                , SharedDeclaration.DataConstructor ()
                    (sharedName $ "RecursiveLayerAgain" ++ show index)
                    [layerType index]
                ]
    boundedEnvironment <- mkNeutralDjinnEnvironment
        [layerDeclaration index | index <- [0 .. lastLayer]]
    boundedSession <- expectShownRight $ Djex.mkDjinnSession boundedEnvironment
    bounded <- run boundedSession "boundRecursiveComponentChain" $
        layerType (0 :: Int)
    assertUndecided "recursive component layer budget" bounded
  where
    run session targetSpelling goal = do
        target <- expectShownRight $ SharedGenerated.mkDefinitionName $
            sharedName targetSpelling
        request <- expectShownRight $ Djex.mkDjinnRequest SharedQuery.QueryRequest
            { SharedQuery.requestTarget = target
            , SharedQuery.requestGoal = goal
            , SharedQuery.requestContexts = []
            , SharedQuery.requestOptions = defaultQueryOptions
            }
        expectShownRight $ Djex.runDjinnQuery session request

    renderCandidates result = mapM
        (expectShownRight . Djex.renderDjinnCandidateExpression
            SharedGenerated.Unqualified)
        $ SharedSearch.batchCandidates $ SharedQuery.resultSearch result

    assertUndecided description result = do
        assertEqual (description ++ " invented a candidate") []
            $ SharedSearch.batchCandidates $ SharedQuery.resultSearch result
        assertEqual (description ++ " produced unsound negative evidence")
            SharedQuery.NoEvidence $ SharedQuery.resultEvidence result
        assertEqual (description ++ " did not exhaust its bounded plans")
            (SharedSearch.Completed SharedSearch.Finished)
            $ SharedSearch.batchProgress $ SharedQuery.resultSearch result

    substringCount :: String -> String -> Int
    substringCount needle = go
      where
        go [] = 0
        go rest@(_ : suffix) =
            (if needle `isPrefixOf` rest then 1 else 0) + go suffix

-- A declared datatype normally lowers to its constructor sum, which is still
-- the primary Djinn search vocabulary. The complementary nominal projection
-- must retain the complete @MaybeLike argument@ atom long enough for guarded
-- impredicative instantiation to recover the direct Haskell transport. Both
-- projections remain observable: the nominal result is the source hypothesis
-- itself, while structural alternatives still introduce and eliminate the
-- declared constructors.
testNominalParametricDataPlans :: IO ()
testNominalParametricDataPlans = do
    let maybeName = sharedName "MaybeLike"
        nothingName = sharedName "NothingLike"
        justName = sharedName "JustLike"
        resultName = sharedName "NominalResult"
        finishName = sharedName "finish"
        parameter = SharedDeclaration.TypeParameter "parameter" Nothing
        parameterType = SharedType.TypeVariable "parameter"
        maybeType element = SharedType.TypeApplication
            (SharedType.TypeConstructor maybeName) element
        polymorphicIdentity binder = SharedType.ForallType [binder] [] $
            SharedType.FunctionType
                (SharedType.TypeVariable binder)
                (SharedType.TypeVariable binder)
        maybeDeclaration = SharedDeclaration.DataTypeDeclaration () maybeName
            [parameter]
            [ SharedDeclaration.DataConstructor () nothingName []
            , SharedDeclaration.DataConstructor () justName [parameterType]
            ]
        goal = SharedType.FunctionType
            (SharedType.ForallType ["element"] [] $
                maybeType $ SharedType.TypeVariable "element")
            (maybeType $ polymorphicIdentity "nested")
    session <- seal [maybeDeclaration]
    rendered <- runRendered session "transportMaybeLike" goal
    assertBool ("the nominal data family lost direct guarded instantiation: " ++
        show rendered)
        $ "\\a -> a" `elem` rendered
    assertBool "the nominal family replaced structural constructor search"
        $ any (\source ->
            "case " `isInfixOf` source &&
            "NothingLike" `isInfixOf` source &&
            "JustLike" `isInfixOf` source) rendered
    -- A loaded consumer catches the subtler case where structural and nominal
    -- goal formulas coincide: only the global premise differs. The local
    -- polymorphic value must be instantiated at the polytype already present
    -- under the consumer's nominal datatype application.
    let resultType = SharedType.TypeConstructor resultName
        resultDeclaration = SharedDeclaration.AbstractTypeDeclaration ()
            resultName SharedKind.ProperTypeKind
        finishDeclaration = SharedDeclaration.ValueDeclaration $
            SharedDeclaration.ValueSignature () finishName $
                SharedType.FunctionType
                    (maybeType $ polymorphicIdentity "accepted")
                    resultType
        finishGoal = SharedType.FunctionType
            (SharedType.ForallType ["supplied"] [] $
                maybeType $ SharedType.TypeVariable "supplied")
            resultType
    finishEnvironment <- mkNeutralDjinnEnvironment
        [resultDeclaration, maybeDeclaration, finishDeclaration]
    finishPrepared <- expectShownRight $
        RawEnvironment.prepareGroundSynthesisEnvironment finishEnvironment
    let (structuralPremises, _, _) =
            RawEnvironment.preparedEnvironmentPolarizedFunctionPremises
                finishPrepared
        (nominalPremises, _, _) =
            RawEnvironment.preparedEnvironmentNominalPolarizedFunctionPremises
                finishPrepared
    structuralGoal <- expectShownRight $
        RawEnvironment.preparedEnvironmentSynthesisFormulaTranslator
            finishPrepared finishGoal
    nominalGoal <- expectShownRight $
        RawEnvironment.preparedEnvironmentNominalSynthesisFormulaTranslator
            finishPrepared finishGoal
    assertEqual "the coincident loaded-consumer goal projections drifted"
        structuralGoal nominalGoal
    assertBool "the nominal global-premise cache reused structural formulas"
        $ structuralPremises /= nominalPremises
    finishSession <- expectShownRight $
        Djex.mkDjinnSession finishEnvironment
    finishRendered <- runRendered finishSession
        "finishNominalMaybeLike" finishGoal
    assertBool ("the nominal premise used a structurally compiled axiom: " ++
        show finishRendered)
        $ "\\a -> finish a" `elem` finishRendered
  where
    seal declarations = do
        environment <- mkNeutralDjinnEnvironment declarations
        expectShownRight $ Djex.mkDjinnSession environment

    runRendered session targetSpelling goal = do
        runRenderedWith defaultQueryOptions session targetSpelling goal

    runRenderedWith options session targetSpelling goal = do
        target <- expectShownRight $ SharedGenerated.mkDefinitionName $
            sharedName targetSpelling
        request <- expectShownRight $ Djex.mkDjinnRequest SharedQuery.QueryRequest
            { SharedQuery.requestTarget = target
            , SharedQuery.requestGoal = goal
            , SharedQuery.requestContexts = []
            , SharedQuery.requestOptions = options
            }
        result <- expectShownRight $ Djex.runDjinnQuery session request
        mapM
            (expectShownRight . Djex.renderDjinnCandidateExpression
                SharedGenerated.Unqualified)
            $ SharedSearch.batchCandidates $ SharedQuery.resultSearch result

-- The second compiler is intentionally narrow: only applications of
-- parametric data need their complete nominal shape preserved. A nullary data
-- declaration must keep its constructor formula, and an alias of a
-- parametric datatype must remain transparent in both projections.
testNominalDataProjectionBoundaries :: IO ()
testNominalDataProjectionBoundaries = do
    let flagName = sharedName "NominalFlag"
        offName = sharedName "NominalOff"
        onName = sharedName "NominalOn"
        flagType = SharedType.TypeConstructor flagName
        flagDeclaration = SharedDeclaration.DataTypeDeclaration () flagName []
            [ SharedDeclaration.DataConstructor () offName []
            , SharedDeclaration.DataConstructor () onName []
            ]
    flagEnvironment <- mkNeutralDjinnEnvironment [flagDeclaration]
    flagPrepared <- expectShownRight $
        RawEnvironment.prepareGroundSynthesisEnvironment flagEnvironment
    flagStructural <- translateStructural flagPrepared flagType
    flagNominal <- translateNominal flagPrepared flagType
    assertEqual "a nullary datatype acquired a redundant nominal projection"
        flagStructural flagNominal

    let dataName = sharedName "NominalData"
        constructorName = sharedName "NominalDataValue"
        aliasName = sharedName "NominalAlias"
        parameter = SharedDeclaration.TypeParameter "parameter" Nothing
        parameterType = SharedType.TypeVariable "parameter"
        dataType element = SharedType.TypeApplication
            (SharedType.TypeConstructor dataName) element
        aliasType element = SharedType.TypeApplication
            (SharedType.TypeConstructor aliasName) element
        dataDeclaration = SharedDeclaration.DataTypeDeclaration () dataName
            [parameter]
            [SharedDeclaration.DataConstructor () constructorName
                [parameterType]]
        aliasDeclaration = SharedDeclaration.TypeSynonymDeclaration ()
            aliasName [parameter] $ dataType parameterType
        polytype = SharedType.ForallType ["nested"] [] $
            SharedType.FunctionType
                (SharedType.TypeVariable "nested")
                (SharedType.TypeVariable "nested")
    aliasEnvironment <- mkNeutralDjinnEnvironment
        [dataDeclaration, aliasDeclaration]
    aliasPrepared <- expectShownRight $
        RawEnvironment.prepareGroundSynthesisEnvironment aliasEnvironment
    structuralData <- translateStructural aliasPrepared $ dataType polytype
    structuralAlias <- translateStructural aliasPrepared $ aliasType polytype
    nominalData <- translateNominal aliasPrepared $ dataType polytype
    nominalAlias <- translateNominal aliasPrepared $ aliasType polytype
    assertEqual "a structural datatype alias stopped expanding transparently"
        structuralData structuralAlias
    assertEqual "a nominal datatype alias stopped expanding transparently"
        nominalData nominalAlias
    assertBool "the parametric datatype lost its complementary projection"
        $ structuralData /= nominalData

    -- Exact provider assignments may use the structural projection only when
    -- every assigned datatype-argument flow survives constructor expansion.
    -- Check the correlated case explicitly: the first source argument must
    -- not hide an equal second source argument erased below a phantom
    -- parameter, including when that application is nested in a faithful
    -- wrapper.
    let phantomName = sharedName "FlowPhantom"
        phantomConstructorName = sharedName "FlowPhantomValue"
        mixedOneName = sharedName "MixedOneFlow"
        mixedOneConstructorName = sharedName "MixedOneFlowValue"
        mixedName = sharedName "MixedFlow"
        mixedConstructorName = sharedName "MixedFlowValue"
        wrapperName = sharedName "FlowWrapper"
        wrapperConstructorName = sharedName "FlowWrapperValue"
        faithfulSiblingsName = sharedName "FaithfulSiblingFlow"
        faithfulSiblingsConstructorName =
            sharedName "FaithfulSiblingFlowValue"
        correlatedName = sharedName "CorrelatedFlow"
        correlatedConstructorName = sharedName "CorrelatedFlowValue"
        emptyName = sharedName "FlowEmpty"
        hiddenParameter =
            SharedDeclaration.TypeParameter "hiddenParameter" Nothing
        hiddenParameterType = SharedType.TypeVariable "hiddenParameter"
        phantomType element = SharedType.TypeApplication
            (SharedType.TypeConstructor phantomName) element
        mixedOneType element = SharedType.TypeApplication
            (SharedType.TypeConstructor mixedOneName) element
        mixedType left right = SharedType.TypeApplication
            (SharedType.TypeApplication
                (SharedType.TypeConstructor mixedName) left)
            right
        wrapperType element = SharedType.TypeApplication
            (SharedType.TypeConstructor wrapperName) element
        faithfulSiblingsType element = SharedType.TypeApplication
            (SharedType.TypeConstructor faithfulSiblingsName) element
        correlatedType left right = SharedType.TypeApplication
            (SharedType.TypeApplication
                (SharedType.TypeConstructor correlatedName) left)
            right
        emptyType element = SharedType.TypeApplication
            (SharedType.TypeConstructor emptyName) element
        phantomDeclaration = SharedDeclaration.DataTypeDeclaration ()
            phantomName [parameter]
            [SharedDeclaration.DataConstructor () phantomConstructorName []]
        mixedOneDeclaration = SharedDeclaration.DataTypeDeclaration ()
            mixedOneName [parameter]
            [SharedDeclaration.DataConstructor () mixedOneConstructorName
                [parameterType, phantomType parameterType]]
        mixedDeclaration = SharedDeclaration.DataTypeDeclaration () mixedName
            [parameter, hiddenParameter]
            [SharedDeclaration.DataConstructor () mixedConstructorName
                [parameterType, phantomType hiddenParameterType]]
        wrapperDeclaration = SharedDeclaration.DataTypeDeclaration ()
            wrapperName [parameter]
            [SharedDeclaration.DataConstructor () wrapperConstructorName
                [parameterType]]
        faithfulSiblingsDeclaration =
            SharedDeclaration.DataTypeDeclaration ()
                faithfulSiblingsName [parameter]
                [ SharedDeclaration.DataConstructor ()
                    faithfulSiblingsConstructorName
                    [parameterType, wrapperType parameterType]
                ]
        correlatedDeclaration = SharedDeclaration.DataTypeDeclaration ()
            correlatedName [parameter, hiddenParameter]
            [SharedDeclaration.DataConstructor () correlatedConstructorName
                [parameterType, hiddenParameterType]]
        emptyDeclaration = SharedDeclaration.DataTypeDeclaration ()
            emptyName [parameter] []
        assignedVariable = SharedType.TypeVariable "assigned"
        hiddenVariable = SharedType.TypeVariable "hidden"
        higherVariable = SharedType.TypeVariable "higher"
    flowEnvironment <- mkNeutralDjinnEnvironment
        [ dataDeclaration
        , phantomDeclaration
        , mixedOneDeclaration
        , mixedDeclaration
        , wrapperDeclaration
        , faithfulSiblingsDeclaration
        , correlatedDeclaration
        , emptyDeclaration
        ]
    flowPrepared <- expectShownRight $
        RawEnvironment.prepareGroundSynthesisEnvironment flowEnvironment
    let retains binders arguments source = expectShownRight $
            RawEnvironment.preparedEnvironmentStructuralAssignmentFidelity
                flowPrepared binders arguments source
    faithfulFlow <- retains ["assigned"] [flagType] $
        dataType assignedVariable
    phantomFlow <- retains ["assigned"] [flagType] $
        phantomType assignedVariable
    mixedOneFlow <- retains ["assigned"] [flagType] $
        mixedOneType assignedVariable
    mixedFlow <- retains ["assigned"] [flagType] $
        mixedType assignedVariable assignedVariable
    nestedMixedFlow <- retains ["assigned"] [flagType] $
        wrapperType $ mixedType assignedVariable assignedVariable
    faithfulSiblingsFlow <- retains ["assigned"] [flagType] $
        faithfulSiblingsType assignedVariable
    correlatedFlow <- retains ["assigned", "hidden"] [flagType, polytype] $
        correlatedType assignedVariable hiddenVariable
    nestedAssignmentFlow <- retains ["assigned"]
        [phantomType flagType] assignedVariable
    higherKindedFlow <- retains ["higher"]
        [SharedType.TypeConstructor phantomName] $
        SharedType.TypeApplication higherVariable flagType
    vacuousPhantomFlow <- retains ["assigned"] [flagType] $
        phantomType flagType
    emptyFlow <- retains ["assigned"] [emptyType flagType] assignedVariable
    assertBool "a faithful constructor-field assignment was rejected"
        faithfulFlow
    assertBool "a wholly phantom assignment was retained" $ not phantomFlow
    assertBool
        "a faithful field masked an erased sibling field"
        $ not mixedOneFlow
    assertBool
        "a correlated first argument masked a phantom second argument"
        $ not mixedFlow
    assertBool
        "a faithful source wrapper masked a nested correlated phantom argument"
        $ not nestedMixedFlow
    assertBool
        "fully faithful sibling fields were rejected"
        faithfulSiblingsFlow
    assertBool "a correlated faithful assignment vector was rejected"
        correlatedFlow
    assertBool "erasure inside an exact assignment was retained"
        $ not nestedAssignmentFlow
    assertBool "an exact higher-kinded phantom head was retained"
        $ not higherKindedFlow
    assertBool "a wholly vacuous structural vector was rejected"
        vacuousPhantomFlow
    assertBool
        "a parameterized empty datatype lost its complete Empty identity"
        emptyFlow

    -- Result matching must specialize a provider before adding its domains.
    -- @bridge@ fixes @a := IntLike@, so the next frontier is @XLike IntLike@;
    -- retaining the unspecialized @XLike a@ would miss @producer@ and the
    -- parametric datatype in its domain.
    let intName = sharedName "IntLike"
        boxName = sharedName "BoxLike"
        xName = sharedName "XLike"
        bridgeName = sharedName "bridge"
        producerName = sharedName "producer"
        proper = SharedKind.ProperTypeKind
        unary = SharedKind.FunctionKind proper proper
        nominal name = SharedType.TypeConstructor name
        apply name argument = SharedType.TypeApplication
            (nominal name) argument
        intType = nominal intName
        bridgeDeclaration = SharedDeclaration.ValueDeclaration $
            SharedDeclaration.ValueSignature () bridgeName $
                SharedType.FunctionType
                    (apply xName parameterType)
                    (apply boxName parameterType)
        producerDeclaration = SharedDeclaration.ValueDeclaration $
            SharedDeclaration.ValueSignature () producerName $
                SharedType.FunctionType
                    (dataType polytype)
                    (apply xName intType)
        specializationDeclarations =
            [ SharedDeclaration.AbstractTypeDeclaration () intName proper
            , SharedDeclaration.AbstractTypeDeclaration () boxName unary
            , SharedDeclaration.AbstractTypeDeclaration () xName unary
            , dataDeclaration
            , bridgeDeclaration
            , producerDeclaration
            ]
        specializationGoal = apply boxName intType
    specializationEnvironment <- mkNeutralDjinnEnvironment
        specializationDeclarations
    specializationPrepared <- expectShownRight $
        RawEnvironment.prepareGroundSynthesisEnvironment
            specializationEnvironment
    assertBool "the nominal reachability slice lost result specialization"
        $ RawEnvironment.preparedEnvironmentQueryUsesParametricData
            specializationPrepared specializationGoal

    -- A datatype declaration is only a projection template. Without a loaded
    -- value whose positive result actually provides its owner, the flexible
    -- field parameter must not match an arbitrary rigid goal or insert nominal
    -- search ahead of the historical candidate stream.
    let unrelatedBoxName = sharedName "UnrelatedBox"
        unrelatedBoxConstructorName = sharedName "UnrelatedBoxValue"
        unrelatedBoxDeclaration = SharedDeclaration.DataTypeDeclaration ()
            unrelatedBoxName [parameter]
            [ SharedDeclaration.DataConstructor ()
                unrelatedBoxConstructorName [parameterType]
            ]
        rigidName = sharedName "UnrelatedRigid"
        rigidLeftName = sharedName "unrelatedRigidLeft"
        rigidRightName = sharedName "unrelatedRigidRight"
        rigidType = nominal rigidName
        rigidDeclaration = SharedDeclaration.AbstractTypeDeclaration ()
            rigidName proper
        rigidValue name = SharedDeclaration.ValueDeclaration $
            SharedDeclaration.ValueSignature () name rigidType
        rigidValues =
            [rigidValue rigidLeftName, rigidValue rigidRightName]
        rigidOptions = defaultQueryOptions
            { optionAlternatives = True
            , optionRanking = SharedQuality.LegacyCandidateRanking
            , optionSorted = False
            , optionCutoff = 10
            }
        runRigid environment = do
            session <- expectShownRight $ Djex.mkDjinnSession environment
            target <- expectShownRight $ SharedGenerated.mkDefinitionName $
                sharedName "selectUnrelatedRigid"
            request <- expectShownRight $ Djex.mkDjinnRequest
                SharedQuery.QueryRequest
                    { SharedQuery.requestTarget = target
                    , SharedQuery.requestGoal = rigidType
                    , SharedQuery.requestContexts = []
                    , SharedQuery.requestOptions = rigidOptions
                    }
            result <- expectShownRight $ Djex.runDjinnQuery session request
            rendered <- mapM
                (expectShownRight . Djex.renderDjinnCandidateExpression
                    SharedGenerated.Unqualified)
                $ SharedSearch.batchCandidates
                $ SharedQuery.resultSearch result
            pure (rendered, SharedSearch.batchProgress $
                SharedQuery.resultSearch result)
    baselineRigidEnvironment <- mkNeutralDjinnEnvironment $
        rigidDeclaration : rigidValues
    unrelatedDataEnvironment <- mkNeutralDjinnEnvironment $
        rigidDeclaration : unrelatedBoxDeclaration : rigidValues
    unrelatedPrepared <- expectShownRight $
        RawEnvironment.prepareGroundSynthesisEnvironment
            unrelatedDataEnvironment
    assertBool "an unreachable Box-like field activated nominal search" $
        not $ RawEnvironment.preparedEnvironmentQueryUsesParametricData
            unrelatedPrepared rigidType
    baselineRigid@(baselineRigidCandidates, _) <-
        runRigid baselineRigidEnvironment
    unrelatedRigid <- runRigid unrelatedDataEnvironment
    assertEqual "the rigid-prefix fixture lost its historical candidates"
        ["unrelatedRigidRight", "unrelatedRigidLeft"]
        baselineRigidCandidates
    assertEqual "an unreachable parametric datatype changed the rigid prefix"
        baselineRigid unrelatedRigid
  where
    translateStructural prepared = expectShownRight .
        RawEnvironment.preparedEnvironmentSynthesisFormulaTranslator prepared
    translateNominal prepared = expectShownRight .
        RawEnvironment.preparedEnvironmentNominalSynthesisFormulaTranslator
            prepared

-- A parametric datatype need not occur in the requested result. Backward
-- slicing from the closed result must reach its consumer, then enable the
-- nominal provider/instantiation chain without activating every unrelated
-- declaration in the sealed environment.
testNominalClosedGoalReachability :: IO ()
testNominalClosedGoalReachability = do
    let tokenName = sharedName "ClosedToken"
        resultName = sharedName "ClosedResult"
        phantomName = sharedName "ClosedPhantom"
        tokenValueName = sharedName "closedToken"
        polyName = sharedName "closedPoly"
        finishName = sharedName "closedFinish"
        parameter = SharedDeclaration.TypeParameter "parameter" Nothing
        nominal name = SharedType.TypeConstructor name
        phantom element = SharedType.TypeApplication
            (nominal phantomName) element
        polymorphicIdentity binder = SharedType.ForallType [binder] [] $
            SharedType.FunctionType
                (SharedType.TypeVariable binder)
                (SharedType.TypeVariable binder)
        tokenType = nominal tokenName
        resultType = nominal resultName
        declarations =
            [ SharedDeclaration.AbstractTypeDeclaration () tokenName
                SharedKind.ProperTypeKind
            , SharedDeclaration.AbstractTypeDeclaration () resultName
                SharedKind.ProperTypeKind
            , SharedDeclaration.DataTypeDeclaration () phantomName [parameter]
                []
            , SharedDeclaration.ValueDeclaration $
                SharedDeclaration.ValueSignature () tokenValueName tokenType
            , SharedDeclaration.ValueDeclaration $
                SharedDeclaration.ValueSignature () polyName $
                    SharedType.FunctionType tokenType $
                        SharedType.ForallType ["provided"] [] $
                            phantom $ SharedType.TypeVariable "provided"
            , SharedDeclaration.ValueDeclaration $
                SharedDeclaration.ValueSignature () finishName $
                    SharedType.FunctionType
                        (phantom $ polymorphicIdentity "accepted")
                        resultType
            ]
    environment <- mkNeutralDjinnEnvironment declarations
    prepared <- expectShownRight $
        RawEnvironment.prepareGroundSynthesisEnvironment environment
    assertBool "the closed goal did not reach its nominal consumer"
        $ RawEnvironment.preparedEnvironmentQueryUsesParametricData
            prepared resultType
    session <- expectShownRight $ Djex.mkDjinnSession environment
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $
        sharedName "useClosedNominalChain"
    request <- expectShownRight $ Djex.mkDjinnRequest SharedQuery.QueryRequest
        { SharedQuery.requestTarget = target
        , SharedQuery.requestGoal = resultType
        , SharedQuery.requestContexts = []
        , SharedQuery.requestOptions = defaultQueryOptions
        }
    result <- expectShownRight $ Djex.runDjinnQuery session request
    rendered <- mapM
        (expectShownRight . Djex.renderDjinnCandidateExpression
            SharedGenerated.Unqualified)
        $ SharedSearch.batchCandidates $ SharedQuery.resultSearch result
    assertEqual "the nominal chain must be the only non-empty inhabitant"
        ["closedFinish (closedPoly closedToken)"] $
            filter (not . isInfixOf " of {}") rendered

-- Aggregate eliminations can hide the relevant consumer from a closed goal.
-- Both a datatype field and a tuple element expose @D Poly -> Result@; the
-- backward slice must project that result, demand the aggregate provider, and
-- continue through @poly token@ without broadly enabling unrelated values.
testNominalAggregateProviderReachability :: IO ()
testNominalAggregateProviderReachability = do
    let tokenName = sharedName "AggregateToken"
        resultName = sharedName "AggregateResult"
        dataName = sharedName "AggregateEmpty"
        holderName = sharedName "AggregateHolder"
        holderConstructorName = sharedName "AggregateHolderValue"
        tokenValueName = sharedName "aggregateToken"
        polyName = sharedName "aggregatePoly"
        holderValueName = sharedName "aggregateHolder"
        tupleValueName = sharedName "aggregateTuple"
        parameter = SharedDeclaration.TypeParameter "parameter" Nothing
        nominal name = SharedType.TypeConstructor name
        dataType element = SharedType.TypeApplication
            (nominal dataName) element
        polymorphicIdentity binder = SharedType.ForallType [binder] [] $
            SharedType.FunctionType
                (SharedType.TypeVariable binder)
                (SharedType.TypeVariable binder)
        tokenType = nominal tokenName
        resultType = nominal resultName
        consumerType = SharedType.FunctionType
            (dataType $ polymorphicIdentity "accepted") resultType
        baseDeclarations =
            [ SharedDeclaration.AbstractTypeDeclaration () tokenName
                SharedKind.ProperTypeKind
            , SharedDeclaration.AbstractTypeDeclaration () resultName
                SharedKind.ProperTypeKind
            , SharedDeclaration.DataTypeDeclaration () dataName [parameter] []
            , SharedDeclaration.ValueDeclaration $
                SharedDeclaration.ValueSignature () tokenValueName tokenType
            , SharedDeclaration.ValueDeclaration $
                SharedDeclaration.ValueSignature () polyName $
                    SharedType.FunctionType tokenType $
                        SharedType.ForallType ["provided"] [] $
                            dataType $ SharedType.TypeVariable "provided"
            ]
        holderDeclaration =
            SharedDeclaration.DataTypeDeclaration () holderName []
                [ SharedDeclaration.DataConstructor () holderConstructorName
                    [consumerType]
                ]
        holderDeclarations =
            [ holderDeclaration
            , SharedDeclaration.ValueDeclaration $
                SharedDeclaration.ValueSignature () holderValueName $
                    nominal holderName
            ]
        tupleDeclarations =
            [ SharedDeclaration.ValueDeclaration $
                SharedDeclaration.ValueSignature () tupleValueName $
                    SharedType.TupleType SharedName.Boxed
                        [consumerType, tokenType]
            ]
        usesAll fragments source =
            all (`isInfixOf` source) fragments &&
                not (" of {}" `isInfixOf` source)
        localHolderGoal = SharedType.FunctionType
            (nominal holderName) resultType
        runAggregate targetSpelling additions goal expectedFragments = do
            environment <- mkNeutralDjinnEnvironment $
                baseDeclarations ++ additions
            prepared <- expectShownRight $
                RawEnvironment.prepareGroundSynthesisEnvironment environment
            assertBool (targetSpelling ++
                " did not activate nominal aggregate reachability") $
                RawEnvironment.preparedEnvironmentQueryUsesParametricData
                    prepared goal
            session <- expectShownRight $ Djex.mkDjinnSession environment
            target <- expectShownRight $ SharedGenerated.mkDefinitionName $
                sharedName targetSpelling
            request <- expectShownRight $ Djex.mkDjinnRequest
                SharedQuery.QueryRequest
                    { SharedQuery.requestTarget = target
                    , SharedQuery.requestGoal = goal
                    , SharedQuery.requestContexts = []
                    , SharedQuery.requestOptions = defaultQueryOptions
                    }
            result <- expectShownRight $ Djex.runDjinnQuery session request
            rendered <- mapM
                (expectShownRight . Djex.renderDjinnCandidateExpression
                    SharedGenerated.Unqualified)
                $ SharedSearch.batchCandidates
                $ SharedQuery.resultSearch result
            assertBool
                (targetSpelling ++
                    " did not synthesize its non-empty aggregate path: " ++
                    show rendered)
                $ any (usesAll expectedFragments) rendered
    runAggregate "useAggregateHolder" holderDeclarations resultType
        [ "case aggregateHolder of"
        , "AggregateHolderValue"
        , "aggregatePoly aggregateToken"
        ]
    runAggregate "useAggregateTuple" tupleDeclarations resultType
        ["aggregateTuple", "aggregatePoly aggregateToken"]
    runAggregate "useLocalAggregateHolder" [holderDeclaration]
        localHolderGoal
        [ "\\a ->"
        , "case a of"
        , "AggregateHolderValue"
        , "aggregatePoly aggregateToken"
        ]

-- The polarized plan constructs either Church projection, while only the
-- alpha-opaque plan can reuse the exact loaded polytype. Alternative search
-- must retain all three without granting either plan its own cutoff budget.
testComplementaryRankNPlans :: IO ()
testComplementaryRankNPlans = do
    let token = HTCon "Token"
        churchChoice binder = HTForall [binder] [] $
            HTArrow (HTVar binder) $
                HTArrow (HTVar binder) (HTVar binder)
        churchType binder = HTArrow token $ churchChoice binder
        polyIdentity binder = HTForall [binder] [] $
            HTArrow (HTVar binder) (HTVar binder)
        identityType binder = HTArrow token $ polyIdentity binder
        goal = churchType "answer"
        unsortedOptions = defaultQueryOptions {
            optionAlternatives = True,
            optionSorted = False,
            optionCutoff = 20
            }
        sortedOptions = unsortedOptions {
            optionAlternatives = False,
            optionSorted = True
            }
    environment <- expectRight $ do
        withToken <- declare (AbstractType "Token" KStar) emptyEnvironment
        declare (Function "church" $ churchType "result") withToken

    -- Relevance is true here because the goal transports a parametric data
    -- value. The exact opaque Church provider belongs to a later historical
    -- structural frontier; it must consume the cutoff before the complementary
    -- nominal family can transport the data argument directly.
    let orderingData element = HTApp (HTCon "OrderingData") element
        polymorphicData binder = HTForall [binder] [] $
            orderingData $ HTVar binder
        orderingGoal = HTArrow (polymorphicData "input") $ HTTuple
            [ orderingData $ polyIdentity "stored"
            , goal
            ]
    orderingEnvironment <- expectRight $ do
        withToken <- declare (AbstractType "Token" KStar) emptyEnvironment
        withData <- declare
            (DataType "OrderingData" ["element"]
                [("OrderingDataValue", [])])
            withToken
        declare (Function "orderingChurch" $ churchType "provided")
            withData
    structuralPrefixReport <- run unsortedOptions {optionCutoff = 7}
        "orderNominalAfterStructuralFrontier" orderingEnvironment orderingGoal
    structuralPrefix <- realizedClauses
        "parametric structural-frontier prefix" structuralPrefixReport
    assertEqual "the low cutoff lost a historical structural frontier"
        3 $ length structuralPrefix
    assertBool "the exact structural provider moved behind nominal search"
        $ any ("(OrderingDataValue, orderingChurch)" `isInfixOf`)
            structuralPrefix
    assertBool "nominal search was inserted before the structural prefix ended"
        $ all (not . isInfixOf "(a, \\b -> orderingChurch b)")
            structuralPrefix

    nominalThresholdReport <- run unsortedOptions {optionCutoff = 13}
        "orderNominalAfterStructuralFrontier" orderingEnvironment orderingGoal
    nominalThreshold <- realizedClauses
        "nominal search after structural frontier" nominalThresholdReport
    assertEqual "nominal search changed the historical candidate prefix"
        structuralPrefix $ take (length structuralPrefix) nominalThreshold
    assertBool "the nominal candidate did not follow the structural frontier"
        $ any ("(a, \\b -> orderingChurch b)" `isInfixOf`)
            nominalThreshold

    -- The appended instantiation-axiom plans add two eta-distinct provider
    -- applications to the historical three-candidate union. Fully eta-normal
    -- comparison removes their compact/expanded duplicates without rewriting
    -- whichever checked spelling appeared first.
    complete <- run
        unsortedOptions {optionCutoff = 60} "allRankNPlans" environment goal
    allClauses <- realizedClauses "complementary rank-N plans" complete
    assertEqual "the plan union lost or duplicated a candidate"
        5 $ length allClauses
    assertEqual "the plan union repeated a generated candidate"
        allClauses $ nub allClauses
    assertBool "the opaque church candidate disappeared behind polarized hits"
        $ any ("church" `isInfixOf`) allClauses

    sorted <- run sortedOptions "rankAllPlansOnce" environment goal
    sortedClauses <- realizedClauses "globally ranked rank-N plans" sorted
    case sortedClauses of
        firstClause : _ -> assertBool
            "plans were ranked separately before concatenation"
            $ "church" `isInfixOf` firstClause
        [] -> fail "globally ranked rank-N plans produced no candidates"

    firstOnly <- run
        unsortedOptions {
            optionAlternatives = False,
            optionSorted = False
            }
        "firstRankNPlan" environment goal
    firstClauses <- realizedClauses "first-only rank-N plan" firstOnly
    assertEqual "first-only search did not short-circuit on a polarized hit"
        1 $ length firstClauses
    assertBool "first-only search unexpectedly entered the opaque plan"
        $ all (not . isInfixOf "church") firstClauses

    limited <- run
        unsortedOptions {optionCutoff = 4}
        "boundAllRankNPlans" environment goal
    limitedClauses <- realizedClauses "globally bounded rank-N plans" limited
    assertEqual "global raw-proof accounting changed the distinct union"
        3 $ length limitedClauses
    assertBool "the bounded opaque plan did not retain its first candidate"
        $ any ("church" `isInfixOf`) limitedClauses
    assertEqual "the opaque plan incorrectly received a fresh cutoff"
        (SharedSearch.truncated SharedSearch.CandidateLimitReached)
        $ reportCompletion limited

    -- Consuming the limit exactly is not proof that later plans are empty.
    -- A zero-allowance probe must still discover their first raw proof and
    -- report truncation without admitting another candidate.
    exactlyLimitedEnvironment <- expectRight $ do
        withToken <- declare (AbstractType "Token" KStar) emptyEnvironment
        declare (Function "polyIdentity" $ identityType "result") withToken
    exactlyLimited <- run
        unsortedOptions {optionCutoff = 1}
        "exactlyBoundRankNPlans" exactlyLimitedEnvironment
        $ identityType "answer"
    exactlyLimitedClauses <- realizedClauses
        "exactly bounded rank-N plans" exactlyLimited
    assertEqual "the exact cutoff admitted a later-plan candidate"
        1 $ length exactlyLimitedClauses
    assertBool "the zero-allowance probe admitted its provider candidate"
        $ all (not . isInfixOf "polyIdentity") exactlyLimitedClauses
    assertEqual "an unsearched later rank-N plan was reported as complete"
        (SharedSearch.truncated SharedSearch.CandidateLimitReached)
        $ reportCompletion exactlyLimited

    -- Existing plans retain their prefix, and the appended dual-frontier plan
    -- receives only the global cutoff remainder.  The exact provider consumes
    -- the sole allowance; probing the later structural proof must report
    -- truncation without admitting it as a second candidate.
    let emptyPoly binder = HTForall [binder] [] $ HTVar binder
        rankNQ = HTCon "RankNQ"
        emptyToQ binder = HTForall [binder] [] $
            HTArrow (HTVar binder) rankNQ
        dualGoal = HTArrow (emptyPoly "input") $
            HTArrow (emptyToQ "consumer") $
            HTTuple
                [ emptyPoly "output"
                , emptyToQ "producer"
                , polyIdentity "identity"
                ]
    dualPlanEnvironment <- expectRight $ do
        withQ <- declare (AbstractType "RankNQ" KStar) emptyEnvironment
        declare (Function "dualProvider" dualGoal) withQ
    dualCutoff <- run
        unsortedOptions {optionCutoff = 1}
        "boundDualFrontier" dualPlanEnvironment dualGoal
    dualCutoffClauses <- realizedClauses
        "globally bounded dual-frontier plans" dualCutoff
    assertEqual "the appended plan received a fresh candidate cutoff"
        1 $ length dualCutoffClauses
    assertBool "the historical exact provider lost its result prefix"
        $ any ("dualProvider" `isInfixOf`) dualCutoffClauses
    assertEqual "a zero-allowance dual-frontier probe looked complete"
        (SharedSearch.truncated SharedSearch.CandidateLimitReached)
        $ reportCompletion dualCutoff

    -- Choice-point fuel is global too.  Earlier plans consume enough of this
    -- budget to stop before the final direct construction; resetting the
    -- budget for that appended plan would incorrectly admit the construction.
    dualBudgeted <- run
        unsortedOptions {optionBudget = Just 60}
        "budgetDualFrontier" dualPlanEnvironment dualGoal
    dualBudgetedClauses <- realizedClauses
        "choice-bounded dual-frontier plans" dualBudgeted
    assertBool "choice-bounded dual-frontier search found no prefix"
        $ not $ null dualBudgetedClauses
    assertBool "the appended plan received a fresh choice budget"
        $ all ("dualProvider" `isInfixOf`) dualBudgetedClauses
    assertEqual "exhausted dual-frontier choice fuel looked complete"
        (SharedSearch.truncated SharedSearch.ChoicePointLimitReached)
        $ reportCompletion dualBudgeted

    dualGenerous <- run
        unsortedOptions {optionBudget = Just 1000}
        "completeDualFrontier" dualPlanEnvironment dualGoal
    dualGenerousClauses <- realizedClauses
        "fully funded dual-frontier plans" dualGenerous
    assertBool "the appended plan stayed unreachable with sufficient fuel"
        $ any (not . isInfixOf "dualProvider") dualGenerousClauses

    budgeted <- run
        unsortedOptions {optionBudget = Just 9}
        "budgetAllRankNPlans" environment goal
    budgetedClauses <- realizedClauses
        "choice-bounded rank-N plans" budgeted
    assertEqual "sharing choice fuel changed the complementary candidate union"
        3 $ length budgetedClauses
    assertBool "the opaque plan did not receive the polarized remainder"
        $ any ("church" `isInfixOf`) budgetedClauses
    assertEqual "the opaque plan incorrectly received a fresh choice budget"
        (SharedSearch.truncated SharedSearch.ChoicePointLimitReached)
        $ reportCompletion budgeted

    -- Premise views coexist in one proof environment. The first parameter
    -- needs exact opaque transport while the second is constructed under a
    -- fresh skolem; a whole-premise strategy cannot use @consume@ this way.
    let result = HTCon "RankNResult"
        consumeType = HTArrow (emptyPoly "a") $
            HTArrow (polyIdentity "b") result
        mixedPremiseGoal = HTArrow (emptyPoly "x") result
    mixedPremiseEnvironment <- expectRight $ do
        withResult <- declare
            (AbstractType "RankNResult" KStar) emptyEnvironment
        declare (Function "consume" consumeType) withResult
    mixedPremise <- run unsortedOptions
        "mixedPremiseRankNPlans" mixedPremiseEnvironment mixedPremiseGoal
    mixedPremiseClauses <- realizedClauses
        "occurrence-local premise plans" mixedPremise
    assertBool "no mixed premise candidate used consume"
        $ any ("consume" `isInfixOf`) mixedPremiseClauses

    -- The cached dual frontier is needed when one provider consumes two exact
    -- rank-N transports and one structurally introduced polymorphic value.
    -- Compiling only the goal's new views would leave this query unsupported.
    let dualConsumeType = HTArrow (emptyPoly "a") $
            HTArrow (emptyToQ "b") $
            HTArrow (polyIdentity "c") result
        dualPremiseGoal = HTArrow (emptyPoly "x") $
            HTArrow (emptyToQ "y") result
    dualPremiseEnvironment <- expectRight $ do
        withResult <- declare
            (AbstractType "RankNResult" KStar) emptyEnvironment
        withQ <- declare (AbstractType "RankNQ" KStar) withResult
        declare (Function "consumeDual" dualConsumeType) withQ
    dualPremise <- run unsortedOptions
        "dualPremiseRankNPlans" dualPremiseEnvironment dualPremiseGoal
    dualPremiseClauses <- realizedClauses
        "dual-frontier premise plans" dualPremise
    assertBool "no cached dual-frontier candidate used consumeDual"
        $ any ("consumeDual" `isInfixOf`) dualPremiseClauses

    -- Alternate aliases are appended after every declaration's primary view.
    -- Interleaving one function's variants before the next primary would
    -- perturb the historical depth-first result prefix and finite budgets.
    let orderedEnvironment = RawEnvironment.Environment
            [ ("RankNResult", ([], HTAbstract "RankNResult" KStar, KStar))
            , ("RankNQ", ([], HTAbstract "RankNQ" KStar, KStar))
            ]
            [ ("variantFirst", dualConsumeType)
            , ("directSecond", result)
            ]
            []
    orderedPrepared <- expectShownRight $ prepareEnvironment orderedEnvironment
    let (orderedPremises, _, _) =
            RawEnvironment.preparedEnvironmentPolarizedFunctionPremises
                orderedPrepared
    assertEqual "premise variants displaced a later primary declaration"
        [Symbol "variantFirst", Symbol "directSecond"]
        $ map fst $ take 2 orderedPremises
    let opaqueOrderedPremises =
            RawEnvironment.preparedEnvironmentFunctionPremises orderedPrepared
        variantFormulas =
            [ formula
            | (Symbol name, formula) <- orderedPremises
            , name == "variantFirst"
            ]
    case (opaqueOrderedPremises, variantFormulas) of
        ((Symbol "variantFirst", exactVariantFormula) : _,
                [_, _, _, _, observedExact, _, _, _]) ->
            assertEqual "the exact premise moved behind the new dual frontier"
                exactVariantFormula observedExact
        unexpected -> fail $ "unexpected categorized premise family: " ++
            show unexpected
  where
    run options target environment goal = expectRight $
        inhabit options environment [] target goal

    realizedClauses description report = case reportOutcome report of
        Realized clauses -> return clauses
        outcome -> fail $ description ++ " failed: " ++ show outcome

testMultiArgumentEtaDeduplication :: IO ()
testMultiArgumentEtaDeduplication = do
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $
        sharedName "deduplicatedEta"
    let selector = sharedName "etaSelector"
        compact = SharedGenerated.FunctionClause target [] $
            SharedGenerated.Global selector
        expanded first second = SharedGenerated.FunctionClause target
            [ SharedGenerated.Bind first
            , SharedGenerated.Bind second
            ] $
            SharedGenerated.Apply
                (SharedGenerated.Apply
                    (SharedGenerated.Global selector)
                    (SharedGenerated.Local first))
                (SharedGenerated.Local second)
        firstExpanded = expanded "record" "argument"
        alphaRenamed = expanded "renamedRecord" "renamedArgument"
    assertEqual "eta de-duplication rewrote the first expanded candidate"
        [firstExpanded] $
            DjinnGenerated.deduplicateEtaEquivalentClauses
                [firstExpanded, alphaRenamed, compact]
    assertEqual "eta de-duplication did not retain the first compact candidate"
        [compact] $
            DjinnGenerated.deduplicateEtaEquivalentClauses
                [compact, alphaRenamed]

testSharedDeclarationAdapter :: IO ()
testSharedDeclarationAdapter = do
    let declarations =
            [ TypeSynonym "Identity" ["a"] (HTVar "a")
            , DataType "Maybe2" ["a"]
                [("Nothing2", []), ("Just2", [HTVar "a"])]
            , AbstractType "HK" $ KArrow (KVar 3) KStar
            , ClassDecl "Comparable" ["a"]
                [("compareTo", HTArrow (HTVar "a") (HTVar "a"))]
            , Function "M.value" $ HTCon "()"
            ]
    mapM_ assertRoundTrip declarations
    let kind = KArrow (KVar 4) (KArrow KStar KStar)
    assertEqual "kind conversion is lossless"
        kind (fromSynthesisKind $ toSynthesisKind kind)
    let parameter = SharedDeclaration.TypeParameter "a" Nothing
        superclass = Constraint (sharedName "Comparable")
            [SharedType.TypeVariable "a"]
        sharedClass = SharedDeclaration.ClassDeclaration ()
            (sharedName "Comparable") [parameter] [superclass] []
    assertEqual "Djinn lowering rejects unsupported superclass semantics"
        (Left ClassSuperclassesUnsupported)
        (fromSynthesisDeclaration sharedClass)
    let explicitClassParameter = SharedDeclaration.TypeParameter "f" $
            Just $ SharedKind.FunctionKind
                SharedKind.ProperTypeKind SharedKind.ProperTypeKind
        explicitlyKindedClass = SharedDeclaration.ClassDeclaration ()
            (sharedName "HigherComparable") [explicitClassParameter] [] []
    assertEqual
        "standalone Djinn declarations cannot erase explicit class kinds"
        (Left $ ExplicitParameterKindUnsupported "f")
        (fromSynthesisDeclaration explicitlyKindedClass)
    assertEqual "shared validation catches a function in the type namespace"
        (Left $ UnsupportedDjinnDeclarationName FunctionOwner
            $ sharedName "T")
        (toSynthesisDeclaration $ Function "T" $ HTCon "()")
    let unitType = SharedType.TupleType SharedName.Boxed []
        unkinded variable = SharedDeclaration.TypeParameter variable Nothing
        signature name = SharedDeclaration.ValueSignature ()
            (sharedName name) unitType
        sharedType name parameters =
            SharedDeclaration.TypeSynonymDeclaration () (sharedName name)
                parameters unitType
        sharedData name constructor =
            SharedDeclaration.DataTypeDeclaration () (sharedName name) []
                [SharedDeclaration.DataConstructor ()
                    (sharedName constructor) []]
        roleCheckedClass name methods = SharedDeclaration.ClassDeclaration ()
            (sharedName name) [] [] methods
    assertEqual "unused uppercase parameters still obey Djinn's VarId grammar"
        (Left $ DeclarationTypeConversionError
            $ InvalidDjinnTypeVariable "A")
        (fromSynthesisDeclaration $ sharedType "Phantom" [unkinded "A"])
    assertEqual "type owners remain local ConIds"
        (Left $ UnsupportedDjinnDeclarationName TypeOwner
            $ sharedName "M.Alias")
        (fromSynthesisDeclaration $ sharedType "M.Alias" [])
    assertEqual "symbolic type owners remain outside Djinn's declaration syntax"
        (Left $ UnsupportedDjinnDeclarationName TypeOwner
            $ sharedName "(:+:)")
        (fromSynthesisDeclaration $
            SharedDeclaration.AbstractTypeDeclaration ()
                (sharedName "(:+:)") SharedKind.ProperTypeKind)
    assertEqual "data constructors remain local ConIds"
        (Left $ UnsupportedDjinnDeclarationName DataConstructorOwner
            $ sharedName "M.Box")
        (fromSynthesisDeclaration $ sharedData "Box" "M.Box")
    assertEqual "class owners remain local ConIds"
        (Left $ UnsupportedDjinnDeclarationName ClassOwner
            $ sharedName "M.Marker")
        (fromSynthesisDeclaration $ roleCheckedClass "M.Marker" [])
    assertEqual "method owners remain unqualified value names"
        (Left $ UnsupportedDjinnDeclarationName MethodOwner
            $ sharedName "M.marker")
        (fromSynthesisDeclaration $
            roleCheckedClass "Marker" [signature "M.marker"])
    assertEqual "type operators are rejected inside declaration signatures"
        (Left $ DeclarationTypeConversionError
            $ UnsupportedDjinnTypeConstructorName $ sharedName "(:+:)")
        (fromSynthesisDeclaration $ SharedDeclaration.ValueDeclaration
            $ SharedDeclaration.ValueSignature () (sharedName "value")
            $ SharedType.TypeConstructor $ sharedName "(:+:)")
  where
    assertRoundTrip declaration = do
        shared <- either (fail . show) pure
            $ toSynthesisDeclaration declaration
        lowered <- either (fail . show) pure
            $ fromSynthesisDeclaration shared
        assertEqual "Djinn declaration round-trip changed its compatibility view"
            (show declaration) (show lowered)

testSharedEnvironmentAdapter :: IO ()
testSharedEnvironmentAdapter = do
    withFirstFunction <- expectRight $ declare
        (Function "firstAssumption" $ HTCon "()") standardEnvironment
    orderedEnvironment <- expectRight $ declare
        (Function "secondAssumption" $ HTCon "()") withFirstFunction
    shared <- either (fail . show) pure
        $ toSynthesisEnvironment orderedEnvironment
    inventory <- either (fail . show) pure
        $ toSynthesisInventory orderedEnvironment
    assertEqual "inventory and compatibility projection disagree"
        (Map.keys $ SharedEnvironment.typeDeclarationMap shared)
        (Map.keys $ SharedEnvironment.typeDeclarationMap
            $ SharedInventory.inventoryEnvironment inventory)
    assertEqual "inventory lost Maybe's inferred kind"
        (Just $ SharedKind.FunctionKind
            SharedKind.ProperTypeKind SharedKind.ProperTypeKind)
        (Map.lookup (sharedName "Maybe")
            $ SharedInference.typeConstructorKinds
            $ SharedInventory.inventoryKindAssumptions inventory)
    markerEnvironment <- expectRight $ declare
        (ClassDecl "Marker" ["a"] []) emptyEnvironment
    markerInventory <- either (fail . show) pure
        $ toSynthesisInventory markerEnvironment
    assertEqual "inventory generalized Djinn's defaulted class kind"
        (Just [Just SharedKind.ProperTypeKind])
        (Map.lookup (sharedName "Marker")
            $ SharedInference.classParameterKinds
            $ SharedInventory.inventoryKindAssumptions markerInventory)
    assertBool "shared standard environment lost unit"
        $ Map.member (sharedName "()")
        $ SharedEnvironment.typeDeclarationMap shared
    assertBool "shared standard environment lost Eq"
        $ Map.member (sharedName "Eq")
        $ SharedEnvironment.classDeclarationMap shared
    lowered <- either (fail . show) pure $ fromSynthesisEnvironment shared
    assertEqual "type order changed through the shared environment"
        (map fst $ typeDeclarations orderedEnvironment)
        (map fst $ typeDeclarations lowered)
    assertEqual "function order changed through the shared environment"
        (map fst $ functionDeclarations orderedEnvironment)
        (map fst $ functionDeclarations lowered)
    assertEqual "class order changed through the shared environment"
        (map fst $ classDeclarations orderedEnvironment)
        (map fst $ classDeclarations lowered)
    let sharedInstance = SharedDeclaration.InstanceDeclaration () ["a"] []
            $ Constraint (sharedName "Eq") [SharedType.TypeVariable "a"]
    instanceEnvironment <- either (fail . show) pure
        $ SharedEnvironment.mkEnvironment [sharedInstance]
    assertEqual "Djinn does not silently install shared instances"
        (Left $ SynthesisEnvironmentDeclarationError
            InstanceDeclarationUnsupported)
        (fromSynthesisEnvironment instanceEnvironment)
    let unitName = sharedName "()"
        unitType = SharedType.TupleType SharedName.Boxed []
        forgedUnitAlias = SharedDeclaration.TypeSynonymDeclaration ()
            unitName [] unitType
        stolenUnitConstructor = SharedDeclaration.DataTypeDeclaration ()
            (sharedName "CounterfeitUnit") []
            [SharedDeclaration.DataConstructor () unitName []]
        canonicalUnit = SharedDeclaration.DataTypeDeclaration () unitName []
            [SharedDeclaration.DataConstructor () unitName []]
        rejectsForgedUnit description declaration = do
            forged <- either (fail . show) pure
                $ SharedEnvironment.mkEnvironment [declaration]
            assertEqual description
                (Left $ SynthesisEnvironmentDeclarationError
                    NonCanonicalUnitDeclaration)
                (fromSynthesisEnvironment forged)
    rejectsForgedUnit "a synonym cannot own structural unit"
        forgedUnitAlias
    rejectsForgedUnit "another datatype cannot own the unit constructor"
        stolenUnitConstructor
    canonicalUnitEnvironment <- either (fail . show) pure
        $ SharedEnvironment.mkEnvironment [canonicalUnit]
    loweredUnit <- either (fail . show) pure
        $ fromSynthesisEnvironment canonicalUnitEnvironment
    assertEqual "only canonical data () = () crosses the trusted unit path"
        [ ("()", ([], HTUnion [("()", [])], KStar)) ]
        (typeDeclarations loweredUnit)

testIntrinsicListDeclaration :: IO ()
testIntrinsicListDeclaration = do
    let element = HTVar "element"
        list = HTApp (HTCon "[]") element
        canonical = DataType "[]" ["element"]
            [("[]", []), (":", [element, list])]
        rejected label result = case result of
            Left _ -> pure ()
            Right _ -> fail $ label ++ ": a forged intrinsic declaration was accepted"
        sharedElement = SharedType.TypeVariable "element"
        sharedList = SharedType.TypeApplication
            (SharedType.TypeConstructor SharedName.listName) sharedElement
        parameter kind = SharedDeclaration.TypeParameter "element" kind
        source owner kind constructors = SharedDeclaration.DataTypeDeclaration ()
            owner [parameter kind] constructors
        nil = SharedDeclaration.DataConstructor () SharedName.listName []
        cons fields = SharedDeclaration.DataConstructor () SharedName.consName fields
        exact kind = source SharedName.listName kind [nil, cons [sharedElement, sharedList]]
    converted <- expectShownRight $ toSynthesisDeclaration canonical
    assertEqual "the shared list retains the exact binder and constructor identities"
        (exact Nothing) converted
    assertEqual "the complete intrinsic list round-trips to its raw source"
        (Right canonical) $ fromSynthesisDeclaration converted
    assertEqual "an explicitly proper element kind has the same exact raw projection"
        (Right canonical) $ fromSynthesisDeclaration $ exact $ Just SharedKind.ProperTypeKind
    sourceEnvironment <- expectShownRight $ SharedEnvironment.mkEnvironment [converted]
    prepared <- expectShownRight $ RawEnvironment.prepareSynthesisEnvironment sourceEnvironment
    assertEqual "preparation retains the intrinsic source declaration"
        [converted] $ map (SharedDeclaration.mapDeclarationKindVariables absurd)
            $ SharedEnvironment.environmentDeclarations
            $ SharedInventory.inventoryEnvironment $ RawEnvironment.preparedEnvironmentInventory prepared
    _ <- expectShownRight $ toSynthesisEnvironment $ RawEnvironment.preparedEnvironmentSource prepared
    forM_
        [ ("another datatype cannot own list constructors",
            DataType "Counterfeit" ["element"] [("[]", []), (":", [element, list])])
        , ("a list alias cannot replace its datatype", TypeSynonym "[]" ["element"] list)
        , ("a function cannot own cons", Function ":" $ element `HTArrow` list)
        , ("a function cannot own nil", Function "[]" list)
        , ("a class cannot own list", ClassDecl "[]" ["element"] [])
        , ("a class method cannot own cons",
            ClassDecl "Counterfeit" ["element"] [(":", element `HTArrow` list)])
        , ("list constructor fields cannot be swapped",
            DataType "[]" ["element"] [("[]", []), (":", [list, element])])
        , ("recursive fields retain the exact element parameter",
            DataType "[]" ["element"]
                [("[]", []), (":", [element, HTApp (HTCon "[]") (HTVar "other")])])
        , ("a list family cannot omit cons", DataType "[]" ["element"] [("[]", [])])
        ] $ \(label, declaration) -> rejected label $ toSynthesisDeclaration declaration
    forM_
        [ ("shared nominal owners cannot steal list constructors",
            source (sharedName "Counterfeit") Nothing [nil, cons [sharedElement, sharedList]])
        , ("shared cons fields cannot be swapped",
            source SharedName.listName Nothing [nil, cons [sharedList, sharedElement]])
        , ("shared recursive fields retain the exact parameter",
            source SharedName.listName Nothing
                [nil, cons [sharedElement, SharedType.TypeApplication
                    (SharedType.TypeConstructor SharedName.listName)
                    (SharedType.TypeVariable "other")]])
        , ("shared list parameters cannot have a unary kind",
            exact $ Just $ SharedKind.FunctionKind SharedKind.ProperTypeKind SharedKind.ProperTypeKind)
        , ("shared list cannot gain an extra constructor",
            source SharedName.listName Nothing [nil, cons [sharedElement, sharedList],
                SharedDeclaration.DataConstructor () (sharedName "Other") []])
        , ("shared function cannot own cons",
            SharedDeclaration.ValueDeclaration $ SharedDeclaration.ValueSignature ()
                SharedName.consName $ SharedType.FunctionType sharedElement sharedList)
        , ("shared class cannot own list",
            SharedDeclaration.ClassDeclaration () SharedName.listName [parameter Nothing] [] [])
        ] $ \(label, declaration) -> rejected label $ fromSynthesisDeclaration declaration
    rejected "cons remains invalid in type position"
        $ fromSynthesisType $ SharedType.TypeConstructor SharedName.consName

-- Raw compatibility type definitions predate 'Declaration' and redundantly
-- encode an abstract type's name and kind.  Every entrance must resolve that
-- redundancy identically instead of allowing its chosen projection to decide
-- which half silently wins.
testRawAbstractDefinitionNormalization :: IO ()
testRawAbstractDefinitionNormalization = do
    let higherKind = KArrow KStar KStar
        nameMismatch =
            ("Outer", ([], HTAbstract "Embedded" KStar, KStar))
        parameterized =
            ("Opaque", (["a"], HTAbstract "Opaque" KStar, KStar))
        staleKind =
            ("Opaque", ([], HTAbstract "Opaque" higherKind, KStar))
        rawEnvironment definition = RawEnvironment.Environment
            { RawEnvironment.envTypes = [definition]
            , RawEnvironment.envFunctions = []
            , RawEnvironment.envClasses = []
            }
        assertPreparedFailure description expected source =
            case prepareEnvironment source of
                Left actual -> assertEqual description expected actual
                Right _ -> fail $ description ++ ": malformed source prepared"

    assertEqual "the shared adapter rejects conflicting abstract names"
        (Left $ SynthesisAbstractTypeNameMismatch "Outer" "Embedded")
        (toSynthesisEnvironment $ rawEnvironment nameMismatch)
    assertPreparedFailure
        "shared preparation rejects the same conflicting abstract names"
        (SynthesisAbstractTypeNameMismatch "Outer" "Embedded")
        (rawEnvironment nameMismatch)
    assertLeftContains
        "raw environment validation rejects conflicting abstract names"
        "embeds the conflicting name \"Embedded\""
        (validateEnvironment [nameMismatch] [] [])
    assertLeftContains "standalone HCheck rejects conflicting abstract names"
        "embeds the conflicting name \"Embedded\""
        (htCheckEnv [nameMismatch])
    assertLeftContains "HCheck query preparation rejects conflicting names"
        "embeds the conflicting name \"Embedded\""
        (htCheckType [nameMismatch] $ HTCon "Outer")

    assertEqual "the shared adapter rejects abstract parameters"
        (Left $ SynthesisAbstractTypeParameters "Opaque" ["a"])
        (toSynthesisEnvironment $ rawEnvironment parameterized)
    assertPreparedFailure "shared preparation rejects abstract parameters"
        (SynthesisAbstractTypeParameters "Opaque" ["a"])
        (rawEnvironment parameterized)
    assertLeftContains "raw validation rejects abstract parameters"
        "cannot declare parameters: [\"a\"]"
        (validateEnvironment [parameterized] [] [])
    assertLeftContains "standalone HCheck rejects abstract parameters"
        "cannot declare parameters: [\"a\"]"
        (htCheckEnv [parameterized])
    assertLeftContains "HCheck query preparation rejects abstract parameters"
        "cannot declare parameters: [\"a\"]"
        (htCheckType [parameterized] $ HTCon "Opaque")

    shared <- expectShownRight
        $ toSynthesisEnvironment $ rawEnvironment staleKind
    case SharedEnvironment.environmentDeclarations shared of
        [SharedDeclaration.AbstractTypeDeclaration _ name kind] -> do
            assertEqual "abstract normalization changed its owner"
                (sharedName "Opaque") name
            assertEqual "the embedded abstract kind is authoritative"
                (SharedKind.FunctionKind SharedKind.ProperTypeKind
                    SharedKind.ProperTypeKind)
                kind
        declarations -> fail $
            "unexpected normalized abstract declarations: " ++
            show declarations

    prepared <- expectShownRight $ prepareEnvironment $ rawEnvironment staleKind
    assertEqual "preparation did not refresh the projected compatibility kind"
        (Just ([], HTAbstract "Opaque" higherKind, higherKind))
        (lookup "Opaque" $ typeDeclarations
            $ RawEnvironment.preparedEnvironmentSource prepared)
    (checked, _) <- expectRight $ validateEnvironment [staleKind] [] []
    assertEqual "raw validation did not refresh the cached abstract kind"
        (Just ([], HTAbstract "Opaque" higherKind, higherKind))
        (lookup "Opaque" checked)
    hchecked <- expectRight $ htCheckEnv [staleKind]
    assertEqual "standalone HCheck did not refresh the cached abstract kind"
        (Just ([], HTAbstract "Opaque" higherKind, higherKind))
        (lookup "Opaque" hchecked)
    assertRight "HCheck query preparation trusted the stale outer kind"
        $ htCheckType
            [ staleKind
            , ("Atom", ([], HTAbstract "Atom" KStar, KStar))
            ]
            (HTApp (HTCon "Opaque") (HTCon "Atom"))

-- The stable Djex boundary must preserve the neutral Environment as the
-- authoritative declaration inventory. Historical raw tables are on-demand
-- compatibility projections; making them the retained source instead would
-- lose global order and can change synonym-transparent recursion.
testNeutralDjinnPreparation :: IO ()
testNeutralDjinnPreparation = do
    let proper = SharedKind.ProperTypeKind
        abstract name kind =
            SharedDeclaration.AbstractTypeDeclaration ()
                (sharedName name) kind
        value name valueType = SharedDeclaration.ValueDeclaration
            $ SharedDeclaration.ValueSignature () (sharedName name) valueType
        variable name = SharedType.TypeVariable name
        constructor name = SharedType.TypeConstructor $ sharedName name
        apply = SharedType.TypeApplication
        parameter name = SharedDeclaration.TypeParameter name Nothing
        dataType name fields = SharedDeclaration.DataTypeDeclaration ()
            (sharedName name) []
            [SharedDeclaration.DataConstructor () (sharedName name) fields]
        methodlessClass = SharedDeclaration.ClassDeclaration ()
            (sharedName "Marker") [parameter "a"] [] []
        orderedDeclarations =
            [ abstract "First" proper
            , value "firstValue" $ constructor "First"
            , methodlessClass
            , abstract "Second" proper
            , value "secondValue" $ constructor "Second"
            ]

    orderedEnvironment <- mkNeutralDjinnEnvironment orderedDeclarations
    orderedSession <- expectShownRight
        $ Djex.mkDjinnSession orderedEnvironment
    assertEqual "the session changed its derived editable environment"
        orderedEnvironment
        (Djex.djinnSessionEnvironment orderedSession)
    assertEqual "the session inventory changed global declaration order"
        (SharedEnvironment.environmentDeclarations orderedEnvironment)
        (SharedEnvironment.environmentDeclarations
            $ SharedInventory.inventoryEnvironment
            $ Djex.djinnSessionInventory orderedSession)
    assertEqual "a methodless Djinn class did not default its parameter to *"
        (Just [Just proper])
        (Map.lookup (sharedName "Marker")
            $ SharedInference.classParameterKinds
            $ SharedInventory.inventoryKindAssumptions
            $ Djex.djinnSessionInventory orderedSession)

    -- A stable neutral environment owns ground class-parameter kinds which
    -- the historical standalone ClassDecl syntax cannot spell.  Sealing must
    -- retain that authoritative annotation while its on-demand compatibility
    -- snapshot reconstructs the same HKind from Inventory assumptions.
    let higherClassKind = SharedKind.FunctionKind proper proper
        higherClass = SharedDeclaration.ClassDeclaration ()
            (sharedName "HigherMarker")
            [SharedDeclaration.TypeParameter "f" $ Just higherClassKind]
            [] []
        higherDeclarations =
            [ abstract "F" higherClassKind
            , abstract "Ground" proper
            , higherClass
            ]
    higherEnvironment <- mkNeutralDjinnEnvironment higherDeclarations
    higherSession <- expectShownRight $ Djex.mkDjinnSession higherEnvironment
    assertEqual "the session erased an explicit ground class kind"
        (Just [Just higherClassKind])
        (Map.lookup (sharedName "HigherMarker")
            $ SharedInference.classParameterKinds
            $ SharedInventory.inventoryKindAssumptions
            $ Djex.djinnSessionInventory higherSession)
    higherPrepared <- expectShownRight $
        RawEnvironment.prepareGroundSynthesisEnvironment higherEnvironment
    assertEqual "the raw snapshot lost an explicit ground class kind"
        [("HigherMarker", ([("f", KArrow KStar KStar)], []))]
        (classDeclarations $
            RawEnvironment.preparedEnvironmentSource higherPrepared)
    weakenedHigherPrepared <- expectShownRight $
        RawEnvironment.prepareSynthesisEnvironment $
            SharedEnvironment.mapEnvironmentKindVariables absurd
                higherEnvironment
    assertEqual "kind-weakened preparation changed the explicit class kind"
        [("HigherMarker", ([("f", KArrow KStar KStar)], []))]
        (classDeclarations $
            RawEnvironment.preparedEnvironmentSource weakenedHigherPrepared)
    higherF <- either fail pure $ mkContext "HigherMarker" [HTCon "F"]
    higherGround <- either fail pure $
        mkContext "HigherMarker" [HTCon "Ground"]
    assertEqual "the explicit higher class kind rejected a matching constructor"
        (Right []) (resolvePreparedContext higherPrepared higherF)
    assertLeft "the explicit higher class kind accepted a proper type"
        (resolvePreparedContext higherPrepared higherGround)

    -- Synonym expansion must precede the recursive-datatype policy.  The
    -- parameter of Phantom is semantically absent, so this datatype is not
    -- recursive despite the surface occurrence of D in its constructor.
    let boolDeclaration = abstract "Bool" proper
        phantomDeclaration = SharedDeclaration.TypeSynonymDeclaration ()
            (sharedName "Phantom") [parameter "a"] $ constructor "Bool"
        phantomUse = apply (constructor "Phantom") (constructor "D")
        phantomDeclarations =
            [boolDeclaration, phantomDeclaration, dataType "D" [phantomUse]]
    phantomEnvironment <- mkNeutralDjinnEnvironment phantomDeclarations
    _ <- expectShownRight $ fromSynthesisEnvironment
        $ SharedEnvironment.mapEnvironmentKindVariables absurd
        phantomEnvironment
    _ <- expectShownRight $ Djex.mkDjinnSession phantomEnvironment

    let identityDeclaration = SharedDeclaration.TypeSynonymDeclaration ()
            (sharedName "Identity") [parameter "a"] $ variable "a"
        identityUse name = apply (constructor "Identity") (constructor name)
        recursiveCases =
            [ ("direct recursion",
                [dataType "Direct" [constructor "Direct"]])
            , ("mutual recursion",
                [ dataType "Even" [constructor "Odd"]
                , dataType "Odd" [constructor "Even"]
                ])
            , ("recursion exposed by synonym expansion",
                [ identityDeclaration
                , dataType "AliasLoop" [identityUse "AliasLoop"]
                ])
            ]
    mapM_ assertRecursiveAcceptance recursiveCases

    -- Kind inference alone accepts this partially applied synonym: Pair Bool
    -- has kind * -> *, exactly the argument kind expected by Higher.  Djinn's
    -- Haskell-compatible boundary must nevertheless reject every supported
    -- declaration position in which a synonym is not fully saturated.
    let higherKind = SharedKind.FunctionKind
            (SharedKind.FunctionKind proper proper) proper
        pairDeclaration = SharedDeclaration.TypeSynonymDeclaration ()
            (sharedName "Pair") [parameter "a", parameter "b"]
            $ SharedType.TupleType SharedName.Boxed
                [variable "a", variable "b"]
        partialPair = apply (constructor "Pair") (constructor "Bool")
        partialUse = apply (constructor "Higher") partialPair
        saturationBase =
            [ boolDeclaration
            , abstract "Higher" higherKind
            , pairDeclaration
            ]
        badSynonym = SharedDeclaration.TypeSynonymDeclaration ()
            (sharedName "BadSynonym") [] partialUse
        badData = dataType "BadData" [partialUse]
        badValue = value "badValue" partialUse
        badClass = SharedDeclaration.ClassDeclaration ()
            (sharedName "BadClass") [parameter "a"] []
            [SharedDeclaration.ValueSignature ()
                (sharedName "badMethod") partialUse]
        saturationCases =
            [ ("a synonym body", badSynonym)
            , ("a data-constructor field", badData)
            , ("a value signature", badValue)
            , ("a class method", badClass)
            ]
    saturationEnvironment <- mkNeutralDjinnEnvironment saturationBase
    _ <- expectShownRight $ Djex.mkDjinnSession saturationEnvironment
    mapM_ (assertUnsaturatedRejection saturationBase) saturationCases
  where
    assertRecursiveAcceptance (description, declarations) = do
        environment <- mkNeutralDjinnEnvironment declarations
        session <- expectShownRight $ Djex.mkDjinnSession environment
        assertEqual
            (description ++ " changed the authoritative neutral environment")
            environment $ Djex.djinnSessionEnvironment session

    assertUnsaturatedRejection base (description, declaration) = do
        environment <- mkNeutralDjinnEnvironment $ base ++ [declaration]
        case Djex.mkDjinnSession environment of
            Left failure -> do
                assertEqual (description ++ " has the environment code")
                    (Just "DJEX_DJINN_ENV")
                    (SharedDiagnostic.diagnosticCode failure)
                let contextText = unwords
                        $ SharedDiagnostic.diagnosticContext failure
                assertBool (description ++ " did not report Pair")
                    $ "Pair" `isInfixOf` contextText
                assertBool (description ++ " did not report saturation")
                    $ ("expects 2" `isInfixOf` contextText &&
                        "got 1" `isInfixOf` contextText) ||
                      ("UnsaturatedTypeSynonym" `isInfixOf` contextText &&
                        "1" `isInfixOf` contextText &&
                        "2" `isInfixOf` contextText)
            Right _ -> fail $ description ++
                ": an unsaturated type synonym reached Djinn"

-- Global assumptions are invariant across queries, so sealing translates
-- them once in exact declaration order. The raw table remains an on-demand
-- compatibility projection of the shared inventory rather than retained
-- session state.
testPreparedFunctionPremises :: IO ()
testPreparedFunctionPremises = do
    let atom = HTCon "Atom"
        alias = HTCon "Alias"
        environment = RawEnvironment.Environment
            [ ("Atom", ([], HTAbstract "Atom" KStar, KStar))
            , ("Alias", ([], atom, KStar))
            ]
            [ ("zAliased", alias)
            , ("External.zAliased", alias)
            , ("%%", alias)
            , ("aIdentity", HTArrow alias alias)
            ]
            []
        atomFormula = PVar $ Symbol "Atom"
        expectedPremises =
            [ (Symbol "zAliased", atomFormula)
            , (Symbol "External.zAliased", atomFormula)
            , (Symbol "%%", atomFormula)
            , (Symbol "aIdentity", atomFormula :-> atomFormula)
            ]
    prepared <- expectShownRight $ prepareEnvironment environment
    assertEqual "prepared premises changed source order or alias expansion"
        expectedPremises
        (RawEnvironment.preparedEnvironmentFunctionPremises prepared)
    neutral <- expectShownRight $ toSynthesisEnvironment environment
    nativePrepared <- expectShownRight $
        RawEnvironment.prepareSynthesisEnvironment neutral
    assertEqual "native preparation changed premise order or operator names"
        expectedPremises
        (RawEnvironment.preparedEnvironmentFunctionPremises nativePrepared)
    assertEqual "the compatibility projection changed the sealed declarations"
        environment (RawEnvironment.preparedEnvironmentSource prepared)
    assertEqual "native preparation lost its on-demand raw projection"
        environment (RawEnvironment.preparedEnvironmentSource nativePrepared)
    firstResult <- expectRight $ inhabitGeneratedPrepared
        defaultQueryOptions prepared [] "answer" alias
    secondResult <- expectRight $ inhabitGeneratedPrepared
        defaultQueryOptions prepared [] "answer" alias
    assertBool "cached global premises were not consumed by proof search"
        $ not $ null $ generatedReportCandidates firstResult
    assertEqual "reusing cached premises changed a repeated query"
        firstResult secondResult

-- The stable query path and global-premise cache must not need an HType
-- round-trip. Assert explicit formulas, rather than equality alone, so the two
-- entrances cannot drift together. In particular, unit is a nominal datatype
-- in Djinn: treating the shared zero-tuple as structural truth renders the
-- same Haskell value but changes both the formula and explored proof.
testPreparedFormulaParity :: IO ()
testPreparedFormulaParity = do
    environment <- expectRight $ do
        withIdentity <- declare
            (TypeSynonym "Id" ["x"] $ HTVar "x")
            standardEnvironment
        withAbstract <- declare
            (AbstractType "F" $ KArrow KStar KStar)
            withIdentity
        withEmpty <- declare
            (DataType "EmptyOf" ["x"] []) withAbstract
        declare
            (DataType "Box" ["x"] [("MkBox", [HTVar "x"])])
            withEmpty
    prepared <- expectShownRight $ prepareEnvironment environment
    rawFormula <- expectRight $ prepareTypeFormulaTranslator $
        RawEnvironment.envTypes environment

    let atom name = PVar $ Symbol name
        pair = HTTuple [HTVar "a", HTVar "b"]
        pairFormula = Conj [atomA, atomB]
        apply name arguments = foldl HTApp (HTCon name) arguments
        identity source = apply "Id" [source]
        list source = apply "[]" [source]
        abstract source = apply "F" [source]
        empty source = apply "EmptyOf" [source]
        box source = apply "Box" [source]
        listPairFormula = atom "[(a, b)]"
        emptyPairFormula = Empty $ Symbol "EmptyOf (a, b)"
        unitFormula = Disj [(ConsDesc "()" 0, Conj [])]
        cases =
            [ ("unit", HTCon "()", unitFormula)
            , ("qualified opaque constructor", HTCon "External.T",
                  atom "External.T")
            , ("prefix function constructor atom", HTCon "->",
                  atom "(->)")
            , ("tuple", pair, pairFormula)
            , ("opaque list", list pair, listPairFormula)
            , ("transparent alias", identity pair, pairFormula)
            , ("alias under list", list $ identity pair, listPairFormula)
            , ("alias under abstract", abstract $ identity pair,
                  atom "F (a, b)")
            , ("parameterized empty type", empty $ identity pair,
                  emptyPairFormula)
            , ("unary tuple payload", box $ identity pair,
                  Disj [(ConsDesc "MkBox" 1, Conj [pairFormula])])
            , ("constructor order", apply "Maybe" [HTVar "a"],
                  Disj
                    [ (ConsDesc "Nothing" 0, Conj [])
                    , (ConsDesc "Just" 1, Conj [atomA])
                    ])
            , ("recursive arrow view",
                  HTArrow (list $ identity pair) (empty $ identity pair),
                  listPairFormula :-> emptyPairFormula)
            ]

    mapM_ (assertFormulaParity rawFormula prepared) cases

    target <- expectShownRight $ SharedGenerated.mkDefinitionName $
        sharedName "nativeUnit"
    result <- expectShownRight $ inhabitSynthesisResultPrepared
        defaultQueryOptions prepared [] target $
            SharedType.TupleType SharedName.Boxed []
    let search = SharedQuery.resultSearch result
        metadata = SharedSearch.batchMetadata search
    assertEqual "native unit lost its nominal formula"
        "(|true)" (djinnTranslatedFormula metadata)
    assertEqual "native unit lost its constructor injection"
        (Just "Inj0 Tuple0") (djinnFirstExploredProof metadata)
    case SharedSearch.batchCandidates search of
        candidate : _ -> assertEqual
            "native unit candidate changed despite stable metadata"
            (Right "nativeUnit = ()") $
                SharedGenerated.renderFunctionClause
                    (SharedGenerated.defaultRenderOptions id)
                    (SharedCandidate.candidateOutput candidate)
        [] -> fail "native unit query produced no candidate"
  where
    assertFormulaParity rawFormula prepared (description, raw, expected) = do
        shared <- expectShownRight $ toSynthesisType raw
        compatibilityFormula <- expectRight $ rawFormula raw
        nativeFormula <- expectRight $
            RawEnvironment.preparedEnvironmentSynthesisFormulaTranslator
                prepared shared
        assertEqual (description ++ ": raw formula changed")
            expected compatibilityFormula
        assertEqual (description ++ ": shared formula changed")
            expected nativeFormula

mkNeutralDjinnEnvironment
    :: [SharedDeclaration.Declaration String Void ()]
    -> IO Djex.DjinnEnvironment
mkNeutralDjinnEnvironment = expectShownRight .
    SharedEnvironment.mkEnvironment

-- Raw Environment is a compatibility input, not a second kind authority.
-- In particular, callers of the internal constructor can forge stale class
-- parameter kinds; preparation must replace them with the assumptions inferred
-- from the same declarations before context lookup sees the backend table.
testRawDjinnPreparationKinds :: IO ()
testRawDjinnPreparationKinds = do
    let RawEnvironment.Environment types functions _ = standardEnvironment
        forged = RawEnvironment.Environment types functions
            [("Marker", ([("a", KArrow KStar KStar)], []))]
    prepared <- expectShownRight $ prepareEnvironment forged
    assertEqual "raw class kinds did not follow the checked inventory"
        [("Marker", ([("a", KStar)], []))]
        (classDeclarations $ RawEnvironment.preparedEnvironmentSource prepared)
    markerMaybe <- either fail pure $ mkContext "Marker" [HTCon "Maybe"]
    assertLeft "a stale raw class kind overrode the shared inventory"
        $ resolvePreparedContext prepared markerMaybe

testBoundedContextArity :: IO ()
testBoundedContextArity = do
    prepared <- expectShownRight $ prepareEnvironment standardEnvironment
    let arguments = repeat $ HTVar "a"
        malformed = Constraint (sharedName "Eq") arguments
    case resolvePreparedContext prepared malformed of
        Left message -> assertBool "context arity did not use its first failure"
            $ "expects 1 type argument(s), but got 2" `isInfixOf` message
        Right _ -> fail "an infinite known-class context was accepted"

    -- Request sealing must not traverse a nested context spine before a
    -- session supplies Eq's finite arity. This is the rank-N counterpart of
    -- the raw compatibility check above.
    session <- expectShownRight Djex.standardDjinnSession
    targetName <- expectShownRight $ SharedGenerated.mkDefinitionName
        $ sharedName "nestedContext"
    let variable = SharedType.TypeVariable "a"
        nestedGoal = SharedType.ForallType ["a"]
            [Constraint (sharedName "Eq") $ repeat variable]
            variable
        query = SharedQuery.QueryRequest
            { SharedQuery.requestTarget = targetName
            , SharedQuery.requestGoal = nestedGoal
            , SharedQuery.requestContexts = []
            , SharedQuery.requestOptions = defaultQueryOptions
            }
    request <- expectShownRight $ Djex.mkDjinnRequest query
    case Djex.runDjinnQuery session request of
        Left failure -> do
            assertEqual "nested arity failure has the query code"
                (Just "DJEX_DJINN_QUERY")
                (SharedDiagnostic.diagnosticCode failure)
            assertBool "nested context arity did not stop at its first excess"
                $ "expects 1 type argument(s), but got 2" `isInfixOf`
                    unwords (SharedDiagnostic.diagnosticContext failure)
        Right _ -> fail "an infinite nested context was accepted"

-- Saturation and kind checking own different failures. A partial synonym can
-- be kind-compatible in a higher-kinded position, so the explicit arity guard
-- must reject it. An extra argument, however, is not an arity shortage; in
-- Djinn's proper-result synonym subset it proceeds to the shared kind checker
-- and is rejected there. Keep both the raw compatibility path and the stable
-- neutral-session path on that same diagnostic boundary.
testSynonymSaturationBoundary :: IO ()
testSynonymSaturationBoundary = do
    let applyDefinition =
            ("Apply", (["f"], HTVar "f", ()))
        maybeLikeDefinition =
            ("MaybeLike", ([],
                HTAbstract "MaybeLike" (KArrow KStar KStar), ()))
        intDefinition =
            ("Int2", ([], HTAbstract "Int2" KStar, ()))
        definitions =
            [applyDefinition, maybeLikeDefinition, intDefinition]
        apply = HTCon "Apply"
        maybeLike = HTCon "MaybeLike"
        intType = HTCon "Int2"
        maybeInt = HTApp maybeLike intType
        overapplied = HTApp (HTApp apply maybeLike) intType
    checked <- expectShownRight $ htCheckEnv definitions
    assertRawKindFailure "raw overapplication"
        $ htCheckType checked $ HTArrow overapplied maybeInt
    assertRawSaturationFailure "raw partial application"
        $ htCheckType checked $ HTArrow apply apply

    let proper = SharedKind.ProperTypeKind
        parameter = SharedDeclaration.TypeParameter "f" Nothing
        sharedApply = SharedDeclaration.TypeSynonymDeclaration ()
            (sharedName "Apply") [parameter] $ SharedType.TypeVariable "f"
        sharedMaybeLike = SharedDeclaration.AbstractTypeDeclaration ()
            (sharedName "MaybeLike")
            (SharedKind.FunctionKind proper proper)
        sharedInt = SharedDeclaration.AbstractTypeDeclaration ()
            (sharedName "Int2") proper
    environment <- mkNeutralDjinnEnvironment
        [sharedApply, sharedMaybeLike, sharedInt]
    session <- expectShownRight $ Djex.mkDjinnSession environment
    target <- expectShownRight $ SharedName.mkIdentifier "witness"
    assertStableKindFailure session target
        "Apply MaybeLike Int2 -> MaybeLike Int2"
    assertStableSaturationFailure session target "Apply -> Apply"
  where
    assertRawKindFailure description result = case result of
        Left message -> do
            assertBool (description ++ " was mislabeled as unsaturated")
                $ "expects at least" `notElemText` message
            assertBool (description ++ " did not reach kind inference")
                $ "KindMismatch" `isInfixOf` message
        Right () -> fail $ description ++ " was accepted"

    assertRawSaturationFailure description result = case result of
        Left message -> assertBool
            (description ++ " lost its saturation diagnostic")
            $ "expects at least 1 argument(s), but got 0" `isInfixOf` message
        Right () -> fail $ description ++ " was accepted"

    assertStableKindFailure session target source = do
        request <- expectShownRight $ Djex.parseDjinnRequest
            session defaultQueryOptions target "overapplied.djinn" source
        case Djex.runDjinnQuery session request of
            Left failure -> do
                assertEqual "stable overapplication has the query code"
                    (Just "DJEX_DJINN_QUERY")
                    (SharedDiagnostic.diagnosticCode failure)
                let message = unwords
                        $ SharedDiagnostic.diagnosticContext failure
                assertBool "stable overapplication was mislabeled as unsaturated"
                    $ "expects at least" `notElemText` message
                assertBool "stable overapplication did not reach kind inference"
                    $ "KindMismatch" `isInfixOf` message
            Right _ -> fail "stable overapplication was accepted"

    assertStableSaturationFailure session target source = do
        request <- expectShownRight $ Djex.parseDjinnRequest
            session defaultQueryOptions target "partial.djinn" source
        case Djex.runDjinnQuery session request of
            Left failure -> assertBool
                "stable partial application lost its saturation diagnostic"
                $ "expects at least 1 argument(s), but got 0" `isInfixOf`
                    unwords (SharedDiagnostic.diagnosticContext failure)
            Right _ -> fail "stable partial application was accepted"

    needle `notElemText` haystack = not $ needle `isInfixOf` haystack

-- Prepared sessions retain an exact shared Inventory/synonym witness for
-- operational queries, while the historical context-resolution surface
-- continues to return the caller's alias-bearing raw spelling. This distinction
-- keeps requests and compatibility inspection source-oriented without making
-- proof-search atoms depend on how an alias happened to be written.
testPreparedQuerySynonyms :: IO ()
testPreparedQuerySynonyms = do
    let variable = HTVar "a"
        boolType = HTCon "Bool"
        voidType = HTCon "Void"
        identity argument = HTApp (HTCon "Identity") argument
        valueMethod valueType = HTArrow valueType valueType
    withIdentity <- expectRight $ declare
        (TypeSynonym "Identity" ["a"] variable) standardEnvironment
    withFirst <- expectRight $ declare
        (TypeSynonym "First" ["a", "b"] variable) withIdentity
    environment <- expectRight $ declare
        (ClassDecl "ValueAlias" ["x"]
            [("valueAlias", valueMethod $ HTVar "x")])
        withFirst
    prepared <- expectShownRight $ prepareEnvironment environment
    sharedBool <- expectShownRight $ toSynthesisType boolType
    sharedVoid <- expectShownRight $ toSynthesisType voidType
    sharedIdentityBool <- expectShownRight $
        toSynthesisType $ identity boolType
    sharedIdentityVoid <- expectShownRight $
        toSynthesisType $ identity voidType

    assertEqual "the prepared environment retained its exact alias table"
        (Right [sharedBool, sharedVoid])
        (RawEnvironment.elaboratePreparedSynthesisTypes prepared
            [ (KStar, sharedIdentityBool)
            , (KStar, sharedIdentityVoid)
            ])

    let aliasContext = context "ValueAlias" [identity boolType]
        expandedContext = context "ValueAlias" [boolType]
        aliasMethod = valueMethod $ identity boolType
    assertEqual "prepared compatibility resolution erased an alias spelling"
        (Right [("valueAlias", aliasMethod)])
        (resolvePreparedContext prepared aliasContext)

    let expandedGoal = HTArrow variable variable
        aliasGoal = HTArrow (identity variable) variable
    aliasGoalReport <- expectRight $ inhabitGeneratedPrepared
        defaultQueryOptions prepared [] "aliasGoal" aliasGoal
    expandedGoalReport <- expectRight $ inhabitGeneratedPrepared
        defaultQueryOptions prepared [] "aliasGoal" expandedGoal
    assertEqual "a goal alias changed prepared proof search"
        expandedGoalReport aliasGoalReport

    let contextualGoal = valueMethod boolType
    aliasContextReport <- expectRight $ inhabitGeneratedPrepared
        defaultQueryOptions prepared [aliasContext]
        "aliasContext" contextualGoal
    expandedContextReport <- expectRight $ inhabitGeneratedPrepared
        defaultQueryOptions prepared [expandedContext]
        "aliasContext" contextualGoal
    assertEqual "a class-argument alias changed prepared proof search"
        expandedContextReport aliasContextReport

    case inhabitGeneratedPrepared defaultQueryOptions prepared
        [context "ValueAlias" [HTCon "Identity"]]
        "partialAlias" expandedGoal of
      Left message -> assertBool
        "a partial class-argument alias lost its compatibility diagnostic"
        $ ("argument Identity of class ValueAlias: Type synonym Identity " ++
          "expects at least 1 argument(s), but got 0") `isInfixOf` message
      Right _ -> fail "a partial class-argument alias reached proof search"

    -- Shared elaboration checks kinds before expansion, but Djinn has always
    -- diagnosed saturation first within one raw HType. The compatibility
    -- preflight deliberately preserves that ordering even when another tuple
    -- element is independently ill-kinded.
    let mixedFailure = HTTuple
            [ HTCon "Identity"
            , HTApp boolType variable
            ]
    case inhabitGeneratedPrepared defaultQueryOptions prepared []
        "mixedAliasFailure" mixedFailure of
      Left message -> do
        assertBool "legacy saturation precedence was lost"
            $ "Type synonym Identity expects at least 1 argument(s), but got 0"
                `isInfixOf` message
        assertBool "an unrelated kind error replaced the saturation failure"
            $ "KindMismatch" `notElemText` message
      Right _ -> fail "an unsaturated, ill-kinded query reached proof search"

    let unprojectableFailure = HTTuple
            [ HTCon "Identity"
            , HTUnion []
            ]
    case inhabitGeneratedPrepared defaultQueryOptions prepared []
        "unprojectableAliasFailure" unprojectableFailure of
      Left message -> assertBool
        "raw conversion overtook synonym saturation"
        $ "Type synonym Identity expects at least 1 argument(s), but got 0"
            `isInfixOf` message
      Right _ -> fail
        "an unsaturated declaration-only query reached proof search"

    -- The sealed adapter walks declaration-only raw nodes even though they
    -- cannot cross the shared query boundary. This keeps the historical local
    -- saturation failure ahead of the later projection failure.
    let nestedDeclarationFailure = HTUnion
            [("Only", [HTCon "Identity"])]
    case inhabitGeneratedPrepared defaultQueryOptions prepared []
        "nestedDeclarationFailure" nestedDeclarationFailure of
      Left message -> assertBool
        "raw declaration traversal lost nested synonym saturation"
        $ "Type synonym Identity expects at least 1 argument(s), but got 0"
            `isInfixOf` message
      Right _ -> fail
        "an unsaturated alias inside HTUnion reached projection"

    -- Application heads are checked before their arguments. In particular,
    -- a partial alias keeps its arity diagnostic even if the supplied argument
    -- is not itself representable in the checked shared name vocabulary.
    let partialHeadFailure = HTApp
            (HTCon "First") (HTCon "not a type")
    case inhabitGeneratedPrepared defaultQueryOptions prepared []
        "partialHeadFailure" partialHeadFailure of
      Left message -> assertBool
        "a malformed argument overtook raw head saturation"
        $ "Type synonym First expects at least 2 argument(s), but got 1"
            `isInfixOf` message
      Right _ -> fail
        "a partial raw alias with a malformed argument reached proof search"

    -- A malformed constructor is not a candidate alias name. Ignore it only
    -- during this preflight walk so a later alias retains saturation
    -- precedence; structural conversion still owns the malformed name when
    -- no earlier compatibility rule fails.
    let malformedBeforeAlias = HTTuple
            [HTCon "not a type", HTCon "Identity"]
    case inhabitGeneratedPrepared defaultQueryOptions prepared []
        "malformedBeforeAlias" malformedBeforeAlias of
      Left message -> assertBool
        "raw name parsing stopped the saturation walk"
        $ "Type synonym Identity expects at least 1 argument(s), but got 0"
            `isInfixOf` message
      Right _ -> fail
        "a later unsaturated alias was hidden by raw name parsing"

    -- Ignoring a malformed spelling during alias lookup delegates rather than
    -- suppresses its error: with no later saturation failure, checked raw-type
    -- conversion remains the diagnostic owner.
    case inhabitGeneratedPrepared defaultQueryOptions prepared []
        "malformedOnly" (HTCon "not a type") of
      Left message -> assertBool "raw malformed-name ownership was lost"
        $ "InvalidHTypeName" `isInfixOf` message
      Right _ -> fail "a malformed raw constructor reached proof search"

    -- The joint batch sees the later partial alias during saturation, then the
    -- compatibility reporter retries each obligation to retain its precise
    -- source label. The earlier malformed goal must therefore remain the
    -- published failure rather than the context's joint-batch error.
    case inhabitGeneratedPrepared defaultQueryOptions prepared
        [context "ValueAlias" [HTCon "Identity"]]
        "firstInvalidObligation" (HTCon "not a type") of
      Left message -> do
        assertBool "an earlier malformed goal lost batch precedence"
            $ "InvalidHTypeName" `isInfixOf` message
        assertBool "a later context saturation error escaped the reporter"
            $ "Type synonym Identity" `notElemText` message
      Right _ -> fail "two invalid raw obligations reached proof search"

    -- Minimum saturation accepts extra arguments; the shared kind checker
    -- remains responsible for rejecting this proper-result synonym as a
    -- function. This is the raw PreparedEnvironment path, complementing the
    -- stable source-query boundary above.
    let overappliedIdentity = HTApp (identity boolType) voidType
    case inhabitGeneratedPrepared defaultQueryOptions prepared []
        "overappliedIdentity" overappliedIdentity of
      Left message -> do
        assertBool "raw prepared overapplication was called unsaturated"
            $ "expects at least" `notElemText` message
        assertBool "raw prepared overapplication skipped kind inference"
            $ "KindMismatch" `isInfixOf` message
      Right _ -> fail "an overapplied raw alias reached proof search"

    -- Context lookup and exact class arity precede every inspection of the
    -- goal tree, including an otherwise immediate alias-saturation failure.
    case inhabitGeneratedPrepared defaultQueryOptions prepared
        [context "ValueAlias" []]
        "classArityFirst" (HTCon "Identity") of
      Left message -> assertBool
        "goal saturation overtook class arity"
        $ "Class ValueAlias expects 1 type argument(s), but got 0"
            `isInfixOf` message
      Right _ -> fail "a bad raw class arity reached type checking"

    -- Raw callers historically resolve every context before inspecting the
    -- goal tree. Keep that observable order at the compatibility preflight:
    -- a declaration-only goal must not hide the more immediate missing-class
    -- error merely because the native worker accepts only shared source types.
    case inhabitGeneratedPrepared defaultQueryOptions prepared
        [context "MissingClass" []]
        "missingClassFirst" (HTUnion []) of
      Left message -> assertBool
        "raw goal projection overtook context lookup"
        $ "Class not found: MissingClass" `isInfixOf` message
      Right _ -> fail "a missing raw context class reached goal projection"

    targetName <- expectShownRight $
        SharedName.mkIdentifier "sharedPrecedence"
    checkedTarget <- expectShownRight $
        SharedGenerated.mkDefinitionName targetName
    missingClassName <- expectShownRight $
        SharedName.mkIdentifier "MissingClass"
    let invalidSharedGoal = SharedType.TupleType SharedName.Boxed
            [ SharedType.TypeConstructor $ sharedName "Identity"
            , SharedType.TypeVariable "A"
            ]
        missingSharedContext = Constraint missingClassName []
    case inhabitSynthesisResultPrepared defaultQueryOptions prepared
        [missingSharedContext] checkedTarget invalidSharedGoal of
      Left (DjinnQueryFailure message) -> assertBool
        "native type validation overtook context lookup"
        $ "Class not found: MissingClass" `isInfixOf` message
      result -> fail $ "native missing-class precedence changed: " ++ show result
    case inhabitSynthesisResultPrepared defaultQueryOptions prepared []
        checkedTarget invalidSharedGoal of
      Left (DjinnQueryFailure message) -> assertBool
        "native structural validation overtook synonym saturation"
        $ "Type synonym Identity expects at least 1 argument(s), but got 0"
            `isInfixOf` message
      result -> fail $ "native saturation precedence changed: " ++ show result
  where
    needle `notElemText` haystack = not $ needle `isInfixOf` haystack

-- Type synonyms are transparent even when they occur below an opaque type
-- constructor.  The whole opaque application remains one proposition, but
-- its atom name must use the normalized type rather than the surface alias.
testOpaqueAliasAtoms :: IO ()
testOpaqueAliasAtoms = do
    let definitions =
            [ ("Id", (["a"], HTVar "a", ()))
            , ("Pair", (["a"], HTTuple [HTVar "a", HTVar "a"], ()))
            , ("F", ([], HTAbstract "F" (KArrow KStar KStar), ()))
            ]
        app constructor argument = HTApp (HTCon constructor) argument
    assertEqual "an alias below an abstract constructor is transparent"
        (hTypeToFormula definitions $ app "F" $ HTVar "a")
        (hTypeToFormula definitions $ app "F" $ app "Id" $ HTVar "a")
    assertEqual "aliases normalize recursively below intrinsic applications"
        (hTypeToFormula definitions $ app "[]" $
            HTTuple [HTVar "b", HTVar "b"])
        (hTypeToFormula definitions $ app "[]" $ app "Pair" $ HTVar "b")

    let result = do
            idBody <- parseHType "a"
            goal <- parseHType "F (Id a) -> F a"
            environment <- declare
                (TypeSynonym "Id" ["a"] idBody) emptyEnvironment
            environment' <- declare
                (AbstractType "F" $ kArrow kStar kStar) environment
            inhabit defaultQueryOptions environment' [] "coerce" goal
    case result of
        Left message -> fail $ "opaque alias query failed: " ++ message
        Right report -> assertEqual
            "the normalized opaque application should admit identity"
            (Realized ["coerce a = a"]) (reportOutcome report)

-- The low-level translator is deliberately exposed for research clients, so
-- malformed caller-built tables must fail rather than relying on the checked
-- Environment facade to make them unreachable. Validate the whole first-
-- binding table: otherwise an unused cycle remains a latent divergence.
testRawTypeExpansionCycles :: IO ()
testRawTypeExpansionCycles = do
    let definition name parameters body = (name, (parameters, body, ()))
        apply constructor argument = HTApp (HTCon constructor) argument
        applications = foldl HTApp
        direct = [definition "A" [] $ HTCon "A"]
        mutual =
            [ definition "A" [] $ HTCon "B"
            , definition "B" [] $ HTCon "A"
            ]
        growing = [definition "A" ["a"] $
            apply "A" $ apply "[]" $ HTVar "a"]
        underSaturated = [definition "A" ["a"] $ HTCon "A"]
        overSaturated = [definition "A" [] $
            apply "A" $ HTCon "Bool"]
        higherOrder =
            [ definition "Apply" ["f", "a"] $
                HTApp (HTVar "f") (HTVar "a")
            , definition "A" ["a"] $
                HTApp (apply "Apply" $ HTCon "A") (HTVar "a")
            ]
        sourceOnly = [definition "S" ["f"] $
            HTApp (HTVar "f") (HTVar "f")]
        normalizationCycle =
            [ definition "S" ["f"] $
                HTApp (HTVar "f") (HTVar "f")
            , definition "A" [] $
                apply "S" $ HTCon "S"
            ]
        phantomCycle =
            [ definition "S" ["f"] $
                HTApp (HTVar "f") (HTVar "f")
            , definition "Phantom" ["unused"] $ HTCon "Bool"
            , definition "A" [] $
                apply "Phantom" $ apply "S" $ HTCon "S"
            ]
        wrappedNormalizationCycle =
            [ definition "S" ["f"] $
                HTApp (HTVar "f") (HTVar "f")
            , definition "Identity" ["a"] $ HTVar "a"
            , definition "A" [] $
                apply "Identity" $ apply "S" $ HTCon "S"
            ]
        lateNormalizationCycle =
            [ definition "S" ["f"] $
                HTApp (HTVar "f") (HTVar "f")
            , definition "D" [] $ HTUnion
                [("MkD", [HTCon "D", apply "S" $ HTCon "S"])]
            ]
        saturatedPrefixArrow =
            [ definition "->" [] $ HTUnion
                [("MkArrow", [HTCon "A"])]
            , definition "A" [] $
                applications (HTCon "->") [HTCon "X", HTCon "Y"]
            ]
        opaqueSourceOnly = definition "F" []
            (HTAbstract "F" $ KArrow KStar KStar) : sourceOnly
        directData = [definition "D" [] $
            HTUnion [("MkD", [HTCon "D"])]]
        mixed =
            [ definition "Alias" [] $ HTCon "D"
            , definition "D" [] $
                HTUnion [("MkD", [HTCon "Alias"])]
            ]
        opaqueDirect = definition "F" []
            (HTAbstract "F" $ KArrow KStar KStar) : direct

    assertLeftMessage "a direct synonym cycle is finite and diagnosed"
        "recursive type synonym: A"
        (hTypeToFormula direct $ HTCon "A")
    assertLeftMessage "a mutual synonym cycle has source-ordered names"
        "recursive type synonyms: A, B"
        (hTypeToFormula mutual $ HTCon "A")
    assertLeftMessage "a cycle below an opaque atom is diagnosed"
        "recursive type synonym: A"
        (hTypeToFormula opaqueDirect $
            apply "F" $ HTCon "A")
    assertLeftMessage "a growing synonym cycle cannot evade the SCC check"
        "recursive type synonym: A"
        (hTypeToFormula growing $ apply "A" $ HTVar "x")
    assertLeftMessage "an inert under-saturated raw cycle is rejected"
        "recursive type synonym: A"
        (hTypeToFormula underSaturated $ HTVar "unrelated")
    assertLeftMessage "an inert over-saturated raw cycle is rejected"
        "recursive type synonym: A"
        (hTypeToFormula overSaturated $ HTVar "unrelated")
    assertLeftMessage "higher-order substitution cannot create a hidden cycle"
        "recursive type synonym: A"
        (hTypeToFormula higherOrder $ apply "A" $ HTVar "x")
    sourceOnlyTranslate <- expectRight $
        prepareTypeFormulaTranslator sourceOnly
    assertLeftMessage "a source-created self-application cycle is diagnosed"
        "recursive type synonym expansion: S, S"
        (sourceOnlyTranslate $ apply "S" $ HTCon "S")
    opaqueSourceOnlyTranslate <- expectRight $
        prepareTypeFormulaTranslator opaqueSourceOnly
    assertLeftMessage "an opaque atom cannot hide a source-created cycle"
        "recursive type synonym expansion: S, S"
        (opaqueSourceOnlyTranslate $
            apply "F" $ apply "S" $ HTCon "S")
    assertLeftMessage "whole-table alias normalization is itself finite"
        "type definition A: recursive type synonym expansion: S, S"
        (hTypeToFormula normalizationCycle $ HTVar "unrelated")
    assertEqual "a phantom alias does not inspect its cyclic argument"
        (Right $ PVar $ Symbol "unrelated")
        (hTypeToFormula phantomCycle $ HTVar "unrelated")
    assertLeftMessage "a transparent wrapper retains the argument cycle path"
        "type definition A: recursive type synonym expansion: S, S"
        (hTypeToFormula wrappedNormalizationCycle $ HTVar "unrelated")
    assertLeftMessage "a late expansion error precedes a known structural edge"
        "type definition D: recursive type synonym expansion: S, S"
        (hTypeToFormula lateNormalizationCycle $ HTVar "unrelated")
    assertEqual "a saturated prefix arrow contributes no raw constructor edge"
        (Right $ PVar $ Symbol "unrelated")
        (hTypeToFormula saturatedPrefixArrow $ HTVar "unrelated")
    assertLeftMessage "an unused cycle invalidates the whole supplied table"
        "recursive type synonym: A"
        (hTypeToFormula direct $ HTVar "unrelated")
    assertLeftMessage "a directly recursive datatype is diagnosed"
        "recursive type definition: D"
        (hTypeToFormula directData $ HTCon "D")
    assertLeftMessage "an alias-datatype cycle is diagnosed after expansion"
        "recursive type definition: D"
        (hTypeToFormula mixed $ HTCon "Alias")

    let identity = [definition "Id" ["a"] $ HTVar "a"]
    assertEqual "finite repetition of one acyclic alias is not a cycle"
        (Right $ PVar $ Symbol "x")
        (hTypeToFormula identity $
            apply "Id" $ apply "Id" $ HTVar "x")

    -- A partial datatype supplied as a higher-kinded argument may be
    -- saturated inside another expansion. Distinct finite source occurrences
    -- and distinct instances of one cached definition body must not be
    -- mistaken for recursive use of the same occurrence.
    let higherKindedDefinitions =
            [ definition "D" ["f", "a"] $ HTUnion
                [("MkD", [HTApp (HTVar "f") (HTVar "a")])]
            , definition "Id" ["a"] $ HTVar "a"
            , definition "F" [] $
                HTAbstract "F" $ KArrow KStar KStar
            ]
        d arguments = applications (HTCon "D") arguments
        nestedD formula = Disj [(ConsDesc "MkD" 1, Conj [formula])]
    assertEqual "a finite nested partial datatype keeps source provenance"
        (Right $ nestedD $ nestedD $ PVar $ Symbol "F x")
        (hTypeToFormula higherKindedDefinitions $
            d [d [HTCon "F"], HTVar "x"])
    assertEqual "cached body occurrences are fresh for each finite instance"
        (Right $ nestedD $ nestedD $ nestedD $ PVar $ Symbol "x")
        (hTypeToFormula higherKindedDefinitions $
            d [d [HTCon "Id"], d [HTCon "Id", HTVar "x"]])

    let sourceLoopDefinitions =
            [ definition "S" ["f"] $
                HTApp (HTVar "f") (HTVar "f")
            , definition "D" ["f", "a"] $ HTUnion
                [("MkD", [HTApp (HTVar "f") (HTVar "a")])]
            ]
    assertLeftMessage "partial-application provenance still detects a loop"
        "recursive type definition expansion: D, S, D"
        (hTypeToFormula sourceLoopDefinitions $
            apply "S" $ d [HTCon "S"])

    -- Arbitrary raw inputs are not kind-checked and can encode untyped
    -- normalization. Re-entering one active source occurrence is therefore a
    -- deliberately conservative boundary: it rejects a finite but ill-kinded
    -- rewrite as well as non-repeating growth before either can diverge.
    let finiteReentryDefinitions =
            [ definition "A" ["f", "x"] $
                HTApp (HTApp (HTVar "f") (HTCon "C")) (HTVar "x")
            , definition "S" ["f", "x"] $
                HTApp (HTApp (HTVar "f") (HTVar "f")) (HTVar "x")
            ]
        growingSourceDefinitions =
            [ definition "S" ["f", "x"] $
                HTApp
                    (HTApp (HTVar "f") (HTVar "f"))
                    (apply "F" $ HTVar "x")
            ]
    assertLeftMessage "raw active-occurrence re-entry is conservative"
        "recursive type synonym expansion: A, A"
        (hTypeToFormula finiteReentryDefinitions $
            applications (HTCon "S") [HTCon "A", HTVar "y"])
    assertLeftMessage "growing untyped self-application is rejected early"
        "recursive type synonym expansion: S, S"
        (hTypeToFormula growingSourceDefinitions $
            applications (HTCon "S") [HTCon "S", HTVar "x"])

    -- Substitution may supply @(->)@ in function position, either directly or
    -- already applied to its domain. Both spellings must retain 'hTApp' arrow
    -- canonicalization while carrying argument-origin markers.
    let applyDefinitions =
            [ definition "Apply" ["f", "a"] $
                HTApp (HTVar "f") (HTVar "a")
            , definition "Apply2" ["f", "a", "b"] $
                HTApp (HTApp (HTVar "f") (HTVar "a")) (HTVar "b")
            ]
        argument = HTVar "x"
        result = HTVar "y"
        arrow = HTArrow argument result
        partialArrow = HTApp (HTCon "->") argument
        rawPrefixArrow = HTApp partialArrow result
    assertEqual "a direct raw prefix arrow retains its historical atom"
        (Right $ PVar $ Symbol "x -> y")
        (hTypeToFormula applyDefinitions rawPrefixArrow)
    assertEqual "a marked partial arrow remains a logical implication"
        (hTypeToFormula applyDefinitions arrow)
        (hTypeToFormula applyDefinitions $
            applications (HTCon "Apply") [partialArrow, result])
    assertEqual "a marked arrow constructor remains a logical implication"
        (hTypeToFormula applyDefinitions arrow)
        (hTypeToFormula applyDefinitions $
            applications (HTCon "Apply2")
                [HTCon "->", argument, result])

    -- Both expansion and cycle analysis follow association-list lookup: the
    -- unreachable duplicate must not poison a valid first definition.
    let firstWins =
            [ definition "A" [] $ HTCon "Bool"
            , definition "A" [] $ HTCon "A"
            ]
    assertEqual "cycle validation honors first-binding lookup semantics"
        (Right $ PVar $ Symbol "Bool")
        (hTypeToFormula firstWins $ HTCon "A")

-- Raw definition parameters predate checked declaration validation. Preserve
-- their historical first-binding behavior while covering an arity wide enough
-- to exercise the logarithmic substitution index rather than list position.
testRawExpansionSubstitution :: IO ()
testRawExpansionSubstitution = do
    let definition name parameters body = (name, (parameters, body, ()))
        applications = foldl HTApp
        duplicateParameters =
            [ definition "F" [] $
                HTAbstract "F" $ KArrow KStar KStar
            , definition "PickFirst" ["a", "a"] $ HTVar "a"
            ]
        duplicateArgument = applications (HTCon "PickFirst")
            [HTVar "x", HTVar "y"]
    assertEqual "duplicate raw parameters retain their first argument"
        (Right $ PVar $ Symbol "F x")
        (hTypeToFormula duplicateParameters $
            HTApp (HTCon "F") duplicateArgument)

    let indices = [0 .. 127] :: [Int]
        parameters = map (("p" ++) . show) indices
        argumentNames = map (("x" ++) . show) indices
        wideDefinition = [definition "Wide" parameters $
            HTTuple $ map HTVar $ reverse parameters]
        wideQuery = applications (HTCon "Wide") $
            map HTVar argumentNames
        expected = Conj $ map (PVar . Symbol) $ reverse argumentNames
    assertEqual "wide raw substitution preserves every parameter position"
        (Right expected)
        (hTypeToFormula wideDefinition wideQuery)

-- Raw Environment constructors remain available to explicit low-level
-- clients. Their checked preparation applies the same expand-first recursion
-- policy as neutral Djinn sessions: real data cycles receive bounded positive
-- lowering, while a phantom alias still erases a merely apparent surface edge.
testRawEnvironmentRecursionPreflight :: IO ()
testRawEnvironmentRecursionPreflight = do
    let direct = RawEnvironment.Environment
            [ ("D", ([], HTUnion [("MkD", [HTCon "D"])], KStar)) ]
            [] []
        mixed = RawEnvironment.Environment
            [ ("Alias", ([], HTCon "D", KStar))
            , ("D", ([], HTUnion [("MkD", [HTCon "Alias"])], KStar))
            ] [] []
        phantomUse = HTApp (HTCon "Phantom") (HTCon "D")
        phantom = RawEnvironment.Environment
            [ ("Bool", ([], HTAbstract "Bool" KStar, KStar))
            , ("Phantom", (["a"], HTCon "Bool", KArrow KStar KStar))
            , ("D", ([], HTUnion [("MkD", [phantomUse])], KStar))
            ] [] []
        higherKinded = RawEnvironment.Environment
            [ ("F", ([], HTAbstract "F" $ KArrow KStar KStar,
                KArrow KStar KStar))
            , ("D", (["f", "a"],
                HTUnion [("MkD", [HTApp (HTVar "f") (HTVar "a")])],
                KArrow (KArrow KStar KStar) $ KArrow KStar KStar))
            ] [] []

    directPrepared <- case prepareEnvironment direct of
        Left failure -> fail $ "direct raw data recursion was rejected: " ++
            show failure
        Right prepared -> pure prepared
    mixedPrepared <- case prepareEnvironment mixed of
        Left failure -> fail $
            "mixed raw alias/data recursion was rejected: " ++ show failure
        Right prepared -> pure prepared
    mapM_ (\(description, prepared) -> case
            inhabitGeneratedPrepared defaultQueryOptions prepared []
                "seedless" $ HTCon "D" of
        Left failure -> fail $ description ++ " did not terminate: " ++ failure
        Right report -> do
            assertEqual (description ++ " invented a seed") []
                $ generatedReportCandidates report
            assertEqual (description ++ " produced unsound negative evidence")
                SharedQuery.NoEvidence $ generatedReportEvidence report
            assertEqual (description ++ " did not exhaust its bounded plans")
                SharedSearch.Finished $ generatedReportCompletion report)
        [ ("direct raw recursive search", directPrepared)
        , ("alias-exposed raw recursive search", mixedPrepared)
        ]
    case prepareEnvironment phantom of
        Left failure -> fail $ "phantom alias invented raw recursion: " ++
            show failure
        Right _ -> return ()
    preparedHigherKinded <- case prepareEnvironment higherKinded of
        Left failure -> fail $ "valid higher-kinded data was rejected: " ++
            show failure
        Right prepared -> return prepared
    let applyMany = foldl HTApp
        partialD = applyMany (HTCon "D") [HTCon "F"]
        nestedGoal = applyMany (HTCon "D") [partialD, HTVar "x"]
    case inhabitGeneratedPrepared defaultQueryOptions
            preparedHigherKinded [] "nested" nestedGoal of
        Left failure -> fail $
            "cached formula translation rejected finite nesting: " ++ failure
        Right _ -> return ()
-- The recursion preflight may retain synonym declarations verbatim because
-- the prepared synonym table owns whole-table validation. Keep that ownership
-- explicit: even an otherwise unused bad synonym must fail in the first phase.
testPreparedSynonymValidationOwnership :: IO ()
testPreparedSynonymValidationOwnership = do
    let proper = KStar
        higherKind = KArrow (KArrow proper proper) proper
        pairKind = KArrow proper $ KArrow proper proper
        partialPair = HTApp (HTCon "Pair") (HTCon "Bool")
        environment = RawEnvironment.Environment
            [ ("Bool", ([], HTAbstract "Bool" proper, proper))
            , ("Higher", ([], HTAbstract "Higher" higherKind, higherKind))
            , ("Pair", (["a", "b"],
                HTTuple [HTVar "a", HTVar "b"], pairKind))
            , ("UnusedBad", ([],
                HTApp (HTCon "Higher") partialPair, proper))
            ] [] []
    case prepareEnvironment environment of
        Left (InvalidSynthesisTypeSynonyms
                (SharedTypeSynonym.UnsaturatedTypeSynonym name expected supplied)) -> do
            assertEqual "the prepared table identified the unused synonym"
                (sharedName "Pair") name
            assertEqual "the prepared table retained the declared arity"
                2 expected
            assertEqual "the prepared table retained the supplied arity"
                1 supplied
        Left failure -> fail $ "unused bad synonym produced the wrong failure: " ++
            show failure
        Right _ -> fail "an unused bad synonym reached recursion preflight"

-- The shared expansion error carries an index and subject, but the exported
-- raw Djinn API historically projects both synonym phases to this constructor.
testOperationalSynonymCompatibilityError :: IO ()
testOperationalSynonymCompatibilityError = do
    let proper = KStar
        pairKind = KArrow proper $ KArrow proper proper
        higherKind = KArrow pairKind proper
        environment = RawEnvironment.Environment
            [ ("Pair", (["a", "b"],
                HTTuple [HTVar "a", HTVar "b"], pairKind))
            , ("Higher", ([], HTAbstract "Higher" higherKind, higherKind))
            ]
            [("bad", HTApp (HTCon "Higher") $ HTCon "Pair")] []
    case prepareEnvironment environment of
        Left (InvalidSynthesisTypeSynonyms
                (SharedTypeSynonym.UnsaturatedTypeSynonym
                  name expected supplied)) -> do
            assertEqual "the alias identity is retained" (sharedName "Pair") name
            assertEqual "the declared arity is retained" 2 expected
            assertEqual "the supplied arity is retained" 0 supplied
        Left failure -> fail $
            "operational alias produced the wrong raw failure: " ++ show failure
        Right _ -> fail "an unsaturated value alias reached Djinn sealing"

-- Grounding must recursively eliminate every unification variable.  Foo's
-- inferred kind is reused after kind inference has reset its local IntMap;
-- leaving a KVar behind used to make this second check crash at IntMap.!
testHigherKindedGrounding :: IO ()
testHigherKindedGrounding = do
    checked <- checkedKindEnvironment
    let expectedFooKind = KArrow (KArrow KStar KStar) (KArrow KStar KStar)
        actualFooKind = lookup "Foo"
            [(name, kind) | (name, (_, _, kind)) <- checked]
        fooMaybeBool = HTApp (HTApp (HTCon "Foo") (HTCon "Maybe")) (HTCon "Bool")
    assertEqual "Foo f a = f a has kind (* -> *) -> * -> *"
        (Just expectedFooKind) actualFooKind
    assertEqual "a grounded higher kind remains usable in a later check"
        (Right ()) (htCheckType checked (HTArrow fooMaybeBool fooMaybeBool))

testIllKindedApplication :: IO ()
testIllKindedApplication = do
    checked <- checkedKindEnvironment
    let fooBoolBool = HTApp (HTApp (HTCon "Foo") (HTCon "Bool")) (HTCon "Bool")
    assertLeft "Foo's first argument must have kind * -> *"
        (htCheckType checked fooBoolBool)

testHigherKindedSynonymBody :: IO ()
testHigherKindedSynonymBody =
    assertLeft "an ordinary synonym body must have result kind *"
        (htCheckEnv
            [("Endo", (["a"], HTApp (HTCon "->") (HTVar "a"), ()))])

-- Class parameter kinds come from the method types (Haskell98 style) and
-- default to * when unconstrained, including for method-less classes.
-- Class arguments must then fit the inferred parameter kind, closing the
-- historical hole where `class Empty a where` accepted any argument.
testClassParameterKinds :: IO ()
testClassParameterKinds = do
    checked <- checkedKindEnvironment
    let m = HTVar "m"
        a = HTVar "a"
        b = HTVar "b"
        ma = HTApp m a
        mb = HTApp m b
        monadMethods =
            [ HTArrow a ma
            , HTArrow ma (HTArrow (HTArrow a mb) mb)
            ]
    assertEqual "Monad's parameter must infer to * -> *"
        (Right [("m", KArrow KStar KStar)])
        (htInferClassKinds checked ["m"] monadMethods)
    assertEqual "a method-less class parameter defaults to *"
        (Right [("phantom", KStar)])
        (htInferClassKinds checked ["phantom"] [])
    assertLeft "a method type that misuses a parameter is rejected"
        (htInferClassKinds checked ["c"]
            [HTArrow (HTVar "c") (HTApp (HTVar "c") a)])
    assertEqual "method-local variables have independent kind scopes"
        (Right [("a", KStar)])
        (htInferClassKinds checked ["a"]
            [HTApp (HTVar "f") (HTVar "a"), HTVar "f"])
    assertLeft "one method still shares repeated occurrences of its local" $
        htInferClassKinds checked ["a"]
            [HTTuple [HTApp (HTVar "f") (HTVar "a"), HTVar "f"]]
    assertRight "a proper-type argument fits kind *"
        (htCheckTypeKind checked KStar (HTCon "Bool"))
    assertRight "a variable argument fits any kind"
        (htCheckTypeKind checked (KArrow KStar KStar) (HTVar "f"))
    assertRight "a constructor fits its higher kind"
        (htCheckTypeKind checked (KArrow KStar KStar) (HTCon "Maybe"))
    assertLeft "an ill-kinded application is rejected even against *"
        (htCheckTypeKind checked KStar (HTApp (HTCon "Bool") a))
    assertLeft "a kind-mismatched argument is rejected"
        (htCheckTypeKind checked (KArrow KStar KStar) (HTCon "Bool"))
    assertLeft "joint checks share the kind of a free variable"
        (htCheckTypesKinds checked
            [ (KStar, HTVar "shared")
            , (KArrow KStar KStar, HTVar "shared")
            ])

checkedKindEnvironment :: IO [(HSymbol, ([HSymbol], HType, HKind))]
checkedKindEnvironment =
    case htCheckEnv kindDefinitions of
        Left message -> fail $ "kind environment was rejected: " ++ message
        Right checked -> return checked

kindDefinitions :: [(HSymbol, ([HSymbol], HType, ()))]
kindDefinitions =
    [ ( "Foo"
      , (["f", "a"], HTApp (HTVar "f") (HTVar "a"), ())
      )
    , ( "Maybe"
      , ( ["a"]
        , HTUnion [("Nothing", []), ("Just", [HTVar "a"])]
        , ()
        )
      )
    , ( "Bool"
      , ([], HTUnion [("False", []), ("True", [])], ())
      )
    ]

testProvableBasics :: IO ()
testProvableBasics =
    mapM_ (uncurry assertTrue)
        [ ("identity", atomA :-> atomA)
        , ("conjunction commutes", (atomA & atomB) :-> (atomB & atomA))
        , ( "conjunction commutes for nested implications"
          , (nested & atomA) :-> (atomA & nested)
          )
        , ("a value injects into a disjunction", atomA :-> (atomA |: atomB))
        , ("false eliminates", false :-> atomA)
        ]
  where
    assertTrue name formula = assertBool name (provable formula)
    nested = fnot $ fnot $ Empty $ Symbol "EmptyA"

-- The goal of the double negation of excluded middle reduces to Void with
-- contradictory antecedents.  redsucc must route an Empty goal through the
-- same fresh-atom encoding as a disjunction; rejecting it outright (mzero)
-- silently lost every theorem whose final goal is an empty type.
testEmptyGoalContradiction :: IO ()
testEmptyGoalContradiction = do
    let assertProvableAndChecked name goal =
            case prove False [] goal of
                [] -> fail $ name ++ " must be provable"
                proof : _ ->
                    assertRight
                        (name ++ ": the proof must check against its formula")
                        (checkProof [] goal proof)
    assertProvableAndChecked "Not (Not (Either a (Not a)))" $
        fnot $ fnot $ atomA |: fnot atomA
    -- QuickCheck-discovered case: the proof feeds one ex falso result into
    -- another, leaving an interior proof type free.  The checker must
    -- default that empty-eliminator input rather than reject the proof
    -- as ambiguous.
    let nested = (atomA :-> atomA) :-> Conj [atomB]
    assertProvableAndChecked "Not x -> Not c -> Not (Either x c)" $
        fnot nested :-> (fnot atomC :-> fnot (nested |: atomC))
    -- Raw internal clients can still construct the old structural encoding
    -- of false.  It eliminates into nominal Void, but is not definitionally
    -- identical to it and therefore needs an explicit empty-case term.
    let structuralToNominal = Disj [] :-> false
    case prove False [] structuralToNominal of
        [proof@(Lam binder (Apply (Ccases []) (Var used)))] -> do
            assertEqual "empty elimination must consume its premise" binder used
            assertRight "the structural-to-nominal proof must check" $
                checkProof [] structuralToNominal proof
            assertRendered "structural false should render as an empty case"
                "eliminate a = case a of {}" "eliminate" proof
        proofs -> fail $ "expected one structural empty eliminator, got " ++
            show proofs

testNonTheorems :: IO ()
testNonTheorems =
    mapM_ (uncurry assertFalse)
        [ ("an unconstrained atom", atomA)
        , ("Peirce's law is not intuitionistic", ((atomA :-> atomB) :-> atomA) :-> atomA)
        ]
  where
    assertFalse name formula = assertBool name (not $ provable formula)

testSearchModes :: IO ()
testSearchModes = do
    let peirce = ((atomA :-> atomB) :-> atomA) :-> atomA
        pick3 = atomA :-> (atomA :-> (atomA :-> atomA))
        unlimited = defaultSearchMode True
        run mode = proveWithMode mode []

    -- A finished search decides; it is never marked exhausted.
    let complete = run unlimited peirce
    assertEqual "a finished search refutes a non-theorem"
        [] (searchProofs complete)
    assertBool "a finished search must not be marked exhausted" $
        not (searchExhausted complete)
    assertEqual "an unlimited search has no finite fuel remainder"
        Nothing (remainingSearchBudget complete)

    -- A zero budget cannot decide anything that branches.
    let starved = run unlimited { searchBudget = Just 0 } peirce
    assertEqual "a starved search finds nothing" [] (searchProofs starved)
    assertBool "an expired budget must be reported" $ searchExhausted starved
    assertEqual "an expired search has no fuel left"
        (Just 0) (remainingSearchBudget starved)

    -- Internal callers can construct SearchMode directly.  Treat a negative
    -- budget as already expired rather than accidentally making it unlimited.
    let invalidBudget = run unlimited { searchBudget = Just (-1) } peirce
    assertEqual "a negative internal budget finds nothing"
        [] (searchProofs invalidBudget)
    assertBool "a negative internal budget must be reported as expired" $
        searchExhausted invalidBudget
    assertEqual "expired negative fuel is normalized to zero"
        (Just 0) (remainingSearchBudget invalidBudget)
    let immediateWithNegativeFuel =
            run unlimited { searchBudget = Just (-1) } (Conj [])
    assertEqual "a zero-step proof remains available at zero normalized fuel"
        [Ctuple 0] (searchProofs immediateWithNegativeFuel)
    assertBool "a zero-step proof does not exhaust normalized fuel" $
        not (searchExhausted immediateWithNegativeFuel)
    assertEqual "even a finished zero-step search reports non-negative fuel"
        (Just 0) (remainingSearchBudget immediateWithNegativeFuel)

    -- A complete refutation reports exactly the fuel that a diagnostic
    -- follow-up may spend without exceeding the original query budget.
    let atomicRefutation =
            run unlimited { searchBudget = Just 1 } atomA
    assertEqual "one choice point suffices to refute an unconstrained atom"
        [] (searchProofs atomicRefutation)
    assertBool "the one-step atomic refutation is complete" $
        not (searchExhausted atomicRefutation)
    assertEqual "the atomic refutation spends its complete budget"
        (Just 0) (remainingSearchBudget atomicRefutation)

    -- A bounded depth-first search yields a prefix of the unbounded stream.
    let full = searchProofs $ run unlimited pick3
        bounded = run unlimited { searchBudget = Just 1 } pick3
    assertBool "bounded proofs must be a prefix of the unbounded stream" $
        searchProofs bounded `isPrefixOf` full
    assertBool "the pick-3 space is larger than one step" $
        searchExhausted bounded
    assertEqual "bounded alternative search consumes all available fuel"
        (Just 0) (remainingSearchBudget bounded)

    -- Interleaving may reorder proofs but proves and refutes the same
    -- formulas over a finite space.
    let fair = unlimited { searchStrategy = Interleave }
    assertBool "interleaved search still refutes Peirce's law" $
        null $ searchProofs $ run fair peirce
    assertEqual "interleaved search finds the same pick-3 proof set"
        (sort full) (sort $ searchProofs $ run fair pick3)

-- A query carries the strategy the prover has always accepted: the default
-- stays the historical depth-first order, and the alternative reaches search
-- without changing which formulas are inhabited.
testQueryOptionsStrategy :: IO ()
testQueryOptionsStrategy = do
    assertEqual "a query defaults to the historical strategy"
        DepthFirst (optionStrategy defaultQueryOptions)
    let goal = HTArrow (HTVar "a") (HTArrow (HTVar "a") (HTVar "a"))
        spellings strategy = sort $ map show $ either (const []) id
            (generatedReportCandidates <$> inhabitGenerated
                defaultQueryOptions
                    { optionAlternatives = True
                    , optionSorted = False
                    , optionStrategy = strategy
                    }
                standardEnvironment [] "pick" goal)
    assertEqual "both strategies inhabit the same query"
        (spellings DepthFirst) (spellings Interleave)
    assertBool "a strategy reaches search rather than being ignored" $
        not $ null $ spellings Interleave

-- A curried premise with repeated domains used to exhaust the complete
-- subtree for its first atom proof before trying a second proof at the next
-- argument.  Two ordinary unary premises are enough to push @combine x y@
-- beyond a sixty-candidate client window even though @combine x x@ appears
-- first.  The repeated-domain branch should instead expose both the direct
-- repeated and distinct applications before exhausting derived compositions.
testDistinctCurriedArguments :: IO ()
testDistinctCurriedArguments = do
    let combine = atomA :-> atomA :-> atomA
        distractor = atomA :-> atomA
        goal = foldr (:->) atomA
            [atomA, atomA, combine, distractor, distractor]
        proofs = prove True [] goal
        isRepeated proof = case proof of
            Lam first (Lam _ (Lam function
                    (Lam _ (Lam _ body)))) ->
                body == Apply (Apply (Var function) (Var first)) (Var first)
            _ -> False
        isMixed proof = case proof of
            Lam first (Lam second (Lam function
                    (Lam _ (Lam _ body)))) ->
                body == Apply (Apply (Var function) (Var first)) (Var second)
            _ -> False
        prefix = take 20 proofs
        mixed = [(index, proof) |
            (index, proof) <- zip [(1 :: Int) ..] prefix, isMixed proof]
        repeated = [index |
            (index, proof) <- zip [(1 :: Int) ..] prefix, isRepeated proof]
    case (mixed, repeated) of
        ((mixedIndex, proof) : _, repeatedIndex : _) -> do
            assertBool "distinct evidence should precede repeated evidence" $
                mixedIndex < repeatedIndex
            assertRight
                "the early distinct-argument proof must check independently"
                (checkProof [] goal proof)
        ([], _) -> fail "the first twenty proofs omitted the mixed application"
        (_, []) -> fail "the first twenty proofs omitted the repeated application"

testThreeWayCurriedArguments :: IO ()
testThreeWayCurriedArguments = do
    let combine = atomA :-> atomA :-> atomA
        distractor = atomA :-> atomA
        goal = foldr (:->) atomA
            [atomA, atomA, atomA, combine, distractor, distractor]
        proofs = prove True [] goal
        directPairs :: Proof -> [(Int, Int)]
        directPairs proof = case proof of
            Lam first (Lam second (Lam third (Lam function
                    (Lam _ (Lam _ body))))) ->
                [(leftIndex, rightIndex) |
                    (leftIndex, left) <- zip [0 ..] [first, second, third],
                    (rightIndex, right) <- zip [0 ..] [first, second, third],
                    body == Apply (Apply (Var function) (Var left)) (Var right)]
            _ -> []
        expectedPairs = [(left, right) | left <- [0 .. 2], right <- [0 .. 2]]
        prefix = take 60 proofs
        observedPairs = concatMap directPairs prefix
        bounded = proveWithMode
            (defaultSearchMode True) { searchBudget = Just 120 } [] goal
        boundedPairs = concatMap directPairs (searchProofs bounded)
    assertBool "the sixty-candidate window omitted a direct sibling pair" $
        all (`elem` observedPairs) expectedPairs
    assertBool "the bounded search omitted a direct sibling pair" $
        all (`elem` boundedPairs) expectedPairs
    assertBool "the bounded repeated-domain search should remain truncated" $
        searchExhausted bounded
    assertEqual "the bounded repeated-domain search should spend its fuel"
        (Just 0) (remainingSearchBudget bounded)
    let usesFirstAndThird proof = (0, 2) `elem` directPairs proof
    case filter usesFirstAndThird prefix of
        proof : _ -> assertRight
            "the early third-sibling proof must check independently"
            (checkProof [] goal proof)
        [] -> fail "the first sixty proofs omitted the third atom sibling"

testWideCurriedArguments :: IO ()
testWideCurriedArguments = do
    let combine = atomA :-> atomA :-> atomA
        goal = foldr (:->) atomA
            [atomA, atomA, atomA, atomA, combine]
        directPairs :: Proof -> [(Int, Int)]
        directPairs proof = case proof of
            Lam first (Lam second (Lam third (Lam fourth
                    (Lam function body)))) ->
                [(leftIndex, rightIndex) |
                    (leftIndex, left) <-
                        zip [0 ..] [first, second, third, fourth],
                    (rightIndex, right) <-
                        zip [0 ..] [first, second, third, fourth],
                    body == Apply (Apply (Var function) (Var left)) (Var right)]
            _ -> []
        applications = take 9
            [pair | proof <- prove True [] goal, pair <- directPairs proof]
        expectedPairs =
            [(left, right) | left <- [0 .. 2], right <- [0 .. 2]]
    assertEqual "the fair cohort should contain exactly the oldest three proofs"
        (sort expectedPairs) (sort applications)

-- The local rotation is not a general repeated-domain scheduler.  In
-- particular, changing the result atom makes this @A -> A -> B@ rather than
-- the exact binary endomorphism shape, so DepthFirst must retain its historical
-- left-argument-major traversal across all four available A proofs.
testNonEndomorphicCurriedArguments :: IO ()
testNonEndomorphicCurriedArguments = do
    let combine = atomA :-> atomA :-> atomB
        goal = foldr (:->) atomB
            [atomA, atomA, atomA, atomA, combine]
        directPairs :: Proof -> [(Int, Int)]
        directPairs proof = case proof of
            Lam first (Lam second (Lam third (Lam fourth
                    (Lam function body)))) ->
                [(leftIndex, rightIndex) |
                    (leftIndex, left) <-
                        zip [0 ..] [first, second, third, fourth],
                    (rightIndex, right) <-
                        zip [0 ..] [first, second, third, fourth],
                    body == Apply (Apply (Var function) (Var left)) (Var right)]
            _ -> []
        applications =
            [pair | proof <- prove True [] goal, pair <- directPairs proof]
        expectedPairs =
            [(left, right) | left <- [0 .. 3], right <- [0 .. 3]]
        -- Each direct application is reached through both the immediate and
        -- indexed implication paths; the historical DFS order keeps those
        -- twins adjacent before advancing the right-hand atom.
        expectedApplications = concatMap (replicate 2) expectedPairs
    assertEqual "non-endomorphic repeated domains must remain row-major"
        expectedApplications applications

-- DepthFirst deliberately leaves evidence after the oldest three proofs on a
-- classical tail.  Global Interleave must still alternate into that tail; this
-- finite prefix check ensures the fourth proof is reachable rather than merely
-- present somewhere in an unforced, potentially starved search space.
testInterleavedWideCurriedArguments :: IO ()
testInterleavedWideCurriedArguments = do
    let combine = atomA :-> atomA :-> atomA
        goal = foldr (:->) atomA
            [atomA, atomA, atomA, atomA, combine]
        mode = (defaultSearchMode True) { searchStrategy = Interleave }
        directPairs :: Proof -> [(Int, Int)]
        directPairs proof = case proof of
            Lam first (Lam second (Lam third (Lam fourth
                    (Lam function body)))) ->
                [(leftIndex, rightIndex) |
                    (leftIndex, left) <-
                        zip [0 ..] [first, second, third, fourth],
                    (rightIndex, right) <-
                        zip [0 ..] [first, second, third, fourth],
                    body == Apply (Apply (Var function) (Var left)) (Var right)]
            _ -> []
        prefix = take 60 $ searchProofs $ proveWithMode mode [] goal
        fourthApplications =
            [(proof, pair) |
                proof <- prefix,
                pair@(left, right) <- directPairs proof,
                left == 3 || right == 3]
    case fourthApplications of
        (proof, _) : _ -> assertRight
            "the interleaved fourth-proof application must check independently"
            (checkProof [] goal proof)
        [] -> fail $ "the first sixty interleaved proofs omitted the " ++
            "fourth-proof tail"

testNamedAssumption :: IO ()
testNamedAssumption = do
    let assumption = Symbol "givenA"
    assertEqual "proof search should preserve the assumption's term symbol"
        [Var assumption] (prove False [(assumption, atomA)] atomA)

testCheckedProofSearchEnvironment :: IO ()
testCheckedProofSearchEnvironment = do
    let duplicate = Symbol "given"
        environment = [(duplicate, atomA), (duplicate, atomB)]
        mode = defaultSearchMode False
        checked = void $
            proveWithModeChecked mode environment atomA
    assertEqual "search and proof checking share the duplicate diagnostic"
        (checkProof environment atomA $ Var duplicate)
        checked
    assertEqual "the checked boundary reports the ambiguous identity"
        (Left "duplicate proof identity in environment: given")
        checked
    case proveWithModeChecked mode [(duplicate, atomA)] atomA of
        Left failure -> fail $
            "a unique proof environment was rejected: " ++ failure
        Right outcome ->
            assertEqual "checked search preserves ordinary proof results"
                [Var duplicate] (searchProofs outcome)
    -- Keep the historical unchecked API source- and behavior-compatible for
    -- callers that deliberately own its association-list invariant.
    assertEqual "historical search retains first-match compatibility"
        [Var duplicate]
        (prove False environment atomA)

-- The generated binder for b must not reuse x2.  Reuse changed the intended
-- constant function into the ill-typed identity `f a = a` during rendering.
testCallerSymbolCapture :: IO ()
testCallerSymbolCapture = do
    let caller = Symbol "x2"
        proofs = prove False [(caller, atomA)] (atomB :-> atomA)
    case proofs of
        [] -> fail "expected b -> a to be realizable from x2 :: a"
        proof : _ ->
            assertRendered "the rendered proof must refer to the caller's x2"
                "f _ = x2" "f" proof

-- The continuation atom introduced while proving a disjunction lives in the
-- same Symbol namespace as caller formula atoms.  `_2` in the environment is
-- unrelated to a or b and must not accidentally make their disjunction true.
testContinuationAtomCapture :: IO ()
testContinuationAtomCapture =
    assertEqual "an unrelated _2 assumption cannot prove a | b"
        [] (prove False [(Symbol "u", PVar $ Symbol "_2")] (atomA |: atomB))

testCsplitResidualArguments :: IO ()
testCsplitResidualArguments = do
    let left = Symbol "left"
        right = Symbol "right"
        handler = Lam left $ Lam right $
            applys (Var $ Symbol "combine") [Var left, Var right]
        term = applys (Csplit 2)
            [ handler
            , Var $ Symbol "pair"
            , Var $ Symbol "arg1"
            , Var $ Symbol "arg2"
            ]
    rendered <- renderTerm "f" term
    assertContains "Csplit should still render its tuple case" "case pair of" rendered
    assertWordsSuffix "Csplit residual arguments must retain left-to-right order"
        ["arg1", "arg2"] rendered

testCsplitResidualHandlerLambda :: IO ()
testCsplitResidualHandlerLambda = do
    let field = Symbol "field"
        argument = Symbol "argument"
        handler = Lam field $ Lam argument $
            applys (Var $ Symbol "combine") [Var field, Var argument]
        term = applys (Csplit 1)
            [handler, Var $ Symbol "payload"]
    assertRendered "Csplit consumes only its requested handler prefix"
        ("f a =\n" ++
          "  case payload of\n" ++
          "  b -> combine b a")
        "f" term

-- If a split handler returns the original product, its component patterns are
-- unused but the as-binder is not.  Simplifying @pair@_@ to @_@ used to emit a
-- typed hole; it must simplify to the still-bound @pair@ instead.
testCsplitProductIdentity :: IO ()
testCsplitProductIdentity = do
    let pair = Symbol "pair"
        left = Symbol "left"
        right = Symbol "right"
        term = Lam pair $ applys (Csplit 2)
            [Lam left $ Lam right $ Var pair, Var pair]
        formula = (atomA & atomB) :-> (atomA & atomB)
    assertRight "the raw product identity must be a valid proof" $
        checkProof [] formula term
    assertRendered "an as-pattern over wildcards must retain its binder"
        "identity a = a" "identity" term

-- A unary constructor field arrives as a 1-ary split.  Haskell has no
-- 1-tuples, so the field must bind as `Wrap a`, not as `Wrap (a)`.
testUnaryConstructorPattern :: IO ()
testUnaryConstructorPattern = do
    let payload = Symbol "payload"
        field = Symbol "field"
        handler = Lam payload $ applys (Csplit 1)
            [ Lam field $ Apply (Var $ Symbol "use") (Var field)
            , Var payload
            ]
        term = applys (Ccases [ConsDesc "Wrap" 1])
            [Var $ Symbol "value", handler]
    rendered <- renderTerm "unwrap" term
    assertContains "a unary constructor field binds the payload directly"
        "Wrap a" rendered
    assertBool "no singleton tuple pattern may remain in the output" $
        not $ "(a)" `isInfixOf` rendered

testCcasesResidualArguments :: IO ()
testCcasesResidualArguments = do
    let leftConstructor = ConsDesc "LeftC" 1
        rightConstructor = ConsDesc "RightC" 1
        left = Symbol "leftPayload"
        right = Symbol "rightPayload"
        leftHandler = Lam left $ Apply (Var $ Symbol "onLeft") (Var left)
        rightHandler = Lam right $ Apply (Var $ Symbol "onRight") (Var right)
        term = applys (Ccases [leftConstructor, rightConstructor])
            [ Var $ Symbol "choice"
            , leftHandler
            , rightHandler
            , Var $ Symbol "arg1"
            , Var $ Symbol "arg2"
            ]
    rendered <- renderTerm "f" term
    assertContains "Ccases should still render its scrutiny" "case choice of" rendered
    assertContains "Ccases should retain its first alternative" "LeftC" rendered
    assertContains "Ccases should retain its second alternative" "RightC" rendered
    assertWordsSuffix "Ccases residual arguments must not be dropped or reordered"
        ["arg1", "arg2"] rendered

-- Case cleanup commutes a lambda shared by every alternative out of the case.
-- The first branch below discards that argument while the second uses it.
-- Choosing the first branch's wildcard as the common name used to substitute
-- the live occurrence with @_@ and make this valid proof unrenderable.
testMixedCaseLambdaBinders :: IO ()
testMixedCaseLambdaBinders = do
    let choice = Symbol "choice"
        ignored = Symbol "ignored"
        used = Symbol "used"
        argument = Symbol "argument"
        live = Symbol "live"
        nothing = ConsDesc "Nothing" 0
        just = ConsDesc "Just" 1
        constructors = [nothing, just]
        term = Lam choice $ applys (Ccases constructors)
            [ Var choice
            , Lam ignored $ Lam argument $ Ctuple 0
            , Lam used $ Lam live $ Apply (Var used) (Var live)
            ]
        formula = Disj
            [ (nothing, true)
            , (just, atomA :-> true)
            ] :-> atomA :-> true
        expected = "minimal a b =\n" ++
            "  case a of\n" ++
            "  Nothing -> ()\n" ++
            "  Just c -> c b"
    assertRight "the mixed-binder term must independently type-check" $
        checkProof [] formula term
    assertRendered "a live branch binder must not become a typed hole"
        expected "minimal" term

testUnaryTuplePayload :: IO ()
testUnaryTuplePayload = do
    let constructor = ConsDesc "Only" 1
        payload = Symbol "payload"
        left = Symbol "left"
        right = Symbol "right"
        handler = Lam payload $ applys (Csplit 2)
            [ Lam left $ Lam right $ Apply (Var $ Symbol "consume") $
                applys (Ctuple 2) [Var left, Var right]
            , Var payload
            ]
        term = applys (Ccases [constructor])
            [Var $ Symbol "value", handler]
    rendered <- renderTerm "unwrap" term
    assertContains "the tuple must remain one constructor field"
        "Only (a, b)" rendered

testBranchRefinements :: IO ()
testBranchRefinements = do
    let outer = Symbol "outer"
        choice = Symbol "choice"
        shared = Symbol "shared"
        leftConstructor = ConsDesc "LeftC" 1
        rightConstructor = ConsDesc "RightC" 1
        splitShared prefix =
            let first = Symbol $ prefix ++ "First"
                second = Symbol $ prefix ++ "Second"
            in applys (Csplit 2)
                [ Lam first $ Lam second $
                    applys (Ctuple 2) [Var first, Var second]
                , Var shared
                ]
        body = applys (Ccases [leftConstructor, rightConstructor])
            [ Var choice
            , Lam (Symbol "leftPayload") $ splitShared "left"
            , Lam (Symbol "rightPayload") $ splitShared "right"
            ]
        term = Lam outer $ applys (Csplit 2)
            [Lam choice $ Lam shared body, Var outer]
    _ <- renderTerm "mergeBranches" term
    return ()

-- A disjunction handler receives one logical payload value.  For a constructor
-- with several Haskell fields that value is their tuple, so a handler that
-- returns it whole must bind the fields and reconstruct the tuple explicitly.
testWholeConstructorPayload :: IO ()
testWholeConstructorPayload = do
    let constructor = ConsDesc "C" 2
        payload = Conj [atomA, atomB]
        formula = Disj [(constructor, payload)] :-> payload
        proofs = prove True [] formula
        expected = "f a =\n" ++
            "  case a of\n" ++
            "  C b c -> (b, c)"
    assertEqual "the theorem should expose both proof-search alternatives"
        2 (length proofs)
    rendered <- mapM (renderTerm "f") proofs
    assertEqual "every alternative must reconstruct the constructor payload"
        [expected, expected] rendered
    assertBool "no alpha-renamed implementation binder may escape" $
        all (not . isInfixOf "__djinn") rendered

    let beyondMachineCount = fromIntegral (maxBound :: Int) + 1 :: Natural
    assertBool "candidate ordering retains binder counts beyond Int" $
        DjinnCandidateDetails 0 beyondMachineCount <
            DjinnCandidateDetails 0 (beyondMachineCount + 1)

    goal <- either fail return $ parseHType "T a b -> (a, b)"
    environment <- either fail return $
        declare (DataType "T" ["a", "b"]
            [("C", [HTVar "a", HTVar "b"])]) emptyEnvironment
    let options = defaultQueryOptions {
            optionAlternatives = True,
            optionSorted = False
            }
        oneCandidate = options {optionCutoff = 1}
        allCandidates = options {optionCutoff = 2}
    limited <- either fail return $
        inhabitGenerated oneCandidate environment [] "f" goal
    assertEqual "the first canonical candidate survives the cutoff"
        1 (length $ generatedReportCandidates limited)
    assertEqual "stopping before another proof is a candidate truncation"
        (SharedSearch.truncated SharedSearch.CandidateLimitReached)
        (generatedReportCompletion limited)
    complete <- either fail return $
        inhabitGenerated allCandidates environment [] "f" goal
    assertEqual "exhausting both proofs completes the canonical search"
        SharedSearch.Finished (generatedReportCompletion complete)
    maximumCutoff <- either fail return $ inhabitGenerated
        options {optionCutoff = maxBound} environment [] "f" goal
    assertEqual "the largest valid cutoff does not overflow its witness bound"
        SharedSearch.Finished (generatedReportCompletion maximumCutoff)
    case generatedReportCandidates complete of
        [candidate] -> do
            assertEqual "equivalent proofs are de-duplicated canonically"
                (Right expected) $ SharedGenerated.renderFunctionClause
                    (SharedGenerated.defaultRenderOptions id)
                    (SharedCandidate.candidateOutput candidate)
            assertEqual "Djinn discharges every candidate constraint"
                [] $ SharedCandidate.candidateResidualConstraints candidate
            let details = SharedCandidate.candidateDetails candidate
            assertEqual "the candidate uses every generated binder"
                0 $ djinnUnusedBinderFraction details
            assertEqual "ranking accounts for argument and case binders"
                3 $ djinnBinderCount details
        candidates -> fail $ "expected one canonical candidate, got " ++
            show (length candidates)
    report <- either fail return $
        inhabit options environment [] "f" goal
    assertEqual "the public boundary should de-duplicate equivalent clauses"
        (Realized [expected]) (reportOutcome report)

testResolveInstanceMethods :: IO ()
testResolveInstanceMethods = do
    let parameter = HTVar "f"
        local = HTVar "a"
        applied = HTApp parameter local
        valueClass = ClassDecl "Value" ["a"] []
        higherClass = ClassDecl "Higher" ["f"]
            [("use", HTArrow applied applied)]
    environment <- expectRight $ do
        withValue <- declare valueClass standardEnvironment
        declare higherClass withValue

    let target = context "Higher" [HTCon "Maybe"]
    assertEqual "joint resolution preserves exact target method substitution"
        (resolveContext environment target)
        (resolveInstanceMethods environment [] target)

    assertLeftContains
        "an instance head and its prerequisites share kind variables"
        "argument f of class Higher" $
        resolveInstanceMethods environment
            [context "Value" [HTVar "f"], context "Higher" [HTVar "f"]]
            (context "Value" [HTVar "x"])

    -- A method-local variable with the same spelling as an instance argument
    -- must not be captured by class-parameter substitution.
    captureEnvironment <- expectRight $
        declare (ClassDecl "Capture" ["a"]
            [("capture", HTApp (HTVar "f") (HTVar "a"))]) environment
    let capture = context "Capture" [HTVar "f"]
    assertEqual "context instantiation alpha-renames a captured method local"
        (Right [("capture", HTApp (HTVar "f'") (HTVar "f"))])
        (resolveContext captureEnvironment capture)
    safe <- expectRight $ inhabit defaultQueryOptions captureEnvironment
        [capture] "safe" (HTArrow (HTVar "x") (HTVar "x"))
    assertEqual "an unused capture-safe context does not poison a query"
        (Realized ["safe a = a"]) (reportOutcome safe)

    -- Identical local spellings in different signatures denote different
    -- implicit quantifiers and can therefore have different kinds.
    independentEnvironment <- expectRight $
        declare (ClassDecl "Independent" ["a"]
            [ ("left", HTApp (HTVar "f") (HTVar "a"))
            , ("right", HTVar "f")
            ]) captureEnvironment
    assertEqual "instantiated sibling methods retain independent local scopes"
        (Right
            [ ("left", HTApp (HTVar "f") (HTCon "Bool"))
            , ("right", HTVar "f")
            ])
        (resolveContext independentEnvironment $
            context "Independent" [HTCon "Bool"])

    -- A colliding image for a parameter absent from this method performs no
    -- substitution and therefore must not rename a useful shallow local.
    inactiveEnvironment <- expectRight $
        declare (ClassDecl "Inactive" ["a", "b"]
            [("inactive", HTApp (HTVar "f") (HTVar "b"))])
            independentEnvironment
    assertEqual "inactive substitution images do not trigger alpha-renaming"
        (Right [("inactive", HTApp (HTVar "f") (HTCon "Bool"))])
        (resolveContext inactiveEnvironment $
            context "Inactive" [HTVar "f", HTCon "Bool"])

    -- Fresh allocation must avoid both existing primes and every name in a
    -- compound substitution image while renaming multiple locals at once.
    multiCaptureEnvironment <- expectRight $
        declare (ClassDecl "MultiCapture" ["a"]
            [("multiCapture", HTTuple
                [ HTApp (HTVar "f") (HTVar "a")
                , HTApp (HTVar "f'") (HTVar "a")
                ])]) inactiveEnvironment
    let compoundArgument = HTTuple [HTVar "f", HTVar "f'"]
    assertEqual "multiple captured locals receive distinct fresh primes"
        (Right [("multiCapture", HTTuple
            [ HTApp (HTVar "f''") compoundArgument
            , HTApp (HTVar "f'''") compoundArgument
            ])])
        (resolveContext multiCaptureEnvironment $
            context "MultiCapture" [compoundArgument])

    -- Exercise a substantial collision chain without a machine-sized prime
    -- count or rebuilding every candidate with 'replicate'. Candidate
    -- spellings are extended directly, so the next name stays exact.
    wideCaptureEnvironment <- expectRight $
        declare (ClassDecl "WideCapture" ["a"]
            [("wideCapture", HTApp (HTVar "f") (HTVar "a"))])
            multiCaptureEnvironment
    let primeNames = iterate (++ "'") "f"
        occupiedVariables = take 65 primeNames
        freshVariable = primeNames !! 65
        wideArgument = foldr
            (\variable rest -> HTTuple [HTVar variable, rest])
            (HTCon "()") occupiedVariables
    assertEqual "long prime collision chains retain the next exact spelling"
        (Right [("wideCapture", HTApp (HTVar freshVariable) wideArgument)])
        (resolveContext wideCaptureEnvironment $
            context "WideCapture" [wideArgument])

testSelfReferenceEvidence :: IO ()
testSelfReferenceEvidence = do
    let a = HTVar "a"
        b = HTVar "b"

    unrelatedEnvironment <- expectRight $
        declare (Function "token" $ HTCon "Bool") standardEnvironment
    unrelated <- expectRight $
        inhabit defaultQueryOptions unrelatedEnvironment [] "token"
            (HTArrow a b)
    assertEqual "an unrelated collision does not justify a recursion warning"
        Unrealizable (reportOutcome unrelated)

    -- Keep this diagnostic fixture monomorphic. A free variable in a loaded
    -- Haskell signature is implicitly quantified, so @seed :: a@ is itself a
    -- valid inhabitant of any proper-type goal once loaded schemes are honored.
    let selfInput = HTCon "SelfReferenceInput"
        selfResult = HTCon "SelfReferenceResult"
    combinedEnvironment <- expectRight $ do
        withInput <- declare
            (AbstractType "SelfReferenceInput" KStar) standardEnvironment
        withResult <- declare
            (AbstractType "SelfReferenceResult" KStar) withInput
        withSeed <- declare (Function "seed" selfInput) withResult
        declare (Function "token" $ HTArrow selfInput selfResult) withSeed
    combined <- expectRight $
        inhabit defaultQueryOptions combinedEnvironment [] "token" selfResult
    assertEqual
        "a proof needing both safe and excluded assumptions justifies the warning"
        UnrealizableWithoutSelfReference (reportOutcome combined)

    exactEnvironment <- expectRight $
        declare (Function "token" a) standardEnvironment
    exact <- expectRight $
        inhabit defaultQueryOptions exactEnvironment [] "token" a
    assertEqual "an exact target assumption still justifies the warning"
        UnrealizableWithoutSelfReference (reportOutcome exact)

    diagnosticHeavyEnvironment <- expectRight $
        declare (Function "token" $ HTArrow (HTArrow a b) a)
            standardEnvironment
    diagnosticHeavy <- expectRight $
        inhabit defaultQueryOptions { optionBudget = Just 1 }
            diagnosticHeavyEnvironment [] "token" b
    assertEqual
        "diagnostic fuel exhaustion cannot undo a completed safe refutation"
        Unrealizable (reportOutcome diagnosticHeavy)

testProofEnvironment :: IO ()
testProofEnvironment = do
    let target = Symbol "answer"
        duplicate = Symbol "shared"
        environment = prepareProofEnvironment target
            [ (target, atomA)
            , (duplicate, atomA)
            , (duplicate, atomB)
            ]
        bindings = proofBindings environment
        allBindings = proofBindingsIncludingTarget environment
    assertBool "a target-named assumption must be excluded"
        (targetWasExcluded environment)
    assertEqual "only the unsafe target binding should be removed"
        [atomA, atomB] (map snd bindings)
    assertEqual "every remaining assumption needs a unique proof identity"
        2 (length $ nub $ map fst bindings)
    assertEqual "the diagnostic environment retains every assumption"
        [atomA, atomA, atomB] (map snd allBindings)
    assertEqual "excluded assumptions also receive unique proof identities"
        3 (length $ nub $ map fst allBindings)
    let numberedCollisionEnvironment = prepareProofEnvironment target
            [ (Symbol "$assumption1", atomA)
            , (Symbol "$assumption2", atomB)
            ]
    assertEqual "internal proof identities skip occupied numeric suffixes"
        [Symbol "$assumption3", Symbol "$assumption4"]
        (map fst $ proofBindings numberedCollisionEnvironment)
    case bindings of
        (internal, _) : _ -> do
            assertEqual "free proof identities should regain their display names"
                (Var duplicate) (restoreProofTerm environment $ Var internal)
            assertEqual "a safe alternate assumption should prove the target"
                [Var duplicate]
                (map (restoreProofTerm environment) $
                    prove False bindings atomA)
        [] -> fail "expected safe proof bindings"

testCheckedProofEvidenceParity :: IO ()
testCheckedProofEvidenceParity = do
    let identity = Symbol "identity"
        missing = Symbol "missing"
        duplicate = Symbol "duplicate"
        unused = Symbol "unused"
        argument = Symbol "argument"
        inner = Symbol "inner"
        leftConstructor = ConsDesc "Left" 1
        cases =
            [ ("successful identity",
                [], atomA :-> atomA, Lam identity $ Var identity,
                Right ())
            , ("unbound variable",
                [], atomA, Var missing,
                Left "unbound proof variable: missing")
            , ("duplicate environment",
                [(duplicate, atomA), (duplicate, atomB)],
                atomA, Var duplicate,
                Left "duplicate proof identity in environment: duplicate")
            , ("duplicate environment precedes malformed metadata",
                [(duplicate, atomA), (duplicate, atomB)],
                atomA, Ctuple (-1),
                Left "duplicate proof identity in environment: duplicate")
            , ("root mismatch",
                [], atomA :-> atomB, Lam identity $ Var identity,
                Left "proof type mismatch: a vs b")
            , ("malformed metadata",
                [], atomA, Ctuple (-1),
                Left "tuple arity is negative: -1")
            , ("metadata validation precedes inference",
                [], atomA, Apply (Var missing) (Ctuple (-1)),
                Left "tuple arity is negative: -1")
            , ("constrained injection failure",
                [], atomA :-> (atomA |: atomB),
                Lam identity $
                    Apply (Cinj leftConstructor 2) (Var identity),
                Left "injection index 2 is outside a sum with 2 alternatives")
            , ("unsupported legacy selector",
                [(identity, atomA)], atomA, Xsel 0 1 $ Var identity,
                Left "legacy Xsel has no proof-type semantics")
            , ("unconstrained intermediate domain",
                [(unused, atomA)], atomA,
                Apply
                    (Lam argument $ Var unused)
                    (Lam inner $ Var inner),
                Right ())
            ]
    mapM_ comparePaths cases
  where
    comparePaths (description, environment, expected, term, baseline) = do
        assertEqual
            (description ++ " changed its frozen historical result or error")
            baseline (checkProof environment expected term)
        assertEqual
            (description ++ " changed the historical checker result or error")
            (checkProof environment expected term)
            (void (ProofEvidence.checkProofWithEvidence
                environment expected term))

type ValidatedTestCandidate =
    CheckedCandidate.ValidatedCandidate DjinnCandidateDetails
        (SharedGenerated.FunctionClause HSymbol)

validatedCandidateForEvidence
    :: ProofEvidence.CheckedProofEvidence
    -> SharedGenerated.FunctionClause HSymbol
    -> DjinnCandidateDetails
    -> IO ValidatedTestCandidate
validatedCandidateForEvidence evidence clause details = do
    checked <- expectRight $ CheckedCandidate.checkCandidateProofWith
        (\() -> Right evidence) ()
    expectRight $ CheckedCandidate.convertCheckedCandidate
        (\() -> Right clause)
        (const details)
        checked

variableProofEvidence
    :: String
    -> IO ProofEvidence.CheckedProofEvidence
variableProofEvidence spelling = do
    let variable = Symbol spelling
    expectRight $ ProofEvidence.checkProofWithEvidence
        [(variable, atomA)] atomA (Var variable)

assertEvidenceOwner
    :: String
    -> Symbol
    -> ProofEvidence.CheckedProofEvidence
    -> IO ()
assertEvidenceOwner description expected evidence =
    case ProofEvidence.checkedProofEnvironment evidence of
        [(actual, _)] -> assertEqual description expected actual
        environment -> fail $
            description ++ ": unexpected environment width " ++
                show (length environment)

testValidatedCandidateResultParity :: IO ()
testValidatedCandidateResultParity = do
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $
        sharedName "sidecarParity"
    firstEvidence <- variableProofEvidence "firstParityEvidence"
    secondEvidence <- variableProofEvidence "secondParityEvidence"
    let firstClause = SharedGenerated.FunctionClause target [] $
            SharedGenerated.Global $ sharedName "firstParityOutput"
        secondClause = SharedGenerated.FunctionClause target
            [SharedGenerated.Bind "keptArgument"] $
            SharedGenerated.Local "keptArgument"
        firstDetails = DjinnCandidateDetails 0 0
        secondDetails = DjinnCandidateDetails 0 1
        metadata = DjinnQueryMetadata
            "parity-formula"
            (Just "parity-proof")
        completion = SharedSearch.truncated
            SharedSearch.CandidateLimitReached
    firstCandidate <- validatedCandidateForEvidence
        firstEvidence firstClause firstDetails
    secondCandidate <- validatedCandidateForEvidence
        secondEvidence secondClause secondDetails
    let validated = CheckedCandidate.mkValidatedResult
            SharedQuery.ValidatedCandidates
            completion
            metadata
            [firstCandidate, secondCandidate]
        projected = CheckedCandidate.projectValidatedResult validated
            :: Either SharedQuery.QueryResultInvariantError DjinnResult
        historical = SharedQuery.mkQueryResult
            SharedQuery.ValidatedCandidates $
                SharedSearch.SearchBatch
                    (SharedSearch.Completed completion)
                    metadata
                    [ SharedCandidate.Candidate
                        firstClause [] firstDetails
                    , SharedCandidate.Candidate
                        secondClause [] secondDetails
                    ]
            :: Either SharedQuery.QueryResultInvariantError DjinnResult
    expected <- expectShownRight historical
    actual <- expectShownRight projected
    assertEqual
        "the sidecar-retaining path changed the complete public result"
        expected actual

testTypedDjinnCoreProjectionParity :: IO ()
testTypedDjinnCoreProjectionParity = do
    prepared <- expectShownRight $ prepareEnvironment emptyEnvironment
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $
        sharedName "typedCoreIdentity"
    let goal = SharedType.FunctionType
            (SharedType.TypeVariable "element")
            (SharedType.TypeVariable "element")
    legacy <- expectShownRight $ inhabitSynthesisResultPrepared
        defaultQueryOptions prepared [] target goal
    typed <- expectShownRight $ inhabitTypedSynthesisResultPrepared
        defaultQueryOptions prepared [] target goal
    assertEqual "typed Core projection changed the complete legacy result"
        legacy $ SharedTypedCandidate.typedQueryResultCompatibility typed
    assertTypedCoreGraphs target goal typed

-- A supported ordinary producer must retain source authority for every
-- returned candidate, not just erase to a plausible untyped expression.
assertTypedCoreGraphs
    :: SharedGenerated.DefinitionName
    -> SharedType.Type String
    -> DjinnTypedResult
    -> Assertion
assertTypedCoreGraphs target expectedGoal result = do
    let candidates = SharedSearch.batchCandidates $ SharedQuery.resultSearch result
    assertBool "supported typed Core query produced no candidate" $ not $ null candidates
    mapM_ check candidates
  where
    check candidate = do
        graph <- expectShownRight $ SharedTypedCandidate.typedCandidateTermGraph candidate
        assertEqual "source graph changed its exact associated clause"
            (SharedCandidate.candidateOutput $
                SharedTypedCandidate.typedCandidateCompatibility candidate)
            (SharedTypedGenerated.eraseTermGraphToFunctionClause target graph)
        root <- maybe (fail "source graph lost its root") pure $
            SharedTypedGenerated.lookupTermNode
                (SharedTypedGenerated.termGraphRoot graph) graph
        let actualGoal = SharedTypedGenerated.termNodeType root
            taggedGoal = fmap SharedType.FlexibleVariable expectedGoal
        assertBool ("source graph changed its root type: " ++ show actualGoal) $
            actualGoal == taggedGoal ||
                SharedTypeAtom.alphaEquivalentClosedTypes expectedGoal actualGoal

-- An unused source context still introduces its ordered Given telescope.
-- This helper accepts an empty terminal stream batch; callers separately
-- require a positive identity result before checking the exact graph evidence.
assertUnusedGivenIdentityGraphs
    :: SharedGenerated.DefinitionName
    -> SharedType.Type String
    -> SharedName.Name
    -> DjinnTypedResult
    -> Assertion
assertUnusedGivenIdentityGraphs target expectedSource className result = do
    let candidates = SharedSearch.batchCandidates $ SharedQuery.resultSearch result
    if null candidates then pure () else assertTypedCoreGraphs target expectedSource result
    forM_ candidates $ \candidate -> do
        graph <- expectShownRight $ SharedTypedCandidate.typedCandidateTermGraph candidate
        let nodes = SharedTypedGenerated.termGraphNodes graph
            introductions = [() | (_, node) <- nodes,
                SharedTypedGenerated.TypedContextIntroduction{} <- [SharedTypedGenerated.termNodeForm node]]
            applications = [() | (_, node) <- nodes,
                SharedTypedGenerated.TypedContextApplication{} <- [SharedTypedGenerated.termNodeForm node]]
        assertEqual "identity lost or duplicated its source Given introduction" 1 $ length introductions
        assertEqual "unused identity fabricated a dictionary application" [] applications
        assertEqual "contextual identity acquired a method or provider" [] $
            SharedGenerated.expressionGlobals $ SharedTypedGenerated.eraseTermGraph graph
        (_, child, witness) <- rootContext graph $ SharedTypedGenerated.termGraphRoot graph
        body <- maybe (fail "Given introduction lost its body") pure $
            SharedTypedGenerated.lookupTermNode child graph
        let bodyType = SharedTypedGenerated.termNodeType body
        parameter <- case bodyType of
            SharedType.FunctionType domain codomain | domain == codomain -> pure domain
            _ -> fail $ "Given identity body lost its exact parameter correlation: " ++ show bodyType
        let constraint = Constraint className [parameter]
            constraints = [constraint]
        assertEqual "Given introduction changed its ordered source slot"
            [(0 :: Natural, constraint)] $
            zip [0 ..] $ SharedTypedGenerated.contextIntroductionConstraints witness
        assertEqual "Given introduction changed its qualified source type"
            (SharedType.ForallType [] constraints bodyType) $
            SharedTypedGenerated.contextIntroductionSource witness
        assertEqual "Given introduction changed its source body"
            bodyType $ SharedTypedGenerated.contextIntroductionBody witness
  where
    -- Only actual leading forall introductions may precede the context.
    -- A nested or unrelated introduction cannot stand in for root authority.
    rootContext graph nodeId = case SharedTypedGenerated.lookupTermNode nodeId graph of
        Just node -> case SharedTypedGenerated.termNodeForm node of
            SharedTypedGenerated.TypedForallIntroduction _ child _ -> rootContext graph child
            SharedTypedGenerated.TypedContextIntroduction occurrence child witness ->
                pure (occurrence, child, witness)
            _ -> fail "source context is not at the exact graph introduction root"
        Nothing -> fail "source context traversal lost a graph node"
testPreparedSourceGoalGraphs :: IO ()
testPreparedSourceGoalGraphs = do
    tokenEnvironment <- expectRight $ declare
        (DataType "SourceToken" [] [("SourceTokenValue", [])]) emptyEnvironment
    environment <- expectRight $ declare
        (TypeSynonym "SourceIdentity" ["a"] $ HTVar "a") tokenEnvironment
    prepared <- expectShownRight $ prepareEnvironment environment
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $
        sharedName "preservedSourceGoal"
    let token = SharedType.TypeConstructor $ sharedName "SourceToken"
        variable = SharedType.TypeVariable
        identity = SharedType.TypeApplication $
            SharedType.TypeConstructor $ sharedName "SourceIdentity"
        quantified body = SharedType.ForallType ["a"] [] body
        source = quantified $ SharedType.FunctionType (identity $ variable "a") (variable "a")
        opened = SharedType.FunctionType (identity $ variable "a'") (variable "a'")
        expanded = quantified $ SharedType.FunctionType (variable "a") (variable "a")
        cases =
            [ (token, token, token)
            , (SharedType.ForallType [] [] token, token, token)
            , (source, opened, expanded)
            ]
    mapM_ (\(sourceGoal, searchGoal, expectedGoal) -> do
        legacy <- expectShownRight $ inhabitSynthesisResultPrepared
            defaultQueryOptions prepared [] target searchGoal
        typed <- expectShownRight $ inhabitTypedSynthesisResultPreparedWithSourceGoal
            defaultQueryOptions prepared sourceGoal []
            (DjinnSourceInstantiationCandidates []) target searchGoal
        assertEqual "source preservation changed the complete search envelope"
            legacy $ SharedTypedCandidate.typedQueryResultCompatibility typed
        assertTypedCoreGraphs target expectedGoal typed) cases

testPreparedSourceContextCorrespondence :: IO ()
testPreparedSourceContextCorrespondence = do
    aliasEnvironment <- expectRight $ declare
        (TypeSynonym "SourceIdentity" ["a"] $ HTVar "a") emptyEnvironment
    environment <- expectRight $ declare
        (ClassDecl "SourceContext" ["a"]
            [("sourceContextMethod", HTArrow (HTVar "a") (HTVar "a"))]) aliasEnvironment
    prepared <- expectShownRight $ prepareEnvironment environment
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $
        sharedName "preservedSourceContext"
    let variable = SharedType.TypeVariable
        identity = SharedType.TypeApplication $
            SharedType.TypeConstructor $ sharedName "SourceIdentity"
        sourceContext ty = Constraint (sharedName "SourceContext") [identity ty]
        source = SharedType.ForallType ["a"] [sourceContext $ variable "a"] $
            SharedType.FunctionType (identity $ variable "a") (variable "a")
        searchGoal = SharedType.FunctionType (identity $ variable "a'") (variable "a'")
        contexts = [sourceContext $ variable "a'"]
    legacy <- expectShownRight $ inhabitSynthesisResultPrepared
        defaultQueryOptions prepared contexts target searchGoal
    typed <- expectShownRight $ inhabitTypedSynthesisResultPreparedWithSourceGoal
        defaultQueryOptions prepared source contexts
        (DjinnSourceInstantiationCandidates []) target searchGoal
    assertEqual "joint context opening changed the complete search envelope"
        legacy $ SharedTypedCandidate.typedQueryResultCompatibility typed
    let candidates = SharedSearch.batchCandidates $ SharedQuery.resultSearch typed
    assertBool "context-independent identity was lost" $ not $ null candidates
    -- Alias expansion preserves the full quantified/contextual source shape;
    -- its unused Given is introduced but never applied to a method/provider.
    let expandedSource = SharedType.ForallType ["a"]
            [Constraint (sharedName "SourceContext") [variable "a"]] $
            SharedType.FunctionType (variable "a") (variable "a")
    assertUnusedGivenIdentityGraphs target expandedSource (sharedName "SourceContext") typed
    case inhabitTypedSynthesisResultPreparedWithSourceGoal defaultQueryOptions prepared
            source [sourceContext $ variable "unrelated"]
            (DjinnSourceInstantiationCandidates []) target searchGoal of
        Left (DjinnInternalQueryFailure message) -> assertBool
            "context mismatch lost its source/search diagnostic"
            $ "does not match its preserved source goal" `isInfixOf` message
        Left failure -> fail $ "unexpected context-mismatch rejection: " ++ show failure
        Right _ -> fail "a separately renamed context acquired source-goal authority"

testPreparedSourceGoalMismatch :: IO ()
testPreparedSourceGoalMismatch = do
    prepared <- expectShownRight $ prepareEnvironment emptyEnvironment
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $
        sharedName "unrelatedSourceGoal"
    let variable = SharedType.TypeVariable
        identity name = SharedType.FunctionType (variable name) (variable name)
        source = SharedType.ForallType ["a"] [] $ identity "a"
        mismatches =
            [ (source, SharedType.FunctionType (variable "a'") (variable "b'"))
            , (SharedType.ForallType ["a"] [] (variable "a"), identity "a'")
            , (source, SharedType.ForallType ["a'"] [] $ identity "a'")
            ]
    mapM_ (\(sourceGoal, searchGoal) ->
        case inhabitTypedSynthesisResultPreparedWithSourceGoal defaultQueryOptions
                prepared sourceGoal [] (DjinnSourceInstantiationCandidates [])
                target searchGoal of
            Left (DjinnInternalQueryFailure message) -> assertBool
                "source mismatch lost its precise diagnostic"
                $ "does not match its preserved source goal" `isInfixOf` message
            Left failure -> fail $ "unexpected source-mismatch rejection: " ++ show failure
            Right _ -> fail "an unrelated source goal acquired search evidence") mismatches

testValidatedCandidateDeduplication :: IO ()
testValidatedCandidateDeduplication = do
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $
        sharedName "sidecarDeduplication"
    firstEvidence <- variableProofEvidence "firstDeduplicatedEvidence"
    duplicateEvidence <- variableProofEvidence "duplicateEvidence"
    let selector = sharedName "sidecarSelector"
        compact = SharedGenerated.FunctionClause target [] $
            SharedGenerated.Global selector
        expanded = SharedGenerated.FunctionClause target
            [ SharedGenerated.Bind "record"
            , SharedGenerated.Bind "argument"
            ] $
            SharedGenerated.Apply
                (SharedGenerated.Apply
                    (SharedGenerated.Global selector)
                    (SharedGenerated.Local "record"))
                (SharedGenerated.Local "argument")
        details = DjinnCandidateDetails 0 2
    firstCandidate <- validatedCandidateForEvidence
        firstEvidence expanded details
    duplicateCandidate <- validatedCandidateForEvidence
        duplicateEvidence compact details
    case deduplicateEtaEquivalentClausesOn
            CheckedCandidate.validatedCandidateOutput
            [firstCandidate, duplicateCandidate] of
        [survivor] -> do
            assertEqual
                "eta de-duplication changed the first clause spelling"
                expanded
                (CheckedCandidate.validatedCandidateOutput survivor)
            assertEvidenceOwner
                "eta de-duplication detached the first proof sidecar"
                (Symbol "firstDeduplicatedEvidence")
                (CheckedCandidate.validatedCandidateProofEvidence survivor)
        survivors -> fail $
            "expected one eta-equivalent sidecar, got " ++
                show (length survivors)

testValidatedCandidateSorting :: IO ()
testValidatedCandidateSorting = do
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $
        sharedName "sidecarSorting"
    laterEvidence <- variableProofEvidence "laterSortedEvidence"
    earlierEvidence <- variableProofEvidence "earlierSortedEvidence"
    let laterClause = SharedGenerated.FunctionClause target [] $
            SharedGenerated.Global $ sharedName "laterSortedOutput"
        earlierClause = SharedGenerated.FunctionClause target [] $
            SharedGenerated.Global $ sharedName "earlierSortedOutput"
        laterDetails = DjinnCandidateDetails 1 2
        earlierDetails = DjinnCandidateDetails 0 0
    laterCandidate <- validatedCandidateForEvidence
        laterEvidence laterClause laterDetails
    earlierCandidate <- validatedCandidateForEvidence
        earlierEvidence earlierClause earlierDetails
    case CheckedCandidate.sortValidatedCandidates
            [laterCandidate, earlierCandidate] of
        [firstCandidate, secondCandidate] -> do
            assertEqual "candidate-detail sorting lost the earlier clause"
                earlierClause $
                    CheckedCandidate.validatedCandidateOutput firstCandidate
            assertEvidenceOwner
                "candidate-detail sorting detached the earlier sidecar"
                (Symbol "earlierSortedEvidence") $
                    CheckedCandidate.validatedCandidateProofEvidence
                        firstCandidate
            assertEqual "candidate-detail sorting lost the later clause"
                laterClause $
                    CheckedCandidate.validatedCandidateOutput secondCandidate
            assertEvidenceOwner
                "candidate-detail sorting detached the later sidecar"
                (Symbol "laterSortedEvidence") $
                    CheckedCandidate.validatedCandidateProofEvidence
                        secondCandidate
        sortedCandidates -> fail $
            "expected two sorted sidecars, got " ++
                show (length sortedCandidates)
    stableFirst <- validatedCandidateForEvidence
        laterEvidence laterClause earlierDetails
    stableSecond <- validatedCandidateForEvidence
        earlierEvidence earlierClause earlierDetails
    case CheckedCandidate.sortValidatedCandidates
            [stableFirst, stableSecond] of
        [firstCandidate, secondCandidate] -> do
            assertEqual "equal candidate details changed clause order"
                laterClause $
                    CheckedCandidate.validatedCandidateOutput firstCandidate
            assertEvidenceOwner
                "equal candidate details changed sidecar order"
                (Symbol "laterSortedEvidence") $
                    CheckedCandidate.validatedCandidateProofEvidence
                        firstCandidate
            assertEqual "equal candidate details changed the second clause"
                earlierClause $
                    CheckedCandidate.validatedCandidateOutput secondCandidate
            assertEvidenceOwner
                "equal candidate details changed the second sidecar"
                (Symbol "earlierSortedEvidence") $
                    CheckedCandidate.validatedCandidateProofEvidence
                        secondCandidate
        stableCandidates -> fail $
            "expected two stable sidecars, got " ++
                show (length stableCandidates)

testValidatedCandidateFinalKeys :: IO ()
testValidatedCandidateFinalKeys = do
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $
        sharedName "finalCandidateKeys"
    laterEvidence <- variableProofEvidence "laterKeyEvidence"
    earlierEvidence <- variableProofEvidence "earlierKeyEvidence"
    let laterClause = SharedGenerated.FunctionClause target [] $
            SharedGenerated.Global $ sharedName "laterKeyOutput"
        earlierClause = SharedGenerated.FunctionClause target [] $
            SharedGenerated.Global $ sharedName "earlierKeyOutput"
    later <- validatedCandidateForEvidence laterEvidence laterClause $
        DjinnCandidateDetails 1 2
    earlier <- validatedCandidateForEvidence earlierEvidence earlierClause $
        DjinnCandidateDetails 0 0
    let ranked = CheckedCandidate.sortValidatedCandidates [later, earlier]
        validated = CheckedCandidate.mkValidatedResult
            SharedQuery.ValidatedCandidates
            SharedSearch.Finished
            (DjinnQueryMetadata "candidate-key-formula" Nothing)
            ranked
        projected = CheckedCandidate.projectValidatedResultWith
            (\key candidate ->
                (key, CheckedCandidate.validatedCandidateOutput candidate))
            validated
            :: Either SharedQuery.QueryResultInvariantError
                (SharedQuery.QueryResult DjinnQueryMetadata
                    (Natural, SharedGenerated.FunctionClause String))
    result <- expectShownRight projected
    assertEqual "final candidate keys were not allocated after ranking"
        [(0, earlierClause), (1, laterClause)] $
        SharedSearch.batchCandidates $ SharedQuery.resultSearch result

testValidatedCandidateProjectionLaziness :: IO ()
testValidatedCandidateProjectionLaziness = do
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $
        sharedName "lazySidecarProjection"
    let clause = SharedGenerated.FunctionClause target
            [SharedGenerated.Bind "argument"] $
            SharedGenerated.Local "argument"
        details = DjinnCandidateDetails 0 1
        poisonedEvidence = error "compatibility projection forced checked proof evidence"
    checked <- expectRight $ CheckedCandidate.checkCandidateProofWith
        (\() -> Right poisonedEvidence) ()
    candidate <- expectRight $ CheckedCandidate.convertCheckedCandidate
        (\() -> Right clause)
        (const details)
        checked
    let validated = CheckedCandidate.mkValidatedResult
            SharedQuery.ValidatedCandidates
            SharedSearch.Finished
            (DjinnQueryMetadata "lazy-formula" Nothing)
            (candidate : error
                "compatibility projection forced the sidecar tail")
        projected = CheckedCandidate.projectValidatedResult validated
            :: Either SharedQuery.QueryResultInvariantError DjinnResult
    result <- expectShownRight projected
    assertEqual "lazy projection lost query evidence"
        SharedQuery.ValidatedCandidates $
            SharedQuery.resultEvidence result
    case SharedSearch.batchCandidates $ SharedQuery.resultSearch result of
        publicCandidate : _ -> do
            assertEqual "lazy projection changed the first clause"
                clause $ SharedCandidate.candidateOutput publicCandidate
            assertEqual "lazy projection changed candidate details"
                details $ SharedCandidate.candidateDetails publicCandidate
        [] -> fail "lazy sidecar projection produced no public candidate"

testValidatedTypedProjectionLaziness :: IO ()
testValidatedTypedProjectionLaziness = do
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $
        sharedName "lazyTypedSidecarProjection"
    let clause = SharedGenerated.FunctionClause target
            [SharedGenerated.Bind "argument"] $
            SharedGenerated.Local "argument"
        details = DjinnCandidateDetails 0 1
        poisonedEvidence = error "typed projection forced checked proof evidence"
    checked <- expectRight $ CheckedCandidate.checkCandidateProofWith
        (\() -> Right poisonedEvidence) ()
    candidate <- expectRight $ CheckedCandidate.convertCheckedCandidate
        (\() -> Right clause)
        (const details)
        checked
    let validated = CheckedCandidate.mkValidatedResult
            SharedQuery.ValidatedCandidates
            SharedSearch.Finished
            (DjinnQueryMetadata "lazy-typed-formula" Nothing)
            (candidate : error "typed projection forced the candidate tail")
        projected = CheckedCandidate.projectValidatedResultWith
            (\_ retained ->
                ( CheckedCandidate.validatedCandidateOutput retained
                , error "typed projection forced deferred graph checking"
                    :: Either DjinnTermGraphAbsence ()
                ))
            validated
            :: Either SharedQuery.QueryResultInvariantError
                (SharedQuery.QueryResult DjinnQueryMetadata
                    (SharedGenerated.FunctionClause String,
                     Either DjinnTermGraphAbsence ()))
    result <- expectShownRight projected
    case SharedSearch.batchCandidates $ SharedQuery.resultSearch result of
        (actualClause, _) : _ -> do
            assertEqual "typed lazy projection changed compatibility output"
                clause actualClause
            assertEqual "typed lazy projection lost logical evidence"
                SharedQuery.ValidatedCandidates $ SharedQuery.resultEvidence result
            assertEqual "typed lazy projection changed query metadata"
                (DjinnQueryMetadata "lazy-typed-formula" Nothing) $
                    SharedSearch.batchMetadata $ SharedQuery.resultSearch result
        [] -> fail "lazy typed sidecar projection produced no candidate"

testValidatedRankNProductionEvidence :: IO ()
testValidatedRankNProductionEvidence = do
    target <- expectShownRight $ SharedGenerated.mkDefinitionName $
        sharedName "rankNProductionEvidence"
    let instantiationAxiom = Symbol "$djinn$rankNInstantiation"
        provider = Symbol "rankNProvider"
        impredicativeWitness = Symbol "impredicativeWitness"
        sourceType = SharedType.ForallType ["first", "second"] [] $
            SharedType.FunctionType
                (SharedType.TypeVariable "first")
                (SharedType.TypeVariable "second")
        impredicativeType = SharedType.ForallType ["element"] [] $
            SharedType.FunctionType
                (SharedType.TypeVariable "element")
                (SharedType.TypeVariable "element")
        resultType = SharedType.FunctionType
            impredicativeType impredicativeType
        sourceFormula = PVar $ opaqueTypeSymbol sourceType
        impredicativeFormula = PVar $ opaqueTypeSymbol impredicativeType
        resultFormula = PVar $ opaqueTypeSymbol resultType
        axiomFormula =
            sourceFormula :-> impredicativeFormula :-> resultFormula
        environment =
            [ (instantiationAxiom, axiomFormula)
            , (provider, sourceFormula)
            , (impredicativeWitness, impredicativeFormula)
            ]
        partialApplication =
            Apply (Var instantiationAxiom) (Var provider)
        rawProof =
            Apply partialApplication (Var impredicativeWitness)
        convertProductionProof term = do
            let erased =
                    InstantiationEvidence.eliminateInstantiationEvidence
                        (Set.singleton instantiationAxiom) term
            compatibilityClause <- termToHClause
                (SharedGenerated.definitionSpelling target) erased
            DjinnGenerated.toGeneratedClauseWithName
                target compatibilityClause
    checked <- expectRight $ CheckedCandidate.checkCandidateProofWith
        (ProofEvidence.checkProofWithEvidence environment resultFormula)
        rawProof
    candidate <- expectRight $ CheckedCandidate.convertCheckedCandidate
        convertProductionProof
        (const $ DjinnCandidateDetails 0 0)
        checked
    rendered <- expectRight $ DjinnGenerated.renderGeneratedClause $
        CheckedCandidate.validatedCandidateOutput candidate
    assertBool
        ("generated instantiation evidence was not erased: " ++ rendered)
        (not $ "$djinn$rankNInstantiation" `isInfixOf` rendered)
    assertBool
        ("erased production clause lost the source application: " ++ rendered)
        ("rankNProvider impredicativeWitness" `isInfixOf` rendered)
    let evidence =
            CheckedCandidate.validatedCandidateProofEvidence candidate
        root = ProofEvidence.checkedProofRoot evidence
    assertEqual
        "the production sidecar retained the post-erasure term instead of the raw proof"
        rawProof $ ProofEvidence.checkedProofNodeTerm root
    assertEqual "the production proof root lost its exact rank-N result"
        (Just resultFormula) $ checkedProofNodeExactFormula root
    case ProofEvidence.checkedProofNodeChildren root of
        [partial, witness] -> do
            assertEqual
                "the production proof lost its pre-erasure intermediate application"
                partialApplication $ ProofEvidence.checkedProofNodeTerm partial
            assertEqual
                "the production proof lost its impredicative intermediate type"
                (Just $ impredicativeFormula :-> resultFormula) $
                    checkedProofNodeExactFormula partial
            assertEqual "the production proof lost its impredicative argument"
                (Just impredicativeFormula) $
                    checkedProofNodeExactFormula witness
            case ProofEvidence.checkedProofNodeChildren partial of
                [axiom, checkedProvider] -> do
                    assertEqual
                        "the production sidecar erased its checker-visible axiom"
                        (Var instantiationAxiom) $
                            ProofEvidence.checkedProofNodeTerm axiom
                    assertEqual
                        "the production provider lost its exact source rank-N type"
                        (Just sourceType) $
                            checkedProofNodeExactFormula checkedProvider
                                >>= proofFormulaOpaqueSource
                children -> fail $
                    "expected axiom and provider production children, got " ++
                        show (length children)
        children -> fail $
            "expected partial and witness production children, got " ++
                show (length children)

testCheckedProofRankNTypes :: IO ()
testCheckedProofRankNTypes = do
    let provider = Symbol "rankNProvider"
        sourceType = SharedType.ForallType ["element"] [] $
            SharedType.FunctionType
                (SharedType.TypeVariable "element")
                (SharedType.TypeVariable "element")
        sourceFormula = PVar $ opaqueTypeSymbol sourceType
        environment = [(provider, sourceFormula)]
        term = Var provider
    evidence <- either fail return $
        ProofEvidence.checkProofWithEvidence
            environment sourceFormula term
    assertEqual "evidence retains the exact checked proof environment"
        environment (ProofEvidence.checkedProofEnvironment evidence)
    assertEqual "evidence retains the exact checked root obligation"
        sourceFormula (ProofEvidence.checkedProofExpectedType evidence)
    let root = ProofEvidence.checkedProofRoot evidence
    assertEqual "the root retains its exact rank-N proof occurrence"
        term (ProofEvidence.checkedProofNodeTerm root)
    assertEqual "the root retains the opaque rank-N logical atom"
        (Just sourceFormula) (checkedProofNodeExactFormula root)
    assertEqual "the opaque atom still owns its full source type"
        (Just sourceType)
        (checkedProofNodeExactFormula root >>= proofFormulaOpaqueSource)
    assertEqual "a ground rank-N atom retains no unconstrained identity"
        0 (checkedProofNodeUnconstrainedCount root)
    assertEqual "a variable proof has no invented typed children"
        0 (length $ ProofEvidence.checkedProofNodeChildren root)

testCheckedProofImpredicativeApplications :: IO ()
testCheckedProofImpredicativeApplications = do
    let instantiationAxiom = Symbol "instantiationAxiom"
        provider = Symbol "provider"
        impredicativeWitness = Symbol "impredicativeWitness"
        sourceType = SharedType.ForallType ["first", "second"] [] $
            SharedType.FunctionType
                (SharedType.TypeVariable "first")
                (SharedType.TypeVariable "second")
        impredicativeType = SharedType.ForallType ["element"] [] $
            SharedType.FunctionType
                (SharedType.TypeVariable "element")
                (SharedType.TypeVariable "element")
        resultType = SharedType.FunctionType
            impredicativeType impredicativeType
        sourceFormula = PVar $ opaqueTypeSymbol sourceType
        impredicativeFormula = PVar $ opaqueTypeSymbol impredicativeType
        resultFormula = PVar $ opaqueTypeSymbol resultType
        axiomFormula =
            sourceFormula :-> impredicativeFormula :-> resultFormula
        environment =
            [ (instantiationAxiom, axiomFormula)
            , (provider, sourceFormula)
            , (impredicativeWitness, impredicativeFormula)
            ]
        partialApplication =
            Apply (Var instantiationAxiom) (Var provider)
        term = Apply partialApplication (Var impredicativeWitness)
    evidence <- either fail return $
        ProofEvidence.checkProofWithEvidence environment resultFormula term
    let root = ProofEvidence.checkedProofRoot evidence
    assertEqual "the complete application retains its exact result type"
        (Just resultFormula) (checkedProofNodeExactFormula root)
    case ProofEvidence.checkedProofNodeChildren root of
        [partial, witness] -> do
            assertEqual
                "the first application retains its multi-binder intermediate"
                (Just $ impredicativeFormula :-> resultFormula)
                (checkedProofNodeExactFormula partial)
            assertEqual "the argument retains its impredicative atom"
                (Just impredicativeFormula)
                (checkedProofNodeExactFormula witness)
            case ProofEvidence.checkedProofNodeChildren partial of
                [axiom, checkedProvider] -> do
                    assertEqual "the axiom retains its complete source/result spine"
                        (Just axiomFormula)
                        (checkedProofNodeExactFormula axiom)
                    assertEqual "the provider retains the exact source scheme atom"
                        (Just sourceType)
                        (checkedProofNodeExactFormula checkedProvider
                            >>= proofFormulaOpaqueSource)
                children -> fail $
                    "expected axiom and provider children, got " ++
                    show (length children)
        children -> fail $
            "expected partial and witness children, got " ++
            show (length children)
    -- Visible type arguments are attached only later by Instantiation and
    -- ProofToGenerated.  This test intentionally verifies only the source and
    -- application types representable in the checked LJT term.

testCheckedProofFinalPruning :: IO ()
testCheckedProofFinalPruning = do
    let outer = Symbol "outer"
        inner = Symbol "inner"
        identityApplication =
            Apply (Lam inner $ Var inner) (Var outer)
        term = Lam outer identityApplication
        expected = atomA :-> atomA
    evidence <- either fail return $
        ProofEvidence.checkProofWithEvidence [] expected term
    let root = ProofEvidence.checkedProofRoot evidence
    assertEqual "the root metavariable chain resolves to the exact goal"
        (Just expected) (checkedProofNodeExactFormula root)
    case ProofEvidence.checkedProofNodeChildren root of
        [application] -> do
            assertEqual "the application result is fully substituted"
                (Just atomA) (checkedProofNodeExactFormula application)
            case ProofEvidence.checkedProofNodeChildren application of
                [identity, argument] -> do
                    assertEqual "the inferred identity type is fully substituted"
                        (Just expected) (checkedProofNodeExactFormula identity)
                    assertEqual "the outer occurrence is fully substituted"
                        (Just atomA) (checkedProofNodeExactFormula argument)
                    case ProofEvidence.checkedProofNodeChildren identity of
                        [body] -> assertEqual
                            "the inner occurrence is fully substituted"
                            (Just atomA) (checkedProofNodeExactFormula body)
                        children -> fail $
                            "expected one identity body, got " ++
                            show (length children)
                children -> fail $
                    "expected function and argument children, got " ++
                    show (length children)
        children -> fail $
            "expected one lambda body, got " ++ show (length children)

testCheckedProofUnconstrainedIntermediate :: IO ()
testCheckedProofUnconstrainedIntermediate = do
    let supplied = Symbol "supplied"
        ignored = Symbol "ignored"
        identity = Symbol "identity"
        term = Apply
            (Lam ignored $ Var supplied)
            (Lam identity $ Var identity)
    evidence <- either fail return $
        ProofEvidence.checkProofWithEvidence
            [(supplied, atomA)] atomA term
    let root = ProofEvidence.checkedProofRoot evidence
    assertEqual "the successful application root remains exact"
        (Just atomA) (checkedProofNodeExactFormula root)
    assertEqual "the exact root contains no unconstrained identity"
        0 (checkedProofNodeUnconstrainedCount root)
    case ProofEvidence.checkedProofNodeChildren root of
        [function, argument] -> do
            assertEqual
                "the constant function exposes a partial nested checker type"
                Nothing (checkedProofNodeExactFormula function)
            assertBool
                "the constant function must report its unknown domain"
                (checkedProofNodeHasUnconstrained function)
            assertEqual
                "the function domain is correlated with the argument type"
                1 (checkedProofNodeUnconstrainedCount function)
            assertEqual
                "the identity argument cannot be guessed as an exact formula"
                Nothing (checkedProofNodeExactFormula argument)
            assertEqual
                "both identity positions retain one correlated unknown"
                1 (checkedProofNodeUnconstrainedCount argument)
            case ProofEvidence.checkedProofNodeChildren argument of
                [body] -> do
                    assertEqual "the identity body remains explicitly unknown"
                        Nothing (checkedProofNodeExactFormula body)
                    assertEqual "the body retains that one unknown identity"
                        1 (checkedProofNodeUnconstrainedCount body)
                children -> fail $
                    "expected one identity body, got " ++
                    show (length children)
        children -> fail $
            "expected function and argument children, got " ++
            show (length children)

checkedProofNodeExactFormula
    :: ProofEvidence.CheckedProofNode
    -> Maybe Formula
checkedProofNodeExactFormula =
    ProofEvidence.checkedProofTypeExactFormula
        . ProofEvidence.checkedProofNodeType

checkedProofNodeHasUnconstrained :: ProofEvidence.CheckedProofNode -> Bool
checkedProofNodeHasUnconstrained =
    ProofEvidence.checkedProofTypeHasUnconstrained
        . ProofEvidence.checkedProofNodeType

checkedProofNodeUnconstrainedCount
    :: ProofEvidence.CheckedProofNode
    -> Natural
checkedProofNodeUnconstrainedCount =
    ProofEvidence.checkedProofTypeUnconstrainedCount
        . ProofEvidence.checkedProofNodeType

proofFormulaOpaqueSource :: Formula -> Maybe (SharedType.Type String)
proofFormulaOpaqueSource formula = case formula of
    PVar symbol -> opaqueSymbolSource symbol
    _ -> Nothing

testGeneratedProofsCheck :: IO ()
testGeneratedProofsCheck = do
    let cases =
            [ ([], atomA :-> atomA)
            , ([], (atomA & atomB) :-> (atomB & atomA))
            , ([], atomA :-> (atomA |: atomB))
            , ([], false :-> atomA)
            , ([(Symbol "given", atomA)], atomB :-> atomA)
            ]
    mapM_ checkGenerated cases
  where
    checkGenerated (environment, formula) =
        case prove False environment formula of
            [] -> fail $ "expected a generated proof of " ++ show formula
            proof : _ -> assertEqual
                ("independent checker rejected " ++ show proof)
                (Right ()) (checkProof environment formula proof)

testWideProofMetas :: IO ()
testWideProofMetas = do
    let arity = 512
        elements = replicate arity true
        handler = foldr (:->) true elements
        formula = handler :-> Conj elements :-> true
    assertEqual "every wide product component keeps a distinct metavariable"
        (Right ()) (checkProof [] formula $ Csplit arity)

testMalformedProofTerms :: IO ()
testMalformedProofTerms = do
    let a = Symbol "a"
        b = Symbol "b"
        leftConstructor = ConsDesc "Left" 1
    assertLeft "identity cannot prove a -> b"
        (checkProof [] (atomA :-> atomB) $ Lam a $ Var a)
    assertLeft "an injection must name the expected constructor"
        (checkProof [] (atomA :-> (atomA |: atomB)) $
            Lam a $ Apply (Cinj (ConsDesc "Wrong" 1) 0) (Var a))
    assertLeft "a one-element tuple cannot prove a pair"
        (checkProof [] ((atomA & atomB) :-> (atomA & atomB)) $
            Lam a $ Apply (Ctuple 1) (Var a))
    assertLeft "legacy selectors have no independently checkable semantics"
        (checkProof [(b, atomA)] atomA $ Xsel 0 1 (Var b))
    assertLeftMessage "an injection index must be in range"
        "injection index 2 is outside a sum with 2 alternatives"
        (checkProof [] (atomA :-> (atomA |: atomB)) $
            Lam a $ Apply (Cinj leftConstructor 2) (Var a))

testNominalEmptyTypes :: IO ()
testNominalEmptyTypes = do
    let definitions =
            [ ("EmptyA", ([], HTUnion [], ()))
            , ("EmptyB", ([], HTUnion [], ()))
            , ("AliasA", ([], HTCon "EmptyA", ()))
            , ("EmptyOf", (["a"], HTUnion [], ()))
            , ("Flag", ([], HTUnion [("Flag", [])], ()))
            , ("FlagAlias", ([], HTCon "Flag", ()))
            ]
    translate <- expectRight $ prepareTypeFormulaTranslator definitions
    emptyA <- expectRight $ translate $ HTCon "EmptyA"
    emptyB <- expectRight $ translate $ HTCon "EmptyB"
    aliasA <- expectRight $ translate $ HTCon "AliasA"
    emptyOfFlag <- expectRight $ translate $
        HTApp (HTCon "EmptyOf") (HTCon "Flag")
    emptyOfAlias <- expectRight $ translate $
        HTApp (HTCon "EmptyOf") (HTCon "FlagAlias")
    let cast = emptyA :-> emptyB
        identity = emptyA :-> emptyA
    assertBool "distinct empty datatypes need distinct propositions"
        (emptyA /= emptyB)
    assertEqual "an alias should retain its underlying nominal identity"
        emptyA aliasA
    assertEqual "aliases in empty-type arguments should be transparent"
        emptyOfFlag emptyOfAlias
    case prove True [] identity of
        [Lam binder (Var used)] ->
            assertEqual "the same empty type should use identity" binder used
        proofs -> fail $ "expected only empty identity, got " ++ show proofs
    case prove False [] cast of
        [proof@(Lam binder (Apply (Ccases []) (Var used)))] -> do
            assertEqual "empty conversion must eliminate its argument explicitly"
                binder used
            assertEqual "the explicit empty elimination should type-check"
                (Right ()) (checkProof [] cast proof)
            rendered <- renderTerm "cast" proof
            assertEqual "empty elimination should remain structural"
                "cast a = case a of {}" rendered
        proofs -> fail $ "expected one explicit empty elimination, got " ++
            show proofs
    assertLeft "a direct identity cast between empty types must be rejected"
        (checkProof [] cast $ Lam (Symbol "x") (Var $ Symbol "x"))

    -- Empty elimination used to become a magic free variable named @void@.
    -- That made @void@ unusable as a target and silently captured an unrelated
    -- assumption with the same spelling.  A structural empty case has neither
    -- collision.
    let emptyGoal = HTArrow (HTCon "Void") (HTVar "a")
    voidTarget <- expectRight $ inhabit defaultQueryOptions
        standardEnvironment [] "void" emptyGoal
    assertEqual "void remains a legal generated definition name"
        (Realized ["void a = case a of {}"])
        (reportOutcome voidTarget)
    collidingEnvironment <- expectRight $
        declare (Function "void" $ HTCon "Bool") standardEnvironment
    collisionSafe <- expectRight $ inhabit defaultQueryOptions
        collidingEnvironment [] "eliminate" emptyGoal
    assertEqual "an unrelated void assumption cannot capture empty elimination"
        (Realized ["eliminate a = case a of {}"])
        (reportOutcome collisionSafe)

testEnvironmentValidation :: IO ()
testEnvironmentValidation = do
    let base =
            [ ("Base", ([], HTUnion [("Base", [])], KStar))
            , ("Alias", ([], HTCon "Base", KStar))
            ]
        withoutBase = filter ((/= "Base") . fst) base
        changedArity =
            ("Base", (["a"], HTVar "a", KStar)) : withoutBase
        axiom = ("given", HTCon "Base")
        classDefinition =
            ("UsesBase", ([], [("useBase", HTCon "Base")]))
        invalidTypes =
            [ ("Alias", (["a"], HTVar "a", KStar))
            , ("Broken", ([], HTCon "Alias", KStar))
            ]
        invalidAxioms =
            [ ("first", HTCon "MissingFirst")
            , ("second", HTCon "MissingSecond")
            ]
        invalidClass =
            ("BrokenClass",
                ([], [ ("firstMethod", HTCon "MissingFirst")
                     , ("secondMethod", HTCon "MissingSecond")
                     ]))
    assertLeft "deletion must reject a dependent synonym"
        (validateEnvironment withoutBase [] [])
    assertLeft "replacement must reject a newly unsaturated dependency"
        (validateEnvironment changedArity [] [])
    assertLeft "deletion must reject a dependent axiom"
        (validateEnvironment [] [axiom] [])
    assertLeft "deletion must reject a dependent class method"
        (validateEnvironment [] [] [classDefinition])
    assertRight "an unrelated declaration set should still rebuild"
        (validateEnvironment
            [("Other", ([], HTUnion [("Other", [])], KStar))]
            [] [])
    -- Batch preparation must not change the transactional validation order:
    -- types precede values, values precede classes, and methods retain source
    -- order within their class.
    assertLeftContains "type errors still precede dependent declarations"
        "type environment: Type synonym Alias"
        (validateEnvironment invalidTypes invalidAxioms [invalidClass])
    assertLeftContains "axioms still precede classes in source order"
        "axiom first:"
        (validateEnvironment [] invalidAxioms [invalidClass])
    assertLeftContains "class methods still retain source order"
        "method firstMethod of class BrokenClass:"
        (validateEnvironment [] [] [invalidClass])

    -- The raw rebuilding boundary must seal the same declaration namespaces
    -- as the shared environment used by public editing.  These malformed
    -- environments used to survive because kind inference indexes only type
    -- constructors and the legacy value preflight indexes only functions and
    -- methods.
    assertLeftContains "one datatype cannot repeat a constructor"
        "DuplicateConstructorName"
        (validateEnvironment
            [("Repeated", ([],
                HTUnion [("RepeatedValue", []), ("RepeatedValue", [])],
                KStar))]
            [] [])
    assertLeftMessage "constructors are unique across datatype owners"
        "Value name is already declared: SharedConstructor"
        (validateEnvironment
            [ ("FirstOwner", ([], HTUnion [("SharedConstructor", [])],
                KStar))
            , ("SecondOwner", ([], HTUnion [("SharedConstructor", [])],
                KStar))
            ]
            [] [])
    assertLeftMessage "types and classes share their owner namespace"
        "Type name is already declared: SharedOwner"
        (validateEnvironment
            [("SharedOwner", ([], HTUnion [("OnlyConstructor", [])], KStar))]
            [] [("SharedOwner", ([], []))])

testPrintedValueNamespace :: IO ()
testPrintedValueNamespace = do
    let bool = HTCon "Bool"
        selectable = ClassDecl "Selectable" ["a"]
            [("select", HTVar "a")]
        sharedConflict = "Value name is already declared: select"
        rawConflict =
            "Function assumption select conflicts with method select " ++
            "of class Selectable"

    functionFirst <- expectRight $
        declare (Function "select" bool) standardEnvironment
    assertLeftMessage "a later class method must not shadow an assumption"
        sharedConflict (declare selectable functionFirst)

    classFirst <- expectRight $ declare selectable standardEnvironment
    assertLeftMessage "a later assumption must not shadow a class selector"
        sharedConflict (declare (Function "select" bool) classFirst)
    assertLeftMessage "operator selectors share the same printed namespace"
        "Value name is already declared: (==)"
        (declare (Function "==" bool) standardEnvironment)

    -- Qualified references retain their qualification in generated code and
    -- therefore cannot shadow an unqualified selector with the same suffix.
    qualifiedFirst <- expectRight $
        declare (Function "External.select" bool) standardEnvironment
    qualifiedWithClass <- expectRight $ declare selectable qualifiedFirst
    assertEqual "the qualified assumption remains alongside the selector"
        (Just bool)
        (lookup "External.select" $ functionDeclarations qualifiedWithClass)
    assertBool "the class declaration is retained too" $
        "Selectable" `elem` map fst (classDeclarations qualifiedWithClass)
    _ <- expectRight $ declare (Function "External.select" bool) classFirst

    -- Removing the owning declaration releases the spelling, while failed
    -- candidates leave their immutable input environment untouched.
    withoutFunction <- expectRight $ removeDeclaration "select" functionFirst
    _ <- expectRight $ declare selectable withoutFunction
    withoutClass <- expectRight $ removeDeclaration "Selectable" classFirst
    _ <- expectRight $ declare (Function "select" bool) withoutClass

    -- The internal rebuilding boundary owns the invariant as well; it is not
    -- merely an ad-hoc check in the two public declaration branches.
    assertLeftMessage "raw environment validation rejects the same ambiguity"
        rawConflict
        (validateEnvironment [] [("select", HTVar "a")]
            [("Selectable", ([("a", KStar)], [("select", HTVar "a")]))])
    assertLeftContains "raw validation rejects duplicate assumptions"
        "Duplicate function assumption: duplicate"
        (validateEnvironment []
            [("duplicate", bool), ("duplicate", bool)] [])
    assertLeftContains "duplicate precedence follows the first occurrence"
        "Duplicate function assumption: first"
        (validateEnvironment []
            [ ("first", bool)
            , ("second", bool)
            , ("second", bool)
            , ("first", bool)
            ] [])
    assertLeftContains "raw validation rejects duplicate class owners"
        "Duplicate class: Selectable"
        (validateEnvironment [] []
            [ ("Selectable", ([("a", KStar)], []))
            , ("Selectable", ([("a", KStar)], []))
            ])

testTrustedUnitDeclaration :: IO ()
testTrustedUnitDeclaration = do
    let exactUnit = ([], HTUnion [("()", [])], KStar)
        declarationFailure = "() is a built-in type and cannot be declared"
    assertEqual "the standard environment contains exactly the wired-in unit"
        (Just exactUnit) (lookup "()" $ typeDeclarations standardEnvironment)

    unitType <- expectRight $ parseHType "()"
    report <- expectRight $
        inhabit defaultQueryOptions standardEnvironment [] "unitValue" unitType
    assertEqual "the trusted constructor still realizes the unit type"
        (Realized ["unitValue = ()"]) (reportOutcome report)

    -- The spelling remains valid inside ordinary type expressions.
    assertRight "a synonym body may refer to the built-in unit" $
        declare (TypeSynonym "UnitAlias" [] unitType) standardEnvironment
    assertRight "a constructor field may have the built-in unit type" $
        declare (DataType "CarriesUnit" [] [("CarriesUnit", [unitType])])
            standardEnvironment

    -- It is not, however, a user-definable ConId.  In particular, the exact
    -- standard declaration is private rather than a loophole in this rule.
    assertLeftMessage "a unit-named synonym is rejected" declarationFailure
        (declare (TypeSynonym "()" [] $ HTCon "Bool") standardEnvironment)
    assertLeftMessage "a unit-named abstract type is rejected" declarationFailure
        (declare (AbstractType "()" KStar) standardEnvironment)
    assertLeftMessage "a unit-named data type is rejected" declarationFailure
        (declare (DataType "()" [] []) standardEnvironment)
    assertLeftMessage "even the exact built-in data declaration is private"
        declarationFailure
        (declare (DataType "()" [] [("()", [])]) emptyEnvironment)
    assertLeftMessage "a unit-named class is rejected" declarationFailure
        (declare (ClassDecl "()" [] []) standardEnvironment)
    assertLeftMessage "the unit constructor cannot belong to another type"
        declarationFailure
        (declare (DataType "CounterfeitUnit" [] [("()", [])])
            standardEnvironment)

    assertLeftMessage "the trusted unit cannot be deleted and recreated"
        "() is a built-in type and cannot be removed"
        (removeDeclaration "()" standardEnvironment)
    assertLeftMessage "unit protection follows the parsed structural name"
        "() is a built-in type and cannot be removed"
        (removeDeclaration " () " standardEnvironment)

testScopeSafeRendering :: IO ()
testScopeSafeRendering = do
    let shadowed = Symbol "x"
        term = Lam shadowed $
            Apply (Var shadowed) (Lam shadowed $ Var shadowed)
    rendered <- renderTerm "applyIdentity" term
    assertEqual "nested shadowing binders should receive distinct names"
        "applyIdentity a = a (\\b -> b)" rendered
    let generatedPrefix = Symbol "__djinn1"
        argument = Symbol "argument"
        externalTerm = Lam argument $
            Apply (Var generatedPrefix) (Var argument)
    assertRendered "a generated-prefix external assumption remains free"
        "applyExternal = __djinn1" "applyExternal" externalTerm

    -- This spelling is also the first field name the payload elaborator would
    -- prefer for its first alpha-renamed branch binder.  Reserving all source
    -- names forces a different local binder and prevents a string collision
    -- from hiding a scope leak from the final validator.
    let externalField = Symbol "__djinn1_field1"
        choice = Symbol "choice"
        payload = Symbol "payload"
        constructor = ConsDesc "C" 2
        caseTerm = applys (Ccases [constructor])
            [ Var choice
            , Lam payload $ Apply (Var externalField) (Var payload)
            ]
    renderedCase <- renderTerm "applyPayload" caseTerm
    assertContains "the adversarial external name must remain untouched"
        "__djinn1_field1" renderedCase
    assertContains "the constructor fields must still be lexically bound"
        "C a b -> __djinn1_field1 (a, b)" renderedCase

testMalformedRendering :: IO ()
testMalformedRendering = do
    let source = Symbol "source"
        payload = Symbol "payload"
        negativeInjection = Apply
            (Cinj (ConsDesc "Just" 1) (-1)) (Var payload)
        negativeCase = applys (Ccases [ConsDesc "Just" (-1)])
            [Var source, Lam payload $ Ctuple 0]
    assertLeft "legacy selectors should return a conversion error"
        (termToHExpr $ Xsel 0 1 $ Var $ Symbol "x")
    assertLeft "bare non-unit tuple combinators should not crash"
        (termToHExpr $ Ctuple 2)
    assertLeft "case alternatives must be lambdas"
        (termToHExpr $ applys (Ccases [ConsDesc "Only" 1])
            [Var $ Symbol "choice", Var $ Symbol "handler"])
    assertLeftMessage "negative injection indices cannot disappear in lowering"
        "injection index is negative: -1"
        (termToHExpr negativeInjection)
    assertLeftMessage "clause lowering shares injection metadata validation"
        "injection index is negative: -1"
        (termToHClause "badInjection" negativeInjection)
    assertLeftMessage "negative case payload arities cannot become nullary"
        "constructor arity is negative: -1"
        (termToHExpr negativeCase)
    assertLeftMessage "clause lowering shares case metadata validation"
        "constructor arity is negative: -1"
        (termToHClause "badCase" negativeCase)
    assertLeftMessage "negative injection payload arities are rejected"
        "constructor arity is negative: -1"
        (termToHExpr $ Apply
            (Cinj (ConsDesc "Just" (-1)) 0) (Var payload))
    assertLeftMessage "negative tuple arities are rejected before conversion"
        "tuple arity is negative: -1"
        (termToHExpr $ Ctuple (-1))
    assertLeftMessage "negative split arities are rejected before conversion"
        "split arity is negative: -1"
        (termToHExpr $ Csplit (-1))

testGeneratedClauseBoundary :: IO ()
testGeneratedClauseBoundary = do
    let duplicateTupleBinder = DjinnGenerated.HClause "badTuple"
            [DjinnGenerated.HPTuple
                [DjinnGenerated.HPVar "value", DjinnGenerated.HPVar "value"]]
            (DjinnGenerated.HEVar "value")
        duplicateAsBinder = DjinnGenerated.HClause "badAs"
            [DjinnGenerated.HPAt "value" $ DjinnGenerated.HPVar "value"]
            (DjinnGenerated.HEVar "value")
        invalidDefinition = DjinnGenerated.HClause "Result" []
            (DjinnGenerated.HEVar "value")
        invalidDefinitionAndScope = DjinnGenerated.HClause "Result"
            [DjinnGenerated.HPVar "value", DjinnGenerated.HPVar "value"]
            (DjinnGenerated.HEVar "value")
        lowercaseConstructor = DjinnGenerated.HClause "badConstructor" []
            (DjinnGenerated.HECon "lower")
        uppercaseFreeValue = DjinnGenerated.HClause "badValue" []
            (DjinnGenerated.HEVar "Upper")
    assertLeftContains "tuple patterns cannot bind a local twice"
        "DuplicatePatternBinder \"value\""
        (DjinnGenerated.toGeneratedClause duplicateTupleBinder)
    assertLeftContains "as-patterns cannot bind a local twice"
        "DuplicatePatternBinder \"value\""
        (DjinnGenerated.toGeneratedClause duplicateAsBinder)
    assertLeftContains "raw clauses reject invalid definition names"
        "InvalidFunctionName Result"
        (DjinnGenerated.toGeneratedClause invalidDefinition)
    assertLeftContains "scope errors retain precedence over definition syntax"
        "DuplicatePatternBinder \"value\""
        (DjinnGenerated.toGeneratedClause invalidDefinitionAndScope)
    assertLeftContains "legacy constructor nodes retain their lexical role"
        "expected a constructor-like name"
        (DjinnGenerated.toGeneratedClause lowercaseConstructor)
    assertLeftContains "legacy free-value nodes retain their lexical role"
        "expected a variable-like name"
        (DjinnGenerated.toGeneratedClause uppercaseFreeValue)
    assertLeftContains "raw proof values cannot become constructors by spelling"
        "expected a variable-like name"
        (termToHExpr $ Var $ Symbol "Upper")
    assertLeftContains
        "raw proof constructors cannot become values by spelling"
        "expected a constructor-like name"
        (termToHExpr $
            Apply (Cinj (ConsDesc "lower" 0) 0) (Ctuple 0))

    checkedProjection <- expectShownRight $ SharedGenerated.mkDefinitionName
        $ sharedName "projected"
    let just = sharedName "Just"
        sharedProjection = SharedGenerated.FunctionClause checkedProjection
            [SharedGenerated.As "whole" $
                SharedGenerated.Constructor just
                    [SharedGenerated.Bind "value"]]
            (SharedGenerated.Case (SharedGenerated.Local "whole")
                [ ( SharedGenerated.Constructor just
                        [SharedGenerated.Bind "nested"]
                  , SharedGenerated.Tuple
                        [ SharedGenerated.Local "value"
                        , SharedGenerated.Local "nested"
                        ]
                  )
                ])
    legacyProjection <- either fail return $
        DjinnGenerated.fromGeneratedClause sharedProjection
    assertEqual "legacy generated syntax is an on-demand lossless view"
        (Right sharedProjection)
        (DjinnGenerated.toGeneratedClauseWithName
            checkedProjection legacyProjection)
    assertLeftContains "legacy expressions reject shared holes explicitly"
        "cannot represent generated holes"
        (DjinnGenerated.fromGeneratedExpression $
            SharedGenerated.Hole "missing")
    assertLeftContains "legacy expressions reject shared lets explicitly"
        "cannot represent generated lets"
        (DjinnGenerated.fromGeneratedExpression $
            SharedGenerated.Let (SharedGenerated.Bind "bound")
                (SharedGenerated.Tuple [])
                (SharedGenerated.Local "bound"))

    goals <- mapM (either fail return . parseHType)
        ["a -> a", "a -> b -> a"]
    reports <- mapM
        (either fail return .
            inhabitGenerated defaultQueryOptions emptyEnvironment [] "generated")
        goals
    let candidates = concatMap generatedReportCandidates reports
    assertEqual "representative proofs should reach the generated boundary"
        2 (length candidates)
    mapM_ validateCandidate candidates
  where
    validateCandidate candidate = do
        let clause = SharedCandidate.candidateOutput candidate
        assertEqual "generated clause retains its checked definition"
            "generated" $ SharedGenerated.definitionSpelling
                $ SharedGenerated.clauseName clause
        assertEqual "generated candidate has valid lexical scope"
            (Right ()) $ SharedGenerated.validateFunctionClauseScope clause
        assertEqual "generated candidate has valid renderer-independent syntax"
            (Right ()) $ SharedGenerated.validateFunctionClauseSyntax
                SharedGenerated.FullyQualified clause

testKeywordTokens :: IO ()
testKeywordTokens = do
    mapM_ rejectGluedKeyword
        [ ("type", "Foo")
        , ("data", "Bar")
        , ("class", "Quux")
        , ("where", "identity")
        , ("instance", "Quux")
        ]
    assertParses "white space terminates an alphabetic keyword"
        (skeyword "type" >> pConId) "type Foo"
    assertParses "punctuation terminates an alphabetic keyword"
        (skeyword "instance" >> pParen pHConstraint)
        "instance(Eq a)"
    assertParses "a stripped line comment terminates a keyword"
        (skeyword "where") (stripLineComments "where-- trailing\n")
    assertDoesNotParse "the keyword helper is not for symbolic tokens"
        (skeyword "::") "::"
    assertParses "ordinary symbolic tokens retain boundary-free matching"
        (sstring "::") "::"
  where
    rejectGluedKeyword (keyword, suffix) =
        assertDoesNotParse
            (keyword ++ " must not consume the prefix of " ++
                keyword ++ suffix)
            (skeyword keyword) (keyword ++ suffix)

testIdentifiers :: IO ()
testIdentifiers = do
    assertParses "leading underscores are valid variable identifiers"
        pVarId "_compose'"
    assertParses "Unicode lowercase letters are variable identifiers"
        pVarId "λvalue"
    assertParses "Unicode uppercase letters are constructor identifiers"
        pConId "Δelta"
    assertParses "qualified external variables are valid"
        pQualifiedVarId "Data.Function.id"
    assertParses "qualified Unicode variables are valid"
        pQualifiedVarId "Data.λvalue"
    assertParses "qualified constructors are valid"
        pQualifiedConId "Data.Maybe.Maybe"
    assertBool "identifier lexical classes remain distinct"
        (isVarId "value" && not (isConId "value") &&
         isConId "Value" && not (isVarId "Value"))
    assertBool "qualified constructor lexical classes remain distinct"
        (isQualifiedConId "Data.Maybe.Just" &&
         not (isQualifiedVarId "Data.Maybe.Just"))
    assertParses "the full ASCII operator alphabet is available"
        pParenthesizedVarOp "(/?)"
    assertParses "Unicode Haskell operators are available"
        pParenthesizedVarOp "(⊕)"
    assertBool "Unicode operators retain their variable lexical class"
        (isVarOperator "⊕" && renderVarName "⊕" == "(⊕)")
    assertEqual "proof symbols keep unqualified operators bare"
        "⊕" (renderProofSymbolName $ sharedName "(⊕)")
    assertDoesNotParse "constructor operators are not term binding names"
        pParenthesizedVarOp "(:+:)"
    assertBool "constructor operators remain outside the variable namespace"
        (not (isVarOperator ":+:") && renderVarName ":+:" == ":+:")
    assertDoesNotParse "reserved words are not identifiers" pVarId "case"
    assertDoesNotParse "a bare underscore is not a binding name" pVarId "_"
    assertBool "the complete shared reserved-word policy reaches Djinn"
        (all (not . isVarId) ["_", "as", "case", "module", "where"])
    assertDoesNotParse "module segments must be constructors"
        pQualifiedVarId "data.module.value"
    assertDoesNotParse "lowercase intermediate module segments are invalid"
        pQualifiedVarId "Data.internal.value"
    assertDoesNotParse "leading qualification dots are invalid"
        pQualifiedVarId ".Data.value"
    assertDoesNotParse "empty qualification segments are invalid"
        pQualifiedVarId "Data..value"
    assertDoesNotParse "trailing qualification dots are invalid"
        pQualifiedVarId "Data.value."
    assertBool "classification does not inherit parseName whitespace trimming"
        (not $ isQualifiedVarId " Data.value")
    assertParses "ReadP still owns and consumes leading whitespace"
        pQualifiedVarId " Data.value"
    assertDoesNotParse "qualified operators remain outside Djinn's grammar"
        pQualifiedVarId "Data.(+)"
    assertBool "qualified operators are not reclassified as identifiers"
        (not (isQualifiedVarId "Data.(+)") &&
         renderVarName "Data.(+)" == "Data.(+)")
    assertEqual "proof symbols keep qualified operators canonical"
        "Data.(+)" (renderProofSymbolName $ sharedName "Data.(+)")
    assertDoesNotParse "reserved operators are invalid binding names"
        pParenthesizedVarOp "(->)"
    assertDoesNotParse "a line-comment introducer is not an operator name"
        pParenthesizedVarOp "(--)"
    assertBool "the complete shared reserved-operator policy reaches Djinn"
        (all (not . isVarOperator)
            ["..", "--", ":", "::", "=", "\\", "|", "<-", "->", "@", "~", "=>"])
    assertEqual "underscore identifiers must not be printed as operators"
        "_compose" (prHSymbolOp "_compose")
    assertEqual "qualified variables must remain prefix names"
        "Data.Function.id" (prHSymbolOp "Data.Function.id")
    assertEqual "operators should be parenthesized in prefix positions"
        "(/?)" (prHSymbolOp "/?")
    assertEqual "qualified type constructors should parse structurally"
        (Just $ HTApp (HTCon "Data.Maybe.Maybe") (HTVar "a"))
        (readMaybe "Data.Maybe.Maybe a")
    assertEqual "ordinary command-file comments are removed"
        "identity ? a -> a \n\n"
        (stripLineComments "identity ? a -> a -- trailing\n-- whole line\n")
    assertEqual "dash-prefixed operators are not mistaken for comments"
        "(--*) :: a -> a\n"
        (stripLineComments "(--*) :: a -> a\n")
    assertEqual "Unicode symbols also continue dash-prefixed operators"
        "(--⊕) :: a -> a\n"
        (stripLineComments "(--⊕) :: a -> a\n")
    assertEqual "line-comment markers inside strings remain literal"
        "import \"pkg--name\" A \n"
        (stripLineComments "import \"pkg--name\" A -- trailing\n")
    assertEqual "escaped string quotes do not expose comment markers"
        "\"quoted \\\"--\\\" text\" \n"
        (stripLineComments "\"quoted \\\"--\\\" text\" -- trailing\n")
    assertEqual "escaped character quotes do not expose comments"
        "'\\\'' \n"
        (stripLineComments "'\\\'' -- trailing\n")
    assertEqual "identifier apostrophes do not hide trailing comments"
        "value' \n"
        (stripLineComments "value' -- trailing\n")
    assertEqual "promotion ticks do not hide trailing comments"
        "'Just a \n"
        (stripLineComments "'Just a -- trailing\n")

atomA :: Formula
atomA = PVar $ Symbol "a"

atomB :: Formula
atomB = PVar $ Symbol "b"

atomC :: Formula
atomC = PVar $ Symbol "c"

assertLeft :: Show a => String -> Either String a -> IO ()
assertLeft _ (Left _) = return ()
assertLeft message (Right value) =
    fail $ message ++ ": expected an error, got " ++ show value

assertLeftMessage :: Show a => String -> String -> Either String a -> IO ()
assertLeftMessage message expected result =
    case result of
        Left actual -> assertEqual message expected actual
        Right value ->
            fail $ message ++ ": expected an error, got " ++ show value

assertLeftContains :: Show a => String -> String -> Either String a -> IO ()
assertLeftContains message expectedFragment result =
    case result of
        Left actual -> assertContains message expectedFragment actual
        Right value ->
            fail $ message ++ ": expected an error, got " ++ show value

assertRight :: String -> Either String a -> IO ()
assertRight _ (Right _) = return ()
assertRight message (Left errorMessage) =
    fail $ message ++ ": unexpected error: " ++ errorMessage

assertRendered :: String -> String -> HSymbol -> Term -> IO ()
assertRendered message expected name term = do
    actual <- renderTerm name term
    assertEqual message expected actual

renderTerm :: HSymbol -> Term -> IO String
renderTerm name term =
    case termToHClause name term of
        Left message -> fail $ "proof rendering failed: " ++ message
        Right clause -> either
            (fail . ("shared clause rendering failed: " ++))
            return
            (hPrClause clause)

assertParses :: String -> ReadP a -> String -> IO ()
assertParses message parser input =
    assertBool message $ not $ null $ parseFully parser input

assertDoesNotParse :: String -> ReadP a -> String -> IO ()
assertDoesNotParse message parser input =
    assertBool message $ null $ parseFully parser input

parseFully :: ReadP a -> String -> [a]
parseFully parser input =
    [value | (value, "") <- readP_to_S complete input]
  where
    complete = do
        value <- parser
        skipSpaces
        eof
        return value

assertContains :: String -> String -> String -> IO ()
assertContains message needle haystack =
    assertBool (message ++ ": " ++ show needle ++ " not found in " ++ show haystack)
        (needle `isInfixOf` haystack)

assertWordsSuffix :: String -> [String] -> String -> IO ()
assertWordsSuffix message suffix rendered =
    assertBool (message ++ ": got " ++ show rendered)
        (suffix `isSuffixOf` words rendered)
