# Reduction carrier boundary and unsuccessful experiments

The corrected native trace starts at Leant 3b24ebbd4022255b8e22888408d7e890984f3887
and Djex ebadbefd175ac98d4f79393d4ed4a4089a1725bf. Apply the trace-preparation
patch and use trace-v2/source for exact inputs. The original two queries come
from the separately published native-reductions-baseline archive, whose hash
is recorded. Adapt local runtime paths and use fresh output directories.

trace-v1 has a failed input equality check: the runner doubled CR in Windows
line endings. Its nonempty command lines match the original input, but it is
not the authoritative corrected capture. trace-v2 normalizes input line endings
before submission and passes both input comparisons and final integrity checks.
No search policy changes are in these temporary traces.

The canonical baseline and continuation experiment use Djex 1481e918 plus the
retained change.patch/source overlays. Both strict builds pass; neither left
nor right reduction passes the new behavioral regression at 65536 candidates
and 500000 choices. The continuation experiment passes all 97 private Exference
engine tests. The fixed-carrier control is a DIFFERENT, monomorphic-fold target;
it ends at the Tasty 120-second diagnostic timeout, not a completed exhaustive
search. The native continuation experiment includes only the Exference rule
on accepted Leant/Djex source. Its strict build, oracle and actual False control
pass, but foldl1 misses. No full release validation or new Church acceptance
follows from any experiment here. Source, runtime and controller hashes pass.

The source snapshots retain the unaccepted construction rules and regressions.
They can be reconstructed without relying on the current mutable workspaces.
