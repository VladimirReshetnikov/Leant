{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds #-}
module Main where
import Fixture
probe :: forall (f :: * -> *) a. f a -> f a
probe = ((\ @f @a -> (let { djexPoly54 :: forall (djexSkolem54 :: (*) -> *). forall (djexBound0_0 :: *). djexSkolem54 djexBound0_0 -> djexSkolem54 djexBound0_0; djexPoly54 = (let { djexPoly35 :: forall (djexSkolem35 :: *). djexSkolem54 djexSkolem35 -> djexSkolem54 djexSkolem35; djexPoly35 = (\(a :: djexSkolem54 djexSkolem35) -> a) } in djexPoly35) } in djexPoly54)) :: forall (f :: * -> *) a . f a -> f a)
main :: IO ()
main = print (probe @[] [7 :: Int] == [7])
