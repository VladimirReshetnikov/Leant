{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds #-}
module Main where
import Fixture
probe :: forall a. a -> (forall (f :: * -> *). a)
probe = ((\ @a -> (let { djexPoly54 :: forall (djexSkolem54 :: *). djexSkolem54 -> forall (djexBound0_0 :: (*) -> *). djexSkolem54; djexPoly54 = (\(a :: djexSkolem54) -> (let { djexPoly27 :: forall (djexSkolem27 :: (*) -> *). djexSkolem54; djexPoly27 = a } in djexPoly27)) } in djexPoly54)) :: forall a . a -> (forall (f :: * -> *) . a))
main :: IO ()
main = print (probe @Int 7 @[] == 7)
