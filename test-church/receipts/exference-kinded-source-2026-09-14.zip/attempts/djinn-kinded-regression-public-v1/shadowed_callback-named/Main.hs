{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds #-}
module Main where
import Fixture
probe :: forall (f :: * -> *) b. ((forall (f :: *) a. a -> a) -> b) -> b
probe a = a (\b -> b)
main :: IO ()
main = print (probe @[] (\h -> h @Int (7 :: Int)) == 7)
