{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds #-}
module Main where
import Fixture
probe :: forall b. ((forall (f :: * -> *) a. a -> a) -> b) -> b
probe a = a (\b -> b)
main :: IO ()
main = print (probe (\h -> h @[] (7 :: Int)) == 7)
