{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds #-}
module Main where
import Fixture
probe :: forall b. ((forall (f :: * -> *) a. f a -> f a) -> b) -> b
probe = ((\ @b -> (let { djexPoly170 :: forall (djexSkolem170 :: *). ((forall (djexBound0_0 :: (*) -> *) (djexBound0_1 :: *). djexBound0_0 djexBound0_1 -> djexBound0_0 djexBound0_1) -> djexSkolem170) -> djexSkolem170; djexPoly170 = (\(a :: (forall (djexBound0_0 :: (*) -> *) (djexBound0_1 :: *). djexBound0_0 djexBound0_1 -> djexBound0_0 djexBound0_1) -> djexSkolem170) -> ((a) ((let { djexPoly104 :: forall (djexSkolem104 :: (*) -> *). forall (djexBound0_0 :: *). djexSkolem104 djexBound0_0 -> djexSkolem104 djexBound0_0; djexPoly104 = (let { djexPoly77 :: forall (djexSkolem77 :: *). djexSkolem104 djexSkolem77 -> djexSkolem104 djexSkolem77; djexPoly77 = (\(b :: djexSkolem104 djexSkolem77) -> b) } in djexPoly77) } in djexPoly104) :: forall (djexBound0_0 :: (*) -> *) (djexBound0_1 :: *). djexBound0_0 djexBound0_1 -> djexBound0_0 djexBound0_1))) } in djexPoly170)) :: forall b . ((forall (f :: * -> *) a . f a -> f a) -> b) -> b)
main :: IO ()
main = print (probe (\h -> h @Maybe (Just (7 :: Int))) == Just 7)
