{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds #-}
module Main where
import Fixture
probe :: forall b. ((forall (f :: * -> *) a. f a -> f a) -> b) -> b
probe a = a (\b -> b)
main :: IO ()
main = print (probe (\h -> h @Maybe (Just (7 :: Int))) == Just 7)
