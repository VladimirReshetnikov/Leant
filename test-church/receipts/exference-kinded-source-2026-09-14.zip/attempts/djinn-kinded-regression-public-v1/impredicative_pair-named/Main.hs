{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds #-}
module Main where
import Fixture
probe :: forall (f :: * -> *). ((forall a. a -> a), (forall a. a -> a))
probe = (\a -> a, \b -> b)
main :: IO ()
main = print (case probe @[] of (left, right) -> left (7 :: Int) == 7 && right True)
