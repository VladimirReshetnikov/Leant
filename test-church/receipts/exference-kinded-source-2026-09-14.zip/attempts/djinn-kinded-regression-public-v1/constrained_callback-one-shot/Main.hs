{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds #-}
module Main where
import Fixture
probe :: forall b. ((forall (f :: * -> *) a. Fixture.Marker a => a -> a) -> b) -> b
probe = ((\ @b -> (let { djexPoly209 :: forall (djexSkolem209 :: *). ((forall (djexBound0_0 :: (*) -> *) (djexBound0_1 :: *). (Marker djexBound0_1) => djexBound0_1 -> djexBound0_1) -> djexSkolem209) -> djexSkolem209; djexPoly209 = (\(a :: (forall (djexBound0_0 :: (*) -> *) (djexBound0_1 :: *). (Marker djexBound0_1) => djexBound0_1 -> djexBound0_1) -> djexSkolem209) -> ((a) ((let { djexPoly135 :: forall (djexSkolem135 :: (*) -> *). forall (djexBound0_0 :: *). (Marker djexBound0_0) => djexBound0_0 -> djexBound0_0; djexPoly135 = (let { djexPoly104 :: forall (djexSkolem104 :: *). (Marker djexSkolem104) => djexSkolem104 -> djexSkolem104; djexPoly104 = ((\(b :: djexSkolem104) -> b) :: (Marker djexSkolem104) => djexSkolem104 -> djexSkolem104) } in djexPoly104) } in djexPoly135) :: forall (djexBound0_0 :: (*) -> *) (djexBound0_1 :: *). (Marker djexBound0_1) => djexBound0_1 -> djexBound0_1))) } in djexPoly209)) :: forall b .   ((forall (f :: * -> *) a . Fixture.Marker a => a -> a) -> b) -> b)
main :: IO ()
main = print (probe (\h -> h @[] (7 :: Int)) == 7)
