{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds #-}
module Main where
import Fixture
probe :: forall a. Fixture.Identity (forall (f :: * -> *). a) -> a
probe = ((\ @a -> (let { djexPoly54 :: forall (djexSkolem54 :: *). (forall (djexBound0_0 :: (*) -> *). djexSkolem54) -> djexSkolem54; djexPoly54 = (\(a :: forall (djexBound0_0 :: (*) -> *). djexSkolem54) -> ((a :: forall (djexBound0_0 :: (*) -> *). djexSkolem54) @(([])))) } in djexPoly54)) :: forall a . Fixture.Identity (forall (f :: * -> *) . a) -> a)
main :: IO ()
main = print (probe @Int (7 :: forall (f :: * -> *). Int) == 7)
