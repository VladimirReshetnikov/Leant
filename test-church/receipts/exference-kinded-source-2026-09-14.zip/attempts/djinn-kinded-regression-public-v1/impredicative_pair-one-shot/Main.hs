{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds #-}
module Main where
import Fixture
probe :: forall (f :: * -> *). ((forall a. a -> a), (forall a. a -> a))
probe = ((\ @f -> (let { djexPoly170 :: forall (djexSkolem170 :: (*) -> *). (forall (djexBound0_0 :: *). djexBound0_0 -> djexBound0_0, forall (djexBound0_0 :: *). djexBound0_0 -> djexBound0_0); djexPoly170 = ((let { djexPoly35 :: forall (djexSkolem35 :: *). djexSkolem35 -> djexSkolem35; djexPoly35 = (\(a :: djexSkolem35) -> a) } in djexPoly35), (let { djexPoly119 :: forall (djexSkolem119 :: *). djexSkolem119 -> djexSkolem119; djexPoly119 = (\(b :: djexSkolem119) -> b) } in djexPoly119)) } in djexPoly170)) :: forall (f :: * -> *) . ((forall a . a -> a), (forall a . a -> a)))
main :: IO ()
main = print (case probe @[] of (left, right) -> left (7 :: Int) == 7 && right True)
