Exference public ground-kind synthesis, 2026-09-14.
Final regression: attempts/exference-kinded-regression-v2/results.json.
Final public matrices: attempts/exference-kinded-public-v3/results.json and
attempts/djinn-kinded-regression-public-v1/results.json.
Each public matrix has 22 exact GHC replays, 11 False controls, one bad-kind rejection.
Earlier failed builds, the failed certificate regression, and prior passing snapshots are separate.
Includes captured source, commands, process transcripts, and runtime hashes.
Compiled binaries and object files are not embedded.
No native dependency integration or Church behavior-ledger closure is claimed.
