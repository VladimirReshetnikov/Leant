module Main where

import Control.Exception (evaluate)
import Control.Monad (forM_)
import qualified Data.Set as Set
import GHC.Clock (getMonotonicTimeNSec)
import GHC.Stats (getRTSStats, allocated_bytes, gcdetails_live_bytes, gc)
import System.CPUTime (getCPUTime)
import System.Environment (getArgs)
import System.IO (hSetBuffering, stdout, BufferMode(LineBuffering))
import System.Timeout (timeout)
import Leant.Synth.Engine
import Leant.Synth.Fragment

main :: IO ()
main = do
  hSetBuffering stdout LineBuffering
  arguments <- getArgs
  let variable = FVar
      identity = FAll True "s0" (FArr (variable "s0") (variable "s0"))
      boolean = FAll True "s0"
        (FArr (variable "s0") (FArr (variable "s0") (variable "s0")))
      result headName arguments' = FApp False (headName ++ " arguments")
        (AppNominal headName) arguments'
      binary seed = FArr seed (FAll True "s0"
        (FArr (variable "s0") (FArr seed (FAll True "s1"
          (FArr (variable "s1") (result "Layered.G2" [variable "s0", variable "s1"]))))))
      ternary seed = FArr seed (FAll True "s0" (FAll True "s1"
        (FArr (variable "s0") (FArr (variable "s1") (FArr seed
          (FAll True "s2" (FArr (variable "s2")
            (result "Layered.G3" [variable "s0", variable "s1", variable "s2"]))))))))
      seed = FAtom False "Layered.Seed"
      providers = [ProviderFragWithBinders "Layered.maker2" (binary seed) [],
                   ProviderFragWithBinders "Layered.seed" seed [],
                   ProviderFragWithBinders "Layered.maker3" (ternary seed) []]
      goal = result "Layered.G2" [identity, boolean]
      bounds = defaultSynthLimits {synthLimitWindow = 1, synthLimitTried = 1, synthLimitShown = 1}
      stages = case arguments of
        ["djinn"] -> [(EngineDjinn, providers)]
        ["exference"] -> [(EngineExference, providers)]
        ["both"] -> [(EngineBoth, providers)]
        _ -> providerStagesWithRanking (synthLimitRanking bounds) EngineBoth providers
  forM_ stages $ \(engine, inventory) -> do
    putStrLn $ "START " ++ show engine ++ " providers=" ++ show (length inventory)
    before <- getMonotonicTimeNSec
    cpuBefore <- getCPUTime
    statsBefore <- getRTSStats
    let outcome = synthesizeWithProvidersSkippingDetailedWith bounds engine 4096 Set.empty inventory goal
    observed <- timeout 30000000 $ evaluate $ forceDetailedOutcome 1 outcome
    after <- getMonotonicTimeNSec
    cpuAfter <- getCPUTime
    statsAfter <- getRTSStats
    putStrLn $ "END wall=" ++ show (fromIntegral (after-before) / 1e9 :: Double)
      ++ " cpu=" ++ show (fromIntegral (cpuAfter-cpuBefore) / 1e12 :: Double)
      ++ " allocated=" ++ show (allocated_bytes statsAfter - allocated_bytes statsBefore)
      ++ " last_major_live=" ++ show (gcdetails_live_bytes $ gc statsAfter)
      ++ " timed_out=" ++ show (observed == Nothing)
    case observed of
      Nothing -> pure ()
      Just _ -> case outcome of
        Right (DetailedSynthCandidates (group : _) _) ->
          print $ detailedCandidateGroupVariants group
        Right (DetailedSynthNoTerm _) -> putStrLn "NO_TERM"
        Right (DetailedSynthRefuted sound) -> putStrLn $ "REFUTED " ++ show sound
        Left failure -> putStrLn failure
        _ -> putStrLn "OTHER_OUTCOME"
