from pathlib import Path
import hashlib,json,shutil
ROOT=Path('C:/Leant')
old=ROOT/'dist-newstyle/recursor-acceptance/tree-accumulator-proposal-v2'
new=ROOT/'test-recursive/tree-accumulator'
assert not new.exists()
shutil.copytree(old,new,ignore=shutil.ignore_patterns('__pycache__'))
p=new/'run_acceptance.py';s=p.read_text(encoding='utf-8')
s=s.replace('import shutil\n','import shutil\nimport shlex\n')
s=s.replace('LEANT = Path("C:/Leant")\nDJEX = Path("C:/Djex")',
'''LEANT = HERE.parents[1]
DJEX = LEANT / "lib/Djex"
BUILD_PROJECT = LEANT''')
start=s.index('def library_inputs():')
end=s.index('\n\ndef main():',start)
s=s[:start]+'''def library_inputs(directories):
    paths = [path for directory in directories for path in directory.glob("*HSdjex*")
             if path.is_file() and path.suffix in {".a", ".dll", ".so", ".dylib"}]
    require(paths, "no built Djex library in the configured Cabal package database")
    return paths
'''+s[end:]
s=s.replace('def main():\n', 'def main():\n    global DJEX, BUILD_PROJECT\n',1)
s=s.replace('    args = parser.parse_args()', '''    parser.add_argument("--djex-root", type=Path, default=DJEX,
                        help="Djex source checkout; defaults to Leant's vendored dependency")
    parser.add_argument("--haskell-project", type=Path,
                        help="Cabal project owning the prebuilt Djex library; defaults to Leant for its vendored dependency")
    args = parser.parse_args()
    DJEX = args.djex_root.resolve()
    BUILD_PROJECT = (args.haskell_project or
                     (LEANT if DJEX == (LEANT / "lib/Djex").resolve() else DJEX)).resolve()''',1)
s=s.replace('report["library_inputs"] = hashes(library_inputs())', '''located = run("haskell-library-location", [cabal, "exec", "--", "ghc-pkg",
                    "field", "djex", "library-dirs", "--simple-output"], cwd=BUILD_PROJECT)
                directories = [Path(token.strip('"')) for token in shlex.split(located.stdout, posix=False)]
                report["library_inputs"] = hashes(library_inputs(directories))''')
s=s.replace('"-package", "djex"], cwd=DJEX)', '"-package", "djex"], cwd=BUILD_PROJECT)')
s=s.replace('"Root-owned, serial acceptance of ONE supplied tree-accumulator operation.', '"Serial acceptance of one supplied tree-accumulator operation.')
s=s.replace('Root must first build both frozen\nprojects.', 'Build the selected project and executables before running this fixture.')
p.write_text(s,encoding='utf-8')
p=new/'prepare.py';s=p.read_text(encoding='utf-8')
start=s.index('base_paths = [');end=s.index('\nwrite("case.json"',start)
s=s[:start]+'''project = OUT.parents[1]
base_paths = [project / "test-recursive/run_recursors.py",
              project / "lib/Djex/test-integration/RecursorSpec.hs"]
'''+s[end:]
s=s.replace('dict(path=path, sha256=digest(path)) for path in base_paths',
            'dict(path=path.relative_to(project).as_posix(), sha256=digest(path)) for path in base_paths')
s=s.replace('status="source_preparation_only"', 'status="specification_only"')
s=s.replace('path.name not in ("manifest.json",)', 'path.name not in ("manifest.json",) and "__pycache__" not in path.parts')
p.write_text(s,encoding='utf-8')
(new/'README.md').write_text('''# Supplied-fold tree accumulation

This is a manual behavioral acceptance fixture for priority 2. The initial
recorded runs do **not** accept a synthesized accumulator in either Haskell
engine. Lean's corrected oracle proofs pass; its live engine results are
recorded separately. See the current search report before treating any cell
as accepted. This fixture is not part of the passing unit-test count.

The target threads a caller-supplied state through tree leaves from left to
right, using only a generic fold and the tree constructors:

```haskell
forall a s. (s -> a -> s) -> s -> Tree a -> s
```

```lean
{α σ : Type} → (σ → α → σ) → σ → TreeAccumulatorFixture.Tree α → σ
```

Sixteen observations cover order, tree association, several initial states,
nonlinear state updates, heterogeneous element/state types, and list and Bool
accumulators. Eight oracle controls accept the supplied reference and reject
wrong order, ignored subtrees, duplication and reset-state implementations.
Those controls are outside synthesis inventories. The Lean oracle proofs
explicitly unfold `observations` before `decide`; every recorded declaration
must have an empty axiom inventory.

`prepare.py` regenerates the specification, provider/control sources, exact
command files, replay templates and file manifest. `run_acceptance.py` checks
that manifest before running anything. Put outputs outside this directory.
Use a fresh output directory for every run. Do not change sources or rebuild
the selected executables while a run is active.

From the Leant root, with the project and selected executables already built:

```powershell
python -B test-recursive/tree-accumulator/prepare.py
python -B test-recursive/tree-accumulator/run_acceptance.py --language haskell --output dist-newstyle/tree-haskell
python -B test-recursive/tree-accumulator/run_acceptance.py --language lean --leant <built-leant.exe> --kernel <actual-lean-4.32.0-binary> --output dist-newstyle/tree-lean
```

The default Haskell route uses the prebuilt vendored Djex library in Leant's
Cabal project. `--djex-root <checkout>` selects a separate canonical checkout;
`--haskell-project <project>` can select its build project explicitly. Library
paths are read from that project's Cabal package database and hashed. They do
not depend on a particular user's directory or a hard-coded GHC build path.
For Lean, use the actual kernel binary, rather than an Elan dispatch proxy.
Set `LEANT_BACKEND` to the intended backend when multiple builds are available;
the enclosing milestone runner additionally records the resolved runtime.

`--controls-only` validates the independent controls without searching.
`--haskell-engine djinn|exference` and `--lean-engine djinn|exference|both`
select individual engines. Each Lean engine selection includes a positive
query and a live False control. The Haskell probe retains its original raw
candidate window, then independently compiles and executes every retained
candidate at the full original signature, including contradictory checks.

The specification freezes the original limits: 1,024 raw Haskell candidates,
100,000 choices/steps, and an Exference queue of 1,024; Lean uses window/verify
1,024, 100,000 choices/steps, provider cap 80 and a 90-second command deadline.
Outer process guards are separate. A timeout, exhausted pool or unsupported
candidate remains a failed cell, never an impossibility claim. The supplied
witness demonstrates that a state-transformer fold carrier works; a passing
synthesized implementation need not use that exact construction.
''',encoding='utf-8')
print('Installed fixture; regenerate its manifest before execution.')
