from pathlib import Path
import json, os, sys
ROOT=Path('C:/Leant')
sys.path.insert(0,str(ROOT/'lib/Djex/test-church'))
import behavior_runtime as runtime
OUT=ROOT/'dist-newstyle/layered-provider-timing-v4'
OUT.mkdir(exist_ok=False)
objects=ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/t/leant-synth-tests/build/leant-synth-tests/leant-synth-tests-tmp'
source=ROOT/'dist-newstyle/LayeredProviderTiming.hs'
inputs=[source,Path(__file__),*objects.rglob('*.hi'),*objects.rglob('*.o')]
def snapshot(): return {str(p):runtime.sha256(p) for p in inputs}
report={'status':'running','purpose':'diagnostic linked against existing unit engine objects; no production source mutation','before':snapshot()}
processes=runtime.Processes(OUT,120)
env=dict(os.environ,leant_datadir=str(ROOT),djex_datadir=str(ROOT/'lib/Djex'))
def run(label,args):
 checked=processes.run(label,args,cwd=ROOT,env=env)
 if checked.returncode: raise RuntimeError(label+' failed; inspect captured compiler/runtime output')
try:
 run('compile',['cabal','exec','--','ghc','-this-unit-id','leant-0.1.0-inplace-leant-synth-tests','-O','-threaded','-c',str(source),'-i'+str(objects),'-ohi',str(OUT/'Main.hi'),'-o',str(OUT/'Main.o')])
 linkObjects=sorted((objects/'Leant').rglob('*.o'))
 run('link',['cabal','exec','--','ghc','-this-unit-id','leant-0.1.0-inplace-leant-synth-tests','-threaded','-rtsopts',*[flag for package in ['djex','async','bytestring','containers','deepseq','directory','filepath','process','stm','text'] for flag in ['-package',package]],str(OUT/'Main.o'),*map(str,linkObjects),'-o',str(OUT/'layered-timing.exe')])
 for mode in ['stages','djinn','exference','both']:
  run(mode,[str(OUT/'layered-timing.exe'),mode,'+RTS','-T','-s','-RTS'])
 report['status']='completed_diagnostic'
finally:
 report['after']=snapshot();report['unchanged']=report['before']==report['after'];report['processes']=processes.rows
 runtime.write_json(OUT/'results.json',report)
