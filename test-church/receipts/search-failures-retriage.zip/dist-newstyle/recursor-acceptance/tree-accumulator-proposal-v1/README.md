# One missing supplied-fold program: left-to-right tree accumulation

Status: source preparation only. No Haskell or Lean compiler, synthesis engine,
oracle/control execution, or kernel replay has been run for this proposal.
Every file is under an ignored proposal directory. This does not alter either
engine, current fixtures, search limits, or accepted receipts.

The existing supplied family already describes treeMap and treeFlatten
(`C:/Leant/test-recursive/run_recursors.py`, supplied_cases). The new operation
threads a caller-supplied state through all leaves from left to right. Its
result is arbitrary, rather than restricted to a rebuilt tree or a sequence.
It combines a tree fold with an accumulator and tests the function-valued fold
carrier `s -> s`. The current Haskell RecursorSpec has map, append and
generalized length; it does not contain this tree accumulator.

The original P2 requirement remains checked recursive-data programs through
supplied folds/recursors or decreasing calls, with source graphs, actual
Haskell behavior and independent termination-checked Lean replay. This case
uses a supplied fold. It does not claim synthesis of recursive calls or
completion of all P2 tree/recursor coverage.

## Complete signatures and exact inventory

Haskell target:

```haskell
forall a s. (s -> a -> s) -> s -> Tree a -> s
```

Lean target, retaining both original Type-0 binders:

```lean
{α σ : Type} → (σ → α → σ) → σ → TreeAccumulatorFixture.Tree α → σ
```

The only ordinary value provider is the complete generic fold:

```haskell
foldTree :: forall a r. (a -> r) -> (r -> r -> r) -> Tree a -> r
```

```lean
TreeAccumulatorFixture.foldTree :
  {α ρ : Type} → (α → ρ) → (ρ → ρ → ρ) →
  TreeAccumulatorFixture.Tree α → ρ
```

The only datatype is `Tree a = Leaf a | Branch (Tree a) (Tree a)`.
`TreeAccumulatorProviders.hs` exports only that datatype and foldTree.
`TreeAccumulatorProviders.lean` contains only the corresponding declaration
and generic fold. Both recursive calls consume proper constructor subtrees.
The Lean definition uses the same structural recursion form as the existing
supplied fold fixture. Lean must check its termination independently before
search. There are no `partial`, `unsafe`, axiom, or synthesized recursive
definitions. `genSizeOf` is disabled, and this case needs no tree equality
instance: only the accumulator results are compared.

The synthesis inventory must contain no implementations of traversal,
flattening, append, arithmetic, oracle observations or the reference. For
Haskell use a minimal public facade environment containing exactly the Tree
declaration and foldTree value signature, as RecursorSpec already does for
List/foldList. Never load TreeAccumulatorControls as a source provider module.
For Lean each fresh command loads only the provider prelude; its complete
finite predicate is inline. Discovery is restricted and checked against the
one fold and its two constructors. Required fold discovery and actual fold
use must both be established. Do not expand this allowlist to accept an
unexpected helper or generated size provider.

## Witness and discriminating observations

The following is a reference/control witness, not a synthesized result:

```haskell
\step seed input ->
  foldTree (\value state -> step state value)
    (\left right state -> right (left state)) input seed
```

```lean
fun step seed input =>
  TreeAccumulatorFixture.foldTree
    (fun value state => step state value)
    (fun left right state => right (left state)) input seed
```

The provider's result parameter is instantiated to the complete state
transformer type. The branch applies the left transformer first and passes
its exact result to the right. Tree topology must not change the linear
left-to-right result.

`case.json` retains sixteen individually named observations in both host
languages and the exact full predicate for each. They cover:

- A singleton, a pair, both three-leaf associations, balanced/asymmetric
  four-leaf trees, and a five-leaf chain.
- Decimal accumulation with several caller seeds (including 7 and 37), so
  leaf order and initial-state preservation affect the result.
- Nonlinear state updates `state * state + value`. Starting at 2 on leaves
  1,2,3 gives 732; starting at 3 gives 10407. Expected values are explicit
  literals, not obtained by calling the reference or supplied fold.
- Boolean elements with numeric state, numeric elements with a sequence
  accumulator containing a sentinel prefix, and Boolean state with numeric
  elements. The full polymorphic candidate is used at these independent
  instantiations. Haskell numeric observations use actual Prelude.Int; Lean
  uses Nat, with identical finite nonnegative arithmetic outcomes.

The datatype is nonempty; no fake empty-tree behavior is asserted.

`TreeAccumulatorControls.hs` and `.lean` contain one positive witness and
seven fully polymorphic wrong implementations: ignored tree, reversed order,
left-only, right-only, duplicated left subtree, reset at branches, and reset
at leaves. Reset controls capture the supplied seed and invent no inhabitant
of the state type. In particular, resetting at branches behaves correctly on
a single branch but fails when a right subtree discards the completed left
state. This is a control for composition, not merely a type mismatch.
Lean has eight independent `by decide` acceptance/rejection theorems and
seventeen requested axiom inventories (provider plus each control and proof).
Their success/emptiness is required, not yet observed.

## Bounded acceptance entrance

Keep the existing Haskell RecursorSpec limits exactly: Djinn raw cutoff 1024,
alternatives and Interleave enabled, choice budget 100000; Exference at most
1024 raw candidates, 100000 steps, queue 1024, allow-unused and constructor
patterns enabled. The existing independent Haskell replay guard is 60 seconds.
The new standalone probe and its small helper build each have an explicit
180-second outer process guard. That supervisory bound is distinct from the
unchanged engine fuel and from the existing 60-second independent replay.
Add one new operation per engine through the same facade producer/typed graph
checks; do not silently change these to the larger unrelated Church bounds.
Its declarations must map all source variables injectively. The tree fold's
result parameter and the target state parameter must not be identified during
environment translation.

The six prepared Lean command files contain one positive and one actually
inhabited `where False` control for each of Djinn, Exference and Both. Each
file needs its own fresh owned process. They retain the existing supplied
family settings: shown 1; raw window and verification cap 1024; steps and
choices 100000; interleaving; provider cap 80; command deadline 90 seconds;
library/classical off. The separate fresh-process guard remains 180 seconds.
Queue configuration remains the current runner/engine default, not a new
override. Both receives its existing combined budgets; do not multiply them.
`False` must reject at least one actually checked candidate, with no accepted
term or invented successful rejection after an unrelated failure.

Before live search, root should independently compile the exact Haskell
provider/control files and run CheckControls, and check the complete standalone
Lean control file with the existing Lean 4.32.0 kernel. A provider termination
failure, wrong-control failure, or malformed predicate is a preparation
failure. Preserve it distinctly from a bounded synthesis miss.

After live search, independently replay the exact displayed result using the
prepared templates. Replace only `__EXACT_SYNTHESIZED_TERM__`; keep the full
original signature and predicate, without alpha rewriting, specialization or
hidden helper application. Haskell replay imports the provider and observation
module only after synthesis. Reject candidate AST globals outside the original
fold/constructor inventory before introducing the observation module. Record
the original typed graph, exact erasure/renderer relation, full root type and
actual provider use. Graph annotations may retain their documented source-owned
openings; do not fabricate closure or weaken erasure checks for this fixture.

Lean replay must check the exact candidate, provider termination, original
sixteen-conjunct predicate, and empty axiom inventories of provider, candidate
and theorem. Source-level pattern matching may elaborate to intrinsic Tree
eliminators; such uses require their original constructor/case graph authority,
not a newly allowed callable oracle or fold implementation. Do not accept a
mere textual occurrence of foldTree as the full provider-authority check.

Record actual process/command/input/source/executable/kernel hashes, observed
raw and verification counts, each failure stage and actual output. Preserve
false, compiler/type error, inconclusive, command timeout and outer timeout as
distinct statuses. A failed engine cell remains failed at these bounds; this
proposal adds no refill, extended timeout, or automatically larger rerun.

## Prepared files and integration size

`prepare.py` only writes source and hashes; it invokes no subprocess or test.
`manifest.json` pins each prepared artifact and `case.json` pins the inspected
existing runner/fixture/doc sources. The proposal supplies source definitions,
two-language controls, exact replay templates and six Lean input files.

`run_acceptance.py` is a root-owned, serial driver based on the existing
run_recursors process, settings, transcript and axiom validation helpers. It
has not been executed. It first checks the actual eight oracle controls in
each selected language. For Haskell it compiles TreeAccumulatorProbe.hs against
the already-built canonical public facade, observes the original bounded
candidate cohort and checks each exact source graph/root/erasure/global
inventory. A separate GHC process compiles that cohort under the full original
type and executes the predicate plus a contradictory, candidate-evaluating
False control for each candidate. These Haskell False observations are the
existing RecursorSpec-style independent checker controls, not a separate
named-where CLI run. The receipt keeps that distinction explicit. For Lean it
runs one fresh process per prepared command, including each real `where False`,
and independently replays each exact accepted output with its own retained
graph/renderer observation and direct implementation-constant inventory.

The driver pins both source trees, existing parser/process helpers, proposal
files, built Haskell library inputs, actual executables, generated GHC/Lean
inputs and process captures. Source or executable changes invalidate the run.
Owned process jobs/groups prevent unrelated-process cleanup. The driver does
not invoke Cabal builds, silently relax a failed cell, or enlarge its bounds;
its only GHC compilation is the small public-facade probe and independent
control/candidate replays, after root has completed the strict project build.

Root invocation after the strict builds (replace the two exact binary paths):

```powershell
python C:/Leant/dist-newstyle/recursor-acceptance/tree-accumulator-proposal-v1/run_acceptance.py --output C:/Leant/dist-newstyle/recursor-acceptance/tree-accumulator-live-v1 --leant C:/Leant/dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/x/leant/build/leant/leant.exe --kernel C:/Users/vresh/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean.exe
```

`--controls-only` runs only the two independent preparation gates.
`--language haskell` or `--language lean` selects one language; repeated
`--haskell-engine`/`--lean-engine` options choose explicit subsets. Defaults
are the two Haskell engines and all three Lean modes. No acceptance counts are
assumed before actual results. A controls-only or subset receipt is labeled as
such. Output must be a fresh directory outside this frozen proposal.

The smallest tracked follow-up is one public Haskell integration case using
the existing typed facade entrance and one additional Lean supplied-family
case/strict inventory entry. Root owns Cabal registration if a separate
integration module is preferable to extending RecursorSpec's list-specific
declaration builder. No production API change is proposed. New result receipts
must be kept distinct from earlier native append/length and the unexecuted
treeMap/treeFlatten specification.
