import Lean
set_option autoImplicit false
namespace TreeAccumulatorFixture
set_option genSizeOf false in inductive Tree (α : Type) where | leaf : α → Tree α | branch : Tree α → Tree α → Tree α
end TreeAccumulatorFixture
def TreeAccumulatorFixture.foldTree {α ρ : Type} (leaf : α → ρ) (branch : ρ → ρ → ρ) : TreeAccumulatorFixture.Tree α → ρ | .leaf x => leaf x | .branch l r => branch (TreeAccumulatorFixture.foldTree leaf branch l) (TreeAccumulatorFixture.foldTree leaf branch r)

namespace OrdinaryUser
def elim (x : Nat) : Nat := x
end OrdinaryUser
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  for name in [``TreeAccumulatorFixture.Tree.leaf.elim, ``TreeAccumulatorFixture.Tree.branch.elim] do
    unless env.contains name && Lean.isAuxRecursor env name do
      throwError "expected generated auxiliary recursor: {name}"
  for name in [``TreeAccumulatorFixture.foldTree, ``TreeAccumulatorFixture.Tree.leaf, ``TreeAccumulatorFixture.Tree.branch, ``OrdinaryUser.elim] do
    unless env.contains name && !Lean.isAuxRecursor env name do
      throwError "ordinary provider unexpectedly marked auxiliary: {name}"
  logInfo "PASS: two generated auxiliaries and four retained ordinary providers"
