"""Archive the completed failure evidence used by the September 8 re-triage."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root=Path('C:/Leant')
out=root/'test-church/receipts'
stem='search-failures-retriage'
selected={}
def include(path):
    if path.is_file() and path.suffix.lower() in {'.json','.txt','.hs','.lean','.py','.md','.log','.in'} and '__pycache__' not in path.parts:
        selected[path.relative_to(root).as_posix()]=path

directories=[
 'polymorphic-introduction-integration-v3',
 'layered-provider-timing-v4','layered-provider-timing-v5',
 'tree-accumulator-acceptance-v1','tree-accumulator-acceptance-v2',
 'tree-accumulator-portable-haskell-v1','tree-accumulator-portable-haskell-v2',
 'tree-accumulator-portable-haskell-v3','tree-accumulator-portable-lean-controls-v1',
 'auxiliary-provider-metadata-v1',
 'recursor-acceptance/tree-accumulator-proposal-v1',
 'recursor-acceptance/tree-accumulator-proposal-v2']
for directory in directories:
    for path in (root/'dist-newstyle'/directory).rglob('*'):include(path)
for name in ['LayeredProviderTiming.hs','validate-polymorphic-introduction-integration-v3.py',
             'run-layered-provider-timing-v4.py','run-layered-provider-timing-v5.py',
             'run-prepared-tree-accumulator.py','run-prepared-tree-accumulator-v2.py',
             'install-tree-accumulator-fixture.py','pending-focus-reverted-integration-build-v1.log']:
    path=root/'dist-newstyle'/name
    assert path.is_file(),path
    include(path)
for path in (root/'test-recursive/tree-accumulator').rglob('*'):include(path)
include(Path(__file__))

def digest(data):return hashlib.sha256(data).hexdigest()
artifacts=[]
archive=out/(stem+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in sorted(selected.items()):
        data=path.read_bytes()
        z.writestr(name,data)
        artifacts.append(dict(path=name,bytes=len(data),sha256=digest(data)))
    for rev in ['b567d7815830e510d1735cfdffb3af85f503f0bd','50340b0793822c2c5ef3a42dd250c04e674e8274']:
        data=subprocess.run(['git','show','--format=fuller',rev],cwd='C:/Djex',capture_output=True,check=True).stdout
        name='canonical-git/'+rev+'.patch'
        z.writestr(name,data)
        artifacts.append(dict(path=name,bytes=len(data),sha256=digest(data)))

def read(name):return json.loads((root/'dist-newstyle'/name/'results.json').read_text(encoding='utf-8'))
unit=read('polymorphic-introduction-integration-v3')
assert unit['status']=='incomplete' and unit['unchanged']
assert unit['stopped_after_failed_required_gate']=='unit'
for name in ['tree-accumulator-acceptance-v1','tree-accumulator-acceptance-v2']:
    assert read(name)['unchanged']
    assert not read(name+'/matrix')['accepted_positive_cells']
portable=read('tree-accumulator-portable-haskell-v3')
assert all(portable[k] for k in ['source_integrity','executable_integrity','input_integrity','library_integrity','process_capture_integrity'])
assert [r['producer']['observed_count'] for r in portable['results']]==[95,1024]
assert all(r['ghc_verdict']['accepted']==[] for r in portable['results'])
assert read('tree-accumulator-portable-lean-controls-v1')['status']=='passed'
assert read('auxiliary-provider-metadata-v1')['status']=='passed'
experiment=read('layered-provider-timing-v5')
assert any(p['label']=='layered' and p['status']=='completed' and p['exit_code']==1 for p in experiment['processes'])
assert subprocess.run(['git','diff','--quiet','3b075d6dea015f0986b463627a0547bc76f29895','50340b0793822c2c5ef3a42dd250c04e674e8274'],cwd='C:/Djex').returncode==0

receipt=dict(
 status='completed_retriage_not_integration_acceptance',
 date='2026-09-08',
 scope='Existing complete unit failure, engine timing, rejected scheduler experiment, tree acceptance failures, portable fixture validation and auxiliary-provider metadata diagnosis',
 revisions=dict(canonical_source='50340b0793822c2c5ef3a42dd250c04e674e8274',canonical_net_identical_to='3b075d6dea015f0986b463627a0547bc76f29895',native_working_dependency='63a23f58d2e0f6fd1ffcd0532412f049dd29e834',native_committed_dependency='4a4ed0fc23f76d7b82b06496e03adfadbf374f84',native_host='16fd7051ecd671985cbd93650feaa09ea1401465'),
 findings=dict(native_unit=dict(passed=700,total=701,suite_seconds=688.55,failure='named binary: staged combined search exceeded 30s',dependency_promotion=False),
  layered_diagnostic=dict(scope='one named-binary fixture linked against existing native unit engine objects',exference_wall_seconds=12.8450281,exference_allocated_bytes=12547458920,allocation_is_cumulative_not_residency=True,causal_performance_claim=False),
  rejected_experiment=dict(revision='b567d7815830e510d1735cfdffb3af85f503f0bd',revert='50340b0793822c2c5ef3a42dd250c04e674e8274',accepted=False,terminal_outcome='focused layered-provider test failed unchanged',raw_parent_status='running',status_resolution='The diagnostic wrapper did not finalize its top-level status after its exception. Its completed layered process record, exit 1 and captured test failure establish the terminal failed outcome.'),
  tree_haskell=dict(djinn_candidates=95,exference_candidates=1024,positive_matches=0,independent_full_type_ghc=True,actual_false_observations=1119,original_limits_preserved=True,portable_reproduction=True),
  tree_lean=dict(oracle_controls=8,empty_axiom_inventories=17,accepted_positive_cells=0,positive_failure='generated constructor eliminators outside original allowed provider inventory',accepted_false_engines=['exference','both'],djinn_false_inventory_gate='failed'),
  portable_fixture=dict(haskell_full_run='completed with bounded synthesis misses',lean_controls_only='passed; not a new live synthesis run',initial_failures=['Cabal exec passed compiler flags to ghc-pkg','relative output paths resolved under the child working directory'],production_search_change=False),
  auxiliary_metadata=dict(status='passed',generated_auxiliaries=2,ordinary_providers=4,ordinary_user_elim_retained=True,production_discovery_filter_changed=False)),
 no_new_accepted_church_cells=True,
 expected_open_goal='Original priorities 2-4 and broader frontend/contextual scope remain open; all 13 extended plus 19 defaults across five language/engine combinations remain required.',
 archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=digest(archive.read_bytes()),artifact_count=len(artifacts),uncompressed_bytes=sum(a['bytes'] for a in artifacts),excludes='Compiled executables, object/interface files, unrelated diagnostic source and external runtime binaries. Runtime/source hashes remain in original receipts.'),
 artifacts=artifacts)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for a in artifacts:
        data=z.read(a['path']);assert len(data)==a['bytes'] and digest(data)==a['sha256']
(out/(stem+'.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt['archive']))
