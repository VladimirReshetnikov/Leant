"""Capture the dictionary-selection graph baseline before any production repair."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('C:/Leant')
sys.path.insert(0, str(ROOT / 'lib/Djex/test-church'))
import behavior_runtime as rt
OUT = rt.prepare_output_directory(ROOT / 'dist-newstyle/context-dictionary-selection-unit-v1')
source_paths = [Path(__file__), ROOT / 'leant.cabal', ROOT / 'test-unit/Spec.hs',
    ROOT / 'test-unit/ContextDictionarySelectionSpec.hs', ROOT / 'src/Leant/Synth/ContextSource.hs',
    ROOT / 'src/Leant/Synth/ContextUniverse.hs', ROOT / 'src/Leant/Synth/ContextRender.hs']
sources = {str(p): rt.sha256(p) for p in source_paths}
for p in source_paths:
    target = OUT / 'source' / p.relative_to(ROOT)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(p.read_bytes())
report = dict(status='running', scope='Three sealed graph tests on the published production source, before dictionary evidence transport changes.',
    source_hashes=sources, executable_hashes={}, gates=[])
runner = rt.Processes(OUT, 2400)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', leant_datadir=str(ROOT), djex_datadir=str(ROOT / 'lib/Djex'))
def save():
    report['processes'] = runner.rows
    rt.write_json(OUT / 'results.json', report)
try:
    save()
    result = runner.run('strict-build', ['cabal', 'build', 'leant:test:leant-synth-tests', '--ghc-options=-Werror', '-j1'], cwd=ROOT, env=env)
    report['gates'].append(dict(label='strict-build', exit_code=result.returncode)); save()
    assert result.returncode == 0
    unit = Path(subprocess.check_output(['cabal','list-bin','leant:test:leant-synth-tests'],cwd=ROOT).decode().strip())
    report['executable_hashes'][str(unit)] = rt.sha256(unit)
    pattern = '/Polymorphic selection through dictionary application/'
    result = runner.run('focused-tests', [str(unit), '--num-threads', '1', '-p', pattern], cwd=ROOT, env=env)
    report['gates'].append(dict(label='focused-tests', exit_code=result.returncode)); save()
    report['status'] = 'passed' if result.returncode == 0 else 'failed'
except BaseException as error:
    report.update(status='failed', failure=repr(error))
finally:
    report['sources_unchanged'] = all(rt.sha256(Path(p)) == h for p,h in sources.items())
    report['runtimes_unchanged'] = all(rt.sha256(Path(p)) == h for p,h in report['executable_hashes'].items())
    if not report['sources_unchanged'] or not report['runtimes_unchanged']:
        report['status'] = 'failed'
    save()
print(report['status'], report.get('failure',''), flush=True)
sys.exit(0 if report['status'] == 'passed' else 1)
