{-# LANGUAGE RankNTypes, ImpredicativeTypes, TypeApplications, TypeAbstractions, ScopedTypeVariables, KindSignatures, NoPolyKinds, FlexibleContexts #-}
module Main where
vacuousK :: forall (f :: * -> *) a. a -> a
vacuousK = ((\ @f @a -> \x -> x) :: forall (f :: * -> *) a . a -> a)
main :: IO ()
main = print (vacuousK @Int @Int 23)
