from pathlib import Path
import json, os, subprocess, sys
ROOT=Path('C:/Djex-validation/public-kinded-source')
assert Path.cwd()==ROOT
baseline=Path('C:/Leant/dist-newstyle/extrema-baseline-recovery-both-v1/results.json')
d=json.loads(baseline.read_text())
assert d['status'] in ['passed','failed'] and d['sources_unchanged'] and d['executables_unchanged']
sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as runtime
OUT=runtime.prepare_output_directory(ROOT/'dist-newstyle/source-scope-rendering-v1')
source_paths=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=ROOT).decode().split('\0')
source_paths=sorted({p for p in source_paths if p and (ROOT/p).is_file() and Path(p).suffix in ['.hs','.cabal']})
report=dict(status='running',scope='Original-signature renderer fixtures, not live synthesis acceptance.',source_sha256={p:runtime.sha256(ROOT/p) for p in source_paths},gates=[])
for p in source_paths:
 target=OUT/'source'/p; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes((ROOT/p).read_bytes())
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
runner=runtime.Processes(OUT,1200)
env=dict(os.environ,djex_datadir=str(ROOT),PYTHONDONTWRITEBYTECODE='1')
def save():
 report['processes']=runner.rows
 runtime.write_json(OUT/'results.json',report)
def run(label,command,expected=0):
 result=runner.run(label,command,cwd=ROOT,env=env)
 passed=result.returncode==expected if expected is not None else result.returncode!=0
 report['gates'].append(dict(name=label,exit_code=result.returncode,passed=passed))
 save()
 assert passed,label+' failed: '+result.stderr[-2000:]
 return result
try:
 save()
 run('strict-library-build',['cabal','build','djex:lib:djex','--ghc-options=-Werror','-j1'])
 common=['cabal','exec','--','ghc','-i','-package','djex','-package','haskell-src-exts','-Wall','-Werror']
 utils=ROOT/'exference/src-frontend/Language/Haskell/Exference/HaskellSrcUtils.hs'
 driver=ROOT/'test-church/source_scope_rendering.hs'
 for label,scope in [('baseline',Path('C:/Djex/src/Language/Haskell/Djex/HaskellSrc/Scope.hs')),('repaired',ROOT/'src/Language/Haskell/Djex/HaskellSrc/Scope.hs')]:
  stage=OUT/label; stage.mkdir()
  (stage/'Scope.hs').write_bytes(scope.read_bytes())
  exe=stage/'render.exe'
  run(label+'-driver-build',common+[str(driver),str(scope),str(utils),'-odir',str(stage),'-hidir',str(stage),'-o',str(exe)])
  report.setdefault('runtime_sha256',{})[str(exe)]=runtime.sha256(exe)
  result=run(label+'-render',[str(exe),str(stage)],None if label=='baseline' else 0)
  if label=='baseline':
   assert 'kinded source binders' in result.stderr
   continue
  run('positive-ghc-build',['ghc','-fforce-recomp',str(stage/'Positive.hs'),'-odir',str(stage),'-hidir',str(stage),'-o',str(stage/'positive.exe')])
  result=run('positive-execution',[str(stage/'positive.exe')])
  assert result.stdout.strip()=='(Just 17,23,31,Just 41,Just [43],47,Just True,[True])',result.stdout
  result=run('wrong-kind-ghc-rejection',['ghc','-fno-code','-fforce-recomp',str(stage/'WrongKind.hs'),'-odir',str(stage),'-hidir',str(stage)],None)
  assert 'kind' in result.stderr.lower() and 'Int' in result.stderr
 report['status']='passed'
except BaseException as failure:
 report['failure']=repr(failure); report['status']='failed'
finally:
 report['sources_unchanged']=all(runtime.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
 report['runtimes_unchanged']=all(runtime.sha256(Path(p))==h for p,h in report.get('runtime_sha256',{}).items())
 report['controller_unchanged']=(OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
 if not all(report[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged']): report['status']='failed'
 save()
print(json.dumps({k:report.get(k) for k in ['status','gates','failure']},indent=2),flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
