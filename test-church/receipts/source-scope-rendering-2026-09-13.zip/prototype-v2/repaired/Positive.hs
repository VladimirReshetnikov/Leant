{-# LANGUAGE RankNTypes, ImpredicativeTypes, TypeApplications, TypeAbstractions, ScopedTypeVariables, KindSignatures, NoPolyKinds, FlexibleContexts #-}
module Main where
identityK :: forall (f :: * -> *) a. f a -> f a
identityK = ((\ @f @a -> \x -> x) :: forall (f :: * -> *) a . f a -> f a)
vacuousK :: forall (f :: * -> *) a. a -> a
vacuousK = ((\ @f @a -> \x -> x) :: forall (f :: * -> *) a . a -> a)
nestedK :: forall a. (forall (f :: * -> *) b. f b -> f b) -> a -> a
nestedK = ((\ @a -> \_ x -> x) :: forall a . (forall (f :: * -> *) b . f b -> f b) -> a -> a)
implicitK :: forall a. a -> (forall (f :: * -> *) b. f b -> f b)
implicitK = ((\ @a -> \_ -> (\x -> x :: forall (f :: * -> *) b. f b -> f b)) :: forall a. a -> (forall (f :: * -> *) b . f b -> f b))
higherK :: forall (f :: * -> *) (g :: * -> *) a. f (g a) -> f (g a)
higherK = ((\ @f @g @a -> \x -> x) :: forall (f :: * -> *) (g :: * -> *) a . f (g a) -> f (g a))
layeredK :: forall (f :: * -> *). forall a. a -> a
layeredK = ((\ @f @a -> \x -> x) :: forall (f :: * -> *) . forall a . a -> a)
constrainedK :: forall a. Eq a => a -> (forall (f :: * -> *) b. f b -> f b)
constrainedK = ((\ @a -> \_ -> (\x -> x :: forall (f :: * -> *) b. f b -> f b)) :: forall a.   Eq a => a -> (forall (f :: * -> *) b . f b -> f b))
shadowedK :: forall (f :: * -> *) a. f a -> (forall (f :: * -> *) a. f a -> f a)
shadowedK = ((\ @f @a -> \_ -> (\x -> x :: forall (f :: * -> *) a. f a -> f a)) :: forall (f :: * -> *) a .   f a -> (forall (f :: * -> *) a . f a -> f a))
main :: IO ()
main = print (identityK @Maybe @Int (Just 17), vacuousK @Maybe @Int 23, nestedK @Int (\x -> x) 31, implicitK @Bool True @Maybe @Int (Just 41), higherK @Maybe @[] @Int (Just [43]), layeredK @Maybe @Int 47, constrainedK @Int 53 @Maybe @Bool (Just True), shadowedK @Maybe @Int (Just 59) @[] @Bool [True])
