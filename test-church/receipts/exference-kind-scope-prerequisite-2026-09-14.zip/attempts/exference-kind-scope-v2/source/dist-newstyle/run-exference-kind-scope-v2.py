"""Check lexical kind ownership, substitution and quantified compatibility for Exference."""
from pathlib import Path
import os
import subprocess
import sys

ROOT=Path('C:/Djex')
sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as rt
OUT=rt.prepare_output_directory(ROOT/'dist-newstyle/exference-kind-scope-v2')
paths=[Path(__file__),ROOT/'djex.cabal',
    ROOT/'exference/src-core/Language/Haskell/Exference/Core/Internal/Polytype.hs',
    ROOT/'exference/test-engine/EngineSpec.hs',ROOT/'exference/test-engine/KindScopeSpec.hs',ROOT/'exference/src-core/Language/Haskell/Exference/Core/Internal/KindScope.hs']
source_hashes={str(p):rt.sha256(p) for p in paths}
for p in paths:
    destination=OUT/'source'/p.relative_to(ROOT)
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes(p.read_bytes())
report=dict(status='running',scope=__doc__,source_hashes=source_hashes,executable_hashes={})
runner=rt.Processes(OUT,2400)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',djex_datadir=str(ROOT))
def save():
    report['processes']=runner.rows
    rt.write_json(OUT/'results.json',report)
try:
    save()
    build=runner.run('strict-build',['cabal','build','djex:test:exference-engine-tests','--ghc-options=-Werror','-j1'],cwd=ROOT,env=env)
    assert build.returncode==0
    exe=Path(subprocess.check_output(['cabal','list-bin','djex:test:exference-engine-tests'],cwd=ROOT).decode().strip())
    report['executable_hashes'][str(exe)]=rt.sha256(exe)
    save()
    tests=runner.run('private-engine',[str(exe),'--num-threads','1'],cwd=ROOT,env=env)
    assert tests.returncode==0 and 'All 114 tests passed' in tests.stdout
    report['status']='passed'
except BaseException as error:
    report.update(status='failed',failure=repr(error))
finally:
    report['sources_unchanged']=all(rt.sha256(Path(p))==h for p,h in source_hashes.items())
    report['runtimes_unchanged']=all(rt.sha256(Path(p))==h for p,h in report['executable_hashes'].items())
    if not report['sources_unchanged'] or not report['runtimes_unchanged']:report['status']='failed'
    save()
print(report['status'],report.get('failure',''),flush=True)
sys.exit(0 if report['status']=='passed' else 1)
