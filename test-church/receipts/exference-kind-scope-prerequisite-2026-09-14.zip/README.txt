Exference lexical-kind checker prerequisite, 2026-09-14.
Final gate: attempts/exference-kind-scope-release-v2/results.json.
Strict build, 120 private engine tests and 515 ordinary tests.
Includes captured changed source, controllers, transcripts and runtime hashes.
Executable binaries are identified by hashes, not embedded.
Earlier passing and failed attempts are retained as separate snapshots.
This is not acceptance of public kinded synthesis or a native Lean release.
