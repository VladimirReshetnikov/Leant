from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path("C:/Djex")
OTHER = Path("C:/Leant")
FINAL = ROOT / "dist-newstyle/exference-kind-scope-release-v2/results.json"
receipt = json.loads(FINAL.read_text())
assert receipt["status"] == "passed"
assert receipt["sources_unchanged"] and receipt["runtimes_unchanged"]
for key in ("source_hashes", "executable_hashes"):
    for raw, expected in receipt[key].items():
        assert hashlib.sha256(Path(raw).read_bytes()).hexdigest() == expected, raw

histories = ["exference-kind-openings-v1"]
histories += [f"exference-kind-scope-v{n}" for n in range(1, 7)]
histories += ["exference-kind-scope-release-v1", "exference-kind-scope-release-v2"]
members = {}
for history in histories:
    directory = ROOT / "dist-newstyle" / history
    assert (directory / "results.json").is_file(), history
    for path in sorted(directory.rglob("*")):
        if path.is_file():
            members[f"attempts/{history}/{path.relative_to(directory).as_posix()}"] = path.read_bytes()
members["controllers/package-exference-kind-scope-prerequisite.py"] = Path(__file__).read_bytes()
members["README.txt"] = (
    "Exference lexical-kind checker prerequisite, 2026-09-14.\n"
    "Final gate: attempts/exference-kind-scope-release-v2/results.json.\n"
    "Strict build, 120 private engine tests and 515 ordinary tests.\n"
    "Includes captured changed source, controllers, transcripts and runtime hashes.\n"
    "Executable binaries are identified by hashes, not embedded.\n"
    "Earlier passing and failed attempts are retained as separate snapshots.\n"
    "This is not acceptance of public kinded synthesis or a native Lean release.\n"
).encode()
manifest = {
    "scope": "Internal Exference kind ownership and independent checker prerequisite",
    "final_receipt": "attempts/exference-kind-scope-release-v2/results.json",
    "members": {name: hashlib.sha256(data).hexdigest() for name, data in members.items()},
}
members["manifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
stem = "exference-kind-scope-prerequisite-2026-09-14"
archive = ROOT / "test-church/receipts" / (stem + ".zip")
index_path = archive.with_suffix(".json")
assert not archive.exists() and not index_path.exists(), "Refuse to overwrite prior evidence"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(members.items()):
        output.writestr(name, data)
with zipfile.ZipFile(archive) as stored:
    assert set(stored.namelist()) == set(members)
    for name, data in members.items():
        assert stored.read(name) == data, name
index = {
    "status": "passed",
    "scope": manifest["scope"],
    "public_kinded_synthesis_accepted": False,
    "native_integration_accepted": False,
    "counts": {"private_engine_tests": 120, "ordinary_exference_tests": 515},
    "archive": archive.name,
    "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    "archive_bytes": archive.stat().st_size,
    "member_count": len(members),
    "final_receipt": manifest["final_receipt"],
    "final_receipt_sha256": hashlib.sha256(FINAL.read_bytes()).hexdigest(),
    "member_hashes": {name: hashlib.sha256(data).hexdigest() for name, data in members.items()},
}
index_path.write_text(json.dumps(index, indent=2) + "\n", encoding="utf-8")
for path in (archive, index_path):
    destination = OTHER / "test-church/receipts" / path.name
    assert not destination.exists(), destination
    destination.write_bytes(path.read_bytes())
    assert destination.read_bytes() == path.read_bytes()
print(json.dumps({key: index[key] for key in
                 ("archive_sha256", "archive_bytes", "member_count")}), flush=True)
