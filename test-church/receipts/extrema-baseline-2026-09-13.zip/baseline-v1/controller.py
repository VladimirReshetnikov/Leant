from pathlib import Path
import json, os, subprocess, sys

DJEX = Path('C:/Djex')
LEANT = Path('C:/Leant')
NATIVE = Path('C:/Leant-validation/strict-implicit-source')
sys.path.insert(0, str(DJEX / 'test-church'))
import behavior_runtime as runtime

OUT = runtime.prepare_output_directory(LEANT / 'dist-newstyle/extrema-baseline-v1')
prior_path = NATIVE / 'dist-newstyle/strict-implicit-release-v2/results.json'
prior = json.loads(prior_path.read_text())
assert prior['status'] == 'passed'
for path, digest in prior['source_sha256'].items():
    assert runtime.sha256(NATIVE / path) == digest, path
for path, digest in prior['runtime_sha256'].items():
    assert runtime.sha256(Path(path)) == digest, path
bins = [Path(p) for p in prior['runtime_sha256']]
native = next(p for p in bins if p.name == 'leant.exe')
kernel = next(p for p in bins if p.name == 'lean.exe')
backend = next(p for p in bins if p.name == 'repl.exe')
djex = Path(subprocess.check_output(['cabal','list-bin','djex:exe:djex'], cwd=DJEX).decode().strip())
sources = {}
for name, root in [('djex',DJEX), ('leant',LEANT), ('native',NATIVE)]:
    paths = subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=root).decode().split('\0')
    for rel in sorted(set(paths)):
        if rel and (root/rel).is_file() and Path(rel).suffix in {'.hs','.cabal','.py','.lean'}:
            path = root/rel
            sources[str(path)] = runtime.sha256(path)
            dest = OUT/'source'/name/rel
            dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_bytes(path.read_bytes())
# Verify the executable-producing native source against the published native
# implementation. Ignore newline-only checkout differences; do not compare
# the dependency to Djex main, because the native pin is intentionally older.
parity = []
for rel in subprocess.check_output(['git','ls-files','-z'],cwd=LEANT).decode().split('\0'):
    if rel and Path(rel).suffix in {'.hs','.cabal'}:
        assert (NATIVE/rel).is_file(), rel
        assert (LEANT/rel).read_text(encoding='utf-8') == (NATIVE/rel).read_text(encoding='utf-8'), rel
        parity.append(rel)
native_pin = subprocess.check_output(['git','rev-parse','HEAD'],cwd=NATIVE/'lib/Djex').decode().strip()
assert native_pin == subprocess.check_output(['git','rev-parse','HEAD:lib/Djex'],cwd=LEANT).decode().strip()
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
(OUT/'djex-build.log').write_bytes((DJEX/'dist-newstyle/extrema-baseline-build-v1.log').read_bytes())
(OUT/'native-prior-receipt.json').write_bytes(prior_path.read_bytes())
report = dict(status='running', scope='Ten original supplied-default extrema cells at existing bounds; baseline, not a full release gate.',
    commits={name:subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip() for name,root in [('djex',DJEX),('leant',LEANT),('native',NATIVE)]},
    native_dependency=native_pin,native_source_parity=parity,source_sha256=sources,
    runtime_sha256={str(p):runtime.sha256(p) for p in [djex,native,kernel,backend]}, gates=[])
runner = runtime.Processes(OUT,2400)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', djex_datadir=str(DJEX),leant_datadir=str(NATIVE))
def save():
    report['processes']=runner.rows
    runtime.write_json(OUT/'results.json',report)
try:
    save()
    for label,root,cmd in [
        ('haskell',DJEX,[sys.executable,'-X','utf8','-B','test-church/behavior_partial_probe.py','--djex',str(djex),
          '--output',str(OUT/'haskell'),'--operation','maximumBy','--operation','maximumOn']),
        ('lean',LEANT,[sys.executable,'-X','utf8','-B','test-church/behavior_partial_probe.py','--leant',str(native),
          '--spec-dir',str(DJEX/'test-church'),'--lean-runtime',str(kernel),'--backend',str(backend),
          '--output',str(OUT/'lean'),'--operation','maximumBy','--operation','maximumOn'])]:
        result=runner.run(label,cmd,cwd=root,env=env)
        child=json.loads((OUT/label/'results.json').read_text())
        report['gates'].append(dict(name=label,exit_code=result.returncode,status=child['status'],
          accepted=child.get('accepted'),cells=[{k:row.get(k) for k in ['engine','operation','status','accepted','failure']} for row in child['cells']]))
        save()
except BaseException as failure:
    report['failure']=repr(failure)
finally:
    report['sources_unchanged']=all(runtime.sha256(Path(p))==h for p,h in sources.items())
    report['runtimes_unchanged']=all(runtime.sha256(Path(p))==h for p,h in report['runtime_sha256'].items())
    report['controller_unchanged']=(OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
    report['status']='completed' if len(report['gates'])==2 and all(report[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged']) else 'failed'
    save()
print(json.dumps({k:report[k] for k in ['status','gates']},indent=2),flush=True)
raise SystemExit(0 if report['status']=='completed' else 1)
