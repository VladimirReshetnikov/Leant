set_option autoImplicit false
set_option linter.unusedVariables false
namespace BehaviorPartial
universe u v
abbrev CList (A : Type u) := ∀ R : Type, (A → R → R) → R → R
abbrev CMaybe (A : Type u) := ∀ R : Type, R → (A → R) → R
abbrev CEither (A : Type u) (B : Type v) := ∀ R : Type, (A → R) → (B → R) → R
abbrev CPair (A : Type u) (B : Type v) := ∀ R : Type, (A → B → R) → R
abbrev CBool := ∀ R : Type, R → R → R
def enc {A : Type} (xs : List A) : CList A := fun _ step zero => xs.foldr step zero
def dec {A : Type} (xs : CList A) : List A := xs (List A) List.cons []
def maybe {A : Type} (m : Option A) : CMaybe A := fun _ zero some => m.elim zero some
def either {A B : Type} (e : Sum A B) : CEither A B := fun _ onLeft onRight => e.elim onLeft onRight
def bool (flag : Bool) : CBool := fun _ yes no => if flag then yes else no
def pair {A B : Type} (p : A × B) : CPair A B := fun _ k => k p.1 p.2
def decPair {A B : Type} (p : CPair A B) : A × B := p (A × B) Prod.mk
def dict {A B : Type} (xs : List (A × B)) : CList (CPair A B) := fun _ step zero => xs.foldr (fun p rest => step (fun _ k => k p.1 p.2) rest) zero
end BehaviorPartial
def BehaviorPartial.check_maximumBy (f : (∀ (church0 : Type), (church0 → ((church0 → (church0 → (∀ (church1 : Type), (church1 → (church1 → church1))))) → ((∀ (church2 : Type), ((church0 → (church2 → church2)) → (church2 → church2))) → church0))))) : Bool := (((((((f) ((Int × Int)) ((((-99),(-1)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≤ y)) x.1 y.1))) ((BehaviorPartial.enc ([] : (List (Int × Int)))))) == (((-99),(-1)) : (Int × Int))) && ((((f) ((Int × Int)) ((((-99),(-1)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≥ y)) x.1 y.1))) ((BehaviorPartial.enc ([] : (List (Int × Int)))))) == (((-99),(-1)) : (Int × Int))) && (((f) ((Int × Int)) ((((-99),(-1)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun _ _ => true) x.1 y.1))) ((BehaviorPartial.enc ([] : (List (Int × Int)))))) == (((-99),(-1)) : (Int × Int))))) && (((((f) ((Int × Int)) ((((-99),(-1)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≤ y)) x.1 y.1))) ((BehaviorPartial.enc ([((7),(20))] : (List (Int × Int)))))) == (((7),(20)) : (Int × Int))) && (((f) ((Int × Int)) ((((-99),(-1)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≥ y)) x.1 y.1))) ((BehaviorPartial.enc ([((7),(20))] : (List (Int × Int)))))) == (((7),(20)) : (Int × Int)))) && ((((f) ((Int × Int)) ((((-99),(-1)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun _ _ => true) x.1 y.1))) ((BehaviorPartial.enc ([((7),(20))] : (List (Int × Int)))))) == (((7),(20)) : (Int × Int))) && (((f) ((Int × Int)) ((((-99),(-1)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≤ y)) x.1 y.1))) ((BehaviorPartial.enc ([((2),(10)),((1),(11)),((1),(12)),((2),(13))] : (List (Int × Int)))))) == (((2),(13)) : (Int × Int)))))) && ((((((f) ((Int × Int)) ((((-99),(-1)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≥ y)) x.1 y.1))) ((BehaviorPartial.enc ([((2),(10)),((1),(11)),((1),(12)),((2),(13))] : (List (Int × Int)))))) == (((1),(12)) : (Int × Int))) && (((f) ((Int × Int)) ((((-99),(-1)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun _ _ => true) x.1 y.1))) ((BehaviorPartial.enc ([((2),(10)),((1),(11)),((1),(12)),((2),(13))] : (List (Int × Int)))))) == (((2),(13)) : (Int × Int)))) && ((((f) ((Int × Int)) ((((-99),(-1)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≤ y)) x.1 y.1))) ((BehaviorPartial.enc ([((1),(10)),((1),(11)),((1),(12))] : (List (Int × Int)))))) == (((1),(12)) : (Int × Int))) && (((f) ((Int × Int)) ((((-99),(-1)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≥ y)) x.1 y.1))) ((BehaviorPartial.enc ([((1),(10)),((1),(11)),((1),(12))] : (List (Int × Int)))))) == (((1),(12)) : (Int × Int))))) && (((((f) ((Int × Int)) ((((-99),(-1)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun _ _ => true) x.1 y.1))) ((BehaviorPartial.enc ([((1),(10)),((1),(11)),((1),(12))] : (List (Int × Int)))))) == (((1),(12)) : (Int × Int))) && (((f) ((Int × Int)) ((((-99),(-1)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≤ y)) x.1 y.1))) ((BehaviorPartial.enc ([((3),(10)),((-2),(11)),((0),(12))] : (List (Int × Int)))))) == (((3),(10)) : (Int × Int)))) && ((((f) ((Int × Int)) ((((-99),(-1)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≥ y)) x.1 y.1))) ((BehaviorPartial.enc ([((3),(10)),((-2),(11)),((0),(12))] : (List (Int × Int)))))) == (((-2),(11)) : (Int × Int))) && (((f) ((Int × Int)) ((((-99),(-1)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun _ _ => true) x.1 y.1))) ((BehaviorPartial.enc ([((3),(10)),((-2),(11)),((0),(12))] : (List (Int × Int)))))) == (((0),(12)) : (Int × Int))))))) && ((((((f) ((Int × Int)) ((((99),(-2)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≤ y)) x.1 y.1))) ((BehaviorPartial.enc ([] : (List (Int × Int)))))) == (((99),(-2)) : (Int × Int))) && ((((f) ((Int × Int)) ((((99),(-2)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≥ y)) x.1 y.1))) ((BehaviorPartial.enc ([] : (List (Int × Int)))))) == (((99),(-2)) : (Int × Int))) && (((f) ((Int × Int)) ((((99),(-2)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun _ _ => true) x.1 y.1))) ((BehaviorPartial.enc ([] : (List (Int × Int)))))) == (((99),(-2)) : (Int × Int))))) && (((((f) ((Int × Int)) ((((99),(-2)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≤ y)) x.1 y.1))) ((BehaviorPartial.enc ([((7),(20))] : (List (Int × Int)))))) == (((7),(20)) : (Int × Int))) && (((f) ((Int × Int)) ((((99),(-2)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≥ y)) x.1 y.1))) ((BehaviorPartial.enc ([((7),(20))] : (List (Int × Int)))))) == (((7),(20)) : (Int × Int)))) && ((((f) ((Int × Int)) ((((99),(-2)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun _ _ => true) x.1 y.1))) ((BehaviorPartial.enc ([((7),(20))] : (List (Int × Int)))))) == (((7),(20)) : (Int × Int))) && (((f) ((Int × Int)) ((((99),(-2)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≤ y)) x.1 y.1))) ((BehaviorPartial.enc ([((2),(10)),((1),(11)),((1),(12)),((2),(13))] : (List (Int × Int)))))) == (((2),(13)) : (Int × Int)))))) && ((((((f) ((Int × Int)) ((((99),(-2)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≥ y)) x.1 y.1))) ((BehaviorPartial.enc ([((2),(10)),((1),(11)),((1),(12)),((2),(13))] : (List (Int × Int)))))) == (((1),(12)) : (Int × Int))) && (((f) ((Int × Int)) ((((99),(-2)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun _ _ => true) x.1 y.1))) ((BehaviorPartial.enc ([((2),(10)),((1),(11)),((1),(12)),((2),(13))] : (List (Int × Int)))))) == (((2),(13)) : (Int × Int)))) && ((((f) ((Int × Int)) ((((99),(-2)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≤ y)) x.1 y.1))) ((BehaviorPartial.enc ([((1),(10)),((1),(11)),((1),(12))] : (List (Int × Int)))))) == (((1),(12)) : (Int × Int))) && (((f) ((Int × Int)) ((((99),(-2)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≥ y)) x.1 y.1))) ((BehaviorPartial.enc ([((1),(10)),((1),(11)),((1),(12))] : (List (Int × Int)))))) == (((1),(12)) : (Int × Int))))) && (((((f) ((Int × Int)) ((((99),(-2)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun _ _ => true) x.1 y.1))) ((BehaviorPartial.enc ([((1),(10)),((1),(11)),((1),(12))] : (List (Int × Int)))))) == (((1),(12)) : (Int × Int))) && (((f) ((Int × Int)) ((((99),(-2)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≤ y)) x.1 y.1))) ((BehaviorPartial.enc ([((3),(10)),((-2),(11)),((0),(12))] : (List (Int × Int)))))) == (((3),(10)) : (Int × Int)))) && ((((f) ((Int × Int)) ((((99),(-2)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun x y => decide (x ≥ y)) x.1 y.1))) ((BehaviorPartial.enc ([((3),(10)),((-2),(11)),((0),(12))] : (List (Int × Int)))))) == (((-2),(11)) : (Int × Int))) && (((f) ((Int × Int)) ((((99),(-2)) : (Int × Int))) ((fun x y => BehaviorPartial.bool ((fun _ _ => true) x.1 y.1))) ((BehaviorPartial.enc ([((3),(10)),((-2),(11)),((0),(12))] : (List (Int × Int)))))) == (((0),(12)) : (Int × Int))))))))
namespace BehaviorPartialOracle
def head {A : Type} (d : A) (xs : List A) : A := match xs with | [] => d | x :: _ => x
def last {A : Type} (d : A) (xs : List A) : A := xs.foldl (fun _ x => x) d
def indexOr {A : Type} (d : A) (n : Int) : List A → A
  | [] => d
  | x :: xs => if n < 0 then d else if n = 0 then x else indexOr d (n - 1) xs
def foldl1 {A : Type} (d : A) (step : A → A → A) (xs : List A) : A := match xs with | [] => d | x :: rest => rest.foldl step x
def foldr1 {A : Type} (d : A) (step : A → A → A) (xs : List A) : A := (xs.foldr (fun x rest => some (rest.elim x (step x))) (none : Option A)).getD d
end BehaviorPartialOracle
namespace BehaviorPartialControl
def witness_maximumBy : (∀ (church0 : Type), (church0 → ((church0 → (church0 → (∀ (church1 : Type), (church1 → (church1 → church1))))) → ((∀ (church2 : Type), ((church0 → (church2 → church2)) → (church2 → church2))) → church0)))) := fun A d le xs => BehaviorPartialOracle.foldl1 d (fun x y => le x y A y x) (BehaviorPartial.dec xs)
theorem witness_maximumBy_passes : BehaviorPartial.check_maximumBy (BehaviorPartialControl.witness_maximumBy) = true := by decide
def wrong_maximumBy_always_default : (∀ (church0 : Type), (church0 → ((church0 → (church0 → (∀ (church1 : Type), (church1 → (church1 → church1))))) → ((∀ (church2 : Type), ((church0 → (church2 → church2)) → (church2 → church2))) → church0)))) := fun _ d _ _ => d
theorem wrong_maximumBy_always_default_rejected : BehaviorPartial.check_maximumBy BehaviorPartialControl.wrong_maximumBy_always_default = false := by decide
def wrong_maximumBy_wrong_tie : (∀ (church0 : Type), (church0 → ((church0 → (church0 → (∀ (church1 : Type), (church1 → (church1 → church1))))) → ((∀ (church2 : Type), ((church0 → (church2 → church2)) → (church2 → church2))) → church0)))) := fun A d le xs => BehaviorPartialOracle.foldl1 d (fun x y => le y x A x y) (BehaviorPartial.dec xs)
theorem wrong_maximumBy_wrong_tie_rejected : BehaviorPartial.check_maximumBy BehaviorPartialControl.wrong_maximumBy_wrong_tie = false := by decide
end BehaviorPartialControl
#print axioms BehaviorPartial.CList
#print axioms BehaviorPartial.CMaybe
#print axioms BehaviorPartial.CEither
#print axioms BehaviorPartial.CPair
#print axioms BehaviorPartial.CBool
#print axioms BehaviorPartial.enc
#print axioms BehaviorPartial.dec
#print axioms BehaviorPartial.maybe
#print axioms BehaviorPartial.either
#print axioms BehaviorPartial.bool
#print axioms BehaviorPartial.pair
#print axioms BehaviorPartial.decPair
#print axioms BehaviorPartial.dict
#print axioms BehaviorPartial.check_maximumBy
#print axioms BehaviorPartialOracle.head
#print axioms BehaviorPartialOracle.last
#print axioms BehaviorPartialOracle.indexOr
#print axioms BehaviorPartialOracle.foldl1
#print axioms BehaviorPartialOracle.foldr1
#print axioms BehaviorPartialControl.witness_maximumBy
#print axioms BehaviorPartialControl.witness_maximumBy_passes
#print axioms BehaviorPartialControl.wrong_maximumBy_always_default
#print axioms BehaviorPartialControl.wrong_maximumBy_always_default_rejected
#print axioms BehaviorPartialControl.wrong_maximumBy_wrong_tie
#print axioms BehaviorPartialControl.wrong_maximumBy_wrong_tie_rejected
