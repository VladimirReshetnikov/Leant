--
-- Copyright (c) 2005 Lennart Augustsson
-- See LICENSE for licensing details.
--

-- | The historical @djinn@ command-line frontend: argument decoding, the
-- ReadP command grammar (@?@ queries, declarations, @:@ commands, @:set@
-- options), and the read-eval-print loop over an opaque 'DjinnSession'.
-- Edits and queries go through the checked session API of
-- "Language.Haskell.Djex.Djinn" and its compatibility session module; this
-- module only parses, dispatches, formats, and drives "Djinn.Internal.REPL".
module Djinn
    ( main
    , runWithSessionInitializer
    ) where
import Data.Char(isAlpha, isDigit, isSpace)
import Data.List(isPrefixOf, intercalate)
import Data.Version(showVersion)
import Text.ParserCombinators.ReadP
import Control.Exception(evaluate)
import Control.Monad (void, when)
import Data.Maybe (fromMaybe)
import System.Exit(exitWith, ExitCode(..))
import System.Environment(getArgs)
import System.IO(hPutStrLn, stderr)
import System.IO.Error(tryIOError)

import Djinn.Core
import Djinn.Internal.REPL
import Djinn.Internal.HTypes
import Djinn.Internal.HIdentifier
import Djinn.Internal.Help
import Language.Haskell.Djex.Djinn
import qualified Language.Haskell.Djex.Djinn.Internal.Request
    as CompatibilityRequest
import qualified Language.Haskell.Djex.Djinn.Internal.Session
    as CompatibilitySession
import qualified Language.Haskell.Synthesis.Diagnostic as Diagnostic
import qualified Language.Haskell.Synthesis.Name as SharedName
import Language.Haskell.Synthesis.Query
import qualified Language.Haskell.Synthesis.Search as SharedSearch
import qualified Language.Haskell.Synthesis.Selection as SharedSelection
import qualified Paths_djex

version :: String
version = "version " ++ showVersion Paths_djex.version

-- | Entry point of the historical @djinn@ executable: runs
-- 'runWithSessionInitializer' with the standard session and the command-line
-- arguments (options, then files to load; with no files, the interactive
-- REPL starts).
main :: IO ()
main = do
    args <- getArgs
    runWithSessionInitializer (return standardDjinnSession) args

-- | Run the historical frontend with a checked-session initializer.
--
-- The action is invoked both at process startup and for @:clear@.  Keeping it
-- injectable makes the complete lifecycle total: an embedding launcher can
-- propagate a structured construction failure, and a failed reset can retain
-- the last usable session instead of installing a partial value.
runWithSessionInitializer
    :: IO (Either Diagnostic.Diagnostic DjinnSession)
    -> [String]
    -> IO ()
runWithSessionInitializer initializeSession args = do
    initialState <- initializeState initializeSession
    state <- case initialState of
        Left failure -> do
            hPutStrLn stderr $ renderSessionInitializationFailure
                "Djinn startup failed:" failure
            exitWith $ ExitFailure 1
        Right state -> return state
    (files, configuredState) <- case decodeArguments state args of
        Left message -> do
            hPutStrLn stderr message
            usage
            exitWith $ ExitFailure 1
        Right result -> return result
    case files of
        [] -> repl (hsGenRepl configuredState)
        _ -> do
            finalState <- loadFiles configuredState files
            when (commandFailed finalState) $
                exitWith $ ExitFailure 1

decodeArguments :: State -> [String] -> Either String ([FilePath], State)
decodeArguments initialState = go initialState []
  where
    go state reversed [] = Right (reverse reversed, state)
    go state reversed ("--" : remaining) =
        Right (reverse reversed ++ remaining, state)
    go state reversed (argument : remaining) = case argument of
        '-' : name | not (null name) -> applyOption False name
        '+' : name | not (null name) -> applyOption True name
        _ -> go state (argument : reversed) remaining
      where
        applyOption enabled name = do
            setter <- decodeOption name
            go (setter enabled state) reversed remaining

    decodeOption name = case exact of
        [setter] -> Right setter
        _ -> case prefixes of
            [] -> Left $ "Unknown Djinn option: " ++ name
            [setter] -> Right setter
            _ -> Left $ "Ambiguous Djinn option: " ++ name ++
                " (could be " ++ intercalate ", " matchingNames ++ ")"
      where
        exact = [setter | (command, _, _, setter) <- options,
            name == command]
        prefixes = [setter | (command, _, _, setter) <- options,
            name `isPrefixOf` command]
        matchingNames = [command | (command, _, _, _) <- options,
            name `isPrefixOf` command]

loadFiles :: State -> [FilePath] -> IO State
loadFiles state [] = return state
loadFiles state (file : remaining) = do
    putStrLn $ "-- loading file " ++ file
    (quit, state') <- loadFile state file
    if quit then return state' else loadFiles state' remaining

usage :: IO ()
usage = hPutStrLn stderr "Usage: djinn [option ...] [file ...]"

hsGenRepl :: State -> REPL State
hsGenRepl state = REPL {
    repl_init = welcome state,
    repl_eval = eval,
    repl_exit = exit
    }

data State = State {
    -- Declaration edits are transactional operations on this opaque session.
    -- Its shared environment is authoritative; historical raw tables exist
    -- only as private display projections. Search uses sealed premise, class,
    -- kind, synonym, and formula indexes instead.
    djinnSession :: DjinnSession,
    -- Re-run the checked constructor for :clear rather than retaining an
    -- assumed-infallible top-level session value.
    sessionInitializer :: IO (Either Diagnostic.Diagnostic DjinnSession),
    multi :: Bool,
    sorted :: Bool,
    debug :: Bool,
    cutOff :: Int,
    -- Search-step budget; 0 keeps the search an unlimited decision procedure.
    budget :: Integer,
    commandFailed :: Bool
    }

initializeState
    :: IO (Either Diagnostic.Diagnostic DjinnSession)
    -> IO (Either Diagnostic.Diagnostic State)
initializeState initializeSession = do
    result <- initializeSession
    return $ fmap (stateFromSession initializeSession) result

stateFromSession
    :: IO (Either Diagnostic.Diagnostic DjinnSession)
    -> DjinnSession
    -> State
stateFromSession initializeSession session = State {
    djinnSession = session,
    sessionInitializer = initializeSession,
    multi = optionAlternatives defaults,
    sorted = optionSorted defaults,
    debug = False,
    cutOff = optionCutoff defaults,
    budget = fromMaybe unlimitedBudget $ optionBudget defaults,
    commandFailed = False
    }
  where
    defaults = defaultQueryOptions

welcome :: State -> IO (String, State)
welcome state = do
    putStrLn $ "Welcome to Djinn " ++ version ++ "."
    putStrLn "Type :h to get help."
    return ("Djinn> ", state)

eval :: State -> String -> IO (Bool, State)
eval s line =
    case filter (null . snd) (readP_to_S pCmd line) of
        [] -> do
            putStrLn "Cannot parse command"
            return (False, markFailed s)
        (cmd, _) : _ -> runCmd s cmd

exit :: State -> IO ()
exit _ = putStrLn "Bye."

-- The raw parser output; Djinn.Core.declare attaches inferred kinds and
-- validates before anything enters the environment.
type RawClassDef = (HSymbol, ([HSymbol], [Method]))

data Cmd = Help Bool | Quit | Add HSymbol HType | Query HSymbol [Context] HType | Del HSymbol | Load HSymbol | Noop | Env |
           Type HSymbol [HSymbol] HType | Set (State -> State) | Clear | Class RawClassDef |
           QueryInstance [Context] Context

pCmd :: ReadP Cmd
pCmd = do
    skipSpaces
    let adds (':':s) p = do schar ':'; pPrefix (takeWhile (/= ' ') s); c <- p; skipSpaces; return c
        adds _ p = do c <- p; skipSpaces; return c
    cmd <- foldr1 (+++) [adds s p | (s, p) <- commandParsers]
    skipSpaces
    return cmd

pPrefix :: String -> ReadP ()
pPrefix s = do
    skipSpaces
    cs <- look
    let w = takeWhile (\ c -> isAlpha c || c == '-') cs
    if isPrefix w s then
        void (string w)
     else
        pfail

isPrefix :: String -> String -> Bool
isPrefix p s = not (null p) && p `isPrefixOf` s

runCmd :: State -> Cmd -> IO (Bool, State)
runCmd s Noop = return (False, s)
runCmd s (Help verbose) = do
    putStr $ helpText ++ unlines (map getHelp commands) ++ getSettings s
    when verbose $ putStr verboseHelp
    return (False, s)
runCmd s Quit =
    return (True, s)
runCmd s (Load f) = loadFile s f
runCmd s (Add i t) = updateSession s $
    CompatibilitySession.declareDjinnDeclaration (Function i t)
runCmd s Clear = do
    result <- initializeState $ sessionInitializer s
    case result of
        Left failure -> do
            putStrLn $ renderSessionInitializationFailure
                "Error: cannot clear the Djinn session:" failure
            return (False, markFailed s)
        Right cleared ->
            return (False, cleared { commandFailed = commandFailed s })
runCmd s (Del i) =
    case CompatibilitySession.removeDjinnDeclaration i (djinnSession s) of
        Left failure -> do
            putStrLn $ "Error: cannot delete " ++ i ++ ": " ++
                Diagnostic.renderDiagnostic failure
            return (False, markFailed s)
        Right session -> installSession s session
runCmd s Env = do
    let declarationSnapshot =
            CompatibilitySession.djinnSessionDeclarationSnapshot $
                djinnSession s
        showType (i, (_, HTAbstract _ kind, _)) =
            "type " ++ i ++ " :: " ++ show kind
        showType (i, (vs, t, _)) =
            tname t ++ " " ++ unwords (i:vs) ++ showd t
        tname t = if isHTUnion t then "data" else "type"
        showd (HTUnion []) = ""
        showd t = " = " ++ show t
    mapM_ (putStrLn . showType)
        (reverse $ CompatibilitySession.djinnSnapshotTypeDeclarations
            declarationSnapshot)
    mapM_ (\ (i, t) -> putStrLn $ prHSymbolOp i ++ " :: " ++ show t)
        (reverse $ CompatibilitySession.djinnSnapshotFunctionDeclarations
            declarationSnapshot)
    mapM_ (putStrLn . showClass)
        (reverse $ CompatibilitySession.djinnSnapshotClassDeclarations
            declarationSnapshot)
    return (False, s)
runCmd s (Type name params body) =
    updateSession s . CompatibilitySession.declareDjinnDeclaration $
        case body of
            HTUnion constructors -> DataType name params constructors
            HTAbstract _ kind -> AbstractType name kind
            _ -> TypeSynonym name params body
runCmd s (Set f) =
    return (False, f s)
runCmd s (Query i ctx g) =
    query s i ctx g
runCmd s (Class (name, (params, methods))) =
    updateSession s $ CompatibilitySession.declareDjinnDeclaration $
        ClassDecl name params methods
runCmd s (QueryInstance ctx target) =
    case CompatibilitySession.resolveDjinnInstanceMethods
            (djinnSession s) ctx target of
        Left failure -> do
            putStrLn $ "Error: " ++ commandDiagnostic failure
            return (False, markFailed s)
        Right methods -> do
            let instanceHeading = "instance " ++ contextPrefix ctx ++
                    show target
                -- An instance needs one coherent body per method.  Ordinary
                -- query alternatives would become overlapping equations, and
                -- debug lines would split the layout block, so neither
                -- presentation option applies inside an instance declaration.
                methodPresentation = s { multi = False, debug = False }
                prepareMethod method@(name, goal) =
                    case makeDjinnResult methodPresentation name ctx goal of
                        Left failure -> Left $
                            "cannot generate method " ++ prHSymbolOp name ++
                            ": " ++ Diagnostic.renderDiagnostic failure
                        Right result -> case formatDjinnResult
                            False methodPresentation name ctx goal result of
                          Left message -> Left $
                            "cannot render method " ++ prHSymbolOp name ++
                            ": " ++ message
                          Right output -> Right (method, result, output)
                methodRealized (_, result, _) =
                    resultEvidence result == ValidatedCandidates
                -- The shared renderer may return a multi-line case expression
                -- as one string.  Prefix every physical line, not merely the
                -- first list element, to keep the complete method in the
                -- instance's layout block.
                printMethod (_, _, output) =
                    mapM_ (putStrLn . ("   " ++)) $ concatMap lines output
                printFailedMethod (_, _, output) = mapM_ putStrLn output
            case mapM prepareMethod methods of
                Left msg -> do
                    putStrLn $ "Error: " ++ msg
                    return (False, markFailed s)
                Right reports -> do
                    let failures = filter (not . methodRealized) reports
                    case failures of
                      [] -> do
                        putStrLn $ instanceHeading ++ " where"
                        mapM_ printMethod reports
                      _ -> do
                        -- Do not print an instance-shaped prefix unless every
                        -- method has a body.  A partial block is not useful
                        -- Haskell and can easily be mistaken for generated
                        -- code that merely needs a small edit.
                        putStrLn $ "-- cannot generate " ++ instanceHeading ++
                            ": one or more methods have no realization."
                        mapM_ printFailedMethod failures
                    return (False, s)

updateSession :: State
              -> (DjinnSession -> Either Diagnostic.Diagnostic DjinnSession)
              -> IO (Bool, State)
updateSession state change =
    case change (djinnSession state) of
        Left failure -> do
            putStrLn $ "Error: " ++ Diagnostic.renderDiagnostic failure
            return (False, markFailed state)
        Right session -> installSession state session

installSession :: State -> DjinnSession -> IO (Bool, State)
installSession state session =
    return (False, state { djinnSession = session })

markFailed :: State -> State
markFailed state = state { commandFailed = True }

query :: State -> String -> [Context] -> HType -> IO (Bool, State)
query s i ctx g = do
    case makeDjinnResult s i ctx g of
        Left failure -> do
            putStrLn $ "Error: " ++ commandDiagnostic failure
            return (False, markFailed s)
        Right result -> case formatDjinnResult True s i ctx g result of
            Left message -> do
                putStrLn $ "Error: " ++ message
                return (False, markFailed s)
            Right output -> do
                mapM_ putStrLn output
                return (False, s)

makeDjinnResult :: State -> String -> [Context] -> HType
                -> Either Diagnostic.Diagnostic DjinnResult
makeDjinnResult s name contexts goal = do
    target <- case SharedName.parseName name of
        Left failure -> Left $ Diagnostic.shownErrorDiagnostic
            "DJEX_DJINN_TARGET" "cannot convert the parsed Djinn target"
            failure
        Right value -> Right value
    checkedTarget <- validateDjinnTarget target
    sharedGoal <- CompatibilityRequest.validateDjinnQueryType "goal" goal
    sharedContexts <- traverse
        (traverse $ CompatibilityRequest.validateDjinnQueryType
            "context argument") contexts
    request <- mkDjinnRequest QueryRequest {
        requestTarget = checkedTarget,
        requestGoal = sharedGoal,
        requestContexts = sharedContexts,
        requestOptions = queryOptions
        }
    runDjinnQuery (djinnSession s) request
  where queryOptions = defaultQueryOptions {
        optionAlternatives = multi s,
        optionSorted = sorted s,
        optionCutoff = cutOff s,
        optionBudget = if budget s > unlimitedBudget
            then Just (budget s)
            else Nothing
        }

formatDjinnResult :: Bool -> State -> String -> [Context] -> HType
                  -> DjinnResult -> Either String [String]
formatDjinnResult prType s name ctx goal result =
    fmap (debugFormula ++) $ case resultEvidence result of
      NoEvidence -> case SharedSearch.observeProgress $ Just progress of
          SharedSearch.ObservedTruncated _ ->
              Right ["-- " ++ name ++
                  ": no proof found within budget " ++
                  show (budget s) ++ "; inhabitation is undecided."]
          SharedSearch.ObservedFinished ->
              Right ["-- " ++ name ++
                  ": no proof found in the supported inference fragment; " ++
                  "inhabitation is undecided."]
          _ -> Left $ "Djinn returned no evidence after " ++ show progress
      RequiresTargetReference -> Right ["-- " ++ name ++
          " cannot be safely realized without a recursive self-reference."]
      ProvedUninhabitable ->
          Right ["-- " ++ name ++ " cannot be realized."]
      ValidatedCandidates -> do
          clauses <- mapM renderClause selectedCandidates
          case clauses of
            [] -> Left "Djinn returned candidate evidence without a candidate"
            firstClause : alternatives -> Right $
                debugProof ++ typeSignature ++ [firstClause] ++
                concat [["-- or", alternative] | alternative <- alternatives]
  where
    search = resultSearch result
    progress = SharedSearch.batchProgress search
    selectedCandidates = SharedSelection.selectionCandidates
        $ SharedSelection.selectQueryResults selectionMode
            (const ()) (const True) [result]
    selectionMode
      | multi s = SharedSelection.SelectAll
      | otherwise = SharedSelection.SelectFirst
    metadata = SharedSearch.batchMetadata search
    debugFormula
      | debug s = ["*** " ++ djinnTranslatedFormula metadata]
      | otherwise = []
    debugProof
      | debug s = maybe [] (\proof -> ["+++ " ++ proof]) $
          djinnFirstExploredProof metadata
      | otherwise = []
    typeSignature
      | prType = [prHSymbolOp name ++ " :: " ++
          contextPrefix ctx ++ show goal]
      | otherwise = []
    renderClause = either (Left . show) Right .
        renderDjinnCandidateDefinition FullyQualified

-- The compatibility CLI promotes the innermost context to its traditional
-- @Error:@ headline. Remove that entry before rendering the structured body so
-- every context is still shown exactly once.
commandDiagnostic :: Diagnostic.Diagnostic -> String
commandDiagnostic failure = case reverse $ Diagnostic.diagnosticContext failure of
    [] -> Diagnostic.renderDiagnostic failure
    context : reversedOuterContexts ->
        let strippedFailure = failure
                { Diagnostic.diagnosticContext = reverse reversedOuterContexts }
        in context ++ "\n  " ++ Diagnostic.renderDiagnostic strippedFailure

renderSessionInitializationFailure
    :: String
    -> Diagnostic.Diagnostic
    -> String
renderSessionInitializationFailure heading failure =
    heading ++ "\n  " ++ intercalate "\n  "
        (lines $ Diagnostic.renderDiagnostic failure)

contextPrefix :: [Context] -> String
contextPrefix [] = ""
contextPrefix contexts = showContexts contexts ++ " => "

loadFile :: State -> String -> IO (Bool, State)
loadFile s name = do
    -- Force the complete file before running any command. With a lazy read,
    -- a decode or device error surfacing mid-file would abort evalCmds after
    -- earlier commands had already printed their results, silently rolling
    -- the session back to the pre-load state; batch semantics are otherwise
    -- incremental, so reporting the read error up front keeps printed output
    -- and surviving state in agreement.
    result <- tryIOError $ do
        file <- readFile name
        _ <- evaluate $ length file
        evalCmds s $ lines $ stripLineComments file
    case result of
        Left err -> do
            putStrLn $ "Error loading " ++ show name ++ ": " ++ show err
            return (False, markFailed s)
        Right result' -> return result'

showClass :: (HSymbol, ([(HSymbol, HKind)], [Method])) -> String
showClass (c, (as, ms)) =
    "class " ++ show validatedHead ++ " where " ++
        intercalate "; " (map sm ms)
  where
    -- Class declarations have already passed the same name validation in the
    -- core.  Rebuilding their head through mkContext keeps the CLI renderer on
    -- the shared nominal representation without introducing another format.
    validatedHead =
        case mkContext c (map (HTVar . fst) as) of
            Right context -> context
            Left message -> error $ "Djinn.showClass: " ++ message
    sm (i, t) = prHSymbolOp i ++ " :: " ++ show t

showContexts :: [Context] -> String
showContexts [] = ""
showContexts cs = "(" ++ intercalate ", " (map show cs) ++ ")"

evalCmds :: State -> [String] -> IO (Bool, State)
evalCmds state [] = return (False, state)
evalCmds state (l:ls) = do
    qs@(q, state') <- eval state l
    if q then
        return qs
     else
        evalCmds state' ls

commands :: [(String, String, ReadP Cmd)]
commands = [
        (":clear",              "Clear environment and settings", return Clear),
        (":delete <sym>",       "Delete from environment.",     pDel),
        (":environment",        "Show environment",             return Env),
        (":help",               "Print this message.",          return (Help False)),
        (":load <file>",        "Load a file",                  pLoad),
        (":quit",               "Quit program.",                return Quit),
        (":set <option>",       "Set options",                  pSet),
        (":verbose-help",       "Print verbose help.",          return (Help True)),
        ("type <sym> <vars> = <type>", "Add a type synonym",    pType),
        ("data <sym> <vars> = <datatype>", "Add a data type",   pData),
        ("class <sym> <vars> where <methods>", "Add a class",   pClass),
        ("<sym> :: <type>",     "Add to environment",           pAdd),
        ("? <sym> :: <type>",   "Query",                        pQuery'),
        ("<sym> ? <type>",      "Query",                        pQuery),
        ("?instance <sym> <types>","Query instance",            pQueryInstance)
        ]

-- Keep accepting the historical camel-case spelling without advertising it.
commandParsers :: [(String, ReadP Cmd)]
commandParsers =
    [(name, parser) | (name, _, parser) <- commands] ++
    [(":verboseHelp", return (Help True)), ("", return Noop)]

options :: [(String, String, State->Bool, Bool->State->State)]
options = [
          ("multi",             "print multiple solutions",     multi,  \ v s -> s { multi  = v }),
          ("sorted",            "sort solutions",               sorted, \ v s -> s { sorted = v }),
          ("debug",             "debug mode",                   debug,  \ v s -> s { debug  = v })
          ]

getHelp :: (String, String, a) -> String
getHelp (cmd, help, _) = cmd ++ replicate (helpColumn - length cmd) ' ' ++ help

helpColumn :: Int
helpColumn = 2 + maximum [length cmd | (cmd, _, _) <- commands]

-- Accept anything that could have been declared: type and class names are
-- plain constructor identifiers, but axioms may carry a qualified name.
pDel :: ReadP Cmd
pDel = do
    s <- pConId +++ pExternalTermName
    return $ Del s

pLoad :: ReadP Cmd
pLoad = do
    skipSpaces
    s <- munch1 (not . isSpace)
    return $ Load s

pAdd :: ReadP Cmd
pAdd = do
    i <- pExternalTermName
    sstring "::"
    t <- pHType
    optional $ schar ';'
    return $ Add i t

pQuery :: ReadP Cmd
pQuery = do
    i <- pLocalTermName
    schar '?'
    c <- option [] pHContext
    t <- pHType
    optional $ schar ';'
    return $ Query i c t

pQuery' :: ReadP Cmd
pQuery' = do
    schar '?'
    i <- pLocalTermName
    sstring "::"
    c <- option [] pHContext
    t <- pHType
    optional $ schar ';'
    return $ Query i c t

pQueryInstance :: ReadP Cmd
pQueryInstance = do
    schar '?'
    skeyword "instance"
    c <- option [] pHContext
    target <- pHConstraint
    optional $ schar ';'
    return $ QueryInstance c target

pType :: ReadP Cmd
pType = do
    skeyword "type"
    syn <- pHSymbol True
    do args <- many (pHSymbol False)
       schar '='
       t <- pHType
       return $ Type syn args t
     +++
      do
       sstring "::"
       k <- pHKind
       return $ Type syn [] (HTAbstract syn k)

pData :: ReadP Cmd
pData = do
    skeyword "data"
    syn <- pHSymbol True
    args <- many (pHSymbol False)
    do schar '='
       t <- pHDataType
       case t of
           HTUnion [] -> pfail
           _ -> return $ Type syn args t
      +++
     do
       return $ Type syn args (HTUnion [])

pClass :: ReadP Cmd
pClass = do
    skeyword "class"
    cls <- pHSymbol True
    args <- many (pHSymbol False)
    skeyword "where"
    mets <- sepBy pMethod (schar ';')
    return $ Class (cls, (args, mets))

type Method = (HSymbol, HType)

pMethod :: ReadP Method
pMethod = do
    i <- pLocalTermName
    sstring "::"
    t <- pHType
    return (i, t)

pLocalTermName :: ReadP HSymbol
pLocalTermName = pVarId +++ pParenthesizedVarOp

pExternalTermName :: ReadP HSymbol
pExternalTermName = pQualifiedVarId +++ pParenthesizedVarOp

pSet :: ReadP Cmd
pSet = pSetFlag +++ pSetVal

pSetFlag :: ReadP Cmd
pSetFlag = do
    val <- (do schar '+'; return True) +++ (do schar '-'; return False)
    f <- foldr (+++) pfail [ do pPrefix s; return (set val) | (s, _, _, set) <- options ]
    return $ Set f

pSetVal :: ReadP Cmd
pSetVal = pCutoff +++ pBudget
  where
    pCutoff = do
        n <- pNumericSetting "cutoff"
        if n > 0 && n <= toInteger (maxBound :: Int) then
            return $ Set $ \ s -> s { cutOff = fromInteger n }
         else
            pfail
    pBudget = do
        n <- pNumericSetting "budget"
        return $ Set $ \ s -> s { budget = n }

pNumericSetting :: String -> ReadP Integer
pNumericSetting name = do
    pPrefix name
    schar '='
    digits <- munch1 isDigit
    return (read digits)

helpText :: String
helpText = "\
\Djinn is a program that generates Haskell code from a type.\n\
\Given a type the program will deduce an expression of this type,\n\
\if one exists.  If the Djinn says the type is not realizable it is\n\
\because there is no (total) expression of the given type.\n\
\Djinn only knows about tuples, ->, and some data types in the\n\
\initial environment (use :environment for a list).\n\
\\n\
\Caveat emptor: Treat the generated expression as a candidate.  It may\n\
\need supporting declarations and still belongs in your compile/test loop.\n\
\\n\
\Send any comments and feedback to https://github.com/VladimirReshetnikov/Djex/issues\n\
\\n\
\Commands (may be abbreviated):\n\
\"

getSettings :: State -> String
getSettings s = unlines $ [
    "",
    "Current settings" ] ++ [ "    " ++ (if gett s then "+" else "-") ++ name ++ replicate (10 - length name) ' ' ++ descr |
                              (name, descr, gett, _set) <- options ] ++
    [ "    cutoff=" ++ show (cutOff s) ++ " maximum number of solutions generated",
      "    budget=" ++ show (budget s) ++ " choice-point budget, " ++
          show unlimitedBudget ++ " = unlimited" ]

-- The historical REPL represents the core's 'Nothing' budget with a numeric
-- setting so @:set budget=0@ can retain its original spelling.
unlimitedBudget :: Integer
unlimitedBudget = 0
