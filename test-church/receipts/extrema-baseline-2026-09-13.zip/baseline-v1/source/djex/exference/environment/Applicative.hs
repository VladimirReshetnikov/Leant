module Control.Applicative where

import Control.Arrow (Arrow, ArrowMonad, ArrowPlus, ArrowZero)
-- Instance-only SOURCE imports keep the curated module graph acyclic.
import {-# SOURCE #-} qualified Control.Monad (Monad, MonadPlus)
import qualified Data.Eq (Eq)
import qualified Data.Functor (Functor)
import qualified Data.Functor.Const (Const)
import qualified Data.Monoid (Monoid)
import qualified Data.Ord (Ord)
import qualified GHC.Generics (Generic, Generic1)
import {-# SOURCE #-} qualified Text.Read (Read)
import qualified Text.Show (Show)


class Data.Functor.Functor f => Applicative f where
  pure :: a -> f a
  (<*>) :: f (a->b) -> f a -> f b

class Applicative f => Alternative f where
  -- empty :: f a
  (<|>) :: f a -> f a -> f a
  -- some :: f a -> f [a]
  -- many :: f a -> f [a] 

liftA2 :: Applicative f => (a1 -> a2 -> r) -> f a1 -> f a2 -> f r
liftA3 :: Applicative f => (a1 -> a2 -> a3 -> r) -> f a1 -> f a2 -> f a3 -> f r 

instance Data.Monoid.Monoid a => Applicative ((,) a)
instance Arrow a => Applicative (Control.Arrow.ArrowMonad a)
instance Control.Monad.Monad m => Applicative (Control.Applicative.WrappedMonad m)
instance Data.Monoid.Monoid m => Applicative (Data.Functor.Const.Const m)
instance Arrow a => Applicative (Control.Applicative.WrappedArrow a b)
-- instance Typeable ((* -> *) -> Constraint) Applicative

instance Alternative []
instance ArrowPlus a => Alternative (Control.Arrow.ArrowMonad a)
instance Control.Monad.MonadPlus m => Alternative (Control.Applicative.WrappedMonad m)
-- instance Alternative f => Alternative (Alt * f)
instance (ArrowZero a, ArrowPlus a) => Alternative (Control.Applicative.WrappedArrow a b)

data WrappedMonad m a
data WrappedArrow a b c
data ZipList a

instance Data.Functor.Functor ZipList
instance Control.Applicative.Applicative ZipList
instance GHC.Generics.Generic1 ZipList
instance Data.Eq.Eq a => Data.Eq.Eq (ZipList a)
instance Data.Ord.Ord a => Data.Ord.Ord (ZipList a)
instance Text.Read.Read a => Text.Read.Read (ZipList a)
instance Text.Show.Show a => Text.Show.Show (ZipList a)
instance GHC.Generics.Generic (ZipList a)
