from pathlib import Path
import json,os,subprocess,sys

ROOT=Path.cwd()
OUT=ROOT/'dist-newstyle/acyclic-head-unit-v1'
TRACE=Path('C:/Leant-validation/constructor-closure/dist-newstyle/reduction-carrier-trace-v2/results.json')
assert json.loads(TRACE.read_text())['status']=='completed_diagnostic'
sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as runtime
OUT.mkdir(exist_ok=False)
paths=[ROOT/p for p in subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
    if p and (ROOT/p).is_file() and (Path(p).suffix in ['.hs','.lhs','.cabal'] or p=='cabal.project')]
report=dict(status='running',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    source_sha256={p.relative_to(ROOT).as_posix():runtime.sha256(p) for p in paths})
for p in paths:
    dest=OUT/'source'/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
(OUT/'change.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=ROOT))
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
runner=runtime.Processes(OUT,1200)
runtime.write_json(OUT/'results.json',report)
try:
    build=runner.run('strict-build',['cabal','build','djex:test:djinn-tests','djex:exe:djex','djex:exe:djex-fake-z3','djex:exe:djex-fake-cabal','--ghc-options=-Werror','-j1'],cwd=ROOT)
    report['build_exit_code']=build.returncode
    assert build.returncode==0,'strict build failed'
    exe=Path(subprocess.check_output(['cabal','list-bin','djex:test:djinn-tests'],cwd=ROOT).decode().strip())
    report['runtime_sha256']={str(exe):runtime.sha256(exe)}
    runner.timeout=180
    result=runner.run('reductions',[str(exe),'--timeout','120s'],cwd=ROOT,env=dict(os.environ,djex_datadir=str(ROOT)))
    report['test_exit_code']=result.returncode
except Exception as failure:
    report['failure']=repr(failure)
finally:
    report['sources_unchanged']=all(runtime.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
    report['runtimes_unchanged']=all(runtime.sha256(Path(p))==h for p,h in report.get('runtime_sha256',{}).items())
    report['controller_unchanged']=(OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
    report['processes']=runner.rows
    report['status']='passed' if report.get('test_exit_code')==0 and all(report[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged']) else 'failed'
    runtime.write_json(OUT/'results.json',report)
print(report['status'],flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)



