# Path-sensitive head use acceptance

Canonical validation starts at Djex 202e0f5951ab2156ed8e418b6480e9e60937c720
plus the exact three-file overlay retained in canonical-unit and canonical-release.
Native validation starts at Leant cce462e0474536c091295eef18e8deb3615a00a3
with that same Djex base and overlay. No native implementation file is changed.
Use retained source snapshots, patches, runtime identities and controllers.
Adapt absolute workspace/runtime paths in a fresh output directory without
altering source types, provider inventories, observations or query limits.

Run strict builds, the complete 137-test Djinn suite, focused public Haskell
and native maybeEither queries, both complete extended Haskell corpora, then
the canonical and native release controllers. All heavy stages ran serially.
The canonical release controller's outer process guard is 3600 seconds;
this does not change query bounds or per-test settings.

Earlier reduction-use experiments failed and remain diagnostic only. The
maybeEither baseline and traces precede the successful path-sensitive branch.
The branch restricts exact head reuse along individual application paths;
sibling arguments retain independent availability, and the original full
search remains in the cursor. No reference implementation enters synthesis.
Compiler/runtime binaries are identified by hashes rather than redistributed.
