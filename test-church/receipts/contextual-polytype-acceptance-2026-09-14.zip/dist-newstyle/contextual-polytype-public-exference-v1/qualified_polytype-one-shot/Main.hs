{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds, AllowAmbiguousTypes #-}
module Main where
import Fixture
probe :: forall a r. Fixture.Marker a => (forall s. Fixture.Marker a => s -> Fixture.Witness s r) -> (forall b. b -> Fixture.Token) -> Fixture.Witness (forall b. b -> Fixture.Token) r
probe = ((\ @a @r -> (\(x :: forall djexBound0_0. (Fixture.Marker a) => djexBound0_0 -> Fixture.Witness djexBound0_0 r) -> ((((x :: forall djexBound0_0. (Fixture.Marker a) => djexBound0_0 -> Fixture.Witness djexBound0_0 r) @(forall djexBound0_0. djexBound0_0 -> Fixture.Token)) :: (Fixture.Marker a) => (forall djexBound1_0. djexBound1_0 -> Fixture.Token) -> Fixture.Witness (forall djexBound1_0. djexBound1_0 -> Fixture.Token) r) :: (forall djexBound0_0. djexBound0_0 -> Fixture.Token) -> Fixture.Witness (forall djexBound0_0. djexBound0_0 -> Fixture.Token) r))) :: forall a r . Fixture.Marker a =>   (forall s . Fixture.Marker a => s -> Fixture.Witness s r) ->     (forall b . b -> Fixture.Token) ->       Fixture.Witness (forall b . b -> Fixture.Token) r)
main :: IO ()
main = print (case probe @Int @Int (\x -> Fixture.Witness 7 x) (\_ -> Fixture.Token 37) of Fixture.Witness value payload -> value == 7 && (case payload True of Fixture.Token n -> n == 37))
