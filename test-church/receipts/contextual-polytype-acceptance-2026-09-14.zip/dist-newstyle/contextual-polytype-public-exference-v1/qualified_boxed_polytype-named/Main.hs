{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds, AllowAmbiguousTypes #-}
module Main where
import Fixture
probe :: forall a r. Fixture.Marker a => (forall s. Fixture.Marker a => s -> Fixture.Witness s r) -> Fixture.Box (forall b. b -> Fixture.Token) -> Fixture.Witness (Fixture.Box (forall b. b -> Fixture.Token)) r
probe f1 b2 = let Fixture.Box _ = b2 in f1 b2
main :: IO ()
main = print (case probe @Int @Int (\x -> Fixture.Witness 11 x) (Fixture.Box (\_ -> Fixture.Token 53)) of Fixture.Witness value (Fixture.Box payload) -> value == 11 && (case payload () of Fixture.Token n -> n == 53))
