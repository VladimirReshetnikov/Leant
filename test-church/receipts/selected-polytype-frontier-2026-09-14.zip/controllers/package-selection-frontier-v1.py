"""Package bounded diagnostic evidence; this is not a synthesis release."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path('C:/Leant')
LENGTH = Path('C:/Djex-validation/constructor-carrier-length/dist-newstyle')
DEST = ROOT / 'test-church/receipts'
stem = 'selected-polytype-frontier-2026-09-14'
files = {}
def sha(data):
    return hashlib.sha256(data).hexdigest()
for attempt in ['constructor-carrier-baseline-v1', 'constructor-carrier-baseline-v2']:
    directory = LENGTH / attempt
    data = json.loads((directory / 'results.json').read_text(encoding='utf-8'))
    assert data['status'] == 'failed' and data['sources_unchanged'] and data['runtimes_unchanged']
    fixture = directory / 'source/djinn/test-unit/Spec.hs'
    assert sha(fixture.read_bytes()) == data['source_sha256']['djinn/test-unit/Spec.hs']
    for path in directory.iterdir():
        if path.is_file():
            files[attempt + '/' + path.name] = path
    files[attempt + '/source/djinn/test-unit/Spec.hs'] = fixture
    controller = LENGTH / ('run-' + attempt + '.py')
    files['controllers/' + controller.name] = controller

directory = ROOT / 'dist-newstyle/selected-polytype-public-v1'
data = json.loads((directory / 'results.json').read_text(encoding='utf-8'))
assert data['status'] == 'failed' and data['sources_unchanged'] and data['runtimes_unchanged']
assert data['specifications'][0]['oracle_replay']['status'] == 'passed'
assert len(data['results']) == 3 and all(row['status'] == 'failed' for row in data['results'])
for path in directory.rglob('*'):
    if path.is_file():
        files['selected-polytype-public-v1/' + path.relative_to(directory).as_posix()] = path
for name in ['selected-polytype-baseline.py', Path(__file__).name]:
    files['controllers/' + name] = ROOT / 'dist-newstyle' / name

archive = DEST / (stem + '.zip')
assert not archive.exists()
members = {}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name,path in sorted(files.items()):
        raw = path.read_bytes()
        bundle.writestr(name, raw)
        members[name] = sha(raw)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    assert {name:sha(bundle.read(name)) for name in bundle.namelist()} == members
record = dict(scope='Diagnostic evidence only: corrected direct/wrapped length comparison misses at fixed bounds, and a kernel-checked boxed polymorphic payload refused by the published native source entrance. Includes changed private fixture snapshots, controllers, logs, public inputs and replay. Full unchanged baseline sources and executables are excluded; receipts retain hashes. Length baseline is Djex 31ffa3c87d2241212d2b85e7e4f9168fdbf7ab66; native baseline is the separately archived contextual-universe acceptance source.',
              archive=archive.name, sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size, members=members)
(DEST / (stem + '.json')).write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k:v for k,v in record.items() if k != 'members'}, indent=2))
print('members', len(members))
