"""Discriminating public baseline; no implementation or acceptance claim."""
from pathlib import Path
import sys

ROOT = Path('C:/Leant-validation/contextual-universe-transport')
sys.path.insert(0, str(ROOT / 'test-context'))
import run_products

POLY = '(∀ β : Type, β → Nat)'
SOURCE = f'∀ A : Type, [SelectedPoly.Dictionary A] → {POLY} → SelectedPoly.Box {POLY}'
PREDICATE = (
    '(@{f} Nat (@SelectedPoly.Dictionary.mk Nat 7) (fun _ _ => 37)).value Bool true = 37 ∧ '
    '(@{f} Nat (@SelectedPoly.Dictionary.mk Nat 11) (fun _ _ => 53)).value Unit () = 53'
)
SPECIFICATIONS = [dict(
    label='boxed_polymorphic_payload',
    type=SOURCE,
    declarations=[
        'class SelectedPoly.Dictionary (α : Type) where tag : Nat',
        'structure SelectedPoly.Box (α : Type 1) where value : α',
    ],
    oracle='fun (A : Type) [d : SelectedPoly.Dictionary A] payload => ⟨payload⟩',
    predicate=PREDICATE,
    ordinary=PREDICATE,
    require_context_introduction=True,
)]

if __name__ == '__main__':
    raise SystemExit(run_products.main(
        SPECIFICATIONS,
        scope='A boxed polymorphic payload forces a quantified constructor type argument, while two observations require preserving the supplied payload. Baseline for source admission, universe evidence and selected-polytype projection; not acceptance until live synthesis and exact replay pass.',
        label_prefix='selected_polytype', additional_sources=(Path(__file__),)))
