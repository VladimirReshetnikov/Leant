"""Bounded witness diagnostic; run only after the shared runtime owner finishes."""
from pathlib import Path
import json
import os
import subprocess
import sys

ROOT = Path('C:/Djex-validation/constructor-carrier-length')
sys.path.insert(0, str(ROOT / 'test-church'))
import behavior_runtime as rt

OUT = rt.prepare_output_directory(ROOT / 'dist-newstyle/constructor-carrier-baseline-v2')
names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
files = [ROOT / name for name in names if name.endswith(('.hs', '.cabal', '.py'))]
files.append(Path(__file__).resolve())
sources = {}
for path in files:
    name = path.relative_to(ROOT).as_posix()
    sources[name] = rt.sha256(path)
    target = OUT / 'source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(path.read_bytes())
report = dict(status='running', scope='Direct versus wrapped recursive counter witness at fixed 65536 raw proofs and 500000 choices. No public Lean acceptance.',
              source_sha256=sources, runtime_sha256={}, gates=[])
runner = rt.Processes(OUT, 2400)
env = dict(os.environ, djex_datadir=str(ROOT), PYTHONDONTWRITEBYTECODE='1')

def save():
    report['processes'] = runner.rows
    rt.write_json(OUT / 'results.json', report)

try:
    save()
    build = runner.run('strict-build', ['cabal', 'build', 'test:djinn-tests', '--ghc-options=-Werror', '-j1'], cwd=ROOT, env=env)
    report['gates'].append(dict(label='strict-build', exit_code=build.returncode))
    save()
    assert build.returncode == 0
    exe = subprocess.check_output(['cabal', 'list-bin', 'test:djinn-tests'], cwd=ROOT).decode().strip()
    report['runtime_sha256'][exe] = rt.sha256(Path(exe))
    tested = runner.run('constructor-field-witness', [exe, '--num-threads', '1', '-p', '/instantiate a local fold at a recursive constructor field type/'], cwd=ROOT, env=env)
    report['gates'].append(dict(label='constructor-field-witness', exit_code=tested.returncode))
    assert tested.returncode == 0 and 'All 1 tests passed' in tested.stdout
    report['status'] = 'passed'
except BaseException as failure:
    report.update(status='failed', failure=repr(failure))
finally:
    report['sources_unchanged'] = all(rt.sha256(ROOT / p) == h for p, h in sources.items())
    report['runtimes_unchanged'] = all(rt.sha256(Path(p)) == h for p, h in report['runtime_sha256'].items())
    if not report['sources_unchanged'] or not report['runtimes_unchanged']:
        report['status'] = 'failed'
    save()
print(report['status'], report.get('failure', ''), flush=True)
sys.exit(0 if report['status'] == 'passed' else 1)
