set_option autoImplicit false
class ContextProduction.Dictionary (α : Type) where tag : Nat
def ProductReplay.accepted : ∀ (α : Type), [ContextProduction.Dictionary α] → ∀ (γ : Type 1), (∀ (β : Type 1), β → α) → γ → α :=
((fun (leantType120 : Type) => (fun [leantGiven137x0 : @_root_.«ContextProduction».«Dictionary» (leantType120)] => (fun (leantType155 : Type (0 + 1)) => (fun (leantLocal174 : (∀ (leantBound0x0 : Type (0 + 1)), (leantBound0x0 → leantType120))) => @(let leantHead194 : (∀ (leantBound0x0 : Type (0 + 1)), (leantBound0x0 → leantType120)) := @leantLocal174; @leantHead194 (leantType155)))))) : (∀ (leantBound0x0 : Type) [@_root_.«ContextProduction».«Dictionary» (leantBound0x0)], (∀ (leantBound1x0 : Type (0 + 1)), ((∀ (leantBound2x0 : Type (0 + 1)), (leantBound2x0 → leantBound0x0)) → (leantBound1x0 → leantBound0x0)))))
theorem ProductReplay.passes : (@ProductReplay.accepted Nat (@ContextProduction.Dictionary.mk Nat 7) (ULift.{1} Nat) (fun _ _ => 44) (⟨37⟩ : (ULift.{1} Nat)) = 44) ∧ (@ProductReplay.accepted Nat (@ContextProduction.Dictionary.mk Nat 11) (ULift.{1} Nat) (fun _ _ => 64) (⟨53⟩ : (ULift.{1} Nat)) = 64) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
