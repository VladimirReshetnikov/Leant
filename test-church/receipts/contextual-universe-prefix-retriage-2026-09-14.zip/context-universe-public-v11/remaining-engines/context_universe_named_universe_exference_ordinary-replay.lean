set_option autoImplicit false
universe u
class ContextProduction.Dictionary (α : Type) where tag : Nat
def ProductReplay.accepted : ∀ (α : Type), [ContextProduction.Dictionary α] → (∀ (β : Type u), β → β) :=
((fun (leantType55 : Type) => (fun [leantGiven67x0 : @_root_.«ContextProduction».«Dictionary» (leantType55)] => (fun (leantType80 : Type «u») => (fun (leantLocal94 : leantType80) => @leantLocal94)))) : (∀ (leantBound0x0 : Type) [@_root_.«ContextProduction».«Dictionary» (leantBound0x0)], (∀ (leantBound1x0 : Type «u»), (leantBound1x0 → leantBound1x0))))
theorem ProductReplay.passes : ((@ProductReplay.accepted.{u} Nat (@ContextProduction.Dictionary.mk Nat 7) (ULift.{u} Nat) (⟨37⟩ : (ULift.{u} Nat))).down = 37) ∧ ((@ProductReplay.accepted.{u} Nat (@ContextProduction.Dictionary.mk Nat 11) (ULift.{u} Nat) (⟨53⟩ : (ULift.{u} Nat))).down = 53) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
