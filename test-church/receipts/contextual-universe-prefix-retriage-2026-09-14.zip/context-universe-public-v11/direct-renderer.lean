set_option autoImplicit false
namespace ContextFixture
class C (α : Type) where
  payload : Nat
def first : C Nat := ⟨11⟩
def second : C Nat := ⟨29⟩
def boolSecond : C Bool := ⟨43⟩
def observe {α : Type} [c : C α] : Nat := c.payload
def observeValue {α : Type} [c : C α] (_value : α) : Nat := c.payload
end ContextFixture
def contextChooseFirst : [ContextFixture.C Nat] → [ContextFixture.C Nat] → ([ContextFixture.C Nat] → Nat) → Nat :=
  ((fun [leantGiven0x0 : @_root_.«ContextFixture».«C» (@_root_.«Nat»)] [leantGiven0x1 : @_root_.«ContextFixture».«C» (@_root_.«Nat»)] => (fun (leantLocal1 : (∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], @_root_.«Nat»)) => @(let leantHead2 : (∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], @_root_.«Nat») := @leantLocal1; @leantHead2 leantGiven0x0))) : (∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)] [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], ((∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], @_root_.«Nat») → @_root_.«Nat»)))
def contextChooseSecond : [ContextFixture.C Nat] → [ContextFixture.C Nat] → ([ContextFixture.C Nat] → Nat) → Nat :=
  ((fun [leantGiven0x0 : @_root_.«ContextFixture».«C» (@_root_.«Nat»)] [leantGiven0x1 : @_root_.«ContextFixture».«C» (@_root_.«Nat»)] => (fun (leantLocal1 : (∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], @_root_.«Nat»)) => @(let leantHead2 : (∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], @_root_.«Nat») := @leantLocal1; @leantHead2 leantGiven0x1))) : (∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)] [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], ((∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], @_root_.«Nat») → @_root_.«Nat»)))
def contextChooseOuter : [ContextFixture.C Nat] → [ContextFixture.C Nat] → ([ContextFixture.C Nat] → Nat) → Nat :=
  ((fun [leantGiven0x0 : @_root_.«ContextFixture».«C» (@_root_.«Nat»)] => (fun [leantGiven1x0 : @_root_.«ContextFixture».«C» (@_root_.«Nat»)] => (fun (leantLocal2 : (∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], @_root_.«Nat»)) => @(let leantHead3 : (∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], @_root_.«Nat») := @leantLocal2; @leantHead3 leantGiven0x0)))) : (∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], (∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], ((∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], @_root_.«Nat») → @_root_.«Nat»))))
def contextRankN : (A : Type) → [ContextFixture.C A] → (∀ {b : Type}, [ContextFixture.C b] → b → Nat) → A → Nat :=
  ((fun (leantType0 : Type) => (fun [leantGiven1x0 : @_root_.«ContextFixture».«C» (leantType0)] => (fun (leantLocal2 : (∀ {leantBound0x0 : Type} [@_root_.«ContextFixture».«C» (leantBound0x0)], (leantBound0x0 → @_root_.«Nat»))) (leantLocal3 : leantType0) => @(let leantHead3 : (leantType0 → @_root_.«Nat») := @(let leantHead4 : (∀ [@_root_.«ContextFixture».«C» (leantType0)], (leantType0 → @_root_.«Nat»)) := @(let leantHead5 : (∀ {leantBound0x0 : Type} [@_root_.«ContextFixture».«C» (leantBound0x0)], (leantBound0x0 → @_root_.«Nat»)) := @leantLocal2; @leantHead5 (leantType0)); @leantHead4 leantGiven1x0); @leantHead3 (@leantLocal3 : leantType0))))) : (∀ (leantBound0x0 : Type) [@_root_.«ContextFixture».«C» (leantBound0x0)], ((∀ {leantBound1x0 : Type} [@_root_.«ContextFixture».«C» (leantBound1x0)], (leantBound1x0 → @_root_.«Nat»)) → (leantBound0x0 → @_root_.«Nat»))))
def contextNested : (A : Type) → [ContextFixture.C A] → {B : Type} → [ContextFixture.C B] → ([ContextFixture.C A] → Nat) → Nat :=
  ((fun (leantType0 : Type) => (fun [leantGiven1x0 : @_root_.«ContextFixture».«C» (leantType0)] => (fun {leantType2 : Type} => (fun [leantGiven3x0 : @_root_.«ContextFixture».«C» (leantType2)] => (fun (leantLocal4 : (∀ [@_root_.«ContextFixture».«C» (leantType0)], @_root_.«Nat»)) => @(let leantHead5 : (∀ [@_root_.«ContextFixture».«C» (leantType0)], @_root_.«Nat») := @leantLocal4; @leantHead5 leantGiven1x0)))))) : (∀ (leantBound0x0 : Type) [@_root_.«ContextFixture».«C» (leantBound0x0)], (∀ {leantBound1x0 : Type} [@_root_.«ContextFixture».«C» (leantBound1x0)], ((∀ [@_root_.«ContextFixture».«C» (leantBound0x0)], @_root_.«Nat») → @_root_.«Nat»))))
def contextProvider : (A : Type) → [ContextFixture.C A] → Nat :=
  ((fun (leantType0 : Type) => (fun [leantGiven1x0 : @_root_.«ContextFixture».«C» (leantType0)] => @(let leantHead2 : (∀ [@_root_.«ContextFixture».«C» (leantType0)], @_root_.«Nat») := @(let leantHead3 : (∀ {leantBound0x0 : Type} [@_root_.«ContextFixture».«C» (leantBound0x0)], @_root_.«Nat») := @_root_.«ContextFixture».«observe»; @leantHead3 (leantType0)); @leantHead2 leantGiven1x0))) : (∀ (leantBound0x0 : Type) [@_root_.«ContextFixture».«C» (leantBound0x0)], @_root_.«Nat»))
def contextAlias : [ContextFixture.C Nat] → ([ContextFixture.C Nat] → Nat) → Nat :=
  ((fun [leantGiven0x0 : @_root_.«ContextFixture».«C» (@_root_.«Nat»)] => (fun (leantLocal1 : (∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], @_root_.«Nat»)) => @(let leantLocal2 : (∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], @_root_.«Nat») := @leantLocal1; @(let leantHead4 : (∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], @_root_.«Nat») := @leantLocal2; @leantHead4 leantGiven0x0)))) : (∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], ((∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], @_root_.«Nat») → @_root_.«Nat»)))
def contextUnit : [ContextFixture.C Nat] → Nat → Unit :=
  ((fun [leantGiven0x0 : @_root_.«ContextFixture».«C» (@_root_.«Nat»)] => (fun (leantLocal1 : @_root_.«Nat») => @_root_.Unit.unit)) : (∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], (@_root_.«Nat» → @_root_.Unit)))
def contextPair : [ContextFixture.C Nat] → Nat → Nat × Nat :=
  ((fun [leantGiven0x0 : @_root_.«ContextFixture».«C» (@_root_.«Nat»)] => (fun (leantLocal1 : @_root_.«Nat») => ⟨@leantLocal1, @leantLocal1⟩)) : (∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], (@_root_.«Nat» → (_root_.Prod (@_root_.«Nat») (@_root_.«Nat»)))))
def contextTriple : [ContextFixture.C Nat] → Nat → Nat × Nat × Nat :=
  ((fun [leantGiven0x0 : @_root_.«ContextFixture».«C» (@_root_.«Nat»)] => (fun (leantLocal1 : @_root_.«Nat») => ⟨@leantLocal1, @leantLocal1, @leantLocal1⟩)) : (∀ [@_root_.«ContextFixture».«C» (@_root_.«Nat»)], (@_root_.«Nat» → (_root_.Prod (@_root_.«Nat») ((_root_.Prod (@_root_.«Nat») (@_root_.«Nat»)))))))
theorem contextFirstPayload : @contextChooseFirst ContextFixture.first ContextFixture.second (@ContextFixture.observe Nat) = 11 := by rfl
theorem contextSecondPayload : @contextChooseSecond ContextFixture.first ContextFixture.second (@ContextFixture.observe Nat) = 29 := by rfl
theorem contextOuterPayload : @contextChooseOuter ContextFixture.first ContextFixture.second (@ContextFixture.observe Nat) = 11 := by rfl
theorem contextRankNPayload : @contextRankN Nat ContextFixture.second (@ContextFixture.observeValue) 7 = 29 := by rfl
theorem contextNestedPayload : @contextNested Nat ContextFixture.first Bool ContextFixture.boolSecond (@ContextFixture.observe Nat) = 11 := by rfl
theorem contextProviderPayload : @contextProvider Nat ContextFixture.first = 11 := by rfl
theorem contextAliasPayload : @contextAlias ContextFixture.second (@ContextFixture.observe Nat) = 29 := by rfl
theorem contextUnitPayload : @contextUnit ContextFixture.first 7 = () := by rfl
theorem contextPairPayload : @contextPair ContextFixture.first 7 = (7,7) := by rfl
theorem contextTriplePayload : @contextTriple ContextFixture.second 29 = (29,29,29) := by rfl
theorem contextFirstWrong : @contextChooseFirst ContextFixture.first ContextFixture.second (@ContextFixture.observe Nat) ≠ 29 := by decide
theorem contextSecondWrong : @contextChooseSecond ContextFixture.first ContextFixture.second (@ContextFixture.observe Nat) ≠ 11 := by decide
#print axioms contextFirstPayload
#print axioms contextSecondPayload
#print axioms contextOuterPayload
#print axioms contextRankNPayload
#print axioms contextNestedPayload
#print axioms contextProviderPayload
#print axioms contextAliasPayload
#print axioms contextUnitPayload
#print axioms contextPairPayload
#print axioms contextTriplePayload
#print axioms contextFirstWrong
#print axioms contextSecondWrong

#print axioms contextChooseFirst
#print axioms contextChooseSecond
#print axioms contextChooseOuter
#print axioms contextRankN
#print axioms contextNested
#print axioms contextProvider
#print axioms contextAlias
#print axioms contextUnit
#print axioms contextPair
#print axioms contextTriple
