set_option autoImplicit false
universe u
class ContextProduction.Dictionary (α : Type) where tag : Nat
def ProductReplay.accepted : ∀ (α : Type), [ContextProduction.Dictionary α] → ∀ (γ : Type u), (∀ (β : Type u), β → α) → γ → α :=
fun (α : Type) [d : ContextProduction.Dictionary α] (γ : Type u) p x => @p γ x
theorem ProductReplay.passes : (@ProductReplay.accepted.{u} Nat (@ContextProduction.Dictionary.mk Nat 7) (ULift.{u} Nat) (fun _ _ => 44) (⟨37⟩ : (ULift.{u} Nat)) = 44) ∧ (@ProductReplay.accepted.{u} Nat (@ContextProduction.Dictionary.mk Nat 11) (ULift.{u} Nat) (fun _ _ => 64) (⟨53⟩ : (ULift.{u} Nat)) = 64) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
