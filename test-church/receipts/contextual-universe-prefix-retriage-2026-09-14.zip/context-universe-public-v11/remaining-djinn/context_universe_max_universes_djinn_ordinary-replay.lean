set_option autoImplicit false
universe u v
class ContextProduction.Dictionary (α : Type) where tag : Nat
def ProductReplay.accepted : ∀ (α : Type), [ContextProduction.Dictionary α] → (∀ (β : Type (max u v)), β → β) :=
((fun (leantType77 : Type) => (fun [leantGiven2x0 : @_root_.«ContextProduction».«Dictionary» (leantType77)] => (fun (leantType44 : Sort (max («u» + 1) («v» + 1))) => (fun (leantLocal9 : leantType44) => @leantLocal9)))) : (∀ (leantBound0x0 : Type) [@_root_.«ContextProduction».«Dictionary» (leantBound0x0)], (∀ (leantBound1x0 : Sort (max («u» + 1) («v» + 1))), (leantBound1x0 → leantBound1x0))))
theorem ProductReplay.passes : ((@ProductReplay.accepted.{u, v} Nat (@ContextProduction.Dictionary.mk Nat 7) (ULift.{max u v} Nat) (⟨37⟩ : (ULift.{max u v} Nat))).down = 37) ∧ ((@ProductReplay.accepted.{u, v} Nat (@ContextProduction.Dictionary.mk Nat 11) (ULift.{max u v} Nat) (⟨53⟩ : (ULift.{max u v} Nat))).down = 53) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
