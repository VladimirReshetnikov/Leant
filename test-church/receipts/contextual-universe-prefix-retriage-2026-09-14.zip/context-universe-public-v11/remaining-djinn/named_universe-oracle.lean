set_option autoImplicit false
universe u
class ContextProduction.Dictionary (α : Type) where tag : Nat
def ProductReplay.accepted : ∀ (α : Type), [ContextProduction.Dictionary α] → (∀ (β : Type u), β → β) :=
fun (α : Type) [d : ContextProduction.Dictionary α] (β : Type u) x => x
theorem ProductReplay.passes : ((@ProductReplay.accepted.{u} Nat (@ContextProduction.Dictionary.mk Nat 7) (ULift.{u} Nat) (⟨37⟩ : (ULift.{u} Nat))).down = 37) ∧ ((@ProductReplay.accepted.{u} Nat (@ContextProduction.Dictionary.mk Nat 11) (ULift.{u} Nat) (⟨53⟩ : (ULift.{u} Nat))).down = 53) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
