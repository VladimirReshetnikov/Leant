set_option autoImplicit false
universe u v
class ContextProduction.Dictionary (α : Type) where tag : Nat
def ProductReplay.accepted : ∀ (α : Type), [ContextProduction.Dictionary α] → (∀ (β : Type (max u v)), β → β) :=
fun (α : Type) [d : ContextProduction.Dictionary α] (β : Type (max u v)) x => x
theorem ProductReplay.passes : ((@ProductReplay.accepted.{u, v} Nat (@ContextProduction.Dictionary.mk Nat 7) (ULift.{max u v} Nat) (⟨37⟩ : (ULift.{max u v} Nat))).down = 37) ∧ ((@ProductReplay.accepted.{u, v} Nat (@ContextProduction.Dictionary.mk Nat 11) (ULift.{max u v} Nat) (⟨53⟩ : (ULift.{max u v} Nat))).down = 53) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
