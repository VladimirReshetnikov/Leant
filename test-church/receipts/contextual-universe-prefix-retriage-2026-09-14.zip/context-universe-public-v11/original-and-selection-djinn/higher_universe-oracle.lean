set_option autoImplicit false
class ContextProduction.Dictionary (α : Type) where tag : Nat
def ProductReplay.accepted : ∀ (α : Type), [ContextProduction.Dictionary α] → (∀ (β : Type 1), β → β) :=
fun (α : Type) [d : ContextProduction.Dictionary α] (β : Type 1) x => x
theorem ProductReplay.passes : ((@ProductReplay.accepted Nat (@ContextProduction.Dictionary.mk Nat 7) (ULift.{1} Nat) (⟨37⟩ : (ULift.{1} Nat))).down = 37) ∧ ((@ProductReplay.accepted Nat (@ContextProduction.Dictionary.mk Nat 11) (ULift.{1} Nat) (⟨53⟩ : (ULift.{1} Nat))).down = 53) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
