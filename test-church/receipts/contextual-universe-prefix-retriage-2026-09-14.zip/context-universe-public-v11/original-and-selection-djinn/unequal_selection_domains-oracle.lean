set_option autoImplicit false
class ContextProduction.Dictionary (α : Type) where tag : Nat
def ProductReplay.accepted : ∀ (α : Type), [ContextProduction.Dictionary α] → ∀ (γ : Type 1), (∀ (β : Type 0), β → α) → γ → α :=
fun (α : Type) [d : ContextProduction.Dictionary α] (γ : Type 1) p x => @p (α → α) (fun value => value)
theorem ProductReplay.passes : (@ProductReplay.accepted Nat (@ContextProduction.Dictionary.mk Nat 7) (ULift.{1} Nat) (fun _ _ => 44) (⟨37⟩ : (ULift.{1} Nat)) = 44) ∧ (@ProductReplay.accepted Nat (@ContextProduction.Dictionary.mk Nat 11) (ULift.{1} Nat) (fun _ _ => 64) (⟨53⟩ : (ULift.{1} Nat)) = 64) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
