set_option autoImplicit false
class ContextProduction.Dictionary (α : Type) where tag : Nat
def ProductReplay.accepted : ∀ (α : Type), [ContextProduction.Dictionary α] → (∀ (β : Type 1), β → β) :=
((fun (leantType77 : Type) => (fun [leantGiven2x0 : @_root_.«ContextProduction».«Dictionary» (leantType77)] => (fun (leantType44 : Type (0 + 1)) => (fun (leantLocal9 : leantType44) => @leantLocal9)))) : (∀ (leantBound0x0 : Type) [@_root_.«ContextProduction».«Dictionary» (leantBound0x0)], (∀ (leantBound1x0 : Type (0 + 1)), (leantBound1x0 → leantBound1x0))))
theorem ProductReplay.passes : ((@ProductReplay.accepted Nat (@ContextProduction.Dictionary.mk Nat 7) (ULift.{1} Nat) (⟨37⟩ : (ULift.{1} Nat))).down = 37) ∧ ((@ProductReplay.accepted Nat (@ContextProduction.Dictionary.mk Nat 11) (ULift.{1} Nat) (⟨53⟩ : (ULift.{1} Nat))).down = 53) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
