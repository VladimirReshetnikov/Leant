"""Verify exact public coverage across one retained timeout and its focused retry."""
from pathlib import Path
import hashlib
import json

ROOT = Path('C:/Leant')
DIST = ROOT / 'dist-newstyle'
NAMES = ['context-selected-polytypes-portable-v1', 'context-selected-polytypes-portable-retry-v1']

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

reports = [json.loads((DIST / n / 'results.json').read_text(encoding='utf-8')) for n in NAMES]
original, retry = reports
assert original['status'] == 'failed' and retry['status'] == 'passed'
assert original['source_hashes'] == retry['source_hashes']
assert original['executable_hashes'] == retry['executable_hashes']
for data in reports:
    assert data['sources_unchanged'] and data['runtimes_unchanged']
    for mapping in (data['source_hashes'], data['executable_hashes']):
        assert all(sha(Path(path)) == digest for path, digest in mapping.items())
failures = [row for row in original['results'] if row['status'] != 'passed']
assert len(original['results']) == 54 and len(failures) == 1 and len(retry['results']) == 3
failure = failures[0]
assert failure['label'] == 'nominal_universe_boxed_strict_quantifier_both_ordinary'
assert failure['failure'].startswith("TimeoutError('owned process exceeded the separate wall-clock guard:")
process = next(p for p in original['processes'] if p['label'] == failure['label'] + '-live')
assert process['timed_out'] and process['process_timeout_seconds'] == 120
assert Path(process['stdout_path']).read_text(encoding='utf-8').rstrip().endswith(
    'preparing synthesis environment (session imports + Lean)...')

specs = {s['label']: {k:v for k,v in s.items() if k != 'oracle_replay'} for s in original['specifications']}
assert all(specs[s['label']] == {k:v for k,v in s.items() if k != 'oracle_replay'} for s in retry['specifications'])
expected = {row['label']: row['command'] for row in original['results']}
coverage = {}
for name, data in zip(NAMES, reports):
    for row in data['results']:
        if row['status'] != 'passed':
            continue
        assert row['command'] == expected[row['label']]
        if row['mode'] != 'false':
            replay = row['replay']
            assert replay['status'] == 'passed'
            assert len(replay['axiom_inventories']) == 2
            assert all(values == [] for values in replay['axiom_inventories'].values())
            assert sha(Path(replay['path'])) == replay['sha256']
        else:
            observations = row['live']['observations']
            assert row['live']['status'] == 'no_candidate'
            assert observations['falsified'] > 0 and observations['passed'] == observations['inconclusive'] == 0
        coverage[row['label']] = dict(receipt=name, mode=row['mode'], engine=row['engine'])
assert set(coverage) == set(expected)
assert sum(r['mode'] == 'false' for r in coverage.values()) == 18
result = dict(status='passed', scope='54 distinct current-source public cells: 36 exact empty-axiom replays and 18 actual-False controls. Original attempt retains one environment-preparation wall-clock timeout; focused three-cell retry uses identical inputs, source/runtime identities and limits.',
    source_and_runtime_hashes_current=True,
    receipts={n: sha(DIST / n / 'results.json') for n in NAMES},
    retained_failure=failure['label'], coverage=coverage,
    verifier_sha256=sha(Path(__file__)))
(DIST / 'selected-public-coverage-v1.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(result['status'], len(coverage), 'distinct accepted cells; one retained timeout')
