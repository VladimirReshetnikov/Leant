"""Freeze and check the first exact nominal universe implementation."""
from pathlib import Path
import json
import os
import re
import subprocess
import sys

ROOT = Path('C:/Leant')
sys.path.insert(0, str(ROOT / 'lib/Djex/test-church'))
import behavior_runtime as rt

OUT = rt.prepare_output_directory(ROOT / 'dist-newstyle/context-selected-polytypes-v3')
files = [Path(__file__).resolve(), ROOT / 'src/Leant/Synth/ContextUniverse.hs',
         ROOT / 'test-unit/ContextUniverseSpec.hs', ROOT / 'test-unit/ContextSelectionSpec.hs']
for repo in [ROOT, ROOT / 'lib/Djex']:
    tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=repo).decode().split('\0')
    files.extend(repo / p for p in tracked if p.endswith(('.hs', '.cabal', '.lean', '.py')) and (repo / p).is_file())
source = {}
for path in files:
    key = path.relative_to(ROOT).as_posix()
    source[key] = rt.sha256(path)
    target = OUT / 'source' / key
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(path.read_bytes())
report = dict(status='running', scope='Source anchored polymorphic selections through expected application positions and local arguments, with exact Pi universe formation and consecutive type-application spine reconstruction; failure-preserving projection work accounting. Focused tests and emitted Lean serializer checking; no public synthesis acceptance yet.',
              source_sha256=source, runtime_sha256={}, gates=[])
runner = rt.Processes(OUT, 2400)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', leant_datadir=str(ROOT), djex_datadir=str(ROOT / 'lib/Djex'))
def save():
    report['processes'] = runner.rows
    rt.write_json(OUT / 'results.json', report)
try:
    save()
    result = runner.run('strict-build', ['cabal', 'build', 'leant:exe:leant', 'leant:test:leant-synth-tests', '--ghc-options=-Werror', '-j1'], cwd=ROOT, env=env)
    report['gates'].append(dict(label='strict-build', exit_code=result.returncode)); save()
    assert result.returncode == 0, 'strict build failed'
    for component in ['leant:exe:leant', 'leant:test:leant-synth-tests']:
        path = Path(subprocess.check_output(['cabal', 'list-bin', component], cwd=ROOT).decode().strip())
        report['runtime_sha256'][str(path)] = rt.sha256(path)
    unit = next(path for path in report['runtime_sha256'] if path.endswith('leant-synth-tests.exe'))
    pattern = '/Source anchored polymorphic selection/ || /Contextual declaration universe selections/ || /Production lexical Given source metadata/ || /direct Lean lexical context rendering/'
    inventory = runner.run('focused-inventory', [unit, '--list-tests', '-p', pattern], cwd=ROOT, env=env)
    names = inventory.stdout.splitlines()
    assert inventory.returncode == 0 and len(names) == 95, 'focused inventory differs'
    report['focused_inventory'] = names
    result = runner.run('focused-units', [unit, '--num-threads', '1', '-p', pattern], cwd=ROOT, env=env)
    report['gates'].append(dict(label='focused-units', exit_code=result.returncode, tests=len(names))); save()
    assert result.returncode == 0 and re.findall(r'All (\d+) tests passed', result.stdout) == ['95'], 'focused tests failed'
    emitted = runner.run('emit-prelude', [unit, '--emit-synthesis-prelude'], cwd=ROOT, env=env)
    assert emitted.returncode == 0
    prelude = OUT / 'NominalUniversePrelude.lean'
    prelude.write_text('import Lean\n' + emitted.stdout, encoding='utf-8')
    kernel = Path('C:/Users/vresh/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean.exe')
    report['runtime_sha256'][str(kernel)] = rt.sha256(kernel)
    result = runner.run('check-prelude', [str(kernel), str(prelude)], cwd=ROOT, env=env)
    report['gates'].append(dict(label='check-prelude', exit_code=result.returncode, source_sha256=rt.sha256(prelude))); save()
    assert result.returncode == 0, 'Lean serializer did not compile'
    report['status'] = 'passed'
except BaseException as failure:
    report.update(status='failed', failure=repr(failure))
finally:
    report['sources_unchanged'] = all(rt.sha256(ROOT / p) == h for p,h in source.items())
    report['runtimes_unchanged'] = all(rt.sha256(Path(p)) == h for p,h in report['runtime_sha256'].items())
    if not report['sources_unchanged'] or not report['runtimes_unchanged']:
        report['status'] = 'failed'
    save()
print(report['status'], report.get('failure', ''), flush=True)
sys.exit(0 if report['status'] == 'passed' else 1)
