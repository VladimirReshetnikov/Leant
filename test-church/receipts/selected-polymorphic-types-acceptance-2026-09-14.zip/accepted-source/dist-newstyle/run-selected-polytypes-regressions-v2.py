"""Run affected contextual public regressions after the universe acceptance gate."""
from pathlib import Path
import json
import os
import sys

ROOT = Path('C:/Leant')
sys.path.insert(0, str(ROOT / 'lib/Djex/test-church'))
import behavior_runtime as rt

parent_path = ROOT / 'dist-newstyle/context-selected-polytypes-v3/results.json'
parent = json.loads(parent_path.read_text(encoding='utf-8'))
assert parent['status'] == 'passed' and parent['sources_unchanged'] and parent['runtimes_unchanged']
assert all(rt.sha256(ROOT / name) == digest for name, digest in parent['source_sha256'].items())
assert all(rt.sha256(Path(name)) == digest for name, digest in parent['runtime_sha256'].items())
OUT = rt.prepare_output_directory(ROOT / 'dist-newstyle/selected-polytypes-regressions-v2')
sources = dict(parent['source_sha256'])
for name in ['dist-newstyle/run-selected-polytypes-regressions-v2.py', 'test-context/run_constructors.py',
             'test-context/run_strict_implicit.py', 'test-context/run_serializer.py', 'test-context/run_context_universes.py', 'test-context/run_polymorphic_selection.py', 'test-unit/ContextSelectionSpec.hs']:
    sources[name] = rt.sha256(ROOT / name)
    target = OUT / 'source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())
report = dict(status='running', parent_sha256=rt.sha256(parent_path), source_sha256=sources,
              runtime_sha256=parent['runtime_sha256'], gates=[])
runner = rt.Processes(OUT, 2400)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', leant_datadir=str(ROOT), djex_datadir=str(ROOT / 'lib/Djex'))
exe = next(name for name in parent['runtime_sha256'] if name.endswith('leant.exe'))

def save():
    report['processes'] = runner.rows
    rt.write_json(OUT / 'results.json', report)

try:
    save()
    for label, script, count in [('universes', 'run_context_universes.py', 63), ('constructors', 'run_constructors.py', 27), ('strict-binders', 'run_strict_implicit.py', 15)]:
        result = runner.run(label, [sys.executable, '-X', 'utf8', '-B', 'test-context/' + script,
                                   '--leant', exe, '--output', str(OUT / label)], cwd=ROOT, env=env)
        path = OUT / label / 'results.json'
        data = json.loads(path.read_text(encoding='utf-8'))
        report['gates'].append(dict(label=label, exit_code=result.returncode, receipt_sha256=rt.sha256(path), cells=len(data['results'])))
        save()
        assert result.returncode == 0 and data['status'] == 'passed' and len(data['results']) == count, label + ' regression'
        if label == 'universes':
            assert all(row['status'] == 'passed' for row in data['results'])
            assert data['sources_unchanged'] and data['runtimes_unchanged']
        else:
            assert all(row['status'] in {'candidate', 'no_candidate'} for row in data['results'])
            assert data['source_and_input_hashes_unchanged'] and data['exact_replay_sources_unchanged']
    report['status'] = 'passed'
except BaseException as failure:
    report.update(status='failed', failure=repr(failure))
finally:
    report['sources_unchanged'] = all(rt.sha256(ROOT / name) == digest for name, digest in sources.items())
    report['runtimes_unchanged'] = all(rt.sha256(Path(name)) == digest for name, digest in report['runtime_sha256'].items())
    if not report['sources_unchanged'] or not report['runtimes_unchanged']:
        report['status'] = 'failed'
    save()
print(report['status'], report.get('failure', ''), flush=True)
sys.exit(0 if report['status'] == 'passed' else 1)
