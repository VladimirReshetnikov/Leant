set_option autoImplicit false
namespace BehaviorPartialNumeric
def intCase : ∀ R : Type, Int → R → R → (Int → R) → R := fun _ n negative zero positive => if n < 0 then negative else if n = 0 then zero else positive (n - 1)
end BehaviorPartialNumeric
theorem BehaviorPartialNumeric.integer_branches : (BehaviorPartialNumeric.intCase Int (-3) (-71) 23 (fun p => p+101) = -71) ∧ (BehaviorPartialNumeric.intCase Int (-1) (-71) 23 (fun p => p+101) = -71) ∧ (BehaviorPartialNumeric.intCase Int (0) (-71) 23 (fun p => p+101) = 23) ∧ (BehaviorPartialNumeric.intCase Int (1) (-71) 23 (fun p => p+101) = 101) ∧ (BehaviorPartialNumeric.intCase Int (4) (-71) 23 (fun p => p+101) = 104) := by decide
theorem BehaviorPartialNumeric.boolean_branches : (BehaviorPartialNumeric.intCase Bool (-1) false true (fun p => p == 0) = false) ∧ (BehaviorPartialNumeric.intCase Bool 0 false true (fun p => p == 0) = true) ∧ (BehaviorPartialNumeric.intCase Bool 1 false true (fun p => p == 0) = true) ∧ (BehaviorPartialNumeric.intCase Bool 2 false true (fun p => p == 0) = false) := by decide
#print axioms BehaviorPartialNumeric.intCase
#print axioms BehaviorPartialNumeric.integer_branches
#print axioms BehaviorPartialNumeric.boolean_branches
