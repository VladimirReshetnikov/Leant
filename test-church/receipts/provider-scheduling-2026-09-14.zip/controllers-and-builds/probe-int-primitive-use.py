"""Isolate live use of the existing generic Int provider, without a Church fold.
This is a prerequisite diagnostic, never acceptance of original integer at.
"""
from pathlib import Path
import json,os,sys,re
ROOT=Path('C:/Leant');sys.path[:0]=[str(ROOT/'test-church'),'C:/Djex/test-church']
import behavior_runtime as rt
from behavior_probe import parse_output
from run_corpus import reported_axioms
base=ROOT/'dist-newstyle/priority3-native-int-at-baseline-v1'
pins=json.loads((base/'results.json').read_text())['runtime_identity']
out=rt.prepare_output_directory(ROOT/'dist-newstyle/priority3-int-primitive-use-v1')
original=(base/'partial_exference_at.txt').read_text(encoding='utf-8')
prefix=original.split(':synth partial_exference_at :',1)[0]
declaration=prefix[prefix.index('namespace BehaviorPartialNumeric'):].strip()
name='primitive_use'
signature='∀ R : Type, Int → R → R → (Int → R) → R'
predicate=' ∧ '.join([
    '{f} Nat (-2) 7 11 (fun k => k.toNat + 20) = 7',
    '{f} Nat 0 7 11 (fun k => k.toNat + 20) = 11',
    '{f} Nat 1 7 11 (fun k => k.toNat + 20) = 20',
    '{f} Nat 3 7 11 (fun k => k.toNat + 20) = 22',
    '{f} Bool (-2) false true (fun k => decide (k = 1)) = false',
    '{f} Bool 0 false true (fun k => decide (k = 1)) = true',
    '{f} Bool 2 false true (fun k => decide (k = 1)) = true'])
command=f':synth {name} : ({signature}) where '+predicate.replace('{f}',name)
source=prefix+command+'\n:quit\n'
runner=rt.Processes(out,300)
sources={str(p):rt.sha256(p) for p in (ROOT/'src').rglob('*.hs')}
for path in sources:
    p=Path(path);target=out/'source'/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
runtimes={pins[k]:rt.sha256(Path(pins[k])) for k in ['leant','backend','backend_lake_runtime','kernel_runtime']}
report=dict(status='running',scope=__doc__,acceptance_of_original_at=False,original_input_sha256=rt.sha256(base/'partial_exference_at.txt'),source_hashes=sources,executable_hashes=runtimes,runtime_identity=pins)
def save():
    report['processes']=runner.rows;rt.write_json(out/'results.json',report)
try:
    save()
    live=runner.run('primitive-use',[pins['leant'],'--plain','--lake',pins['backend_lake_runtime']],source=source,cwd=ROOT,env=dict(os.environ,LEANT_BACKEND=pins['backend']))
    assert live.returncode==0
    text=live.stdout+live.stderr
    report['provider_names']=re.findall(r'^debug provider: .*?providerLeanName = "([^"]+)"',text,re.M)
    assert report['provider_names']==['BehaviorPartialNumeric.intCase']
    parsed=parse_output(text,[dict(name=name,command=command,type=signature,expected='candidate')])[0]
    report['candidate']=parsed['candidate'];report['observations']=parsed['observations'];save()
    candidate='PrimitiveUse.candidate';proof='PrimitiveUse.passes'
    path=out/'PrimitiveUse.lean'
    path.write_text('set_option autoImplicit false\n'+declaration+f'\ndef {candidate} : ({signature}) :=\n'+parsed['candidate']+f'\ntheorem {proof} : '+predicate.replace('{f}',candidate)+f' := by decide\n#print axioms {candidate}\n#print axioms {proof}\n',encoding='utf-8')
    checked=runner.run('kernel-replay',[pins['kernel_runtime'],path],cwd=ROOT)
    inventories={n:reported_axioms(checked.stdout+checked.stderr,n) for n in [candidate,proof]}
    assert checked.returncode==0 and all(v==set() for v in inventories.values())
    report['axiom_inventories']={n:sorted(v) for n,v in inventories.items()};report['status']='passed'
except BaseException as error:
    report.update(status='failed',failure=repr(error))
finally:
    report['sources_unchanged']=all(rt.sha256(Path(p))==h for p,h in sources.items())
    report['runtimes_unchanged']=all(rt.sha256(Path(p))==h for p,h in runtimes.items())
    if not report['sources_unchanged'] or not report['runtimes_unchanged']:report['status']='failed'
    save()
print(report['status'],report.get('failure',''),flush=True)
sys.exit(0 if report['status']=='passed' else 1)
