from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path('C:/Leant')
OTHER = Path('C:/Djex')
D = ROOT / 'dist-newstyle'
sha = lambda data: hashlib.sha256(data).hexdigest()
folders = [
    'provider-scheduling-public-v1', 'provider-scheduling-public-v2',
    'provider-scheduling-public-v3', 'provider-scheduling-dictionary-v1',
    'priority3-native-int-at-scheduled-v1', 'priority3-native-int-at-scheduled-v2',
    'priority3-int-primitive-use-v1', 'priority3-predicate-elaboration-v1',
]
reports = {name: json.loads((D / name / 'results.json').read_text()) for name in folders}
members = {}

def put(name, data):
    if name in members:
        assert members[name] == data, name
    members[name] = data

for name, report in reports.items():
    assert report['status'] in ('passed', 'failed'), name
    for p in sorted((D / name).rglob('*')):
        if p.is_file() and p.suffix.lower() not in ('.exe', '.dll', '.o', '.hi', '.pyc'):
            put('runs/' + name + '/' + p.relative_to(D / name).as_posix(), p.read_bytes())

final_names = ['provider-scheduling-public-v3', 'provider-scheduling-dictionary-v1',
               'priority3-native-int-at-scheduled-v2', 'priority3-int-primitive-use-v1']
for name in final_names:
    r = reports[name]
    if name != 'priority3-native-int-at-scheduled-v2':
        assert r['status'] == 'passed', name
    for field in ('sources_unchanged', 'executables_unchanged', 'runtimes_unchanged'):
        if field in r:
            assert r[field], (name, field)
    for source, digest in r.get('source_hashes', {}).items():
        p = Path(source)
        data = p.read_bytes()
        assert sha(data) == digest, (name, source)
        if p.is_relative_to(ROOT):
            target = 'Leant/' + p.relative_to(ROOT).as_posix()
        elif p.is_relative_to(OTHER):
            target = 'Djex/' + p.relative_to(OTHER).as_posix()
        else:
            target = 'external/' + p.name
        put('final-source/' + target, data)
    for source, digest in r.get('executable_hashes', {}).items():
        assert sha(Path(source).read_bytes()) == digest, (name, source)

public = reports['provider-scheduling-public-v3']['cells']
assert len(public) == 15 and all(c['status'] == 'passed' for c in public)
assert sum('candidate' in c for c in public) == 9
dictionary = reports['provider-scheduling-dictionary-v1']['results']
assert len(dictionary) == 3 and all(c['status'] == 'passed' for c in dictionary)
assert reports['priority3-native-int-at-scheduled-v2']['candidate_count'] == 0

# The first scheduling implementation is retained by its public source snapshots.
for name in ['priority3-native-int-at-scheduled-v1', 'provider-scheduling-public-v1',
             'provider-scheduling-public-v2']:
    for source, digest in reports[name].get('source_hashes', {}).items():
        p = Path(source)
        if p == ROOT / 'src/Main.hs':
            data = (D / 'provider-scheduling-public-v2/source/src/Main.hs').read_bytes()
        elif p == ROOT / 'test-behavioral/run_provider_scheduling.py':
            data = (D / name / 'source/test-behavioral/run_provider_scheduling.py').read_bytes()
        else:
            data = p.read_bytes()
        assert sha(data) == digest, (name, source)

for name in ['provider-scheduling-build-v1.log', 'provider-scheduling-build-v2.log',
             'probe-int-primitive-use.py', 'probe-predicate-elaboration.py']:
    put('controllers-and-builds/' + name, (D / name).read_bytes())
put('controllers-and-builds/package-provider-scheduling.py', Path(__file__).read_bytes())
put('INTERPRETATION.md', b'''# Evidence boundaries

Final product source: provider-scheduling-public-v3 and dictionary-v1.
15 scheduling cells plus 3 dictionary cells: 11 exact positive Lean replays,
7 actual-False controls. No fresh full native unit-suite claim.
Public-v1 failed because its draft positive fixture's verification allowance was
too small. Public-v2 passed on the earlier scheduler. Public-v3 is final.
The original 168-observation source-Int/default indexing query still fails on
Exference. Scheduled-v1 includes 270 no-time callback attempts; scheduled-v2
has zero such attempts, three actual timeouts, and no matching candidate.
The small integer-case diagnostic synthesizes structural case analysis; its
candidate does not call the supplied intCase provider. It proves neither
provider use nor Church indexing.
The shared-predicate timing experiment fails to synthesize Decidable instances
and its rejection theorems depend on sorryAx. Its runtime is not a speedup.
Compiled binaries are identified by hashes, not bundled.
''')
base = 'provider-scheduling-2026-09-14'
archive = ROOT / 'test-church/receipts' / (base + '.zip')
assert not archive.exists(), archive
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(members.items()):
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(members)
    for name, data in members.items():
        assert z.read(name) == data, name
index = dict(
    scope='Cooperative native provider scheduling and deadline admission accepted; original Int indexing remains open.',
    archive=archive.name, archive_sha256=sha(archive.read_bytes()),
    archive_bytes=archive.stat().st_size, member_count=len(members),
    acceptance=dict(public_cells=18, exact_lean_replays=11, actual_false_controls=7,
                    fresh_full_native_suite=False, indexing_candidates_accepted=0),
    runs=[dict(directory=n, status=reports[n]['status'],
               receipt_sha256=sha((D/n/'results.json').read_bytes())) for n in folders],
    members=[dict(path=n, sha256=sha(b), bytes=len(b)) for n, b in sorted(members.items())])
for root in [ROOT, OTHER]:
    target = root / 'test-church/receipts' / archive.name
    if root != ROOT:
        assert not target.exists(), target
        target.write_bytes(archive.read_bytes())
    destination = target.with_suffix('.json')
    assert not destination.exists(), destination
    destination.write_text(json.dumps(index, indent=2) + '\n', encoding='utf-8')
print({k: index[k] for k in ['archive_sha256', 'archive_bytes', 'member_count']})
