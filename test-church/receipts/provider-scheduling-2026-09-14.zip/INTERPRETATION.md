# Evidence boundaries

Final product source: provider-scheduling-public-v3 and dictionary-v1.
15 scheduling cells plus 3 dictionary cells: 11 exact positive Lean replays,
7 actual-False controls. No fresh full native unit-suite claim.
Public-v1 failed because its draft positive fixture's verification allowance was
too small. Public-v2 passed on the earlier scheduler. Public-v3 is final.
The original 168-observation source-Int/default indexing query still fails on
Exference. Scheduled-v1 includes 270 no-time callback attempts; scheduled-v2
has zero such attempts, three actual timeouts, and no matching candidate.
The small integer-case diagnostic synthesizes structural case analysis; its
candidate does not call the supplied intCase provider. It proves neither
provider use nor Church indexing.
The shared-predicate timing experiment fails to synthesize Decidable instances
and its rejection theorems depend on sorryAx. Its runtime is not a speedup.
Compiled binaries are identified by hashes, not bundled.
