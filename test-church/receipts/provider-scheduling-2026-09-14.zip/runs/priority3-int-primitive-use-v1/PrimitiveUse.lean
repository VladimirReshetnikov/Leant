set_option autoImplicit false
namespace BehaviorPartialNumeric
def intCase : ∀ R : Type, Int → R → R → (Int → R) → R := fun _ n negative zero positive => if n < 0 then negative else if n = 0 then zero else positive (n - 1)
end BehaviorPartialNumeric
def PrimitiveUse.candidate : (∀ R : Type, Int → R → R → (Int → R) → R) :=
fun _ x y z f => match x with | .ofNat w => (match w with | .zero => z | .succ x1 => f (.ofNat x1)) | .negSucc _ => y
theorem PrimitiveUse.passes : PrimitiveUse.candidate Nat (-2) 7 11 (fun k => k.toNat + 20) = 7 ∧ PrimitiveUse.candidate Nat 0 7 11 (fun k => k.toNat + 20) = 11 ∧ PrimitiveUse.candidate Nat 1 7 11 (fun k => k.toNat + 20) = 20 ∧ PrimitiveUse.candidate Nat 3 7 11 (fun k => k.toNat + 20) = 22 ∧ PrimitiveUse.candidate Bool (-2) false true (fun k => decide (k = 1)) = false ∧ PrimitiveUse.candidate Bool 0 false true (fun k => decide (k = 1)) = true ∧ PrimitiveUse.candidate Bool 2 false true (fun k => decide (k = 1)) = true := by decide
#print axioms PrimitiveUse.candidate
#print axioms PrimitiveUse.passes
