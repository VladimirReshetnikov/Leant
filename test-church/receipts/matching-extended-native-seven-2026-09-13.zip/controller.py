"""Frozen remaining extended Church behavior batch after matching-mode acceptance."""
from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path('C:/Leant-validation/trailing-type-witness')
OUT=ROOT/'dist-newstyle/matching-extended-native-v2'
sys.path.insert(0,str(ROOT/'lib/Djex/test-church'))
import behavior_runtime as runtime
assert json.loads((ROOT/'dist-newstyle/trailing-type-witness-isolated-v2/results.json').read_text())['status']=='passed'
assert json.loads((ROOT/'dist-newstyle/matching-extended-native-v1/snapshot.json').read_text())['status']=='passed'
OUT.mkdir(parents=True,exist_ok=False)
report={'status':'running','source_base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
 'published_renderer_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd='C:/Leant').decode().strip(),
 'dependency_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT/'lib/Djex').decode().strip(),
 'source_hashes':{}}
# The two isolated source deltas must be exactly the published code and tests.
for name in ['src/Leant/Synth/Render.hs','test-unit/Spec.hs']:
 published=subprocess.check_output(['git','show','HEAD:'+name],cwd='C:/Leant')
 assert published.replace(b'\r\n',b'\n')==(ROOT/name).read_bytes().replace(b'\r\n',b'\n'),name
assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT/'lib/Djex')==b''
for repo,prefix in [(ROOT,''),(ROOT/'lib/Djex','lib/Djex/')]:
 for name in subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0'):
  path=repo/name
  if not name or not path.is_file() or '/receipts/' in name:continue
  if path.suffix not in ['.hs','.lhs','.py','.lean','.cabal'] and name not in ['cabal.project','lean-toolchain']:continue
  relative=prefix+name;report['source_hashes'][relative]=runtime.sha256(path)
  target=OUT/'source'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(path.read_bytes())
(OUT/'change.diff').write_bytes(subprocess.check_output(['git','diff','HEAD'],cwd=ROOT))
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
exe=ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/x/leant/build/leant/leant.exe'
kernel=Path('C:/Users/vresh/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean.exe')
backend=Path('C:/Users/vresh/AppData/Local/Python/pythoncore-3.14-64/Lib/site-packages/lean_interact/cache/augustepoiroux/repl/repl_v1.3.18_lean-toolchain-v4.32.0/.lake/build/bin/repl.exe')
report['runtime_hashes']={str(p):runtime.sha256(p) for p in [exe,kernel,backend]}
processes=runtime.Processes(OUT,9000)
def save():
 report['processes']=processes.rows;runtime.write_json(OUT/'snapshot.json',report)
save()
command=[sys.executable,'-X','utf8','-B','test-church/behavior_extended_probe.py','--leant',str(exe),'--spec-dir',str(ROOT/'lib/Djex/test-church'),'--output',str(OUT/'run'),
 '--lean',str(kernel),'--lean-runtime',str(kernel),'--backend',str(backend),'--toolchain','',
 '--engine','djinn','--engine','both','--window','65536','--budget','500000','--steps','100000','--djinn-strategy','interleave','--timeout','90','--process-timeout','900']
for operation in ['foldr','foldl','length','listToMaybe','catMaybes','squashMaybe','maybeEither']:command.extend(['--operation',operation])
try:
 result=processes.run('matching-extended',command,cwd=ROOT)
 report['status']='passed' if result.returncode==0 else 'failed'
finally:
 report['sources_unchanged']=all(runtime.sha256(ROOT/n)==h for n,h in report['source_hashes'].items())
 report['runtimes_unchanged']=all(runtime.sha256(Path(n))==h for n,h in report['runtime_hashes'].items())
 report['controller_unchanged']=(OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
 if not all(report[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged']):report['status']='failed'
 save()
print(report['status'],flush=True)
sys.exit(0 if report['status']=='passed' else 1)
