from pathlib import Path
import hashlib,json,zipfile
ROOT=Path('C:/Leant')
CHECKOUT=Path('C:/Leant-validation/trailing-type-witness')
OUT=CHECKOUT/'dist-newstyle/matching-extended-native-v2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
snapshot=read(OUT/'snapshot.json'); data=read(OUT/'run/results.json')
assert snapshot['status']=='failed'
assert all(snapshot[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged'])
assert data['status']=='failed' and data['candidate_count']==12 and data['false_control_count']==2
assert data['sources_unchanged'] and data['executables_unchanged']
for name,value in snapshot['source_hashes'].items():assert sha(CHECKOUT/name)==value,name
for name,value in snapshot['runtime_hashes'].items():assert sha(Path(name))==value,name
for pins in [data['source_hashes'],data['executable_hashes']]:
 for name,value in pins.items():assert sha(Path(name))==value,name
assert (OUT/'controller.py').read_bytes()==(ROOT/'dist-newstyle/run-matching-extended-native-v2.py').read_bytes()
operations={'foldr':400,'foldl':400,'length':44,'listToMaybe':44,'catMaybes':40,'squashMaybe':8,'maybeEither':7}
expected={(engine,op) for engine in ['djinn','both'] for op in operations}
assert {(r['engine'],r['operation']) for r in data['cells'] if r['operation']!='reject_all'}==expected
assert len(data['cells'])==16
assert {(r['engine'],r['operation']) for r in data['cells'] if r['status']=='failed'}=={('djinn','length'),('djinn','maybeEither')}
assert all(r['exit_code']==0 and not r['timed_out'] for r in data['processes'])
false={}; empty_inventories=0
for row in data['cells']:
 if row['status']=='failed':
  assert row['exit_code']==0 and row['runtime_hashes_unchanged']
  continue
 assert row['status']=='passed'
 observations=row['live_outcome']['observations']
 if row['operation']=='reject_all':
  assert observations['passed']==0 and observations['falsified']>0 and observations['inconclusive']==0
  false[row['engine']]=observations['falsified']
 else:
  assert row['finite_observation_count']==operations[row['operation']]
  assert row['actual_provider_inventory']['count']==0
  replay=row['replay'];assert replay['status']=='passed' and replay['exit_code']==0
  assert replay['kernel_runtime_unchanged'] and replay['source_unchanged']
  assert replay['actual_axiom_inventories']==replay['expected_axiom_inventories']
  assert replay['actual_axiom_inventories']['BehaviorExtendedReplay.candidate']==[]
  for name,axioms in replay['actual_axiom_inventories'].items():
   assert axioms==(['propext'] if row['operation']=='maybeEither' and name=='BehaviorExtendedReplay.candidate_passes_original_oracle' else [])
   empty_inventories+=int(not axioms)
  if row['operation']=='length':
   assert row['numeric_source_route']['route']=='native_constructor_baseline'
oracle=data['oracle_controls'];assert oracle['status']=='passed' and oracle['exit_code']==0
assert oracle['actual_axiom_inventories']==oracle['expected_axiom_inventories']
assert oracle['positive_controls']==13 and oracle['fully_typed_wrong_controls']==14 and oracle['specialized_adapter_controls']==1
diagnoses=[]
for operation,classification in [('length','command_deadline_before_provider_discovery'),('maybeEither','choice_point_limit_with_verification_and_source_graph_failures')]:
 path=OUT/'run'/('extended_djinn_'+operation+'.stdout.txt');output=path.read_text()
 if operation=='length':
  assert 'the engine did not finish within 90s' in output and '0 passed, 37 falsified, 0 inconclusive' in output
  assert 'debug provider:' not in output
 else:
  assert 'choice-point limit reached' in output and '0 passed, 288 falsified, 0 inconclusive' in output
  assert 'source-graph-absent.djinn.source-typing-failure=1' in output
 diagnoses.append({'engine':'djinn','operation':operation,'classification':classification,'capture_member':path.relative_to(OUT).as_posix(),'capture_sha256':sha(path)})
(OUT/'diagnoses.json').write_text(json.dumps(diagnoses,indent=2)+'\n',encoding='utf-8')
(OUT/'packager.py').write_bytes(Path(__file__).read_bytes())
manifest={};omitted={}
for p in sorted(OUT.rglob('*')):
 if not p.is_file():continue
 name=p.relative_to(OUT).as_posix();entry={'sha256':sha(p),'bytes':p.stat().st_size}
 if p.suffix in ['.exe','.o','.hi','.dyn_o','.dyn_hi','.olean','.ilean']:omitted[name]=entry
 else:manifest[name]=entry
archive=ROOT/'test-church/receipts/matching-extended-native-seven-2026-09-13.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in manifest:z.write(OUT/name,name)
 z.writestr('archive-manifest.json',json.dumps({'artifacts':manifest,'omitted_build_products':omitted},indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(manifest)|{'archive-manifest.json'}
 for name,expected in manifest.items():
  raw=z.read(name);assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256']
receipt={'schema':'leant-matching-extended-seven-v1','status':'completed_with_two_djinn_misses','scope':'Seven extended operations in Lean Djinn and Both: twelve accepted cells and two retained failures at original settings.',
 'published_renderer_commit':snapshot['published_renderer_commit'],'source_base_commit':snapshot['source_base_commit'],'dependency_commit':snapshot['dependency_commit'],
 'diagnoses':diagnoses,'counts':{'attempted_behavior_cells':14,'accepted_behavior_cells':12,'failed_behavior_cells':2,'exact_candidate_replays':12,'actual_false_queries':2,'false_falsifications_by_engine':false,'finite_observations_in_fixture_per_engine':sum(operations.values()),'finite_observations_on_accepted_cells':sum(operations[r['operation']] for r in data['cells'] if r['status']=='passed' and r['operation']!='reject_all'),'finite_observations_by_operation':operations,
 'positive_oracle_controls':13,'fully_typed_wrong_oracle_controls':14,'specialized_adapter_controls':1,'empty_candidate_replay_inventories':empty_inventories,'owned_query_and_kernel_processes':len(data['processes']),'frozen_source_files':len(snapshot['source_hashes'])},
 'settings':data['settings'],'sources_and_runtimes_unchanged':True,'all_query_and_kernel_processes_exit_zero':True,'parent_acceptance_exit_code':1,'raw_receipt_member':'run/results.json',
 'archive':{'path':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'artifact_count':len(manifest),'all_members_rehashed':True},
 'boundaries':['This batch adds finite behavioral acceptance for its twelve operation/mode cells; it is not a current-revision replay of all 160 target cells.', 'The published renderer and tests are checked against the isolated source before execution. No source change or rebuild is claimed in this batch.', 'All synthesized implementations have empty inventories; only the exact maybeEither oracle proof has propext. Oracle controls retain their separately checked declared inventories.', 'Reference implementations and prior synthesized declarations do not enter the live search sessions.', 'Contextual-constructor changes and dependency promotion are outside this acceptance.']}
archive.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':receipt['status'],'counts':receipt['counts'],'archive':receipt['archive']},indent=2))
