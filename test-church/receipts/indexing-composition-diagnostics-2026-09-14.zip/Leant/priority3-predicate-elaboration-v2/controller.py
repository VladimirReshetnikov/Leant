"""Compare repeated elaboration of the exact original at predicate with a shared
checked predicate definition. Diagnostic only: fixed deliberately wrong candidate,
no synthesis and no production cache implementation. The shared definition is
explicitly unfolded before decidability synthesis; both variants must pass exact
kernel and empty-axiom checks before any timing comparison is valid.
"""
from pathlib import Path
import json,sys
ROOT=Path('C:/Leant');sys.path[:0]=[str(ROOT/'test-church'),'C:/Djex/test-church']
import behavior_runtime as rt
from run_corpus import reported_axioms
base=ROOT/'dist-newstyle/priority3-native-int-at-baseline-v1'
pins=json.loads((base/'results.json').read_text())['runtime_identity']
out=rt.prepare_output_directory(ROOT/'dist-newstyle/priority3-predicate-elaboration-v2')
original=(base/'partial_exference_at.txt').read_text(encoding='utf-8')
command=next(line for line in original.splitlines() if line.startswith(':synth partial_exference_at : '))
typed,predicate=command.split(' where ',1);signature=typed.removeprefix(':synth partial_exference_at : ')
repeats=8
common='set_option autoImplicit false\nset_option linter.unusedVariables false\n'
common+='def bad : '+signature+' := fun _ d _ _ => d\n'
runner=rt.Processes(out,180)
report=dict(status='running',scope=__doc__,repetitions=repeats,original_input_sha256=rt.sha256(base/'partial_exference_at.txt'),kernel=pins['kernel_runtime'],kernel_sha256=rt.sha256(Path(pins['kernel_runtime'])),cells=[])
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
def save():
    report['processes']=runner.rows;rt.write_json(out/'results.json',report)
try:
    save()
    for label in ['inline','shared']:
        body=common
        if label=='shared':body+='def Wanted (partial_exference_at : '+signature+') : Prop := '+predicate+'\n'
        names=['bad']
        for n in range(repeats):
            name='rejected'+str(n);names.append(name)
            proposition='Wanted bad' if label=='shared' else 'let partial_exference_at : '+signature+' := bad; '+predicate
            proof='by unfold Wanted; decide' if label=='shared' else 'by decide'
            body+='theorem '+name+' : ¬ ('+proposition+') := '+proof+'\n'
        body+='\n'.join('#print axioms '+n for n in names)+'\n'
        path=out/(label+'.lean');path.write_text(body,encoding='utf-8')
        result=runner.run(label,[pins['kernel_runtime'],path],cwd=ROOT)
        inventories={n:reported_axioms(result.stdout+result.stderr,n) for n in names}
        ok=result.returncode==0 and all(v==set() for v in inventories.values())
        report['cells'].append(dict(name=label,status='passed' if ok else 'failed',source_sha256=rt.sha256(path),wall_seconds=runner.rows[-1]['wall_seconds'],axiom_inventories={n:None if v is None else sorted(v) for n,v in inventories.items()}));save()
        assert ok,label+' kernel check failed'
    report['status']='passed'
except BaseException as error:
    report.update(status='failed',failure=repr(error))
finally:
    report['kernel_unchanged']=rt.sha256(Path(pins['kernel_runtime']))==report['kernel_sha256']
    if not report['kernel_unchanged']:report['status']='failed'
    save()
print(report['status'],[(r['name'],r['wall_seconds']) for r in report['cells']],flush=True)
sys.exit(0 if report['status']=='passed' else 1)
