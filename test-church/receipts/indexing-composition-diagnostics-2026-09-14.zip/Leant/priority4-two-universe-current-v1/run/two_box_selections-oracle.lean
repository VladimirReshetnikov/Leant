set_option autoImplicit false
class SelectedPoly.Dictionary (α : Type) where tag : Nat
structure SelectedPoly.Box (α : Type 1) where value : α
universe u
structure SelectedPoly.GenericBox (α : Type u) where value : α
def ProductReplay.accepted : ∀ A : Type, [SelectedPoly.Dictionary A] → Nat → ULift.{1} Nat → SelectedPoly.GenericBox.{0} Nat × SelectedPoly.GenericBox.{1} (ULift.{1} Nat) :=
fun (A : Type) [d : SelectedPoly.Dictionary A] low high => (⟨low⟩, ⟨high⟩)
theorem ProductReplay.passes : let pair := @ProductReplay.accepted Nat (@SelectedPoly.Dictionary.mk Nat 7) 37 ⟨53⟩; pair.1.value = 37 ∧ pair.2.value.down = 53 := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
