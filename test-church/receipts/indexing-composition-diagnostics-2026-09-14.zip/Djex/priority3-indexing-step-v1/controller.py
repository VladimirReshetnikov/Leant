"""Isolate construction of the Int-indexed Church fold step; diagnostic only."""
from pathlib import Path
import json,re,sys
from types import SimpleNamespace
ROOT=Path('C:/Djex');sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as rt
from behavior_probe import behavioral_observations
from behavior_partial_probe import observed_inventory,validate_cell_settings
parent=ROOT/'dist-newstyle/priority3-haskell-int-at-current-v1'
gate=json.loads((parent/'results.json').read_text())
original=json.loads((parent/'run/results.json').read_text())
exe=next(path for path in gate['runtime_sha256'] if path.endswith('djex.exe'))
name='indexing_step'
signature='forall a. a -> a -> (Int -> a) -> Int -> a'
observations=[f'{name} @Int 37 53 (\\i -> 100 + i) ({n}) == {v}'
              for n,v in [(-3,37),(-1,37),(0,53),(1,100),(2,101),(4,103)]]
observations += [f'{name} @Bool True False (\\_ -> True) ({n}) == {v}'
                 for n,v in [(-2,'True'),(0,'False'),(1,'True'),(3,'True')]]
predicate=' && '.join('('+p+')' for p in observations)
lines=(parent/'run/exference-at.commands.txt').read_text().splitlines()
source='\n'.join(':synth '+name+' :: '+signature+' where '+predicate
                if line.startswith(':synth partial_exference_at :: ') else line for line in lines)+'\n'
out=rt.prepare_output_directory(ROOT/'dist-newstyle/priority3-indexing-step-v1')
runner=rt.Processes(out,300)
sources=dict(gate['source_sha256']);sources.update(original['source_hashes'])
sources[str(Path(__file__).relative_to(ROOT))]=rt.sha256(Path(__file__))
def stable():
    return all(rt.sha256(ROOT/p)==h for p,h in sources.items()) and all(rt.sha256(Path(p))==h for p,h in gate['runtime_sha256'].items())
report=dict(status='running',scope=__doc__,source_type=signature,observations=observations,
            source_sha256=sources,runtime_sha256=gate['runtime_sha256'],original_at_accepted=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
def save():
    report['processes']=runner.rows;rt.write_json(out/'results.json',report)
try:
    assert stable();save()
    result=runner.run('step',[exe,'repl','--ignore-startup','--environment',parent/'run/empty-environment'],source=source,cwd=ROOT)
    assert result.returncode==0
    transcript=result.stdout+result.stderr
    assert not re.search(r'error \[DJEX_',transcript),transcript
    report['settings']=validate_cell_settings(transcript,'exference','at',SimpleNamespace(**original['settings']['exference']))
    report['inventory']=observed_inventory(transcript,'exference','at')
    report['behavioral_observations']=behavioral_observations(transcript,expect_success=True,window=256)
    assert re.search(r'^indexing_step[^\n]*=',result.stdout,re.M)
    report['status']='passed'
except BaseException as failure:
    report.update(status='failed',failure=repr(failure))
finally:
    report['sources_and_runtimes_unchanged']=stable()
    if not report['sources_and_runtimes_unchanged']:report['status']='failed'
    save()
print(report['status'],report.get('failure',''),flush=True)
sys.exit(0 if report['status']=='passed' else 1)
