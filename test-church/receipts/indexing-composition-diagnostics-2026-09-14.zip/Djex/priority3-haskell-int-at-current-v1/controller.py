from pathlib import Path
import json
import sys

ROOT = Path('C:/Djex')
sys.path.insert(0, str(ROOT / 'test-church'))
import behavior_runtime as rt

parent_path = ROOT / 'dist-newstyle/provider-kind-composition-public-v1/results.json'
parent = json.loads(parent_path.read_text(encoding='utf-8'))
assert parent['status'] == 'passed' and parent['sources_unchanged'] and parent['runtimes_unchanged']
sources = dict(parent['source_sha256'])
sources[str(Path(__file__).relative_to(ROOT))] = rt.sha256(Path(__file__))
runtimes = parent['runtime_sha256']
def stable():
    return (all(rt.sha256(ROOT / path) == digest for path, digest in sources.items())
            and all(rt.sha256(Path(path)) == digest for path, digest in runtimes.items()))
assert stable()
exe = next(path for path in runtimes if path.endswith('djex.exe'))
out = rt.prepare_output_directory(ROOT / 'dist-newstyle/priority3-haskell-int-at-current-v1')
runner = rt.Processes(out, 900)
report = dict(status='running', scope='Original Exference supplied-default Int-at query at unchanged public runner limits; independent oracle, exact replay and False controls.',
              parent_sha256=rt.sha256(parent_path), source_sha256=sources, runtime_sha256=runtimes)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
def save():
    report['processes'] = runner.rows
    rt.write_json(out / 'results.json', report)
try:
    save()
    result = runner.run('original-exference-at', [sys.executable, '-X', 'utf8', '-B',
        'test-church/behavior_partial_probe.py', '--djex', exe, '--output', out / 'run',
        '--engine', 'exference', '--operation', 'at', '--observe-latency'], cwd=ROOT)
    child_path = out / 'run/results.json'
    child = json.loads(child_path.read_text(encoding='utf-8'))
    report.update(status=child['status'], child_sha256=rt.sha256(child_path),
                  accepted=child['accepted'], failed_synthesis_cells=child['failed_synthesis_cells'])
    if result.returncode != 0:
        report['status'] = 'failed'
except BaseException as failure:
    report.update(status='failed', failure=repr(failure))
finally:
    report['sources_and_runtimes_unchanged'] = stable()
    if not report['sources_and_runtimes_unchanged']:
        report['status'] = 'failed'
    save()
print(report['status'], report.get('failed_synthesis_cells'), flush=True)
sys.exit(0 if report['status'] == 'passed' else 1)
