{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Main (main) where
import Prelude
import qualified Prelude
import PartialNumeric (partialIntCase)
import qualified Control.Exception as E
import qualified System.Timeout as T
import qualified System.Exit as Exit
main :: IO ()
main = do
  outcome <- T.timeout 2000000 (E.try (E.evaluate (Prelude.and [(partialIntCase @Prelude.Int (-3) (-71) 23 (\p -> p+101) == -71),(partialIntCase @Prelude.Int (-1) (-71) 23 (\p -> p+101) == -71),(partialIntCase @Prelude.Int (0) (-71) 23 (\p -> p+101) == 23),(partialIntCase @Prelude.Int (1) (-71) 23 (\p -> p+101) == 101),(partialIntCase @Prelude.Int (4) (-71) 23 (\p -> p+101) == 104)])) :: IO (Either E.SomeException Bool))
  case outcome of
    Just (Right True) -> putStrLn "PASS primitive-int_negative_zero_positive"
    _ -> putStrLn ("FAIL primitive-int_negative_zero_positive: " ++ show outcome) >> Exit.exitFailure
