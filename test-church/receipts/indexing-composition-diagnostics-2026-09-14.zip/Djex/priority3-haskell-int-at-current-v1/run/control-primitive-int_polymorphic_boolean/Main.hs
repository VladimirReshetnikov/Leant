{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Main (main) where
import Prelude
import qualified Prelude
import PartialNumeric (partialIntCase)
import qualified Control.Exception as E
import qualified System.Timeout as T
import qualified System.Exit as Exit
main :: IO ()
main = do
  outcome <- T.timeout 2000000 (E.try (E.evaluate (Prelude.and [partialIntCase @Prelude.Bool (-1) Prelude.False Prelude.True (\p -> p == 0) == Prelude.False, partialIntCase @Prelude.Bool 0 Prelude.False Prelude.True (\p -> p == 0), partialIntCase @Prelude.Bool 1 Prelude.False Prelude.True (\p -> p == 0), Prelude.not (partialIntCase @Prelude.Bool 2 Prelude.False Prelude.True (\p -> p == 0))])) :: IO (Either E.SomeException Bool))
  case outcome of
    Just (Right True) -> putStrLn "PASS primitive-int_polymorphic_boolean"
    _ -> putStrLn ("FAIL primitive-int_polymorphic_boolean: " ++ show outcome) >> Exit.exitFailure
