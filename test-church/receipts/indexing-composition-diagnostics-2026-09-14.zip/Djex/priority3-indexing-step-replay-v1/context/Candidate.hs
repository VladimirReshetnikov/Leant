{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes #-}
module Candidate where
import Prelude (Int)
import qualified PartialNumeric
indexing_step_in_context :: forall a. a -> Int -> (forall r. (a -> r -> r) -> r -> r) -> a -> (Int -> a) -> Int -> a
indexing_step_in_context a _ _ d f5 i6 =
  PartialNumeric.partialIntCase i6 a d f5
