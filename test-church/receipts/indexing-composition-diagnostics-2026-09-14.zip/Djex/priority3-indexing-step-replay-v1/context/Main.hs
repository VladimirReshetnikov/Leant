{-# LANGUAGE TypeApplications #-}
module Main where
import Prelude
import qualified Candidate
main :: IO ()
main = if ((Candidate.indexing_step_in_context @Int 37 77 (\_ seed -> seed) 53 (\i -> 100 + i) (-3) == 37) && (Candidate.indexing_step_in_context @Int 37 77 (\_ seed -> seed) 53 (\i -> 100 + i) (-1) == 37) && (Candidate.indexing_step_in_context @Int 37 77 (\_ seed -> seed) 53 (\i -> 100 + i) (0) == 53) && (Candidate.indexing_step_in_context @Int 37 77 (\_ seed -> seed) 53 (\i -> 100 + i) (1) == 100) && (Candidate.indexing_step_in_context @Int 37 77 (\_ seed -> seed) 53 (\i -> 100 + i) (2) == 101) && (Candidate.indexing_step_in_context @Int 37 77 (\_ seed -> seed) 53 (\i -> 100 + i) (4) == 103) && (Candidate.indexing_step_in_context @Bool True 77 (\_ seed -> seed) False (\_ -> True) (-2) == True) && (Candidate.indexing_step_in_context @Bool True 77 (\_ seed -> seed) False (\_ -> True) (0) == False) && (Candidate.indexing_step_in_context @Bool True 77 (\_ seed -> seed) False (\_ -> True) (1) == True) && (Candidate.indexing_step_in_context @Bool True 77 (\_ seed -> seed) False (\_ -> True) (3) == True))
  then putStrLn "PASS indexing step" else fail "indexing step mismatch"
