from pathlib import Path
import json,re,sys
ROOT=Path('C:/Djex');sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as rt
parent=ROOT/'dist-newstyle/priority3-haskell-int-at-current-v1/run'
accepted=json.loads((parent/'results.json').read_text())
ghc=Path(accepted['independent_ghc_path'])
assert rt.sha256(ghc)==accepted['executable_hashes'][str(ghc)]
out=rt.prepare_output_directory(ROOT/'dist-newstyle/priority3-indexing-step-replay-v1')
runner=rt.Processes(out,120)
report=dict(status='running',scope='Independent GHC replay of displayed diagnostic step implementations; no original indexing acceptance.',compiler=str(ghc),compiler_sha256=rt.sha256(ghc),cells=[])
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
def save():
    report['processes']=runner.rows;rt.write_json(out/'results.json',report)
try:
    save()
    for label,name,folder in [('isolated','indexing_step','priority3-indexing-step-v1'),('context','indexing_step_in_context','priority3-indexing-step-context-v1')]:
        previous=ROOT/'dist-newstyle'/folder
        data=json.loads((previous/'results.json').read_text())
        assert data['status']=='passed' and data['sources_and_runtimes_unchanged']
        stdout=(previous/'step.stdout.txt').read_text(encoding='utf-8')
        match=re.search(r'^'+name+r'\b[^\n]*=',stdout,re.M);assert match
        definition=stdout[match.start():].strip()
        directory=out/label;directory.mkdir();(directory/'obj').mkdir()
        candidate='\n'.join(['{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes #-}',
            'module Candidate where','import Prelude (Int)','import qualified PartialNumeric',
            name+' :: '+data['source_type'],definition,''])
        main='\n'.join(['{-# LANGUAGE TypeApplications #-}','module Main where','import Prelude',
            'import qualified Candidate','main :: IO ()',
            'main = if ('+' && '.join('('+p.replace(name,'Candidate.'+name)+')' for p in data['observations'])+')',
            '  then putStrLn "PASS indexing step" else fail "indexing step mismatch"',''])
        (directory/'Candidate.hs').write_text(candidate,encoding='utf-8')
        (directory/'Main.hs').write_text(main,encoding='utf-8')
        (directory/'PartialNumeric.hs').write_bytes((parent/'numeric-fixture/PartialNumeric.hs').read_bytes())
        row=dict(label=label,status='running',origin_receipt_sha256=rt.sha256(previous/'results.json'),source_sha256={p.name:rt.sha256(p) for p in directory.glob('*.hs')})
        report['cells'].append(row);save()
        exe=directory/'step.exe'
        compiled=runner.run(label+'-compile',[ghc,'-v0','-fforce-recomp','-i'+str(directory),'-outputdir',directory/'obj','-o',exe,directory/'Main.hs'],cwd=directory)
        assert compiled.returncode==0,label+' compile'
        row['executable_sha256']=rt.sha256(exe)
        tested=runner.run(label+'-execute',[exe],cwd=directory)
        assert tested.returncode==0 and 'PASS indexing step' in tested.stdout,label+' execute'
        row['status']='passed';save()
    report['status']='passed'
except BaseException as failure:
    report.update(status='failed',failure=repr(failure))
finally:
    report['compiler_unchanged']=rt.sha256(ghc)==report['compiler_sha256']
    if not report['compiler_unchanged']:report['status']='failed'
    save()
print(report['status'],report.get('failure',''),flush=True)
sys.exit(0 if report['status']=='passed' else 1)
