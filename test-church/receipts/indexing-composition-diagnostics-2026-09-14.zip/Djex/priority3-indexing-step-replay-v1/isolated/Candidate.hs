{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes #-}
module Candidate where
import Prelude (Int)
import qualified PartialNumeric
indexing_step :: forall a. a -> a -> (Int -> a) -> Int -> a
indexing_step a b f3 i4 = PartialNumeric.partialIntCase i4 a b f3
