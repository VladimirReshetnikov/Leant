"""Diagnostic candidate inventory, not original Int-at behavior acceptance.

Reuse the original loaded module, source type and search limits. Change only
presentation to all and the predicate to True so rejected terms can be inspected.
REPL.hs constructs the Exference request independently of presentation selection;
Behavioral.hs applies selection after checking. Presentation may reorder terms.
"""
from pathlib import Path
import json
import re
import sys
ROOT=Path('C:/Djex'); sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as rt
from behavior_probe import behavioral_observations
from behavior_partial_probe import observed_inventory, _clean_output
parent=ROOT/'dist-newstyle/priority3-haskell-int-at-current-v1'
original=(parent/'run/exference-at.commands.txt').read_text(encoding='utf-8')
gate=json.loads((parent/'results.json').read_text(encoding='utf-8'))
assert gate['status']=='failed' and gate['sources_and_runtimes_unchanged']
exe=next(path for path in gate['runtime_sha256'] if path.endswith('djex.exe'))
out=rt.prepare_output_directory(ROOT/'dist-newstyle/priority3-at-candidate-inventory-v2')
lines=[]
for line in original.splitlines():
    if line==':set select first': line=':set select all'
    if line.startswith(':synth partial_exference_at :: '): line=line.split(' where ',1)[0]+' where True'
    lines.append(line)
source='\n'.join(lines)+'\n'
runner=rt.Processes(out,300)
sources=dict(gate['source_sha256'])
sources.update(json.loads((parent/'run/results.json').read_text(encoding='utf-8'))['source_hashes'])
sources[str(Path(__file__).relative_to(ROOT))]=rt.sha256(Path(__file__))
report=dict(status='running',scope=__doc__,original_input_sha256=rt.sha256(parent/'run/exference-at.commands.txt'),
            source_sha256=sources,runtime_sha256=gate['runtime_sha256'])
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
def stable():
    return all(rt.sha256(ROOT/p)==h for p,h in sources.items()) and all(rt.sha256(Path(p))==h for p,h in gate['runtime_sha256'].items())
def save():
    report['processes']=runner.rows;rt.write_json(out/'results.json',report)
try:
    assert stable();save()
    result=runner.run('inventory',[exe,'repl','--ignore-startup','--environment',parent/'run/empty-environment'],source=source,cwd=ROOT)
    assert result.returncode==0
    transcript=result.stdout+result.stderr
    assert not re.search(r'error \[DJEX_',transcript),transcript
    cleaned=_clean_output(transcript)
    original_result=json.loads((parent/'run/results.json').read_text(encoding='utf-8'))
    expected=dict(original_result['cells'][0]['validated_settings']);expected['select']='all'
    for key,value in expected.items():
        assert re.findall(r'(?m)^'+re.escape(key)+r' = (.*)$',cleaned)==[value],key
    report['validated_settings']=expected
    report['observed_inventory']=observed_inventory(transcript,'exference','at')
    counts=behavioral_observations(result.stdout+result.stderr,expect_success=True,window=256)
    assert counts==dict(checked=256,true=256,false=0,error=0,timeout=0,window=256),counts
    terms=re.findall(r'^partial_exference_at[^\n]*=',result.stdout,re.M)
    report.update(status='passed',observations=counts,definition_count=len(terms),original_behavior_accepted=False)
    assert len(terms)==256,len(terms)
except BaseException as failure:
    report.update(status='failed',failure=repr(failure))
finally:
    report['sources_and_runtimes_unchanged']=stable()
    if not report['sources_and_runtimes_unchanged']:report['status']='failed'
    save()
print(report['status'],report.get('failure',''),flush=True)
sys.exit(0 if report['status']=='passed' else 1)
