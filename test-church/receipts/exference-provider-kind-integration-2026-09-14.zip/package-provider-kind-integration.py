from pathlib import Path
import hashlib,json,zipfile
ROOT=Path('C:/Djex');OTHER=Path('C:/Leant');D=ROOT/'dist-newstyle'
sha=lambda b:hashlib.sha256(b).hexdigest()
folders=['provider-kind-composition-baseline-v1','kinded-deconstructor-baseline-v1','provider-kind-composition-regression-v1','provider-kind-composition-public-v1']
reports={f:json.loads((D/f/'results.json').read_text()) for f in folders}
for f in folders[-2:]:
 r=reports[f];assert r['status']=='passed',f
 assert r['sources_unchanged'] and r['runtimes_unchanged'],f
 for p,h in r['source_sha256'].items():assert sha((ROOT/p).read_bytes())==h,p
 for p,h in r['runtime_sha256'].items():assert sha(Path(p).read_bytes())==h,p
reg=reports[folders[2]];public=reports[folders[3]]
assert sum(s['count'] for s in reg['suites'])==1664
assert all(s['passed'] for s in reg['suites'])
assert len(public['queries'])==11 and all(q['passed'] for q in public['queries'])
assert public['invalid_kind']['passed']
members={}
for f in folders:
 for p in sorted((D/f).rglob('*')):
  if p.is_file() and p.suffix.lower() not in ('.exe','.dll','.o','.hi','.pyc'):
   members['runs/'+f+'/'+p.relative_to(D/f).as_posix()]=p.read_bytes()
members['package-provider-kind-integration.py']=Path(__file__).read_bytes()
base='exference-provider-kind-integration-2026-09-14'
archive=ROOT/'test-church/receipts'/(base+'.zip');assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(members.items()):z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(members)
 for n,b in members.items():assert z.read(n)==b,n
index=dict(scope='Exference source/provider kind composition and polymorphic pattern-field ownership accepted in Haskell; native adoption pending.',archive=archive.name,archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,member_count=len(members),acceptance=dict(tests=1664,new_integration_ghc_replays=8,public_exference_ghc_replays=22,public_false_controls=11,malformed_kind_controls=1,native_adoption=False),runs=[dict(directory=f,status=reports[f]['status'],receipt_sha256=sha((D/f/'results.json').read_bytes())) for f in folders],members=[dict(path=n,sha256=sha(b),bytes=len(b)) for n,b in sorted(members.items())])
for root in [ROOT,OTHER]:
 p=root/'test-church/receipts'/archive.name
 if root!=ROOT:
  assert not p.exists();p.write_bytes(archive.read_bytes())
 assert not p.with_suffix('.json').exists()
 p.with_suffix('.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
print({k:index[k] for k in ['archive_sha256','archive_bytes','member_count']})
