module Fixture where
type Identity x = x
class Marker a
instance Marker Int
