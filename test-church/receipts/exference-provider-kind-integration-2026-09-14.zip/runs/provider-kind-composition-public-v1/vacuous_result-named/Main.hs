{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds #-}
module Main where
import Fixture
probe :: forall a. a -> (forall (f :: * -> *). a)
probe a = a
main :: IO ()
main = print (probe @Int 7 @[] == 7)
