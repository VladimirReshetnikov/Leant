module Main (main) where

import Control.DeepSeq (force)
import Control.Exception (SomeException, evaluate, try)
import Control.Monad (forM_)
import Data.List (find)
import qualified Data.Map.Strict as Map
import qualified Data.IntMap.Strict as IntMap
import qualified Data.IntSet as IntSet
import Data.List.NonEmpty (NonEmpty ((:|)))
import qualified Data.Set as Set
import Data.Void (Void)
import Numeric.Natural (Natural)
import System.Environment (getArgs)
import Test.Tasty (TestTree, defaultMain, testGroup)
import Test.Tasty.HUnit
  ((@?=), assertBool, assertEqual, assertFailure, testCase)

import Language.Haskell.Exference.Core.Candidate
  ( ExferenceCandidateDetails (..), emptyExferenceSourceTypeVariableHints )
import Language.Haskell.Exference.Core.ConstraintSolver (filterUnresolved, uniqueGivenInstantiation, givenInstantiations)
import Language.Haskell.Exference.Core.Expression
  ( Expression (..), toGeneratedExpression, showExpression )
import Language.Haskell.Exference.Core.ExferenceStats (ExferenceStats (..))
import Language.Haskell.Exference.Core.Internal.ExpressionCheck
  ( CheckedExpressionEvidence
  , ExpressionCheckError (..)
  , ExferenceTermGraphAbsence (..)
  , ExferenceTermGraphAvailability (..)
  , ExferenceTermGraphCertificateAssociationFailure (..)
  , ExferenceTermGraphConstructionLimit (..)
  , checkedExpressionTermGraph
  , checkedExpressionTypeApplicationOriginReferences
  , checkedExpressionTypeApplicationOrigins
  , checkedTypeApplicationOriginId
  , checkedTypeApplicationOriginOwner
  , checkedTypeApplicationOriginSource
  , checkedTypeApplicationOriginStepObligations
  , checkedTypeApplicationOriginStepResult
  , checkedTypeApplicationOriginStepSelected
  , checkedTypeApplicationOriginStepSlot
  , checkedTypeApplicationOriginStepSource
  , checkedTypeApplicationOriginSteps
  , checkExpression
  , checkExpressionInContextWithNestedRigidProvenanceEvidence
  , prepareExpressionCheckContext
  , prepareExpressionCheckContextWithSchemes
  )
import Language.Haskell.Exference.Core.FunctionBinding
  ( ConstructorBinding (..)
  , DeconstructorBinding (..)
  , EnvDictionary (..)
  , FunctionBinding (..)
  )
import Language.Haskell.Exference.Core.Declaration
  ( prepareSynthesisInventory
  , preparedSynthesisBackend
  , preparedSynthesisSchemes
  )
import qualified Language.Haskell.Exference.Core.Internal.Exference as E
import Language.Haskell.Exference.Core.Internal.FlexibleIds
  ( allocateNamespace )
import Language.Haskell.Exference.Core.Internal.Options
  ( ExferenceHeuristicsConfig (..)
  , ExferenceOptions (..)
  , defaultHeuristicsConfig
  , defaultExferenceOptions
  )
import Language.Haskell.Exference.Core.Internal.Polytype
  ( GroundProviderInstantiation (..)
  , candidateProviderInstantiations
  , assignmentProviderInstantiations
  , groundProviderInstantiations
  , instantiateLeadingForallsWith
  , instantiateLeadingForallsWithOpenings
  , leadingForallOpeningSource
  , leadingForallOpeningBindings
  , quantifiedProviderSubsumes
  )
import Language.Haskell.Exference.Core.Internal.RigidScope
  ( RigidEscape (..)
  , emptyRigidScope
  , nestedRigidProvenance
  , registerRigidScope
  , validateRigidSubstitutions
  )
import Language.Haskell.Exference.Core.Internal.ScopedConstraint
import Language.Haskell.Exference.Core.Internal.Testing
import Language.Haskell.Exference.Core.Internal.VariableSupply
  ( supplyFromIdentifiers )
import Language.Haskell.Exference.Core.Score (Penalty (..))
import qualified Language.Haskell.Exference.Core.Score as Score
import Language.Haskell.Exference.Core.RigidInstantiation
  ( mkRigidInstantiationContext, planRigidInstantiation )
import Language.Haskell.Exference.Core.Types
import qualified Language.Haskell.Synthesis.Candidate as SharedCandidate
import qualified Language.Haskell.Synthesis.CandidateQuality as SharedQuality
import qualified Language.Haskell.Synthesis.Constraint as SharedConstraint
import qualified Language.Haskell.Synthesis.Declaration as SharedDeclaration
import qualified Language.Haskell.Synthesis.Generated as Generated
import qualified Language.Haskell.Synthesis.Inventory as SharedInventory
import qualified Language.Haskell.Synthesis.KindInference as SharedKindInference
import qualified Language.Haskell.Synthesis.Kind as SharedKind
import qualified Language.Haskell.Synthesis.SourceKind as SourceKind
import qualified Language.Haskell.Synthesis.Internal.TypedGenerated.Certificate
  as Certificate
import qualified Language.Haskell.Synthesis.Internal.TypedGenerated.Certificate.Association
  as Association
import qualified Language.Haskell.Synthesis.Internal.TypedCandidate
  as TypedCandidate
import qualified Language.Haskell.Synthesis.Name as SharedName
import qualified Language.Haskell.Synthesis.Query as SharedQuery
import qualified Language.Haskell.Synthesis.Search as SharedSearch
import qualified Language.Haskell.Synthesis.TypeAtom as SharedTypeAtom
import qualified Language.Haskell.Synthesis.TypedGenerated as Typed
import qualified Language.Haskell.Synthesis.TypedGenerated.Fingerprint
  as Fingerprint
import qualified NestedForallGraphSpec
import qualified ImplicitConstructorGraphSpec
import qualified GivenEvidenceSpec
import qualified KindScopeSpec

main :: IO ()
main = do
  arguments <- getArgs
  case arguments of
    ["--emit-unit-prefix"] -> emitUnitPrefix
    _ -> defaultMain tests

tests :: TestTree
tests = testGroup "Exference private engine boundaries"
  [ testCase "intrinsic-unit alternatives preserve the maybeEither prefix" unitPrefixRegression
  , NestedForallGraphSpec.tests
  , ImplicitConstructorGraphSpec.tests
  , GivenEvidenceSpec.tests
  , KindScopeSpec.tests
  , testCase "rigid scopes reject direct and propagated skolem escapes" $ do
      let opened = registerRigidScope
            (IntSet.singleton 0) [7] emptyRigidScope
      validateRigidSubstitutions opened
        (IntMap.singleton 0 $ TypeConstant 7) @?=
          Left (RigidEscape 0 7)
      propagated <- expectRight $ validateRigidSubstitutions opened
        (IntMap.singleton 0 $ TypeVar 1)
      validateRigidSubstitutions propagated
        (IntMap.singleton 1 $ TypeConstant 7) @?=
          Left (RigidEscape 1 7)
      validateRigidSubstitutions opened
        (IntMap.fromList
          [(0, TypeVar 1), (1, TypeConstant 7)]) @?=
            Left (RigidEscape 1 7)
      case validateRigidSubstitutions opened
          (IntMap.singleton 2 $ TypeConstant 7) of
        Right _ -> pure ()
        Left failure -> fail
          $ "a younger flexible variable was rejected: " ++ show failure
  , testCase "scoped givens resolve only their own obligations" $ do
      let className = name "C"
          integer = TypeCons $ name "Int"
          evidence = HsConstraint className [integer]
          local = ScopedConstraint [evidence] evidence
          sibling = ScopedConstraint [] evidence
      staticClasses <- expectRight
        $ mkStaticClassEnv [HsTypeClass className [0] []] []
      resolveScopedConstraints filterUnresolved
        (mkQueryClassEnv staticClasses []) [local, sibling]
        @?= Just [sibling]
  , testCase "scoped substitutions update givens and obligations together" $ do
      let className = name "C"
          integer = TypeCons $ name "Int"
          evidence ty = HsConstraint className [ty]
          original = ScopedConstraint
            [evidence $ TypeVar 0]
            (evidence $ TypeVar 1)
          (_, substituted) = scopedConstraintApplySubsts
            (IntMap.fromList [(0, integer), (1, integer)]) original
      staticClasses <- expectRight
        $ mkStaticClassEnv [HsTypeClass className [0] []] []
      substituted @?= ScopedConstraint [evidence integer] (evidence integer)
      resolveScopedConstraints filterUnresolved
        (mkQueryClassEnv staticClasses []) [substituted]
        @?= Just []
  , testCase "scoped instance prerequisites retain their lexical givens" $ do
      let baseName = name "Base"
          derivedName = name "Derived"
          integer = TypeCons $ name "Int"
          base ty = HsConstraint baseName [ty]
          derived ty = HsConstraint derivedName [ty]
          instanceRule = HsInstance
            [base $ TypeVar 0]
            (derived $ TypeVar 0)
          local = ScopedConstraint [base integer] (derived integer)
          sibling = ScopedConstraint [] (derived integer)
      staticClasses <- expectRight $ mkStaticClassEnv
        [ HsTypeClass baseName [0] []
        , HsTypeClass derivedName [0] []
        ] [instanceRule]
      resolveScopedConstraints filterUnresolved
        (mkQueryClassEnv staticClasses []) [local, sibling]
        @?= Just [ScopedConstraint [] $ base integer]
  , testCase "prepared queries consume one validated options witness" $ do
      environment <- expectRight $ sealLegacyEnvironment identityInput
      target <- checkedIdentifierTarget "singleOptionValidation"
      let query = legacyInputQuery identityInput
          sourceHints = emptyExferenceSourceTypeVariableHints
            $ E.queryGoalType query
      singleOptionValidationStrictnessForTesting
        target sourceHints environment query @?= Right ()
  , testGroup "constraint-only lexical instantiation"
      [ testCase "two lexical selections survive global method search" $
          assertTwoLexicalSelections False
      , testCase "two lexical selections survive local callback search" $
          assertTwoLexicalSelections True
      , testCase "explicit selections do not authorize missing or sibling evidence" $
          assertSelectedProviderChecking
      , testCase "search alternatives retain ambiguity and matching guards" $ do
          let c ty = HsConstraint (name "C") [ty]
              obligations = [([c $ TypeConstant 0, c $ TypeConstant 1], c $ TypeVar 9)]
          givenInstantiations 20 (IntSet.singleton 9) obligations @?=
            [IntMap.singleton 9 $ TypeConstant 0, IntMap.singleton 9 $ TypeConstant 1]
          uniqueGivenInstantiation 20 (IntSet.singleton 9) obligations @?= Nothing
          givenInstantiations 1 (IntSet.singleton 9) obligations @?=
            [IntMap.singleton 9 $ TypeConstant 0]
          givenInstantiations 20 IntSet.empty obligations @?= []
      , testCase "only fresh provider variables can be solved" $ do
          let c ty = HsConstraint (name "C") [ty]
              request = [([c $ TypeVar 0], c $ TypeVar 9)]
          uniqueGivenInstantiation 20 (IntSet.singleton 9) request @?=
            Just (IntMap.singleton 9 $ TypeVar 0)
          uniqueGivenInstantiation 20 IntSet.empty request @?= Nothing
      , testCase "joint constraints resolve an individually ambiguous parameter" $ do
          let c ty = HsConstraint (name "C") [ty]
              d ty = HsConstraint (name "D") [ty]
              givens = [c $ TypeConstant 0, c $ TypeConstant 1, d $ TypeConstant 1]
          uniqueGivenInstantiation 30 (IntSet.singleton 9)
            [(givens, c $ TypeVar 9), (givens, d $ TypeVar 9)] @?=
              Just (IntMap.singleton 9 $ TypeConstant 1)
      , testCase "matching respects the work guard before certifying uniqueness" $ do
          let c ty = HsConstraint (name "C") [ty]
              one = [([c $ TypeConstant 0], c $ TypeVar 9)]
              two = [([c $ TypeConstant 0, c $ TypeConstant 1], c $ TypeVar 9)]
          uniqueGivenInstantiation 0 (IntSet.singleton 9) one @?= Nothing
          uniqueGivenInstantiation 1 (IntSet.singleton 9) one @?=
            Just (IntMap.singleton 9 $ TypeConstant 0)
          uniqueGivenInstantiation 1 (IntSet.singleton 9) two @?= Nothing
          uniqueGivenInstantiation 20 (IntSet.singleton 9) two @?= Nothing
      , testCase "alpha-equivalent polytype selections do not create ambiguity" $ do
          let c ty = HsConstraint (name "C") [ty]
              identity x = TypeForall [x] [] $ TypeArrow (TypeVar x) (TypeVar x)
              givens = [c $ identity 1, c $ identity 2]
          uniqueGivenInstantiation 20 (IntSet.singleton 9)
            [(givens, c $ TypeVar 9)] @?= Just (IntMap.singleton 9 $ identity 1)
      , testCase "a quantified Given cannot donate its bound variable" $ do
          let c ty = HsConstraint (name "C") [ty]
              actual = TypeForall [0] [] $ TypeArrow (TypeVar 0) (TypeVar 0)
              wanted = TypeForall [1] [] $ TypeArrow (TypeVar 1) (TypeVar 9)
          uniqueGivenInstantiation 20 (IntSet.singleton 9) [([c actual], c wanted)] @?= Nothing
      , testCase "live global method search retains the exact inferred Given graph" $ do
          let c ty = HsConstraint (name "C") [ty]
              token = TypeCons $ name "Token"
              providerName = name "method"
              provider = TypeForall [3] [c $ TypeVar 3] token
              goal = TypeForall [0] [c $ TypeVar 0] token
              input = identityInput { E.input_goalType = goal, E.input_maxSteps = 32 }
          classes <- expectRight $ mkStaticClassEnv [HsTypeClass (name "C") [0] []] []
          (bindings, schemes) <- preparedValueEnvironment providerName provider
          environment <- expectRight $ E.mkExferenceEnvironmentWithSchemes
            (EnvDictionary bindings [] classes) schemes
          target <- checkedIdentifierTarget "inferredMethod"
          options <- expectRight $ E.checkExferenceOptions $
            E.querySearchOptions $ legacyInputQuery input
          results <- expectRight $
            E.findTypedQueryResultsInEnvironmentWithCheckedOptionsAndAssignments Map.empty
              target (emptyExferenceSourceTypeVariableHints goal) environment
              (legacyInputQuery input) options
          let candidates = concatMap
                (SharedSearch.batchCandidates . SharedQuery.resultSearch) results
          candidate <- case candidates of
            first : _ -> pure first
            [] -> fail "constraint-only global method search produced no candidate"
          graph <- TypedCandidate.foldTypedCandidateGraph
            (\_ reason -> fail $ "method candidate has no graph: " ++ show reason)
            (\_ owned -> pure owned)
            (\_ associated -> pure $ Association.checkedTypeApplicationCertificateGraph associated)
            candidate
          let introductions =
                [ Typed.contextEvidenceBinder $ Typed.givenContextEvidence occurrence slot
                | (_, Typed.TermNode _ (Typed.TypedContextIntroduction occurrence _ witness)) <- Typed.termGraphNodes graph
                , (slot, _) <- zip [0 ..] $ Typed.contextIntroductionConstraints witness ]
              applications =
                [ Typed.contextEvidenceBinder proof
                | (_, Typed.TermNode _ (Typed.TypedContextApplication _ _ witness)) <- Typed.termGraphNodes graph
                , proof <- Typed.contextApplicationEvidence witness ]
          length introductions @?= 1
          applications @?= introductions
      ]
  , testGroup "serial ordered step actions"
      [ testCase "preserve complete finite traces and typed candidates" $ do
          let ample = IdentifierCapacities 1000 1000 1000 1000
              integer = TypeCons $ name "Int"
              result = TypeCons $ name "Result"
              atom = TypeCons $ name "Atom"
              constant bindingName = FunctionBinding
                integer bindingName 0 [] []
              immediate = identityInput
                { E.input_goalType = integer
                , E.input_envFuncs =
                    [constant $ name "left", constant $ name "right"]
                , E.input_maxSteps = 10
                }
              wrapper bindingName = FunctionBinding
                result bindingName 0 [] [atom]
              seed = FunctionBinding atom (name "seed") 0 [] []
              tied maximumQueue = identityInput
                { E.input_goalType = result
                , E.input_envFuncs =
                    [wrapper $ name "first", wrapper $ name "second", seed]
                , E.input_maxSteps = 20
                , E.input_maxQueueSize = maximumQueue
                }
              depthLimited = identityInput
                { E.input_maxDepth = Just 0
                , E.input_heuristicsConfig = defaultHeuristicsConfig
                    {heuristics_functionGoalTransform = 1}
                }
              choice = TypeCons $ name "Choice"
              choiceDeconstructor = DeconstructorBinding choice
                [ ConstructorBinding (name "LeftChoice") []
                , ConstructorBinding (name "RightChoice") []
                ] False
              patternInput = identityInput
                { E.input_goalType = TypeArrow choice result
                , E.input_envFuncs =
                    [FunctionBinding result (name "result") 0 [] []]
                , E.input_envDeconsS = [choiceDeconstructor]
                , E.input_multiPM = True
                , E.input_maxSteps = 50
                , E.input_maxQueueSize = Just 128
                }
              nestedTuple = TypeTuple Boxed
                [TypeTuple Boxed [integer, integer], integer]
              tupleInput = identityInput
                { E.input_goalType = nestedTuple
                , E.input_envFuncs = [constant $ name "integer"]
                , E.input_maxSteps = 50
                , E.input_maxQueueSize = Just 128
                }
              evidence = HsConstraint (name "External") [integer]
              constrained = identityInput
                { E.input_goalType = result
                , E.input_envFuncs =
                    [ FunctionBinding result (name "constrained") 0
                        [evidence] []
                    ]
                , E.input_allowConstraints = True
                , E.input_allowConstraintsStopStep = 0
                , E.input_maxSteps = 10
                }
              cases =
                [ ("identity", identityInput)
                , ("equal-cost immediate solutions", immediate)
                , ("equal-priority futures", tied Nothing)
                , ("equal-priority queue retention", tied $ Just 1)
                , ("zero queue", identityInput
                    {E.input_maxQueueSize = Just 0})
                , ("depth pruning", depthLimited)
                , ("multi-constructor pattern", patternInput)
                , ("nested structural tuple", tupleInput)
                , ("residual constraint", constrained)
                ]
          mapM_ (\(label, input) ->
              assertStepRouteParity label ample input)
            cases
      , testCase "preserve every finite identifier-exhaustion route" $ do
          let integer = TypeCons $ name "Int"
              result = TypeCons $ name "Result"
              polymorphic = FunctionBinding
                (TypeVar 0) (name "polymorphic") 0 [] []
              constant = FunctionBinding integer (name "constant") 0 [] []
              successfulSibling = identityInput
                { E.input_goalType = integer
                , E.input_envFuncs = [polymorphic, constant]
                }
              identityScheme = TypeForall [0] []
                $ TypeArrow (TypeVar 0) (TypeVar 0)
              nestedForall = identityInput
                { E.input_goalType = TypeArrow
                    (TypeArrow identityScheme result) result
                , E.input_maxSteps = 200
                }
              cases =
                [ ( "term identifier"
                  , IdentifierCapacities 0 100 100 100
                  , identityInput
                  )
                , ( "flexible identifier with successful sibling"
                  , IdentifierCapacities 100 0 100 100
                  , successfulSibling
                  )
                , ( "nested rigid identifier"
                  , IdentifierCapacities 100 100 0 100
                  , nestedForall
                  )
                , ( "scope identifier"
                  , IdentifierCapacities 100 100 100 1
                  , identityInput
                  )
                ]
          mapM_ (\(label, capacities, input) ->
              assertStepRouteParity label capacities input)
            cases
      , testCase "retain identical candidate-to-graph identities" $ do
          let integer = TypeCons $ name "Int"
              leftName = name "actionLeft"
              rightName = name "actionRight"
              binding bindingName = FunctionBinding
                integer bindingName 0 [] []
              input = identityInput
                { E.input_goalType = integer
                , E.input_envFuncs = [binding leftName, binding rightName]
                }
              capacities = IdentifierCapacities 100 100 100 100
              observe candidates = Map.fromList
                [ (bindingName,
                    Typed.termNodeIdValue $ Typed.termGraphRoot graph)
                | (ExpName bindingName, _,
                    ExferenceTermGraphAvailable graph) <- candidates
                ]
          (legacyLazy, actionsLazy) <- expectRight
            $ findTypedEngineCandidateStepRouteTracesWithIdentifierCapacitiesEither
                capacities input
          legacy <- evaluate $ force legacyLazy
          actions <- evaluate $ force actionsLazy
          assertBool "ordered actions changed typed candidates or graphs"
            $ actions == legacy
          let legacyRoots = observe legacy
              actionRoots = observe actions
          actionRoots @?= legacyRoots
          Map.keysSet actionRoots @?= Set.fromList [leftName, rightName]
          assertBool "ordered actions reused one typed-graph identity"
            $ Map.lookup leftName actionRoots
                /= Map.lookup rightName actionRoots
      , testCase "do not demand the next lazy search step" $ do
          (legacy, actions) <- expectRight
            $ findExpressionStepRouteTracesWithPoisonedNextStepEither
                identityInput
          legacyFirst <- firstChunk "legacy poisoned trace" legacy
          actionFirst <- firstChunk "ordered-action poisoned trace" actions
          assertBool "ordered actions changed the first poisoned batch"
            $ observeChunk actionFirst == observeChunk legacyFirst
          E.chunkStatus actionFirst @?=
            E.SearchStatus E.SearchRunning 0 0
          assertSecondBatchPoisoned "legacy dispatcher" legacy
          assertSecondBatchPoisoned "ordered-action dispatcher" actions
      ]
  , testCase "term identifier exhaustion truncates instead of colliding" $ do
      chunk <- lastCapacityChunk
        (IdentifierCapacities 0 100 100 100) identityInput
      E.chunkStatus chunk @?=
        E.SearchStatus E.SearchIdentifierSpaceExhausted 0 0
      assertBool "an exhausted term-ID branch produced a candidate"
        $ null $ E.chunkElements chunk
  , testCase "identifier truncation survives a successful sibling" $ do
      let integer = TypeCons $ name "Int"
          polymorphic = FunctionBinding
            (TypeVar 0) (name "polymorphic") 0 [] []
          constant = FunctionBinding integer (name "constant") 0 [] []
          input = identityInput
            { E.input_goalType = integer
            , E.input_envFuncs = [polymorphic, constant]
            }
          capacities = IdentifierCapacities 100 0 100 100
      chunk <- lastCapacityChunk capacities input
      E.searchCompletion (E.chunkStatus chunk) @?=
        E.SearchIdentifierSpaceExhausted
      assertBool "a viable sibling was suppressed by identifier exhaustion"
        $ not $ null $ E.chunkElements chunk
      target <- checkedIdentifierTarget "generated"
      environment <- expectRight $ sealLegacyEnvironment input
      results <- expectRight
        $ findQueryResultsWithIdentifierCapacitiesEither
            capacities target
            (emptyExferenceSourceTypeVariableHints $ E.input_goalType input)
            environment (legacyInputQuery input)
      result <- lastResult results
      let batch = SharedQuery.resultSearch result
      SharedQuery.resultEvidence result @?=
        SharedQuery.ValidatedCandidates
      SharedSearch.batchProgress batch @?= SharedSearch.Completed
        (SharedSearch.Truncated
          $ SharedSearch.IdentifierSpaceExhausted :| [])
      assertBool "the direct result lost its checked target"
        $ all ((== target) . Generated.clauseName
            . SharedCandidate.candidateOutput)
        $ SharedSearch.batchCandidates batch
  , testCase "provider forall exhaustion truncates the affected branch" $ do
      let integer = TypeCons $ name "Int"
          polymorphic = TypeForall [0] []
            $ TypeArrow (TypeVar 0) (TypeVar 0)
          input = identityInput
            { E.input_goalType =
                TypeArrow polymorphic $ TypeArrow integer integer
            , E.input_maxSteps = 100
            }
      -- Binder 0 already occupies the only flexible slot. Per-use
      -- instantiation needs one additional spelling and must fail without
      -- wrapping or reusing the binder identity.
      chunk <- lastCapacityChunk
        (IdentifierCapacities 100 1 100 100) input
      E.chunkStatus chunk @?=
        E.SearchStatus E.SearchIdentifierSpaceExhausted 0 0
      assertBool "an exhausted forall instantiation produced a candidate"
        $ null $ E.chunkElements chunk
  , testCase "nested forall introduction is checked and rigid-bounded" $ do
      let result = TypeCons $ name "Result"
          identityScheme = TypeForall [0] []
            $ TypeArrow (TypeVar 0) (TypeVar 0)
          goal = TypeArrow
            (TypeArrow identityScheme result)
            result
          input = identityInput
            { E.input_goalType = goal
            , E.input_maxSteps = 200
            }
      chunks <- expectRight
        $ findExpressionsWithIdentifierCapacitiesEither
            (IdentifierCapacities 100 100 100 100) input
      let expressions =
            [ expression
            | chunk <- chunks
            , (expression, _, _) <- E.chunkElements chunk
            ]
      assertBool "the quantified callback produced no checked candidate"
        $ not $ null expressions
      mapM_ (\expression -> checkExpression
          (mkQueryClassEnv emptyStaticClassEnv []) [] [] goal [] expression
            @?= Right ())
        expressions

      exhausted <- lastCapacityChunk
        (IdentifierCapacities 100 100 0 100) input
      E.searchCompletion (E.chunkStatus exhausted) @?=
        E.SearchIdentifierSpaceExhausted
      assertBool "rigid exhaustion admitted a quantified callback"
        $ null $ E.chunkElements exhausted
  , testCase "nested forall skolems cannot escape through older variables" $ do
      let boolean = TypeCons $ name "Bool"
          callback = TypeForall [1] []
            $ TypeArrow (TypeVar 1) (TypeVar 0)
          use = FunctionBinding boolean (name "use") 0 [] [callback]
          input = identityInput
            { E.input_goalType = boolean
            , E.input_envFuncs = [use]
            , E.input_maxSteps = 200
            }
      chunks <- expectRight
        $ findExpressionsWithIdentifierCapacitiesEither
            (IdentifierCapacities 100 100 100 100) input
      assertBool "an older result meta captured a nested skolem"
        $ all (null . E.chunkElements) chunks
  , testCase "overapplication uses the finite flexible namespace and checked arguments" $ do
      let envelope = TypeApp $ TypeCons $ name "ExtraArgumentEnvelope"
          seed = TypeCons $ name "ExtraArgumentSeed"
          result = TypeCons $ name "ExtraArgumentResult"
          extractor = TypeForall [0] [] $
            TypeArrow (envelope $ TypeVar 0) (TypeVar 0)
          goal = foldr TypeArrow result
            [extractor, envelope $ TypeArrow seed result, seed]
          input = identityInput
            { E.input_goalType = goal, E.input_maxSteps = 500
            , E.input_maxQueueSize = Just 512 }
      ample <- expectRight $ findExpressionsWithIdentifierCapacitiesEither
        (IdentifierCapacities 1000 1000 1000 1000) input
      let candidates = [expression | chunk <- ample,
            (expression, _, _) <- E.chunkElements chunk]
      assertBool "the bounded extra application produced no checked witness" $
        not $ null candidates
      mapM_ (\expression -> checkExpression
          (mkQueryClassEnv emptyStaticClassEnv []) [] [] goal [] expression @?= Right ())
        candidates
      limited <- lastCapacityChunk (IdentifierCapacities 1000 1 1000 1000) input
      E.searchCompletion (E.chunkStatus limited) @?= E.SearchIdentifierSpaceExhausted
      assertBool "namespace exhaustion manufactured an extra-argument witness" $
        null $ E.chunkElements limited
  , testCase "balanced search instantiates Church reverse and scalar folds at an endomorphism" $ do
      let element = TypeVar 0
          list = TypeForall [1] [] $ TypeArrow
            (TypeArrow element $ TypeArrow (TypeVar 1) (TypeVar 1)) $
            TypeArrow (TypeVar 1) (TypeVar 1)
          goal = TypeArrow list list
          scalarElement = TypeCons $ name "ContinuationElement"
          scalarCarrier = TypeCons $ name "ContinuationCarrier"
          scalarFold = TypeForall [1] [] $ TypeArrow
            (TypeArrow scalarElement $ TypeArrow (TypeVar 1) (TypeVar 1)) $
            TypeArrow (TypeVar 1) (TypeVar 1)
          scalarGoal = foldr TypeArrow scalarCarrier
            [ scalarFold
            , TypeArrow scalarElement $ TypeArrow scalarCarrier scalarCarrier
            , scalarCarrier
            ]
          local = Generated.Local
          app = Generated.Apply
          lam variables = Generated.lambdaExpression $ map Generated.Bind variables
          -- xs (\a k r -> k (c a r)) (\r -> r) z
          step = lam [4, 5, 6] $ app (local 5) $
            app (app (local 2) (local 4)) (local 6)
          -- The shared eta simplifier acts on singleton lambdas, while
          -- the alpha comparator preserves pattern grouping. Split the
          -- grouped witness before applying that existing simplifier so
          -- an eta-shorter emitted fold compares equally. Keep all
          -- visible type arguments and check the original candidate below.
          singletonLambdas source = case source of
            Generated.Lambda patterns body -> foldr
              (\pattern rest -> Generated.Lambda [pattern] rest)
              (singletonLambdas body) patterns
            Generated.Apply function argument -> Generated.Apply
              (singletonLambdas function) (singletonLambdas argument)
            Generated.VisibleTypeApplication function argument ->
              Generated.VisibleTypeApplication (singletonLambdas function) argument
            Generated.Tuple elements -> Generated.Tuple $ map singletonLambdas elements
            Generated.Let pattern value body -> Generated.Let pattern
              (singletonLambdas value) (singletonLambdas body)
            Generated.Case value branches -> Generated.Case (singletonLambdas value)
              [(pattern, singletonLambdas body) | (pattern, body) <- branches]
            _ -> source
          normalize = Generated.simplifyExpressionBy id . singletonLambdas
          expected = normalize $ lam [1, 2, 3] $
            app (app (app (local 1) step) (lam [7] $ local 7)) (local 3)
          matches (expression, _, _) = Generated.alphaEquivalentExpression expected $
            normalize $ toGeneratedExpression expression
      assertBool "the witness comparison rejected the same eta-shorter fold" $
        Generated.alphaEquivalentExpression expected $ normalize $ lam [1, 2] $
          app (app (local 1) step) (lam [7] $ local 7)
      forM_ [("Church reverse", goal), ("arbitrary scalar continuation", scalarGoal)] $
        \(label, requested) -> do
          -- The behavioral command uses the balanced policy. The historical
          -- ExferenceInput facade deliberately selects legacy ranking, whose
          -- first candidate window is a different search-order contract.
          environment <- expectRight $ E.mkExferenceEnvironment $
            EnvDictionary [] [] emptyStaticClassEnv
          checked <- expectRight $ E.prepareExferenceQuery environment $
            E.ExferenceQuery requested Set.empty defaultExferenceOptions
              { exferenceMaximumSteps = 100000
              , exferenceMaximumQueueSize = Just 8192
              , exferenceAllowUnused = True
              , exferenceCandidateRanking = SharedQuality.defaultCandidateRankingPolicy
              }
          let candidates = concatMap E.chunkElements $ E.findExpressions checked
          (expression, residual, _) <- maybe
            (fail $ label ++ " was absent from the bounded candidate prefix") pure $
              find matches $ take 256 candidates
          residual @?= []
          checkExpression (mkQueryClassEnv emptyStaticClassEnv []) [] []
            requested [] expression @?= Right ()
  , testCase "intrinsic unit introduction needs no declaration and cannot inhabit a rigid type" $ do
      environment <- expectRight $ E.mkExferenceEnvironment $ EnvDictionary [] [] emptyStaticClassEnv
      forM_ [TypeTuple Boxed [], TypeForall [0] [] $ TypeVar 0] $ \goal -> do
        checked <- expectRight $ E.prepareExferenceQuery environment $
          E.ExferenceQuery goal Set.empty defaultExferenceOptions
            { exferenceMaximumSteps = 64, exferenceMaximumQueueSize = Just 64
            , exferenceAllowUnused = True }
        let candidates = concatMap E.chunkElements $ E.findExpressions checked
        case goal of
          TypeTuple Boxed [] -> case candidates of
            (expression, residual, _) : _ -> do
              toGeneratedExpression expression @?= Generated.Tuple []
              residual @?= []
              checkExpression (mkQueryClassEnv emptyStaticClassEnv []) [] [] goal [] expression @?= Right ()
            [] -> assertFailure "a concrete intrinsic unit goal had no constructor"
          _ -> assertBool "intrinsic unit inhabited an arbitrary rigid type" $ null candidates
  , testCase "local polymorphic consumers can select intrinsic unit without a declaration" $ do
      let result = TypeVar 0
          consumer = TypeForall [1] [] $ TypeArrow (TypeVar 1) result
          goal = TypeForall [0] [] $ TypeArrow consumer result
          containsUnit expression = case expression of
            Generated.Tuple fields -> null fields || any containsUnit fields
            Generated.Lambda _ body -> containsUnit body
            Generated.Apply function argument -> containsUnit function || containsUnit argument
            Generated.VisibleTypeApplication function _ -> containsUnit function
            Generated.Let _ value body -> containsUnit value || containsUnit body
            Generated.Case value branches -> containsUnit value || any (containsUnit . snd) branches
            _ -> False
      environment <- expectRight $ E.mkExferenceEnvironment $ EnvDictionary [] [] emptyStaticClassEnv
      checked <- expectRight $ E.prepareExferenceQuery environment $
        E.ExferenceQuery goal Set.empty defaultExferenceOptions
          { exferenceMaximumSteps = 4096, exferenceMaximumQueueSize = Just 1024
          , exferenceAllowUnused = True
          , exferenceCandidateRanking = SharedQuality.defaultCandidateRankingPolicy }
      let candidates = take 60 $ concatMap E.chunkElements $ E.findExpressions checked
      (expression, residual, _) <- maybe
        (fail "intrinsic unit was absent from the bounded local-consumer prefix") pure $
          find (\(term, _, _) -> containsUnit $ toGeneratedExpression term) candidates
      residual @?= []
      checkExpression (mkQueryClassEnv emptyStaticClassEnv []) [] [] goal [] expression @?= Right ()
  , testCase "bare provider foralls cross the checked result boundary" $ do
      let unit = TypeTuple Boxed []
          vacuousUnit = TypeForall [] [] unit
          polymorphic = TypeForall [0] [] $ TypeVar 0
          input = identityInput
            { E.input_goalType = TypeArrow polymorphic unit
            , E.input_maxSteps = 100
            }
      chunks <- expectRight
        $ findExpressionsWithIdentifierCapacitiesEither
            (IdentifierCapacities 100 100 100 100) input
      assertBool
        "forall a. a was mistaken for opaque forwarding at a flexible use"
        $ not $ all (null . E.chunkElements) chunks
      wrappedChunks <- expectRight
        $ findExpressionsWithIdentifierCapacitiesEither
            (IdentifierCapacities 100 100 100 100)
            (input {E.input_goalType = TypeArrow polymorphic vacuousUnit})
      assertBool "a vacuous forall wrapper suppressed provider instantiation"
        $ not $ all (null . E.chunkElements) wrappedChunks
      let wrappedOccurrence = ExpLambda 1 polymorphic
            $ ExpVar 1 $ TypeForall [] [] $ TypeVar 2
      checkExpression (mkQueryClassEnv emptyStaticClassEnv []) [] []
        (TypeArrow polymorphic vacuousUnit) [] wrappedOccurrence @?= Right ()
      let distinct = TypeForall [1] []
            $ TypeArrow (TypeVar 1) (TypeVar 1)
      quantifiedChunks <- expectRight
        $ findExpressionsWithIdentifierCapacitiesEither
            (IdentifierCapacities 100 100 100 100)
            (input {E.input_goalType = TypeArrow polymorphic distinct})
      let quantifiedExpressions =
            [ expression
            | chunk <- quantifiedChunks
            , (expression, _, _) <- E.chunkElements chunk
            ]
          requestedOccurrence expression = case expression of
            ExpLambda _ declared (ExpVar _ annotation) ->
              declared == polymorphic && annotation == distinct
            _ -> False
      assertBool "a more-general provider did not subsume a quantified goal"
        $ any requestedOccurrence quantifiedExpressions
      mapM_ (\expression -> checkExpression
          (mkQueryClassEnv emptyStaticClassEnv []) [] []
          (TypeArrow polymorphic distinct) [] expression @?= Right ())
        quantifiedExpressions
      -- Guarded impredicativity end to end: the requested scheme itself
      -- supplies the quantified atom the provider binder is solved with,
      -- and the independent checker accepts every emitted candidate.
      let impredicativeRequested = TypeForall [3] []
            $ TypeArrow
                (TypeForall [4] [] $ TypeArrow (TypeVar 4) (TypeVar 4))
                (TypeForall [5] [] $ TypeArrow (TypeVar 5) (TypeVar 5))
          polymorphicIdentity = TypeForall [1] []
            $ TypeArrow (TypeVar 1) (TypeVar 1)
          impredicativeGoal =
            TypeArrow polymorphicIdentity impredicativeRequested
      impredicativeChunks <- expectRight
        $ findExpressionsWithIdentifierCapacitiesEither
            (IdentifierCapacities 100 100 100 100)
            (input {E.input_goalType = impredicativeGoal})
      let impredicativeExpressions =
            [ expression
            | chunk <- impredicativeChunks
            , (expression, _, _) <- E.chunkElements chunk
            ]
          impredicativeOccurrence expression = case expression of
            ExpLambda _ declared (ExpVar _ annotation) ->
              declared == polymorphicIdentity
                && annotation == impredicativeRequested
            _ -> False
      assertBool "guarded impredicative subsumption found no forwarding"
        $ any impredicativeOccurrence impredicativeExpressions
      mapM_ (\expression -> checkExpression
          (mkQueryClassEnv emptyStaticClassEnv []) [] []
          impredicativeGoal [] expression @?= Right ())
        impredicativeExpressions
  , testCase "quantified provider subsumption stays shallow with guarded impredicativity" $ do
      let integer = TypeCons $ name "Int"
          provider = TypeForall [0, 1] []
            $ TypeArrow (TypeVar 0)
            $ TypeArrow (TypeVar 1) (TypeVar 0)
          specialization = TypeForall [2] []
            $ TypeArrow (TypeVar 2)
            $ TypeArrow (TypeVar 2) (TypeVar 2)
          wrongResult = TypeForall [2, 3] []
            $ TypeArrow (TypeVar 2)
            $ TypeArrow (TypeVar 3) (TypeVar 3)
          lessGeneral = TypeForall [0] []
            $ TypeArrow integer integer
          ordinaryIdentity = TypeForall [2] []
            $ TypeArrow (TypeVar 2) (TypeVar 2)
          impredicative = TypeForall [2] []
            $ TypeArrow
                (TypeForall [3] [] $ TypeArrow (TypeVar 3) (TypeVar 3))
                (TypeForall [4] [] $ TypeArrow (TypeVar 4) (TypeVar 4))
          -- The two quantified atoms differ (the second mentions the
          -- requested binder), so one provider binder cannot cover both.
          correlatedImpredicative = TypeForall [2] []
            $ TypeArrow
                (TypeForall [3] [] $ TypeArrow (TypeVar 3) (TypeVar 3))
                (TypeForall [4] [] $ TypeArrow (TypeVar 4) (TypeVar 2))
          providerIdentity = TypeForall [0] []
            $ TypeArrow (TypeVar 0) (TypeVar 0)
          freeProvider = TypeForall [0] []
            $ TypeArrow (TypeVar 9) (TypeVar 0)
          freeRequested = TypeForall [1] []
            $ TypeArrow (TypeVar 9) (TypeVar 1)
          contextual variable = TypeForall [variable]
            [HsConstraint (name "C") [TypeVar variable]]
            $ TypeVar variable
          rigidProvider = TypeForall [9] [] $ TypeConstant 0
          collidingRequested = TypeForall [0] [] $ TypeVar 0
      quantifiedProviderSubsumes provider specialization @?= True
      quantifiedProviderSubsumes provider wrongResult @?= False
      quantifiedProviderSubsumes lessGeneral ordinaryIdentity @?= False
      -- Guarded impredicativity: the binder is solved with a quantified
      -- atom, but only one the requested scheme itself supplies.
      quantifiedProviderSubsumes providerIdentity impredicative @?= True
      quantifiedProviderSubsumes providerIdentity correlatedImpredicative
        @?= False
      quantifiedProviderSubsumes freeProvider freeRequested @?= False
      quantifiedProviderSubsumes (contextual 0) (contextual 1) @?= False
      quantifiedProviderSubsumes rigidProvider collidingRequested @?= False
  , testCase "provider forall opening preserves nested lexical scopes" $ do
      let outerClass = name "Outer"
          innerClass = name "Inner"
          evidence className variable = HsConstraint className [variable]
          shadowed = TypeForall [0] [evidence outerClass $ TypeVar 0]
            $ TypeForall [0] [evidence innerClass $ TypeVar 0]
            $ TypeVar 0
      case instantiateLeadingForallsWith
          allocateNamespace (supplyFromIdentifiers []) shadowed of
        Just
            ( TypeVar bodyIdentifier
            , [ HsConstraint outerName [TypeVar outerIdentifier]
              , HsConstraint innerName [TypeVar innerIdentifier]
              ]
            , _
            ) -> do
          outerName @?= outerClass
          innerName @?= innerClass
          assertBool "shadowed forall binders reused one fresh identity"
            $ outerIdentifier /= innerIdentifier
          bodyIdentifier @?= innerIdentifier
        actual -> fail $ "unexpected shadowed-forall instantiation: "
          ++ show actual
  , testCase "forall allocation evidence preserves vacuous and shadowed kind owners" $ do
      let proper = SharedKind.ProperTypeKind
          higher = SharedKind.FunctionKind proper proper
          outerClass = name "Outer"
          unit = TypeTuple Boxed []
          nestedValue = TypeForall [3] [] $ TypeArrow (TypeVar 3) (TypeVar 9)
          inner = TypeForall [0] [] $ TypeArrow (TypeApp (TypeVar 0) unit) nestedValue
          source = TypeForall [2, 0] [HsConstraint outerClass [TypeVar 0]] inner
          assumptions = SharedKindInference.KindAssumptions Map.empty $
            Map.singleton outerClass [Just proper]
          initialSupply = supplyFromIdentifiers []
      checked <- expectRight $ SourceKind.prepareSourceTypeKinds assumptions source
        [SourceKind.SourceKindAnnotation [] 0 higher,
         SourceKind.SourceKindAnnotation [SourceKind.ForallBody] 0 higher]
      case instantiateLeadingForallsWithOpenings allocateNamespace initialSupply source of
        Just (body, constraints, openings, finalSupply) -> do
          map leadingForallOpeningBindings openings @?= [[(2, 12), (0, 10)], [(0, 13)]]
          map leadingForallOpeningSource openings @?= [source, inner]
          body @?= TypeArrow (TypeApp (TypeVar 13) unit) nestedValue
          constraints @?= [HsConstraint outerClass [TypeVar 10]]
          -- Slot ownership comes from the independently checked source. A
          -- flattened map keyed by source ID 0 would conflate these kinds;
          -- scanning the result cannot recover the vacuous ID 2 at all.
          let transported =
                [(fresh, Map.lookup (replicate depth SourceKind.ForallBody, slot) $
                    SourceKind.sourceBinderKinds checked)
                | (depth, opening) <- zip [0..] openings
                , (slot, (_, fresh)) <- zip [0..] $ leadingForallOpeningBindings opening]
          transported @?= [(12, Just higher), (10, Just proper), (13, Just higher)]
          instantiateLeadingForallsWith allocateNamespace initialSupply source @?=
            Just (body, constraints, finalSupply)
        Nothing -> assertFailure "the opening discarded available lexical allocation evidence"
  , testCase "forall allocation evidence retains constraint-only telescope steps" $ do
      let outerClass = name "Outer"
          obligation = HsConstraint outerClass [TypeVar 9]
          residual = TypeForall [0] [] $ TypeVar 9
          source = TypeForall [] [obligation] residual
      case instantiateLeadingForallsWithOpenings allocateNamespace (supplyFromIdentifiers []) source of
        Just (body, constraints, openings, _) -> do
          body @?= TypeVar 9
          constraints @?= [obligation]
          map leadingForallOpeningSource openings @?= [source, residual]
          map leadingForallOpeningBindings openings @?= [[], [(0, 10)]]
        Nothing -> assertFailure "constraint-only opening failed"
  , testCase "ground provider evidence separates free and bound identities" $ do
      let outerClass = name "Outer"
          innerClass = name "Inner"
          integer = TypeCons $ name "Int"
          boolean = TypeCons $ name "Bool"
          token = TypeCons $ name "Token"
          evidence className ty = HsConstraint className [ty]
          provider =
            TypeForall [] [evidence outerClass $ TypeVar 0]
              $ TypeForall [0] [evidence innerClass $ TypeVar 0]
                token
          classes =
            [ HsTypeClass outerClass [0] []
            , HsTypeClass innerClass [0] []
            ]
      outerOnly <- expectRight $ mkStaticClassEnv classes
        [HsInstance [] $ evidence outerClass integer]
      complete <- expectRight $ mkStaticClassEnv classes
        [ HsInstance [] $ evidence outerClass integer
        , HsInstance [] $ evidence innerClass boolean
        ]
      groundProviderInstantiations
          (mkQueryClassEnv outerOnly []) provider @?= []
      groundProviderInstantiations
          (mkQueryClassEnv complete []) provider @?=
        [ GroundProviderInstantiation
            { groundProviderArguments = [boolean]
            , groundProviderType = token
            , groundProviderConstraints =
                [ evidence outerClass $ TypeVar 0
                , evidence innerClass boolean
                ]
            }
        ]
  , testCase "query candidates admit only closed context-free foralls" $ do
      let token = TypeCons $ name "Token"
          evidence ty = HsConstraint (name "C") [ty]
          identity binder = TypeForall [binder] []
            $ TypeArrow (TypeVar binder) (TypeVar binder)
          selected = identity 1
          renamed = identity 7
          open = TypeForall [2] []
            $ TypeArrow (TypeVar 2) (TypeVar 3)
          rigidlyOpen = TypeForall [4] []
            $ TypeArrow (TypeVar 4) (TypeConstant 9)
          contextual = TypeForall [5] [evidence $ TypeVar 5]
            $ TypeArrow (TypeVar 5) (TypeVar 5)
          nestedContextual = TypeForall [6] []
            $ TypeArrow
                (TypeForall [8] [evidence $ TypeVar 8]
                  $ TypeVar 8)
                (TypeVar 6)
          provider = TypeForall [0] [] token
      candidateProviderInstantiations
          [selected, renamed, open, rigidlyOpen, contextual, nestedContextual]
          provider @?=
        [ GroundProviderInstantiation
            { groundProviderArguments = [selected]
            , groundProviderType = token
            , groundProviderConstraints = []
            }
        ]
  , testCase "query candidates retain ambient rigids, not flexibles" $ do
      let selected = TypeForall [1] []
            $ TypeArrow (TypeVar 1) (TypeVar 1)
          provider result = TypeForall [0] [] result
          ambientRigid = TypeConstant 9
          ambientFlexible = TypeVar 9
      candidateProviderInstantiations [selected]
          (provider ambientRigid) @?=
        [ GroundProviderInstantiation
            { groundProviderArguments = [selected]
            , groundProviderType = ambientRigid
            , groundProviderConstraints = []
            }
        ]
      candidateProviderInstantiations [selected]
          (provider ambientFlexible) @?= []
  , testCase "exact assignments retain structure, order, and non-vacuous bodies" $ do
      let selected = TypeForall [1] []
            $ TypeArrow (TypeVar 1) (TypeVar 1)
          contextual = TypeForall [15]
            [HsConstraint (name "Eq") [TypeVar 15]]
            $ TypeArrow (TypeVar 15) (TypeVar 15)
          wrapper argument = TypeApp (TypeCons $ name "Wrapper") argument
          provider = TypeForall [0] [] $ wrapper $ TypeVar 0
          contextualProvider = TypeForall [0]
            [HsConstraint (name "C") [TypeVar 0]]
            $ wrapper $ TypeVar 0
          token = TypeCons $ name "Token"
          structural = wrapper selected
          quantified binder body = TypeForall [binder] [] body
          arguments =
            [ quantified 11 $ TypeArrow (TypeVar 11) (TypeVar 11)
            , quantified 12 $ TypeArrow (TypeVar 12) token
            , quantified 13 $ TypeArrow token (TypeVar 13)
            , quantified 14 $ TypeArrow
                (TypeVar 14) (TypeArrow (TypeVar 14) (TypeVar 14))
            ]
          fourBinderProvider = TypeForall [2, 3, 4, 5] [] token
      candidateProviderInstantiations [selected] provider @?= []
      candidateProviderInstantiations [contextual] provider @?= []
      assignmentProviderInstantiations [[selected]] provider @?=
        [ GroundProviderInstantiation
            { groundProviderArguments = [selected]
            , groundProviderType = wrapper selected
            , groundProviderConstraints = []
            }
        ]
      assignmentProviderInstantiations [[contextual]] provider @?=
        [ GroundProviderInstantiation
            { groundProviderArguments = [contextual]
            , groundProviderType = wrapper contextual
            , groundProviderConstraints = []
            }
        ]
      assignmentProviderInstantiations [[selected]] contextualProvider @?= []
      assignmentProviderInstantiations [[structural]]
          (TypeForall [6] [] token) @?=
        [ GroundProviderInstantiation
            { groundProviderArguments = [structural]
            , groundProviderType = token
            , groundProviderConstraints = []
            }
        ]
      assignmentProviderInstantiations [arguments] fourBinderProvider @?=
        [ GroundProviderInstantiation
            { groundProviderArguments = arguments
            , groundProviderType = token
            , groundProviderConstraints = []
            }
        ]
  , testCase "heuristic instantiation stays bounded while exact vectors follow source arity" $ do
      let token = TypeCons $ name "WideToken"
          quantified binder body = TypeForall [binder] [] body
          selected = quantified 10
            $ TypeArrow (TypeVar 10) (TypeVar 10)
          exactArguments =
            [ quantified 11 $ TypeArrow (TypeVar 11) (TypeVar 11)
            , quantified 12 $ TypeArrow (TypeVar 12) token
            , quantified 13 $ TypeArrow token (TypeVar 13)
            , quantified 14 $ TypeArrow
                (TypeVar 14) (TypeArrow (TypeVar 14) (TypeVar 14))
            , quantified 15 $ TypeArrow
                (TypeArrow (TypeVar 15) token) (TypeVar 15)
            , quantified 16 $ TypeArrow
                (TypeVar 16) (TypeArrow token (TypeVar 16))
            ]
          seventhArgument = quantified 17 $ TypeArrow
            (TypeArrow (TypeVar 17) token)
            (TypeArrow token (TypeVar 17))
          sixBinderProvider = TypeForall [0 .. 5] [] token
          sevenBinderProvider = TypeForall [0 .. 6] [] token
      candidateProviderInstantiations [selected] sixBinderProvider @?=
        [ GroundProviderInstantiation
            { groundProviderArguments = replicate 6 selected
            , groundProviderType = token
            , groundProviderConstraints = []
            }
        ]
      assignmentProviderInstantiations [exactArguments]
          sixBinderProvider @?=
        [ GroundProviderInstantiation
            { groundProviderArguments = exactArguments
            , groundProviderType = token
            , groundProviderConstraints = []
            }
        ]
      candidateProviderInstantiations [selected] sevenBinderProvider @?= []
      assignmentProviderInstantiations
          [exactArguments ++ [seventhArgument]] sevenBinderProvider @?=
        [ GroundProviderInstantiation
            { groundProviderArguments = exactArguments ++ [seventhArgument]
            , groundProviderType = token
            , groundProviderConstraints = []
            }
        ]
      assignmentProviderInstantiations [exactArguments] sevenBinderProvider @?= []
      assignmentProviderInstantiations
          [exactArguments ++ [seventhArgument]] sixBinderProvider @?= []
  , testCase "generic deconstructors need no persistent flexible IDs" $ do
      let integer = TypeCons $ name "Int"
          box argument = TypeApp (TypeCons $ name "Box") argument
          deconstructor = DeconstructorBinding
            (box $ TypeVar 0)
            [ConstructorBinding (name "Box") [TypeVar 0]]
            False
          input = identityInput
            { E.input_goalType = TypeArrow (box integer) integer
            , E.input_envDeconsS = [deconstructor]
            }
          capacities = IdentifierCapacities 100 0 100 100
          isBoxElimination candidate = case candidate of
            ( ExpLambda scrutinee _
                (ExpLetMatch constructor [(field, annotation)]
                  (ExpVar matchedScrutinee _)
                  (ExpVar returnedField _))
              , []
              , _
              ) -> constructor == name "Box"
                && matchedScrutinee == scrutinee
                && returnedField == field
                && annotation == integer
            _ -> False
      chunks <- expectRight
        $ findExpressionsWithIdentifierCapacitiesEither capacities input
      finalChunk <- lastChunk "generic Box elimination" chunks
      E.chunkStatus finalChunk @?= E.SearchStatus E.SearchExhausted 0 0
      assertBool "generic Box elimination consumed a flexible ID"
        $ any isBoxElimination $ concatMap E.chunkElements chunks
  , testCase "multi-case deconstructors need no persistent flexible IDs" $ do
      let integer = TypeCons $ name "Int"
          choice argument = TypeApp (TypeCons $ name "Choice") argument
          genericChoice = choice $ TypeVar 0
          integerChoice = choice integer
          leftName = name "First"
          rightName = name "Second"
          deconstructor = DeconstructorBinding genericChoice
            [ ConstructorBinding leftName [TypeVar 0]
            , ConstructorBinding rightName [TypeVar 0]
            ] False
          input = identityInput
            { E.input_goalType = TypeArrow integerChoice integer
            , E.input_envDeconsS = [deconstructor]
            , E.input_multiPM = True
            , E.input_maxSteps = 200
            }
          capacities = IdentifierCapacities 100 0 100 100
          returnsAnnotatedField (_, [(field, annotation)], body) =
            annotation == integer && body == ExpVar field annotation
          returnsAnnotatedField _ = False
          isChoiceElimination candidate = case candidate of
            ( ExpLambda scrutinee _
                (ExpCaseMatch (ExpVar matchedScrutinee _) alternatives)
              , []
              , _
              ) -> matchedScrutinee == scrutinee
                && map (\(constructor, _, _) -> constructor) alternatives
                  == [leftName, rightName]
                && all returnsAnnotatedField alternatives
            _ -> False
      chunks <- expectRight
        $ findExpressionsWithIdentifierCapacitiesEither capacities input
      finalChunk <- lastChunk "generic Choice elimination" chunks
      E.chunkStatus finalChunk @?= E.SearchStatus E.SearchExhausted 0 0
      assertBool "generic Choice elimination consumed a flexible ID"
        $ any isChoiceElimination $ concatMap E.chunkElements chunks
  , testCase "empty elimination consumes no flexible identifier" $ do
      let integer = TypeCons $ name "Int"
          empty argument = TypeApp (TypeCons $ name "Empty") argument
          deconstructor = DeconstructorBinding
            (empty $ TypeVar 0) [] False
          input = identityInput
            { E.input_goalType = TypeArrow (empty integer) integer
            , E.input_envDeconsS = [deconstructor]
            }
      chunks <- expectRight
        $ findExpressionsWithIdentifierCapacitiesEither
            (IdentifierCapacities 100 0 100 100) input
      finalChunk <- lastChunk "empty elimination" chunks
      E.chunkStatus finalChunk @?= E.SearchStatus E.SearchExhausted 0 0
      assertBool "empty elimination required a non-escaping flexible ID"
        $ not $ all (null . E.chunkElements) chunks
  , testCase "empty deconstructors do not suppress provider use" $ do
      let integer = TypeCons $ name "Int"
          monomorphic = TypeArrow integer integer
          polymorphic = TypeForall [0] []
            $ TypeArrow (TypeVar 0) (TypeVar 0)
          emptyInteger = DeconstructorBinding integer [] False
          assertProviderRemainsUsable provider = do
            let input = identityInput
                  { E.input_goalType = TypeArrow provider
                      $ TypeArrow integer integer
                  , E.input_envDeconsS = [emptyInteger]
                  , E.input_maxSteps = 1024
                  }
            chunks <- expectRight
              $ findExpressionsWithIdentifierCapacitiesEither
                  (IdentifierCapacities 100 100 100 100) input
            -- With unused parameters forbidden, every surviving term must use
            -- both the provider and the Int argument. The eager empty-case
            -- branch alone therefore cannot make this assertion pass.
            assertBool
              ("constructorless Int suppressed provider " ++ show provider)
              $ not $ all (null . E.chunkElements) chunks
      mapM_ assertProviderRemainsUsable [monomorphic, polymorphic]
  , testCase "scope identifier collisions are operational truncations" $ do
      chunk <- lastCapacityChunk
        (IdentifierCapacities 100 100 100 1) identityInput
      E.chunkStatus chunk @?=
        E.SearchStatus E.SearchIdentifierSpaceExhausted 0 0
  , testCase "exact progress retains simultaneous step and ID limits" $ do
      let integer = TypeCons $ name "Int"
          boolean = TypeCons $ name "Bool"
          polymorphic = FunctionBinding
            (TypeVar 0) (name "polymorphic") 0 [] []
          deferred = FunctionBinding boolean (name "deferred") 0 [] [integer]
          input = identityInput
            { E.input_goalType = boolean
            , E.input_envFuncs = [polymorphic, deferred]
            -- The root opens even an empty leading forall before the
            -- binding-expansion step under test.
            , E.input_maxSteps = 2
            }
          capacities = IdentifierCapacities 100 0 100 100
      chunk <- lastCapacityChunk capacities input
      E.searchCompletion (E.chunkStatus chunk) @?=
        E.SearchIdentifierSpaceExhausted
      target <- checkedIdentifierTarget "generated"
      environment <- expectRight $ sealLegacyEnvironment input
      results <- expectRight
        $ findQueryResultsWithIdentifierCapacitiesEither
            capacities target
            (emptyExferenceSourceTypeVariableHints $ E.input_goalType input)
            environment (legacyInputQuery input)
      result <- lastResult results
      let batch = SharedQuery.resultSearch result
      SharedQuery.resultEvidence result @?= SharedQuery.NoEvidence
      SharedSearch.batchProgress batch @?= SharedSearch.Completed
        (SharedSearch.Truncated
          $ SharedSearch.StepLimitReached
            :| [SharedSearch.IdentifierSpaceExhausted])
  , testCase "queue representation overflow retains the best priorities" $ do
      let queued = [(2, 20)]
          generated = [(3, 30), (1, 10)]
      mergePriorityQueueAtCapacity 3 Nothing queued generated @?=
        ([(3, 30), (2, 20), (1, 10)], 0)
      mergePriorityQueueAtCapacity 2 Nothing queued generated @?=
        ([(3, 30), (2, 20)], 1)
      mergePriorityQueueAtCapacity 2 (Just 1) queued generated @?=
        ([(3, 30)], 2)
      mergePriorityQueueAtCapacity 3 (Just (-1)) queued generated @?=
        ([], 3)
  , testCase "compatibility pruning counts saturate without losing reasons" $ do
      let maximumCount = fromIntegral (maxBound :: Int) :: Natural
          queueTotal = maximumCount + 1
          depthTotal = maximumCount + 2
          binding = name "usedBinding"
      compatibilityPruningCount (maximumCount - 1) @?= maxBound - 1
      compatibilityPruningCount maximumCount @?= maxBound
      compatibilityPruningCount queueTotal @?= maxBound
      compatibilityBindingUsageCounts
          (Map.singleton binding queueTotal) @?=
        Map.singleton binding maxBound
      pruningReasonsFromNaturalTotals queueTotal depthTotal @?=
        [ SharedSearch.QueueLimitPruned queueTotal
        , SharedSearch.DepthLimitPruned depthTotal
        ]
  , testCase "structural tuple ranking exactly preserves applications" $ do
      tupleConstructor <- expectRight $ SharedName.tupleName Boxed 3
      let elements =
            [ TypeVar 0
            , TypeConstant 1
            , TypeArrow (TypeVar 2) (TypeConstant 3)
            ]
          structural = TypeTuple Boxed elements
          legacy = foldl TypeApp (TypeCons tupleConstructor) elements
          fractional = defaultHeuristicsConfig
            { heuristics_goalVar = 0.1
            , heuristics_goalCons = 0.2
            , heuristics_goalArrow = 0.3
            , heuristics_goalApp = 0.4
            }
          near divisor = Penalty
            $ Score.penaltyValue Score.maxPenalty / divisor
          nearSaturation = defaultHeuristicsConfig
            { heuristics_goalVar = near 13
            , heuristics_goalCons = near 11
            , heuristics_goalArrow = near 9
            , heuristics_goalApp = near 7
            }
          complexity config = typeComplexityForTesting config
      assertEqual "fractional accumulation order"
        (complexity fractional legacy)
        (complexity fractional structural)
      assertEqual "near-saturation accumulation order"
        (complexity nearSaturation legacy)
        (complexity nearSaturation structural)
  , testCase "checker seals exact context-free visible specialization evidence" $ do
      let integer = TypeCons $ name "Int"
          provider = TypeForall [0] []
            $ TypeArrow (TypeVar 0) (TypeVar 0)
          result = TypeArrow integer integer
          goal = TypeArrow provider result
      argument <- expectRight $ Generated.specifiedVisibleTypeArgument integer
      let expression = ExpLambda 1 provider
            $ ExpTypeApply (ExpVar 1 provider) argument
      evidence <- checkedEvidence emptyStaticClassEnv [] [] goal expression
      null (checkedExpressionTypeApplicationOrigins evidence) @?= True
      checkedExpressionTypeApplicationOriginReferences evidence @?= []
      let availability = checkedExpressionTermGraph 23 evidence
      availability @?= checkedExpressionTermGraph 23 evidence
      case availability of
        ExferenceTermGraphUnavailable reason -> fail
          $ "context-free visible application had no typed graph: "
          ++ show reason
        ExferenceTermGraphAvailable graph -> do
          Typed.eraseTermGraph graph @?=
            Generated.discardUnusedPatternBindingsBy id
              (toGeneratedExpression expression)
          Typed.typedGraphVisibleTypeApplications
              (Typed.termGraphMetrics graph) @?= 1
          let witnesses =
                [ witness
                | (_, Typed.TermNode _
                    (Typed.TypedVisibleTypeApplication _ _ _ witness)) <-
                      Typed.termGraphNodes graph
                ]
          witnesses @?=
            [Typed.TypeApplicationWitness provider integer result Nothing]
          case checkedExpressionTermGraph 24 evidence of
            ExferenceTermGraphAvailable distinctGraph -> assertBool
              "different candidate keys reused one term-node identity"
              $ Typed.termGraphRoot distinctGraph /= Typed.termGraphRoot graph
            ExferenceTermGraphAssociated _ -> fail
              "local visible specialization gained global certificate authority"
            ExferenceTermGraphUnavailable reason -> fail
              $ "changing only the candidate key lost the graph: " ++ show reason
        ExferenceTermGraphAssociated _ -> fail
          "local visible specialization gained global certificate authority"
  , testCase "checker retains exact direct-global specialization origins" $ do
      let integer = TypeCons $ name "Int"
          boolean = TypeCons $ name "Bool"
          providerName = name "specialize"
          provider = TypeForall [0, 1] []
            $ TypeArrow (TypeVar 0)
            $ TypeArrow (TypeVar 1) (TypeVar 0)
          firstResult = TypeForall [1] []
            $ TypeArrow integer
            $ TypeArrow (TypeVar 1) integer
          result = TypeArrow integer $ TypeArrow boolean integer
      (bindings, schemes) <- preparedValueEnvironment providerName provider
      integerArgument <- expectRight
        $ Generated.specifiedVisibleTypeArgument integer
      booleanArgument <- expectRight
        $ Generated.specifiedVisibleTypeArgument boolean
      let expression = ExpTypeApply
            (ExpTypeApply (ExpName providerName) integerArgument)
            booleanArgument
      evidence <- checkedEvidenceWithSchemes emptyStaticClassEnv
        bindings [] schemes result expression
      checkedExpressionTypeApplicationOriginReferences evidence @?=
        [(0, 0), (0, 1)]
      case checkedExpressionTypeApplicationOrigins evidence of
        [origin] -> do
          checkedTypeApplicationOriginId origin @?= 0
          checkedTypeApplicationOriginOwner origin @?= providerName
          checkedTypeApplicationOriginSource origin @?= provider
          case checkedTypeApplicationOriginSteps origin of
            [first, second] -> do
              checkedTypeApplicationOriginStepSlot first @?= 0
              checkedTypeApplicationOriginStepSource first @?= provider
              checkedTypeApplicationOriginStepSelected first @?= integer
              checkedTypeApplicationOriginStepResult first @?= firstResult
              checkedTypeApplicationOriginStepObligations first @?= []
              checkedTypeApplicationOriginStepSlot second @?= 1
              checkedTypeApplicationOriginStepSource second @?= firstResult
              checkedTypeApplicationOriginStepSelected second @?= boolean
              checkedTypeApplicationOriginStepResult second @?= result
              checkedTypeApplicationOriginStepObligations second @?= []
            steps -> fail $ "unexpected retained specialization steps: "
              ++ show (length steps)
        origins -> fail $ "unexpected direct-global origin count: "
          ++ show (length origins)
      case checkedExpressionTermGraph 41 evidence of
        ExferenceTermGraphUnavailable reason -> fail
          $ "origin-bearing specialization lost its graph: " ++ show reason
        ExferenceTermGraphAvailable _ -> fail
          "origin-bearing specialization was downgraded to a plain graph"
        ExferenceTermGraphAssociated checked -> do
          let graph =
                Association.checkedTypeApplicationCertificateGraph checked
              associated = ExferenceTermGraphAssociated checked
              plain = ExferenceTermGraphAvailable graph
              legacyShow :: Int -> ShowS
              legacyShow precedence = showParen (precedence > 10)
                $ showString "ExferenceTermGraphAvailable" . showChar ' '
                . showsPrec 11 graph
          associated @?= plain
          show associated @?= show plain
          showsPrec 11 associated "" @?= showsPrec 11 plain ""
          showsPrec 0 associated "" @?= legacyShow 0 ""
          showsPrec 11 associated "" @?= legacyShow 11 ""
          (ExferenceTermGraphUnavailable TermGraphEvidenceMismatch ==
              ExferenceTermGraphAssociated
                (error "availability equality forced associated payload"))
            @?= False
          _ <- evaluate $ force associated
          let kinds = [(TypeVar 0, SharedKind.ProperTypeKind)]
              kindedCandidate = TypedCandidate.mkKindedCertificateCapableTypedCandidate () $
                Right (Right checked, kinds) `asTypeOf` Left ("" :: String)
              poisoned = TypedCandidate.mkKindedCertificateCapableTypedCandidate ()
                (error "compatibility forced certificate/kind availability")
                  `asTypeOf` kindedCandidate
          TypedCandidate.typedCandidateCompatibility poisoned @?= ()
          TypedCandidate.typedCandidateBinderKinds kindedCandidate @?=
            (Right kinds :: Either String [(HsType, SharedKindInference.GroundKind)])
          TypedCandidate.typedCandidateTermGraph kindedCandidate @?= Right graph
          TypedCandidate.foldTypedCandidateGraph
            (\_ _ -> False) (\_ _ -> False) (\_ _ -> True) kindedCandidate @?= True
          _ <- evaluate $ force kindedCandidate
          let witnesses =
                [ witness
                | (_, Typed.TermNode _
                    (Typed.TypedVisibleTypeApplication _ _ _ witness)) <-
                      Typed.termGraphNodes graph
                ]
          length witnesses @?= 2
          map Typed.typeApplicationCertificate witnesses @?=
            [ Just (Typed.certificateId 0, 1)
            , Just (Typed.certificateId 0, 0)
            ]
          let rows = Association.foldCheckedTypeApplicationCertificateGraph
                (\retained certificate owner scheme baseNode baseOccurrence
                    receipts -> retained ++
                  [ ( certificate
                    , owner
                    , scheme
                    , Typed.termNodeIdValue baseNode
                    , Typed.occurrenceIdValue baseOccurrence
                    , [ ( Certificate.checkedTypeApplicationCertificateStepSlot
                            step
                        , Typed.termNodeIdValue node
                        , Typed.occurrenceIdValue occurrence
                        )
                      | (node, occurrence, step) <- receipts
                      ]
                    )
                  ]) [] checked
          rows @?=
            [ ( Typed.certificateId 0
              , providerName
              , provider
              , paired 41 2
              , paired 41 2
              , [ (0, paired 41 1, paired 41 1)
                , (1, paired 41 0, paired 41 0)
                ]
              )
            ]
          Fingerprint.fingerprintSharedTermGraph
              Typed.defaultTermGraphLimits
              Fingerprint.defaultTermGraphFingerprintByteLimit graph @?=
            Left (Fingerprint.TermGraphFingerprintUnsupportedCertificate
              $ Typed.certificateId 0)
  , testCase "specialization origins retain activated source constraints" $ do
      let className = name "C"
          providerName = name "contextual"
          integer = TypeCons $ name "Int"
          token = TypeCons $ name "Token"
          constraint ty = HsConstraint className [ty]
          provider = TypeForall [0] [constraint $ TypeVar 0] token
      (bindings, schemes) <- preparedValueEnvironment providerName provider
      classes <- expectRight $ mkStaticClassEnv
        [HsTypeClass className [0] []]
        [HsInstance [] $ constraint integer]
      argument <- expectRight
        $ Generated.specifiedVisibleTypeArgument integer
      let expression = ExpTypeApply (ExpName providerName) argument
      evidence <- checkedEvidenceWithSchemes classes bindings [] schemes
        token expression
      case checkedExpressionTypeApplicationOrigins evidence of
        [origin] -> case checkedTypeApplicationOriginSteps origin of
          [step] ->
            checkedTypeApplicationOriginStepObligations step @?=
              [constraint integer]
          steps -> fail $ "unexpected contextual step count: "
            ++ show (length steps)
        origins -> fail $ "unexpected contextual origin count: "
          ++ show (length origins)
      checkedExpressionTypeApplicationOriginReferences evidence @?= [(0, 0)]
      case checkedExpressionTermGraph 42 evidence of
        ExferenceTermGraphUnavailable reason -> fail
          $ "contextual origin lost its associated graph: " ++ show reason
        ExferenceTermGraphAvailable _ -> fail
          "contextual origin was downgraded to a plain graph"
        ExferenceTermGraphAssociated checked -> do
          let graph =
                Association.checkedTypeApplicationCertificateGraph checked
              obligations =
                Association.foldCheckedTypeApplicationCertificateGraph
                  (\retained _ _ _ _ _ receipts -> retained ++
                    [ [ Certificate.checkedTypeApplicationCertificateStepObligations
                          step
                      | (_, _, step) <- receipts
                      ]
                    ]) [] checked
          obligations @?=
            [ [ [ SharedConstraint.Constraint className
                    [fmap Certificate.TypeApplicationCertificateFree integer]
                ]
              ]
            ]
          let certificates =
                [ Typed.typeApplicationCertificate witness
                | (_, Typed.TermNode _
                    (Typed.TypedVisibleTypeApplication _ _ _ witness)) <-
                      Typed.termGraphNodes graph
                ]
          certificates @?= [Just (Typed.certificateId 0, 0)]
  , testCase "scheme-backed query results retain the associated carrier" $ do
      let integer = TypeCons $ name "Int"
          token = TypeCons $ name "Token"
          providerName = name "querySpecialize"
          provider = TypeForall [0] [] token
          input = identityInput
            { E.input_goalType = token
            , E.input_maxSteps = 20
            }
      (bindings, schemes) <- preparedValueEnvironment providerName provider
      environment <- expectRight $ E.mkExferenceEnvironmentWithSchemes
        (EnvDictionary bindings [] emptyStaticClassEnv) schemes
      target <- checkedIdentifierTarget "queryAssociatedResult"
      options <- expectRight $ E.checkExferenceOptions
        $ E.querySearchOptions $ legacyInputQuery input
      let observe assignments = do
            results <- expectRight $
              E.findTypedQueryResultsInEnvironmentWithCheckedOptionsAndAssignments
                assignments
                target
                (emptyExferenceSourceTypeVariableHints token)
                environment
                (legacyInputQuery input)
                options
            let candidates = concatMap
                  (SharedSearch.batchCandidates . SharedQuery.resultSearch)
                  results
            pure
              [ TypedCandidate.foldTypedCandidateGraph
                  (\_ _ -> "unavailable")
                  (\_ _ -> "plain")
                  (\_ checked ->
                    if null $
                        Association.foldCheckedTypeApplicationCertificateGraph
                          (\rows _ _ _ _ _ receipts -> receipts : rows)
                          [] checked
                      then "associated-empty"
                      else "associated")
                  candidate
              | candidate <- candidates
              ]
      assigned <- observe $ Map.singleton providerName [[integer]]
      take 2 assigned @?= ["associated", "plain"]
      unassigned <- observe Map.empty
      take 1 unassigned @?= ["plain"]
      unusable <- observe $ Map.singleton providerName [[]]
      unusable @?= unassigned
  , testCase "source constraints activate before a selected polytype suffix" $ do
      let className = name "C"
          providerName = name "polyContextual"
          integer = TypeCons $ name "Int"
          selected = TypeForall [7] [] $ TypeVar 7
          constraint ty = HsConstraint className [ty]
          provider = TypeForall [0] [constraint $ TypeVar 0] $ TypeVar 0
      (bindings, schemes) <- preparedValueEnvironment providerName provider
      classes <- expectRight $ mkStaticClassEnv
        [HsTypeClass className [0] []]
        [HsInstance [] $ constraint selected]
      selectedArgument <- expectRight
        $ Generated.specifiedVisibleTypeArgument selected
      integerArgument <- expectRight
        $ Generated.specifiedVisibleTypeArgument integer
      let expression = ExpTypeApply
            (ExpTypeApply (ExpName providerName) selectedArgument)
            integerArgument
      evidence <- checkedEvidenceWithSchemes classes bindings [] schemes
        integer expression
      checkedExpressionTypeApplicationOriginReferences evidence @?= [(0, 0)]
      case checkedExpressionTypeApplicationOrigins evidence of
        [origin] -> case checkedTypeApplicationOriginSteps origin of
          [step] -> do
            assertBool "selected polytype result changed alpha-structure"
              $ SharedTypeAtom.alphaEquivalentTypes
                  (checkedTypeApplicationOriginStepResult step) selected
            case checkedTypeApplicationOriginStepObligations step of
              [HsConstraint retainedClass [retainedSelected]] -> do
                retainedClass @?= className
                assertBool "source obligation lost the selected polytype"
                  $ SharedTypeAtom.alphaEquivalentTypes
                      retainedSelected selected
              obligations -> fail $ "unexpected selected-polytype obligations: "
                ++ show obligations
          steps -> fail $ "returned-polytype source step count changed: "
            ++ show (length steps)
        origins -> fail $ "returned-polytype origin count changed: "
          ++ show (length origins)
      case checkedExpressionTermGraph 43 evidence of
        ExferenceTermGraphAssociated checked -> do
          let certificates =
                [ Typed.typeApplicationCertificate witness
                | (_, Typed.TermNode _
                    (Typed.TypedVisibleTypeApplication _ _ _ witness)) <-
                      Typed.termGraphNodes
                        $ Association.checkedTypeApplicationCertificateGraph
                            checked
                ]
              retained =
                Association.foldCheckedTypeApplicationCertificateGraph
                  (\rows _ _ _ _ _ receipts -> receipts : rows) [] checked
          certificates @?= [Nothing, Just (Typed.certificateId 0, 0)]
          case retained of
            [[(_, _, step)]] -> do
              Certificate.checkedTypeApplicationCertificateStepSlot step @?= 0
              assertBool "associated suffix changed the selected polytype"
                $ SharedTypeAtom.alphaEquivalentTypes
                    (Certificate.checkedTypeApplicationCertificateStepSelected
                      step)
                    (fmap Certificate.TypeApplicationCertificateFree selected)
              case Certificate.checkedTypeApplicationCertificateStepObligations
                  step of
                [SharedConstraint.Constraint retainedClass [retainedSelected]] -> do
                  retainedClass @?= className
                  assertBool "associated suffix changed the source obligation"
                    $ SharedTypeAtom.alphaEquivalentTypes retainedSelected
                        (fmap Certificate.TypeApplicationCertificateFree selected)
                obligations -> fail $ "unexpected associated suffix obligations: "
                  ++ show obligations
            rows -> fail $ "returned suffix retained the wrong receipt chain: "
              ++ show (map length rows)
        ExferenceTermGraphAvailable _ -> fail
          "returned-polymorphic origin was downgraded to a plain graph"
        ExferenceTermGraphUnavailable reason -> fail
          $ "returned-polymorphic origin lost association: " ++ show reason

      -- The same source step must activate before any suffix exists.  This
      -- pins the checker correction which decides continuation from the raw
      -- source body, never from a replacement-introduced forall.
      noSuffix <- checkedEvidenceWithSchemes classes bindings [] schemes
        (TypeTuple Boxed [selected, TypeTuple Boxed []])
        (ExpTuple
          [ ExpTypeApply (ExpName providerName) selectedArgument
          , ExpTuple []
          ])
      checkedExpressionTypeApplicationOriginReferences noSuffix @?= [(0, 0)]
      case checkedExpressionTypeApplicationOrigins noSuffix of
        [origin] -> case checkedTypeApplicationOriginSteps origin of
          [step] -> do
            assertBool "no-suffix selected result changed alpha-structure"
              $ SharedTypeAtom.alphaEquivalentTypes
                  (checkedTypeApplicationOriginStepResult step) selected
            case checkedTypeApplicationOriginStepObligations step of
              [HsConstraint retainedClass [retainedSelected]] -> do
                retainedClass @?= className
                assertBool "no-suffix source obligation changed selection"
                  $ SharedTypeAtom.alphaEquivalentTypes
                      retainedSelected selected
              obligations -> fail $ "unexpected no-suffix obligations: "
                ++ show obligations
          steps -> fail $ "unexpected no-suffix step count: "
            ++ show (length steps)
        origins -> fail $ "unexpected no-suffix origin count: "
          ++ show (length origins)
      case checkedExpressionTermGraph 50 noSuffix of
        ExferenceTermGraphAssociated checked ->
          map (Certificate.checkedTypeApplicationCertificateStepSlot . third)
            (concat $ Association.foldCheckedTypeApplicationCertificateGraph
              (\rows _ _ _ _ _ receipts -> receipts : rows) [] checked)
            @?= [0]
        ExferenceTermGraphAvailable _ -> fail
          "no-suffix source origin was downgraded to a plain graph"
        ExferenceTermGraphUnavailable reason -> fail
          $ "no-suffix source origin lost association: " ++ show reason
  , testCase "incomplete and compatibility visible spines stay origin-free" $ do
      let integer = TypeCons $ name "Int"
          boolean = TypeCons $ name "Bool"
          providerName = name "boundedSpecialize"
          provider = TypeForall [0, 1] []
            $ TypeArrow (TypeVar 0) (TypeVar 1)
      (bindings, schemes) <- preparedValueEnvironment providerName provider
      integerArgument <- expectRight
        $ Generated.specifiedVisibleTypeArgument integer
      booleanArgument <- expectRight
        $ Generated.specifiedVisibleTypeArgument boolean
      let remaining = TypeForall [1] [] $ TypeArrow integer $ TypeVar 1
          partialExpression = ExpTypeApply
            (ExpName providerName) integerArgument
      partial <- checkedEvidenceWithSchemes emptyStaticClassEnv bindings []
        schemes (TypeTuple Boxed [remaining, TypeTuple Boxed []])
        (ExpTuple [partialExpression, ExpTuple []])
      null (checkedExpressionTypeApplicationOrigins partial) @?= True
      checkedExpressionTypeApplicationOriginReferences partial @?= []
      expectPlainGraph "partial source telescope" 44 partial
      inferred <- checkedEvidenceWithSchemes emptyStaticClassEnv bindings []
        schemes (TypeArrow integer boolean)
        (ExpTypeApply
          (ExpTypeApply (ExpName providerName)
            Generated.inferredVisibleTypeArgument)
          booleanArgument)
      null (checkedExpressionTypeApplicationOrigins inferred) @?= True
      expectPlainGraph "inferred visible prefix" 45 inferred
      let fallbackName = name "compatibilityPolytype"
          fallbackScheme = TypeForall [0] [] $ TypeVar 0
          fallbackBinding = FunctionBinding fallbackScheme fallbackName 0 [] []
      compatibility <- checkedEvidence emptyStaticClassEnv [fallbackBinding] []
        integer (ExpTypeApply (ExpName fallbackName) integerArgument)
      null (checkedExpressionTypeApplicationOrigins compatibility) @?= True
      expectPlainGraph "compatibility fallback" 46 compatibility
  , testCase "origin eligibility is closed source-arity-directed and post-constraint" $ do
      let integer = TypeCons $ name "Int"
          boolean = TypeCons $ name "Bool"
          token = TypeCons $ name "Token"
          className = name "C"
          constraint ty = HsConstraint className [ty]
          specified ty = expectRight
            $ Generated.specifiedVisibleTypeArgument ty
      arguments <- mapM specified
        [ TypeCons $ name ("T" ++ show index)
        | index <- [0 :: Int .. 6]
        ]

      let sixName = name "sixOrigin"
          sixScheme = TypeForall [0 .. 5] [] token
      (sixBindings, sixSchemes) <- preparedValueEnvironment sixName sixScheme
      sixEvidence <- checkedEvidenceWithSchemes emptyStaticClassEnv sixBindings []
        sixSchemes token
        (foldl ExpTypeApply (ExpName sixName) $ take 6 arguments)
      length (checkedExpressionTypeApplicationOrigins sixEvidence) @?= 1
      checkedExpressionTypeApplicationOriginReferences sixEvidence @?=
        [(0, slot) | slot <- [0 .. 5]]
      case checkedExpressionTermGraph 47 sixEvidence of
        ExferenceTermGraphAssociated checked -> do
          let graph =
                Association.checkedTypeApplicationCertificateGraph checked
              certificates =
                [ Typed.typeApplicationCertificate witness
                | (_, Typed.TermNode _
                    (Typed.TypedVisibleTypeApplication _ _ _ witness)) <-
                      Typed.termGraphNodes graph
                ]
          certificates @?=
            [Just (Typed.certificateId 0, slot) | slot <- [5, 4 .. 0]]
          map (Certificate.checkedTypeApplicationCertificateStepSlot . third)
            (concat $ Association.foldCheckedTypeApplicationCertificateGraph
              (\rows _ _ _ _ _ receipts -> receipts : rows) [] checked)
            @?= [0 .. 5]
        ExferenceTermGraphAvailable _ -> fail
          "six-slot exact origin was downgraded to a plain graph"
        ExferenceTermGraphUnavailable reason -> fail
          $ "six-slot exact origin lost association: " ++ show reason

      let sevenName = name "sevenOrigin"
          sevenScheme = TypeForall [0 .. 6] [] token
      (sevenBindings, sevenSchemes) <- preparedValueEnvironment
        sevenName sevenScheme
      sevenEvidence <- checkedEvidenceWithSchemes emptyStaticClassEnv
        sevenBindings [] sevenSchemes token
        (foldl ExpTypeApply (ExpName sevenName) arguments)
      length (checkedExpressionTypeApplicationOrigins sevenEvidence) @?= 1
      checkedExpressionTypeApplicationOriginReferences sevenEvidence @?=
        [(0, slot) | slot <- [0 .. 6]]
      case checkedExpressionTermGraph 48 sevenEvidence of
        ExferenceTermGraphAssociated checked ->
          map (Certificate.checkedTypeApplicationCertificateStepSlot . third)
            (concat $ Association.foldCheckedTypeApplicationCertificateGraph
              (\rows _ _ _ _ _ receipts -> receipts : rows) [] checked)
            @?= [0 .. 6]
        ExferenceTermGraphAvailable _ -> fail
          "seven-slot exact origin was downgraded to a plain graph"
        ExferenceTermGraphUnavailable reason -> fail
          $ "seven-slot exact origin lost association: " ++ show reason

      -- A deliberately open retained scheme can satisfy the structural
      -- sidecar check, but cannot own a closed specialization origin.
      let openName = name "openOrigin"
          openScheme = TypeForall [0] []
            $ TypeArrow (TypeVar 0) (TypeVar 9)
      (openBindings, openSchemes) <- preparedValueEnvironment
        openName openScheme
      integerArgument <- specified integer
      openEvidence <- checkedEvidenceWithSchemes emptyStaticClassEnv
        openBindings [] openSchemes (TypeArrow integer $ TypeVar 9)
        (ExpTypeApply (ExpName openName) integerArgument)
      null (checkedExpressionTypeApplicationOrigins openEvidence) @?= True

      constrainedClasses <- expectRight $ mkStaticClassEnv
        [HsTypeClass className [0] []]
        [HsInstance [] $ constraint integer]
      let constrainedName = name "constraintGate"
          constrainedScheme = TypeForall [0]
            [constraint $ TypeVar 0] token
      (constrainedBindings, constrainedSchemes) <- preparedValueEnvironment
        constrainedName constrainedScheme
      booleanArgument <- specified boolean
      plan <- expectRight $ planRigidInstantiation
        (mkRigidInstantiationContext
          $ EnvDictionary constrainedBindings [] constrainedClasses)
        [] token
      context <- expectRight $ prepareExpressionCheckContextWithSchemes plan
        (mkQueryClassEnv constrainedClasses []) constrainedBindings []
        constrainedSchemes token
      case checkExpressionInContextWithNestedRigidProvenanceEvidence
          context (nestedRigidProvenance emptyRigidScope) []
          (ExpTypeApply (ExpName constrainedName) booleanArgument) of
        Left failure -> failure @?=
          ConstraintMismatch [] [constraint boolean]
        Right _ -> fail "an unsatisfied origin escaped the constraint gate"
  , testCase "association row limits fail closed without a plain downgrade" $ do
      let token = TypeCons $ name "Token"
          integer = TypeCons $ name "Int"
          providerName = name "manyOrigins"
          provider = TypeForall [0] [] token
      (bindings, schemes) <- preparedValueEnvironment providerName provider
      argument <- expectRight $ Generated.specifiedVisibleTypeArgument integer
      let application = ExpTypeApply (ExpName providerName) argument
          expression = ExpTuple $ replicate 33 application
          goal = TypeTuple Boxed $ replicate 33 token
      evidence <- checkedEvidenceWithSchemes emptyStaticClassEnv bindings []
        schemes goal expression
      length (checkedExpressionTypeApplicationOrigins evidence) @?= 33
      checkedExpressionTermGraph 49 evidence @?=
        ExferenceTermGraphUnavailable
          (TermGraphCertificateAssociationFailure
            TermGraphCertificatePlanLimitFailure)
  , testCase "failed preferred inference rolls origin state back" $ do
      let integer = TypeCons $ name "Int"
          providerName = name "transactionalOrigin"
          provider = TypeForall [0] []
            $ TypeArrow (TypeVar 0) (TypeVar 0)
          selected = TypeArrow integer integer
          nestedExpected = TypeForall [9] [] selected
      (bindings, schemes) <- preparedValueEnvironment providerName provider
      argument <- expectRight
        $ Generated.specifiedVisibleTypeArgument integer
      let visible = ExpTypeApply (ExpName providerName) argument
          expression = ExpLambda 20 integer visible
      evidence <- checkedEvidenceWithSchemes emptyStaticClassEnv bindings []
        schemes (TypeArrow integer nestedExpected) expression
      case checkedExpressionTypeApplicationOrigins evidence of
        [origin] -> do
          checkedTypeApplicationOriginId origin @?= 0
          checkedTypeApplicationOriginOwner origin @?= providerName
          map checkedTypeApplicationOriginStepSlot
            (checkedTypeApplicationOriginSteps origin) @?= [0]
        origins -> fail $ "transactional retry retained ghost origins: "
          ++ show (length origins)
      -- The successful independent introduction retains exactly its own
      -- visible-origin reference; the abandoned preferred inference adds none.
      checkedExpressionTypeApplicationOriginReferences evidence @?= [(0, 0)]
      case checkedExpressionTermGraph 61 evidence of
        ExferenceTermGraphAssociated checked -> do
          let graph = Association.checkedTypeApplicationCertificateGraph checked
          Typed.eraseTermGraph graph @?=
            Generated.discardUnusedPatternBindingsBy id
              (toGeneratedExpression expression)
        other -> fail $ "transactional introduction lost its exact origin: "
          ++ show other
  , testCase "checker retains complete constructor cases with exact field authority" $ do
      let payload = TypeCons $ name "Payload"
          spineName = name "Spine"
          zeroName = name "SpineZero"
          stepName = name "SpineStep"
          spine = TypeApp (TypeCons spineName) payload
          zero = FunctionBinding spine zeroName 0 [] []
          step = FunctionBinding spine stepName 0 [] [payload, spine]
          exactDeconstructor = DeconstructorBinding spine
            [ ConstructorBinding zeroName []
            , ConstructorBinding stepName [payload, spine]
            ] True
          ordinaryDeconstructor = exactDeconstructor
            { deconstructorRecursive = False }
          goal = TypeArrow spine spine
          expression = ExpLambda 1 spine
            $ ExpCaseMatch (ExpVar 1 spine)
                [ (zeroName, [], ExpName zeroName)
                , ( stepName
                  , [(2, payload), (3, spine)]
                  , ExpVar 3 spine
                  )
                ]
          functions = [zero, step]
      evidence <- checkedEvidence emptyStaticClassEnv functions
        [exactDeconstructor] goal expression
      case checkedExpressionTermGraph 29 evidence of
        ExferenceTermGraphUnavailable reason -> fail
          $ "exact zero-step spine case had no typed graph: " ++ show reason
        ExferenceTermGraphAssociated _ -> fail
          "certificate-free exact case gained specialization authority"
        ExferenceTermGraphAvailable graph -> do
          Typed.eraseTermGraph graph @?=
            Generated.discardUnusedPatternBindingsBy id
              (toGeneratedExpression expression)
          Typed.typedGraphCases (Typed.termGraphMetrics graph) @?= 1
          case
              [ alternatives
              | (_, Typed.TermNode _ (Typed.TypedCase _ alternatives)) <-
                  Typed.termGraphNodes graph
              ] of
            [[(_, _), (stepPattern, _)]] -> case
                Typed.typedPatternNode stepPattern of
              Typed.TypedConstructor retainedName [payloadPattern, tailPattern] -> do
                retainedName @?= stepName
                Typed.typedPatternNode payloadPattern @?= Typed.TypedWildcard
                case Typed.typedPatternNode tailPattern of
                  Typed.TypedBind{} -> pure ()
                  actual -> fail $ "recursive field lost its binder: "
                    ++ show actual
              actual -> fail $ "unexpected retained step pattern: " ++ show actual
            actual -> fail $ "unexpected retained case graph: " ++ show actual

      ordinaryEvidence <- checkedEvidence emptyStaticClassEnv functions
        [ordinaryDeconstructor] goal expression
      expectPlainGraph "nonrecursive complete case" 30 ordinaryEvidence
      -- Competing fragments of one datatype are rejected before any branch
      -- can acquire constructor authority from the combined inventory.
      case checkExpression (mkQueryClassEnv emptyStaticClassEnv []) functions
          [exactDeconstructor { deconstructorConstructors = [constructor] }
          | constructor <- deconstructorConstructors exactDeconstructor]
          goal [] expression of
        Left InvalidCheckEnvironmentBindings{} -> pure ()
        other -> fail $ "split constructor inventory crossed preparation: " ++ show other

      let token = TypeCons $ name "CaseToken"
          tokenName = name "caseToken"
          tokenProvider = FunctionBinding token tokenName 0 [] []
          observer alternatives = ExpLambda 1 spine
            $ ExpCaseMatch (ExpVar 1 spine) alternatives
          zeroAlternative = (zeroName, [], ExpName tokenName)
          stepAlternative = (stepName, [(2, payload), (3, spine)], ExpName tokenName)
      observerEvidence <- checkedEvidence emptyStaticClassEnv
        (tokenProvider : functions) [exactDeconstructor]
        (TypeArrow spine token) $ observer [zeroAlternative, stepAlternative]
      expectPlainGraph "case result independent of its scrutinee" 31 observerEvidence
      mapM_ (\alternatives -> do
          partialEvidence <- checkedEvidence emptyStaticClassEnv
            (tokenProvider : functions) [exactDeconstructor]
            (TypeArrow spine token) $ observer alternatives
          expectUnavailable "partial or duplicate alternatives cannot own case evidence"
            (== NominalConstructorPattern zeroName) partialEvidence)
        [[zeroAlternative], [zeroAlternative, zeroAlternative]]
      partialLetEvidence <- checkedEvidence emptyStaticClassEnv functions
        [exactDeconstructor] (TypeArrow spine spine)
        (ExpLambda 1 spine $ ExpLetMatch stepName [(2, payload), (3, spine)]
          (ExpVar 1 spine) $ ExpVar 3 spine)
      expectUnavailable "one constructor of a sum cannot own total let evidence"
        (== NominalConstructorPattern stepName) partialLetEvidence

      -- Shared generated-expression validation forbids one local identity
      -- from being rebound anywhere in a candidate. Keep that stronger raw
      -- boundary explicit even though checked-term free-local collection is
      -- independently lexical for lambda, let, and nested case scopes.
      let duplicate = 2
          duplicateError = Left $ InvalidCheckExpressionScope
            $ Generated.DuplicatePatternBinder duplicate
          stepFields = [(duplicate, payload), (3, spine)]
          withStepBody body = ExpLambda 1 spine
            $ ExpCaseMatch (ExpVar 1 spine)
                [ (zeroName, [], ExpName zeroName)
                , (stepName, stepFields, body)
                ]
          lambdaShadow = withStepBody
            $ ExpLambda duplicate payload $ ExpName zeroName
          letShadow = withStepBody
            $ ExpLet duplicate spine (ExpName zeroName)
                (ExpVar duplicate spine)
          nestedCaseShadow = withStepBody
            $ ExpCaseMatch (ExpVar 3 spine)
                [ (zeroName, [], ExpName zeroName)
                , (stepName, [(duplicate, payload), (4, spine)]
                    , ExpVar 4 spine)
                ]
      mapM_ (\shadowed -> checkExpression
          (mkQueryClassEnv emptyStaticClassEnv []) functions
          [exactDeconstructor] goal [] shadowed @?= duplicateError)
        [lambdaShadow, letShadow, nestedCaseShadow]

  , testCase "certificate association preserves exact case schemas" $ do
      let payload = TypeCons $ name "Payload"
          token = TypeCons $ name "Token"
          integer = TypeCons $ name "Int"
          spineName = name "AssociatedSpine"
          zeroName = name "AssociatedZero"
          stepName = name "AssociatedStep"
          providerName = name "associatedCaseProvider"
          spine = TypeApp (TypeCons spineName) payload
          zero = FunctionBinding spine zeroName 0 [] []
          step = FunctionBinding spine stepName 0 [] [payload, spine]
          deconstructor = DeconstructorBinding spine
            [ ConstructorBinding zeroName []
            , ConstructorBinding stepName [payload, spine]
            ] True
          provider = TypeForall [0] [] token
          caseExpression = ExpLambda 1 spine
            $ ExpCaseMatch (ExpVar 1 spine)
                [ (zeroName, [], ExpName zeroName)
                , (stepName, [(2, payload), (3, spine)], ExpVar 3 spine)
                ]
      (providerBindings, schemes) <- preparedValueEnvironment
        providerName provider
      argument <- expectRight $ Generated.specifiedVisibleTypeArgument integer
      let expression = ExpTuple
            [ caseExpression
            , ExpTypeApply (ExpName providerName) argument
            ]
          goal = TypeTuple Boxed [TypeArrow spine spine, token]
          functions = [zero, step] ++ providerBindings
      evidence <- checkedEvidenceWithSchemes emptyStaticClassEnv functions
        [deconstructor] schemes goal expression
      case checkedExpressionTermGraph 51 evidence of
        ExferenceTermGraphAssociated checked -> do
          let graph =
                Association.checkedTypeApplicationCertificateGraph checked
          Typed.typedGraphCases (Typed.termGraphMetrics graph) @?= 1
          map (Certificate.checkedTypeApplicationCertificateStepSlot . third)
            (concat $ Association.foldCheckedTypeApplicationCertificateGraph
              (\rows _ _ _ _ _ receipts -> receipts : rows) [] checked)
            @?= [0]
        ExferenceTermGraphAvailable _ -> fail
          "mixed exact case and origin was downgraded to a plain graph"
        ExferenceTermGraphUnavailable reason -> fail
          $ "mixed exact case and origin failed association: " ++ show reason

  , testCase "strict production search retains an exact zero-step case graph" $ do
      let payload = TypeCons $ name "Payload"
          spineName = name "Spine"
          zeroName = name "SpineZero"
          stepName = name "SpineStep"
          spine = TypeApp (TypeCons spineName) payload
          functions =
            [ FunctionBinding spine zeroName 0 [] []
            , FunctionBinding spine stepName 0 [] [payload, spine]
            ]
          deconstructor = DeconstructorBinding spine
            [ ConstructorBinding zeroName []
            , ConstructorBinding stepName [payload, spine]
            ] True
          input = identityInput
            { E.input_goalType = TypeArrow spine spine
            , E.input_envFuncs = functions
            , E.input_envDeconsS = [deconstructor]
            , E.input_allowUnused = False
            , E.input_multiPM = True
            , E.input_maxSteps = 500
            }
          capacities = IdentifierCapacities 100 100 100 100
          isRebuildCase (expression, _, availability) = case expression of
            ExpLambda scrutinee _
                (ExpCaseMatch (ExpVar matched _) alternatives)
              | scrutinee == matched
              , map (\(constructor, _, _) -> constructor) alternatives
                  == [zeroName, stepName]
              , [([], ExpName retainedZero),
                  ([(payloadVariable, payloadType),
                    (tailVariable, tailType)],
                    ExpApply
                      (ExpApply (ExpName retainedStep)
                        (ExpVar returnedPayload returnedPayloadType))
                      (ExpVar returnedTail returnedTailType))] <-
                    [ (fields, body)
                    | (_, fields, body) <- alternatives
                    ]
              , retainedZero == zeroName
              , retainedStep == stepName
              , payloadVariable == returnedPayload
              , payloadType == payload
              , returnedPayloadType == payload
              , tailVariable == returnedTail
              , tailType == spine
              , returnedTailType == spine -> case availability of
                  ExferenceTermGraphAvailable{} -> True
                  ExferenceTermGraphAssociated{} -> False
                  ExferenceTermGraphUnavailable{} -> False
            _ -> False
      candidates <- expectRight
        $ findTypedEngineCandidatesWithIdentifierCapacitiesEither
            capacities input
      assertBool "strict production search did not retain the rebuild-case graph"
        $ any isRebuildCase candidates
  , testGroup "bounded recursive case scheduling"
      [ testCase "both lanes share the caller's step and queue allowance" $ do
          let token = TypeCons $ name "LaneToken"
              base = recursiveLaneInput
                { E.input_goalType = TypeArrow laneSpine
                    $ TypeArrow laneSpine token
                , E.input_envFuncs =
                    [ FunctionBinding token (name "laneSeed") 0 [] []
                    , FunctionBinding token (name "laneWrap") 0 [] [token]
                    ]
                }
          forM_ [0, 1, 2, 3, 8] $ \queueBound ->
            forM_ [1, 2, 16] $ \stepBound -> do
              let input = base
                    { E.input_maxSteps = stepBound
                    , E.input_maxQueueSize = Just queueBound
                    }
              results <- recursiveLaneResults input
              assertBool "a protected lane doubled the global step allowance"
                $ length results <= stepBound
              terminal <- lastResult results
              assertBool "a bounded trace ended without reporting completion"
                $ SharedSearch.batchProgress (SharedQuery.resultSearch terminal)
                    /= SharedSearch.Continuing
              let candidates = concatMap
                    (SharedSearch.batchCandidates . SharedQuery.resultSearch)
                    results
              forM_ candidates $ \candidate -> do
                let stats = exferenceCandidateStats
                      $ SharedCandidate.candidateDetails candidate
                assertBool "a result exceeded the aggregate queue allowance"
                  $ exference_finalSize stats <= queueBound
                assertBool "a result exceeded the shared step deadline"
                  $ exference_steps stats <= stepBound
              if queueBound > 0 && stepBound == 16
                then assertBool "the budget checks observed no completed work"
                  $ not $ null candidates
                else pure ()
      , testCase "one recursive input retains its original first-result step" $ do
          let input = recursiveLaneInput
                { E.input_goalType = TypeArrow laneSpine laneSpine
                , E.input_maxSteps = 3
                }
          results <- recursiveLaneResults input
          let candidates = concatMap
                (SharedSearch.batchCandidates . SharedQuery.resultSearch)
                results
              isIdentity candidate = case
                  Generated.functionClauseExpression
                    $ SharedCandidate.candidateOutput candidate of
                Generated.Lambda [Generated.Bind variable]
                    (Generated.Local returned) -> variable == returned
                _ -> False
          assertBool "a one-input query acquired a second scheduling lane"
            $ any isIdentity candidates
          map (exference_steps . exferenceCandidateStats
              . SharedCandidate.candidateDetails) candidates @?=
            replicate (length candidates) 3
      , testCase "scheduling does not become heuristic expression depth" $ do
          let token = TypeCons $ name "LaneDepthToken"
              input = recursiveLaneInput
                { E.input_goalType = TypeArrow laneSpine
                    $ TypeArrow laneSpine token
                , E.input_envFuncs =
                    [FunctionBinding token (name "laneDepthSeed") 0 [] []]
                , E.input_maxSteps = 64
                , E.input_maxDepth = Just 0
                , E.input_heuristicsConfig = defaultHeuristicsConfig
                    { heuristics_functionGoalTransform = 0
                    , heuristics_stepProvidedGood = 0
                    , heuristics_stepProvidedBad = 0
                    , heuristics_stepEnvGood = 0
                    , heuristics_stepEnvBad = 0
                    , heuristics_unusedVar = 1000
                    }
                }
          allowed <- recursiveLaneResults input
          assertBool "forwarding gained a synthetic depth penalty"
            $ any (not . null . SharedSearch.batchCandidates
                . SharedQuery.resultSearch) allowed
          rejected <- recursiveLaneResults input
            { E.input_heuristicsConfig = (E.input_heuristicsConfig input)
                {heuristics_functionGoalTransform = 1}
            }
          assertBool "the protected lane bypassed the existing depth bound"
            $ all (null . SharedSearch.batchCandidates
                . SharedQuery.resultSearch) rejected
      , testCase "the ordinary lane preserves a whole-value consumer" $ do
          let token = TypeCons $ name "LaneObserved"
              observer = name "laneObserve"
              input = recursiveLaneInput
                { E.input_goalType = TypeArrow laneSpine
                    $ TypeArrow laneSpine token
                , E.input_envFuncs =
                    [FunctionBinding token observer 0 [] [laneSpine, laneSpine]]
                , E.input_maxSteps = 64
                }
          results <- recursiveLaneResults input
          let candidates = concatMap
                (SharedSearch.batchCandidates . SharedQuery.resultSearch)
                results
              usesWhole candidate =
                Generated.alphaEquivalentExpression
                  (Generated.functionClauseExpression
                    $ SharedCandidate.candidateOutput candidate)
                  (Generated.Global observer)
          assertBool "eager cases suppressed an uninspected consumer"
            $ any usesWhole candidates
      , testCase "both case policies retain ordered-action oracle parity" $ do
          let token = TypeCons $ name "LaneParityToken"
              input = recursiveLaneInput
                { E.input_goalType = TypeArrow laneSpine
                    $ TypeArrow laneSpine token
                , E.input_envFuncs =
                    [FunctionBinding token (name "laneParitySeed") 0 [] []]
                , E.input_maxSteps = 24
                , E.input_maxQueueSize = Just 8
                }
          assertStepRouteParity "bounded recursive lanes"
            (IdentifierCapacities 1000 1000 1000 1000) input
      ]
  , testCase "final zonking seals a multi-binder inferred specialization" $ do
      let integer = TypeCons $ name "Int"
          boolean = TypeCons $ name "Bool"
          provider = TypeForall [0, 1] []
            $ TypeArrow (TypeVar 0)
            $ TypeArrow (TypeVar 1) (TypeVar 0)
          expectedRemaining = TypeForall [7] []
            $ TypeArrow integer
            $ TypeArrow (TypeVar 7) integer
          expectedResult = TypeArrow integer
            $ TypeArrow boolean integer
      booleanArgument <- expectRight
        $ Generated.specifiedVisibleTypeArgument boolean
      let expression = ExpLambda 2 provider
            $ ExpTypeApply
                (ExpTypeApply (ExpVar 2 provider)
                  Generated.inferredVisibleTypeArgument)
                booleanArgument
      evidence <- checkedEvidence emptyStaticClassEnv [] []
        (TypeArrow provider expectedResult) expression
      case checkedExpressionTermGraph 31 evidence of
        ExferenceTermGraphUnavailable reason -> fail
          $ "multi-binder specialization had no typed graph: " ++ show reason
        ExferenceTermGraphAssociated _ -> fail
          "local inferred specialization gained global certificate authority"
        ExferenceTermGraphAvailable graph -> do
          let witnesses =
                [ witness
                | (_, Typed.TermNode _
                    (Typed.TypedVisibleTypeApplication _ _ _ witness)) <-
                      Typed.termGraphNodes graph
                ]
              firstWitnesses =
                [ witness
                | witness <- witnesses
                , SharedTypeAtom.alphaEquivalentTypes
                    (Typed.typeApplicationSource witness) provider
                ]
              secondWitnesses =
                [ witness
                | witness <- witnesses
                , SharedTypeAtom.alphaEquivalentTypes
                    (Typed.typeApplicationSource witness) expectedRemaining
                ]
          case firstWitnesses of
            [witness] -> do
              Typed.typeApplicationSelected witness @?= integer
              assertBool "first visible result lost its remaining binder"
                $ SharedTypeAtom.alphaEquivalentTypes
                    (Typed.typeApplicationResult witness) expectedRemaining
            _ -> fail "missing unique first multi-binder witness"
          case secondWitnesses of
            [witness] -> do
              Typed.typeApplicationSelected witness @?= boolean
              Typed.typeApplicationResult witness @?= expectedResult
            _ -> fail "missing unique second multi-binder witness"
          assertBool "a final visible witness was not a leading instantiation"
            $ all
                (\witness -> SharedTypeAtom.isLeadingForallInstantiation
                  (Typed.typeApplicationSource witness)
                  (Typed.typeApplicationSelected witness)
                  (Typed.typeApplicationResult witness))
                witnesses
  , testCase "engine batches retain stable candidate-to-graph keying" $ do
      let integer = TypeCons $ name "Int"
          leftName = name "engineLeft"
          rightName = name "engineRight"
          binding bindingName = FunctionBinding integer bindingName 0 [] []
          input = identityInput
            { E.input_goalType = integer
            , E.input_envFuncs = [binding leftName, binding rightName]
            , E.input_maxSteps = 20
            }
          capacities = IdentifierCapacities 100 100 100 100
          observe candidates = Map.fromList
            [ (bindingName, Typed.termNodeIdValue $ Typed.termGraphRoot graph)
            | (ExpName bindingName, _, ExferenceTermGraphAvailable graph) <-
                candidates
            ]
      firstRun <- expectRight
        $ findTypedEngineCandidatesWithIdentifierCapacitiesEither
            capacities input
      secondRun <- expectRight
        $ findTypedEngineCandidatesWithIdentifierCapacitiesEither
            capacities input
      let first = observe firstRun
          second = observe secondRun
      Map.keysSet first @?= Set.fromList [leftName, rightName]
      first @?= second
      assertBool "two retained candidates reused one graph root identity"
        $ Map.lookup leftName first /= Map.lookup rightName first
  , testCase "engine batches retain impredicative multi-binder graphs" $ do
      let selected = TypeForall [2] []
            $ TypeArrow (TypeVar 2) (TypeVar 2)
          selectedPair = TypeTuple Boxed [selected, selected]
          provider = TypeForall [0, 1] [] selectedPair
          input = identityInput
            { E.input_goalType = TypeArrow provider selectedPair
            , E.input_envFuncs = []
            , E.input_maxSteps = 3
            }
          capacities = IdentifierCapacities 100 100 100 100
          visibleWitnesses graph =
            [ witness
            | (_, Typed.TermNode _
                (Typed.TypedVisibleTypeApplication _ _ _ witness)) <-
                  Typed.termGraphNodes graph
            ]
      argument <- expectRight
        $ Generated.specifiedVisibleTypeArgument selected
      let expectedExpression = ExpLambda 1 provider
            $ ExpTypeApply
                (ExpTypeApply (ExpVar 1 provider) argument) argument
      candidates <- expectRight
        $ findTypedEngineCandidatesWithIdentifierCapacitiesEither
            capacities input
      let impredicativeGraphs =
            [ (graph, witnesses)
            | (expression, _, ExferenceTermGraphAvailable graph) <- candidates
            , expression == expectedExpression
            , let witnesses = visibleWitnesses graph
            , length witnesses == 2
            , all
                (\witness -> SharedTypeAtom.alphaEquivalentTypes
                  (Typed.typeApplicationSelected witness) selected)
                witnesses
            ]
      case impredicativeGraphs of
        [] -> fail
          "production search retained no available impredicative multi-binder graph"
        [(graph, witnesses)] -> do
          Typed.typedGraphVisibleTypeApplications
              (Typed.termGraphMetrics graph) @?= 2
          assertBool "production witness chain is not leading-forall exact"
            $ all
                (\witness -> SharedTypeAtom.isLeadingForallInstantiation
                  (Typed.typeApplicationSource witness)
                  (Typed.typeApplicationSelected witness)
                  (Typed.typeApplicationResult witness))
                witnesses
        _ -> fail
          "production search duplicated the exact impredicative candidate"
  , testCase "implicit local specialization retains checker-owned type selections" $ do
      let unit = TypeTuple Boxed []
          polymorphic = TypeForall [0] [] $ TypeVar 0
          implicitExpression = ExpLambda 1 polymorphic
            $ ExpVar 1 $ TypeVar 2
      implicitEvidence <- checkedEvidence emptyStaticClassEnv [] []
        (TypeArrow polymorphic unit) implicitExpression
      expectPlainGraph "implicit local specialization" 23 implicitEvidence
      case checkedExpressionTermGraph 23 implicitEvidence of
        ExferenceTermGraphAvailable graph -> do
          let witnesses =
                [ witness
                | (_, Typed.TermNode _ (Typed.TypedImplicitTypeApplication _ _ witness))
                    <- Typed.termGraphNodes graph
                ]
          length witnesses @?= 1
          map Typed.implicitTypeApplicationSelected witnesses @?= [unit]
          assertBool "implicit evidence changed compatibility syntax" $
            Typed.eraseTermGraph graph ==
              Generated.discardUnusedPatternBindingsBy id
                (toGeneratedExpression implicitExpression)
        _ -> fail "implicit local graph not retained"
  , testCase "implicit local occurrences select independent monotypes and polytypes" $ do
      let unit = TypeTuple Boxed []
          pair = TypeTuple Boxed [unit, unit]
          poly = TypeForall [0] [] $ TypeArrow (TypeVar 0) (TypeVar 0)
          use ty = ExpVar 1 $ TypeArrow ty ty
          expression = ExpLambda 1 poly $ ExpTuple
            [ ExpApply (use unit) $ ExpTuple []
            , ExpApply (use pair) $ ExpTuple [ExpTuple [], ExpTuple []]
            , use poly
            ]
          goal = TypeArrow poly $ TypeTuple Boxed
            [unit, pair, TypeArrow poly poly]
      evidence <- checkedEvidence emptyStaticClassEnv [] [] goal expression
      expectPlainGraph "independent implicit occurrences" 29 evidence
      case checkedExpressionTermGraph 29 evidence of
        ExferenceTermGraphAvailable graph -> do
          let selected =
                [ Typed.implicitTypeApplicationSelected witness
                | (_, Typed.TermNode _ (Typed.TypedImplicitTypeApplication _ _ witness))
                    <- Typed.termGraphNodes graph
                ]
          length selected @?= 3
          forM_ [unit, pair, poly] $ \expected ->
            assertBool "a local occurrence borrowed another occurrence's selection" $
              any (SharedTypeAtom.alphaEquivalentTypes expected) selected
          Typed.typedGraphVisibleTypeApplications (Typed.termGraphMetrics graph) @?= 0
        _ -> fail "independent implicit graphs not retained"
  , testCase "typed evidence explains the deliberately unsupported subset" $ do
      let polymorphic = TypeForall [0] [] $ TypeVar 0
      let distinct = TypeForall [1] []
            $ TypeArrow (TypeVar 1) (TypeVar 1)
          subsumedExpression = ExpLambda 1 polymorphic $ ExpVar 1 distinct
      subsumedEvidence <- checkedEvidence emptyStaticClassEnv [] []
        (TypeArrow polymorphic distinct) subsumedExpression
      expectUnavailable "shallow local subsumption"
        (\reason -> case reason of
          SubsumedLocalSpecialization{} -> True
          _ -> False)
        subsumedEvidence

      let outer = TypeVar 4
          identityScheme = TypeForall [2] []
            $ TypeArrow (TypeVar 2) (TypeVar 2)
          rigidIdentity rigid local = ExpLambda local (TypeConstant rigid)
            $ ExpVar local $ TypeConstant rigid
          introducedExpression = ExpLambda 1 (TypeConstant 0)
            $ rigidIdentity 1 2
      introducedEvidence <- checkedEvidence emptyStaticClassEnv [] []
        (TypeArrow outer identityScheme) introducedExpression
      expectPlainGraph "nested forall introduction" 31 introducedEvidence
      case checkedExpressionTermGraph 31 introducedEvidence of
        ExferenceTermGraphAvailable graph -> do
          length
            [ ()
            | (_, Typed.TermNode _ Typed.TypedForallIntroduction{}) <-
                Typed.termGraphNodes graph
            ] @?= 2
          Typed.eraseTermGraph graph @?=
            Generated.discardUnusedPatternBindingsBy id
              (toGeneratedExpression introducedExpression)
        other -> fail $ "nested introduction lost its checked openings: "
          ++ show other

      let integer = TypeCons $ name "Int"
          boxName = name "Box"
          box argument = TypeApp (TypeCons boxName) argument
          boxDeconstructor = DeconstructorBinding (box $ TypeVar 0)
            [ConstructorBinding boxName [TypeVar 0]] False
          matchedExpression = ExpLambda 1 (box integer)
            $ ExpLetMatch boxName [(2, integer)]
                (ExpVar 1 $ box integer)
                (ExpVar 2 integer)
      patternEvidence <- checkedEvidence emptyStaticClassEnv []
        [boxDeconstructor] (TypeArrow (box integer) integer)
        matchedExpression
      expectPlainGraph "complete nominal constructor let" 32 patternEvidence

      pairName <- expectRight $ SharedName.tupleName Boxed 2
      let pairType = TypeTuple Boxed [integer, integer]
          tupleExpression = ExpLambda 1 pairType
            $ ExpLetMatch pairName [(2, integer), (3, integer)]
                (ExpVar 1 pairType)
                (ExpVar 2 integer)
      tupleEvidence <- checkedEvidence emptyStaticClassEnv [] []
        (TypeArrow pairType integer) tupleExpression
      expectPlainGraph "structural tuple pattern" 33 tupleEvidence

      let className = name "C"
          token = TypeCons $ name "Token"
          constraint ty = HsConstraint className [ty]
          contextualProvider = TypeForall [0]
            [constraint $ TypeVar 0] token
      contextualClasses <- expectRight $ mkStaticClassEnv
        [HsTypeClass className [0] []]
        [HsInstance [] $ constraint integer]
      integerArgument <- expectRight
        $ Generated.specifiedVisibleTypeArgument integer
      let contextualExpression = ExpLambda 1 contextualProvider
            $ ExpTypeApply (ExpVar 1 contextualProvider) integerArgument
      contextualEvidence <- checkedEvidence contextualClasses [] []
        (TypeArrow contextualProvider token) contextualExpression
      expectUnavailable "contextual visible application"
        (\reason -> case reason of
          UnsupportedContextualVisibleApplication{} -> True
          _ -> False)
        contextualEvidence

      let implicitContextualProvider = TypeForall [0]
            [constraint $ TypeVar 0] $ TypeArrow (TypeVar 0) (TypeVar 0)
          implicitContextualExpression = ExpLambda 1 implicitContextualProvider
            $ ExpVar 1 $ TypeArrow integer integer
      implicitContextualEvidence <- checkedEvidence contextualClasses [] []
        (TypeArrow implicitContextualProvider $ TypeArrow integer integer)
        implicitContextualExpression
      expectUnavailable "implicit local dictionaries still require graph evidence"
        (\reason -> case reason of
          UnsupportedContextEvidence{} -> True
          _ -> False)
        implicitContextualEvidence

      let layeredContextualProvider = TypeForall [] [constraint integer]
            $ TypeForall [0, 1] []
            $ TypeArrow (TypeVar 0) (TypeVar 1)
          layeredContextualResult = TypeForall [] [constraint integer]
            $ TypeForall [1] []
            $ TypeArrow integer (TypeVar 1)
          layeredContextualExpression = ExpLambda 1 layeredContextualProvider
            $ ExpTypeApply
                (ExpVar 1 layeredContextualProvider) integerArgument
      layeredContextualEvidence <- checkedEvidence contextualClasses [] []
        (TypeArrow layeredContextualProvider layeredContextualResult)
        layeredContextualExpression
      case checkedExpressionTermGraph 37 layeredContextualEvidence of
        ExferenceTermGraphUnavailable
            (UnsupportedContextualVisibleApplication source selected result) -> do
            assertBool "layered source changed before classification"
              $ SharedTypeAtom.alphaEquivalentTypes
                  source layeredContextualProvider
            selected @?= integer
            assertBool "layered result lost its remaining binder"
              $ SharedTypeAtom.alphaEquivalentTypes
                  result layeredContextualResult
        ExferenceTermGraphUnavailable reason -> fail
          $ "layered contextual application had the wrong reason: "
          ++ show reason
        ExferenceTermGraphAvailable _ -> fail
          "layered contextual application unexpectedly produced a graph"
        ExferenceTermGraphAssociated _ -> fail
          "local contextual application gained global certificate authority"
  , testCase "typed evidence reports limits and preserves unused binders as wildcards" $ do
      let integer = TypeCons $ name "Int"
          seedName = name "seed"
          seed = FunctionBinding integer seedName 0 [] []
          oversizedExpression = foldr
            (\variable body -> ExpLet variable integer
              (ExpName seedName) body)
            (ExpName seedName)
            [1 .. 2050]
      oversizedEvidence <- checkedEvidence emptyStaticClassEnv [seed] []
        integer oversizedExpression
      expectUnavailable "graph node limit"
        (\reason -> case reason of
          TermGraphConstructionLimit
              (TermGraphConstructionNodeLimitExceeded 4096 4097) -> True
          _ -> False)
        oversizedEvidence

      let deepType = foldr TypeArrow integer $ replicate 2050 integer
          deepName = name "deep"
          deep = FunctionBinding deepType deepName 0 [] []
      deepEvidence <- checkedEvidence emptyStaticClassEnv [deep] []
        deepType $ ExpName deepName
      expectUnavailable "typed-graph type sealing"
        (\reason -> case reason of
          TermGraphSealingFailure
              (Typed.TermGraphTypeNodeLimitExceeded
                (Typed.GraphTermNodeType _) 4096 4097) -> True
          _ -> False)
        deepEvidence

      let unusedExpression = ExpLambda 1 integer $ ExpName seedName
      unusedEvidence <- checkedEvidence emptyStaticClassEnv [seed] []
        (TypeArrow integer integer) unusedExpression
      case checkedExpressionTermGraph 38 unusedEvidence of
        ExferenceTermGraphAvailable graph -> Typed.eraseTermGraph graph @?=
          Generated.Lambda [Generated.Wildcard] (Generated.Global seedName)
        other -> fail $ "unused-binder evidence unavailable: " ++ show other
      let unusedLet = ExpLet 2 integer (ExpName seedName) unusedExpression
      unusedLetEvidence <- checkedEvidence emptyStaticClassEnv [seed] []
        (TypeArrow integer integer) unusedLet
      case checkedExpressionTermGraph 39 unusedLetEvidence of
        ExferenceTermGraphAvailable graph -> Typed.eraseTermGraph graph @?=
          Generated.Let Generated.Wildcard (Generated.Global seedName)
            (Generated.Lambda [Generated.Wildcard] $ Generated.Global seedName)
        other -> fail $ "unused-let evidence unavailable: " ++ show other
  , testCase "query-result projection preserves its envelope lazily" $ do
      targetName <- expectRight $ SharedName.mkOperator "<~>"
      target <- expectRight $ Generated.mkDefinitionName targetName
      let metadata = E.ExferenceBatchMetadata Map.empty 2 3
          (typedHasValidatedEvidence, typedProgress, typedMetadata,
            typedTarget, typedFallbackObserved) =
              typedQueryProjectionStrictnessForTesting target Map.empty
      typedHasValidatedEvidence @?= True
      typedProgress @?= SharedSearch.Continuing
      typedMetadata @?= metadata
      typedTarget @?= target
      typedFallbackObserved @?= True
      let
          (hasValidatedEvidence, progress, observedMetadata,
            observedTarget) =
              queryProjectionStrictnessForTesting target Map.empty
      hasValidatedEvidence @?= True
      progress @?= SharedSearch.Continuing
      observedMetadata @?= metadata
      observedTarget @?= target
      let (compatibilityStatus, compatibilityExpression,
            compatibilityConstraints, compatibilityStatistics) =
              compatibilityProjectionStrictnessForTesting
          compatibilityExpected = ExpLambda 1 (TypeVar 0)
            $ ExpVar 1 $ TypeVar 0
      compatibilityStatus @?=
        E.SearchStatus E.SearchRunning 2 3
      assertBool "compatibility projection changed the candidate expression"
        $ compatibilityExpression == compatibilityExpected
      compatibilityConstraints @?= []
      compatibilityStatistics @?= ExferenceStats 1 0 0
  ]

identityInput :: E.ExferenceInput
identityInput = E.ExferenceInput
  (TypeArrow (TypeVar 0) (TypeVar 0))
  [] [] emptyStaticClassEnv
  False False 0 False 20 Nothing Nothing defaultHeuristicsConfig

-- A fresh nominal recursive declaration exercises scheduling without giving
-- search any reference operation or recursive eliminator. Constructors are
-- visible for matching only, so tests cannot pass by reconstructing a value.
laneSpine :: HsType
laneSpine = TypeCons $ name "LaneSpine"

recursiveLaneInput :: E.ExferenceInput
recursiveLaneInput = identityInput
  { E.input_envDeconsS =
      [ DeconstructorBinding laneSpine
          [ ConstructorBinding (name "LaneZero") []
          , ConstructorBinding (name "LaneStep") [laneSpine]
          ] True
      ]
  , E.input_allowUnused = True
  , E.input_multiPM = True
  , E.input_maxQueueSize = Just 32
  }

recursiveLaneResults :: E.ExferenceInput -> IO [E.ExferenceResult]
recursiveLaneResults input = do
  environment <- expectRight $ sealLegacyEnvironment input
  target <- checkedIdentifierTarget "recursiveLane"
  let legacyQuery = legacyInputQuery input
      query = legacyQuery
        { E.querySearchOptions = (E.querySearchOptions legacyQuery)
            {exferenceCandidateRanking = SharedQuality.defaultCandidateRankingPolicy}
        }
  expectRight $ findQueryResultsWithIdentifierCapacitiesEither
    (IdentifierCapacities 1000 1000 1000 1000)
    target (emptyExferenceSourceTypeVariableHints $ E.input_goalType input)
    environment query

legacyInputEnvironment :: E.ExferenceInput -> EnvDictionary
legacyInputEnvironment input = EnvDictionary
  { environmentFunctions = E.input_envFuncs input
  , environmentDeconstructors = E.input_envDeconsS input
  , environmentClasses = E.input_envClasses input
  }

legacyInputQuery :: E.ExferenceInput -> E.ExferenceQuery
legacyInputQuery input = E.ExferenceQuery
  { E.queryGoalType = E.input_goalType input
  , E.queryExcludedBindings = Set.empty
  , E.querySearchOptions = ExferenceOptions
      { exferenceAllowUnused = E.input_allowUnused input
      , exferenceAllowResidualConstraints = E.input_allowConstraints input
      , exferenceConstraintDeferralSteps =
          E.input_allowConstraintsStopStep input
      , exferenceMultiConstructorPatterns = E.input_multiPM input
      , exferenceMaximumSteps = E.input_maxSteps input
      , exferenceMaximumQueueSize = E.input_maxQueueSize input
      , exferenceMaximumDepth = E.input_maxDepth input
      , exferenceHeuristics = E.input_heuristicsConfig input
      , exferenceCandidateRanking = SharedQuality.LegacyCandidateRanking
      , exferenceProviderCosts = Map.empty
      }
  }

sealLegacyEnvironment
  :: E.ExferenceInput
  -> Either E.ExferenceInputError E.ExferenceEnvironment
sealLegacyEnvironment = E.mkExferenceEnvironment . legacyInputEnvironment

lastCapacityChunk
  :: IdentifierCapacities
  -> E.ExferenceInput
  -> IO E.ExferenceChunkElement
lastCapacityChunk capacities input = do
  chunks <- expectRight
    $ findExpressionsWithIdentifierCapacitiesEither capacities input
  lastChunk "capacity-limited search" chunks

lastChunk :: String -> [value] -> IO value
lastChunk description chunks = case chunks of
  [] -> fail $ description ++ " produced no search chunks"
  first : remaining -> pure $ lastElement first remaining

lastResult :: [value] -> IO value
lastResult results = case results of
  [] -> fail "expected at least one capacity-limited query result"
  first : remaining -> pure $ lastElement first remaining

assertStepRouteParity
  :: String
  -> IdentifierCapacities
  -> E.ExferenceInput
  -> IO ()
assertStepRouteParity label capacities input = do
  (legacyChunks, actionChunks) <- expectRight
    $ findExpressionStepRouteTracesWithIdentifierCapacitiesEither
        capacities input
  assertBool (label ++ " changed the complete compatibility trace")
    $ map observeChunk legacyChunks == map observeChunk actionChunks

  (legacyCandidatesLazy, actionCandidatesLazy) <- expectRight
    $ findTypedEngineCandidateStepRouteTracesWithIdentifierCapacitiesEither
        capacities input
  legacyCandidates <- evaluate $ force legacyCandidatesLazy
  actionCandidates <- evaluate $ force actionCandidatesLazy
  assertBool (label ++ " changed typed candidates or retained graphs")
    $ legacyCandidates == actionCandidates

observeChunk
  :: E.ExferenceChunkElement
  -> ( E.SearchStatus
     , Map.Map QualifiedName Int
     , [E.ExferenceOutputElement]
     )
observeChunk chunk =
  ( E.chunkStatus chunk
  , E.chunkBindingUsages chunk
  , E.chunkElements chunk
  )

firstChunk :: String -> [value] -> IO value
firstChunk description chunks = case chunks of
  [] -> fail $ description ++ " produced no search chunks"
  first : _ -> pure first

assertSecondBatchPoisoned
  :: String
  -> [E.ExferenceChunkElement]
  -> IO ()
assertSecondBatchPoisoned label trace = do
  outcome <- try (evaluate $ length $ take 2 trace)
    :: IO (Either SomeException Int)
  case outcome of
    Left _ -> pure ()
    Right observed -> assertFailure $ label
      ++ " evaluated " ++ show observed
      ++ " batches without reaching the live next-step poison"

lastElement :: value -> [value] -> value
lastElement latest [] = latest
lastElement _ (next : remaining) = lastElement next remaining

checkedEvidence
  :: StaticClassEnv
  -> [FunctionBinding]
  -> [DeconstructorBinding]
  -> HsType
  -> Expression
  -> IO CheckedExpressionEvidence
checkedEvidence classes functions deconstructors goal expression = do
  plan <- expectRight $ planRigidInstantiation
    (mkRigidInstantiationContext
      $ EnvDictionary functions deconstructors classes)
    [] goal
  context <- expectRight $ prepareExpressionCheckContext plan
    (mkQueryClassEnv classes []) functions deconstructors goal
  expectRight $ checkExpressionInContextWithNestedRigidProvenanceEvidence
    context (nestedRigidProvenance emptyRigidScope) [] expression

checkedEvidenceWithSchemes
  :: StaticClassEnv
  -> [FunctionBinding]
  -> [DeconstructorBinding]
  -> Map.Map QualifiedName HsType
  -> HsType
  -> Expression
  -> IO CheckedExpressionEvidence
checkedEvidenceWithSchemes classes functions deconstructors schemes goal
    expression = do
  plan <- expectRight $ planRigidInstantiation
    (mkRigidInstantiationContext
      $ EnvDictionary functions deconstructors classes)
    [] goal
  context <- expectRight $ prepareExpressionCheckContextWithSchemes plan
    (mkQueryClassEnv classes []) functions deconstructors schemes goal
  expectRight $ checkExpressionInContextWithNestedRigidProvenanceEvidence
    context (nestedRigidProvenance emptyRigidScope) [] expression

preparedValueEnvironment
  :: QualifiedName
  -> HsType
  -> IO ([FunctionBinding], Map.Map QualifiedName HsType)
preparedValueEnvironment valueName valueType = do
  inventory <- expectRight $ SharedInventory.mkInventory
    SharedKindInference.OpenKindInventory
    ([ SharedDeclaration.ValueDeclaration
       $ SharedDeclaration.ValueSignature () valueName valueType
     ] :: [SharedDeclaration.Declaration SynthesisVariable Void ()])
  prepared <- expectRight $ prepareSynthesisInventory inventory
  let backend = preparedSynthesisBackend prepared
  pure
    ( environmentFunctions backend
    , preparedSynthesisSchemes prepared
    )

expectUnavailable
  :: String
  -> (ExferenceTermGraphAbsence -> Bool)
  -> CheckedExpressionEvidence
  -> IO ()
expectUnavailable label matches evidence =
  case checkedExpressionTermGraph 23 evidence of
    ExferenceTermGraphUnavailable reason
      | matches reason -> pure ()
      | otherwise -> fail $ label ++ ": wrong absence: " ++ show reason
    ExferenceTermGraphAvailable graph ->
      fail $ label ++ ": unexpectedly sealed: " ++ show graph
    ExferenceTermGraphAssociated _ ->
      fail $ label ++ ": unexpectedly associated"

expectPlainGraph
  :: String
  -> Natural
  -> CheckedExpressionEvidence
  -> IO ()
expectPlainGraph label key evidence =
  case checkedExpressionTermGraph key evidence of
    ExferenceTermGraphAvailable graph ->
      [ Typed.typeApplicationCertificate witness
      | (_, Typed.TermNode _
          (Typed.TypedVisibleTypeApplication _ _ _ witness)) <-
            Typed.termGraphNodes graph
      ] @?= replicate
        (fromIntegral $ Typed.typedGraphVisibleTypeApplications
          $ Typed.termGraphMetrics graph)
        Nothing
    ExferenceTermGraphAssociated _ ->
      fail $ label ++ ": unexpectedly retained certificate authority"
    ExferenceTermGraphUnavailable reason ->
      fail $ label ++ ": unexpectedly unavailable: " ++ show reason

paired :: Natural -> Natural -> Natural
paired left right = ((sum' * (sum' + 1)) `div` 2) + right
 where
  sum' = left + right

third :: (first, second, value) -> value
third (_, _, value) = value

checkedIdentifierTarget :: String -> IO Generated.DefinitionName
checkedIdentifierTarget spelling = do
  targetName <- expectRight $ SharedName.mkIdentifier spelling
  expectRight $ Generated.mkDefinitionName targetName

name :: String -> QualifiedName
name spelling = either (error . show) id $ mkQualifiedName [] spelling

assertSelectedProviderChecking :: IO ()
assertSelectedProviderChecking = do
  let c ty = HsConstraint (name "C") [ty]
      d ty = HsConstraint (name "D") [ty]
      integer = TypeCons $ name "Int"
      boolean = TypeCons $ name "Bool"
      character = TypeCons $ name "Char"
      token = TypeCons $ name "Token"
      providerName = name "method"
      provider = TypeForall [3] [c $ TypeVar 3] token
      selected ty = ExpSelect (ExpName providerName) [c ty]
      assertRejected label result = case result of
        Left _ -> pure ()
        Right _ -> fail $ "independent checker accepted " ++ label
  classes <- expectRight $ mkStaticClassEnv
    [HsTypeClass (name "C") [0] [], HsTypeClass (name "D") [0] []] []
  (bindings, schemes) <- preparedValueEnvironment providerName provider
  let checker goal givens = do
        plan <- expectRight $ planRigidInstantiation
          (mkRigidInstantiationContext $ EnvDictionary bindings [] classes) [] goal
        context <- expectRight $ prepareExpressionCheckContextWithSchemes plan
          (mkQueryClassEnv classes givens) bindings [] schemes goal
        pure $ checkExpressionInContextWithNestedRigidProvenanceEvidence
          context (nestedRigidProvenance emptyRigidScope) []
  check <- checker token [c integer, c boolean]
  _ <- expectRight $ check $ selected integer
  _ <- expectRight $ check $ selected boolean
  _ <- expectRight $ check $ ExpSelect
    (ExpTypeApply (ExpName providerName) Generated.inferredVisibleTypeArgument) [c integer]
  integerArgument <- expectRight $ Generated.specifiedVisibleTypeArgument integer
  assertRejected "selection contradicting an explicit type argument" $ check $
    ExpSelect (ExpTypeApply (ExpName providerName) integerArgument) [c boolean]
  toGeneratedExpression (selected integer) @?= toGeneratedExpression (selected boolean)
  assertRejected "erased ambiguous selection" $ check $ ExpName providerName
  assertRejected "missing dictionary" $ check $ selected character
  assertRejected "unselected ambient variable" $ check $ selected $ TypeVar 0
  assertRejected "changed provider class" $ check $ ExpSelect (ExpName providerName) [d integer]
  assertRejected "extra provider constraint" $ check $ ExpSelect (ExpName providerName) [c integer, c boolean]
  assertRejected "empty selection" $ check $ ExpSelect (ExpName providerName) []
  localCheck <- checker (TypeForall [] [c integer] token) []
  _ <- expectRight $ localCheck $ selected integer
  siblingCheck <- checker (TypeTuple Boxed [TypeForall [] [c integer] token, token]) []
  assertRejected "sibling dictionary leakage" $ siblingCheck $
    ExpTuple [selected integer, selected integer]

assertTwoLexicalSelections :: Bool -> IO ()
assertTwoLexicalSelections local = do
  let c ty = HsConstraint (name "C") [ty]
      token = TypeCons $ name "Token"
      providerName = name "method"
      provider = TypeForall [3] [c $ TypeVar 3] token
      goal = TypeForall [0, 1] [c $ TypeVar 0, c $ TypeVar 1] $
        if local then TypeArrow provider token else token
      input = identityInput { E.input_goalType = goal, E.input_maxSteps = 20000 }
  classes <- expectRight $ mkStaticClassEnv [HsTypeClass (name "C") [0] []] []
  (bindings, schemes) <- preparedValueEnvironment providerName provider
  environment <- expectRight $ E.mkExferenceEnvironmentWithSchemes
    (EnvDictionary (if local then [] else bindings) [] classes)
    (if local then Map.empty else schemes)
  target <- checkedIdentifierTarget "twoLexicalSelections"
  options <- expectRight $ E.checkExferenceOptions $
    E.querySearchOptions $ legacyInputQuery input
  results <- expectRight $
    E.findTypedQueryResultsInEnvironmentWithCheckedOptionsAndAssignments Map.empty
      target (emptyExferenceSourceTypeVariableHints goal) environment
      (legacyInputQuery input) options
  let candidates = take 32 $ concatMap
        (SharedSearch.batchCandidates . SharedQuery.resultSearch) results
  selections <- mapM (\candidate -> do
      graph <- TypedCandidate.foldTypedCandidateGraph
        (\_ reason -> fail $ "selection candidate has no graph: " ++ show reason)
        (\_ owned -> pure owned)
        (\_ associated -> pure $ Association.checkedTypeApplicationCertificateGraph associated)
        candidate
      let introductions =
            [ Typed.contextEvidenceBinder $ Typed.givenContextEvidence occurrence slot
            | (_, Typed.TermNode _ (Typed.TypedContextIntroduction occurrence _ witness)) <- Typed.termGraphNodes graph
            , (slot, _) <- zip [0 ..] $ Typed.contextIntroductionConstraints witness ]
          applications =
            [ Typed.contextEvidenceBinder proof
            | (_, Typed.TermNode _ (Typed.TypedContextApplication _ _ witness)) <- Typed.termGraphNodes graph
            , proof <- Typed.contextApplicationEvidence witness ]
      length introductions @?= 2
      length applications @?= 1
      assertBool "selection escaped the root lexical evidence" $
        all (`elem` introductions) applications
      pure $ map Typed.evidenceBinderSlot applications) candidates
  Set.fromList selections @?= Set.fromList [[0], [1]]

expectRight :: Show problem => Either problem result -> IO result
expectRight = either (fail . show) pure

-- This diagnostic uses the same closed goal and balanced 256-result window
-- as the public behavioral regression. The reference is an assertion only.
unitPrefixGoal :: HsType
unitPrefixGoal = TypeForall [0, 1] [] $ TypeArrow source target
 where
  maybeType binder element = TypeForall [binder] [] $
    TypeArrow (TypeVar binder) $ TypeArrow
      (TypeArrow element $ TypeVar binder) (TypeVar binder)
  eitherType binder left right = TypeForall [binder] [] $
    TypeArrow (TypeArrow left $ TypeVar binder) $ TypeArrow
      (TypeArrow right $ TypeVar binder) (TypeVar binder)
  source = eitherType 4 (maybeType 2 $ TypeVar 0) (maybeType 3 $ TypeVar 1)
  target = maybeType 6 $ eitherType 5 (TypeVar 0) (TypeVar 1)

unitPrefixNormalize :: Generated.Expression Int -> Generated.Expression Int
unitPrefixNormalize = Generated.simplifyExpressionBy id . go
 where
  go expression = case expression of
    Generated.Lambda patterns body -> foldr
      (\pattern rest -> Generated.Lambda [pattern] rest) (go body) patterns
    Generated.Apply function argument -> Generated.Apply (go function) (go argument)
    Generated.VisibleTypeApplication function _ -> go function
    Generated.Tuple fields -> Generated.Tuple $ map go fields
    Generated.Let pattern value body -> Generated.Let pattern (go value) (go body)
    Generated.Case value branches -> Generated.Case (go value)
      [(pattern, go body) | (pattern, body) <- branches]
    _ -> expression

unitPrefixMatches :: Expression -> Bool
unitPrefixMatches expression = Generated.alphaEquivalentExpression expected $
  unitPrefixNormalize $ toGeneratedExpression expression
 where
  local = Generated.Local
  app = Generated.Apply
  lam variables = Generated.lambdaExpression $ map Generated.Bind variables
  expected = unitPrefixNormalize $ lam [0, 1, 2] $
    app (app (local 0)
      (lam [3] $ app (app (local 3) (local 1))
        (lam [4] $ app (local 2) $ lam [5, 6] $ app (local 5) (local 4))))
      (lam [7] $ app (app (local 7) (local 1))
        (lam [8] $ app (local 2) $ lam [9, 10] $ app (local 10) (local 8)))

unitPrefixCandidates :: IO [E.ExferenceOutputElement]
unitPrefixCandidates = unitPrefixCandidatesIn []

unitPrefixCandidatesIn :: [FunctionBinding] -> IO [E.ExferenceOutputElement]
unitPrefixCandidatesIn functions = do
  environment <- expectRight $ E.mkExferenceEnvironment $
    EnvDictionary functions [] emptyStaticClassEnv
  checked <- expectRight $ E.prepareExferenceQuery environment $
    E.ExferenceQuery unitPrefixGoal Set.empty defaultExferenceOptions
      { exferenceMaximumSteps = 100000
      , exferenceMaximumQueueSize = Just 8192
      , exferenceAllowUnused = True
      , exferenceCandidateRanking = SharedQuality.defaultCandidateRankingPolicy }
  pure $ take 256 $ concatMap E.chunkElements $ E.findExpressions checked

unitPrefixRegression :: IO ()
unitPrefixRegression = do
  constructor <- expectRight $ SharedName.tupleName SharedName.Boxed 0
  let unit = FunctionBinding (TypeTuple Boxed []) constructor 9.9 [] []
  forM_ [[], [unit]] $ \functions -> do
    candidates <- unitPrefixCandidatesIn functions
    (expression, residual, _) <- maybe
      (fail "maybeEither witness was absent from the original 256-candidate prefix") pure $
        find (\(term, _, _) -> unitPrefixMatches term) candidates
    residual @?= []
    checkExpression (mkQueryClassEnv emptyStaticClassEnv []) functions []
      unitPrefixGoal [] expression @?= Right ()

emitUnitPrefix :: IO ()
emitUnitPrefix = do
  candidates <- unitPrefixCandidates
  forM_ (zip [(1 :: Int)..] candidates) $ \(index, (term, residual, stats)) -> do
    residual @?= []
    print (index, unitPrefixMatches term, stats, showExpression term)
