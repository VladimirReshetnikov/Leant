{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds #-}
module Main where
import Fixture
probe :: forall a. (forall (f :: * -> *). a) -> (forall (f :: *). a) -> (a,a)
probe = \a b -> (a, b)
main :: IO ()
main = print (probe @Int (7 :: forall (f :: * -> *). Int) (7 :: forall (f :: *). Int) == (7,7))
