{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds #-}
module Main where
import Fixture
probe :: forall (f :: * -> *) a. f a -> f a
probe = \a -> a
main :: IO ()
main = print (probe @[] [7 :: Int] == [7])
