{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds #-}
module Main where
import Fixture
probe :: forall a. Fixture.Identity (forall (f :: * -> *). a) -> a
probe = \a -> a
main :: IO ()
main = print (probe @Int (7 :: forall (f :: * -> *). Int) == 7)
