{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds #-}
module Main where
import Fixture
probe :: forall r. (((), ()) -> r) -> r
probe = \f1 -> f1 ((), ())
main :: IO ()
main = print (probe @Int (\((), ()) -> 53) == 53)
