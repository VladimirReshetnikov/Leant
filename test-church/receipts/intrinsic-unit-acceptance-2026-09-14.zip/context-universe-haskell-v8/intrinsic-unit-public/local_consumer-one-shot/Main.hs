{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds #-}
module Main where
import Fixture
probe :: forall r. (forall a. a -> r) -> r
probe = \f1 -> f1 f1
main :: IO ()
main = print (probe @Int (\_ -> 37) == 37)
