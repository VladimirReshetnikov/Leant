"""Frozen diagnostic for behavioral full-inventory admission."""
from pathlib import Path
import json,re,subprocess,sys
ROOT=Path('C:/Leant-validation/trailing-type-witness')
OUT=ROOT/'dist-newstyle/behavioral-provider-admission-v1'
sys.path.insert(0,str(ROOT/'lib/Djex/test-church'))
import behavior_runtime as runtime
OUT.mkdir(parents=True,exist_ok=False)
report={'status':'running','scope':'Unpublished Main.hs scheduling experiment; original length fixture and same-world False control.',
 'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
 'dependency_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT/'lib/Djex').decode().strip(),'source_hashes':{}}
assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT/'lib/Djex')==b''
assert subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).decode().splitlines()==['src/Main.hs']
for repo,prefix in [(ROOT,''),(ROOT/'lib/Djex','lib/Djex/')]:
 for name in subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0'):
  p=repo/name
  if not name or not p.is_file() or '/receipts/' in name:continue
  if p.suffix not in ['.hs','.lhs','.py','.lean','.cabal'] and name not in ['cabal.project','lean-toolchain']:continue
  relative=prefix+name;report['source_hashes'][relative]=runtime.sha256(p)
  target=OUT/'source'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
(OUT/'change.diff').write_bytes(subprocess.check_output(['git','diff','HEAD'],cwd=ROOT))
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
processes=runtime.Processes(OUT,1800)
def save():
 report['processes']=processes.rows;runtime.write_json(OUT/'snapshot.json',report)
save()
exe=ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/x/leant/build/leant/leant.exe'
kernel=Path('C:/Users/vresh/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean.exe')
backend=Path('C:/Users/vresh/AppData/Local/Python/pythoncore-3.14-64/Lib/site-packages/lean_interact/cache/augustepoiroux/repl/repl_v1.3.18_lean-toolchain-v4.32.0/.lake/build/bin/repl.exe')
try:
 build=processes.run('strict-build',['cabal','build','exe:leant','test:leant-synth-tests','--ghc-options=-Werror','-j1'],cwd=ROOT)
 assert build.returncode==0,'strict build failed'
 report['runtime_hashes']={str(p):runtime.sha256(p) for p in [exe,kernel,backend]};save()
 processes.timeout=3600
 command=[sys.executable,'-X','utf8','-B','test-church/behavior_extended_probe.py','--leant',str(exe),'--spec-dir',str(ROOT/'lib/Djex/test-church'),'--output',str(OUT/'run'),
  '--lean',str(kernel),'--lean-runtime',str(kernel),'--backend',str(backend),'--toolchain','','--engine','djinn','--operation','length',
  '--window','65536','--budget','500000','--steps','100000','--djinn-strategy','interleave','--timeout','90','--process-timeout','900']
 live=processes.run('length',command,cwd=ROOT)
 result=json.loads((OUT/'run/results.json').read_text())
 case=next(r for r in result['cells'] if r['operation']=='length')
 lines=Path(case['input']['path']).read_text().splitlines()
 assert sum(line.startswith(':synth ') for line in lines)==1
 control='\n'.join(line.split(' where ',1)[0]+' where False' if line.startswith(':synth ') else line for line in lines)+'\n'
 (OUT/'provider-false.commands.txt').write_text(control,encoding='utf-8')
 processes.timeout=900
 negative=processes.run('provider-false',[str(exe),'--plain'],source=control,cwd=ROOT)
 matches=re.findall(r'supplied behavioral assertion: (\d+) passed, (\d+) falsified, (\d+) inconclusive',negative.stdout)
 assert len(matches)==1 and matches[0][0]=='0' and int(matches[0][1])>0 and matches[0][2]=='0'
 assert not re.search(r'(?m)^\s+it\d+\s',negative.stdout)
 provider_lines=[line for line in negative.stdout.splitlines() if line.startswith('debug provider:')]
 assert len(provider_lines)==2 and all(any(name in line for line in provider_lines) for name in ['BehaviorExtendedNumeric.zero','BehaviorExtendedNumeric.successor'])
 assert negative.returncode==0
 report['provider_false']={'status':'passed','observations':list(map(int,matches[0])),'exact_two_providers_observed':True}
 report['length_status']=case['status'];report['status']='passed' if live.returncode==0 else 'failed'
except BaseException as error:
 report['status']='failed';report['failure']=type(error).__name__+': '+str(error)
finally:
 report['sources_unchanged']=all(runtime.sha256(ROOT/name)==value for name,value in report['source_hashes'].items())
 report['runtimes_unchanged']=all(runtime.sha256(Path(name))==value for name,value in report.get('runtime_hashes',{}).items())
 report['controller_unchanged']=(OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
 if not all(report[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged']):report['status']='failed'
 save()
print(report['status'],report.get('failure',''),flush=True)
sys.exit(0 if report['status']=='passed' else 1)
