set_option autoImplicit false
namespace BehaviorPartialReplay
end BehaviorPartialReplay
def BehaviorPartialReplay.candidate : (∀ (church0 : Type) (church1 : Type), (church0 → ((∀ (church2 : Type), ((church1 → church2) → ((church0 → church2) → church2))) → church0))) :=
  fun _ _ x f => f _ (fun _ => x) (fun y => f _ (fun _ => x) (fun _ => y))
set_option linter.unusedVariables false
namespace BehaviorPartial
universe u v
abbrev CList (A : Type u) := ∀ R : Type, (A → R → R) → R → R
abbrev CMaybe (A : Type u) := ∀ R : Type, R → (A → R) → R
abbrev CEither (A : Type u) (B : Type v) := ∀ R : Type, (A → R) → (B → R) → R
abbrev CPair (A : Type u) (B : Type v) := ∀ R : Type, (A → B → R) → R
abbrev CBool := ∀ R : Type, R → R → R
def enc {A : Type} (xs : List A) : CList A := fun _ step zero => xs.foldr step zero
def dec {A : Type} (xs : CList A) : List A := xs (List A) List.cons []
def maybe {A : Type} (m : Option A) : CMaybe A := fun _ zero some => m.elim zero some
def either {A B : Type} (e : Sum A B) : CEither A B := fun _ onLeft onRight => e.elim onLeft onRight
def bool (flag : Bool) : CBool := fun _ yes no => if flag then yes else no
def pair {A B : Type} (p : A × B) : CPair A B := fun _ k => k p.1 p.2
def decPair {A B : Type} (p : CPair A B) : A × B := p (A × B) Prod.mk
def dict {A B : Type} (xs : List (A × B)) : CList (CPair A B) := fun _ step zero => xs.foldr (fun p rest => step (fun _ k => k p.1 p.2) rest) zero
end BehaviorPartial
def BehaviorPartial.check_fromRight (f : (∀ (church0 : Type) (church1 : Type), (church0 → ((∀ (church2 : Type), ((church1 → church2) → ((church0 → church2) → church2))) → church0)))) : Bool := (((((((f) (Int) (Bool) (((-99) : Int)) ((BehaviorPartial.either (Sum.inl (false : Bool))))) == ((-99) : Int)) && ((((f) (Int) (Bool) (((-99) : Int)) ((BehaviorPartial.either (Sum.inl (true : Bool))))) == ((-99) : Int)) && (((f) (Int) (Bool) (((-99) : Int)) ((BehaviorPartial.either (Sum.inr ((-5) : Int))))) == ((-5) : Int)))) && ((((f) (Int) (Bool) (((-99) : Int)) ((BehaviorPartial.either (Sum.inr ((2) : Int))))) == ((2) : Int)) && ((((f) (Int) (Bool) (((99) : Int)) ((BehaviorPartial.either (Sum.inl (false : Bool))))) == ((99) : Int)) && (((f) (Int) (Bool) (((99) : Int)) ((BehaviorPartial.either (Sum.inl (true : Bool))))) == ((99) : Int))))) && (((((f) (Int) (Bool) (((99) : Int)) ((BehaviorPartial.either (Sum.inr ((-5) : Int))))) == ((-5) : Int)) && ((((f) (Int) (Bool) (((99) : Int)) ((BehaviorPartial.either (Sum.inr ((2) : Int))))) == ((2) : Int)) && (((f) (Bool) (Int) ((false : Bool)) ((BehaviorPartial.either (Sum.inl ((-5) : Int))))) == (false : Bool)))) && ((((f) (Bool) (Int) ((false : Bool)) ((BehaviorPartial.either (Sum.inl ((2) : Int))))) == (false : Bool)) && ((((f) (Bool) (Int) ((false : Bool)) ((BehaviorPartial.either (Sum.inr (false : Bool))))) == (false : Bool)) && (((f) (Bool) (Int) ((false : Bool)) ((BehaviorPartial.either (Sum.inr (true : Bool))))) == (true : Bool)))))) && ((((((f) (Bool) (Int) ((true : Bool)) ((BehaviorPartial.either (Sum.inl ((-5) : Int))))) == (true : Bool)) && ((((f) (Bool) (Int) ((true : Bool)) ((BehaviorPartial.either (Sum.inl ((2) : Int))))) == (true : Bool)) && (((f) (Bool) (Int) ((true : Bool)) ((BehaviorPartial.either (Sum.inr (false : Bool))))) == (false : Bool)))) && ((((f) (Bool) (Int) ((true : Bool)) ((BehaviorPartial.either (Sum.inr (true : Bool))))) == (true : Bool)) && ((((f) ((Int × Bool)) (String) ((((-99),false) : (Int × Bool))) ((BehaviorPartial.either (Sum.inl ("" : String))))) == (((-99),false) : (Int × Bool))) && (((f) ((Int × Bool)) (String) ((((-99),false) : (Int × Bool))) ((BehaviorPartial.either (Sum.inl ("other" : String))))) == (((-99),false) : (Int × Bool)))))) && (((((f) ((Int × Bool)) (String) ((((-99),false) : (Int × Bool))) ((BehaviorPartial.either (Sum.inr (((1),false) : (Int × Bool)))))) == (((1),false) : (Int × Bool))) && ((((f) ((Int × Bool)) (String) ((((-99),false) : (Int × Bool))) ((BehaviorPartial.either (Sum.inr (((2),true) : (Int × Bool)))))) == (((2),true) : (Int × Bool))) && (((f) ((Int × Bool)) (String) ((((99),true) : (Int × Bool))) ((BehaviorPartial.either (Sum.inl ("" : String))))) == (((99),true) : (Int × Bool))))) && ((((f) ((Int × Bool)) (String) ((((99),true) : (Int × Bool))) ((BehaviorPartial.either (Sum.inl ("other" : String))))) == (((99),true) : (Int × Bool))) && ((((f) ((Int × Bool)) (String) ((((99),true) : (Int × Bool))) ((BehaviorPartial.either (Sum.inr (((1),false) : (Int × Bool)))))) == (((1),false) : (Int × Bool))) && (((f) ((Int × Bool)) (String) ((((99),true) : (Int × Bool))) ((BehaviorPartial.either (Sum.inr (((2),true) : (Int × Bool)))))) == (((2),true) : (Int × Bool))))))))
theorem BehaviorPartialReplay.candidate_passes_original_oracle : BehaviorPartial.check_fromRight (BehaviorPartialReplay.candidate) = true := by decide
#print axioms BehaviorPartialReplay.candidate
#print axioms BehaviorPartial.CList
#print axioms BehaviorPartial.CMaybe
#print axioms BehaviorPartial.CEither
#print axioms BehaviorPartial.CPair
#print axioms BehaviorPartial.CBool
#print axioms BehaviorPartial.enc
#print axioms BehaviorPartial.dec
#print axioms BehaviorPartial.maybe
#print axioms BehaviorPartial.either
#print axioms BehaviorPartial.bool
#print axioms BehaviorPartial.pair
#print axioms BehaviorPartial.decPair
#print axioms BehaviorPartial.dict
#print axioms BehaviorPartial.check_fromRight
#print axioms BehaviorPartialReplay.candidate_passes_original_oracle
