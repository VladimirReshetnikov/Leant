set_option autoImplicit false
set_option linter.unusedVariables false
namespace BehaviorPartial
universe u v
abbrev CList (A : Type u) := ∀ R : Type, (A → R → R) → R → R
abbrev CMaybe (A : Type u) := ∀ R : Type, R → (A → R) → R
abbrev CEither (A : Type u) (B : Type v) := ∀ R : Type, (A → R) → (B → R) → R
abbrev CPair (A : Type u) (B : Type v) := ∀ R : Type, (A → B → R) → R
abbrev CBool := ∀ R : Type, R → R → R
def enc {A : Type} (xs : List A) : CList A := fun _ step zero => xs.foldr step zero
def dec {A : Type} (xs : CList A) : List A := xs (List A) List.cons []
def maybe {A : Type} (m : Option A) : CMaybe A := fun _ zero some => m.elim zero some
def either {A B : Type} (e : Sum A B) : CEither A B := fun _ onLeft onRight => e.elim onLeft onRight
def bool (flag : Bool) : CBool := fun _ yes no => if flag then yes else no
def pair {A B : Type} (p : A × B) : CPair A B := fun _ k => k p.1 p.2
def decPair {A B : Type} (p : CPair A B) : A × B := p (A × B) Prod.mk
def dict {A B : Type} (xs : List (A × B)) : CList (CPair A B) := fun _ step zero => xs.foldr (fun p rest => step (fun _ k => k p.1 p.2) rest) zero
end BehaviorPartial
def BehaviorPartial.check_fromJust (f : (∀ (church0 : Type), (church0 → ((∀ (church1 : Type), (church1 → ((church0 → church1) → church1))) → church0)))) : Bool := (((((((f) (Int) (((-99) : Int)) ((BehaviorPartial.maybe (none)))) == ((-99) : Int)) && ((((f) (Int) (((-99) : Int)) ((BehaviorPartial.maybe ((some ((-5) : Int)))))) == ((-5) : Int)) && (((f) (Int) (((-99) : Int)) ((BehaviorPartial.maybe ((some ((2) : Int)))))) == ((2) : Int)))) && ((((f) (Int) (((-99) : Int)) ((BehaviorPartial.maybe ((some ((4) : Int)))))) == ((4) : Int)) && ((((f) (Int) (((99) : Int)) ((BehaviorPartial.maybe (none)))) == ((99) : Int)) && (((f) (Int) (((99) : Int)) ((BehaviorPartial.maybe ((some ((-5) : Int)))))) == ((-5) : Int))))) && (((((f) (Int) (((99) : Int)) ((BehaviorPartial.maybe ((some ((2) : Int)))))) == ((2) : Int)) && ((((f) (Int) (((99) : Int)) ((BehaviorPartial.maybe ((some ((4) : Int)))))) == ((4) : Int)) && (((f) (Bool) ((false : Bool)) ((BehaviorPartial.maybe (none)))) == (false : Bool)))) && ((((f) (Bool) ((false : Bool)) ((BehaviorPartial.maybe ((some (false : Bool)))))) == (false : Bool)) && ((((f) (Bool) ((false : Bool)) ((BehaviorPartial.maybe ((some (true : Bool)))))) == (true : Bool)) && (((f) (Bool) ((false : Bool)) ((BehaviorPartial.maybe ((some (true : Bool)))))) == (true : Bool)))))) && ((((((f) (Bool) ((false : Bool)) ((BehaviorPartial.maybe ((some (false : Bool)))))) == (false : Bool)) && ((((f) (Bool) ((true : Bool)) ((BehaviorPartial.maybe (none)))) == (true : Bool)) && (((f) (Bool) ((true : Bool)) ((BehaviorPartial.maybe ((some (false : Bool)))))) == (false : Bool)))) && ((((f) (Bool) ((true : Bool)) ((BehaviorPartial.maybe ((some (true : Bool)))))) == (true : Bool)) && ((((f) (Bool) ((true : Bool)) ((BehaviorPartial.maybe ((some (true : Bool)))))) == (true : Bool)) && (((f) (Bool) ((true : Bool)) ((BehaviorPartial.maybe ((some (false : Bool)))))) == (false : Bool))))) && (((((f) ((Int × Bool)) ((((-99),false) : (Int × Bool))) ((BehaviorPartial.maybe (none)))) == (((-99),false) : (Int × Bool))) && ((((f) ((Int × Bool)) ((((-99),false) : (Int × Bool))) ((BehaviorPartial.maybe ((some (((1),false) : (Int × Bool))))))) == (((1),false) : (Int × Bool))) && (((f) ((Int × Bool)) ((((-99),false) : (Int × Bool))) ((BehaviorPartial.maybe ((some (((2),true) : (Int × Bool))))))) == (((2),true) : (Int × Bool))))) && ((((f) ((Int × Bool)) ((((99),true) : (Int × Bool))) ((BehaviorPartial.maybe (none)))) == (((99),true) : (Int × Bool))) && ((((f) ((Int × Bool)) ((((99),true) : (Int × Bool))) ((BehaviorPartial.maybe ((some (((1),false) : (Int × Bool))))))) == (((1),false) : (Int × Bool))) && (((f) ((Int × Bool)) ((((99),true) : (Int × Bool))) ((BehaviorPartial.maybe ((some (((2),true) : (Int × Bool))))))) == (((2),true) : (Int × Bool))))))))
namespace BehaviorPartialOracle
def head {A : Type} (d : A) (xs : List A) : A := match xs with | [] => d | x :: _ => x
def last {A : Type} (d : A) (xs : List A) : A := xs.foldl (fun _ x => x) d
def indexOr {A : Type} (d : A) (n : Int) : List A → A
  | [] => d
  | x :: xs => if n < 0 then d else if n = 0 then x else indexOr d (n - 1) xs
def foldl1 {A : Type} (d : A) (step : A → A → A) (xs : List A) : A := match xs with | [] => d | x :: rest => rest.foldl step x
def foldr1 {A : Type} (d : A) (step : A → A → A) (xs : List A) : A := (xs.foldr (fun x rest => some (rest.elim x (step x))) (none : Option A)).getD d
end BehaviorPartialOracle
namespace BehaviorPartialControl
def witness_fromJust : (∀ (church0 : Type), (church0 → ((∀ (church1 : Type), (church1 → ((church0 → church1) → church1))) → church0))) := fun A d m => m A d id
theorem witness_fromJust_passes : BehaviorPartial.check_fromJust (BehaviorPartialControl.witness_fromJust) = true := by decide
def wrong_fromJust_always_default : (∀ (church0 : Type), (church0 → ((∀ (church1 : Type), (church1 → ((church0 → church1) → church1))) → church0))) := fun _ d _ => d
theorem wrong_fromJust_always_default_rejected : BehaviorPartial.check_fromJust BehaviorPartialControl.wrong_fromJust_always_default = false := by decide
end BehaviorPartialControl
#print axioms BehaviorPartial.CList
#print axioms BehaviorPartial.CMaybe
#print axioms BehaviorPartial.CEither
#print axioms BehaviorPartial.CPair
#print axioms BehaviorPartial.CBool
#print axioms BehaviorPartial.enc
#print axioms BehaviorPartial.dec
#print axioms BehaviorPartial.maybe
#print axioms BehaviorPartial.either
#print axioms BehaviorPartial.bool
#print axioms BehaviorPartial.pair
#print axioms BehaviorPartial.decPair
#print axioms BehaviorPartial.dict
#print axioms BehaviorPartial.check_fromJust
#print axioms BehaviorPartialOracle.head
#print axioms BehaviorPartialOracle.last
#print axioms BehaviorPartialOracle.indexOr
#print axioms BehaviorPartialOracle.foldl1
#print axioms BehaviorPartialOracle.foldr1
#print axioms BehaviorPartialControl.witness_fromJust
#print axioms BehaviorPartialControl.witness_fromJust_passes
#print axioms BehaviorPartialControl.wrong_fromJust_always_default
#print axioms BehaviorPartialControl.wrong_fromJust_always_default_rejected
