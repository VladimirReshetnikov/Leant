set_option autoImplicit false
set_option linter.unusedVariables false
namespace BehaviorPartial
universe u v
abbrev CList (A : Type u) := ∀ R : Type, (A → R → R) → R → R
abbrev CMaybe (A : Type u) := ∀ R : Type, R → (A → R) → R
abbrev CEither (A : Type u) (B : Type v) := ∀ R : Type, (A → R) → (B → R) → R
abbrev CPair (A : Type u) (B : Type v) := ∀ R : Type, (A → B → R) → R
abbrev CBool := ∀ R : Type, R → R → R
def enc {A : Type} (xs : List A) : CList A := fun _ step zero => xs.foldr step zero
def dec {A : Type} (xs : CList A) : List A := xs (List A) List.cons []
def maybe {A : Type} (m : Option A) : CMaybe A := fun _ zero some => m.elim zero some
def either {A B : Type} (e : Sum A B) : CEither A B := fun _ onLeft onRight => e.elim onLeft onRight
def bool (flag : Bool) : CBool := fun _ yes no => if flag then yes else no
def pair {A B : Type} (p : A × B) : CPair A B := fun _ k => k p.1 p.2
def decPair {A B : Type} (p : CPair A B) : A × B := p (A × B) Prod.mk
def dict {A B : Type} (xs : List (A × B)) : CList (CPair A B) := fun _ step zero => xs.foldr (fun p rest => step (fun _ k => k p.1 p.2) rest) zero
end BehaviorPartial
def BehaviorPartial.check_fromLeft (f : (∀ (church0 : Type) (church1 : Type), (church0 → ((∀ (church2 : Type), ((church0 → church2) → ((church1 → church2) → church2))) → church0)))) : Bool := (((((((f) (Int) (Bool) (((-99) : Int)) ((BehaviorPartial.either (Sum.inr (false : Bool))))) == ((-99) : Int)) && ((((f) (Int) (Bool) (((-99) : Int)) ((BehaviorPartial.either (Sum.inr (true : Bool))))) == ((-99) : Int)) && (((f) (Int) (Bool) (((-99) : Int)) ((BehaviorPartial.either (Sum.inl ((-5) : Int))))) == ((-5) : Int)))) && ((((f) (Int) (Bool) (((-99) : Int)) ((BehaviorPartial.either (Sum.inl ((2) : Int))))) == ((2) : Int)) && ((((f) (Int) (Bool) (((99) : Int)) ((BehaviorPartial.either (Sum.inr (false : Bool))))) == ((99) : Int)) && (((f) (Int) (Bool) (((99) : Int)) ((BehaviorPartial.either (Sum.inr (true : Bool))))) == ((99) : Int))))) && (((((f) (Int) (Bool) (((99) : Int)) ((BehaviorPartial.either (Sum.inl ((-5) : Int))))) == ((-5) : Int)) && ((((f) (Int) (Bool) (((99) : Int)) ((BehaviorPartial.either (Sum.inl ((2) : Int))))) == ((2) : Int)) && (((f) (Bool) (Int) ((false : Bool)) ((BehaviorPartial.either (Sum.inr ((-5) : Int))))) == (false : Bool)))) && ((((f) (Bool) (Int) ((false : Bool)) ((BehaviorPartial.either (Sum.inr ((2) : Int))))) == (false : Bool)) && ((((f) (Bool) (Int) ((false : Bool)) ((BehaviorPartial.either (Sum.inl (false : Bool))))) == (false : Bool)) && (((f) (Bool) (Int) ((false : Bool)) ((BehaviorPartial.either (Sum.inl (true : Bool))))) == (true : Bool)))))) && ((((((f) (Bool) (Int) ((true : Bool)) ((BehaviorPartial.either (Sum.inr ((-5) : Int))))) == (true : Bool)) && ((((f) (Bool) (Int) ((true : Bool)) ((BehaviorPartial.either (Sum.inr ((2) : Int))))) == (true : Bool)) && (((f) (Bool) (Int) ((true : Bool)) ((BehaviorPartial.either (Sum.inl (false : Bool))))) == (false : Bool)))) && ((((f) (Bool) (Int) ((true : Bool)) ((BehaviorPartial.either (Sum.inl (true : Bool))))) == (true : Bool)) && ((((f) ((Int × Bool)) (String) ((((-99),false) : (Int × Bool))) ((BehaviorPartial.either (Sum.inr ("" : String))))) == (((-99),false) : (Int × Bool))) && (((f) ((Int × Bool)) (String) ((((-99),false) : (Int × Bool))) ((BehaviorPartial.either (Sum.inr ("other" : String))))) == (((-99),false) : (Int × Bool)))))) && (((((f) ((Int × Bool)) (String) ((((-99),false) : (Int × Bool))) ((BehaviorPartial.either (Sum.inl (((1),false) : (Int × Bool)))))) == (((1),false) : (Int × Bool))) && ((((f) ((Int × Bool)) (String) ((((-99),false) : (Int × Bool))) ((BehaviorPartial.either (Sum.inl (((2),true) : (Int × Bool)))))) == (((2),true) : (Int × Bool))) && (((f) ((Int × Bool)) (String) ((((99),true) : (Int × Bool))) ((BehaviorPartial.either (Sum.inr ("" : String))))) == (((99),true) : (Int × Bool))))) && ((((f) ((Int × Bool)) (String) ((((99),true) : (Int × Bool))) ((BehaviorPartial.either (Sum.inr ("other" : String))))) == (((99),true) : (Int × Bool))) && ((((f) ((Int × Bool)) (String) ((((99),true) : (Int × Bool))) ((BehaviorPartial.either (Sum.inl (((1),false) : (Int × Bool)))))) == (((1),false) : (Int × Bool))) && (((f) ((Int × Bool)) (String) ((((99),true) : (Int × Bool))) ((BehaviorPartial.either (Sum.inl (((2),true) : (Int × Bool)))))) == (((2),true) : (Int × Bool))))))))
namespace BehaviorPartialOracle
def head {A : Type} (d : A) (xs : List A) : A := match xs with | [] => d | x :: _ => x
def last {A : Type} (d : A) (xs : List A) : A := xs.foldl (fun _ x => x) d
def indexOr {A : Type} (d : A) (n : Int) : List A → A
  | [] => d
  | x :: xs => if n < 0 then d else if n = 0 then x else indexOr d (n - 1) xs
def foldl1 {A : Type} (d : A) (step : A → A → A) (xs : List A) : A := match xs with | [] => d | x :: rest => rest.foldl step x
def foldr1 {A : Type} (d : A) (step : A → A → A) (xs : List A) : A := (xs.foldr (fun x rest => some (rest.elim x (step x))) (none : Option A)).getD d
end BehaviorPartialOracle
namespace BehaviorPartialControl
def witness_fromLeft : (∀ (church0 : Type) (church1 : Type), (church0 → ((∀ (church2 : Type), ((church0 → church2) → ((church1 → church2) → church2))) → church0))) := fun A B d e => e A id (fun _ => d)
theorem witness_fromLeft_passes : BehaviorPartial.check_fromLeft (BehaviorPartialControl.witness_fromLeft) = true := by decide
def wrong_fromLeft_always_default : (∀ (church0 : Type) (church1 : Type), (church0 → ((∀ (church2 : Type), ((church0 → church2) → ((church1 → church2) → church2))) → church0))) := fun _ _ d _ => d
theorem wrong_fromLeft_always_default_rejected : BehaviorPartial.check_fromLeft BehaviorPartialControl.wrong_fromLeft_always_default = false := by decide
end BehaviorPartialControl
#print axioms BehaviorPartial.CList
#print axioms BehaviorPartial.CMaybe
#print axioms BehaviorPartial.CEither
#print axioms BehaviorPartial.CPair
#print axioms BehaviorPartial.CBool
#print axioms BehaviorPartial.enc
#print axioms BehaviorPartial.dec
#print axioms BehaviorPartial.maybe
#print axioms BehaviorPartial.either
#print axioms BehaviorPartial.bool
#print axioms BehaviorPartial.pair
#print axioms BehaviorPartial.decPair
#print axioms BehaviorPartial.dict
#print axioms BehaviorPartial.check_fromLeft
#print axioms BehaviorPartialOracle.head
#print axioms BehaviorPartialOracle.last
#print axioms BehaviorPartialOracle.indexOr
#print axioms BehaviorPartialOracle.foldl1
#print axioms BehaviorPartialOracle.foldr1
#print axioms BehaviorPartialControl.witness_fromLeft
#print axioms BehaviorPartialControl.witness_fromLeft_passes
#print axioms BehaviorPartialControl.wrong_fromLeft_always_default
#print axioms BehaviorPartialControl.wrong_fromLeft_always_default_rejected
