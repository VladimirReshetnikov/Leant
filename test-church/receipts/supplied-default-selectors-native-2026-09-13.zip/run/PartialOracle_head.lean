set_option autoImplicit false
set_option linter.unusedVariables false
namespace BehaviorPartial
universe u v
abbrev CList (A : Type u) := ∀ R : Type, (A → R → R) → R → R
abbrev CMaybe (A : Type u) := ∀ R : Type, R → (A → R) → R
abbrev CEither (A : Type u) (B : Type v) := ∀ R : Type, (A → R) → (B → R) → R
abbrev CPair (A : Type u) (B : Type v) := ∀ R : Type, (A → B → R) → R
abbrev CBool := ∀ R : Type, R → R → R
def enc {A : Type} (xs : List A) : CList A := fun _ step zero => xs.foldr step zero
def dec {A : Type} (xs : CList A) : List A := xs (List A) List.cons []
def maybe {A : Type} (m : Option A) : CMaybe A := fun _ zero some => m.elim zero some
def either {A B : Type} (e : Sum A B) : CEither A B := fun _ onLeft onRight => e.elim onLeft onRight
def bool (flag : Bool) : CBool := fun _ yes no => if flag then yes else no
def pair {A B : Type} (p : A × B) : CPair A B := fun _ k => k p.1 p.2
def decPair {A B : Type} (p : CPair A B) : A × B := p (A × B) Prod.mk
def dict {A B : Type} (xs : List (A × B)) : CList (CPair A B) := fun _ step zero => xs.foldr (fun p rest => step (fun _ k => k p.1 p.2) rest) zero
end BehaviorPartial
def BehaviorPartial.check_head (f : (∀ (church0 : Type), (church0 → ((∀ (church1 : Type), ((church0 → (church1 → church1)) → (church1 → church1))) → church0)))) : Bool := (((((((f) (Int) (((-99) : Int)) ((BehaviorPartial.enc ([] : (List Int))))) == ((-99) : Int)) && ((((f) (Int) (((-99) : Int)) ((BehaviorPartial.enc ([(-5)] : (List Int))))) == ((-5) : Int)) && (((f) (Int) (((-99) : Int)) ((BehaviorPartial.enc ([(2),(-3),(4)] : (List Int))))) == ((2) : Int)))) && ((((f) (Int) (((-99) : Int)) ((BehaviorPartial.enc ([(4),(7)] : (List Int))))) == ((4) : Int)) && ((((f) (Int) (((99) : Int)) ((BehaviorPartial.enc ([] : (List Int))))) == ((99) : Int)) && (((f) (Int) (((99) : Int)) ((BehaviorPartial.enc ([(-5)] : (List Int))))) == ((-5) : Int))))) && (((((f) (Int) (((99) : Int)) ((BehaviorPartial.enc ([(2),(-3),(4)] : (List Int))))) == ((2) : Int)) && ((((f) (Int) (((99) : Int)) ((BehaviorPartial.enc ([(4),(7)] : (List Int))))) == ((4) : Int)) && (((f) (Bool) ((false : Bool)) ((BehaviorPartial.enc ([] : (List Bool))))) == (false : Bool)))) && ((((f) (Bool) ((false : Bool)) ((BehaviorPartial.enc ([false] : (List Bool))))) == (false : Bool)) && ((((f) (Bool) ((false : Bool)) ((BehaviorPartial.enc ([true] : (List Bool))))) == (true : Bool)) && (((f) (Bool) ((false : Bool)) ((BehaviorPartial.enc ([true,false] : (List Bool))))) == (true : Bool)))))) && ((((((f) (Bool) ((false : Bool)) ((BehaviorPartial.enc ([false,true] : (List Bool))))) == (false : Bool)) && ((((f) (Bool) ((true : Bool)) ((BehaviorPartial.enc ([] : (List Bool))))) == (true : Bool)) && (((f) (Bool) ((true : Bool)) ((BehaviorPartial.enc ([false] : (List Bool))))) == (false : Bool)))) && ((((f) (Bool) ((true : Bool)) ((BehaviorPartial.enc ([true] : (List Bool))))) == (true : Bool)) && ((((f) (Bool) ((true : Bool)) ((BehaviorPartial.enc ([true,false] : (List Bool))))) == (true : Bool)) && (((f) (Bool) ((true : Bool)) ((BehaviorPartial.enc ([false,true] : (List Bool))))) == (false : Bool))))) && (((((f) ((Int × Bool)) ((((-99),false) : (Int × Bool))) ((BehaviorPartial.enc ([] : (List (Int × Bool)))))) == (((-99),false) : (Int × Bool))) && ((((f) ((Int × Bool)) ((((-99),false) : (Int × Bool))) ((BehaviorPartial.enc ([((1),false)] : (List (Int × Bool)))))) == (((1),false) : (Int × Bool))) && (((f) ((Int × Bool)) ((((-99),false) : (Int × Bool))) ((BehaviorPartial.enc ([((2),true),((-1),false)] : (List (Int × Bool)))))) == (((2),true) : (Int × Bool))))) && ((((f) ((Int × Bool)) ((((99),true) : (Int × Bool))) ((BehaviorPartial.enc ([] : (List (Int × Bool)))))) == (((99),true) : (Int × Bool))) && ((((f) ((Int × Bool)) ((((99),true) : (Int × Bool))) ((BehaviorPartial.enc ([((1),false)] : (List (Int × Bool)))))) == (((1),false) : (Int × Bool))) && (((f) ((Int × Bool)) ((((99),true) : (Int × Bool))) ((BehaviorPartial.enc ([((2),true),((-1),false)] : (List (Int × Bool)))))) == (((2),true) : (Int × Bool))))))))
namespace BehaviorPartialOracle
def head {A : Type} (d : A) (xs : List A) : A := match xs with | [] => d | x :: _ => x
def last {A : Type} (d : A) (xs : List A) : A := xs.foldl (fun _ x => x) d
def indexOr {A : Type} (d : A) (n : Int) : List A → A
  | [] => d
  | x :: xs => if n < 0 then d else if n = 0 then x else indexOr d (n - 1) xs
def foldl1 {A : Type} (d : A) (step : A → A → A) (xs : List A) : A := match xs with | [] => d | x :: rest => rest.foldl step x
def foldr1 {A : Type} (d : A) (step : A → A → A) (xs : List A) : A := (xs.foldr (fun x rest => some (rest.elim x (step x))) (none : Option A)).getD d
end BehaviorPartialOracle
namespace BehaviorPartialControl
def witness_head : (∀ (church0 : Type), (church0 → ((∀ (church1 : Type), ((church0 → (church1 → church1)) → (church1 → church1))) → church0))) := fun A d xs => BehaviorPartialOracle.head d (BehaviorPartial.dec xs)
theorem witness_head_passes : BehaviorPartial.check_head (BehaviorPartialControl.witness_head) = true := by decide
def wrong_head_always_default : (∀ (church0 : Type), (church0 → ((∀ (church1 : Type), ((church0 → (church1 → church1)) → (church1 → church1))) → church0))) := fun _ d _ => d
theorem wrong_head_always_default_rejected : BehaviorPartial.check_head BehaviorPartialControl.wrong_head_always_default = false := by decide
def wrong_head_wrong_end : (∀ (church0 : Type), (church0 → ((∀ (church1 : Type), ((church0 → (church1 → church1)) → (church1 → church1))) → church0))) := fun A d xs => BehaviorPartialOracle.last d (BehaviorPartial.dec xs)
theorem wrong_head_wrong_end_rejected : BehaviorPartial.check_head BehaviorPartialControl.wrong_head_wrong_end = false := by decide
end BehaviorPartialControl
#print axioms BehaviorPartial.CList
#print axioms BehaviorPartial.CMaybe
#print axioms BehaviorPartial.CEither
#print axioms BehaviorPartial.CPair
#print axioms BehaviorPartial.CBool
#print axioms BehaviorPartial.enc
#print axioms BehaviorPartial.dec
#print axioms BehaviorPartial.maybe
#print axioms BehaviorPartial.either
#print axioms BehaviorPartial.bool
#print axioms BehaviorPartial.pair
#print axioms BehaviorPartial.decPair
#print axioms BehaviorPartial.dict
#print axioms BehaviorPartial.check_head
#print axioms BehaviorPartialOracle.head
#print axioms BehaviorPartialOracle.last
#print axioms BehaviorPartialOracle.indexOr
#print axioms BehaviorPartialOracle.foldl1
#print axioms BehaviorPartialOracle.foldr1
#print axioms BehaviorPartialControl.witness_head
#print axioms BehaviorPartialControl.witness_head_passes
#print axioms BehaviorPartialControl.wrong_head_always_default
#print axioms BehaviorPartialControl.wrong_head_always_default_rejected
#print axioms BehaviorPartialControl.wrong_head_wrong_end
#print axioms BehaviorPartialControl.wrong_head_wrong_end_rejected
