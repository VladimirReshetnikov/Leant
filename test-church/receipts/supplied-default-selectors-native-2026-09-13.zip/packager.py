from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path('C:/Leant')
OUT = ROOT / 'dist-newstyle/church-default-selectors-native-v1'
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

data = json.loads((OUT/'run/results.json').read_text())
snapshot = json.loads((OUT/'snapshot.json').read_text())
assert snapshot['status'] == 'passed' and all(snapshot[k] for k in ('sources_unchanged', 'executable_unchanged', 'controller_unchanged'))
assert data['status'] == 'passed' and data['accepted']
assert data['candidate_count'] == 12 and data['false_control_count'] == 3 and data['passed_oracle_preflights'] == 4
assert data['sources_unchanged'] and data['executables_unchanged']
assert len(data['processes']) == 31 and all(p['exit_code'] == 0 and not p['timed_out'] for p in data['processes'])
for path, expected in snapshot['source_hashes'].items():
    assert digest(ROOT/path) == expected, path
for pins in (data['source_hashes'], data['executable_hashes']):
    for path, expected in pins.items():
        assert digest(Path(path)) == expected, path
falsifications = {}
inventories = 0
for row in data['cells']:
    assert row['accepted'] and row['status'] == 'passed'
    if row['operation'] == 'reject_all':
        observations = row['live_outcome']['observations']
        assert observations['passed'] == 0 and observations['falsified'] > 0 and observations['inconclusive'] == 0
        falsifications[row['engine']] = observations['falsified']
    else:
        replay = row['replay']
        assert replay['status'] == 'passed' and replay['candidate_declared_before_observation_helpers']
        assert replay['actual_axiom_inventories'] == replay['expected_axiom_inventories']
        assert not any(replay['actual_axiom_inventories'].values())
        assert row['finite_observation_count'] == 24
        inventories += len(replay['actual_axiom_inventories'])
        assert row['actual_provider_inventory']['count'] == 0

(OUT/'packager.py').write_bytes(Path(__file__).read_bytes())
manifest, omitted = {}, {}
for path in sorted(OUT.rglob('*')):
    if not path.is_file():
        continue
    name = path.relative_to(OUT).as_posix()
    entry = {'sha256': digest(path), 'bytes': path.stat().st_size}
    if path.suffix in ('.exe', '.o', '.hi', '.dyn_o', '.dyn_hi', '.olean', '.ilean'):
        omitted[name] = entry
    else:
        manifest[name] = entry
archive = ROOT/'test-church/receipts/supplied-default-selectors-native-2026-09-13.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in manifest:
        z.write(OUT/name, name)
    z.writestr('archive-manifest.json', json.dumps({'artifacts': manifest, 'omitted_build_products': omitted}, indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(manifest) | {'archive-manifest.json'}
    for name, expected in manifest.items():
        raw = z.read(name)
        assert len(raw) == expected['bytes'] and hashlib.sha256(raw).hexdigest() == expected['sha256'], name
receipt = {
    'schema': 'church-supplied-default-native-selectors-v1', 'status': 'behavior_batch_passed',
    'production_release_accepted': False, 'source_base_commit': snapshot['base_commit'],
    'dependency_commit': snapshot['dependency_commit'], 'production_changes_uncommitted': True,
    'scope': 'head, fromJust, fromLeft, fromRight with supplied defaults in Lean Djinn, Exference and Both',
    'counts': {'synthesis_cells': 12, 'exact_candidate_replays': 12, 'finite_observations_per_cell': 24,
               'actual_false_queries': 3, 'false_falsifications_by_engine': falsifications,
               'independent_oracle_modules': 4, 'empty_candidate_replay_inventories': inventories,
               'owned_processes': 31, 'frozen_source_files': len(snapshot['source_hashes'])},
    'settings': data['settings'], 'sources_and_runtimes_unchanged': True,
    'all_owned_processes_exit_zero': True, 'strict_build': 'passed -Werror',
    'raw_receipt_member': 'run/results.json',
    'archive': {'path': archive.name, 'sha256': digest(archive), 'bytes': archive.stat().st_size,
                'artifact_count': len(manifest), 'all_members_rehashed': True},
    'boundaries': ['Fresh behavior acceptance against the frozen working sources, not a full regression or constructor release.',
                   'The accepted production dependency is not promoted by this receipt.',
                   'Default arguments totalize the agreed counterparts; the original partial signatures are not declared total.',
                   'All generated replay declarations have empty axiom inventories.',
                   'Finite observations do not establish universal extensional equivalence.']}
path = ROOT/'test-church/receipts/supplied-default-selectors-native-2026-09-13.json'
path.write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'counts': receipt['counts'], 'archive': receipt['archive']}))
