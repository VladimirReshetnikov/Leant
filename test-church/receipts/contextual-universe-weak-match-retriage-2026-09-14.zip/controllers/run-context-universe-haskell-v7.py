"""Validate the intrinsic-unit core change after the native public gates."""
from pathlib import Path
import json
import os
import re
import shutil
import subprocess
import sys

ROOT = Path('C:/Leant-validation/contextual-universe-transport')
DJEX = ROOT / 'lib/Djex'
sys.path.insert(0, str(DJEX / 'test-church'))
import behavior_runtime as rt

parent_path = ROOT / 'dist-newstyle/context-universe-v13/results.json'
parent = json.loads(parent_path.read_text(encoding='utf-8'))
assert parent['status'] == 'passed' and parent['sources_unchanged'] and parent['runtimes_unchanged']
assert all(rt.sha256(ROOT / p) == h for p, h in parent['source_sha256'].items())
assert all(rt.sha256(Path(p)) == h for p, h in parent['runtime_sha256'].items())
OUT = rt.prepare_output_directory(ROOT / 'dist-newstyle/context-universe-haskell-v7')
sources = dict(parent['source_sha256'])
for path in [Path(__file__), DJEX / 'test-church/public_intrinsic_unit.py']:
    sources[path.relative_to(ROOT).as_posix()] = rt.sha256(path)
for name in sources:
    target = OUT / 'source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())
runner = rt.Processes(OUT, 2400)
report = dict(status='running', parent_sha256=rt.sha256(parent_path), source_sha256=sources,
              runtime_sha256=dict(parent['runtime_sha256']), gates=[])
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', leant_datadir=str(ROOT), djex_datadir=str(DJEX))

def save():
    report['processes'] = runner.rows
    rt.write_json(OUT / 'results.json', report)

try:
    save()
    built = runner.run('strict-haskell-build', ['cabal', 'build', 'djex:exe:djex', 'djex:test:exference-tests',
                                               '--ghc-options=-Werror', '-j1'], cwd=ROOT, env=env)
    report['gates'].append(dict(label='strict-haskell-build', exit_code=built.returncode))
    save()
    assert built.returncode == 0
    binaries = {}
    for target in ['djex:exe:djex', 'djex:test:exference-tests']:
        path = subprocess.check_output(['cabal', 'list-bin', target], cwd=ROOT).decode().strip()
        binaries[target] = path
        report['runtime_sha256'][path] = rt.sha256(Path(path))
    ghc = shutil.which('ghc')
    assert ghc
    report['runtime_sha256'][ghc] = rt.sha256(Path(ghc))
    version = runner.run('ghc-version', [ghc, '--numeric-version'], cwd=ROOT, env=env)
    assert version.returncode == 0
    report['ghc_version'] = version.stdout.strip()
    unit = binaries['djex:test:exference-tests']
    inventory = runner.run('exference-inventory', [unit, '--list-tests'], cwd=ROOT, env=env)
    names = inventory.stdout.splitlines()
    assert inventory.returncode == 0 and names
    report['unit_inventory'] = names
    save()
    tested = runner.run('exference-units', [unit, '--num-threads', '1'], cwd=ROOT, env=env)
    report['gates'].append(dict(label='exference-units', exit_code=tested.returncode, tests=len(names)))
    save()
    assert tested.returncode == 0 and re.findall(r'All (\d+) tests passed', tested.stdout) == [str(len(names))]
    exe = binaries['djex:exe:djex']
    public = runner.run('intrinsic-unit-public', [sys.executable, '-X', 'utf8', '-B', 'test-church/public_intrinsic_unit.py',
                                               '--exe', exe, '--backend', 'exference', '--output', str(OUT / 'intrinsic-unit-public')],
                        cwd=DJEX, env=env)
    path = OUT / 'intrinsic-unit-public/results.json'
    data = json.loads(path.read_text(encoding='utf-8'))
    report['gates'].append(dict(label='intrinsic-unit-public', exit_code=public.returncode,
                               receipt_sha256=rt.sha256(path), cases=len(data['queries'])))
    save()
    assert public.returncode == 0 and data['status'] == 'passed' and len(data['queries']) == 3
    extended = runner.run('extended-exference', [sys.executable, '-X', 'utf8', '-B', 'test-church/behavior_extended_probe.py',
                                              '--djex', exe, '--engine', 'exference', '--output', str(OUT / 'extended-exference')],
                          cwd=DJEX, env=env)
    path = OUT / 'extended-exference/results.json'
    data = json.loads(path.read_text(encoding='utf-8'))
    report['gates'].append(dict(label='extended-exference', exit_code=extended.returncode,
                               receipt_sha256=rt.sha256(path), accepted=data.get('passed_synthesis_cells')))
    save()
    assert extended.returncode == 0 and data['status'] == 'passed' and data['passed_synthesis_cells'] == 13
    report['status'] = 'passed'
except BaseException as failure:
    report.update(status='failed', failure=repr(failure))
finally:
    report['sources_unchanged'] = all(rt.sha256(ROOT / p) == h for p, h in sources.items())
    report['runtimes_unchanged'] = all(rt.sha256(Path(p)) == h for p, h in report['runtime_sha256'].items())
    if not report['sources_unchanged'] or not report['runtimes_unchanged']:
        report['status'] = 'failed'
    save()
print(report['status'], report.get('failure', ''), flush=True)
sys.exit(0 if report['status'] == 'passed' else 1)
