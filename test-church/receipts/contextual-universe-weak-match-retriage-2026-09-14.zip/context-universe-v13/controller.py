from pathlib import Path
import json
import os
import re
import subprocess
import sys

ROOT = Path('C:/Leant-validation/contextual-universe-transport')
sys.path.insert(0, str(ROOT / 'lib/Djex/test-church'))
import behavior_runtime as rt

baseline = Path('C:/Leant-validation/product-integration/dist-newstyle/sort-value-release-v2/results.json')
accepted = json.loads(baseline.read_text(encoding='utf-8'))
assert accepted['status'] == 'passed' and accepted['sources_unchanged'] and accepted['runtimes_unchanged']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT / 'lib/Djex').decode().strip() == 'eea33f2464ea5424cd4e74557d0b5368829a8cd8'
OUT = rt.prepare_output_directory(ROOT / 'dist-newstyle/context-universe-v13')
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
files = [Path(__file__), ROOT / 'test-unit/SortSourceSpec.hs', ROOT / 'test-context/run_products.py', ROOT / 'test-context/run_context_universes.py']
for directory in [ROOT, ROOT / 'lib/Djex']:
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=directory).decode().split('\0')
    files.extend(directory / name for name in names if name.endswith(('.hs', '.cabal', '.lean', '.py')) and (directory / name).is_file())
source = {}
for path in files:
    key = path.relative_to(ROOT).as_posix()
    source[key] = rt.sha256(path)
    target = OUT / 'source' / key
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(path.read_bytes())
report = dict(status='running', scope='Exact contextual Type binder universes, lexical graph opening domains and checked selected-type universes. Strict build and complete focused source-metadata tests only; live acceptance remains a separate gate.',
              native_release_sha256=rt.sha256(baseline), source_sha256=source, runtime_sha256={}, gates=[])
runner = rt.Processes(OUT, 1800)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', leant_datadir=str(ROOT), djex_datadir=str(ROOT / 'lib/Djex'))

def save():
    report['processes'] = runner.rows
    rt.write_json(OUT / 'results.json', report)

try:
    save()
    build = runner.run('strict-build', ['cabal', 'build', 'leant:exe:leant', 'leant:test:leant-synth-tests', 'djex:test:exference-engine-tests', '--ghc-options=-Werror', '-j1'], cwd=ROOT, env=env)
    report['gates'].append(dict(label='strict-build', exit_code=build.returncode))
    save()
    assert build.returncode == 0, 'strict contextual universe build failed'
    for name in ['leant:exe:leant', 'leant:test:leant-synth-tests', 'djex:test:exference-engine-tests']:
        binary = Path(subprocess.check_output(['cabal', 'list-bin', name], cwd=ROOT).decode().strip())
        report['runtime_sha256'][str(binary)] = rt.sha256(binary)
    engine_unit = next(path for path in report['runtime_sha256'] if path.endswith('exference-engine-tests.exe'))
    core = runner.run('intrinsic-unit-regressions', [engine_unit, '--num-threads', '1', '-p', '/intrinsic unit/'], cwd=ROOT, env=env)
    report['gates'].append(dict(label='intrinsic-unit-regressions', exit_code=core.returncode))
    save()
    assert core.returncode == 0 and 'All 2 tests passed' in core.stdout, 'intrinsic unit regression failed'
    unit = next(path for path in report['runtime_sha256'] if path.endswith('leant-synth-tests.exe'))
    pattern = '/Production lexical Given source metadata/ || /direct Lean lexical context rendering/'
    inventory = runner.run('focused-inventory', [unit, '--list-tests', '-p', pattern], cwd=ROOT, env=env)
    names = inventory.stdout.splitlines()
    assert inventory.returncode == 0 and len(names) >= 36 and all('Production lexical Given source metadata' in name or 'direct Lean lexical context rendering' in name for name in names)
    report['focused_inventory'] = names
    save()
    focused = runner.run('focused-context-units', [unit, '--num-threads', '1', '-p', pattern], cwd=ROOT, env=env)
    report['gates'].append(dict(label='focused-context-units', exit_code=focused.returncode))
    save()
    counts = re.findall(r'All (\d+) tests passed', focused.stdout)
    assert focused.returncode == 0 and counts == [str(len(names))], 'focused context universe tests failed or inventory mismatch'
    report['status'] = 'passed'
except BaseException as failure:
    report.update(status='failed', failure=repr(failure))
finally:
    report['sources_unchanged'] = all(rt.sha256(ROOT / path) == value for path, value in report['source_sha256'].items())
    report['runtimes_unchanged'] = all(rt.sha256(Path(path)) == value for path, value in report['runtime_sha256'].items())
    if not report['sources_unchanged'] or not report['runtimes_unchanged']:
        report['status'] = 'failed'
    save()
print(report['status'], report.get('failure', ''), flush=True)
sys.exit(0 if report['status'] == 'passed' else 1)









