{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
{-# LANGUAGE NoImplicitPrelude #-}
{-# LANGUAGE UnicodeSyntax, TypeOperators #-}
module ChurchCorpusGenerated where
import Prelude (Int, fromInteger, undefined)
churchZero :: Int
churchZero = 0
type Bool       = ∀e. e -> e -> e
type Pair a b   = ∀e. (a -> b -> e) -> e
type List a     = ∀e. (a -> e -> e) -> e -> e
type Maybe a    = ∀e. e -> (a -> e) -> e
type Either a b = ∀e. (a -> e) -> (b -> e) -> e
type Tuple a = List a
type Dict k v = List (k `Pair` v)
type Equal a = a -> a -> Bool
type LE a = a -> a -> Bool
type Matrix a = List (List a)


-- ltInt: total
church_case_000 :: Int -> Int -> forall church0. church0 -> church0 -> church0
church_case_000 _ _ _ a = a
church_case_000_original :: Int -> Int -> Bool
church_case_000_original = church_case_000

-- gtInt: total
church_case_001 :: Int -> Int -> forall church0. church0 -> church0 -> church0
church_case_001 _ _ _ a = a
church_case_001_original :: Int -> Int -> Bool
church_case_001_original = church_case_001

-- leInt: total
church_case_002 :: Int -> Int -> forall church0. church0 -> church0 -> church0
church_case_002 _ _ _ a = a
church_case_002_original :: Int -> Int -> Bool
church_case_002_original = church_case_002

-- eqInt: total
church_case_003 :: Int -> Int -> forall church0. church0 -> church0 -> church0
church_case_003 _ _ _ a = a
church_case_003_original :: Int -> Int -> Bool
church_case_003_original = church_case_003

-- geInt: total
church_case_004 :: Int -> Int -> forall church0. church0 -> church0 -> church0
church_case_004 _ _ _ a = a
church_case_004_original :: Int -> Int -> Bool
church_case_004_original = church_case_004

-- eqFromLE: total
church_case_005 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> church0 -> church0 -> forall church2. church2 -> church2 -> church2
church_case_005 _ _ _ _ a = a
church_case_005_original :: forall a. LE a -> Equal a
church_case_005_original = church_case_005

-- ltFromLE: total
church_case_006 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> church0 -> church0 -> forall church2. church2 -> church2 -> church2
church_case_006 _ _ _ _ a = a
church_case_006_original :: forall a. LE a -> a -> a -> Bool
church_case_006_original = church_case_006

-- true: total
church_case_007 :: forall church0. church0 -> church0 -> church0
church_case_007 _ a = a
church_case_007_original :: Bool
church_case_007_original = church_case_007

-- false: total
church_case_008 :: forall church0. church0 -> church0 -> church0
church_case_008 _ a = a
church_case_008_original :: Bool
church_case_008_original = church_case_008

-- not: total
church_case_009 :: (forall church0. church0 -> church0 -> church0) -> forall church1. church1 -> church1 -> church1
church_case_009 _ _ a = a
church_case_009_original :: Bool -> Bool
church_case_009_original = church_case_009

-- and: total
church_case_010 :: (forall church0. church0 -> church0 -> church0) -> (forall church1. church1 -> church1 -> church1) -> forall church2. church2 -> church2 -> church2
church_case_010 _ _ _ a = a
church_case_010_original :: Bool -> Bool -> Bool
church_case_010_original = church_case_010

-- or: total
church_case_011 :: (forall church0. church0 -> church0 -> church0) -> (forall church1. church1 -> church1 -> church1) -> forall church2. church2 -> church2 -> church2
church_case_011 _ _ _ a = a
church_case_011_original :: Bool -> Bool -> Bool
church_case_011_original = church_case_011

-- xor: total
church_case_012 :: (forall church0. church0 -> church0 -> church0) -> (forall church1. church1 -> church1 -> church1) -> forall church2. church2 -> church2 -> church2
church_case_012 _ _ _ a = a
church_case_012_original :: Bool -> Bool -> Bool
church_case_012_original = church_case_012

-- pair: total
church_case_013 :: forall church0 church1. church0 -> church1 -> forall church2. (church0 -> church1 -> church2) -> church2
church_case_013 a b c = c a b
church_case_013_original :: forall a b. a -> b -> Pair a b
church_case_013_original = church_case_013

-- fst: total
church_case_014 :: forall church0 church1. (forall church2. (church0 -> church1 -> church2) -> church2) -> church0
church_case_014 a = a (\b _ -> b)
church_case_014_original :: forall a {w}. Pair a w -> a
church_case_014_original = church_case_014

-- snd: total
church_case_015 :: forall church0 church1. (forall church2. (church1 -> church0 -> church2) -> church2) -> church0
church_case_015 a = a (\_ b -> b)
church_case_015_original :: forall b {w}. Pair w b -> b
church_case_015_original = church_case_015

-- swap: total
church_case_016 :: forall church0 church1. (forall church2. (church0 -> church1 -> church2) -> church2) -> forall church3. (church1 -> church0 -> church3) -> church3
church_case_016 a b = a (\c d -> b d c)
church_case_016_original :: forall a b. Pair a b -> Pair b a
church_case_016_original = church_case_016

-- curry: total
church_case_017 :: forall church0 church1 church2. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church2) -> church0 -> church1 -> church2
church_case_017 a b c = a (\d -> d b c)
church_case_017_original :: forall a b c. (Pair a b -> c) -> a -> b -> c
church_case_017_original = church_case_017

-- uncurry: total
church_case_018 :: forall church0 church1 church2. (church0 -> church1 -> church2) -> (forall church3. (church0 -> church1 -> church3) -> church3) -> church2
church_case_018 a b = b a
church_case_018_original :: forall a b c. (a -> b -> c) -> Pair a b -> c
church_case_018_original = church_case_018

-- pairToList: total
church_case_019 :: forall church0 church1. (forall church2. (church0 -> church1 -> church2) -> church2) -> forall church4. ((forall church3. (church0 -> church3) -> (church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4
church_case_019 _ _ a = a
church_case_019_original :: forall a b. Pair a b -> List (Either a b)
church_case_019_original = church_case_019

-- bimapPair: total
church_case_020 :: forall church0 church1 church2 church3. (church0 -> church1) -> (church2 -> church3) -> (forall church4. (church0 -> church2 -> church4) -> church4) -> forall church5. (church1 -> church3 -> church5) -> church5
church_case_020 a b c d = c (\e f -> d (a e) (b f))
church_case_020_original :: forall a c b d. (a -> c) -> (b -> d) -> Pair a b -> Pair c d
church_case_020_original = church_case_020

-- nil: total
church_case_021 :: forall church0 church1. (church0 -> church1 -> church1) -> church1 -> church1
church_case_021 _ a = a
church_case_021_original :: forall a e. (a -> e -> e) -> e -> e
church_case_021_original = church_case_021

-- cons: total
church_case_022 :: forall church0. church0 -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_022 a _ b = b a
church_case_022_original :: forall a. a -> List a -> List a
church_case_022_original = church_case_022

-- snoc: total
church_case_023 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> church0 -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_023 _ a b = b a
church_case_023_original :: forall a. List a -> a -> List a
church_case_023_original = church_case_023

-- uncons: total
church_case_024 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church4. church4 -> ((forall church3. (church0 -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church3) -> church3) -> church4) -> church4
church_case_024 _ a _ = a
church_case_024_original :: forall a. List a -> Maybe (Pair a (List a))
church_case_024_original = church_case_024

-- unsnoc: total
church_case_025 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church4. church4 -> ((forall church3. ((forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church0 -> church3) -> church3) -> church4) -> church4
church_case_025 _ a _ = a
church_case_025_original :: forall a. List a -> Maybe (Pair (List a) a)
church_case_025_original = church_case_025

-- singleton: total
church_case_026 :: forall church0. church0 -> forall church1. (church0 -> church1 -> church1) -> church1 -> church1
church_case_026 a b = b a
church_case_026_original :: forall a. a -> List a
church_case_026_original = church_case_026

-- caseList: total
church_case_027 :: forall church0 church1. church0 -> (church1 -> (forall church2. (church1 -> church2 -> church2) -> church2 -> church2) -> church0) -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> church0
church_case_027 a _ _ = a
church_case_027_original :: forall b a. b -> (a -> List a -> b) -> List a -> b
church_case_027_original = church_case_027

-- head: requires_partiality
church_case_028 :: forall church0. church0 -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> church0
church_case_028 a _ = a
church_case_028_original :: forall a. a -> List a -> a
church_case_028_original = church_case_028

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_028_partial :: forall a. List a -> a
church_case_028_partial = church_case_028 undefined

-- null: total
church_case_029 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. church2 -> church2 -> church2
church_case_029 _ _ a = a
church_case_029_original :: forall a. List a -> Bool
church_case_029_original = church_case_029

-- tail: total
church_case_030 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_030 _ _ a = a
church_case_030_original :: forall a. List a -> List a
church_case_030_original = church_case_030

-- last: requires_partiality
church_case_031 :: forall church0. church0 -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> church0
church_case_031 a _ = a
church_case_031_original :: forall a. a -> List a -> a
church_case_031_original = church_case_031

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_031_partial :: forall a. List a -> a
church_case_031_partial = church_case_031 undefined

-- init: total
church_case_032 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_032 _ _ a = a
church_case_032_original :: forall a. List a -> List a
church_case_032_original = church_case_032

-- at: requires_partiality
church_case_033 :: forall church0. church0 -> Int -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> church0
church_case_033 a _ _ = a
church_case_033_original :: forall a. a -> Int -> List a -> a
church_case_033_original = church_case_033

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_033_partial :: forall a. Int -> List a -> a
church_case_033_partial = church_case_033 undefined

-- any: total
church_case_034 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. church3 -> church3 -> church3
church_case_034 _ _ _ a = a
church_case_034_original :: forall a. (a -> Bool) -> List a -> Bool
church_case_034_original = church_case_034

-- all: total
church_case_035 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. church3 -> church3 -> church3
church_case_035 _ _ _ a = a
church_case_035_original :: forall a. (a -> Bool) -> List a -> Bool
church_case_035_original = church_case_035

-- foldr: total
church_case_036 :: forall church0 church1. (church0 -> church1 -> church1) -> church1 -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church1
church_case_036 _ a _ = a
church_case_036_original :: forall a b. (a -> b -> b) -> b -> List a -> b
church_case_036_original = church_case_036

-- foldl: total
church_case_037 :: forall church0 church1. (church0 -> church1 -> church0) -> church0 -> (forall church2. (church1 -> church2 -> church2) -> church2 -> church2) -> church0
church_case_037 _ a _ = a
church_case_037_original :: forall b a. (b -> a -> b) -> b -> List a -> b
church_case_037_original = church_case_037

-- foldl1: requires_partiality
church_case_038 :: forall church0. church0 -> (church0 -> church0 -> church0) -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> church0
church_case_038 a _ _ = a
church_case_038_original :: forall a. a -> (a -> a -> a) -> List a -> a
church_case_038_original = church_case_038

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_038_partial :: forall a. (a -> a -> a) -> List a -> a
church_case_038_partial = church_case_038 undefined

-- foldr1: requires_partiality
church_case_039 :: forall church0. church0 -> (church0 -> church0 -> church0) -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> church0
church_case_039 a _ _ = a
church_case_039_original :: forall a. a -> (a -> a -> a) -> List a -> a
church_case_039_original = church_case_039

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_039_partial :: forall a. (a -> a -> a) -> List a -> a
church_case_039_partial = church_case_039 undefined

-- scanr: total
church_case_040 :: forall church0 church1. (church0 -> church1 -> church1) -> church1 -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church1 -> church3 -> church3) -> church3 -> church3
church_case_040 _ a _ b = b a
church_case_040_original :: forall a b. (a -> b -> b) -> b -> List a -> List b
church_case_040_original = church_case_040

-- mapAccumR: total
church_case_041 :: forall church0 church1 church2. (church0 -> church1 -> forall church3. (church0 -> church2 -> church3) -> church3) -> church0 -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church6. (church0 -> (forall church5. (church2 -> church5 -> church5) -> church5 -> church5) -> church6) -> church6
church_case_041 _ a _ b = b a (\_ c -> c)
church_case_041_original :: forall s a b. (s -> a -> Pair s b) -> s -> List a -> Pair s (List b)
church_case_041_original = church_case_041

-- scanl: total
church_case_042 :: forall church0 church1. (church0 -> church1 -> church0) -> church0 -> (forall church2. (church1 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_042 _ a _ b = b a
church_case_042_original :: forall b a. (b -> a -> b) -> b -> List a -> List b
church_case_042_original = church_case_042

-- mapAccumL: total
church_case_043 :: forall church0 church1 church2. (church0 -> church1 -> forall church3. (church0 -> church2 -> church3) -> church3) -> church0 -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church6. (church0 -> (forall church5. (church2 -> church5 -> church5) -> church5 -> church5) -> church6) -> church6
church_case_043 _ a _ b = b a (\_ c -> c)
church_case_043_original :: forall s a b. (s -> a -> Pair s b) -> s -> List a -> Pair s (List b)
church_case_043_original = church_case_043

-- zipWith: total
church_case_044 :: forall church0 church1 church2. (church0 -> church1 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. (church2 -> church5 -> church5) -> church5 -> church5
church_case_044 _ _ _ _ a = a
church_case_044_original :: forall a₁ a₂ b. (a₁ -> a₂ -> b) -> List a₁ -> List a₂ -> List b
church_case_044_original = church_case_044

-- zipWithN: total
church_case_045 :: forall church0 church1. ((forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church1) -> (forall church4. ((forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church5. (church1 -> church5 -> church5) -> church5 -> church5
church_case_045 _ _ _ a = a
church_case_045_original :: forall a b. (Tuple a -> b) -> Tuple (List a) -> List b
church_case_045_original = church_case_045

-- scanl2: total
church_case_046 :: forall church0 church1 church2. (church0 -> church1 -> church2 -> church0) -> church0 -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church2 -> church4 -> church4) -> church4 -> church4) -> forall church5. (church0 -> church5 -> church5) -> church5 -> church5
church_case_046 _ a _ _ b = b a
church_case_046_original :: forall b a₁ a₂. (b -> a₁ -> a₂ -> b) -> b -> List a₁ -> List a₂ -> List b
church_case_046_original = church_case_046

-- scanlN: total
church_case_047 :: forall church0 church1. (church0 -> (forall church2. (church1 -> church2 -> church2) -> church2 -> church2) -> church0) -> church0 -> (forall church4. ((forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church5. (church0 -> church5 -> church5) -> church5 -> church5
church_case_047 _ a _ b = b a
church_case_047_original :: forall b a. (b -> Tuple a -> b) -> b -> Tuple (List a) -> List b
church_case_047_original = church_case_047

-- mapAccumL2: total
church_case_048 :: forall church0 church1 church2 church3. (church0 -> church1 -> church2 -> forall church4. (church0 -> church3 -> church4) -> church4) -> church0 -> (forall church5. (church1 -> church5 -> church5) -> church5 -> church5) -> (forall church6. (church2 -> church6 -> church6) -> church6 -> church6) -> forall church8. (church0 -> (forall church7. (church3 -> church7 -> church7) -> church7 -> church7) -> church8) -> church8
church_case_048 _ a _ _ b = b a (\_ c -> c)
church_case_048_original :: forall s a₁ a₂ b. (s -> a₁ -> a₂ -> Pair s b) -> s -> List a₁ -> List a₂ -> Pair s (List b)
church_case_048_original = church_case_048

-- mapAccumLN: total
church_case_049 :: forall church0 church1 church2. (church0 -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church0 -> church2 -> church4) -> church4) -> church0 -> (forall church6. ((forall church5. (church1 -> church5 -> church5) -> church5 -> church5) -> church6 -> church6) -> church6 -> church6) -> forall church8. (church0 -> (forall church7. (church2 -> church7 -> church7) -> church7 -> church7) -> church8) -> church8
church_case_049 _ a _ b = b a (\_ c -> c)
church_case_049_original :: forall s a b. (s -> Tuple a -> Pair s b) -> s -> Tuple (List a) -> Pair s (List b)
church_case_049_original = church_case_049

-- zip: total
church_case_050 :: forall church0 church1. (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> forall church5. ((forall church4. (church0 -> church1 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5
church_case_050 _ _ _ a = a
church_case_050_original :: forall a b. List a -> List b -> List (Pair a b)
church_case_050_original = church_case_050

-- unzip: total
church_case_051 :: forall church0 church1. (forall church3. ((forall church2. (church0 -> church1 -> church2) -> church2) -> church3 -> church3) -> church3 -> church3) -> forall church6. ((forall church4. (church0 -> church4 -> church4) -> church4 -> church4) -> (forall church5. (church1 -> church5 -> church5) -> church5 -> church5) -> church6) -> church6
church_case_051 _ a = a (\_ b -> b) (\_ c -> c)
church_case_051_original :: forall a b. List (Pair a b) -> Pair (List a) (List b)
church_case_051_original = church_case_051

-- unfoldr: total
church_case_052 :: forall church0 church1. (church0 -> forall church3. church3 -> ((forall church2. (church1 -> church0 -> church2) -> church2) -> church3) -> church3) -> church0 -> forall church4. (church1 -> church4 -> church4) -> church4 -> church4
church_case_052 _ _ _ a = a
church_case_052_original :: forall b a. (b -> Maybe (Pair a b)) -> b -> List a
church_case_052_original = church_case_052

-- unfoldTree: total
church_case_053 :: forall church0 church1. (church0 -> forall church3. (church1 -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church3) -> church3) -> church0 -> forall church4. (church1 -> church4 -> church4) -> church4 -> church4
church_case_053 _ _ _ a = a
church_case_053_original :: forall b a. (b -> Pair a (List b)) -> b -> List a
church_case_053_original = church_case_053

-- append: total
church_case_054 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_054 _ _ _ a = a
church_case_054_original :: forall a. List a -> List a -> List a
church_case_054_original = church_case_054

-- appendEither: total
church_case_055 :: forall church0 church1. (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> forall church5. ((forall church4. (church0 -> church4) -> (church1 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5
church_case_055 _ _ _ a = a
church_case_055_original :: forall a b. List a -> List b -> List (Either a b)
church_case_055_original = church_case_055

-- map: total
church_case_056 :: forall church0 church1. (church0 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church1 -> church3 -> church3) -> church3 -> church3
church_case_056 _ _ _ a = a
church_case_056_original :: forall a b. (a -> b) -> List a -> List b
church_case_056_original = church_case_056

-- concat: total
church_case_057 :: forall church0. (forall church2. ((forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_057 _ _ a = a
church_case_057_original :: forall a. List (List a) -> List a
church_case_057_original = church_case_057

-- concatMap: total
church_case_058 :: forall church0 church1. (church0 -> forall church2. (church1 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church1 -> church4 -> church4) -> church4 -> church4
church_case_058 _ _ _ a = a
church_case_058_original :: forall a b. (a -> List b) -> List a -> List b
church_case_058_original = church_case_058

-- filter: total
church_case_059 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_059 _ _ _ a = a
church_case_059_original :: forall a. (a -> Bool) -> List a -> List a
church_case_059_original = church_case_059

-- length: needs_int_provider
church_case_060 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> Int
church_case_060 _ = churchZero
church_case_060_original :: forall a. List a -> Int
church_case_060_original = church_case_060

-- reverse: total
church_case_061 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_061 _ _ a = a
church_case_061_original :: forall a. List a -> List a
church_case_061_original = church_case_061

-- take: total
church_case_062 :: forall church0. Int -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_062 _ _ _ a = a
church_case_062_original :: forall a. Int -> List a -> List a
church_case_062_original = church_case_062

-- drop: total
church_case_063 :: forall church0. Int -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_063 _ _ _ a = a
church_case_063_original :: forall a. Int -> List a -> List a
church_case_063_original = church_case_063

-- splitAt: total
church_case_064 :: forall church0. Int -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church4. ((forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> church4) -> church4
church_case_064 _ _ a = a (\_ b -> b) (\_ c -> c)
church_case_064_original :: forall a. Int -> List a -> Pair (List a) (List a)
church_case_064_original = church_case_064

-- takeLast: total
church_case_065 :: forall church0. Int -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_065 _ _ _ a = a
church_case_065_original :: forall a. Int -> List a -> List a
church_case_065_original = church_case_065

-- dropLast: total
church_case_066 :: forall church0. Int -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_066 _ _ _ a = a
church_case_066_original :: forall a. Int -> List a -> List a
church_case_066_original = church_case_066

-- takeWhile: total
church_case_067 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_067 _ _ _ a = a
church_case_067_original :: forall a. (a -> Bool) -> List a -> List a
church_case_067_original = church_case_067

-- dropWhile: total
church_case_068 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_068 _ _ _ a = a
church_case_068_original :: forall a. (a -> Bool) -> List a -> List a
church_case_068_original = church_case_068

-- partition: total
church_case_069 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church5. ((forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church0 -> church4 -> church4) -> church4 -> church4) -> church5) -> church5
church_case_069 _ _ a = a (\_ b -> b) (\_ c -> c)
church_case_069_original :: forall a. (a -> Bool) -> List a -> Pair (List a) (List a)
church_case_069_original = church_case_069

-- partitionEvery: total
church_case_070 :: forall church0. Int -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church3. ((forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church3 -> church3) -> church3 -> church3
church_case_070 _ _ _ a = a
church_case_070_original :: forall a. Int -> List a -> List (List a)
church_case_070_original = church_case_070

-- partitionStep: total
church_case_071 :: forall church0. Int -> Int -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church3. ((forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church3 -> church3) -> church3 -> church3
church_case_071 _ _ _ _ a = a
church_case_071_original :: forall a. Int -> Int -> List a -> List (List a)
church_case_071_original = church_case_071

-- windows: total
church_case_072 :: forall church0. Int -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church3. ((forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church3 -> church3) -> church3 -> church3
church_case_072 _ _ _ a = a
church_case_072_original :: forall a. Int -> List a -> List (List a)
church_case_072_original = church_case_072

-- inits: total
church_case_073 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church3. ((forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church3 -> church3) -> church3 -> church3
church_case_073 _ _ a = a
church_case_073_original :: forall a. List a -> List (List a)
church_case_073_original = church_case_073

-- tails: total
church_case_074 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church3. ((forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church3 -> church3) -> church3 -> church3
church_case_074 _ _ a = a
church_case_074_original :: forall a. List a -> List (List a)
church_case_074_original = church_case_074

-- span: total
church_case_075 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church5. ((forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church0 -> church4 -> church4) -> church4 -> church4) -> church5) -> church5
church_case_075 _ _ a = a (\_ b -> b) (\_ c -> c)
church_case_075_original :: forall a. (a -> Bool) -> List a -> Pair (List a) (List a)
church_case_075_original = church_case_075

-- replicate: total
church_case_076 :: forall church0. Int -> church0 -> forall church1. (church0 -> church1 -> church1) -> church1 -> church1
church_case_076 _ a b = b a
church_case_076_original :: forall a. Int -> a -> List a
church_case_076_original = church_case_076

-- lexicographicLE: total
church_case_077 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. church3 -> church3 -> church3
church_case_077 _ _ _ _ a = a
church_case_077_original :: forall a. LE a -> LE (List a)
church_case_077_original = church_case_077

-- compose: total
church_case_078 :: forall church0. (forall church1. ((church0 -> church0) -> church1 -> church1) -> church1 -> church1) -> church0 -> church0
church_case_078 _ a = a
church_case_078_original :: forall a. List (a -> a) -> a -> a
church_case_078_original = church_case_078

-- composeFlatten: total
church_case_079 :: forall church0. (forall church2. ((church0 -> forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> church2 -> church2) -> church2 -> church2) -> church0 -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_079 _ a b = b a
church_case_079_original :: forall a. List (a -> List a) -> a -> List a
church_case_079_original = church_case_079

-- cartesianWith: total
church_case_080 :: forall church0 church1 church2. (church0 -> church1 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. (church2 -> church5 -> church5) -> church5 -> church5
church_case_080 _ _ _ _ a = a
church_case_080_original :: forall a b c. (a -> b -> c) -> List a -> List b -> List c
church_case_080_original = church_case_080

-- cartesian: total
church_case_081 :: forall church0 church1. (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> forall church5. ((forall church4. (church0 -> church1 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5
church_case_081 _ _ _ a = a
church_case_081_original :: forall a b. List a -> List b -> List (Pair a b)
church_case_081_original = church_case_081

-- cartesianN: total
church_case_082 :: forall church0. (forall church2. ((forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> church2 -> church2) -> church2 -> church2) -> forall church4. ((forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> church4 -> church4) -> church4 -> church4
church_case_082 _ _ a = a
church_case_082_original :: forall a. Tuple (List a) -> List (Tuple a)
church_case_082_original = church_case_082

-- intersperse: total
church_case_083 :: forall church0. church0 -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_083 a _ b = b a
church_case_083_original :: forall a. a -> List a -> List a
church_case_083_original = church_case_083

-- riffle: total
church_case_084 :: forall church0. church0 -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_084 a _ b = b a
church_case_084_original :: forall a. a -> List a -> List a
church_case_084_original = church_case_084

-- rotateLeftN: total
church_case_085 :: forall church0. Int -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_085 _ _ _ a = a
church_case_085_original :: forall a. Int -> List a -> List a
church_case_085_original = church_case_085

-- rotateRightN: total
church_case_086 :: forall church0. Int -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_086 _ _ _ a = a
church_case_086_original :: forall a. Int -> List a -> List a
church_case_086_original = church_case_086

-- rotateLeft: total
church_case_087 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_087 _ _ a = a
church_case_087_original :: forall a. List a -> List a
church_case_087_original = church_case_087

-- rotateRight: total
church_case_088 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_088 _ _ a = a
church_case_088_original :: forall a. List a -> List a
church_case_088_original = church_case_088

-- transpose: total
church_case_089 :: forall church0. (forall church2. ((forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> church2 -> church2) -> church2 -> church2) -> forall church4. ((forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> church4 -> church4) -> church4 -> church4
church_case_089 _ _ a = a
church_case_089_original :: forall a. Matrix a -> Matrix a
church_case_089_original = church_case_089

-- just: total
church_case_090 :: forall church0. church0 -> forall church1. church1 -> (church0 -> church1) -> church1
church_case_090 a _ b = b a
church_case_090_original :: forall a. a -> Maybe a
church_case_090_original = church_case_090

-- nothing: total
church_case_091 :: forall church0 church1. church1 -> (church0 -> church1) -> church1
church_case_091 a _ = a
church_case_091_original :: forall a e. e -> (a -> e) -> e
church_case_091_original = church_case_091

-- isNothing: total
church_case_092 :: forall church0. (forall church1. church1 -> (church0 -> church1) -> church1) -> forall church2. church2 -> church2 -> church2
church_case_092 _ _ a = a
church_case_092_original :: forall a. Maybe a -> Bool
church_case_092_original = church_case_092

-- fromJust: requires_partiality
church_case_093 :: forall church0. church0 -> (forall church1. church1 -> (church0 -> church1) -> church1) -> church0
church_case_093 a _ = a
church_case_093_original :: forall a. a -> Maybe a -> a
church_case_093_original = church_case_093

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_093_partial :: forall a. Maybe a -> a
church_case_093_partial = church_case_093 undefined

-- fromMaybe: total
church_case_094 :: forall church0. church0 -> (forall church1. church1 -> (church0 -> church1) -> church1) -> church0
church_case_094 a _ = a
church_case_094_original :: forall a. a -> Maybe a -> a
church_case_094_original = church_case_094

-- maybeToList: total
church_case_095 :: forall church0. (forall church1. church1 -> (church0 -> church1) -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_095 _ _ a = a
church_case_095_original :: forall a. Maybe a -> List a
church_case_095_original = church_case_095

-- listToMaybe: total
church_case_096 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. church2 -> (church0 -> church2) -> church2
church_case_096 _ a _ = a
church_case_096_original :: forall a. List a -> Maybe a
church_case_096_original = church_case_096

-- catMaybes: total
church_case_097 :: forall church0. (forall church2. ((forall church1. church1 -> (church0 -> church1) -> church1) -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_097 _ _ a = a
church_case_097_original :: forall a. List (Maybe a) -> List a
church_case_097_original = church_case_097

-- mapMaybe: total
church_case_098 :: forall church0 church1. (church0 -> forall church2. church2 -> (church1 -> church2) -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church1 -> church4 -> church4) -> church4 -> church4
church_case_098 _ _ _ a = a
church_case_098_original :: forall a b. (a -> Maybe b) -> List a -> List b
church_case_098_original = church_case_098

-- squashMaybe: total
church_case_099 :: forall church0. (forall church2. church2 -> ((forall church1. church1 -> (church0 -> church1) -> church1) -> church2) -> church2) -> forall church3. church3 -> (church0 -> church3) -> church3
church_case_099 _ a _ = a
church_case_099_original :: forall a. Maybe (Maybe a) -> Maybe a
church_case_099_original = church_case_099

-- sequence: total
church_case_100 :: forall church0. (forall church2. ((forall church1. church1 -> (church0 -> church1) -> church1) -> church2 -> church2) -> church2 -> church2) -> forall church4. church4 -> ((forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> church4) -> church4
church_case_100 _ a _ = a
church_case_100_original :: forall a. List (Maybe a) -> Maybe (List a)
church_case_100_original = church_case_100

-- left: total
church_case_101 :: forall church0 church1. church0 -> forall church2. (church0 -> church2) -> (church1 -> church2) -> church2
church_case_101 a b _ = b a
church_case_101_original :: forall a {w}. a -> Either a w
church_case_101_original = church_case_101

-- right: total
church_case_102 :: forall church0 church1. church0 -> forall church2. (church1 -> church2) -> (church0 -> church2) -> church2
church_case_102 a _ b = b a
church_case_102_original :: forall b {w}. b -> Either w b
church_case_102_original = church_case_102

-- isLeft: total
church_case_103 :: forall church0 church1. (forall church2. (church0 -> church2) -> (church1 -> church2) -> church2) -> forall church3. church3 -> church3 -> church3
church_case_103 _ _ a = a
church_case_103_original :: forall {w1} {w2}. Either w1 w2 -> Bool
church_case_103_original = church_case_103

-- isRight: total
church_case_104 :: forall church0 church1. (forall church2. (church0 -> church2) -> (church1 -> church2) -> church2) -> forall church3. church3 -> church3 -> church3
church_case_104 _ _ a = a
church_case_104_original :: forall {w1} {w2}. Either w1 w2 -> Bool
church_case_104_original = church_case_104

-- fromLeft: requires_partiality
church_case_105 :: forall church0 church1. church0 -> (forall church2. (church0 -> church2) -> (church1 -> church2) -> church2) -> church0
church_case_105 a _ = a
church_case_105_original :: forall a w. a -> Either a w -> a
church_case_105_original = church_case_105

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_105_partial :: forall a {w}. Either a w -> a
church_case_105_partial = church_case_105 undefined

-- fromRight: requires_partiality
church_case_106 :: forall church0 church1. church0 -> (forall church2. (church1 -> church2) -> (church0 -> church2) -> church2) -> church0
church_case_106 a _ = a
church_case_106_original :: forall b w. b -> Either w b -> b
church_case_106_original = church_case_106

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_106_partial :: forall b {w}. Either w b -> b
church_case_106_partial = church_case_106 undefined

-- maybeEither: total
church_case_107 :: forall church0 church1. (forall church4. ((forall church2. church2 -> (church0 -> church2) -> church2) -> church4) -> ((forall church3. church3 -> (church1 -> church3) -> church3) -> church4) -> church4) -> forall church6. church6 -> ((forall church5. (church0 -> church5) -> (church1 -> church5) -> church5) -> church6) -> church6
church_case_107 _ a _ = a
church_case_107_original :: forall a b. Either (Maybe a) (Maybe b) -> Maybe (Either a b)
church_case_107_original = church_case_107

-- eitherMaybe: total
church_case_108 :: forall church0 church1. (forall church3. church3 -> ((forall church2. (church0 -> church2) -> (church1 -> church2) -> church2) -> church3) -> church3) -> forall church6. ((forall church4. church4 -> (church0 -> church4) -> church4) -> church6) -> ((forall church5. church5 -> (church1 -> church5) -> church5) -> church6) -> church6
church_case_108 _ a _ = a (\b _ -> b)
church_case_108_original :: forall a b. Maybe (Either a b) -> Either (Maybe a) (Maybe b)
church_case_108_original = church_case_108

-- either: total
church_case_109 :: forall church0 church1 church2. (church0 -> church1) -> (church2 -> church1) -> (forall church3. (church0 -> church3) -> (church2 -> church3) -> church3) -> church1
church_case_109 a b c = c a b
church_case_109_original :: forall a c b. (a -> c) -> (b -> c) -> Either a b -> c
church_case_109_original = church_case_109

-- lefts: total
church_case_110 :: forall church0 church1. (forall church3. ((forall church2. (church0 -> church2) -> (church1 -> church2) -> church2) -> church3 -> church3) -> church3 -> church3) -> forall church4. (church0 -> church4 -> church4) -> church4 -> church4
church_case_110 _ _ a = a
church_case_110_original :: forall a b. List (Either a b) -> List a
church_case_110_original = church_case_110

-- rights: total
church_case_111 :: forall church0 church1. (forall church3. ((forall church2. (church0 -> church2) -> (church1 -> church2) -> church2) -> church3 -> church3) -> church3 -> church3) -> forall church4. (church1 -> church4 -> church4) -> church4 -> church4
church_case_111 _ _ a = a
church_case_111_original :: forall a b. List (Either a b) -> List b
church_case_111_original = church_case_111

-- partitionEithers: total
church_case_112 :: forall church0 church1. (forall church3. ((forall church2. (church0 -> church2) -> (church1 -> church2) -> church2) -> church3 -> church3) -> church3 -> church3) -> forall church6. ((forall church4. (church0 -> church4 -> church4) -> church4 -> church4) -> (forall church5. (church1 -> church5 -> church5) -> church5 -> church5) -> church6) -> church6
church_case_112 _ a = a (\_ b -> b) (\_ c -> c)
church_case_112_original :: forall a b. List (Either a b) -> Pair (List a) (List b)
church_case_112_original = church_case_112

-- lookup: total
church_case_113 :: forall church0 church1 church2. (church0 -> church1 -> forall church3. church3 -> church3 -> church3) -> church1 -> (forall church5. ((forall church4. (church0 -> church2 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church6. church6 -> (church2 -> church6) -> church6
church_case_113 _ _ _ a _ = a
church_case_113_original :: forall a c b. (a -> c -> Bool) -> c -> Dict a b -> Maybe b
church_case_113_original = church_case_113

-- lookupDefault: total
church_case_114 :: forall church0 church1 church2. (church0 -> church1 -> forall church3. church3 -> church3 -> church3) -> church2 -> church1 -> (forall church5. ((forall church4. (church0 -> church2 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> church2
church_case_114 _ a _ _ = a
church_case_114_original :: forall a c b. (a -> c -> Bool) -> b -> c -> Dict a b -> b
church_case_114_original = church_case_114

-- keyExists: total
church_case_115 :: forall church0 church1 church2. (church0 -> church1 -> forall church3. church3 -> church3 -> church3) -> church1 -> (forall church5. ((forall church4. (church0 -> church2 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church6. church6 -> church6 -> church6
church_case_115 _ _ _ _ a = a
church_case_115_original :: forall a c b. (a -> c -> Bool) -> c -> Dict a b -> Bool
church_case_115_original = church_case_115

-- keyMember: total
church_case_116 :: forall church0 church1 church2. (church0 -> church1 -> forall church3. church3 -> church3 -> church3) -> church1 -> (forall church5. ((forall church4. (church0 -> church2 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church6. church6 -> church6 -> church6
church_case_116 _ _ _ _ a = a
church_case_116_original :: forall a c b. (a -> c -> Bool) -> c -> Dict a b -> Bool
church_case_116_original = church_case_116

-- keyFree: total
church_case_117 :: forall church0 church1 church2. (church0 -> church1 -> forall church3. church3 -> church3 -> church3) -> church1 -> (forall church5. ((forall church4. (church0 -> church2 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church6. church6 -> church6 -> church6
church_case_117 _ _ _ _ a = a
church_case_117_original :: forall a c b. (a -> c -> Bool) -> c -> Dict a b -> Bool
church_case_117_original = church_case_117

-- keyValueMap: total
church_case_118 :: forall church0 church1 church2. (church0 -> church1 -> church2) -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church5. (church2 -> church5 -> church5) -> church5 -> church5
church_case_118 _ _ _ a = a
church_case_118_original :: forall k v a. (k -> v -> a) -> Dict k v -> List a
church_case_118_original = church_case_118

-- mapKeys: total
church_case_119 :: forall church0 church1 church2. (church0 -> church1) -> (forall church4. ((forall church3. (church0 -> church2 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church1 -> church2 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_119 _ _ _ a = a
church_case_119_original :: forall k₁ k₂ v. (k₁ -> k₂) -> Dict k₁ v -> Dict k₂ v
church_case_119_original = church_case_119

-- dictFromLists: total
church_case_120 :: forall church0 church1. (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> forall church5. ((forall church4. (church0 -> church1 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5
church_case_120 _ _ _ a = a
church_case_120_original :: forall k v. List k -> List v -> Dict k v
church_case_120_original = church_case_120

-- associationMap: total
church_case_121 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (church0 -> church1) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church5. ((forall church4. (church0 -> church1 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5
church_case_121 _ _ _ _ a = a
church_case_121_original :: forall k v. Equal k -> (k -> v) -> List k -> Dict k v
church_case_121_original = church_case_121

-- insertOrUpdate: total
church_case_122 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> church0 -> church1 -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_122 _ _ _ _ _ a = a
church_case_122_original :: forall a b. Equal a -> a -> b -> Dict a b -> Dict a b
church_case_122_original = church_case_122

-- invert: total
church_case_123 :: forall church0 church1. (church1 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church7. ((forall church6. (church1 -> (forall church5. (church0 -> church5 -> church5) -> church5 -> church5) -> church6) -> church6) -> church7 -> church7) -> church7 -> church7
church_case_123 _ _ _ a = a
church_case_123_original :: forall a b. Equal b -> Dict a b -> Dict b (List a)
church_case_123_original = church_case_123

-- merge: total
church_case_124 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (forall church5. ((forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church8. ((forall church7. (church0 -> (forall church6. (church1 -> church6 -> church6) -> church6 -> church6) -> church7) -> church7) -> church8 -> church8) -> church8 -> church8
church_case_124 _ _ _ a = a
church_case_124_original :: forall k v. Equal k -> List (Dict k v) -> Dict k (List v)
church_case_124_original = church_case_124

-- mergeWith: total
church_case_125 :: forall church0 church1 church2. (church0 -> church0 -> forall church3. church3 -> church3 -> church3) -> ((forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> church2) -> (forall church7. ((forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6) -> church7 -> church7) -> church7 -> church7) -> forall church9. ((forall church8. (church0 -> church2 -> church8) -> church8) -> church9 -> church9) -> church9 -> church9
church_case_125 _ _ _ _ a = a
church_case_125_original :: forall k v r. Equal k -> (List v -> r) -> List (Dict k v) -> Dict k r
church_case_125_original = church_case_125

-- collapse: total
church_case_126 :: forall church0 church1 church2. (church0 -> church0 -> forall church3. church3 -> church3 -> church3) -> (church1 -> church1 -> forall church4. church4 -> church4 -> church4) -> (forall church8. ((forall church7. (church0 -> (forall church6. ((forall church5. (church1 -> church2 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6) -> church7) -> church7) -> church8 -> church8) -> church8 -> church8) -> forall church11. ((forall church10. ((forall church9. (church0 -> church1 -> church9) -> church9) -> church2 -> church10) -> church10) -> church11 -> church11) -> church11 -> church11
church_case_126 _ _ _ _ a = a
church_case_126_original :: forall k₁ k₂ v. Equal k₁ -> Equal k₂ -> Dict k₁ (Dict k₂ v) -> Dict (Pair k₁ k₂) v
church_case_126_original = church_case_126

-- eitherDict: total
church_case_127 :: forall church0 church1 church2. (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> (forall church6. ((forall church5. (church2 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6) -> forall church9. ((forall church8. ((forall church7. (church0 -> church7) -> (church2 -> church7) -> church7) -> church1 -> church8) -> church8) -> church9 -> church9) -> church9 -> church9
church_case_127 _ _ _ a = a
church_case_127_original :: forall k₁ v k₂. Dict k₁ v -> Dict k₂ v -> Dict (Either k₁ k₂) v
church_case_127_original = church_case_127

-- chain: total
church_case_128 :: forall church0 church1 church2. (church0 -> church0 -> forall church3. church3 -> church3 -> church3) -> (church1 -> church1 -> forall church4. church4 -> church4 -> church4) -> (forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6) -> (forall church8. ((forall church7. (church1 -> church2 -> church7) -> church7) -> church8 -> church8) -> church8 -> church8) -> forall church10. ((forall church9. (church0 -> church2 -> church9) -> church9) -> church10 -> church10) -> church10 -> church10
church_case_128 _ _ _ _ _ a = a
church_case_128_original :: forall k₁ k₂ v. Equal k₁ -> Equal k₂ -> Dict k₁ k₂ -> Dict k₂ v -> Dict k₁ v
church_case_128_original = church_case_128

-- chainN: total
church_case_129 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church3. ((forall church2. (church0 -> church0 -> church2) -> church2) -> church3 -> church3) -> church3 -> church3) -> (forall church6. ((forall church5. ((forall church4. (church0 -> church0 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> church6 -> church6) -> church6 -> church6) -> forall church8. ((forall church7. (church0 -> church0 -> church7) -> church7) -> church8 -> church8) -> church8 -> church8
church_case_129 _ _ _ _ a = a
church_case_129_original :: forall a. Equal a -> Dict a a -> List (Dict a a) -> Dict a a
church_case_129_original = church_case_129

-- mapValues: total
church_case_130 :: forall church0 church1 church2. (church0 -> church1) -> (forall church4. ((forall church3. (church2 -> church0 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church2 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_130 _ _ _ a = a
church_case_130_original :: forall v₁ v₂ k. (v₁ -> v₂) -> Dict k v₁ -> Dict k v₂
church_case_130_original = church_case_130

-- mapMaybeValues: total
church_case_131 :: forall church0 church1 church2. (church0 -> forall church3. church3 -> (church1 -> church3) -> church3) -> (forall church5. ((forall church4. (church2 -> church0 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church7. ((forall church6. (church2 -> church1 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7
church_case_131 _ _ _ a = a
church_case_131_original :: forall v₁ v₂ k. (v₁ -> Maybe v₂) -> Dict k v₁ -> Dict k v₂
church_case_131_original = church_case_131

-- cartesianDict: total
church_case_132 :: forall church0 church1 church2 church3. (forall church5. ((forall church4. (church0 -> church2 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> (forall church7. ((forall church6. (church1 -> church3 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7) -> forall church11. ((forall church10. ((forall church8. (church0 -> church1 -> church8) -> church8) -> (forall church9. (church2 -> church3 -> church9) -> church9) -> church10) -> church10) -> church11 -> church11) -> church11 -> church11
church_case_132 _ _ _ a = a
church_case_132_original :: forall k₁ k₂ v₁ v₂. Dict k₁ v₁ -> Dict k₂ v₂ -> Dict (Pair k₁ k₂) (Pair v₁ v₂)
church_case_132_original = church_case_132

-- deleteKey: total
church_case_133 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> church0 -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_133 _ _ _ _ a = a
church_case_133_original :: forall k v. Equal k -> k -> Dict k v -> Dict k v
church_case_133_original = church_case_133

-- keyTake: total
church_case_134 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church5. ((forall church4. (church0 -> church1 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church7. ((forall church6. (church0 -> church1 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7
church_case_134 _ _ _ _ a = a
church_case_134_original :: forall k v. Equal k -> List k -> Dict k v -> Dict k v
church_case_134_original = church_case_134

-- keyTakeOrdered: total
church_case_135 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church5. ((forall church4. (church0 -> church1 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church7. ((forall church6. (church0 -> church1 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7
church_case_135 _ _ _ _ a = a
church_case_135_original :: forall k v. Equal k -> List k -> Dict k v -> Dict k v
church_case_135_original = church_case_135

-- keyDrop: total
church_case_136 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church5. ((forall church4. (church0 -> church1 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church7. ((forall church6. (church0 -> church1 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7
church_case_136 _ _ _ _ a = a
church_case_136_original :: forall k v. Equal k -> List k -> Dict k v -> Dict k v
church_case_136_original = church_case_136

-- keySelect: total
church_case_137 :: forall church0 church1. (church0 -> forall church2. church2 -> church2 -> church2) -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_137 _ _ _ a = a
church_case_137_original :: forall k v. (k -> Bool) -> Dict k v -> Dict k v
church_case_137_original = church_case_137

-- upsertWith: total
church_case_138 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> church0 -> church1 -> (church1 -> church1) -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_138 _ _ _ _ _ _ a = a
church_case_138_original :: forall k v. Equal k -> k -> v -> (v -> v) -> Dict k v -> Dict k v
church_case_138_original = church_case_138

-- keySortBy: total
church_case_139 :: forall church0 church1 church2. (church0 -> church0 -> forall church3. church3 -> church3 -> church3) -> (church1 -> church0) -> (forall church5. ((forall church4. (church1 -> church2 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church7. ((forall church6. (church1 -> church2 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7
church_case_139 _ _ _ _ a = a
church_case_139_original :: forall a k v. LE a -> (k -> a) -> Dict k v -> Dict k v
church_case_139_original = church_case_139

-- keySort: total
church_case_140 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_140 _ _ _ a = a
church_case_140_original :: forall k v. LE k -> Dict k v -> Dict k v
church_case_140_original = church_case_140

-- unionKeys: total
church_case_141 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (forall church5. ((forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church6. (church0 -> church6 -> church6) -> church6 -> church6
church_case_141 _ _ _ a = a
church_case_141_original :: forall k v. Equal k -> List (Dict k v) -> List k
church_case_141_original = church_case_141

-- intersectionKeys: total
church_case_142 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (forall church5. ((forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church6. (church0 -> church6 -> church6) -> church6 -> church6
church_case_142 _ _ _ a = a
church_case_142_original :: forall k v. Equal k -> List (Dict k v) -> List k
church_case_142_original = church_case_142

-- keyComplement: total
church_case_143 :: forall church0 church1 church2. (church0 -> church0 -> forall church3. church3 -> church3 -> church3) -> (forall church5. ((forall church4. (church0 -> church1 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> (forall church8. ((forall church7. ((forall church6. (church0 -> church2 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7) -> church8 -> church8) -> church8 -> church8) -> forall church10. ((forall church9. (church0 -> church1 -> church9) -> church9) -> church10 -> church10) -> church10 -> church10
church_case_143 _ _ _ _ a = a
church_case_143_original :: forall k v w. Equal k -> Dict k v -> List (Dict k w) -> Dict k v
church_case_143_original = church_case_143

-- keyIntersection: total
church_case_144 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (forall church5. ((forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church8. ((forall church7. ((forall church6. (church0 -> church1 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7) -> church8 -> church8) -> church8 -> church8
church_case_144 _ _ _ a = a
church_case_144_original :: forall k v. Equal k -> List (Dict k v) -> List (Dict k v)
church_case_144_original = church_case_144

-- keyUnion: total
church_case_145 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (church0 -> church1) -> (forall church5. ((forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church8. ((forall church7. ((forall church6. (church0 -> church1 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7) -> church8 -> church8) -> church8 -> church8
church_case_145 _ _ _ _ a = a
church_case_145_original :: forall k v. Equal k -> (k -> v) -> List (Dict k v) -> List (Dict k v)
church_case_145_original = church_case_145

-- turn: total
church_case_146 :: forall church0. (forall church2. ((forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> church2 -> church2) -> church2 -> church2) -> forall church4. ((forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> church4 -> church4) -> church4 -> church4
church_case_146 _ _ a = a
church_case_146_original :: forall a. Matrix a -> Matrix a
church_case_146_original = church_case_146

-- unturn: total
church_case_147 :: forall church0. (forall church2. ((forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> church2 -> church2) -> church2 -> church2) -> forall church4. ((forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> church4 -> church4) -> church4 -> church4
church_case_147 _ _ a = a
church_case_147_original :: forall a. Matrix a -> Matrix a
church_case_147_original = church_case_147

-- subsequences: total
church_case_148 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church3. ((forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church3 -> church3) -> church3 -> church3
church_case_148 _ _ a = a
church_case_148_original :: forall a. List a -> List (List a)
church_case_148_original = church_case_148

-- permutations: total
church_case_149 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church3. ((forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church3 -> church3) -> church3 -> church3
church_case_149 _ _ a = a
church_case_149_original :: forall a. List a -> List (List a)
church_case_149_original = church_case_149

-- on: total
church_case_150 :: forall church0 church1 church2. (church0 -> church0 -> church1) -> (church2 -> church0) -> church2 -> church2 -> church1
church_case_150 a b c _ = a (b c) (b c)
church_case_150_original :: forall b c a. (b -> b -> c) -> (a -> b) -> a -> a -> c
church_case_150_original = church_case_150

-- nubBy: total
church_case_151 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_151 _ _ _ a = a
church_case_151_original :: forall a. (a -> a -> Bool) -> List a -> List a
church_case_151_original = church_case_151

-- nubOn: total
church_case_152 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (church1 -> church0) -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church1 -> church4 -> church4) -> church4 -> church4
church_case_152 _ _ _ _ a = a
church_case_152_original :: forall b a. Equal b -> (a -> b) -> List a -> List a
church_case_152_original = church_case_152

-- deleteBy: total
church_case_153 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> church0 -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_153 _ a _ b = b a
church_case_153_original :: forall a. (a -> a -> Bool) -> a -> List a -> List a
church_case_153_original = church_case_153

-- deleteFirstsBy: total
church_case_154 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church0 -> church4 -> church4) -> church4 -> church4
church_case_154 _ _ _ _ a = a
church_case_154_original :: forall a. (a -> a -> Bool) -> List a -> List a -> List a
church_case_154_original = church_case_154

-- unionBy: total
church_case_155 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church0 -> church4 -> church4) -> church4 -> church4
church_case_155 _ _ _ _ a = a
church_case_155_original :: forall a. (a -> a -> Bool) -> List a -> List a -> List a
church_case_155_original = church_case_155

-- intersectBy: total
church_case_156 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church0 -> church4 -> church4) -> church4 -> church4
church_case_156 _ _ _ _ a = a
church_case_156_original :: forall a. (a -> a -> Bool) -> List a -> List a -> List a
church_case_156_original = church_case_156

-- groupBy: total
church_case_157 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church4. ((forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> church4 -> church4) -> church4 -> church4
church_case_157 _ _ _ a = a
church_case_157_original :: forall a. (a -> a -> Bool) -> List a -> List (List a)
church_case_157_original = church_case_157

-- groupOn: total
church_case_158 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (church1 -> church0) -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> forall church5. ((forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> church5 -> church5) -> church5 -> church5
church_case_158 _ _ _ _ a = a
church_case_158_original :: forall b a. Equal b -> (a -> b) -> List a -> List (List a)
church_case_158_original = church_case_158

-- gatherBy: total
church_case_159 :: forall church0 church1. (church1 -> church1 -> forall church2. church2 -> church2 -> church2) -> (church0 -> church1) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church5. ((forall church4. (church0 -> church4 -> church4) -> church4 -> church4) -> church5 -> church5) -> church5 -> church5
church_case_159 _ _ _ _ a = a
church_case_159_original :: forall a k. Equal k -> (a -> k) -> List a -> List (List a)
church_case_159_original = church_case_159

-- gather: total
church_case_160 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church4. ((forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> church4 -> church4) -> church4 -> church4
church_case_160 _ _ _ a = a
church_case_160_original :: forall a. Equal a -> List a -> List (List a)
church_case_160_original = church_case_160

-- countsBy: total
church_case_161 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church4. ((forall church3. (church0 -> Int -> church3) -> church3) -> church4 -> church4) -> church4 -> church4
church_case_161 _ _ _ a = a
church_case_161_original :: forall a. Equal a -> List a -> Dict a Int
church_case_161_original = church_case_161

-- countsByKey: total
church_case_162 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (church1 -> church0) -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> forall church5. ((forall church4. (church0 -> Int -> church4) -> church4) -> church5 -> church5) -> church5 -> church5
church_case_162 _ _ _ _ a = a
church_case_162_original :: forall k a. Equal k -> (a -> k) -> List a -> Dict k Int
church_case_162_original = church_case_162

-- tallyBy: total
church_case_163 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church4. ((forall church3. (church0 -> Int -> church3) -> church3) -> church4 -> church4) -> church4 -> church4
church_case_163 _ _ _ a = a
church_case_163_original :: forall a. Equal a -> List a -> Dict a Int
church_case_163_original = church_case_163

-- countDistinctBy: needs_int_provider
church_case_164 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> Int
church_case_164 _ _ = churchZero
church_case_164_original :: forall a. Equal a -> List a -> Int
church_case_164_original = church_case_164

-- positionIndexBy: total
church_case_165 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church5. ((forall church4. (church0 -> (forall church3. (Int -> church3 -> church3) -> church3 -> church3) -> church4) -> church4) -> church5 -> church5) -> church5 -> church5
church_case_165 _ _ _ a = a
church_case_165_original :: forall a. Equal a -> List a -> Dict a (List Int)
church_case_165_original = church_case_165

-- pick: total
church_case_166 :: forall church0 church1. (forall church3. ((forall church2. church2 -> church2 -> church2) -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church0 -> church4 -> church4) -> church4 -> church4) -> (forall church5. (church1 -> church5 -> church5) -> church5 -> church5) -> forall church7. ((forall church6. (church0 -> church6) -> (church1 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7
church_case_166 _ _ _ _ a = a
church_case_166_original :: forall a b. List Bool -> List a -> List b -> List (Either a b)
church_case_166_original = church_case_166

-- pick': total
church_case_167 :: forall church0. (forall church2. ((forall church1. church1 -> church1 -> church1) -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church0 -> church4 -> church4) -> church4 -> church4) -> forall church5. (church0 -> church5 -> church5) -> church5 -> church5
church_case_167 _ _ _ _ a = a
church_case_167_original :: forall a. List Bool -> List a -> List a -> List a
church_case_167_original = church_case_167

-- isSubstring: total
church_case_168 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> church5 -> church5
church_case_168 _ _ _ _ a = a
church_case_168_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Bool
church_case_168_original = church_case_168

-- isSubseq: total
church_case_169 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> church5 -> church5
church_case_169 _ _ _ _ a = a
church_case_169_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Bool
church_case_169_original = church_case_169

-- isPrefixOf: total
church_case_170 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> church5 -> church5
church_case_170 _ _ _ _ a = a
church_case_170_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Bool
church_case_170_original = church_case_170

-- break: total
church_case_171 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church5. ((forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church0 -> church4 -> church4) -> church4 -> church4) -> church5) -> church5
church_case_171 _ _ a = a (\_ b -> b) (\_ c -> c)
church_case_171_original :: forall a. (a -> Bool) -> List a -> Pair (List a) (List a)
church_case_171_original = church_case_171

-- elemBy: total
church_case_172 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> church0 -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> forall church4. church4 -> church4 -> church4
church_case_172 _ _ _ _ a = a
church_case_172_original :: forall a b. (a -> b -> Bool) -> a -> List b -> Bool
church_case_172_original = church_case_172

-- findIndex: total
church_case_173 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. church3 -> (Int -> church3) -> church3
church_case_173 _ _ a _ = a
church_case_173_original :: forall a. (a -> Bool) -> List a -> Maybe Int
church_case_173_original = church_case_173

-- findIndices: total
church_case_174 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (Int -> church3 -> church3) -> church3 -> church3
church_case_174 _ _ _ a = a
church_case_174_original :: forall a. (a -> Bool) -> List a -> List Int
church_case_174_original = church_case_174

-- elemIndex: total
church_case_175 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> church0 -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> forall church4. church4 -> (Int -> church4) -> church4
church_case_175 _ _ _ a _ = a
church_case_175_original :: forall a b. (a -> b -> Bool) -> a -> List b -> Maybe Int
church_case_175_original = church_case_175

-- isSuffixOf: total
church_case_176 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> church5 -> church5
church_case_176 _ _ _ _ a = a
church_case_176_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Bool
church_case_176_original = church_case_176

-- maximumBy: requires_partiality
church_case_177 :: forall church0. church0 -> (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church0
church_case_177 a _ _ = a
church_case_177_original :: forall a. a -> LE a -> List a -> a
church_case_177_original = church_case_177

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_177_partial :: forall a. LE a -> List a -> a
church_case_177_partial = church_case_177 undefined

-- maximumOn: requires_partiality
church_case_178 :: forall church0 church1. church1 -> (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (church1 -> church0) -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> church1
church_case_178 a _ _ _ = a
church_case_178_original :: forall b a. a -> LE b -> (a -> b) -> List a -> a
church_case_178_original = church_case_178

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_178_partial :: forall b a. LE b -> (a -> b) -> List a -> a
church_case_178_partial = church_case_178 undefined

-- minimumBy: requires_partiality
church_case_179 :: forall church0. church0 -> (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church0
church_case_179 a _ _ = a
church_case_179_original :: forall a. a -> LE a -> List a -> a
church_case_179_original = church_case_179

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_179_partial :: forall a. LE a -> List a -> a
church_case_179_partial = church_case_179 undefined

-- minimumOn: requires_partiality
church_case_180 :: forall church0 church1. church1 -> (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (church1 -> church0) -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> church1
church_case_180 a _ _ _ = a
church_case_180_original :: forall b a. a -> LE b -> (a -> b) -> List a -> a
church_case_180_original = church_case_180

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_180_partial :: forall b a. LE b -> (a -> b) -> List a -> a
church_case_180_partial = church_case_180 undefined

-- minMaxBy: requires_partiality
church_case_181 :: forall church0. church0 -> (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church0 -> church3) -> church3
church_case_181 a _ _ b = b a a
church_case_181_original :: forall a. a -> LE a -> List a -> Pair a a
church_case_181_original = church_case_181

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_181_partial :: forall a. LE a -> List a -> Pair a a
church_case_181_partial = church_case_181 undefined

-- deleteDuplicatesBy: total
church_case_182 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_182 _ _ _ a = a
church_case_182_original :: forall a. Equal a -> List a -> List a
church_case_182_original = church_case_182

-- complementBy: total
church_case_183 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. (church0 -> church5 -> church5) -> church5 -> church5
church_case_183 _ _ _ _ a = a
church_case_183_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> List a
church_case_183_original = church_case_183

-- containsAllBy: total
church_case_184 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> church5 -> church5
church_case_184 _ _ _ _ a = a
church_case_184_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Bool
church_case_184_original = church_case_184

-- containsAnyBy: total
church_case_185 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> church5 -> church5
church_case_185 _ _ _ _ a = a
church_case_185_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Bool
church_case_185_original = church_case_185

-- containsNoneBy: total
church_case_186 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> church5 -> church5
church_case_186 _ _ _ _ a = a
church_case_186_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Bool
church_case_186_original = church_case_186

-- containsOnlyBy: total
church_case_187 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> church5 -> church5
church_case_187 _ _ _ _ a = a
church_case_187_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Bool
church_case_187_original = church_case_187

-- partition3: total
church_case_188 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> church0 -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> ((forall church4. (church0 -> church4 -> church4) -> church4 -> church4) -> (forall church5. (church0 -> church5 -> church5) -> church5 -> church5) -> (forall church6. (church0 -> church6 -> church6) -> church6 -> church6) -> church1) -> church1
church_case_188 _ a _ b = b (\c -> c a) (\d -> d a) (\e -> e a)
church_case_188_original :: forall a r. LE a -> a -> List a -> (List a -> List a -> List a -> r) -> r
church_case_188_original = church_case_188

-- quickStep: total
church_case_189 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> ((forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church0 -> church4 -> church4) -> church4 -> church4) -> forall church5. (church0 -> church5 -> church5) -> church5 -> church5
church_case_189 _ _ _ _ a = a
church_case_189_original :: forall a. LE a -> (List a -> List a) -> List a -> List a
church_case_189_original = church_case_189

-- mergesort: total
church_case_190 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_190 _ _ _ a = a
church_case_190_original :: forall a. LE a -> List a -> List a
church_case_190_original = church_case_190

-- sortOn: total
church_case_191 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (church1 -> church0) -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church1 -> church4 -> church4) -> church4 -> church4
church_case_191 _ _ _ _ a = a
church_case_191_original :: forall b a. LE b -> (a -> b) -> List a -> List a
church_case_191_original = church_case_191

-- quicksort: total
church_case_192 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_192 _ _ _ a = a
church_case_192_original :: forall a. LE a -> List a -> List a
church_case_192_original = church_case_192

-- heapsort: total
church_case_193 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_193 _ _ _ a = a
church_case_193_original :: forall a. LE a -> List a -> List a
church_case_193_original = church_case_193

-- introsort: total
church_case_194 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_194 _ _ _ a = a
church_case_194_original :: forall a. LE a -> List a -> List a
church_case_194_original = church_case_194

-- nthElement: total
church_case_195 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> Int -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_195 _ _ _ _ a = a
church_case_195_original :: forall a. LE a -> Int -> List a -> List a
church_case_195_original = church_case_195

-- nthElement': total
church_case_196 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> Int -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_196 _ _ _ _ a = a
church_case_196_original :: forall a. LE a -> Int -> List a -> List a
church_case_196_original = church_case_196

-- longestCommonPrefix: total
church_case_197 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church0 -> church4 -> church4) -> church4 -> church4
church_case_197 _ _ _ _ a = a
church_case_197_original :: forall a. Equal a -> List a -> List a -> List a
church_case_197_original = church_case_197

-- longestCommonSuffix: total
church_case_198 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church0 -> church4 -> church4) -> church4 -> church4
church_case_198 _ _ _ _ a = a
church_case_198_original :: forall a. Equal a -> List a -> List a -> List a
church_case_198_original = church_case_198

-- longestCommonSublist: total
church_case_199 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church0 -> church4 -> church4) -> church4 -> church4
church_case_199 _ _ _ _ a = a
church_case_199_original :: forall a. Equal a -> List a -> List a -> List a
church_case_199_original = church_case_199

-- none: total
church_case_200 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. church3 -> church3 -> church3
church_case_200 _ _ _ a = a
church_case_200_original :: forall a. (a -> Bool) -> List a -> Bool
church_case_200_original = church_case_200

-- findIf: total
church_case_201 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. church3 -> (church0 -> church3) -> church3
church_case_201 _ _ a _ = a
church_case_201_original :: forall a. (a -> Bool) -> List a -> Maybe a
church_case_201_original = church_case_201

-- findIfNot: total
church_case_202 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. church3 -> (church0 -> church3) -> church3
church_case_202 _ _ a _ = a
church_case_202_original :: forall a. (a -> Bool) -> List a -> Maybe a
church_case_202_original = church_case_202

-- find: total
church_case_203 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> church1 -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. church4 -> (church0 -> church4) -> church4
church_case_203 _ _ _ a _ = a
church_case_203_original :: forall a b. (a -> b -> Bool) -> b -> List a -> Maybe a
church_case_203_original = church_case_203

-- findLast: total
church_case_204 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. church3 -> (church0 -> church3) -> church3
church_case_204 _ _ a _ = a
church_case_204_original :: forall a. (a -> Bool) -> List a -> Maybe a
church_case_204_original = church_case_204

-- countIf: needs_int_provider
church_case_205 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> Int
church_case_205 _ _ = churchZero
church_case_205_original :: forall a. (a -> Bool) -> List a -> Int
church_case_205_original = church_case_205

-- count: needs_int_provider
church_case_206 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> church1 -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> Int
church_case_206 _ _ _ = churchZero
church_case_206_original :: forall a b. (a -> b -> Bool) -> b -> List a -> Int
church_case_206_original = church_case_206

-- mismatch: total
church_case_207 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church6. church6 -> ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6) -> church6
church_case_207 _ _ _ a _ = a
church_case_207_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Maybe (Pair a b)
church_case_207_original = church_case_207

-- adjacentFind: total
church_case_208 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. church3 -> (church0 -> church3) -> church3
church_case_208 _ _ a _ = a
church_case_208_original :: forall a. (a -> a -> Bool) -> List a -> Maybe a
church_case_208_original = church_case_208

-- search: total
church_case_209 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> (Int -> church5) -> church5
church_case_209 _ _ _ a _ = a
church_case_209_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Maybe Int
church_case_209_original = church_case_209

-- findEnd: total
church_case_210 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> (Int -> church5) -> church5
church_case_210 _ _ _ a _ = a
church_case_210_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Maybe Int
church_case_210_original = church_case_210

-- findFirstOf: total
church_case_211 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> (church0 -> church5) -> church5
church_case_211 _ _ _ a _ = a
church_case_211_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Maybe a
church_case_211_original = church_case_211

-- searchN: total
church_case_212 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> Int -> church1 -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. church4 -> (Int -> church4) -> church4
church_case_212 _ a _ _ _ b = b a
church_case_212_original :: forall a b. (a -> b -> Bool) -> Int -> b -> List a -> Maybe Int
church_case_212_original = church_case_212

-- rotate: total
church_case_213 :: forall church0. Int -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_213 _ _ _ a = a
church_case_213_original :: forall a. Int -> List a -> List a
church_case_213_original = church_case_213

-- removeIf: total
church_case_214 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_214 _ _ _ a = a
church_case_214_original :: forall a. (a -> Bool) -> List a -> List a
church_case_214_original = church_case_214

-- remove: total
church_case_215 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> church1 -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church0 -> church4 -> church4) -> church4 -> church4
church_case_215 _ _ _ _ a = a
church_case_215_original :: forall a b. (a -> b -> Bool) -> b -> List a -> List a
church_case_215_original = church_case_215

-- replaceIf: total
church_case_216 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> church0 -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_216 _ a _ b = b a
church_case_216_original :: forall a. (a -> Bool) -> a -> List a -> List a
church_case_216_original = church_case_216

-- replace: total
church_case_217 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> church0 -> church0 -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_217 _ a _ _ b = b a
church_case_217_original :: forall a. (a -> a -> Bool) -> a -> a -> List a -> List a
church_case_217_original = church_case_217

-- uniqueBy: total
church_case_218 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_218 _ _ _ a = a
church_case_218_original :: forall a. (a -> a -> Bool) -> List a -> List a
church_case_218_original = church_case_218

-- isPartitioned: total
church_case_219 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. church3 -> church3 -> church3
church_case_219 _ _ _ a = a
church_case_219_original :: forall a. (a -> Bool) -> List a -> Bool
church_case_219_original = church_case_219

-- partitionPoint: needs_int_provider
church_case_220 :: forall church0. (church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> Int
church_case_220 _ _ = churchZero
church_case_220_original :: forall a. (a -> Bool) -> List a -> Int
church_case_220_original = church_case_220

-- isSorted: total
church_case_221 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. church3 -> church3 -> church3
church_case_221 _ _ _ a = a
church_case_221_original :: forall a. LE a -> List a -> Bool
church_case_221_original = church_case_221

-- isSortedUntil: needs_int_provider
church_case_222 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> Int
church_case_222 _ _ = churchZero
church_case_222_original :: forall a. LE a -> List a -> Int
church_case_222_original = church_case_222

-- lowerBound: needs_int_provider
church_case_223 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> church0 -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> Int
church_case_223 _ _ _ = churchZero
church_case_223_original :: forall a. LE a -> a -> List a -> Int
church_case_223_original = church_case_223

-- upperBound: needs_int_provider
church_case_224 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> church0 -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> Int
church_case_224 _ _ _ = churchZero
church_case_224_original :: forall a. LE a -> a -> List a -> Int
church_case_224_original = church_case_224

-- binarySearch: total
church_case_225 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> church0 -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. church3 -> church3 -> church3
church_case_225 _ _ _ _ a = a
church_case_225_original :: forall a. LE a -> a -> List a -> Bool
church_case_225_original = church_case_225

-- equalRange: needs_int_provider
church_case_226 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> church0 -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (Int -> Int -> church3) -> church3
church_case_226 _ _ _ a = a churchZero churchZero
church_case_226_original :: forall a. LE a -> a -> List a -> Pair Int Int
church_case_226_original = church_case_226

-- mergeBy: total
church_case_227 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church0 -> church4 -> church4) -> church4 -> church4
church_case_227 _ _ _ _ a = a
church_case_227_original :: forall a. LE a -> List a -> List a -> List a
church_case_227_original = church_case_227

-- includes: total
church_case_228 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. church4 -> church4 -> church4
church_case_228 _ _ _ _ a = a
church_case_228_original :: forall a. LE a -> List a -> List a -> Bool
church_case_228_original = church_case_228

-- setOp: total
church_case_229 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. church2 -> church2 -> church2) -> (forall church3. church3 -> church3 -> church3) -> (forall church4. church4 -> church4 -> church4) -> (forall church5. church5 -> church5 -> church5) -> (forall church6. (church0 -> church6 -> church6) -> church6 -> church6) -> (forall church7. (church0 -> church7 -> church7) -> church7 -> church7) -> forall church8. (church0 -> church8 -> church8) -> church8 -> church8
church_case_229 _ _ _ _ _ _ _ _ a = a
church_case_229_original :: forall a. LE a -> Bool -> Bool -> Bool -> Bool -> List a -> List a -> List a
church_case_229_original = church_case_229

-- setUnion: total
church_case_230 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church0 -> church4 -> church4) -> church4 -> church4
church_case_230 _ _ _ _ a = a
church_case_230_original :: forall a. LE a -> List a -> List a -> List a
church_case_230_original = church_case_230

-- setIntersection: total
church_case_231 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church0 -> church4 -> church4) -> church4 -> church4
church_case_231 _ _ _ _ a = a
church_case_231_original :: forall a. LE a -> List a -> List a -> List a
church_case_231_original = church_case_231

-- setDifference: total
church_case_232 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church0 -> church4 -> church4) -> church4 -> church4
church_case_232 _ _ _ _ a = a
church_case_232_original :: forall a. LE a -> List a -> List a -> List a
church_case_232_original = church_case_232

-- setSymmetricDifference: total
church_case_233 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church0 -> church4 -> church4) -> church4 -> church4
church_case_233 _ _ _ _ a = a
church_case_233_original :: forall a. LE a -> List a -> List a -> List a
church_case_233_original = church_case_233

-- maxBy: total
church_case_234 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> church0 -> church0 -> church0
church_case_234 _ _ a = a
church_case_234_original :: forall a. LE a -> a -> a -> a
church_case_234_original = church_case_234

-- minBy: total
church_case_235 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> church0 -> church0 -> church0
church_case_235 _ _ a = a
church_case_235_original :: forall a. LE a -> a -> a -> a
church_case_235_original = church_case_235

-- minmaxBy: total
church_case_236 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> church0 -> church0 -> forall church2. (church0 -> church0 -> church2) -> church2
church_case_236 _ a _ b = b a a
church_case_236_original :: forall a. LE a -> a -> a -> Pair a a
church_case_236_original = church_case_236

-- clamp: total
church_case_237 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> church0 -> church0 -> church0 -> church0
church_case_237 _ _ _ a = a
church_case_237_original :: forall a. LE a -> a -> a -> a -> a
church_case_237_original = church_case_237

-- minmaxElement: requires_partiality
church_case_238 :: forall church0. church0 -> (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church0 -> church3) -> church3
church_case_238 a _ _ b = b a a
church_case_238_original :: forall a. a -> LE a -> List a -> Pair a a
church_case_238_original = church_case_238

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_238_partial :: forall a. LE a -> List a -> Pair a a
church_case_238_partial = church_case_238 undefined

-- equalBy: total
church_case_239 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> church5 -> church5
church_case_239 _ _ _ _ a = a
church_case_239_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Bool
church_case_239_original = church_case_239

-- lexicographicalLess: total
church_case_240 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. church4 -> church4 -> church4
church_case_240 _ _ _ _ a = a
church_case_240_original :: forall a. LE a -> List a -> List a -> Bool
church_case_240_original = church_case_240

-- compareBy: needs_int_provider
church_case_241 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> Int
church_case_241 _ _ _ = churchZero
church_case_241_original :: forall a. LE a -> List a -> List a -> Int
church_case_241_original = church_case_241

-- isPermutation: total
church_case_242 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. church4 -> church4 -> church4
church_case_242 _ _ _ _ a = a
church_case_242_original :: forall a. (a -> a -> Bool) -> List a -> List a -> Bool
church_case_242_original = church_case_242

-- nextPermutation: total
church_case_243 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church4. church4 -> ((forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> church4) -> church4
church_case_243 _ _ a _ = a
church_case_243_original :: forall a. LE a -> List a -> Maybe (List a)
church_case_243_original = church_case_243

-- prevPermutation: total
church_case_244 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church4. church4 -> ((forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> church4) -> church4
church_case_244 _ _ a _ = a
church_case_244_original :: forall a. LE a -> List a -> Maybe (List a)
church_case_244_original = church_case_244

-- member: total
church_case_245 :: forall church0 church1 church2. (church0 -> church1 -> forall church3. church3 -> church3 -> church3) -> church1 -> (forall church5. ((forall church4. (church0 -> church2 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church6. church6 -> church6 -> church6
church_case_245 _ _ _ _ a = a
church_case_245_original :: forall a c b. (a -> c -> Bool) -> c -> Dict a b -> Bool
church_case_245_original = church_case_245

-- notMember: total
church_case_246 :: forall church0 church1 church2. (church0 -> church1 -> forall church3. church3 -> church3 -> church3) -> church1 -> (forall church5. ((forall church4. (church0 -> church2 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church6. church6 -> church6 -> church6
church_case_246 _ _ _ _ a = a
church_case_246_original :: forall a c b. (a -> c -> Bool) -> c -> Dict a b -> Bool
church_case_246_original = church_case_246

-- findWithDefault: total
church_case_247 :: forall church0 church1 church2. church0 -> (church1 -> church2 -> forall church3. church3 -> church3 -> church3) -> church2 -> (forall church5. ((forall church4. (church1 -> church0 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> church0
church_case_247 a _ _ _ = a
church_case_247_original :: forall b a c. b -> (a -> c -> Bool) -> c -> Dict a b -> b
church_case_247_original = church_case_247

-- atKey: requires_partiality
church_case_248 :: forall church0 church1 church2. church2 -> (church0 -> church1 -> forall church3. church3 -> church3 -> church3) -> church1 -> (forall church5. ((forall church4. (church0 -> church2 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> church2
church_case_248 a _ _ _ = a
church_case_248_original :: forall a c b. b -> (a -> c -> Bool) -> c -> Dict a b -> b
church_case_248_original = church_case_248

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_248_partial :: forall a c b. (a -> c -> Bool) -> c -> Dict a b -> b
church_case_248_partial = church_case_248 undefined

-- keys: total
church_case_249 :: forall church0 church1. (forall church3. ((forall church2. (church0 -> church1 -> church2) -> church2) -> church3 -> church3) -> church3 -> church3) -> forall church4. (church0 -> church4 -> church4) -> church4 -> church4
church_case_249 _ _ a = a
church_case_249_original :: forall k v. Dict k v -> List k
church_case_249_original = church_case_249

-- values: total
church_case_250 :: forall church0 church1. (forall church3. ((forall church2. (church0 -> church1 -> church2) -> church2) -> church3 -> church3) -> church3 -> church3) -> forall church4. (church1 -> church4 -> church4) -> church4 -> church4
church_case_250 _ _ a = a
church_case_250_original :: forall k v. Dict k v -> List v
church_case_250_original = church_case_250

-- elems: total
church_case_251 :: forall church0 church1. (forall church3. ((forall church2. (church0 -> church1 -> church2) -> church2) -> church3 -> church3) -> church3 -> church3) -> forall church4. (church1 -> church4 -> church4) -> church4 -> church4
church_case_251 _ _ a = a
church_case_251_original :: forall k v. Dict k v -> List v
church_case_251_original = church_case_251

-- sizeDict: needs_int_provider
church_case_252 :: forall church0 church1. (forall church3. ((forall church2. (church0 -> church1 -> church2) -> church2) -> church3 -> church3) -> church3 -> church3) -> Int
church_case_252 _ = churchZero
church_case_252_original :: forall k v. Dict k v -> Int
church_case_252_original = church_case_252

-- nullDict: total
church_case_253 :: forall church0 church1. (forall church3. ((forall church2. (church0 -> church1 -> church2) -> church2) -> church3 -> church3) -> church3 -> church3) -> forall church4. church4 -> church4 -> church4
church_case_253 _ _ a = a
church_case_253_original :: forall k v. Dict k v -> Bool
church_case_253_original = church_case_253

-- singletonDict: total
church_case_254 :: forall church0 church1. church0 -> church1 -> forall church3. ((forall church2. (church0 -> church1 -> church2) -> church2) -> church3 -> church3) -> church3 -> church3
church_case_254 _ _ _ a = a
church_case_254_original :: forall k v. k -> v -> Dict k v
church_case_254_original = church_case_254

-- lookupAll: total
church_case_255 :: forall church0 church1 church2. (church0 -> church1 -> forall church3. church3 -> church3 -> church3) -> church1 -> (forall church5. ((forall church4. (church0 -> church2 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church6. (church2 -> church6 -> church6) -> church6 -> church6
church_case_255 _ _ _ _ a = a
church_case_255_original :: forall a c b. (a -> c -> Bool) -> c -> Dict a b -> List b
church_case_255_original = church_case_255

-- countKey: needs_int_provider
church_case_256 :: forall church0 church1 church2. (church0 -> church1 -> forall church3. church3 -> church3 -> church3) -> church1 -> (forall church5. ((forall church4. (church0 -> church2 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> Int
church_case_256 _ _ _ = churchZero
church_case_256_original :: forall a c b. (a -> c -> Bool) -> c -> Dict a b -> Int
church_case_256_original = church_case_256

-- insert: total
church_case_257 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> church0 -> church1 -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_257 _ _ _ _ _ a = a
church_case_257_original :: forall k v. Equal k -> k -> v -> Dict k v -> Dict k v
church_case_257_original = church_case_257

-- insertWith: total
church_case_258 :: forall church0 church1. (church1 -> church1 -> church1) -> (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> church0 -> church1 -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_258 _ _ _ _ _ _ a = a
church_case_258_original :: forall k v. (v -> v -> v) -> Equal k -> k -> v -> Dict k v -> Dict k v
church_case_258_original = church_case_258

-- fromList: total
church_case_259 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_259 _ _ _ a = a
church_case_259_original :: forall k v. Equal k -> List (Pair k v) -> Dict k v
church_case_259_original = church_case_259

-- fromListWith: total
church_case_260 :: forall church0 church1. (church0 -> church0 -> church0) -> (church1 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church4. ((forall church3. (church1 -> church0 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church1 -> church0 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_260 _ _ _ _ a = a
church_case_260_original :: forall v k. (v -> v -> v) -> Equal k -> List (Pair k v) -> Dict k v
church_case_260_original = church_case_260

-- adjust: total
church_case_261 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (church1 -> church1) -> church0 -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_261 _ _ _ _ _ a = a
church_case_261_original :: forall k v. Equal k -> (v -> v) -> k -> Dict k v -> Dict k v
church_case_261_original = church_case_261

-- alter: total
church_case_262 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> ((forall church3. church3 -> (church1 -> church3) -> church3) -> forall church4. church4 -> (church1 -> church4) -> church4) -> church0 -> (forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6) -> forall church8. ((forall church7. (church0 -> church1 -> church7) -> church7) -> church8 -> church8) -> church8 -> church8
church_case_262 _ _ _ _ _ a = a
church_case_262_original :: forall k v. Equal k -> (Maybe v -> Maybe v) -> k -> Dict k v -> Dict k v
church_case_262_original = church_case_262

-- mapWithKey: total
church_case_263 :: forall church0 church1 church2. (church0 -> church1 -> church2) -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church0 -> church2 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_263 _ _ _ a = a
church_case_263_original :: forall k v1 v2. (k -> v1 -> v2) -> Dict k v1 -> Dict k v2
church_case_263_original = church_case_263

-- mapMaybeWithKey: total
church_case_264 :: forall church0 church1 church2. (church0 -> church1 -> forall church3. church3 -> (church2 -> church3) -> church3) -> (forall church5. ((forall church4. (church0 -> church1 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church7. ((forall church6. (church0 -> church2 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7
church_case_264 _ _ _ a = a
church_case_264_original :: forall k v1 v2. (k -> v1 -> Maybe v2) -> Dict k v1 -> Dict k v2
church_case_264_original = church_case_264

-- mapKeysWith: total
church_case_265 :: forall church0 church1 church2. (church0 -> church0 -> church0) -> (church1 -> church1 -> forall church3. church3 -> church3 -> church3) -> (church2 -> church1) -> (forall church5. ((forall church4. (church2 -> church0 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church7. ((forall church6. (church1 -> church0 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7
church_case_265 _ _ _ _ _ a = a
church_case_265_original :: forall v k2 k1. (v -> v -> v) -> Equal k2 -> (k1 -> k2) -> Dict k1 v -> Dict k2 v
church_case_265_original = church_case_265

-- update: total
church_case_266 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (church1 -> forall church3. church3 -> (church1 -> church3) -> church3) -> church0 -> (forall church5. ((forall church4. (church0 -> church1 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church7. ((forall church6. (church0 -> church1 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7
church_case_266 _ _ _ _ _ a = a
church_case_266_original :: forall k v. Equal k -> (v -> Maybe v) -> k -> Dict k v -> Dict k v
church_case_266_original = church_case_266

-- updateWithKey: total
church_case_267 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (church0 -> church1 -> forall church3. church3 -> (church1 -> church3) -> church3) -> church0 -> (forall church5. ((forall church4. (church0 -> church1 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church7. ((forall church6. (church0 -> church1 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7
church_case_267 _ _ _ _ _ a = a
church_case_267_original :: forall k v. Equal k -> (k -> v -> Maybe v) -> k -> Dict k v -> Dict k v
church_case_267_original = church_case_267

-- filterWithKey: total
church_case_268 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_268 _ _ _ a = a
church_case_268_original :: forall k v. (k -> v -> Bool) -> Dict k v -> Dict k v
church_case_268_original = church_case_268

-- filterValues: total
church_case_269 :: forall church0 church1. (church0 -> forall church2. church2 -> church2 -> church2) -> (forall church4. ((forall church3. (church1 -> church0 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church1 -> church0 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_269 _ _ _ a = a
church_case_269_original :: forall v k. (v -> Bool) -> Dict k v -> Dict k v
church_case_269_original = church_case_269

-- partitionDict: total
church_case_270 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church9. ((forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6) -> (forall church8. ((forall church7. (church0 -> church1 -> church7) -> church7) -> church8 -> church8) -> church8 -> church8) -> church9) -> church9
church_case_270 _ _ a = a (\_ b -> b) (\_ c -> c)
church_case_270_original :: forall k v. (k -> v -> Bool) -> Dict k v -> Pair (Dict k v) (Dict k v)
church_case_270_original = church_case_270

-- unionWith: total
church_case_271 :: forall church0 church1. (church0 -> church0 -> church0) -> (church1 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church4. ((forall church3. (church1 -> church0 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> (forall church6. ((forall church5. (church1 -> church0 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6) -> forall church8. ((forall church7. (church1 -> church0 -> church7) -> church7) -> church8 -> church8) -> church8 -> church8
church_case_271 _ _ _ _ _ a = a
church_case_271_original :: forall v k. (v -> v -> v) -> Equal k -> Dict k v -> Dict k v -> Dict k v
church_case_271_original = church_case_271

-- unionWithKey: total
church_case_272 :: forall church0 church1. (church0 -> church1 -> church1 -> church1) -> (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> (forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6) -> forall church8. ((forall church7. (church0 -> church1 -> church7) -> church7) -> church8 -> church8) -> church8 -> church8
church_case_272 _ _ _ _ _ a = a
church_case_272_original :: forall k v. (k -> v -> v -> v) -> Equal k -> Dict k v -> Dict k v -> Dict k v
church_case_272_original = church_case_272

-- union: total
church_case_273 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> (forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6) -> forall church8. ((forall church7. (church0 -> church1 -> church7) -> church7) -> church8 -> church8) -> church8 -> church8
church_case_273 _ _ _ _ a = a
church_case_273_original :: forall k v. Equal k -> Dict k v -> Dict k v -> Dict k v
church_case_273_original = church_case_273

-- unionsWith: total
church_case_274 :: forall church0 church1. (church0 -> church0 -> church0) -> (church1 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church5. ((forall church4. ((forall church3. (church1 -> church0 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church7. ((forall church6. (church1 -> church0 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7
church_case_274 _ _ _ _ a = a
church_case_274_original :: forall v k. (v -> v -> v) -> Equal k -> List (Dict k v) -> Dict k v
church_case_274_original = church_case_274

-- unions: total
church_case_275 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (forall church5. ((forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> church5 -> church5) -> church5 -> church5) -> forall church7. ((forall church6. (church0 -> church1 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7
church_case_275 _ _ _ a = a
church_case_275_original :: forall k v. Equal k -> List (Dict k v) -> Dict k v
church_case_275_original = church_case_275

-- intersectionWith: total
church_case_276 :: forall church0 church1 church2 church3. (church0 -> church1 -> church2) -> (church3 -> church3 -> forall church4. church4 -> church4 -> church4) -> (forall church6. ((forall church5. (church3 -> church0 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6) -> (forall church8. ((forall church7. (church3 -> church1 -> church7) -> church7) -> church8 -> church8) -> church8 -> church8) -> forall church10. ((forall church9. (church3 -> church2 -> church9) -> church9) -> church10 -> church10) -> church10 -> church10
church_case_276 _ _ _ _ _ a = a
church_case_276_original :: forall v1 v2 v3 k. (v1 -> v2 -> v3) -> Equal k -> Dict k v1 -> Dict k v2 -> Dict k v3
church_case_276_original = church_case_276

-- intersectionWithKey: total
church_case_277 :: forall church0 church1 church2 church3. (church0 -> church1 -> church2 -> church3) -> (church0 -> church0 -> forall church4. church4 -> church4 -> church4) -> (forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6) -> (forall church8. ((forall church7. (church0 -> church2 -> church7) -> church7) -> church8 -> church8) -> church8 -> church8) -> forall church10. ((forall church9. (church0 -> church3 -> church9) -> church9) -> church10 -> church10) -> church10 -> church10
church_case_277 _ _ _ _ _ a = a
church_case_277_original :: forall k v1 v2 v3. (k -> v1 -> v2 -> v3) -> Equal k -> Dict k v1 -> Dict k v2 -> Dict k v3
church_case_277_original = church_case_277

-- intersection: total
church_case_278 :: forall church0 church1 church2. (church0 -> church0 -> forall church3. church3 -> church3 -> church3) -> (forall church5. ((forall church4. (church0 -> church1 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> (forall church7. ((forall church6. (church0 -> church2 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7) -> forall church9. ((forall church8. (church0 -> church1 -> church8) -> church8) -> church9 -> church9) -> church9 -> church9
church_case_278 _ _ _ _ a = a
church_case_278_original :: forall k v1 v2. Equal k -> Dict k v1 -> Dict k v2 -> Dict k v1
church_case_278_original = church_case_278

-- difference: total
church_case_279 :: forall church0 church1 church2. (church0 -> church0 -> forall church3. church3 -> church3 -> church3) -> (forall church5. ((forall church4. (church0 -> church1 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> (forall church7. ((forall church6. (church0 -> church2 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7) -> forall church9. ((forall church8. (church0 -> church1 -> church8) -> church8) -> church9 -> church9) -> church9 -> church9
church_case_279 _ _ _ _ a = a
church_case_279_original :: forall k v1 v2. Equal k -> Dict k v1 -> Dict k v2 -> Dict k v1
church_case_279_original = church_case_279

-- differenceWith: total
church_case_280 :: forall church0 church1 church2. (church0 -> church1 -> forall church3. church3 -> (church0 -> church3) -> church3) -> (church2 -> church2 -> forall church4. church4 -> church4 -> church4) -> (forall church6. ((forall church5. (church2 -> church0 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6) -> (forall church8. ((forall church7. (church2 -> church1 -> church7) -> church7) -> church8 -> church8) -> church8 -> church8) -> forall church10. ((forall church9. (church2 -> church0 -> church9) -> church9) -> church10 -> church10) -> church10 -> church10
church_case_280 _ _ _ _ _ a = a
church_case_280_original :: forall v1 v2 k. (v1 -> v2 -> Maybe v1) -> Equal k -> Dict k v1 -> Dict k v2 -> Dict k v1
church_case_280_original = church_case_280

-- differenceWithKey: total
church_case_281 :: forall church0 church1 church2. (church0 -> church1 -> church2 -> forall church3. church3 -> (church1 -> church3) -> church3) -> (church0 -> church0 -> forall church4. church4 -> church4 -> church4) -> (forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6) -> (forall church8. ((forall church7. (church0 -> church2 -> church7) -> church7) -> church8 -> church8) -> church8 -> church8) -> forall church10. ((forall church9. (church0 -> church1 -> church9) -> church9) -> church10 -> church10) -> church10 -> church10
church_case_281 _ _ _ _ _ a = a
church_case_281_original :: forall k v1 v2. (k -> v1 -> v2 -> Maybe v1) -> Equal k -> Dict k v1 -> Dict k v2 -> Dict k v1
church_case_281_original = church_case_281

-- restrictKeys: total
church_case_282 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> (forall church5. (church0 -> church5 -> church5) -> church5 -> church5) -> forall church7. ((forall church6. (church0 -> church1 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7
church_case_282 _ _ _ _ a = a
church_case_282_original :: forall k v. Equal k -> Dict k v -> List k -> Dict k v
church_case_282_original = church_case_282

-- withoutKeys: total
church_case_283 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> (forall church5. (church0 -> church5 -> church5) -> church5 -> church5) -> forall church7. ((forall church6. (church0 -> church1 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7
church_case_283 _ _ _ _ a = a
church_case_283_original :: forall k v. Equal k -> Dict k v -> List k -> Dict k v
church_case_283_original = church_case_283

-- foldrWithKey: total
church_case_284 :: forall church0 church1 church2. (church0 -> church1 -> church2 -> church2) -> church2 -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> church2
church_case_284 _ a _ = a
church_case_284_original :: forall k v b. (k -> v -> b -> b) -> b -> Dict k v -> b
church_case_284_original = church_case_284

-- foldlWithKey: total
church_case_285 :: forall church0 church1 church2. (church0 -> church1 -> church2 -> church0) -> church0 -> (forall church4. ((forall church3. (church1 -> church2 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> church0
church_case_285 _ a _ = a
church_case_285_original :: forall b k v. (b -> k -> v -> b) -> b -> Dict k v -> b
church_case_285_original = church_case_285

-- isSubmapOfBy: total
church_case_286 :: forall church0 church1 church2. (church0 -> church1 -> forall church3. church3 -> church3 -> church3) -> (church2 -> church2 -> forall church4. church4 -> church4 -> church4) -> (forall church6. ((forall church5. (church2 -> church0 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6) -> (forall church8. ((forall church7. (church2 -> church1 -> church7) -> church7) -> church8 -> church8) -> church8 -> church8) -> forall church9. church9 -> church9 -> church9
church_case_286 _ _ _ _ _ a = a
church_case_286_original :: forall v1 v2 k. (v1 -> v2 -> Bool) -> Equal k -> Dict k v1 -> Dict k v2 -> Bool
church_case_286_original = church_case_286

-- isSubmapOf: total
church_case_287 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> (church1 -> church1 -> forall church3. church3 -> church3 -> church3) -> (forall church5. ((forall church4. (church1 -> church0 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> (forall church7. ((forall church6. (church1 -> church0 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7) -> forall church8. church8 -> church8 -> church8
church_case_287 _ _ _ _ _ a = a
church_case_287_original :: forall v k. Equal v -> Equal k -> Dict k v -> Dict k v -> Bool
church_case_287_original = church_case_287

-- disjoint: total
church_case_288 :: forall church0 church1 church2. (church0 -> church0 -> forall church3. church3 -> church3 -> church3) -> (forall church5. ((forall church4. (church0 -> church1 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5) -> (forall church7. ((forall church6. (church0 -> church2 -> church6) -> church6) -> church7 -> church7) -> church7 -> church7) -> forall church8. church8 -> church8 -> church8
church_case_288 _ _ _ _ a = a
church_case_288_original :: forall k v1 v2. Equal k -> Dict k v1 -> Dict k v2 -> Bool
church_case_288_original = church_case_288

-- accumulate: total
church_case_289 :: forall church0 church1. (church0 -> church1 -> church0) -> church0 -> (forall church2. (church1 -> church2 -> church2) -> church2 -> church2) -> church0
church_case_289 _ a _ = a
church_case_289_original :: forall b a. (b -> a -> b) -> b -> List a -> b
church_case_289_original = church_case_289

-- reduce: requires_partiality
church_case_290 :: forall church0. church0 -> (church0 -> church0 -> church0) -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> church0
church_case_290 a _ _ = a
church_case_290_original :: forall a. a -> (a -> a -> a) -> List a -> a
church_case_290_original = church_case_290

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_290_partial :: forall a. (a -> a -> a) -> List a -> a
church_case_290_partial = church_case_290 undefined

-- innerProduct: total
church_case_291 :: forall church0 church1 church2 church3. (church0 -> church1 -> church0) -> (church2 -> church3 -> church1) -> church0 -> (forall church4. (church2 -> church4 -> church4) -> church4 -> church4) -> (forall church5. (church3 -> church5 -> church5) -> church5 -> church5) -> church0
church_case_291 _ _ a _ _ = a
church_case_291_original :: forall c d a b. (c -> d -> c) -> (a -> b -> d) -> c -> List a -> List b -> c
church_case_291_original = church_case_291

-- partialSum: total
church_case_292 :: forall church0. (church0 -> church0 -> church0) -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_292 _ _ _ a = a
church_case_292_original :: forall a. (a -> a -> a) -> List a -> List a
church_case_292_original = church_case_292

-- adjacentDifference: total
church_case_293 :: forall church0. (church0 -> church0 -> church0) -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_293 _ _ _ a = a
church_case_293_original :: forall a. (a -> a -> a) -> List a -> List a
church_case_293_original = church_case_293

-- inclusiveScan: total
church_case_294 :: forall church0. (church0 -> church0 -> church0) -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_294 _ _ _ a = a
church_case_294_original :: forall a. (a -> a -> a) -> List a -> List a
church_case_294_original = church_case_294

-- exclusiveScan: total
church_case_295 :: forall church0. (church0 -> church0 -> church0) -> church0 -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_295 _ a _ b = b a
church_case_295_original :: forall a. (a -> a -> a) -> a -> List a -> List a
church_case_295_original = church_case_295

-- transformReduce: total
church_case_296 :: forall church0 church1. (church0 -> church0 -> church0) -> (church1 -> church0) -> church0 -> (forall church2. (church1 -> church2 -> church2) -> church2 -> church2) -> church0
church_case_296 _ _ a _ = a
church_case_296_original :: forall b a. (b -> b -> b) -> (a -> b) -> b -> List a -> b
church_case_296_original = church_case_296

-- transformReduce2: total
church_case_297 :: forall church0 church1 church2 church3. (church0 -> church1 -> church0) -> (church2 -> church3 -> church1) -> church0 -> (forall church4. (church2 -> church4 -> church4) -> church4 -> church4) -> (forall church5. (church3 -> church5 -> church5) -> church5 -> church5) -> church0
church_case_297 _ _ a _ _ = a
church_case_297_original :: forall c d a b. (c -> d -> c) -> (a -> b -> d) -> c -> List a -> List b -> c
church_case_297_original = church_case_297

-- transformInclusiveScan: total
church_case_298 :: forall church0 church1. (church0 -> church0 -> church0) -> (church1 -> church0) -> (forall church2. (church1 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_298 _ _ _ _ a = a
church_case_298_original :: forall b a. (b -> b -> b) -> (a -> b) -> List a -> List b
church_case_298_original = church_case_298

-- transformExclusiveScan: total
church_case_299 :: forall church0 church1. (church0 -> church0 -> church0) -> (church1 -> church0) -> church0 -> (forall church2. (church1 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_299 _ _ a _ b = b a
church_case_299_original :: forall b a. (b -> b -> b) -> (a -> b) -> b -> List a -> List b
church_case_299_original = church_case_299

-- isJust: total
church_case_300 :: forall church0. (forall church1. church1 -> (church0 -> church1) -> church1) -> forall church2. church2 -> church2 -> church2
church_case_300 _ _ a = a
church_case_300_original :: forall a. Maybe a -> Bool
church_case_300_original = church_case_300

-- dup: total
church_case_301 :: forall church0. church0 -> forall church1. (church0 -> church0 -> church1) -> church1
church_case_301 a b = b a a
church_case_301_original :: forall a. a -> Pair a a
church_case_301_original = church_case_301

-- andList: total
church_case_302 :: (forall church1. ((forall church0. church0 -> church0 -> church0) -> church1 -> church1) -> church1 -> church1) -> forall church2. church2 -> church2 -> church2
church_case_302 _ _ a = a
church_case_302_original :: List Bool -> Bool
church_case_302_original = church_case_302

-- orList: total
church_case_303 :: (forall church1. ((forall church0. church0 -> church0 -> church0) -> church1 -> church1) -> church1 -> church1) -> forall church2. church2 -> church2 -> church2
church_case_303 _ _ a = a
church_case_303_original :: List Bool -> Bool
church_case_303_original = church_case_303

-- cycleN: total
church_case_304 :: forall church0. Int -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_304 _ _ _ a = a
church_case_304_original :: forall a. Int -> List a -> List a
church_case_304_original = church_case_304

-- iterateN: total
church_case_305 :: forall church0. Int -> (church0 -> church0) -> church0 -> forall church1. (church0 -> church1 -> church1) -> church1 -> church1
church_case_305 _ _ a b = b a
church_case_305_original :: forall a. Int -> (a -> a) -> a -> List a
church_case_305_original = church_case_305

-- range: total
church_case_306 :: Int -> Int -> forall church0. (Int -> church0 -> church0) -> church0 -> church0
church_case_306 a _ b = b a
church_case_306_original :: Int -> Int -> List Int
church_case_306_original = church_case_306

-- factorial: total
church_case_307 :: Int -> Int
church_case_307 a = a
church_case_307_original :: Int -> Int
church_case_307_original = church_case_307

-- isPalindrome: total
church_case_308 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. church3 -> church3 -> church3
church_case_308 _ _ _ a = a
church_case_308_original :: forall a. Equal a -> List a -> Bool
church_case_308_original = church_case_308

-- isRotation: total
church_case_309 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. church4 -> church4 -> church4
church_case_309 _ _ _ _ a = a
church_case_309_original :: forall a. Equal a -> List a -> List a -> Bool
church_case_309_original = church_case_309

-- notElemBy: total
church_case_310 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> church0 -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> forall church4. church4 -> church4 -> church4
church_case_310 _ _ _ _ a = a
church_case_310_original :: forall a b. (a -> b -> Bool) -> a -> List b -> Bool
church_case_310_original = church_case_310

-- removeOnce: total
church_case_311 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> church0 -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_311 _ a _ b = b a
church_case_311_original :: forall a. Equal a -> a -> List a -> List a
church_case_311_original = church_case_311

-- replaceOnce: total
church_case_312 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> church0 -> church0 -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_312 _ a _ _ b = b a
church_case_312_original :: forall a. Equal a -> a -> a -> List a -> List a
church_case_312_original = church_case_312

-- intercalate: total
church_case_313 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> (forall church3. ((forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church3 -> church3) -> church3 -> church3) -> forall church4. (church0 -> church4 -> church4) -> church4 -> church4
church_case_313 _ _ _ a = a
church_case_313_original :: forall a. List a -> List (List a) -> List a
church_case_313_original = church_case_313

-- sum: needs_int_provider
church_case_314 :: (forall church0. (Int -> church0 -> church0) -> church0 -> church0) -> Int
church_case_314 _ = churchZero
church_case_314_original :: List Int -> Int
church_case_314_original = church_case_314

-- product: needs_int_provider
church_case_315 :: (forall church0. (Int -> church0 -> church0) -> church0 -> church0) -> Int
church_case_315 _ = churchZero
church_case_315_original :: List Int -> Int
church_case_315_original = church_case_315

-- maximum: requires_partiality
church_case_316 :: forall church0. church0 -> (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church0
church_case_316 a _ _ = a
church_case_316_original :: forall a. a -> LE a -> List a -> a
church_case_316_original = church_case_316

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_316_partial :: forall a. LE a -> List a -> a
church_case_316_partial = church_case_316 undefined

-- minimum: requires_partiality
church_case_317 :: forall church0. church0 -> (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church0
church_case_317 a _ _ = a
church_case_317_original :: forall a. a -> LE a -> List a -> a
church_case_317_original = church_case_317

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_317_partial :: forall a. LE a -> List a -> a
church_case_317_partial = church_case_317 undefined

-- minMax: requires_partiality
church_case_318 :: forall church0. church0 -> (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church0 -> church3) -> church3
church_case_318 a _ _ b = b a a
church_case_318_original :: forall a. a -> LE a -> List a -> Pair a a
church_case_318_original = church_case_318

-- The sole explicit partial-value boundary; synthesis never sees undefined.
church_case_318_partial :: forall a. LE a -> List a -> Pair a a
church_case_318_partial = church_case_318 undefined

-- sortBy: total
church_case_319 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_319 _ _ _ a = a
church_case_319_original :: forall a. LE a -> List a -> List a
church_case_319_original = church_case_319

-- sort: total
church_case_320 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_320 _ _ _ a = a
church_case_320_original :: forall a. LE a -> List a -> List a
church_case_320_original = church_case_320

-- group: total
church_case_321 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church4. ((forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> church4 -> church4) -> church4 -> church4
church_case_321 _ _ _ a = a
church_case_321_original :: forall a. Equal a -> List a -> List (List a)
church_case_321_original = church_case_321

-- nub: total
church_case_322 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_322 _ _ _ a = a
church_case_322_original :: forall a. Equal a -> List a -> List a
church_case_322_original = church_case_322

-- tally: total
church_case_323 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church4. ((forall church3. (church0 -> Int -> church3) -> church3) -> church4 -> church4) -> church4 -> church4
church_case_323 _ _ _ a = a
church_case_323_original :: forall a. Equal a -> List a -> Dict a Int
church_case_323_original = church_case_323

-- counts: total
church_case_324 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church4. ((forall church3. (church0 -> Int -> church3) -> church3) -> church4 -> church4) -> church4 -> church4
church_case_324 _ _ _ a = a
church_case_324_original :: forall a. Equal a -> List a -> Dict a Int
church_case_324_original = church_case_324

-- countDistinct: needs_int_provider
church_case_325 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> Int
church_case_325 _ _ = churchZero
church_case_325_original :: forall a. Equal a -> List a -> Int
church_case_325_original = church_case_325

-- positionIndex: total
church_case_326 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church5. ((forall church4. (church0 -> (forall church3. (Int -> church3 -> church3) -> church3 -> church3) -> church4) -> church4) -> church5 -> church5) -> church5 -> church5
church_case_326 _ _ _ a = a
church_case_326_original :: forall a. Equal a -> List a -> Dict a (List Int)
church_case_326_original = church_case_326

-- elem: total
church_case_327 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> church0 -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> forall church4. church4 -> church4 -> church4
church_case_327 _ _ _ _ a = a
church_case_327_original :: forall a b. (a -> b -> Bool) -> a -> List b -> Bool
church_case_327_original = church_case_327

-- notElem: total
church_case_328 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> church0 -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> forall church4. church4 -> church4 -> church4
church_case_328 _ _ _ _ a = a
church_case_328_original :: forall a b. (a -> b -> Bool) -> a -> List b -> Bool
church_case_328_original = church_case_328

-- delete: total
church_case_329 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> church0 -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_329 _ a _ b = b a
church_case_329_original :: forall a. Equal a -> a -> List a -> List a
church_case_329_original = church_case_329

-- intersect: total
church_case_330 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. (church0 -> church4 -> church4) -> church4 -> church4
church_case_330 _ _ _ _ a = a
church_case_330_original :: forall a. Equal a -> List a -> List a -> List a
church_case_330_original = church_case_330

-- complement: total
church_case_331 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. (church0 -> church5 -> church5) -> church5 -> church5
church_case_331 _ _ _ _ a = a
church_case_331_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> List a
church_case_331_original = church_case_331

-- containsAll: total
church_case_332 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> church5 -> church5
church_case_332 _ _ _ _ a = a
church_case_332_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Bool
church_case_332_original = church_case_332

-- containsAny: total
church_case_333 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> church5 -> church5
church_case_333 _ _ _ _ a = a
church_case_333_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Bool
church_case_333_original = church_case_333

-- containsNone: total
church_case_334 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> church5 -> church5
church_case_334 _ _ _ _ a = a
church_case_334_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Bool
church_case_334_original = church_case_334

-- containsOnly: total
church_case_335 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> church5 -> church5
church_case_335 _ _ _ _ a = a
church_case_335_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Bool
church_case_335_original = church_case_335

-- unique: total
church_case_336 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_336 _ _ _ a = a
church_case_336_original :: forall a. Equal a -> List a -> List a
church_case_336_original = church_case_336

-- isPrefix: total
church_case_337 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> church5 -> church5
church_case_337 _ _ _ _ a = a
church_case_337_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Bool
church_case_337_original = church_case_337

-- isSuffix: total
church_case_338 :: forall church0 church1. (church0 -> church1 -> forall church2. church2 -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> (forall church4. (church1 -> church4 -> church4) -> church4 -> church4) -> forall church5. church5 -> church5 -> church5
church_case_338 _ _ _ _ a = a
church_case_338_original :: forall a b. (a -> b -> Bool) -> List a -> List b -> Bool
church_case_338_original = church_case_338

-- compareThreeWay: needs_int_provider
church_case_339 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> Int
church_case_339 _ _ _ = churchZero
church_case_339_original :: forall a. LE a -> List a -> List a -> Int
church_case_339_original = church_case_339

-- lexLess: total
church_case_340 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> forall church4. church4 -> church4 -> church4
church_case_340 _ _ _ _ a = a
church_case_340_original :: forall a. LE a -> List a -> List a -> Bool
church_case_340_original = church_case_340

-- nextPermutationBy: total
church_case_341 :: forall church0. (church0 -> church0 -> forall church1. church1 -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church4. church4 -> ((forall church3. (church0 -> church3 -> church3) -> church3 -> church3) -> church4) -> church4
church_case_341 _ _ a _ = a
church_case_341_original :: forall a. LE a -> List a -> Maybe (List a)
church_case_341_original = church_case_341

-- associationThread: total
church_case_342 :: forall church0 church1. (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> (forall church3. (church1 -> church3 -> church3) -> church3 -> church3) -> forall church5. ((forall church4. (church0 -> church1 -> church4) -> church4) -> church5 -> church5) -> church5 -> church5
church_case_342 _ _ _ a = a
church_case_342_original :: forall k v. List k -> List v -> Dict k v
church_case_342_original = church_case_342

-- assocInsert: total
church_case_343 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> church0 -> church1 -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_343 _ _ _ _ _ a = a
church_case_343_original :: forall k v. Equal k -> k -> v -> Dict k v -> Dict k v
church_case_343_original = church_case_343

-- assocDelete: total
church_case_344 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> church0 -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_344 _ _ _ _ a = a
church_case_344_original :: forall k v. Equal k -> k -> Dict k v -> Dict k v
church_case_344_original = church_case_344

-- insertOrAssign: total
church_case_345 :: forall church0 church1. (church0 -> church0 -> forall church2. church2 -> church2 -> church2) -> church0 -> church1 -> (forall church4. ((forall church3. (church0 -> church1 -> church3) -> church3) -> church4 -> church4) -> church4 -> church4) -> forall church6. ((forall church5. (church0 -> church1 -> church5) -> church5) -> church6 -> church6) -> church6 -> church6
church_case_345 _ _ _ _ _ a = a
church_case_345_original :: forall k v. Equal k -> k -> v -> Dict k v -> Dict k v
church_case_345_original = church_case_345

-- interleave: total
church_case_346 :: forall church0. church0 -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church3. ((forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> church3 -> church3) -> church3 -> church3
church_case_346 _ _ _ a = a
church_case_346_original :: forall a. a -> List a -> List (List a)
church_case_346_original = church_case_346

-- go: total
church_case_347 :: forall church0. Int -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_347 _ _ _ a = a
church_case_347_original :: forall a. Int -> List a -> List a
church_case_347_original = church_case_347

-- introselect: total
church_case_348 :: forall church0. Int -> Int -> (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> forall church2. (church0 -> church2 -> church2) -> church2 -> church2
church_case_348 _ _ _ _ a = a
church_case_348_original :: forall a. Int -> Int -> List a -> List a
church_case_348_original = church_case_348

-- go: total
church_case_349 :: forall church0. (forall church1. (church0 -> church1 -> church1) -> church1 -> church1) -> (forall church2. (church0 -> church2 -> church2) -> church2 -> church2) -> forall church3. (church0 -> church3 -> church3) -> church3 -> church3
church_case_349 _ _ _ a = a
church_case_349_original :: forall a. List a -> List a -> List a
church_case_349_original = church_case_349

