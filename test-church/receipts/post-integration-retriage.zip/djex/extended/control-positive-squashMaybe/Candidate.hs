{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (generated) where
import Prelude (Int)
import qualified Prelude (Int)
generated :: (forall church0. ((forall church2. (church2 -> (((forall church1. (church1 -> ((church0 -> church1) -> church1))) -> church2) -> church2))) -> (forall church3. (church3 -> ((church0 -> church3) -> church3)))))
generated = \mm zero some -> mm zero (\m -> m zero some)
