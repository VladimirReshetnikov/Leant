{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (generated) where
import Prelude (Int)
import qualified Prelude (Int)
generated :: (forall church0 church1 church2. ((church0 -> church1) -> ((church2 -> church1) -> ((forall church3. ((church0 -> church3) -> ((church2 -> church3) -> church3))) -> church1))))
generated = \onLeft onRight e -> e onLeft onRight
