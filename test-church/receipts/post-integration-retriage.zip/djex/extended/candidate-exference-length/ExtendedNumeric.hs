module ExtendedNumeric (numericZero, numericSuccessor) where
numericZero :: Int
numericZero = 0
numericSuccessor :: Int -> Int
numericSuccessor n = n + 1
