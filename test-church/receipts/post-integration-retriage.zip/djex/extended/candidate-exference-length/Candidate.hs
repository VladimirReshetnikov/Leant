{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (extended_exference_length) where
import Prelude (Int)
import qualified Prelude (Int)
import ExtendedNumeric (numericZero, numericSuccessor)
extended_exference_length :: (forall church0. ((forall church1. ((church0 -> (church1 -> church1)) -> (church1 -> church1))) -> Int))
extended_exference_length f1 =
  f1
  (\_ -> ExtendedNumeric.numericSuccessor)
  ExtendedNumeric.numericZero
