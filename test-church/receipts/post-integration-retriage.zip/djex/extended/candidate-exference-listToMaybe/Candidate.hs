{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (extended_exference_listToMaybe) where
import Prelude (Int)
import qualified Prelude (Int)
extended_exference_listToMaybe :: (forall church0. ((forall church1. ((church0 -> (church1 -> church1)) -> (church1 -> church1))) -> (forall church2. (church2 -> ((church0 -> church2) -> church2)))))
extended_exference_listToMaybe f1 c f4 = f1 (\h -> \_ -> f4 h) c
