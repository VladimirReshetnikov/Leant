{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (extended_exference_maybeEither) where
import Prelude (Int)
import qualified Prelude (Int)
extended_exference_maybeEither :: (forall church0 church1. ((forall church4. (((forall church2. (church2 -> ((church0 -> church2) -> church2))) -> church4) -> (((forall church3. (church3 -> ((church1 -> church3) -> church3))) -> church4) -> church4))) -> (forall church6. (church6 -> (((forall church5. ((church0 -> church5) -> ((church1 -> church5) -> church5))) -> church6) -> church6)))))
extended_exference_maybeEither f1 c f4 =
  f1
  (\f8 -> f8 c (\l -> f4 (\f15 -> \_ -> f15 l)))
  (\f19 -> f19 c (\w -> f4 (\_ -> \f27 -> f27 w)))
