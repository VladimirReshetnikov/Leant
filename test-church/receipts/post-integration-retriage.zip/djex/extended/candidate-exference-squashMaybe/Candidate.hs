{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (extended_exference_squashMaybe) where
import Prelude (Int)
import qualified Prelude (Int)
extended_exference_squashMaybe :: (forall church0. ((forall church2. (church2 -> (((forall church1. (church1 -> ((church0 -> church1) -> church1))) -> church2) -> church2))) -> (forall church3. (church3 -> ((church0 -> church3) -> church3)))))
extended_exference_squashMaybe f1 c f4 = f1 c (\f8 -> f8 c f4)
