set_option linter.unusedVariables false
universe u v
abbrev BehaviorExtended.CList (A : Type u) := ∀ R : Type, (A → R → R) → R → R
abbrev BehaviorExtended.CMaybe (A : Type u) := ∀ R : Type, R → (A → R) → R
abbrev BehaviorExtended.CEither (A : Type u) (B : Type v) := ∀ R : Type, (A → R) → (B → R) → R
abbrev BehaviorExtended.CNum := (∀ R : Type, (R → R) → R → R)
def BehaviorExtended.enc {A : Type} (xs : List A) : BehaviorExtended.CList A := fun _ step zero => xs.foldr step zero
def BehaviorExtended.dec {A : Type} (xs : BehaviorExtended.CList A) : List A := xs (List A) List.cons []
def BehaviorExtended.encMaybe {A : Type} (m : Option A) : BehaviorExtended.CMaybe A := fun _ zero some => m.elim zero some
def BehaviorExtended.decMaybe {A : Type} (m : BehaviorExtended.CMaybe A) : Option A := m (Option A) none some
def BehaviorExtended.encEither {A B : Type} (e : Sum A B) : BehaviorExtended.CEither A B := fun _ onLeft onRight => e.elim onLeft onRight
def BehaviorExtended.encMaybes {A : Type} (xs : List (Option A)) : BehaviorExtended.CList (BehaviorExtended.CMaybe A) := fun _ step zero => xs.foldr (fun m rest => step (BehaviorExtended.encMaybe m) rest) zero
def BehaviorExtended.encNestedMaybe {A : Type} (mm : Option (Option A)) : BehaviorExtended.CMaybe (BehaviorExtended.CMaybe A) := fun _ zero some => mm.elim zero (fun m => some (BehaviorExtended.encMaybe m))
def BehaviorExtended.encMaybeEither {A B : Type} (e : Sum (Option A) (Option B)) : BehaviorExtended.CEither (BehaviorExtended.CMaybe A) (BehaviorExtended.CMaybe B) := fun _ onLeft onRight => e.elim (fun m => onLeft (BehaviorExtended.encMaybe m)) (fun m => onRight (BehaviorExtended.encMaybe m))
def BehaviorExtended.decMaybeEither {A B : Type} (m : BehaviorExtended.CMaybe (BehaviorExtended.CEither A B)) : Option (Sum A B) := m (Option (Sum A B)) none (fun e => some (e (Sum A B) Sum.inl Sum.inr))
def BehaviorExtended.encNum (n : Nat) : BehaviorExtended.CNum := fun _ step zero => Nat.rec zero (fun _ acc => step acc) n
def BehaviorExtended.decNum (n : BehaviorExtended.CNum) : Nat := n Nat Nat.succ 0
def BehaviorExtended.inputs : List (List Int) := [[], [-1], [0], [2], [-1, -1], [-1, 0], [-1, 2], [0, -1], [0, 0], [0, 2], [2, -1], [2, 0], [2, 2], [-1, -1, -1], [-1, -1, 0], [-1, -1, 2], [-1, 0, -1], [-1, 0, 0], [-1, 0, 2], [-1, 2, -1], [-1, 2, 0], [-1, 2, 2], [0, -1, -1], [0, -1, 0], [0, -1, 2], [0, 0, -1], [0, 0, 0], [0, 0, 2], [0, 2, -1], [0, 2, 0], [0, 2, 2], [2, -1, -1], [2, -1, 0], [2, -1, 2], [2, 0, -1], [2, 0, 0], [2, 0, 2], [2, 2, -1], [2, 2, 0], [2, 2, 2]]
def BehaviorExtended.boolInputs : List (List Bool) := [[],[false],[true],[true,false]]
def BehaviorExtended.maybeInputs : List (Option Int) := [none,some (-1),some 0,some 2]
def BehaviorExtended.maybeBools : List (Option Bool) := [none,some false,some true]
def BehaviorExtended.maybeLists : List (List (Option Int)) := [[],[none],[some (-1)],[some (2)],[none,none],[none,some (-1)],[none,some (2)],[some (-1),none],[some (-1),some (-1)],[some (-1),some (2)],[some (2),none],[some (2),some (-1)],[some (2),some (2)],[none,none,none],[none,none,some (-1)],[none,none,some (2)],[none,some (-1),none],[none,some (-1),some (-1)],[none,some (-1),some (2)],[none,some (2),none],[none,some (2),some (-1)],[none,some (2),some (2)],[some (-1),none,none],[some (-1),none,some (-1)],[some (-1),none,some (2)],[some (-1),some (-1),none],[some (-1),some (-1),some (-1)],[some (-1),some (-1),some (2)],[some (-1),some (2),none],[some (-1),some (2),some (-1)],[some (-1),some (2),some (2)],[some (2),none,none],[some (2),none,some (-1)],[some (2),none,some (2)],[some (2),some (-1),none],[some (2),some (-1),some (-1)],[some (2),some (-1),some (2)],[some (2),some (2),none],[some (2),some (2),some (-1)],[some (2),some (2),some (2)]]
def BehaviorExtended.nestedMaybes : List (Option (Option Int)) := none :: BehaviorExtended.maybeInputs.map some
def BehaviorExtended.nestedBools : List (Option (Option Bool)) := [none,some none,some (some true)]
def BehaviorExtended.eitherInputs : List (Sum Int Bool) := ([-1,0,2] : List Int).map Sum.inl ++ [false,true].map Sum.inr
def BehaviorExtended.maybeEitherInputs : List (Sum (Option Int) (Option Bool)) := BehaviorExtended.maybeInputs.map Sum.inl ++ BehaviorExtended.maybeBools.map Sum.inr
def BehaviorExtended.foldSteps : List (Int → Int → Int) := [(fun x y => x-y),(fun x y => 2*x+y),(fun x y => x+3*y)]
def BehaviorExtended.check_foldr (f : (∀ (church0 : Type) (church1 : Type), ((church0 → (church1 → church1)) → (church1 → ((∀ (church2 : Type), ((church0 → (church2 → church2)) → (church2 → church2))) → church1))))) : Bool := BehaviorExtended.inputs.all (fun xs => BehaviorExtended.foldSteps.all (fun g => ([-2,0,3] : List Int).all (fun z => f Int Int g z (BehaviorExtended.enc xs) == xs.foldr g z))) && BehaviorExtended.inputs.all (fun xs => f Int (List Int) List.cons [] (BehaviorExtended.enc xs) == xs)
def BehaviorExtended.check_foldl (f : (∀ (church0 : Type) (church1 : Type), ((church0 → (church1 → church0)) → (church0 → ((∀ (church2 : Type), ((church1 → (church2 → church2)) → (church2 → church2))) → church0))))) : Bool := BehaviorExtended.inputs.all (fun xs => BehaviorExtended.foldSteps.all (fun g => ([-2,0,3] : List Int).all (fun z => f Int Int g z (BehaviorExtended.enc xs) == xs.foldl g z))) && BehaviorExtended.inputs.all (fun xs => f (List Int) Int (fun acc x => x :: acc) [] (BehaviorExtended.enc xs) == xs.reverse)
def BehaviorExtended.check_length (f : (∀ (church0 : Type), ((∀ (church1 : Type), ((church0 → (church1 → church1)) → (church1 → church1))) → Int))) : Bool := BehaviorExtended.inputs.all (fun xs => f Int (BehaviorExtended.enc xs) == Int.ofNat xs.length) && BehaviorExtended.boolInputs.all (fun xs => f Bool (BehaviorExtended.enc xs) == Int.ofNat xs.length)
def BehaviorExtended.check_fromMaybe (f : (∀ (church0 : Type), (church0 → ((∀ (church1 : Type), (church1 → ((church0 → church1) → church1))) → church0)))) : Bool := ([-2,0,3] : List Int).all (fun d => BehaviorExtended.maybeInputs.all (fun m => f Int d (BehaviorExtended.encMaybe m) == m.getD d)) && [false,true].all (fun d => BehaviorExtended.maybeBools.all (fun m => f Bool d (BehaviorExtended.encMaybe m) == m.getD d))
def BehaviorExtended.check_maybeToList (f : (∀ (church0 : Type), ((∀ (church1 : Type), (church1 → ((church0 → church1) → church1))) → (∀ (church2 : Type), ((church0 → (church2 → church2)) → (church2 → church2)))))) : Bool := BehaviorExtended.maybeInputs.all (fun m => BehaviorExtended.dec (f Int (BehaviorExtended.encMaybe m)) == m.elim [] (fun x => [x])) && BehaviorExtended.maybeBools.all (fun m => BehaviorExtended.dec (f Bool (BehaviorExtended.encMaybe m)) == m.elim [] (fun x => [x]))
def BehaviorExtended.check_listToMaybe (f : (∀ (church0 : Type), ((∀ (church1 : Type), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type), (church2 → ((church0 → church2) → church2)))))) : Bool := BehaviorExtended.inputs.all (fun xs => BehaviorExtended.decMaybe (f Int (BehaviorExtended.enc xs)) == xs.head?) && BehaviorExtended.boolInputs.all (fun xs => BehaviorExtended.decMaybe (f Bool (BehaviorExtended.enc xs)) == xs.head?)
def BehaviorExtended.check_catMaybes (f : (∀ (church0 : Type), ((∀ (church2 : Type), (((∀ (church1 : Type), (church1 → ((church0 → church1) → church1))) → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type), ((church0 → (church3 → church3)) → (church3 → church3)))))) : Bool := BehaviorExtended.maybeLists.all (fun xs => BehaviorExtended.dec (f Int (BehaviorExtended.encMaybes xs)) == xs.filterMap id)
def BehaviorExtended.check_squashMaybe (f : (∀ (church0 : Type), ((∀ (church2 : Type), (church2 → (((∀ (church1 : Type), (church1 → ((church0 → church1) → church1))) → church2) → church2))) → (∀ (church3 : Type), (church3 → ((church0 → church3) → church3)))))) : Bool := BehaviorExtended.nestedMaybes.all (fun mm => BehaviorExtended.decMaybe (f Int (BehaviorExtended.encNestedMaybe mm)) == mm.elim none id) && BehaviorExtended.nestedBools.all (fun mm => BehaviorExtended.decMaybe (f Bool (BehaviorExtended.encNestedMaybe mm)) == mm.elim none id)
def BehaviorExtended.check_isLeft (f : (∀ (church0 : Type) (church1 : Type), ((∀ (church2 : Type), ((church0 → church2) → ((church1 → church2) → church2))) → (∀ (church3 : Type), (church3 → (church3 → church3)))))) : Bool := BehaviorExtended.eitherInputs.all (fun e => f Int Bool (BehaviorExtended.encEither e) Bool true false == e.elim (fun _ => true) (fun _ => false)) && BehaviorExtended.eitherInputs.all (fun e => f Bool Int (BehaviorExtended.encEither (e.elim Sum.inr Sum.inl)) Bool true false == e.elim (fun _ => false) (fun _ => true))
def BehaviorExtended.check_maybeEither (f : (∀ (church0 : Type) (church1 : Type), ((∀ (church4 : Type), (((∀ (church2 : Type), (church2 → ((church0 → church2) → church2))) → church4) → (((∀ (church3 : Type), (church3 → ((church1 → church3) → church3))) → church4) → church4))) → (∀ (church6 : Type), (church6 → (((∀ (church5 : Type), ((church0 → church5) → ((church1 → church5) → church5))) → church6) → church6)))))) : Bool := BehaviorExtended.maybeEitherInputs.all (fun e => BehaviorExtended.decMaybeEither (f Int Bool (BehaviorExtended.encMaybeEither e)) == e.elim (fun m => m.map Sum.inl) (fun m => m.map Sum.inr))
def BehaviorExtended.check_either (f : (∀ (church0 : Type) (church1 : Type) (church2 : Type), ((church0 → church1) → ((church2 → church1) → ((∀ (church3 : Type), ((church0 → church3) → ((church2 → church3) → church3))) → church1))))) : Bool := BehaviorExtended.eitherInputs.all (fun e => ([(fun x => x+7),(fun x => 3*x)] : List (Int → Int)).all (fun g => f Int Int Bool g (fun flag => if flag then 19 else -4) (BehaviorExtended.encEither e) == e.elim g (fun flag => if flag then 19 else -4))) && BehaviorExtended.eitherInputs.all (fun e => f Int Bool Bool (fun x => decide (x ≥ 0)) Bool.not (BehaviorExtended.encEither e) == e.elim (fun x => decide (x ≥ 0)) Bool.not)
def BehaviorExtended.check_numeralSuccessor (f : (∀ R : Type, (R → R) → R → R) → (∀ R : Type, (R → R) → R → R)) : Bool := ([0,1,2,3,4] : List Nat).all (fun n => BehaviorExtended.decNum (f (BehaviorExtended.encNum n)) == n+1) && ([0,1,2,3,4] : List Nat).all (fun n => [false,true].all (fun flag => f (BehaviorExtended.encNum n) Bool Bool.not flag == BehaviorExtended.encNum (n+1) Bool Bool.not flag))
def BehaviorExtended.check_numeralAdd (f : (∀ R : Type, (R → R) → R → R) → (∀ R : Type, (R → R) → R → R) → (∀ R : Type, (R → R) → R → R)) : Bool := ([0,1,2,3,4] : List Nat).all (fun n => ([0,1,2,3,4] : List Nat).all (fun m => BehaviorExtended.decNum (f (BehaviorExtended.encNum n) (BehaviorExtended.encNum m)) == n+m)) && ([0,1,2,3,4] : List Nat).all (fun n => ([0,1,2,3,4] : List Nat).all (fun m => [false,true].all (fun flag => f (BehaviorExtended.encNum n) (BehaviorExtended.encNum m) Bool Bool.not flag == BehaviorExtended.encNum (n+m) Bool Bool.not flag)))
def BehaviorExtendedNumeric.zero : Int := 0
def BehaviorExtendedNumeric.successor (n : Int) : Int := n + 1
def BehaviorExtendedControl.witness_foldr : (∀ (church0 : Type) (church1 : Type), ((church0 → (church1 → church1)) → (church1 → ((∀ (church2 : Type), ((church0 → (church2 → church2)) → (church2 → church2))) → church1)))) := fun _ _ step zero xs => xs _ step zero
theorem BehaviorExtendedControl.witness_foldr_passes : BehaviorExtended.check_foldr BehaviorExtendedControl.witness_foldr = true := by decide
def BehaviorExtendedControl.witness_foldl : (∀ (church0 : Type) (church1 : Type), ((church0 → (church1 → church0)) → (church0 → ((∀ (church2 : Type), ((church1 → (church2 → church2)) → (church2 → church2))) → church0)))) := fun B _ step zero xs => xs (B → B) (fun x k acc => k (step acc x)) (fun x => x) zero
theorem BehaviorExtendedControl.witness_foldl_passes : BehaviorExtended.check_foldl BehaviorExtendedControl.witness_foldl = true := by decide
def BehaviorExtendedControl.witness_length : (∀ (church0 : Type), ((∀ (church1 : Type), ((church0 → (church1 → church1)) → (church1 → church1))) → Int)) := fun _ xs => xs Int (fun _ n => BehaviorExtendedNumeric.successor n) BehaviorExtendedNumeric.zero
theorem BehaviorExtendedControl.witness_length_passes : BehaviorExtended.check_length BehaviorExtendedControl.witness_length = true := by decide
def BehaviorExtendedControl.witness_fromMaybe : (∀ (church0 : Type), (church0 → ((∀ (church1 : Type), (church1 → ((church0 → church1) → church1))) → church0))) := fun A zero m => m A zero (fun x => x)
theorem BehaviorExtendedControl.witness_fromMaybe_passes : BehaviorExtended.check_fromMaybe BehaviorExtendedControl.witness_fromMaybe = true := by decide
def BehaviorExtendedControl.witness_maybeToList : (∀ (church0 : Type), ((∀ (church1 : Type), (church1 → ((church0 → church1) → church1))) → (∀ (church2 : Type), ((church0 → (church2 → church2)) → (church2 → church2))))) := fun _ m R step zero => m R zero (fun x => step x zero)
theorem BehaviorExtendedControl.witness_maybeToList_passes : BehaviorExtended.check_maybeToList BehaviorExtendedControl.witness_maybeToList = true := by decide
def BehaviorExtendedControl.witness_listToMaybe : (∀ (church0 : Type), ((∀ (church1 : Type), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type), (church2 → ((church0 → church2) → church2))))) := fun _ xs R zero some => xs R (fun x _ => some x) zero
theorem BehaviorExtendedControl.witness_listToMaybe_passes : BehaviorExtended.check_listToMaybe BehaviorExtendedControl.witness_listToMaybe = true := by decide
def BehaviorExtendedControl.witness_catMaybes : (∀ (church0 : Type), ((∀ (church2 : Type), (((∀ (church1 : Type), (church1 → ((church0 → church1) → church1))) → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type), ((church0 → (church3 → church3)) → (church3 → church3))))) := fun _ xs R step zero => xs R (fun m rest => m R rest (fun x => step x rest)) zero
theorem BehaviorExtendedControl.witness_catMaybes_passes : BehaviorExtended.check_catMaybes BehaviorExtendedControl.witness_catMaybes = true := by decide
def BehaviorExtendedControl.witness_squashMaybe : (∀ (church0 : Type), ((∀ (church2 : Type), (church2 → (((∀ (church1 : Type), (church1 → ((church0 → church1) → church1))) → church2) → church2))) → (∀ (church3 : Type), (church3 → ((church0 → church3) → church3))))) := fun _ mm R zero some => mm R zero (fun m => m R zero some)
theorem BehaviorExtendedControl.witness_squashMaybe_passes : BehaviorExtended.check_squashMaybe BehaviorExtendedControl.witness_squashMaybe = true := by decide
def BehaviorExtendedControl.witness_isLeft : (∀ (church0 : Type) (church1 : Type), ((∀ (church2 : Type), ((church0 → church2) → ((church1 → church2) → church2))) → (∀ (church3 : Type), (church3 → (church3 → church3))))) := fun _ _ e R yes no => e R (fun _ => yes) (fun _ => no)
theorem BehaviorExtendedControl.witness_isLeft_passes : BehaviorExtended.check_isLeft BehaviorExtendedControl.witness_isLeft = true := by decide
def BehaviorExtendedControl.witness_maybeEither : (∀ (church0 : Type) (church1 : Type), ((∀ (church4 : Type), (((∀ (church2 : Type), (church2 → ((church0 → church2) → church2))) → church4) → (((∀ (church3 : Type), (church3 → ((church1 → church3) → church3))) → church4) → church4))) → (∀ (church6 : Type), (church6 → (((∀ (church5 : Type), ((church0 → church5) → ((church1 → church5) → church5))) → church6) → church6))))) := fun _ _ e R zero some => e R (fun m => m R zero (fun x => some (fun _ onLeft _ => onLeft x))) (fun m => m R zero (fun y => some (fun _ _ onRight => onRight y)))
theorem BehaviorExtendedControl.witness_maybeEither_passes : BehaviorExtended.check_maybeEither BehaviorExtendedControl.witness_maybeEither = true := by decide
def BehaviorExtendedControl.witness_either : (∀ (church0 : Type) (church1 : Type) (church2 : Type), ((church0 → church1) → ((church2 → church1) → ((∀ (church3 : Type), ((church0 → church3) → ((church2 → church3) → church3))) → church1)))) := fun _ C _ onLeft onRight e => e C onLeft onRight
theorem BehaviorExtendedControl.witness_either_passes : BehaviorExtended.check_either BehaviorExtendedControl.witness_either = true := by decide
def BehaviorExtendedControl.witness_numeralSuccessor : (∀ R : Type, (R → R) → R → R) → (∀ R : Type, (R → R) → R → R) := fun n R step zero => step (n R step zero)
theorem BehaviorExtendedControl.witness_numeralSuccessor_passes : BehaviorExtended.check_numeralSuccessor BehaviorExtendedControl.witness_numeralSuccessor = true := by decide
def BehaviorExtendedControl.witness_numeralAdd : (∀ R : Type, (R → R) → R → R) → (∀ R : Type, (R → R) → R → R) → (∀ R : Type, (R → R) → R → R) := fun n m R step zero => n R step (m R step zero)
theorem BehaviorExtendedControl.witness_numeralAdd_passes : BehaviorExtended.check_numeralAdd BehaviorExtendedControl.witness_numeralAdd = true := by decide
def BehaviorExtendedControl.wrong_foldr_seed : (∀ (church0 : Type) (church1 : Type), ((church0 → (church1 → church1)) → (church1 → ((∀ (church2 : Type), ((church0 → (church2 → church2)) → (church2 → church2))) → church1)))) := fun _ _ _ zero _ => zero
theorem BehaviorExtendedControl.wrong_foldr_seed_rejected : BehaviorExtended.check_foldr BehaviorExtendedControl.wrong_foldr_seed = false := by decide
def BehaviorExtendedControl.wrong_foldr_reversed : (∀ (church0 : Type) (church1 : Type), ((church0 → (church1 → church1)) → (church1 → ((∀ (church2 : Type), ((church0 → (church2 → church2)) → (church2 → church2))) → church1)))) := fun _ B step zero xs => xs (B → B) (fun x k acc => k (step x acc)) (fun x => x) zero
theorem BehaviorExtendedControl.wrong_foldr_reversed_rejected : BehaviorExtended.check_foldr BehaviorExtendedControl.wrong_foldr_reversed = false := by decide
def BehaviorExtendedControl.wrong_foldl_seed : (∀ (church0 : Type) (church1 : Type), ((church0 → (church1 → church0)) → (church0 → ((∀ (church2 : Type), ((church1 → (church2 → church2)) → (church2 → church2))) → church0)))) := fun _ _ _ zero _ => zero
theorem BehaviorExtendedControl.wrong_foldl_seed_rejected : BehaviorExtended.check_foldl BehaviorExtendedControl.wrong_foldl_seed = false := by decide
def BehaviorExtendedControl.wrong_foldl_reversed : (∀ (church0 : Type) (church1 : Type), ((church0 → (church1 → church0)) → (church0 → ((∀ (church2 : Type), ((church1 → (church2 → church2)) → (church2 → church2))) → church0)))) := fun B _ step zero xs => xs B (fun x rest => step rest x) zero
theorem BehaviorExtendedControl.wrong_foldl_reversed_rejected : BehaviorExtended.check_foldl BehaviorExtendedControl.wrong_foldl_reversed = false := by decide
def BehaviorExtendedControl.wrong_length_zero : (∀ (church0 : Type), ((∀ (church1 : Type), ((church0 → (church1 → church1)) → (church1 → church1))) → Int)) := fun _ _ => BehaviorExtendedNumeric.zero
theorem BehaviorExtendedControl.wrong_length_zero_rejected : BehaviorExtended.check_length BehaviorExtendedControl.wrong_length_zero = false := by decide
def BehaviorExtendedControl.wrong_fromMaybe_default : (∀ (church0 : Type), (church0 → ((∀ (church1 : Type), (church1 → ((church0 → church1) → church1))) → church0))) := fun _ zero _ => zero
theorem BehaviorExtendedControl.wrong_fromMaybe_default_rejected : BehaviorExtended.check_fromMaybe BehaviorExtendedControl.wrong_fromMaybe_default = false := by decide
def BehaviorExtendedControl.wrong_maybeToList_empty : (∀ (church0 : Type), ((∀ (church1 : Type), (church1 → ((church0 → church1) → church1))) → (∀ (church2 : Type), ((church0 → (church2 → church2)) → (church2 → church2))))) := fun _ _ _ _ zero => zero
theorem BehaviorExtendedControl.wrong_maybeToList_empty_rejected : BehaviorExtended.check_maybeToList BehaviorExtendedControl.wrong_maybeToList_empty = false := by decide
def BehaviorExtendedControl.wrong_listToMaybe_nothing : (∀ (church0 : Type), ((∀ (church1 : Type), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type), (church2 → ((church0 → church2) → church2))))) := fun _ _ _ zero _ => zero
theorem BehaviorExtendedControl.wrong_listToMaybe_nothing_rejected : BehaviorExtended.check_listToMaybe BehaviorExtendedControl.wrong_listToMaybe_nothing = false := by decide
def BehaviorExtendedControl.wrong_catMaybes_empty : (∀ (church0 : Type), ((∀ (church2 : Type), (((∀ (church1 : Type), (church1 → ((church0 → church1) → church1))) → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type), ((church0 → (church3 → church3)) → (church3 → church3))))) := fun _ _ _ _ zero => zero
theorem BehaviorExtendedControl.wrong_catMaybes_empty_rejected : BehaviorExtended.check_catMaybes BehaviorExtendedControl.wrong_catMaybes_empty = false := by decide
def BehaviorExtendedControl.wrong_squashMaybe_nothing : (∀ (church0 : Type), ((∀ (church2 : Type), (church2 → (((∀ (church1 : Type), (church1 → ((church0 → church1) → church1))) → church2) → church2))) → (∀ (church3 : Type), (church3 → ((church0 → church3) → church3))))) := fun _ _ _ zero _ => zero
theorem BehaviorExtendedControl.wrong_squashMaybe_nothing_rejected : BehaviorExtended.check_squashMaybe BehaviorExtendedControl.wrong_squashMaybe_nothing = false := by decide
def BehaviorExtendedControl.wrong_isLeft_negated : (∀ (church0 : Type) (church1 : Type), ((∀ (church2 : Type), ((church0 → church2) → ((church1 → church2) → church2))) → (∀ (church3 : Type), (church3 → (church3 → church3))))) := fun _ _ e R yes no => e R (fun _ => no) (fun _ => yes)
theorem BehaviorExtendedControl.wrong_isLeft_negated_rejected : BehaviorExtended.check_isLeft BehaviorExtendedControl.wrong_isLeft_negated = false := by decide
def BehaviorExtendedControl.wrong_maybeEither_nothing : (∀ (church0 : Type) (church1 : Type), ((∀ (church4 : Type), (((∀ (church2 : Type), (church2 → ((church0 → church2) → church2))) → church4) → (((∀ (church3 : Type), (church3 → ((church1 → church3) → church3))) → church4) → church4))) → (∀ (church6 : Type), (church6 → (((∀ (church5 : Type), ((church0 → church5) → ((church1 → church5) → church5))) → church6) → church6))))) := fun _ _ _ _ zero _ => zero
theorem BehaviorExtendedControl.wrong_maybeEither_nothing_rejected : BehaviorExtended.check_maybeEither BehaviorExtendedControl.wrong_maybeEither_nothing = false := by decide
def BehaviorExtendedControl.wrong_successor_identity : (∀ R : Type, (R → R) → R → R) → (∀ R : Type, (R → R) → R → R) := fun n => n
theorem BehaviorExtendedControl.wrong_successor_identity_rejected : BehaviorExtended.check_numeralSuccessor BehaviorExtendedControl.wrong_successor_identity = false := by decide
def BehaviorExtendedControl.wrong_add_first : (∀ R : Type, (R → R) → R → R) → (∀ R : Type, (R → R) → R → R) → (∀ R : Type, (R → R) → R → R) := fun n _ => n
theorem BehaviorExtendedControl.wrong_add_first_rejected : BehaviorExtended.check_numeralAdd BehaviorExtendedControl.wrong_add_first = false := by decide
def BehaviorExtendedControl.eitherMono (onLeft _ : Int → Int) (e : BehaviorExtended.CEither Int Int) : Int := e Int onLeft onLeft
theorem BehaviorExtendedControl.either_specialized_wrong_handler : (BehaviorExtendedControl.eitherMono (fun x => x+7) (fun x => 3*x) (fun _ _ onRight => onRight 2) == (6 : Int)) = false := by decide
#print axioms BehaviorExtendedNumeric.zero
#print axioms BehaviorExtendedNumeric.successor
#print axioms BehaviorExtendedControl.witness_foldr
#print axioms BehaviorExtendedControl.witness_foldr_passes
#print axioms BehaviorExtendedControl.witness_foldl
#print axioms BehaviorExtendedControl.witness_foldl_passes
#print axioms BehaviorExtendedControl.witness_length
#print axioms BehaviorExtendedControl.witness_length_passes
#print axioms BehaviorExtendedControl.witness_fromMaybe
#print axioms BehaviorExtendedControl.witness_fromMaybe_passes
#print axioms BehaviorExtendedControl.witness_maybeToList
#print axioms BehaviorExtendedControl.witness_maybeToList_passes
#print axioms BehaviorExtendedControl.witness_listToMaybe
#print axioms BehaviorExtendedControl.witness_listToMaybe_passes
#print axioms BehaviorExtendedControl.witness_catMaybes
#print axioms BehaviorExtendedControl.witness_catMaybes_passes
#print axioms BehaviorExtendedControl.witness_squashMaybe
#print axioms BehaviorExtendedControl.witness_squashMaybe_passes
#print axioms BehaviorExtendedControl.witness_isLeft
#print axioms BehaviorExtendedControl.witness_isLeft_passes
#print axioms BehaviorExtendedControl.witness_maybeEither
#print axioms BehaviorExtendedControl.witness_maybeEither_passes
#print axioms BehaviorExtendedControl.witness_either
#print axioms BehaviorExtendedControl.witness_either_passes
#print axioms BehaviorExtendedControl.witness_numeralSuccessor
#print axioms BehaviorExtendedControl.witness_numeralSuccessor_passes
#print axioms BehaviorExtendedControl.witness_numeralAdd
#print axioms BehaviorExtendedControl.witness_numeralAdd_passes
#print axioms BehaviorExtendedControl.wrong_foldr_seed
#print axioms BehaviorExtendedControl.wrong_foldr_seed_rejected
#print axioms BehaviorExtendedControl.wrong_foldr_reversed
#print axioms BehaviorExtendedControl.wrong_foldr_reversed_rejected
#print axioms BehaviorExtendedControl.wrong_foldl_seed
#print axioms BehaviorExtendedControl.wrong_foldl_seed_rejected
#print axioms BehaviorExtendedControl.wrong_foldl_reversed
#print axioms BehaviorExtendedControl.wrong_foldl_reversed_rejected
#print axioms BehaviorExtendedControl.wrong_length_zero
#print axioms BehaviorExtendedControl.wrong_length_zero_rejected
#print axioms BehaviorExtendedControl.wrong_fromMaybe_default
#print axioms BehaviorExtendedControl.wrong_fromMaybe_default_rejected
#print axioms BehaviorExtendedControl.wrong_maybeToList_empty
#print axioms BehaviorExtendedControl.wrong_maybeToList_empty_rejected
#print axioms BehaviorExtendedControl.wrong_listToMaybe_nothing
#print axioms BehaviorExtendedControl.wrong_listToMaybe_nothing_rejected
#print axioms BehaviorExtendedControl.wrong_catMaybes_empty
#print axioms BehaviorExtendedControl.wrong_catMaybes_empty_rejected
#print axioms BehaviorExtendedControl.wrong_squashMaybe_nothing
#print axioms BehaviorExtendedControl.wrong_squashMaybe_nothing_rejected
#print axioms BehaviorExtendedControl.wrong_isLeft_negated
#print axioms BehaviorExtendedControl.wrong_isLeft_negated_rejected
#print axioms BehaviorExtendedControl.wrong_maybeEither_nothing
#print axioms BehaviorExtendedControl.wrong_maybeEither_nothing_rejected
#print axioms BehaviorExtendedControl.wrong_successor_identity
#print axioms BehaviorExtendedControl.wrong_successor_identity_rejected
#print axioms BehaviorExtendedControl.wrong_add_first
#print axioms BehaviorExtendedControl.wrong_add_first_rejected
#print axioms BehaviorExtendedControl.eitherMono
#print axioms BehaviorExtendedControl.either_specialized_wrong_handler
