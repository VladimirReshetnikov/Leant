set_option autoImplicit false
class ContextProduction.Dictionary (α : Type) where tag : Nat
structure ContextProduction.Token where payload : Nat
def ContextReplay.accepted : ∀ (α : Type), [ContextProduction.Dictionary α] → (∀ (β : Type), [ContextProduction.Dictionary β] → β → ContextProduction.Token) → α → ContextProduction.Token :=
((fun (leantType55 : Type) => (fun [leantGiven67x0 : @_root_.«ContextProduction».«Dictionary» (leantType55)] => (fun (leantLocal80 : (∀ (leantBound0x0 : Type) [@_root_.«ContextProduction».«Dictionary» (leantBound0x0)], (leantBound0x0 → @_root_.«ContextProduction».«Token»))) => @(let leantHead94 : (∀ [@_root_.«ContextProduction».«Dictionary» (leantType55)], (leantType55 → @_root_.«ContextProduction».«Token»)) := @(let leantHead109 : (∀ (leantBound0x0 : Type) [@_root_.«ContextProduction».«Dictionary» (leantBound0x0)], (leantBound0x0 → @_root_.«ContextProduction».«Token»)) := @leantLocal80; @leantHead109 (leantType55)); @leantHead94 leantGiven67x0)))) : (∀ (leantBound0x0 : Type) [@_root_.«ContextProduction».«Dictionary» (leantBound0x0)], ((∀ (leantBound1x0 : Type) [@_root_.«ContextProduction».«Dictionary» (leantBound1x0)], (leantBound1x0 → @_root_.«ContextProduction».«Token»)) → (leantBound0x0 → @_root_.«ContextProduction».«Token»))))
theorem ContextReplay.accepted_passes : (ContextProduction.Token.payload (@ContextReplay.accepted Nat (@ContextProduction.Dictionary.mk Nat 7) (fun (β : Type) [d : ContextProduction.Dictionary β] (_ : β) => ContextProduction.Token.mk ((@ContextProduction.Dictionary.tag β d) + 0)) 37) = 7) ∧ (ContextProduction.Token.payload (@ContextReplay.accepted Nat (@ContextProduction.Dictionary.mk Nat 11) (fun (β : Type) [d : ContextProduction.Dictionary β] (_ : β) => ContextProduction.Token.mk ((@ContextProduction.Dictionary.tag β d) + 0)) 37) = 11) ∧ (ContextProduction.Token.payload (@ContextReplay.accepted Nat (@ContextProduction.Dictionary.mk Nat 7) (fun (β : Type) [d : ContextProduction.Dictionary β] (_ : β) => ContextProduction.Token.mk ((@ContextProduction.Dictionary.tag β d) + 100)) 53) = 107) ∧ (ContextProduction.Token.payload (@ContextReplay.accepted Bool (@ContextProduction.Dictionary.mk Bool 11) (fun (β : Type) [d : ContextProduction.Dictionary β] (_ : β) => ContextProduction.Token.mk ((@ContextProduction.Dictionary.tag β d) + 100)) true) = 111) := by decide
#print axioms ContextProduction.Dictionary
#print axioms ContextProduction.Dictionary.mk
#print axioms ContextProduction.Dictionary.tag
#print axioms ContextProduction.Token
#print axioms ContextProduction.Token.mk
#print axioms ContextProduction.Token.payload
#print axioms ContextReplay.accepted
#print axioms ContextReplay.accepted_passes
