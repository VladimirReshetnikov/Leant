set_option autoImplicit false
class ContextProduction.Dictionary (α : Type) where tag : Nat
structure ContextProduction.Token where payload : Nat
def ContextReplay.accepted : ∀ (α : Type), [ContextProduction.Dictionary α] → α → α :=
((fun (leantType21 : Type) => (fun [leantGiven29x0 : @_root_.«ContextProduction».«Dictionary» (leantType21)] => (fun (leantLocal38 : leantType21) => @leantLocal38))) : (∀ (leantBound0x0 : Type) [@_root_.«ContextProduction».«Dictionary» (leantBound0x0)], (leantBound0x0 → leantBound0x0)))
theorem ContextReplay.accepted_passes : (@ContextReplay.accepted Nat (@ContextProduction.Dictionary.mk Nat 7) 37 = 37) ∧ (@ContextReplay.accepted Nat (@ContextProduction.Dictionary.mk Nat 11) 53 = 53) ∧ (@ContextReplay.accepted Bool (@ContextProduction.Dictionary.mk Bool 11) true = true) ∧ (@ContextReplay.accepted Bool (@ContextProduction.Dictionary.mk Bool 7) false = false) := by decide
#print axioms ContextProduction.Dictionary
#print axioms ContextProduction.Dictionary.mk
#print axioms ContextProduction.Dictionary.tag
#print axioms ContextProduction.Token
#print axioms ContextProduction.Token.mk
#print axioms ContextProduction.Token.payload
#print axioms ContextReplay.accepted
#print axioms ContextReplay.accepted_passes
