set_option autoImplicit false
class ContextProduction.Dictionary (α : Type) where tag : Nat
structure ContextProduction.Token where payload : Nat
class ContextProduction.UniverseDictionary.{u} (α : Type) : Type where evidence : ∀ β : Type u, True
def ContextOracle.reference : ∀ (α : Type), [ContextProduction.UniverseDictionary.{1} α] → α → α := fun (α : Type) [unusedDictionary : ContextProduction.UniverseDictionary.{1} α] (x : α) => x
theorem ContextOracle.reference_checked : True := by decide
#print axioms ContextProduction.Dictionary
#print axioms ContextProduction.Dictionary.mk
#print axioms ContextProduction.Dictionary.tag
#print axioms ContextProduction.Token
#print axioms ContextProduction.Token.mk
#print axioms ContextProduction.Token.payload
#print axioms ContextProduction.UniverseDictionary
#print axioms ContextProduction.UniverseDictionary.mk
#print axioms ContextProduction.UniverseDictionary.evidence
#print axioms ContextOracle.reference
#print axioms ContextOracle.reference_checked
