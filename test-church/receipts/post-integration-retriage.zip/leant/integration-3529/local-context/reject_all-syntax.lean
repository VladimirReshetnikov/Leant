set_option autoImplicit false
class ContextProduction.Dictionary (α : Type) where tag : Nat
structure ContextProduction.Token where payload : Nat
def ContextSyntax.condition (f : ∀ (α : Type), [ContextProduction.Dictionary α] → α → α) : Prop := False
def ContextSyntax.condition_decidable (f : ∀ (α : Type), [ContextProduction.Dictionary α] → α → α) : Decidable (ContextSyntax.condition f) := by unfold ContextSyntax.condition; infer_instance
#print axioms ContextProduction.Dictionary
#print axioms ContextProduction.Dictionary.mk
#print axioms ContextProduction.Dictionary.tag
#print axioms ContextProduction.Token
#print axioms ContextProduction.Token.mk
#print axioms ContextProduction.Token.payload
#print axioms ContextSyntax.condition
#print axioms ContextSyntax.condition_decidable
