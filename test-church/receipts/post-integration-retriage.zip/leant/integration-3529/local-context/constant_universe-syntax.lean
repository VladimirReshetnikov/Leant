set_option autoImplicit false
class ContextProduction.Dictionary (α : Type) where tag : Nat
structure ContextProduction.Token where payload : Nat
class ContextProduction.UniverseDictionary.{u} (α : Type) : Type where evidence : ∀ β : Type u, True
def ContextSyntax.condition (f : ∀ (α : Type), [ContextProduction.UniverseDictionary.{1} α] → α → α) : Prop := True
def ContextSyntax.condition_decidable (f : ∀ (α : Type), [ContextProduction.UniverseDictionary.{1} α] → α → α) : Decidable (ContextSyntax.condition f) := by unfold ContextSyntax.condition; infer_instance
def ContextSyntax.class_result_type_zero : Type := ContextProduction.UniverseDictionary.{1} Nat
#print axioms ContextProduction.Dictionary
#print axioms ContextProduction.Dictionary.mk
#print axioms ContextProduction.Dictionary.tag
#print axioms ContextProduction.Token
#print axioms ContextProduction.Token.mk
#print axioms ContextProduction.Token.payload
#print axioms ContextProduction.UniverseDictionary
#print axioms ContextProduction.UniverseDictionary.mk
#print axioms ContextProduction.UniverseDictionary.evidence
#print axioms ContextSyntax.condition
#print axioms ContextSyntax.condition_decidable
#print axioms ContextSyntax.class_result_type_zero
