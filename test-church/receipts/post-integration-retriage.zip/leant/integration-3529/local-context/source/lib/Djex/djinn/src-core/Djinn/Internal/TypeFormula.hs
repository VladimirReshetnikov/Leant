--
-- Copyright (c) 2005 Lennart Augustsson
-- See LICENSE for licensing details.
--

-- | Representation-neutral compilation of Djinn source types into LJT
-- formulae.
--
-- The public compatibility surface still accepts 'HType', while checked Djex
-- sessions use the shared synthesis type tree.  Both representations enter
-- this package-private engine through a one-layer 'TypeView' and share the
-- same validated definition cache, expansion provenance, and atom renderer.
module Djinn.Internal.TypeFormula
    ( TypeLayer(..)
    , TypeView
    , FormulaDefinition(..)
    , PreparedFormulaCompiler
    , FormulaPolarity(..)
    , FormulaTranslation
    , translatedFormula
    , translationIncomplete
    , translationIntroducedSkolems
    , PolarizedFormulaPlans
    , primaryFormulaPlan
    , exactOpaqueFormulaPlan
    , transportFormulaPlan
    , singleOpaqueFormulaPlans
    , singleOpenFormulaPlans
    , pairOpaqueFormulaPlans
    , pairOpenFormulaPlans
    , tripleOpaqueFormulaPlans
    , tripleOpenFormulaPlans
    , quadrupleOpaqueFormulaPlans
    , quadrupleOpenFormulaPlans
    , quintupleOpaqueFormulaPlans
    , quintupleOpenFormulaPlans
    , polarizedFormulaPlanSkolems
    , polarizedFormulaPlanPositiveForallCount
    , maxCompleteForallFrontierSites
    , prepareFormulaCompiler
    , prepareFormulaCompilerWithRecursiveData
    , compileFormula
    , structuralFormulaRetainsAssignments
    , compilePolarizedFormulaPlans
    , compileTransportFormula
    , compileRecursiveDataViews
    , compileDataConstructorViews
    , compileDataViewInstanceFormula
    , compileDataViewFormula
    , compileConstructedHypothesisFormula
    , negativeOpaqueFormulaSymbols
    ) where

import Control.Monad (zipWithM)
import Control.Monad.Trans.Class (lift)
import Control.Monad.Trans.State.Strict (StateT, evalStateT, get, modify)
import Data.Bifunctor (first)
import Data.Graph (SCC(..), stronglyConnComp)
import Data.List (intercalate, isSuffixOf, sortOn)
import qualified Data.Map.Lazy as LazyMap
import qualified Data.Map.Strict as Map
import Data.Maybe (fromMaybe, listToMaybe, mapMaybe)
import qualified Data.Set as Set
import Numeric.Natural (Natural)

import Djinn.Internal.HIdentifier (isQualifiedConId)
import Djinn.Internal.LJTFormula
import qualified Language.Haskell.Synthesis.Collection as SharedCollection
import qualified Language.Haskell.Synthesis.Name as SharedName
import qualified Language.Haskell.Synthesis.Type as SharedType
import qualified Language.Haskell.Synthesis.TypeAtom as SharedTypeAtom
import qualified Language.Haskell.Synthesis.TypeRender as SharedTypeRender

-- | A single observable layer of a source type.  Keeping children in the
-- caller's representation avoids introducing another source-facing recursive
-- tree merely to connect the legacy and shared frontends.
data TypeLayer source
    = TypeApplicationLayer source source
    | TypeVariableLayer String
    | TypeConstructorLayer String
    | TypeTupleLayer [source]
    | TypeArrowLayer source source
    | TypeForallLayer (SharedTypeAtom.TypeAtom String)
    | TypeUnionLayer [(String, [source])]
    | TypeAbstractLayer String

-- | How the formula compiler observes one layer of a caller-supplied type
-- representation, or fails with a diagnostic for a node it cannot view.
-- Both the legacy 'Djinn.Internal.HTypes.HType' frontend and the shared
-- source-type frontend supply one of these instead of a converted tree.
type TypeView source = source -> Either String (TypeLayer source)

-- | The three declaration shapes relevant to formula compilation.  Value and
-- class declarations are premises rather than type definitions and therefore
-- never enter this table.
data FormulaDefinition source
    = FormulaAlias String [String] source
    | FormulaData String [String] [(String, [source])]
    | FormulaAbstract String [String] String

-- Expansion arguments carry the definition path at which they were supplied.
-- Returning a parameter as a complete type resumes at that origin, so finite
-- @Id (Id a)@ nesting does not look recursive. If a parameter is used in
-- function position, application-spine discovery deliberately retains the
-- current path: @A a = B a; B f = f f@ must reject the query @A A@ rather than
-- resetting past the active @A@ expansion.
data ExpansionType
    = ExpansionApp ExpansionType ExpansionType
    | ExpansionVar String
    | ExpansionCon String ExpansionOrigin
    | ExpansionTuple [ExpansionType]
    | ExpansionArrow ExpansionType ExpansionType
    | ExpansionForall ExpansionOrigin (SharedTypeAtom.TypeAtom String)
    | ExpansionUnion [(String, [ExpansionType])]
    | ExpansionAbstract String
    | ExpansionArgument ExpansionPath ExpansionType
    -- An exact provider argument is marked before it is substituted into the
    -- provider body.  Unlike an ordinary definition argument, this wrapper is
    -- semantic provenance: the fidelity walk follows it through aliases and
    -- higher-kinded application so structural expansion cannot silently erase
    -- part of the caller's visible type application.
    | ExpansionExactAssignment ExpansionType

-- A constructor occurrence keeps its identity when substitution duplicates
-- it. Query nodes are identified by their tree path. Nodes written in a
-- definition body are templates until that definition is expanded, when they
-- are placed under the concrete head occurrence that created this instance.
data ExpansionOrigin
    = QueryOrigin [Natural]
    | DefinitionTemplateOrigin [Natural]
    | DefinitionOrigin ExpansionOrigin String [Natural]
    -- A quantified body is converted lazily only if its forall is opened.
    -- Retaining the parent occurrence makes skolems from two equal-looking
    -- forall nodes distinct, including after definition instantiation.
    | OpenedForallOrigin ExpansionOrigin [Natural]
    deriving (Eq, Ord, Show)

data ExpansionFrame = ExpansionFrame String ExpansionOrigin

data ExpansionPath =
    ExpansionPath
        [ExpansionFrame]
        (Set.Set ExpansionOrigin)
        (Set.Set String)
        -- ^ recursive component representatives already opened on this
        -- logical lowering path

emptyExpansionPath :: ExpansionPath
emptyExpansionPath = ExpansionPath [] Set.empty Set.empty

pushExpansion
    :: String -> ExpansionOrigin -> ExpansionPath -> ExpansionPath
pushExpansion name origin (ExpansionPath frames active recursiveComponents) =
    ExpansionPath
        (ExpansionFrame name origin : frames)
        (Set.insert origin active)
        recursiveComponents

rememberRecursiveComponent
    :: PreparedFormulaCompiler
    -> String
    -> ExpansionPath
    -> ExpansionPath
rememberRecursiveComponent definitions name
        (ExpansionPath frames active recursiveComponents) =
    ExpansionPath frames active $ Set.insert component recursiveComponents
  where
    -- The preparation invariant indexes every admitted recursive head.  The
    -- head itself is a collision-free singleton fallback for defensive
    -- package-internal callers should that invariant ever change.
    component =
        fromMaybe name (formulaDefinitionRecursiveComponent name definitions)

resumeExpansionArgument
    :: ExpansionPath -> ExpansionPath -> ExpansionPath
resumeExpansionArgument
        (ExpansionPath _ _ currentComponents)
        (ExpansionPath originFrames originActive originComponents) =
    ExpansionPath originFrames originActive $
        Set.union currentComponents originComponents

-- | The complete first-binding table after source representations have been
-- discarded.  A checked environment stores one value and translates both raw
-- and native query types through it.
data PreparedFormulaCompiler = PreparedFormulaCompiler
    (Map.Map String ([String], ExpansionType))
    (Set.Set String)
    (Set.Set String)
    (Map.Map String String)
    -- ^ recursive datatype head -> source-order representative of its
    -- alias-normalized definition-graph SCC

-- | Variance at the current formula node. A function parameter reverses it;
-- products, sums, and definition expansion preserve it.
data FormulaPolarity
    = PositiveFormula
    | NegativeFormula
    deriving (Eq, Show)

-- | A polarized formula plus an honesty bit. 'translationIncomplete' means
-- that at least one quantified subtree remained opaque, a positive
-- qualification was opened without its dictionary premises, or a recursive
-- datatype was unfolded/atomized only to the configured positive bound.
-- Proofs are still sound, but an empty proof search is not a refutation of the
-- Haskell type.
-- 'translationIntroducedSkolems' lists the fresh rigid variables allocated by
-- opened positive foralls; instantiation policy treats them as ordinary
-- sequent variables without reparsing rendered atom spellings.
data FormulaTranslation = FormulaTranslation
    { translatedFormula :: Formula
    , translationIncomplete :: Bool
    , translationOpenableForalls :: [ForallSite]
    , translationIntroducedSkolems :: [String]
    }
    deriving (Eq, Show)

-- | One nonempty, deliberately bounded family of coherent translations.  The
-- primary plan opens every supported positive forall.  The historical exact
-- plan opens none; the first two local frontiers differ from either extreme at
-- one independently reachable occurrence.  Quadratic through quintic tail
-- frontiers make the corresponding choice at unordered pairs through
-- quintuples of sites. The quintic categories have a fixed per-orientation
-- cap which still retains every selection needed through eleven sites.
-- Keeping the categories explicit lets goal search and prepared-premise
-- caching preserve their established order without reconstructing it from an
-- unlabelled list.
data PolarizedFormulaPlans = PolarizedFormulaPlans
    { primaryFormulaPlan :: FormulaTranslation
    , exactOpaqueFormulaPlan :: Formula
    , transportFormulaPlan :: FormulaTranslation
    , singleOpaqueFormulaPlans :: [FormulaTranslation]
    , singleOpenFormulaPlans :: [FormulaTranslation]
    , pairOpaqueFormulaPlans :: [FormulaTranslation]
    , pairOpenFormulaPlans :: [FormulaTranslation]
    , tripleOpaqueFormulaPlans :: [FormulaTranslation]
    , tripleOpenFormulaPlans :: [FormulaTranslation]
    , quadrupleOpaqueFormulaPlans :: [FormulaTranslation]
    , quadrupleOpenFormulaPlans :: [FormulaTranslation]
    , quintupleOpaqueFormulaPlans :: [FormulaTranslation]
    , quintupleOpenFormulaPlans :: [FormulaTranslation]
    }
    deriving (Eq, Show)

-- | Every distinct skolem spelling introduced by any plan of this family, in
-- first-plan order. The primary view opens every supported positive site.
-- Alternatives only omit sites and reuse the primary expansion paths and
-- namespaces, so they cannot introduce another spelling. Reading their lists
-- here would unnecessarily force every optional occurrence frontier.
polarizedFormulaPlanSkolems :: PolarizedFormulaPlans -> [String]
polarizedFormulaPlanSkolems plans = SharedCollection.distinctOn id $
    translationIntroducedSkolems $ primaryFormulaPlan plans

-- | Source-sized planning information without demanding any optional
-- occurrence-subset view. This is a scheduling input, never a rank limit.
polarizedFormulaPlanPositiveForallCount :: PolarizedFormulaPlans -> Int
polarizedFormulaPlanPositiveForallCount =
    length . translationOpenableForalls . primaryFormulaPlan

-- A definition origin plus the reverse source path is stable across alias
-- expansion, duplicated arguments, datatype fields, and reopened forall
-- bodies. It therefore identifies exactly one positive introduction choice
-- without depending on source binder spelling.
data ForallSite = ForallSite ExpansionOrigin [Natural]
    deriving (Eq, Ord, Show)

-- Reverse occurrence paths extend at the front, so an enclosing site's path
-- is a suffix of every reachable descendant.  Origin ancestry supplies the
-- corresponding definition/opened-forall provenance; the path check keeps two
-- copies of one substituted source occurrence distinct.
forallSiteLeadsTo :: ForallSite -> ForallSite -> Bool
forallSiteLeadsTo
        (ForallSite ancestorOrigin ancestorPath)
        (ForallSite descendantOrigin descendantPath) =
    ancestorPath `isSuffixOf` descendantPath &&
        originDescendsFrom ancestorOrigin descendantOrigin

originDescendsFrom :: ExpansionOrigin -> ExpansionOrigin -> Bool
originDescendsFrom ancestor descendant
    | ancestor == descendant = True
    | otherwise = case descendant of
        DefinitionOrigin parent _ _ -> originDescendsFrom ancestor parent
        OpenedForallOrigin parent _ -> originDescendsFrom ancestor parent
        QueryOrigin{} -> False
        DefinitionTemplateOrigin{} -> False

data PreparedDefinition = PreparedDefinition
    String
    [String]
    ExpansionType
    Bool

-- | Validate a definition table once under the historical policy which rejects
-- every recursive expansion component.  Checked environments which have
-- already classified recursive datatypes use
-- 'prepareFormulaCompilerWithRecursiveData' instead.
prepareFormulaCompiler
    :: TypeView source
    -> [FormulaDefinition source]
    -> Either String PreparedFormulaCompiler
prepareFormulaCompiler = prepareFormulaCompilerWithRecursiveData Set.empty

-- | Validate a definition table while admitting an already checked set of
-- recursive datatype heads. Synonym cycles and every cycle containing an
-- unmarked definition remain errors. Marked datatypes stay in the definition
-- cache so polarized query compilation can expose one positive constructor
-- layer; conservative and negative translations retain their complete
-- applications as opaque atoms.
--
-- Names which do not select a first-binding 'FormulaData' declaration are
-- ignored. The caller therefore cannot weaken synonym validation by
-- accidentally or maliciously marking an alias as recursive data.
prepareFormulaCompilerWithRecursiveData
    :: Set.Set String
    -> TypeView source
    -> [FormulaDefinition source]
    -> Either String PreparedFormulaCompiler
prepareFormulaCompilerWithRecursiveData requestedRecursiveData view supplied = do
    definitions <- mapM (prepareDefinition view) selected
    let preliminary = PreparedFormulaCompiler
            (Map.fromList
                [(name, (parameters, body)) |
                    PreparedDefinition name parameters body _ <- definitions])
            (Set.fromList
                [name |
                    PreparedDefinition name _ _ True <- definitions])
            recursiveData
            Map.empty
    references <- validateDefinitionExpansion
        recursiveData definitions preliminary
    return $ PreparedFormulaCompiler
        (Map.fromList
            [(name, (parameters, body)) |
                PreparedDefinition name parameters body _ <- definitions])
        (Set.fromList
            [name |
                PreparedDefinition name _ _ True <- definitions])
        recursiveData
        (recursiveDataComponents recursiveData definitions references)
  where
    selected = firstBindings supplied
    dataNames = Set.fromList
        [name | FormulaData name _ _ <- selected]
    recursiveData = Set.intersection requestedRecursiveData dataNames

prepareDefinition
    :: TypeView source
    -> FormulaDefinition source
    -> Either String PreparedDefinition
prepareDefinition view definition = case definition of
    FormulaAlias name parameters body ->
        PreparedDefinition name parameters
            <$> expansionTypeAt view DefinitionTemplateOrigin [] body
            <*> pure True
    FormulaData name parameters constructors -> do
        expandedConstructors <- zipWithM convertConstructor
            [0 ..] constructors
        return $ PreparedDefinition name parameters
            (ExpansionUnion expandedConstructors) False
      where
        convertConstructor constructorIndex (constructor, fields) = do
            expandedFields <- zipWithM
                (\fieldIndex -> expansionTypeAt view
                    DefinitionTemplateOrigin
                    [fieldIndex, constructorIndex])
                [0 ..]
                fields
            return (constructor, expandedFields)
    FormulaAbstract name parameters abstractName -> Right $
        PreparedDefinition name parameters
            (ExpansionAbstract abstractName) False

-- | Compile one source type with a previously checked definition table.
compileFormula
    :: TypeView source
    -> PreparedFormulaCompiler
    -> source
    -> Either String Formula
compileFormula view prepared source = do
    expanded <- expansionTypeAt view QueryOrigin [] source
    translatedFormula <$> lowerExpansionType
        OpaqueForalls prepared emptyExpansionPath [] expanded

-- | Check that structural compilation preserves the complete nominal content
-- of every selected provider argument which actually reaches the provider body.
-- Each argument is marked before substitution, so the walk sees erasure both
-- at a binder occurrence and inside the assigned type itself.  This also
-- follows a higher-kinded assignment into applications supplied by the scheme:
-- assigning @f := Phantom@ in @f Int@ must not authorize a premise usable as
-- @Phantom Bool@.
--
-- A datatype formal is observable when at least one constructor-field path
-- retains it. That existential observation is only the top-level gate: after
-- it passes, the instantiated constructor body is traversed so every field
-- which carries an exact marker must preserve it at each nested datatype
-- boundary. Thus one faithful sibling cannot hide an erased one. Aliases are
-- definitionally transparent. Recursive datatypes, unknown or unsaturated
-- applications, and foralls stay opaque under 'compileFormula' and therefore
-- preserve their complete nominal identity.
-- Fully applied empty datatypes do too: 'compileFormula' deliberately lowers
-- them to an 'Empty' proposition keyed by the complete application.
structuralFormulaRetainsAssignments
    :: TypeView source
    -> PreparedFormulaCompiler
    -> [String]
    -> [source]
    -> source
    -> Either String Bool
structuralFormulaRetainsAssignments view definitions binders arguments source
    | length binders /= length arguments =
        Left "provider assignment vector does not match binder arity"
    | otherwise = do
        expanded <- expansionTypeAt view QueryOrigin [] source
        expandedArguments <- mapM
            (expansionTypeAt view QueryOrigin []) arguments
        instantiated <- substituteExpansion
            (firstExpansionSubstitutions $ zip binders $
                map ExpansionExactAssignment expandedArguments)
            expanded
        evalStateT
            (structuralAssignmentFaithful definitions
                False emptyExpansionPath instantiated)
            Map.empty

-- | Compile the bounded rank-N fragment used by checked Djinn queries.
-- Foralls in positive position are opened with fresh rigid proposition names.
-- Their already validated class contexts are deliberately ignored for proof
-- power, consistently with Djinn's dictionary-independent treatment of the
-- query's prenex context. Unsupported occurrences stay alpha-stable opaque
-- atoms.
-- Besides the two historical extremes, retain both singleton frontiers: one
-- opaque occurrence among opened siblings, and one opened occurrence (plus
-- any enclosing forall chain needed to reach it) among opaque siblings.
-- Pairwise through quintic tail frontiers make the same choices at unordered
-- selections of two through five sites. The fifth-order layer is capped at
-- 512 plans per orientation, enough to retain all 462 selections at eleven
-- sites. This is exhaustive for eleven independent sites without constructing
-- a power set, while larger inputs cannot make the new tail grow without
-- bound.
-- The numeric namespace must be distinct for independently compiled goals and
-- premises so their locally introduced skolems cannot accidentally meet.
compilePolarizedFormulaPlans
    :: Natural
    -> FormulaPolarity
    -> TypeView (SharedType.Type String)
    -> TypeView source
    -> PreparedFormulaCompiler
    -> source
    -> Either String PolarizedFormulaPlans
compilePolarizedFormulaPlans namespace polarity openedView view prepared
        source = do
    expanded <- expansionTypeAt view QueryOrigin [] source
    primary <- lowerExpansionType
        (PolarizedForalls (show namespace) polarity openedView Set.empty Set.empty)
        prepared emptyExpansionPath [] expanded
    -- Exact opacity applies to recursive data as well as quantified subtrees.
    -- This complementary view preserves forwarding such as @Rec a -> Rec a@
    -- when the primary positive view exposes one constructor layer.
    exact <- translatedFormula <$> lowerExpansionType
        OpaqueForalls prepared emptyExpansionPath [] expanded
    let available = negativeOpaqueFormulaSymbols polarity $ translatedFormula primary
    transport <- if Set.null available then pure primary else lowerExpansionType
        (PolarizedForalls (show namespace) polarity openedView Set.empty available)
        prepared emptyExpansionPath [] expanded
    let sites = translationOpenableForalls primary
        allSites = Set.fromList sites
        -- Primary and exact compilation above retain eager diagnostics. The
        -- remaining views are optional proof-producing strategies: compile
        -- each only when search asks for it, omitting a failed alternative.
        -- Such an omission grants no negative authority. In particular, an
        -- early transport proof need not prepare thousands of unused subsets.
        selection = either (const Nothing) Just . compileSelection expanded
        singleOpaque = mapMaybe (selection . Set.singleton) sites
        singleOpen = if atLeast 3 sites then mapMaybe
            (selection . opaqueExceptTargets allSites . (: [])) sites else []
        sitePairs = unorderedPairs sites
        pairOpaque = if atLeast 4 sites then mapMaybe
            (selection . Set.fromList . pairMembers) sitePairs else []
        pairOpen = if atLeast 5 sites then mapMaybe
            (selection . opaqueExceptTargets allSites . pairMembers) sitePairs else []
        siteTriples = unorderedTriples sites
        tripleOpaque = if atLeast 6 sites then mapMaybe
            (selection . Set.fromList . tripleMembers) siteTriples else []
        tripleOpen = if atLeast 7 sites then mapMaybe
            (selection . opaqueExceptTargets allSites . tripleMembers) siteTriples else []
        siteQuadruples = unorderedQuadruples sites
        quadrupleOpaque = if atLeast 8 sites then mapMaybe
            (selection . Set.fromList . quadrupleMembers) siteQuadruples else []
        quadrupleOpen = if atLeast 9 sites then mapMaybe
            (selection . opaqueExceptTargets allSites . quadrupleMembers) siteQuadruples else []
        siteQuintuples = boundedQuintuples sites
        quintupleOpaque = if atLeast 10 sites then mapMaybe
            (selection . Set.fromList . quintupleMembers) siteQuintuples else []
        quintupleOpen = if atLeast 11 sites then mapMaybe
            (selection . opaqueExceptTargets allSites . quintupleMembers) siteQuintuples else []
    return PolarizedFormulaPlans
        { primaryFormulaPlan = primary
        , exactOpaqueFormulaPlan = exact
        , transportFormulaPlan = transport
        , singleOpaqueFormulaPlans = singleOpaque
        , singleOpenFormulaPlans = singleOpen
        , pairOpaqueFormulaPlans = pairOpaque
        , pairOpenFormulaPlans = pairOpen
        , tripleOpaqueFormulaPlans = tripleOpaque
        , tripleOpenFormulaPlans = tripleOpen
        , quadrupleOpaqueFormulaPlans = quadrupleOpaque
        , quadrupleOpenFormulaPlans = quadrupleOpen
        , quintupleOpaqueFormulaPlans = quintupleOpaque
        , quintupleOpenFormulaPlans = quintupleOpen
        }
  where
    compileSelection expanded opaqueSites = lowerExpansionType
        (PolarizedForalls (show namespace) polarity openedView opaqueSites Set.empty)
        prepared emptyExpansionPath [] expanded

    -- Opening nested targets necessarily opens the union of every enclosing
    -- forall chain. Every unrelated occurrence remains opaque, making this
    -- the exact dual of selecting those sites in the fully opened plan.
    opaqueExceptTargets sites targets = Set.filter
        (\site -> not $ any (site `forallSiteLeadsTo`) targets) sites

    pairMembers (firstSite, secondSite) = [firstSite, secondSite]

    tripleMembers (firstSite, secondSite, thirdSite) =
        [firstSite, secondSite, thirdSite]

    quadrupleMembers (firstSite, secondSite, thirdSite, fourthSite) =
        [firstSite, secondSite, thirdSite, fourthSite]

    quintupleMembers
            (firstSite, secondSite, thirdSite, fourthSite, fifthSite) =
        [firstSite, secondSite, thirdSite, fourthSite, fifthSite]

    unorderedPairs [] = []
    unorderedPairs (firstSite : remaining) =
        map ((,) firstSite) remaining ++ unorderedPairs remaining

    unorderedTriples [] = []
    unorderedTriples (firstSite : remaining) =
        [ (firstSite, secondSite, thirdSite)
        | (secondSite, thirdSite) <- unorderedPairs remaining
        ] ++ unorderedTriples remaining

    unorderedQuadruples [] = []
    unorderedQuadruples (firstSite : remaining) =
        [ (firstSite, secondSite, thirdSite, fourthSite)
        | (secondSite, thirdSite, fourthSite) <- unorderedTriples remaining
        ] ++ unorderedQuadruples remaining

    unorderedQuintuples [] = []
    unorderedQuintuples (firstSite : remaining) =
        [ (firstSite, secondSite, thirdSite, fourthSite, fifthSite)
        | (secondSite, thirdSite, fourthSite, fifthSite) <-
            unorderedQuadruples remaining
        ] ++ unorderedQuintuples remaining

    -- The complete eleven-site layer has 462 selections. Alternate the two
    -- source edges so a bounded suffix does not systematically exclude late
    -- sites, then stop before compiling more than a fixed number of views.
    boundedQuintuples values = take maxQuintuplePlansPerFrontier $
        SharedCollection.distinctOn
            (Set.fromList . quintupleMembers)
            (roundRobin
                [ unorderedQuintuples values
                , unorderedQuintuples $ reverse values
                ])

    roundRobin streams = case
            [ (value, remaining)
            | value : remaining <- streams
            ] of
        [] -> []
        active -> map fst active ++ roundRobin (map snd active)

    atLeast :: Int -> [element] -> Bool
    atLeast count = go count
      where
        go remaining _ | remaining <= 0 = True
        go _ [] = False
        go remaining (_ : rest) = go (remaining - 1) rest

-- C(11, 5) = 462, so this cap preserves both complete quintic orientations
-- through eleven independent sites while bounding their incremental cost on
-- every larger input.
maxQuintuplePlansPerFrontier :: Int
maxQuintuplePlansPerFrontier = 512

-- | Up to this many independent positive sites, the historical frontiers
-- cover every subset: either its open side or its opaque side has at most
-- five members, and C(11, 5) = 462 fits the quintuple frontier's 512 cap.
-- Larger sources still use the same proof rules and coherent transport;
-- callers use this threshold only to avoid enumerating known-costly views
-- before trying an inhabitation-only acceleration.
maxCompleteForallFrontierSites :: Int
maxCompleteForallFrontierSites = 11

-- | A single demand-aware introduction plan. Keep a positive quantified site
-- opaque when its exact alpha-aware type is supplied by a negative position;
-- introduce all remaining positive sites. Unlike occurrence-subset frontiers,
-- this plan handles any number of independent transports and introductions in
-- one traversal. External symbols let query preparation share its available
-- schemes with a loaded consumer's argument view. They affect search choices
-- only: ordinary formula proof checking still establishes every use.
compileTransportFormula
    :: Set.Set Symbol
    -> Natural
    -> FormulaPolarity
    -> TypeView (SharedType.Type String)
    -> TypeView source
    -> PreparedFormulaCompiler
    -> source
    -> Either String FormulaTranslation
compileTransportFormula supplied namespace polarity openedView view prepared source = do
    expanded <- expansionTypeAt view QueryOrigin [] source
    primary <- lowerExpansionType
        (PolarizedForalls (show namespace) polarity openedView Set.empty Set.empty)
        prepared emptyExpansionPath [] expanded
    let available = supplied `Set.union`
            negativeOpaqueFormulaSymbols polarity (translatedFormula primary)
    lowerExpansionType
        (PolarizedForalls (show namespace) polarity openedView Set.empty available)
        prepared emptyExpansionPath [] expanded

-- | Compile one already instantiated provider as a hypothesis, opening
-- polymorphic argument obligations so their values can be constructed. Every
-- axiom owns a namespace disjoint from ordinary goal/premise namespaces and
-- from every other axiom. Its new rigid variables must not enter a shared
-- instantiation candidate inventory: they belong only to this introduction.
compileConstructedHypothesisFormula
    :: String
    -> Natural
    -> TypeView (SharedType.Type String)
    -> PreparedFormulaCompiler
    -> SharedType.Type String
    -> Either String (Formula, [String])
compileConstructedHypothesisFormula family index view prepared source = do
    expanded <- expansionTypeAt view QueryOrigin [] source
    translation <- lowerExpansionType
        (PolarizedForalls namespace NegativeFormula view Set.empty Set.empty)
        prepared emptyExpansionPath [] expanded
    if null (translationIntroducedSkolems translation)
        then Left "provider instance has no quantified argument to construct"
        else Right (translatedFormula translation,
            translationIntroducedSkolems translation)
  where
    namespace = "construction$" ++ family ++ "$" ++ show index

-- | Exact one-layer views of recursive atoms already present in this sequent.
-- Source values retain their declared constructors while LJT may keep their
-- complete nominal type opaque or inspect a finite constructor shape.
-- Datatype fields and all foralls remain opaque. In particular this does not recursively
-- close the inventory under expanding applications such as R (Maybe a).
-- Callers may use these views only in proof-producing, incomplete search plans.
compileRecursiveDataViews
    :: TypeView (SharedType.Type String)
    -> PreparedFormulaCompiler
    -> [Formula]
    -> [(Formula, Formula)]
compileRecursiveDataViews = compileDataConstructorViewsWith True

-- | Constructor shapes for all exact declared data atoms in a recursive case
-- sequent, including nonrecursive result families such as Bool.
compileDataConstructorViews
    :: TypeView (SharedType.Type String)
    -> PreparedFormulaCompiler
    -> [Formula]
    -> [(Formula, Formula)]
compileDataConstructorViews = compileDataConstructorViewsWith False

compileDataConstructorViewsWith
    :: Bool
    -> TypeView (SharedType.Type String)
    -> PreparedFormulaCompiler
    -> [Formula]
    -> [(Formula, Formula)]
compileDataConstructorViewsWith recursiveOnly view prepared =
    mapMaybe compile . Set.toAscList . Set.unions . map atoms
  where
    atoms formula = case formula of
        PVar symbol -> Set.singleton symbol
        left :-> right -> atoms left `Set.union` atoms right
        Conj fields -> Set.unions $ map atoms fields
        Disj alternatives -> Set.unions $ map (atoms . snd) alternatives
        _ -> Set.empty

    compile symbol = do
        source <- opaqueSymbolSource symbol
        either (const Nothing) Just $ do
            expanded <- expansionTypeAt view QueryOrigin [] source
            normalized <- normalizeExpansionAliases prepared emptyExpansionPath expanded
            case expansionApplication normalized [] of
                (ExpansionCon name origin, arguments)
                    | Just (parameters, body@ExpansionUnion{}) <- lookupFormulaDefinition name prepared
                    , not recursiveOnly || formulaDefinitionIsRecursiveData name prepared
                    , length parameters == length arguments -> do
                        layer <- expandDefinitionStep prepared emptyExpansionPath
                            name origin parameters body arguments
                        unfolded <- lowerExpansionType (PreserveData OpaqueForalls) prepared
                            (pushExpansion name origin $
                                rememberRecursiveComponent prepared name emptyExpansionPath)
                            [] layer
                        pure (PVar symbol, translatedFormula unfolded)
                _ -> Left "not an exact datatype application"

-- | A coherent nominal datatype view for case search. Positive foralls still
-- introduce their own skolems; aliases expand, but every declared datatype
-- application retains its exact source identity on both sides of an arrow.
compileDataViewFormula
    :: Natural
    -> FormulaPolarity
    -> TypeView (SharedType.Type String)
    -> PreparedFormulaCompiler
    -> SharedType.Type String
    -> Either String FormulaTranslation
compileDataViewFormula namespace polarity view prepared source = do
    expanded <- expansionTypeAt view QueryOrigin [] source
    lowerExpansionType
        (PreserveData $ PolarizedForalls (show namespace) polarity view Set.empty Set.empty)
        prepared emptyExpansionPath [] expanded

-- | Exact vocabulary for instances used beside opaque datatype views. Keep
-- quantified subterms opaque as well: instantiating a provider must not open
-- another obligation scope or acquire fresh skolems implicitly.
compileDataViewInstanceFormula
    :: TypeView (SharedType.Type String)
    -> PreparedFormulaCompiler
    -> SharedType.Type String
    -> Either String Formula
compileDataViewInstanceFormula view prepared source = do
    expanded <- expansionTypeAt view QueryOrigin [] source
    translatedFormula <$> lowerExpansionType (PreserveData OpaqueForalls)
        prepared emptyExpansionPath [] expanded

-- | Exact opaque forall types available at negative source positions.
-- Free skolems stay nominal in symbol keys; an inner scope cannot accidentally
-- authorize an alpha-similar outer type.
negativeOpaqueFormulaSymbols :: FormulaPolarity -> Formula -> Set.Set Symbol
negativeOpaqueFormulaSymbols polarity formula = case formula of
    PVar symbol | polarity == NegativeFormula,
            Just SharedType.ForallType{} <- opaqueSymbolSource symbol -> Set.singleton symbol
    left :-> right -> negativeOpaqueFormulaSymbols (oppositePolarity polarity) left
        `Set.union` negativeOpaqueFormulaSymbols polarity right
    Conj fields -> Set.unions $ map (negativeOpaqueFormulaSymbols polarity) fields
    Disj alternatives -> Set.unions $
        map (negativeOpaqueFormulaSymbols polarity . snd) alternatives
    _ -> Set.empty

oppositePolarity :: FormulaPolarity -> FormulaPolarity
oppositePolarity PositiveFormula = NegativeFormula
oppositePolarity NegativeFormula = PositiveFormula

data ForallLowering
    = OpaqueForalls
    | PreserveData ForallLowering
    | PolarizedForalls
        String
        FormulaPolarity
        (TypeView (SharedType.Type String))
        (Set.Set ForallSite)
        (Set.Set Symbol)
        -- ^ exact hypothesis types which positive forall sites may transport

lookupFormulaDefinition
    :: String
    -> PreparedFormulaCompiler
    -> Maybe ([String], ExpansionType)
lookupFormulaDefinition name (PreparedFormulaCompiler definitions _ _ _) =
    Map.lookup name definitions

formulaDefinitionIsAlias
    :: String -> PreparedFormulaCompiler -> Bool
formulaDefinitionIsAlias name (PreparedFormulaCompiler _ aliases _ _) =
    name `Set.member` aliases

formulaDefinitionIsRecursiveData
    :: String -> PreparedFormulaCompiler -> Bool
formulaDefinitionIsRecursiveData
        name (PreparedFormulaCompiler _ _ recursive _) =
    name `Set.member` recursive

formulaDefinitionRecursiveComponent
    :: String -> PreparedFormulaCompiler -> Maybe String
formulaDefinitionRecursiveComponent
        name (PreparedFormulaCompiler _ _ _ components) =
    Map.lookup name components

-- Reverse tree paths make child extension constant-time. Constructor and
-- field positions are both included, so two equal spellings in one finite
-- input still receive distinct identities.
expansionTypeAt
    :: TypeView source
    -> ([Natural] -> ExpansionOrigin)
    -> [Natural]
    -> source
    -> Either String ExpansionType
expansionTypeAt view origin = convert
  where
    convert path source = do
        layer <- view source
        case layer of
            TypeApplicationLayer function argument -> ExpansionApp
                <$> convert (0 : path) function
                <*> convert (1 : path) argument
            TypeVariableLayer variable -> Right $ ExpansionVar variable
            TypeConstructorLayer name ->
                Right $ ExpansionCon name $ origin path
            TypeTupleLayer types -> ExpansionTuple <$> zipWithM
                (\index -> convert (index : path)) [0 ..] types
            TypeArrowLayer argument result -> ExpansionArrow
                <$> convert (0 : path) argument
                <*> convert (1 : path) result
            TypeForallLayer atom -> Right $ ExpansionForall (origin path) atom
            TypeUnionLayer constructors -> ExpansionUnion <$> zipWithM
                (convertConstructor path) [0 ..] constructors
            TypeAbstractLayer name -> Right $ ExpansionAbstract name

    convertConstructor path constructorIndex (constructor, fields) = do
        expandedFields <- zipWithM
            (\fieldIndex ->
                convert (fieldIndex : constructorIndex : path))
            [0 ..]
            fields
        return (constructor, expandedFields)

-- Turn cached body-local origins into identities for this particular
-- expansion instance. Origins brought in later by parameter substitution are
-- already concrete and are deliberately left unchanged.
instantiateDefinitionOrigins
    :: ExpansionOrigin
    -> String
    -> ExpansionType
    -> ExpansionType
instantiateDefinitionOrigins parent owner = instantiate
  where
    instantiate source = case source of
        ExpansionApp function argument -> ExpansionApp
            (instantiate function) (instantiate argument)
        variable@(ExpansionVar _) -> variable
        ExpansionCon name origin ->
            ExpansionCon name $ instantiateOrigin origin
        ExpansionTuple types -> ExpansionTuple $ map instantiate types
        ExpansionArrow argument result ->
            ExpansionArrow (instantiate argument) (instantiate result)
        ExpansionForall origin atom ->
            ExpansionForall (instantiateOrigin origin) atom
        ExpansionUnion constructors -> ExpansionUnion
            [(constructor, map instantiate fields) |
                (constructor, fields) <- constructors]
        abstract@(ExpansionAbstract _) -> abstract
        ExpansionArgument path argument ->
            ExpansionArgument path $ instantiate argument
        ExpansionExactAssignment argument ->
            ExpansionExactAssignment $ instantiate argument

    instantiateOrigin origin = case origin of
        DefinitionTemplateOrigin sourcePath ->
            DefinitionOrigin parent owner sourcePath
        _ -> origin

expansionApp :: ExpansionType -> ExpansionType -> ExpansionType
expansionApp function argument = case partialExpansionArrow function of
    Just arrowArgument -> ExpansionArrow arrowArgument argument
    Nothing -> ExpansionApp function argument

-- Match the legacy smart constructor even when substitution has put an
-- argument-origin marker around @(->)@ or an already partial arrow.
partialExpansionArrow :: ExpansionType -> Maybe ExpansionType
partialExpansionArrow source = case source of
    ExpansionApp headType argument
        | expansionArrowHead headType -> Just argument
    ExpansionArgument origin function ->
        ExpansionArgument origin `fmap` partialExpansionArrow function
    ExpansionExactAssignment function ->
        ExpansionExactAssignment `fmap` partialExpansionArrow function
    _ -> Nothing

expansionArrowHead :: ExpansionType -> Bool
expansionArrowHead source = case source of
    ExpansionCon "->" _ -> True
    ExpansionArgument _ headType -> expansionArrowHead headType
    ExpansionExactAssignment headType -> expansionArrowHead headType
    _ -> False

lowerExpansionType
    :: ForallLowering
    -> PreparedFormulaCompiler
    -> ExpansionPath
    -> [Natural]
    -> ExpansionType
    -> Either String FormulaTranslation
lowerExpansionType lowering definitions path occurrencePath source = case source of
    ExpansionExactAssignment argument ->
        lowerExpansionType lowering definitions path occurrencePath argument
    ExpansionArgument origin argument ->
        lowerExpansionType lowering definitions
            (resumeExpansionArgument path origin) occurrencePath argument
    ExpansionTuple types -> do
        translated <- zipWithM
            (\index -> lowerChild index) [0 ..] types
        return $ combineTranslations Conj translated
    ExpansionArrow argument result -> do
        translatedArgument <- lowerExpansionType
            (reverseFormulaPolarity lowering) definitions path
            (0 : occurrencePath) argument
        translatedResult <- lowerChild 1 result
        return $ combineBinary (:->) translatedArgument translatedResult
    ExpansionForall origin atom ->
        lowerForall lowering definitions path occurrencePath origin atom
    ExpansionUnion [] -> Right $ completeTranslation false
    ExpansionUnion constructors -> do
        translated <- zipWithM lowerConstructor [0 ..] constructors
        return $ FormulaTranslation
            (Disj $ map fst translated)
            (any (translationIncomplete . snd) translated)
            (concatMap (translationOpenableForalls . snd) translated)
            (concatMap (translationIntroducedSkolems . snd) translated)
    _ -> lowerApplication lowering definitions path occurrencePath source
  where
    lowerChild index = lowerExpansionType lowering definitions path
        (index : occurrencePath)

    lowerConstructor constructorIndex (constructor, fields) = do
        translation <- lowerExpansionType lowering definitions path
            (constructorIndex : occurrencePath) $ ExpansionTuple fields
        return
            ( (ConsDesc constructor (length fields),
                translatedFormula translation)
            , translation
            )

lowerForall
    :: ForallLowering
    -> PreparedFormulaCompiler
    -> ExpansionPath
    -> [Natural]
    -> ExpansionOrigin
    -> SharedTypeAtom.TypeAtom String
    -> Either String FormulaTranslation
lowerForall lowering definitions path occurrencePath origin atom = case forallPolicy lowering of
    OpaqueForalls -> Right opaque
    PolarizedForalls namespace PositiveFormula openedView opaqueSites transportTypes ->
        case SharedTypeAtom.typeAtomType atom of
            -- Context validation belongs to the checked request/session edge.
            -- LJT receives only the body: accepting a contextual positive
            -- forall therefore permits dictionary-independent introduction
            -- without pretending that class methods are proof premises.
            -- The omitted context makes this view incomplete even when it
            -- appears only after expanding a constructor field or alias.
            SharedType.ForallType binders contexts body
                | site `Set.member` opaqueSites ||
                    symbol `Set.member` transportTypes -> Right incompleteOpaque
                | otherwise -> do
                    (skolems, opened) <- openForallBody
                        namespace occurrencePath origin binders body
                    expanded <- expansionTypeAt openedView
                        (OpenedForallOrigin origin) [] opened
                    translation <- lowerExpansionType lowering definitions path
                        occurrencePath expanded
                    return translation
                        { translationIncomplete = not (null contexts)
                            || translationIncomplete translation
                        , translationOpenableForalls = site
                            : translationOpenableForalls translation
                        , translationIntroducedSkolems = skolems
                            ++ translationIntroducedSkolems translation
                        }
            _ -> Right incompleteOpaque
    PolarizedForalls _ NegativeFormula _ _ _ -> Right incompleteOpaque
    PreserveData inner -> lowerForall inner definitions path occurrencePath origin atom
  where
    forallPolicy (PreserveData inner) = forallPolicy inner
    forallPolicy policy = policy
    site = ForallSite origin occurrencePath
    symbol = opaqueTypeSymbol $ SharedTypeAtom.typeAtomType atom
    opaque = completeTranslation $ PVar symbol
    incompleteOpaque = opaque {translationIncomplete = True}

-- Opening happens after removing the forall wrapper, so its binders are free
-- in @body@ and ordinary capture-avoiding substitution can replace them. The
-- private '$' namespace cannot be produced by Djinn's checked source parser;
-- the reservation walk also protects programmatically constructed inputs.
-- The allocated skolem spellings are returned so instantiation policy can
-- treat them as sequent variables without reparsing rendered atoms.
openForallBody
    :: String
    -> [Natural]
    -> ExpansionOrigin
    -> [String]
    -> SharedType.Type String
    -> Either String ([String], SharedType.Type String)
openForallBody namespace occurrencePath origin binders body = do
    opened <- first show $ SharedType.substituteTypeVariables
        allocateShadow Set.empty replacements body
    return (map snd assignments, opened)
  where
    source = SharedType.ForallType binders [] body
    (_, assignments) = foldl allocateSkolem
        (foldMap Set.singleton source, [])
        $ zip [0 :: Natural ..] binders
    replacements = Map.fromList
        [ (binder, SharedType.TypeVariable fresh)
        | (binder, fresh) <- assignments
        ]

    allocateSkolem (reserved, chosen) (index, binder) =
        let fresh = chooseFresh reserved $ skolemBase index
        in ( Set.insert fresh reserved
           , chosen ++ [(binder, fresh)]
           )

    skolemBase index = "$djinn$skolem$" ++ namespace ++ "$" ++
        show occurrencePath ++ "$" ++ show origin ++ "$" ++ show index

    allocateShadow reserved binder = Just $ chooseFresh reserved $
        "$djinn$shadow$" ++ binder

    chooseFresh reserved candidate
        | candidate `Set.member` reserved =
            chooseFresh reserved $ candidate ++ "'"
        | otherwise = candidate

completeTranslation :: Formula -> FormulaTranslation
completeTranslation formula = FormulaTranslation formula False [] []

combineTranslations
    :: ([Formula] -> Formula)
    -> [FormulaTranslation]
    -> FormulaTranslation
combineTranslations constructor translations = FormulaTranslation
    (constructor $ map translatedFormula translations)
    (any translationIncomplete translations)
    (concatMap translationOpenableForalls translations)
    (concatMap translationIntroducedSkolems translations)

combineBinary
    :: (Formula -> Formula -> Formula)
    -> FormulaTranslation
    -> FormulaTranslation
    -> FormulaTranslation
combineBinary constructor left right = FormulaTranslation
    (constructor (translatedFormula left) $ translatedFormula right)
    (translationIncomplete left || translationIncomplete right)
    (translationOpenableForalls left ++ translationOpenableForalls right)
    (translationIntroducedSkolems left ++ translationIntroducedSkolems right)

reverseFormulaPolarity :: ForallLowering -> ForallLowering
reverseFormulaPolarity lowering = case lowering of
    OpaqueForalls -> OpaqueForalls
    PreserveData inner -> PreserveData $ reverseFormulaPolarity inner
    PolarizedForalls namespace polarity openedView selected transportTypes ->
        PolarizedForalls namespace (oppositePolarity polarity) openedView selected
            transportTypes

lowerApplication
    :: ForallLowering
    -> PreparedFormulaCompiler
    -> ExpansionPath
    -> [Natural]
    -> ExpansionType
    -> Either String FormulaTranslation
lowerApplication lowering definitions path occurrencePath source =
    case expansionApplication source [] of
        (ExpansionCon name origin, arguments) ->
            case lookupFormulaDefinition name definitions of
                Just (parameters, body)
                    | length parameters == length arguments
                    , PreserveData{} <- lowering
                    , ExpansionUnion{} <- body -> atom True
                    | length parameters == length arguments ->
                        if formulaDefinitionIsRecursiveData name definitions
                            then lowerRecursiveData
                                name origin parameters body arguments
                            else expandAndLower False
                                name origin parameters body arguments
                _ -> atom False
        _ -> atom False
  where
    -- Recursive data is deliberately asymmetric. Each recursive component on
    -- a positive expansion path may expose one constructor layer; a field that
    -- would reopen that component, every negative occurrence, and the
    -- exact/legacy view retain the complete application as one atom.
    -- Every such decision is incomplete: the bounded positive view omitted a
    -- deeper layer, while the atomized view omitted constructor structure.
    lowerRecursiveData name origin parameters body arguments
        | recursiveDataCanUnfold lowering definitions name path =
            expandAndLower True name origin parameters body arguments
        | otherwise = atom True

    expandAndLower forceIncomplete name origin parameters body arguments = do
        expanded <- expandDefinitionStep definitions path
            name origin parameters body arguments
        let descentPath = pushExpansion name origin $
                if forceIncomplete
                    then rememberRecursiveComponent definitions name path
                    else path
        translation <- case expanded of
            ExpansionUnion [] -> do
                normalized <- normalizeExpansionAliases
                    definitions path source
                completeTranslation . Empty <$> expansionSymbol normalized
            _ -> lowerExpansionType lowering definitions
                descentPath
                occurrencePath expanded
        return $ if forceIncomplete
            then translation {translationIncomplete = True}
            else translation

    atom forceIncomplete = do
        normalized <- normalizeExpansionAliases definitions path source
        -- Retain recursive source applications structurally, including plain
        -- monotypes. Their checked one-layer views must never recover a type
        -- by parsing a proposition's diagnostic spelling.
        formula <- PVar <$> if forceIncomplete
            then opaqueTypeSymbol <$> expansionSourceType normalized
            else expansionSymbol normalized
        return $ FormulaTranslation formula
            (forceIncomplete || polarizedOpaqueForall lowering normalized) [] []

recursiveDataCanUnfold
    :: ForallLowering
    -> PreparedFormulaCompiler
    -> String
    -> ExpansionPath
    -> Bool
recursiveDataCanUnfold lowering definitions name path = case lowering of
    PreserveData{} -> False
    PolarizedForalls _ PositiveFormula _ _ _ ->
        recursiveComponentLayerAvailable path &&
            not (expansionPathContainsRecursiveComponent definitions name path)
    OpaqueForalls -> False
    PolarizedForalls _ NegativeFormula _ _ _ -> False

-- Two independent recursive components recover the common finite wrapper
-- shape (@Outer (Inner a)@) without allowing a duplicated component chain to
-- grow the proof formula exponentially before search budgets can apply.
maximumRecursiveComponentLayers :: Int
maximumRecursiveComponentLayers = 2

recursiveComponentLayerAvailable :: ExpansionPath -> Bool
recursiveComponentLayerAvailable (ExpansionPath _ _ openedComponents) =
    Set.size openedComponents < maximumRecursiveComponentLayers

-- Within the total layer bound, each recursive SCC may expose one positive
-- constructor layer along a path.  A field in an independent recursive
-- component can therefore contribute its own finite layer, while direct,
-- alias-hidden, and mutual recursion stop as soon as the path would reopen the
-- same component.
expansionPathContainsRecursiveComponent
    :: PreparedFormulaCompiler -> String -> ExpansionPath -> Bool
expansionPathContainsRecursiveComponent definitions name
        (ExpansionPath _ _ openedComponents) = case
            formulaDefinitionRecursiveComponent name definitions of
    Just component -> component `Set.member` openedComponents
    -- Every admitted recursive datatype is indexed during preparation.  Keep
    -- the old global bound as a conservative fallback if that invariant ever
    -- changes internally.
    Nothing -> not $ Set.null openedComponents

polarizedOpaqueForall :: ForallLowering -> ExpansionType -> Bool
polarizedOpaqueForall lowering source = case lowering of
    PreserveData inner -> polarizedOpaqueForall inner source
    OpaqueForalls -> False
    PolarizedForalls{} -> expansionContainsForall source

-- Ordinary historical atoms retain their exact renderer identity. As soon as
-- an opaque application contains a quantified child, however, its proposition
-- key is the shared alpha-normal structure of the whole application. This is
-- what makes impredicative wrappers compare correctly without flattening or
-- otherwise changing their existing logical treatment.
expansionSymbol :: ExpansionType -> Either String Symbol
expansionSymbol source
    | expansionContainsForall source = opaqueTypeSymbol
        <$> expansionSourceType source
    | otherwise = Right $ Symbol $ renderExpansionType source

-- The immediate sub-expansions of a node, in source order: an application's
-- function and argument, tuple components, an arrow's argument and result,
-- every union constructor's fields, and the wrapped argument of an argument
-- or exact-assignment marker.  Variables, constructors, abstract atoms and
-- opaque foralls are leaves here: a forall's atom is a source type rather
-- than an expansion, so analyses that need it match 'ExpansionForall' first
-- and fall back to this descent for everything else.
expansionChildren :: ExpansionType -> [ExpansionType]
expansionChildren source = case source of
    ExpansionApp function argument -> [function, argument]
    ExpansionTuple types -> types
    ExpansionArrow argument result -> [argument, result]
    ExpansionUnion constructors -> concatMap snd constructors
    ExpansionArgument _ argument -> [argument]
    ExpansionExactAssignment argument -> [argument]
    ExpansionVar{} -> []
    ExpansionCon{} -> []
    ExpansionForall{} -> []
    ExpansionAbstract{} -> []

expansionContainsForall :: ExpansionType -> Bool
expansionContainsForall source = case source of
    ExpansionForall{} -> True
    _ -> any expansionContainsForall $ expansionChildren source

-- Recover the shared source structure of a normalized, non-logical expansion
-- subtree. Unions are formula definitions rather than Haskell source types and
-- therefore cannot become opaque atoms. Constructor origins are operational
-- expansion metadata and deliberately disappear from logical identity.
expansionSourceType
    :: ExpansionType
    -> Either String (SharedType.Type String)
expansionSourceType source = SharedType.canonicalizeType <$> case source of
    ExpansionApp function argument -> SharedType.TypeApplication
        <$> expansionSourceType function <*> expansionSourceType argument
    ExpansionVar variable -> Right $ SharedType.TypeVariable variable
    ExpansionCon name _ -> SharedType.TypeConstructor
        <$> first show (SharedName.parseName name)
    ExpansionTuple types -> SharedType.TupleType SharedName.Boxed
        <$> mapM expansionSourceType types
    ExpansionArrow argument result -> SharedType.FunctionType
        <$> expansionSourceType argument <*> expansionSourceType result
    ExpansionForall _ atom -> Right $ SharedTypeAtom.typeAtomType atom
    ExpansionUnion{} -> Left
        "datatype expansion reached opaque type identity"
    ExpansionAbstract name -> SharedType.TypeConstructor
        <$> first show (SharedName.parseName name)
    ExpansionArgument _ argument -> expansionSourceType argument
    ExpansionExactAssignment argument -> expansionSourceType argument

-- A marker in function position is unwrapped without resetting the current
-- definition path; a marker around the complete expression is handled by
-- 'lowerExpansionType' above and does reset it.
expansionApplication
    :: ExpansionType
    -> [ExpansionType]
    -> (ExpansionType, [ExpansionType])
expansionApplication (ExpansionApp function argument) arguments =
    expansionApplication function (argument : arguments)
expansionApplication (ExpansionArgument _ function) arguments =
    expansionApplication function arguments
expansionApplication (ExpansionExactAssignment function) arguments =
    expansionApplication function arguments
expansionApplication headType arguments = (headType, arguments)

substituteExpansion
    :: LazyMap.Map String ExpansionType
    -> ExpansionType
    -> Either String ExpansionType
substituteExpansion replacements source = case source of
    ExpansionApp function argument -> expansionApp
        <$> substituteExpansion replacements function
        <*> substituteExpansion replacements argument
    variable@(ExpansionVar name) ->
        Right $ LazyMap.findWithDefault variable name replacements
    constructor@(ExpansionCon _ _) -> Right constructor
    ExpansionTuple types ->
        ExpansionTuple <$> mapM (substituteExpansion replacements) types
    ExpansionArrow argument result -> ExpansionArrow
        <$> substituteExpansion replacements argument
        <*> substituteExpansion replacements result
    ExpansionForall origin atom -> ExpansionForall origin <$>
        substituteExpansionAtom replacements atom
    ExpansionUnion constructors -> ExpansionUnion <$>
        mapM substituteConstructor constructors
      where
        substituteConstructor (constructor, fields) = do
            substitutedFields <- mapM
                (substituteExpansion replacements) fields
            pure (constructor, substitutedFields)
    abstract@(ExpansionAbstract _) -> Right abstract
    argument@(ExpansionArgument _ _) -> Right argument
    exact@(ExpansionExactAssignment _) -> Right exact

-- Definition parameters remain ordinary free variables when they occur under
-- a nested forall. Substitute them through the shared capture-avoiding worker,
-- then rebuild the atom and its cached alpha key. Substitution itself does not
-- inspect the quantified body logically; polarized lowering may later reopen
-- a validated occurrence in positive position, ignoring its context for proof
-- power under Djinn's dictionary-independent policy.
substituteExpansionAtom
    :: LazyMap.Map String ExpansionType
    -> SharedTypeAtom.TypeAtom String
    -> Either String (SharedTypeAtom.TypeAtom String)
substituteExpansionAtom replacements atom = do
    sharedReplacements <- Map.fromList `fmap` mapM convertReplacement
        [ (variable, replacement)
        | (variable, replacement) <- LazyMap.toList replacements
        , variable `Set.member` SharedTypeAtom.typeAtomFreeVariables atom
        ]
    first show $ SharedTypeAtom.substituteTypeAtomVariables
        freshAtomVariable Set.empty sharedReplacements atom
  where
    convertReplacement (variable, replacement) =
        (\converted -> (variable, converted))
          <$> expansionSourceType replacement

    freshAtomVariable reserved variable = Just $ choose (variable ++ "'")
      where
        choose candidate
            | candidate `Set.member` reserved = choose $ candidate ++ "'"
            | otherwise = candidate

-- Raw low-level definitions may repeat a parameter. Association-list lookup
-- historically selected its first binding; folding inserts from the right.
firstExpansionSubstitutions
    :: [(String, ExpansionType)]
    -> LazyMap.Map String ExpansionType
firstExpansionSubstitutions =
    foldr (uncurry LazyMap.insert) LazyMap.empty

-- One checked definition-expansion step: reject an active expansion cycle,
-- then instantiate the definition body with argument markers anchored at the
-- current path. Logical lowering and the alias fold both continue with the
-- result at @pushExpansion name origin path@, so the two consumers cannot
-- drift in substitution or provenance semantics.
expandDefinitionStep
    :: PreparedFormulaCompiler
    -> ExpansionPath
    -> String
    -> ExpansionOrigin
    -> [String]
    -> ExpansionType
    -> [ExpansionType]
    -> Either String ExpansionType
expandDefinitionStep definitions path name origin parameters body arguments = do
    rejectActiveExpansion definitions path name origin
    let replacements = firstExpansionSubstitutions $
            zip parameters $ map (ExpansionArgument path) arguments
    substituteExpansion replacements $
        instantiateDefinitionOrigins origin name body

rejectActiveExpansion
    :: PreparedFormulaCompiler
    -> ExpansionPath
    -> String
    -> ExpansionOrigin
    -> Either String ()
rejectActiveExpansion
        (PreparedFormulaCompiler _ aliasNames _ _)
        (ExpansionPath frames active _)
        name
        origin
    | origin `Set.notMember` active = Right ()
    | otherwise = Left $
        "recursive type " ++ expansionKind ++ " expansion: " ++
            intercalate ", " cycleMembers
  where
    newerFrames = takeWhile ((/= origin) . frameOrigin) frames
    cycleMembers = name : reverse (map frameName newerFrames) ++ [name]
    expansionKind
        | all (`Set.member` aliasNames) cycleMembers = "synonym"
        | otherwise = "definition"

    frameName (ExpansionFrame frameName' _) = frameName'
    frameOrigin (ExpansionFrame _ frameOrigin') = frameOrigin'

-- Alias expansion has two consumers: atom rendering and a reference summary
-- for whole-table validation. Keeping traversal, lazy substitution,
-- occurrence provenance, and error order in one fold prevents them drifting.
data ExpansionAlgebra result = ExpansionAlgebra
    { algebraVariable :: String -> result
    , algebraConstructorApplication :: String -> [result] -> result
    , algebraApplication :: result -> [result] -> result
    , algebraTuple :: [result] -> result
    , algebraArrow :: result -> result -> result
    , algebraForall ::
        ExpansionOrigin -> SharedTypeAtom.TypeAtom String -> result
    , algebraUnion :: [(String, [result])] -> result
    , algebraAbstract :: String -> result
    }

foldExpansionAliases
    :: PreparedFormulaCompiler
    -> ExpansionAlgebra result
    -> ExpansionPath
    -> ExpansionType
    -> Either String result
foldExpansionAliases definitions algebra path source = case source of
    ExpansionExactAssignment argument ->
        foldExpansionAliases definitions algebra path argument
    ExpansionArgument origin argument ->
        foldExpansionAliases definitions algebra
            (resumeExpansionArgument path origin) argument
    ExpansionApp _ _ -> foldApplication
    ExpansionCon _ _ -> foldApplication
    ExpansionVar variable -> Right $ algebraVariable algebra variable
    ExpansionTuple types ->
        algebraTuple algebra `fmap` mapM foldCurrent types
    ExpansionArrow argument result -> do
        foldedArgument <- foldCurrent argument
        foldedResult <- foldCurrent result
        return $ algebraArrow algebra foldedArgument foldedResult
    ExpansionForall origin atom -> Right $
        algebraForall algebra origin atom
    ExpansionUnion constructors ->
        algebraUnion algebra `fmap` mapM foldConstructor constructors
    ExpansionAbstract name -> Right $ algebraAbstract algebra name
  where
    foldCurrent = foldExpansionAliases definitions algebra path

    foldApplication = case expansionApplication source [] of
        (ExpansionCon name origin, arguments) ->
            case lookupFormulaDefinition name definitions of
                Just (parameters, body)
                    | length parameters == length arguments &&
                      formulaDefinitionIsAlias name definitions -> do
                        expanded <- expandDefinitionStep definitions path
                            name origin parameters body arguments
                        foldExpansionAliases definitions algebra
                            (pushExpansion name origin path) expanded
                _ -> do
                    foldedArguments <- mapM foldCurrent arguments
                    return $ algebraConstructorApplication algebra
                        name foldedArguments
        (headType, arguments) -> do
            foldedHead <- foldCurrent headType
            foldedArguments <- mapM foldCurrent arguments
            return $ algebraApplication algebra foldedHead foldedArguments

    foldConstructor (constructor, fields) = do
        foldedFields <- mapM foldCurrent fields
        return (constructor, foldedFields)

-- Alias-normalize an atom without unfolding its outer datatype/abstract
-- constructor. Argument markers preserve the same path semantics as logical
-- lowering. Rebuilding the existing expansion tree keeps rendering private to
-- this module without allocating either frontend's recursive type value.
normalizeExpansionAliases
    :: PreparedFormulaCompiler
    -> ExpansionPath
    -> ExpansionType
    -> Either String ExpansionType
normalizeExpansionAliases definitions =
    foldExpansionAliases definitions normalizedExpansionAlgebra

type StructuralObservationCache = Map.Map String (Set.Set Int)

type StructuralObservation a =
    StateT StructuralObservationCache (Either String) a

-- Follow exact-assignment provenance through the fully instantiated provider
-- body.  @insideExact@ means the complete current subtree came from a visible
-- type argument.  A marker in function position additionally makes every
-- later argument of the saturated datatype application fidelity-relevant: for
-- @f := Phantom@ in @f Int@, it is the exact choice of @Phantom@ which makes
-- the otherwise scheme-owned @Int@ disappear.
structuralAssignmentFaithful
    :: PreparedFormulaCompiler
    -> Bool
    -> ExpansionPath
    -> ExpansionType
    -> StructuralObservation Bool
structuralAssignmentFaithful definitions insideExact path source = case source of
    ExpansionExactAssignment argument ->
        structuralAssignmentFaithful definitions True path argument
    ExpansionArgument origin argument ->
        structuralAssignmentFaithful definitions insideExact
            (resumeExpansionArgument path origin) argument
    ExpansionVar{} -> pure True
    ExpansionCon{} -> applicationFaithful
    ExpansionApp{} -> applicationFaithful
    ExpansionTuple types -> and <$> mapM current types
    ExpansionArrow argument result -> and <$>
        mapM current [argument, result]
    -- Opaque-forandentity contains the complete substituted source type.
    ExpansionForall{} -> pure True
    ExpansionUnion constructors -> and <$> mapM current
        [field | (_, fields) <- constructors, field <- fields]
    ExpansionAbstract{} -> pure True
  where
    current = structuralAssignmentFaithful definitions insideExact path

    applicationFaithful = case fidelityExpansionApplication source [] False of
        (ExpansionCon name origin, arguments, exactHead) ->
            case lookupFormulaDefinition name definitions of
                Just (parameters, body)
                    | length parameters == length arguments ->
                        if formulaDefinitionIsAlias name definitions
                            then do
                                expanded <- lift $ expandDefinitionStep
                                    definitions path name origin parameters body
                                    arguments
                                structuralAssignmentFaithful definitions
                                    (insideExact || exactHead)
                                    (pushExpansion name origin path) expanded
                            else if formulaDefinitionIsRecursiveData
                                    name definitions || definitionIsEmpty body
                                then pure True
                                else do
                                    observed <- definitionParameterObservations
                                        definitions name parameters body
                                    let exactBoundary = insideExact || exactHead
                                        relevant =
                                            [ exactBoundary ||
                                                expansionContainsExact argument
                                            | argument <- arguments
                                            ]
                                        retained = and
                                            [ not isRelevant ||
                                                index `Set.member` observed
                                            | (index, isRelevant) <-
                                                zip [0 :: Int ..] relevant
                                            ]
                                    if not retained
                                        then pure False
                                        else do
                                            expanded <- lift $
                                                expandDefinitionStep
                                                    definitions path name
                                                    origin parameters body
                                                    arguments
                                            structuralAssignmentFaithful
                                                definitions exactBoundary
                                                (pushExpansion
                                                    name origin path)
                                                expanded
                -- Unknown, unsaturated, and oversaturated applications are
                -- opaque atoms containing their complete normalized source.
                _ -> pure True
        _ -> pure True

    definitionIsEmpty body = case body of
        ExpansionUnion [] -> True
        _ -> False

-- Collect an application spine while remembering whether an exact assignment
-- supplied any part of its head.  Ordinary definition-argument wrappers keep
-- the current expansion path in function position, matching
-- 'expansionApplication'.
fidelityExpansionApplication
    :: ExpansionType
    -> [ExpansionType]
    -> Bool
    -> (ExpansionType, [ExpansionType], Bool)
fidelityExpansionApplication source arguments exactHead = case source of
    ExpansionApp function argument ->
        fidelityExpansionApplication function (argument : arguments) exactHead
    ExpansionArgument _ function ->
        fidelityExpansionApplication function arguments exactHead
    ExpansionExactAssignment function ->
        fidelityExpansionApplication function arguments True
    headType -> (headType, arguments, exactHead)

expansionContainsExact :: ExpansionType -> Bool
expansionContainsExact source = case source of
    ExpansionExactAssignment{} -> True
    _ -> any expansionContainsExact $ expansionChildren source

-- Expand one declaration with all of its formals marked at once, then cache
-- the observed index set for the rest of this fidelity check.  The previous
-- per-formal implementation expanded and traversed an n-parameter declaration
-- n times; this work is linear in the declaration plus its argument vector.
definitionParameterObservations
    :: PreparedFormulaCompiler
    -> String
    -> [String]
    -> ExpansionType
    -> StructuralObservation (Set.Set Int)
definitionParameterObservations definitions name parameters body = do
    cached <- get
    case Map.lookup name cached of
        Just observed -> pure observed
        Nothing -> do
            let markers =
                    [ "$djinn$structural-fidelity$" ++ show index
                    | index <- [0 :: Int .. length parameters - 1]
                    ]
                selected = Set.fromList markers
                origin = QueryOrigin []
            expanded <- lift $ expandDefinitionStep definitions
                emptyExpansionPath name origin parameters body
                (map ExpansionVar markers)
            observedVariables <- structuralVariableObservations definitions
                selected (pushExpansion name origin emptyExpansionPath)
                expanded
            let observed = Set.fromList
                    [ index
                    | (index, marker) <- zip [0 :: Int ..] markers
                    , marker `Set.member` observedVariables
                    ]
            modify $ Map.insert name observed
            pure observed

-- Existential variable observation in a declaration formula. One faithful
-- constructor-field path is enough for a formal to pass the top-level gate;
-- 'structuralAssignmentFaithful' then expands the instantiated body and checks
-- every marker-bearing field rather than treating this set as final evidence.
structuralVariableObservations
    :: PreparedFormulaCompiler
    -> Set.Set String
    -> ExpansionPath
    -> ExpansionType
    -> StructuralObservation (Set.Set String)
structuralVariableObservations definitions selected path source = case source of
    ExpansionExactAssignment argument -> current argument
    ExpansionArgument origin argument ->
        structuralVariableObservations definitions selected
            (resumeExpansionArgument path origin) argument
    ExpansionVar variable -> pure $
        Set.singleton variable `Set.intersection` selected
    ExpansionCon{} -> applicationObservations
    ExpansionApp{} -> applicationObservations
    ExpansionTuple types -> Set.unions <$> mapM current types
    ExpansionArrow argument result -> Set.unions <$>
        mapM current [argument, result]
    ExpansionForall _ atom -> pure $ Set.intersection selected $
        SharedTypeAtom.typeAtomFreeVariables atom
    ExpansionUnion constructors -> Set.unions <$> mapM current
        [field | (_, fields) <- constructors, field <- fields]
    ExpansionAbstract{} -> pure Set.empty
  where
    current = structuralVariableObservations definitions selected path

    applicationObservations = case expansionApplication source [] of
        (ExpansionCon name origin, arguments) ->
            case lookupFormulaDefinition name definitions of
                Just (parameters, body)
                    | length parameters == length arguments ->
                        if formulaDefinitionIsAlias name definitions
                            then do
                                expanded <- lift $ expandDefinitionStep
                                    definitions path name origin parameters body
                                    arguments
                                structuralVariableObservations definitions
                                    selected (pushExpansion name origin path)
                                    expanded
                            else if formulaDefinitionIsRecursiveData
                                    name definitions || definitionIsEmpty body
                                then opaqueObservations
                                else do
                                    argumentObservations <- mapM current arguments
                                    observed <- definitionParameterObservations
                                        definitions name parameters body
                                    pure $ Set.unions
                                        [ variables
                                        | (index, variables) <- zip
                                            [0 :: Int ..] argumentObservations
                                        , index `Set.member` observed
                                        ]
                _ -> opaqueObservations
        _ -> opaqueObservations

    opaqueObservations = do
        normalized <- lift $
            normalizeExpansionAliases definitions path source
        pure $ Set.intersection selected $
            expansionFreeVariables normalized

    definitionIsEmpty body = case body of
        ExpansionUnion [] -> True
        _ -> False

expansionFreeVariables :: ExpansionType -> Set.Set String
expansionFreeVariables source = case source of
    ExpansionVar variable -> Set.singleton variable
    ExpansionForall _ atom -> SharedTypeAtom.typeAtomFreeVariables atom
    _ -> Set.unions $ map expansionFreeVariables $ expansionChildren source

normalizedExpansionAlgebra :: ExpansionAlgebra ExpansionType
normalizedExpansionAlgebra = ExpansionAlgebra
    { algebraVariable = ExpansionVar
    , algebraConstructorApplication = \name arguments ->
        foldl' expansionApp
            (ExpansionCon name $ QueryOrigin []) arguments
    , algebraApplication = foldl' expansionApp
    , algebraTuple = ExpansionTuple
    , algebraArrow = ExpansionArrow
    , algebraForall = ExpansionForall
    , algebraUnion = ExpansionUnion
    , algebraAbstract = ExpansionAbstract
    }

-- Render the normalized atom with Djinn's historical HType precedence and
-- spellings. This deliberately handles raw-only malformed shapes (notably a
-- unary tuple or nested declaration body) even though checked shared types
-- cannot construct them.
renderExpansionType :: ExpansionType -> String
renderExpansionType source = showsExpansionType 0 source ""

showsExpansionType :: Int -> ExpansionType -> ShowS
showsExpansionType precedence source = case source of
    ExpansionExactAssignment argument ->
        showsExpansionType precedence argument
    ExpansionArgument _ argument ->
        showsExpansionType precedence argument
    ExpansionApp (ExpansionCon "[]" _) element ->
        showString "[" . showsExpansionType 0 element . showString "]"
    ExpansionApp function argument -> showParen (precedence > 2) $
        showsExpansionType 2 function . showString " " .
            showsExpansionType 3 argument
    ExpansionVar variable -> showString variable
    ExpansionCon "()" _ -> showString "()"
    ExpansionCon name _
        | not (isQualifiedConId name) ->
            showParen True $ showString name
        | otherwise -> showString name
    ExpansionTuple types -> showParen True $ renderTuple types
    ExpansionArrow argument result -> showParen (precedence > 0) $
        showsExpansionType 1 argument . showString " -> " .
            showsExpansionType 0 result
    ExpansionForall _ atom -> showParen (precedence > 0) $ showString
        $ SharedTypeRender.renderType id $ SharedTypeAtom.typeAtomType atom
    ExpansionUnion constructors -> renderConstructors constructors
    ExpansionAbstract name -> showString name
  where
    renderTuple [] = id
    renderTuple [element] = showsExpansionType 0 element
    renderTuple (element : elements) =
        showsExpansionType 0 element . showString ", " .
            renderTuple elements

    renderConstructors [] = id
    renderConstructors [constructor] = renderConstructor constructor
    renderConstructors (constructor : constructors) =
        renderConstructor constructor . showString " | " .
            renderConstructors constructors

    renderConstructor (constructor, fields) = foldl
        (\render field ->
            render . showString " " . showsExpansionType 10 field)
        (showString constructor)
        fields

-- Collect the definition graph after alias normalization without allocating a
-- normalized frontend type. Every child is visited before the algebra is
-- invoked, retaining higher-order expansion failures and their order.
summarizeExpansionReferences
    :: Set.Set String
    -> PreparedFormulaCompiler
    -> ExpansionPath
    -> ExpansionType
    -> Either String (Set.Set String)
summarizeExpansionReferences interesting definitions =
    foldExpansionAliases definitions $ referenceExpansionAlgebra interesting

referenceExpansionAlgebra
    :: Set.Set String
    -> ExpansionAlgebra (Set.Set String)
referenceExpansionAlgebra interesting = ExpansionAlgebra
    { algebraVariable = const Set.empty
    , algebraConstructorApplication = summarizeConstructor
    , algebraApplication = \headReferences argumentReferences ->
        Set.unions $ headReferences : argumentReferences
    , algebraTuple = Set.unions
    , algebraArrow = Set.union
    , algebraForall = \_ -> Set.intersection interesting .
        Set.map SharedName.renderCanonical .
        SharedType.typeConstructors . SharedTypeAtom.typeAtomType
    , algebraUnion = Set.unions . concatMap snd
    , algebraAbstract = const Set.empty
    }
  where
    -- Saturated prefix arrows normalize structurally and therefore contribute
    -- no nominal @->@ reference, matching HType's historical smart constructor.
    summarizeConstructor name arguments
        | name == "->" && length arguments >= 2 = references
        | name `Set.member` interesting = Set.insert name references
        | otherwise = references
      where
        references = Set.unions arguments

-- Validate the actual definition-expansion graph, not merely repeated runtime
-- types. The latter misses growing cycles such as @A a = A [a]@, while an
-- active-name guard falsely rejects finite @Id (Id a)@. Synonym SCCs are found
-- before normalization; datatype SCCs are classified from alias-free fields.
validateDefinitionExpansion
    :: Set.Set String
    -> [PreparedDefinition]
    -> PreparedFormulaCompiler
    -> Either String (Map.Map String (Set.Set String))
validateDefinitionExpansion recursiveData definitions prepared = do
    rejectFirstCycle True Set.empty aliases aliasReferences
    summaries <- Map.fromList `fmap` mapM summarizeDefinition definitions
    let summarizedReferences definition = Map.findWithDefault Set.empty
            (preparedDefinitionName definition) summaries
    rejectFirstCycle False recursiveData definitions summarizedReferences
    return summaries
  where
    aliases = filter preparedDefinitionIsAlias definitions
    aliasNames = Set.fromList $ map preparedDefinitionName aliases
    definitionNames = Set.fromList $ map preparedDefinitionName definitions
    aliasReferences = Set.intersection aliasNames .
        definitionReferences . preparedDefinitionBody

    summarizeDefinition definition = do
        let name = preparedDefinitionName definition
        summary <- first (("type definition " ++ name ++ ": ") ++) $
            summarizeExpansionReferences definitionNames
                prepared emptyExpansionPath $
                    preparedDefinitionBody definition
        return (name, summary)

-- Index every admitted recursive datatype by the source-first representative
-- of its alias-normalized definition-graph component.  Marked acyclic data
-- remain singleton components, preserving the low-level preparation API's
-- defensive behavior even though checked environments normally mark only
-- genuinely recursive heads.
recursiveDataComponents
    :: Set.Set String
    -> [PreparedDefinition]
    -> Map.Map String (Set.Set String)
    -> Map.Map String String
recursiveDataComponents recursiveData definitions references = Map.fromList
    [ (name, representative)
    | component <- stronglyConnComp graph
    , let names = case component of
            AcyclicSCC name -> [name]
            CyclicSCC members -> members
    , Just representative <- [listToMaybe $ sortOn position names]
    , name <- names
    ]
  where
    positions = Map.fromList $ zip
        (map preparedDefinitionName definitions) [0 :: Natural ..]
    position name = Map.findWithDefault fallbackPosition name positions
    fallbackPosition = 1 + maximum (0 : Map.elems positions)
    graph =
        [ (name, name, Set.toAscList $ Set.intersection recursiveData $
            Map.findWithDefault Set.empty name references)
        | definition <- definitions
        , let name = preparedDefinitionName definition
        , name `Set.member` recursiveData
        ]

rejectFirstCycle
    :: Bool
    -> Set.Set String
    -> [PreparedDefinition]
    -> (PreparedDefinition -> Set.Set String)
    -> Either String ()
rejectFirstCycle synonymsOnly allowed definitions references =
    case firstRecursiveComponent allowed definitions references of
        Nothing -> Right ()
        Just names -> Left $
            recursiveDefinitionsMessage synonymsOnly names

firstRecursiveComponent
    :: Set.Set String
    -> [PreparedDefinition]
    -> (PreparedDefinition -> Set.Set String)
    -> Maybe [String]
firstRecursiveComponent allowed definitions references =
    listToMaybe $ sortOn componentPosition orderedCycles
  where
    positions = Map.fromList $ zip
        (map preparedDefinitionName definitions) [0 :: Natural ..]
    position name = Map.findWithDefault fallbackPosition name positions
    fallbackPosition = 1 + maximum (0 : Map.elems positions)
    componentPosition names = minimum $ map position names
    orderedCycles =
        [sortOn position names |
            CyclicSCC names <- stronglyConnComp
                [(name, name, Set.toAscList $ references definition) |
                    definition <- definitions,
                    let name = preparedDefinitionName definition],
            not $ Set.fromList names `Set.isSubsetOf` allowed]

recursiveDefinitionsMessage :: Bool -> [String] -> String
recursiveDefinitionsMessage synonymsOnly names =
    "recursive type " ++ noun ++ ": " ++ intercalate ", " names
  where
    noun
        | synonymsOnly && length names == 1 = "synonym"
        | synonymsOnly = "synonyms"
        | length names == 1 = "definition"
        | otherwise = "definitions"

-- Match association-list lookup: later duplicates are unreachable and cannot
-- add an expansion edge, a malformed view failure, or a spurious cycle.
firstBindings
    :: [FormulaDefinition source]
    -> [FormulaDefinition source]
firstBindings = SharedCollection.distinctOn definitionName

definitionName :: FormulaDefinition source -> String
definitionName definition = case definition of
    FormulaAlias name _ _ -> name
    FormulaData name _ _ -> name
    FormulaAbstract name _ _ -> name

preparedDefinitionName :: PreparedDefinition -> String
preparedDefinitionName (PreparedDefinition name _ _ _) = name

preparedDefinitionBody :: PreparedDefinition -> ExpansionType
preparedDefinitionBody (PreparedDefinition _ _ body _) = body

preparedDefinitionIsAlias :: PreparedDefinition -> Bool
preparedDefinitionIsAlias (PreparedDefinition _ _ _ isAlias) = isAlias

-- Collect every nominal reference, not only applications saturated in the
-- source spelling. Substitution can turn a higher-order argument into a fresh
-- saturated redex.
definitionReferences :: ExpansionType -> Set.Set String
definitionReferences source = case source of
    ExpansionCon name _ -> Set.singleton name
    ExpansionForall _ atom -> Set.map SharedName.renderCanonical
        $ SharedType.typeConstructors
        $ SharedTypeAtom.typeAtomType atom
    _ -> Set.unions $ map definitionReferences $ expansionChildren source
