set_option autoImplicit false
class ContextProduction.Dictionary (α : Type) where tag : Nat
structure ContextProduction.Token where payload : Nat
def ContextSyntax.condition (f : (∀ (β : Type), [ContextProduction.Dictionary β] → β → ContextProduction.Token) → (∀ (β : Type), [ContextProduction.Dictionary β] → β → ContextProduction.Token)) : Prop := (ContextProduction.Token.payload (@f (fun (β : Type) [d : ContextProduction.Dictionary β] (_ : β) => ContextProduction.Token.mk ((@ContextProduction.Dictionary.tag β d) + 0)) Nat (@ContextProduction.Dictionary.mk Nat 7) 37) = 7) ∧ (ContextProduction.Token.payload (@f (fun (β : Type) [d : ContextProduction.Dictionary β] (_ : β) => ContextProduction.Token.mk ((@ContextProduction.Dictionary.tag β d) + 0)) Nat (@ContextProduction.Dictionary.mk Nat 11) 37) = 11) ∧ (ContextProduction.Token.payload (@f (fun (β : Type) [d : ContextProduction.Dictionary β] (_ : β) => ContextProduction.Token.mk ((@ContextProduction.Dictionary.tag β d) + 100)) Nat (@ContextProduction.Dictionary.mk Nat 7) 53) = 107) ∧ (ContextProduction.Token.payload (@f (fun (β : Type) [d : ContextProduction.Dictionary β] (_ : β) => ContextProduction.Token.mk ((@ContextProduction.Dictionary.tag β d) + 100)) Bool (@ContextProduction.Dictionary.mk Bool 11) true) = 111)
def ContextSyntax.condition_decidable (f : (∀ (β : Type), [ContextProduction.Dictionary β] → β → ContextProduction.Token) → (∀ (β : Type), [ContextProduction.Dictionary β] → β → ContextProduction.Token)) : Decidable (ContextSyntax.condition f) := by unfold ContextSyntax.condition; infer_instance
#print axioms ContextProduction.Dictionary
#print axioms ContextProduction.Dictionary.mk
#print axioms ContextProduction.Dictionary.tag
#print axioms ContextProduction.Token
#print axioms ContextProduction.Token.mk
#print axioms ContextProduction.Token.payload
#print axioms ContextSyntax.condition
#print axioms ContextSyntax.condition_decidable
