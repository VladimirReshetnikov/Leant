set_option autoImplicit false
class ContextProduction.Dictionary (α : Type) where tag : Nat
structure ContextProduction.Token where payload : Nat
def ContextReplay.accepted : (∀ (β : Type), [ContextProduction.Dictionary β] → β → ContextProduction.Token) → (∀ (β : Type), [ContextProduction.Dictionary β] → β → ContextProduction.Token) :=
((fun (leantLocal21 : (∀ (leantBound0x0 : Type) [@_root_.«ContextProduction».«Dictionary» (leantBound0x0)], (leantBound0x0 → @_root_.«ContextProduction».«Token»))) => @leantLocal21) : ((∀ (leantBound0x0 : Type) [@_root_.«ContextProduction».«Dictionary» (leantBound0x0)], (leantBound0x0 → @_root_.«ContextProduction».«Token»)) → (∀ (leantBound0x0 : Type) [@_root_.«ContextProduction».«Dictionary» (leantBound0x0)], (leantBound0x0 → @_root_.«ContextProduction».«Token»))))
theorem ContextReplay.accepted_passes : (ContextProduction.Token.payload (@ContextReplay.accepted (fun (β : Type) [d : ContextProduction.Dictionary β] (_ : β) => ContextProduction.Token.mk ((@ContextProduction.Dictionary.tag β d) + 0)) Nat (@ContextProduction.Dictionary.mk Nat 7) 37) = 7) ∧ (ContextProduction.Token.payload (@ContextReplay.accepted (fun (β : Type) [d : ContextProduction.Dictionary β] (_ : β) => ContextProduction.Token.mk ((@ContextProduction.Dictionary.tag β d) + 0)) Nat (@ContextProduction.Dictionary.mk Nat 11) 37) = 11) ∧ (ContextProduction.Token.payload (@ContextReplay.accepted (fun (β : Type) [d : ContextProduction.Dictionary β] (_ : β) => ContextProduction.Token.mk ((@ContextProduction.Dictionary.tag β d) + 100)) Nat (@ContextProduction.Dictionary.mk Nat 7) 53) = 107) ∧ (ContextProduction.Token.payload (@ContextReplay.accepted (fun (β : Type) [d : ContextProduction.Dictionary β] (_ : β) => ContextProduction.Token.mk ((@ContextProduction.Dictionary.tag β d) + 100)) Bool (@ContextProduction.Dictionary.mk Bool 11) true) = 111) := by decide
#print axioms ContextProduction.Dictionary
#print axioms ContextProduction.Dictionary.mk
#print axioms ContextProduction.Dictionary.tag
#print axioms ContextProduction.Token
#print axioms ContextProduction.Token.mk
#print axioms ContextProduction.Token.payload
#print axioms ContextReplay.accepted
#print axioms ContextReplay.accepted_passes
