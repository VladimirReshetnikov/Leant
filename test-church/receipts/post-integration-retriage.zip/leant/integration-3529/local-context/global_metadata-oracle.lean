set_option autoImplicit false
class ContextProduction.Dictionary (α : Type) where tag : Nat
structure ContextProduction.Token where payload : Nat
def ContextOracle.reference : ∀ (α : Type), [ContextProduction.Dictionary α] → ContextProduction.Token := fun (α : Type) [d : ContextProduction.Dictionary α] => ContextProduction.Token.mk (@ContextProduction.Dictionary.tag α d)
theorem ContextOracle.reference_checked : (ContextProduction.Token.payload (@ContextOracle.reference Nat (@ContextProduction.Dictionary.mk Nat 7)) = 7) ∧ (ContextProduction.Token.payload (@ContextOracle.reference Nat (@ContextProduction.Dictionary.mk Nat 11)) = 11) := by decide
#print axioms ContextProduction.Dictionary
#print axioms ContextProduction.Dictionary.mk
#print axioms ContextProduction.Dictionary.tag
#print axioms ContextProduction.Token
#print axioms ContextProduction.Token.mk
#print axioms ContextProduction.Token.payload
#print axioms ContextOracle.reference
#print axioms ContextOracle.reference_checked
