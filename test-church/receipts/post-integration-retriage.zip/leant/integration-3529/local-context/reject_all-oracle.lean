set_option autoImplicit false
class ContextProduction.Dictionary (α : Type) where tag : Nat
structure ContextProduction.Token where payload : Nat
def ContextOracle.reference : ∀ (α : Type), [ContextProduction.Dictionary α] → α → α := fun (α : Type) [unusedDictionary : ContextProduction.Dictionary α] (x : α) => x
theorem ContextOracle.reference_checked : ¬ (False) := by decide
#print axioms ContextProduction.Dictionary
#print axioms ContextProduction.Dictionary.mk
#print axioms ContextProduction.Dictionary.tag
#print axioms ContextProduction.Token
#print axioms ContextProduction.Token.mk
#print axioms ContextProduction.Token.payload
#print axioms ContextOracle.reference
#print axioms ContextOracle.reference_checked
