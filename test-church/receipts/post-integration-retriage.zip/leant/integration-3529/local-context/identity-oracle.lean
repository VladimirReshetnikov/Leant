set_option autoImplicit false
class ContextProduction.Dictionary (α : Type) where tag : Nat
structure ContextProduction.Token where payload : Nat
def ContextOracle.reference : ∀ (α : Type), [ContextProduction.Dictionary α] → α → α := fun (α : Type) [unusedDictionary : ContextProduction.Dictionary α] (x : α) => x
theorem ContextOracle.reference_checked : (@ContextOracle.reference Nat (@ContextProduction.Dictionary.mk Nat 7) 37 = 37) ∧ (@ContextOracle.reference Nat (@ContextProduction.Dictionary.mk Nat 11) 53 = 53) ∧ (@ContextOracle.reference Bool (@ContextProduction.Dictionary.mk Bool 11) true = true) ∧ (@ContextOracle.reference Bool (@ContextProduction.Dictionary.mk Bool 7) false = false) := by decide
theorem ContextOracle.reference_wrong_result_rejected : ¬ (@ContextOracle.reference Nat (@ContextProduction.Dictionary.mk Nat 7) 37 = 38) := by decide
#print axioms ContextProduction.Dictionary
#print axioms ContextProduction.Dictionary.mk
#print axioms ContextProduction.Dictionary.tag
#print axioms ContextProduction.Token
#print axioms ContextProduction.Token.mk
#print axioms ContextProduction.Token.payload
#print axioms ContextOracle.reference
#print axioms ContextOracle.reference_checked
#print axioms ContextOracle.reference_wrong_result_rejected
