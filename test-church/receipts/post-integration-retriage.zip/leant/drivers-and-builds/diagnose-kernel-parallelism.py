from pathlib import Path
import json,os,sys
ROOT=Path('C:/Leant');BASE=ROOT/'dist-newstyle/polymorphic-introduction-integration-v2'
sys.path[:0]=[str(ROOT/'test-church'),str(ROOT/'lib/Djex/test-church')]
import behavior_runtime as runtime
from run_corpus import reported_axioms
prior=json.loads((BASE/'results.json').read_text())
successful=json.loads((ROOT/'dist-newstyle/focused-introduction-integration-v1/methods/results.json').read_text())
metadata=successful['projection_metadata_preflight']
kernel=Path(prior['runtime_identity']['kernel_runtime']);source=BASE/'methods/ProjectionMetadata.lean'
assert source.read_bytes()==Path(metadata['path']).read_bytes()
OUT=ROOT/'dist-newstyle/kernel-parallelism-diagnosis-v1';OUT.mkdir(exist_ok=False)
inputs={str(p):runtime.sha256(p) for p in [Path(__file__),kernel,source]}
report={'status':'running','source_identical_to_previous_pass':True,'before':inputs,'rows':[],
 'configuration_reference':'https://lean-lang.org/doc/reference/latest/IO/Tasks-and-Threads/'}
processes=runtime.Processes(OUT,150);receipt=OUT/'results.json'
runtime.write_json(receipt,report)
try:
 for threads in ['1',None]:
  env=dict(os.environ)
  if threads is None:env.pop('LEAN_NUM_THREADS',None)
  else:env['LEAN_NUM_THREADS']=threads
  label='threads-'+(threads or 'default')
  row={'label':label,'lean_num_threads':threads,'status':'running'}
  report['rows'].append(row);runtime.write_json(receipt,report)
  try:
   result=processes.run(label,[str(kernel),str(source)],cwd=ROOT,env=env)
   inventories={n:reported_axioms(result.stdout+result.stderr,n) for n in metadata['declarations']}
   passed=result.returncode==0 and result.stdout.count('PROJECTION_METADATA_CONTROLS_PASSED_4')==1 and all(v==set() for v in inventories.values())
   row.update(status='passed' if passed else 'failed',exit_code=result.returncode,
    axiom_inventories={n:None if v is None else sorted(v) for n,v in inventories.items()})
  except Exception as failure:row.update(status='failed',failure=repr(failure))
  runtime.write_json(receipt,report)
finally:
 report['after']={p:runtime.sha256(p) for p in inputs};report['unchanged']=report['before']==report['after'];report['processes']=processes.rows;report['status']='completed_diagnostic'
 runtime.write_json(receipt,report)
 print(json.dumps(report['rows']),flush=True)
