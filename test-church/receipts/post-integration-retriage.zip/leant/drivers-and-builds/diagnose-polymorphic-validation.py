from pathlib import Path
from datetime import datetime,timezone
import json,os,sys
ROOT=Path('C:/Leant')
sys.path[:0]=[str(ROOT/'test-church'),str(ROOT/'lib/Djex/test-church')]
import behavior_runtime as runtime
from run_corpus import reported_axioms
BASE=ROOT/'dist-newstyle/polymorphic-introduction-integration-v2'
prior=json.loads((BASE/'results.json').read_text())
after={p:runtime.sha256(p) for p in prior['before']}
runtime.write_json(BASE/'cancellation.json',{
 'status':'stopped_after_failed_required_gates',
 'time_utc':datetime.now(timezone.utc).isoformat(),
 'reason':'699/701 unit tests and unchanged projection metadata preflight timeout; stop unhelpful dependent broad validation for focused diagnosis',
 'owned_driver_pid':23612,'source_and_runtime_hashes_unchanged':after==prior['before'],
 'after':after,'partial_receipts_are_not_complete_acceptance':True,
 'termination':'identity-checked taskkill /PID 23612 /T /F; master observed child exit 1 and stopped; all listed descendants absent'})
OUT=ROOT/'dist-newstyle/polymorphic-validation-diagnosis-v1'
OUT.mkdir(exist_ok=False)
build=ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4'
test=build/'leant-0.1.0/t/leant-synth-tests/build/leant-synth-tests/leant-synth-tests.exe'
fake=build/'djex-2026.7.17/x/djex-fake-z3/build/djex-fake-z3'
kernel=Path(prior['runtime_identity']['kernel_runtime'])
source=BASE/'methods/ProjectionMetadata.lean'
source0=ROOT/'dist-newstyle/focused-introduction-integration-v1/methods/ProjectionMetadata.lean'
assert source.read_bytes()==source0.read_bytes()
env={k:v for k,v in os.environ.items() if not k.upper().startswith('TASTY_')}
env.update(leant_datadir=str(ROOT),djex_datadir=str(ROOT/'lib/Djex'))
env['PATH']=str(fake)+os.pathsep+env['PATH']
inputs={str(p):runtime.sha256(p) for p in [Path(__file__),test,fake/'djex-fake-z3.exe',kernel,source]}
report={'status':'running','before':inputs,'dependency':prior['dependency'],'rows':[],
 'current_inherited_lean_num_threads':os.environ.get('LEAN_NUM_THREADS'),
 'kernel_inputs_identical_to_first_successful_run':True}
processes=runtime.Processes(OUT,360)
receipt=OUT/'results.json';runtime.write_json(receipt,report)
try:
 for label,pattern in [('length-origin','probe query-owned origins after MRU misses and compact live ordinals'),('layered-provider','recover successive polymorphic layers without unrelated prelude constructors')]:
  result=processes.run(label,[str(test),'-j1','-p','/'+pattern+'/'],cwd=ROOT,env=env)
  report['rows'].append({'case':label,'exit_code':result.returncode,'status':'passed' if result.returncode==0 and 'All 1 tests passed' in result.stdout else 'failed'})
  runtime.write_json(receipt,report)
 processes.timeout=150
 metadata=json.loads((BASE/'methods/results.json').read_text())['projection_metadata_preflight']
 for threads in ['1',None]:
  child_env=dict(env)
  if threads is None:child_env.pop('LEAN_NUM_THREADS',None)
  else:child_env['LEAN_NUM_THREADS']=threads
  label='kernel-threads-'+(threads or 'default')
  result=processes.run(label,[str(kernel),str(source)],cwd=ROOT,env=child_env)
  inventories={n:reported_axioms(result.stdout+result.stderr,n) for n in metadata['declarations']}
  passed=result.returncode==0 and result.stdout.count('PROJECTION_METADATA_CONTROLS_PASSED_4')==1 and all(v==set() for v in inventories.values())
  report['rows'].append({'case':label,'status':'passed' if passed else 'failed','exit_code':result.returncode,'lean_num_threads':threads,
   'axiom_inventories':{n:None if v is None else sorted(v) for n,v in inventories.items()}})
  runtime.write_json(receipt,report)
finally:
 report['after']={p:runtime.sha256(p) for p in inputs};report['unchanged']=inputs==report['after'];report['processes']=processes.rows;report['status']='completed_diagnostic'
 runtime.write_json(receipt,report)
 print(json.dumps(report['rows']),flush=True)
