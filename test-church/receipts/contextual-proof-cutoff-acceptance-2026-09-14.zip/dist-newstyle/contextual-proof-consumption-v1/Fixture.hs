module Fixture where
class Marker a
instance Marker Int
data Token = Token Int
data Box a = Box a
data Witness a r = Witness r a
