"""Bounded diagnosis of full-proof checking before the contextual cutoff."""
from pathlib import Path
import json
import os
import re
import subprocess
import sys

ROOT = Path('C:/Djex')
sys.path.insert(0, str(ROOT / 'test-church'))
import behavior_runtime as rt

core = ROOT / 'djinn/src-core/Djinn/Core.hs'
original = core.read_bytes()
original_hash = rt.sha256(core)
source = core.read_text(encoding='utf-8')
old = '                mapM_ (void . checkProofWithEvidence openedEnvironment opened) $ searchProofs outcome'
new = '''                Trace.trace ("contextual-check-start cutoff=" ++ show candidateLimit ++ " fuel=" ++ show (searchBudget mode)) $ Right ()
                mapM_ (\\(index, proof) -> Trace.trace ("contextual-proof-check " ++ show index) $
                    void $ checkProofWithEvidence openedEnvironment opened proof) $
                    zip [1 :: Integer ..] $ searchProofs outcome
                Trace.trace "contextual-check-end" $ Right ()'''
assert source.count(old) == 1
assert 'import qualified Debug.Trace as Trace' not in source
source = source.replace('import Control.DeepSeq (deepseq)', 'import Control.DeepSeq (deepseq)\nimport qualified Debug.Trace as Trace').replace(old, new)
OUT = rt.prepare_output_directory(ROOT / 'dist-newstyle/contextual-proof-consumption-v1')
(OUT / 'Core.original.hs').write_bytes(original)
(OUT / 'Core.instrumented.hs').write_text(source, encoding='utf-8', newline='\n')
(OUT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
prior = ROOT / 'dist-newstyle/contextual-polytype-public-v1/djinn'
baseline = json.loads((prior / 'results.json').read_text(encoding='utf-8'))
signature = baseline['queries'][0]['signature']
fixture = prior / 'environment/Fixture.hs'
(OUT / 'Fixture.hs').write_bytes(fixture.read_bytes())
report = dict(status='running', scope=__doc__, signature=signature,
    original_core_sha256=original_hash, instrumented_core_sha256=rt.sha256(OUT / 'Core.instrumented.hs'),
    fixture_sha256=rt.sha256(fixture), rows=[])
build_runner = rt.Processes(OUT, 2400)
query_runner = rt.Processes(OUT, 12)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', djex_datadir=str(ROOT))

def save():
    report['processes'] = build_runner.rows + query_runner.rows
    rt.write_json(OUT / 'results.json', report)

assert not subprocess.check_output(['git','status','--porcelain','--','djinn/src-core/Djinn/Core.hs'],cwd=ROOT)
try:
    core.write_text(source, encoding='utf-8', newline='\n')
    save()
    built = build_runner.run('strict-trace-build', ['cabal','build','djex:exe:djex','--ghc-options=-Werror','-j1'], cwd=ROOT,env=env)
    assert built.returncode == 0
    exe = Path(subprocess.check_output(['cabal','list-bin','djex:exe:djex'],cwd=ROOT).decode().strip())
    report['trace_executable'] = dict(path=str(exe),sha256=rt.sha256(exe))
    for label,budget in [('finite',4096),('unbounded',0)]:
        save()
        row = dict(label=label,budget=budget,candidate_cutoff=1)
        command = [str(exe),'djinn','--environment',str(prior/'environment'),'--render','expression',
            '--select','first','--candidate-limit','1','--choice-budget',str(budget),signature]
        try:
            result = query_runner.run(label,command,cwd=ROOT,env=env)
            row.update(exit_code=result.returncode,has_output=bool(result.stdout.strip()))
        except TimeoutError:
            row.update(timed_out=True)
        stderr=(OUT/(label+'.stderr.txt')).read_text(encoding='utf-8')
        indices=[int(x) for x in re.findall(r'contextual-proof-check (\d+)',stderr)]
        row.update(proof_check_count=len(indices),maximum_plan_index=max(indices,default=0),
            starts=stderr.count('contextual-check-start'),ends=stderr.count('contextual-check-end'))
        report['rows'].append(row)
        save()
    report['status']='completed'
except BaseException as error:
    report.update(status='failed',failure=repr(error))
finally:
    assert rt.sha256(core)==report['instrumented_core_sha256'], 'core changed during owned trace; refusing to overwrite'
    core.write_bytes(original)
    report['source_restored']=rt.sha256(core)==original_hash
    save()
print(json.dumps({k:v for k,v in report.items() if k not in ['processes','signature']},indent=2),flush=True)
sys.exit(0 if report['status']=='completed' else 1)
