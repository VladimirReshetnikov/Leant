"""Capture the actual Djinn contextual selection miss before changing its vocabulary."""
from pathlib import Path
import json
import os
import subprocess
import sys

ROOT = Path('C:/Djex')
sys.path.insert(0, str(ROOT / 'test-church'))
import behavior_runtime as rt
OUT = rt.prepare_output_directory(ROOT / 'dist-newstyle/contextual-proof-cutoff-baseline-v4')
files = [Path(__file__), ROOT / 'djinn/test-unit/Spec.hs', ROOT / 'djinn/src-core/Djinn/Core.hs',
         ROOT / 'djinn/src-internal/Djinn/Internal/Instantiation.hs', ROOT / 'djex.cabal']
sources = {str(p): rt.sha256(p) for p in files}
for p in files:
    target = OUT / 'source' / p.relative_to(ROOT)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(p.read_bytes())
report = dict(status='running', scope='Unbounded contextual query with a one-proof cutoff and fourteen tuple fields requiring the qualified local consumer; no recursive values or additional search lanes.',
    source_hashes=sources, executable_hashes={}, gates=[])
runner = rt.Processes(OUT, 2400)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', djex_datadir=str(ROOT))
def save():
    report['processes'] = runner.rows
    rt.write_json(OUT / 'results.json', report)
try:
    save()
    build = runner.run('strict-build', ['cabal','build','djex:test:djinn-tests','--ghc-options=-Werror','-j1'], cwd=ROOT, env=env)
    report['gates'].append(dict(label='strict-build', exit_code=build.returncode)); save()
    assert build.returncode == 0
    unit = Path(subprocess.check_output(['cabal','list-bin','djex:test:djinn-tests'],cwd=ROOT).decode().strip())
    report['executable_hashes'][str(unit)] = rt.sha256(unit)
    result = runner.run('contextual-proof-cutoff', [str(unit),'--num-threads','1','-p',
        '/respect the contextual raw cutoff before checking the proof tail/'], cwd=ROOT, env=env)
    report['gates'].append(dict(label='contextual-proof-cutoff',exit_code=result.returncode))
    report['status'] = 'passed' if result.returncode == 0 else 'failed'
except BaseException as error:
    report.update(status='failed',failure=repr(error))
finally:
    report['sources_unchanged'] = all(rt.sha256(Path(p)) == h for p,h in sources.items())
    report['runtimes_unchanged'] = all(rt.sha256(Path(p)) == h for p,h in report['executable_hashes'].items())
    if not report['sources_unchanged'] or not report['runtimes_unchanged']:
        report['status'] = 'failed'
    save()
print(report['status'],report.get('failure',''),flush=True)
sys.exit(0 if report['status']=='passed' else 1)
