-- | Checked nominal source authority, independent of the proof search and
-- lowering history attached to a particular candidate.
module Djinn.Internal.SourceTypingContext
  ( SourceTypingContext
  , sourceTypingContext
  , sourceTypingContextWithCheckedGoal
  , sourceTypingCheckedGoal
  , sourceTypingContextWithProviderKinds
  , sourceTypingPreparedEnvironment
  , sourceTypingGoal
  , sourceTypingProviderKinds
  , sourceTypingTermSchemes
  , sourceTypingConstructorNames
  ) where

import qualified Data.Map.Strict as Map
import qualified Data.Set as Set

import Djinn.Internal.Environment
  ( PreparedEnvironment, preparedEnvironmentInventory
  , elaboratePreparedSynthesisTypes )
import Djinn.Internal.HTypes (HKind(KStar))
import qualified Language.Haskell.Synthesis.Declaration as Declaration
import qualified Language.Haskell.Synthesis.Environment as Environment
import qualified Language.Haskell.Synthesis.Inventory as Inventory
import Language.Haskell.Synthesis.KindInference (GroundKind)
import Language.Haskell.Synthesis.Name (Name)
import qualified Language.Haskell.Synthesis.SourceKind as SourceKind
import qualified Language.Haskell.Synthesis.Type as Type

-- The prepared environment is the original, nominal source inventory. In
-- particular it is not the structural datatype expansion searched by LJT.
-- The goal has already crossed the query's kind and synonym checks.
data SourceTypingContext = SourceTypingContext
  PreparedEnvironment
  (Type.Type String)
  (Map.Map Name [GroundKind])
  (Maybe (SourceKind.SourceTypeKinds String))

sourceTypingContext
  :: PreparedEnvironment -> Type.Type String -> SourceTypingContext
sourceTypingContext prepared goal = SourceTypingContext prepared goal Map.empty Nothing

-- | Kinds admitted by the provider-assignment checker, keyed by the exact
-- source provider. Ordinary inferred requests carry no extra kind authority.
sourceTypingContextWithProviderKinds
  :: PreparedEnvironment
  -> Type.Type String
  -> Map.Map Name [GroundKind]
  -> SourceTypingContext
sourceTypingContextWithProviderKinds prepared goal kinds = SourceTypingContext prepared goal kinds Nothing

-- | Only checked metadata under this exact nominal inventory can authorize
-- lexical kind transport. The checked type itself is the source goal.
sourceTypingContextWithCheckedGoal
  :: PreparedEnvironment -> SourceKind.SourceTypeKinds String
  -> Map.Map Name [GroundKind] -> Either String SourceTypingContext
sourceTypingContextWithCheckedGoal prepared checked kinds
  | SourceKind.sourceKindAssumptions checked /= Inventory.inventoryKindAssumptions
      (preparedEnvironmentInventory prepared) = Left "source goal kinds belong to a different inventory"
  | otherwise = Right $ SourceTypingContext prepared (SourceKind.sourceKindsType checked) kinds (Just checked)

sourceTypingCheckedGoal :: SourceTypingContext -> Maybe (SourceKind.SourceTypeKinds String)
sourceTypingCheckedGoal (SourceTypingContext _ _ _ checked) = checked

sourceTypingPreparedEnvironment :: SourceTypingContext -> PreparedEnvironment
sourceTypingPreparedEnvironment (SourceTypingContext prepared _ _ _) = prepared

sourceTypingGoal :: SourceTypingContext -> Type.Type String
sourceTypingGoal (SourceTypingContext _ goal _ _) = goal

sourceTypingProviderKinds :: SourceTypingContext -> Map.Map Name [GroundKind]
sourceTypingProviderKinds (SourceTypingContext _ _ kinds _) = kinds

-- | Constructor roles come from the sealed declaration inventory. This name
-- projection does not repeat kind inference or source scheme elaboration.
sourceTypingConstructorNames :: SourceTypingContext -> Set.Set Name
sourceTypingConstructorNames (SourceTypingContext prepared _ _ _) = Set.fromList
  [ Declaration.constructorName constructor
  | Declaration.DataTypeDeclaration _ _ _ constructors <-
      Environment.environmentDeclarations $
        Inventory.inventoryEnvironment $ preparedEnvironmentInventory prepared
  , constructor <- constructors
  ]

-- | Exact source names and independently scoped schemes. Class methods
-- remain excluded, consistently with Djinn's dictionary-independent search.
-- Constructor signatures retain their nominal datatype applications.
sourceTypingTermSchemes
  :: SourceTypingContext -> Either String (Map.Map Name (Type.Type String))
sourceTypingTermSchemes (SourceTypingContext prepared _ _ _) =
  Map.fromList . concat <$> mapM elaborate declarations
 where
  declarations = Environment.environmentDeclarations
    $ Inventory.inventoryEnvironment $ preparedEnvironmentInventory prepared
  elaborate declaration = case declaration of
    Declaration.ValueDeclaration{} -> signatures declaration
    Declaration.DataTypeDeclaration{} -> signatures declaration
    _ -> Right []
  signatures declaration = mapM elaborateSignature
    $ Declaration.declarationTermSchemes declaration
  elaborateSignature signature = do
    result <- elaboratePreparedSynthesisTypes prepared
      [(KStar, Declaration.valueType signature)]
    case result of
      [ty] -> Right (Declaration.valueName signature, ty)
      _ -> Left "source signature elaboration changed its singleton shape"
