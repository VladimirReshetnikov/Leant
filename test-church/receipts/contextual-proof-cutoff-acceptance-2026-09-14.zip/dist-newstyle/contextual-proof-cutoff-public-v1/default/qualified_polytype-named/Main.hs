{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, LiberalTypeSynonyms, NoPolyKinds, AllowAmbiguousTypes #-}
module Main where
import Fixture
probe :: forall a r. Fixture.Marker a => (forall s. Fixture.Marker a => s -> Fixture.Witness s r) -> (forall b. b -> Fixture.Token) -> Fixture.Witness (forall b. b -> Fixture.Token) r
probe a b =
  case a a of
  Witness _ _ -> a b
main :: IO ()
main = print (case probe @Int @Int (\x -> Fixture.Witness 7 x) (\_ -> Fixture.Token 37) of Fixture.Witness value payload -> value == 7 && (case payload True of Fixture.Token n -> n == 37))
