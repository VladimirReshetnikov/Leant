module Main where
import qualified ProductAlternativeSpec as Product
import Test.Tasty (defaultMain,testGroup)
import Test.Tasty.HUnit (testCase)
main :: IO ()
main = defaultMain $ testGroup "product alternatives" [testCase name action | (name,action) <- Product.tests]
