from pathlib import Path
import os,sys,json
ROOT=Path('C:/Djex-validation/product-term-construction')
BASE=Path('C:/Djex')
sys.path.insert(0,str(BASE/'test-church'))
import behavior_runtime as rt
cli=BASE/'dist-newstyle/lexical-kinds-root-cli-v1/results.json'
old=json.loads(cli.read_text(encoding='utf-8'))
assert old['status'] in ['passed','failed'],'CLI owner must finish before this probe starts'
assert all(rt.sha256(BASE/p)==h for p,h in old['source_sha256'].items())
OUT=rt.prepare_output_directory(ROOT/'dist-newstyle/product-alternatives-focused-v1')
paths=['djinn/src-core/Djinn/Internal/LJT.hs','djinn/test-unit/ProductAlternativeSpec.hs','djinn/test-unit/Spec.hs','djex.cabal']
report=dict(status='running',scope='Independent proof-checked product alternatives and prefix/fuel contracts; not public source acceptance.',source_sha256={p:rt.sha256(ROOT/p) for p in paths},baseline_source_sha256=old['source_sha256'],baseline_cli_receipt_sha256=rt.sha256(cli),gates=[],runtime_sha256={})
for p in paths:
 dest=OUT/'source'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((ROOT/p).read_bytes())
(OUT/'baseline-LJT.hs').write_bytes((BASE/paths[0]).read_bytes())
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
driver=OUT/'Main.hs'
driver.write_text('''module Main where
import qualified ProductAlternativeSpec as Product
import Test.Tasty (defaultMain,testGroup)
import Test.Tasty.HUnit (testCase)
main :: IO ()
main = defaultMain $ testGroup "product alternatives" [testCase name action | (name,action) <- Product.tests]
''',encoding='utf-8')
runner=rt.Processes(OUT,180)
env=dict(os.environ,djex_datadir=str(BASE),TASTY_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
def save():
 report['processes']=runner.rows;rt.write_json(OUT/'results.json',report)
try:
 save()
 for label in ['baseline','candidate']:
  directory=OUT/label;directory.mkdir();binary=directory/'probe.exe'
  command=['cabal','exec','--','ghc','-i','-package','djex','-package','tasty','-package','tasty-hunit','-package','containers','-package','transformers','-fforce-recomp','-Wall','-Werror',str(driver),str(ROOT/paths[1])]
  if label=='candidate':command.append(str(ROOT/paths[0]))
  command+=['-odir',str(directory),'-hidir',str(directory),'-o',str(binary)]
  built=runner.run(label+'-compile',command,cwd=BASE,env=env)
  assert built.returncode==0,label+' compile failed: '+built.stderr
  report['runtime_sha256'][str(binary)]=rt.sha256(binary);save()
  result=runner.run(label+'-tests',[str(binary),'--color=never','--num-threads=1'],cwd=BASE,env=env)
  report['gates'].append(dict(label=label,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr));save()
  print(label,result.stdout,result.stderr,flush=True)
  assert result.returncode==(1 if label=='baseline' else 0),label+' did not match its required result'
 report['status']='passed'
except BaseException as failure:
 report.update(status='failed',failure=repr(failure))
finally:
 report['sources_unchanged']=all(rt.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
 report['baseline_sources_unchanged']=all(rt.sha256(BASE/p)==h for p,h in report['baseline_source_sha256'].items())
 report['runtimes_unchanged']=all(rt.sha256(Path(p))==h for p,h in report['runtime_sha256'].items())
 if not all(report[k] for k in ['sources_unchanged','baseline_sources_unchanged','runtimes_unchanged']):report['status']='failed'
 save()
print(report['status'],flush=True)
sys.exit(0 if report['status']=='passed' else 1)
