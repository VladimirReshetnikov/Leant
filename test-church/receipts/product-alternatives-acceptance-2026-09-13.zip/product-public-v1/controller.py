from pathlib import Path
import os,sys,json,subprocess
ROOT=Path('C:/Djex-validation/product-term-construction')
sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as rt
OUT=rt.prepare_output_directory(ROOT/'dist-newstyle/product-public-v1')
paths=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=ROOT).decode().split('\0')
paths=sorted({p for p in paths if p and (ROOT/p).is_file() and Path(p).suffix in ['.hs','.cabal','.py']})
report=dict(status='running',scope='Actual isolated Djex executable, original adjacent-input public query and affected Djinn suite.',source_sha256={p:rt.sha256(ROOT/p) for p in paths},runtime_sha256={},gates=[])
for p in paths:
    dest=OUT/'source'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((ROOT/p).read_bytes())
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env=dict(os.environ,djex_datadir=str(ROOT),PYTHONDONTWRITEBYTECODE='1',TASTY_NUM_THREADS='1')
runner=rt.Processes(OUT,1800)
def save():
    report['processes']=runner.rows;rt.write_json(OUT/'results.json',report)
try:
    save()
    build=runner.run('strict-build',['cabal','build','djex:exe:djex','djex:test:djinn-tests','--ghc-options=-Werror','-j1'],cwd=ROOT,env=env)
    report['gates'].append(dict(label='strict-build',exit_code=build.returncode));save()
    assert build.returncode==0,'strict build failed'
    bins={}
    for label,target in [('djex','djex:exe:djex'),('djinn-tests','djex:test:djinn-tests')]:
        binary=Path(subprocess.check_output(['cabal','list-bin',target],cwd=ROOT).decode().strip())
        assert binary.is_file();bins[label]=binary;report['runtime_sha256'][str(binary)]=rt.sha256(binary)
    save()
    public=runner.run('adjacent-public',[sys.executable,'-X','utf8','-B',str(ROOT/'test-church/public_kinded_source.py'),'--exe',str(bins['djex']),'--case','adjacent_kinds','--output',str(OUT/'adjacent-public')],cwd=ROOT,env=env)
    report['gates'].append(dict(label='adjacent-public',exit_code=public.returncode));save()
    print(public.stdout[-3000:],public.stderr[-1500:],flush=True)
    assert public.returncode==0,'original public adjacent-input gate failed'
    suite=runner.run('djinn-tests',[str(bins['djinn-tests']),'--color=never','--num-threads=1'],cwd=ROOT,env=env)
    report['gates'].append(dict(label='djinn-tests',exit_code=suite.returncode));save()
    print(suite.stdout[-4000:],suite.stderr[-1500:],flush=True)
    assert suite.returncode==0,'Djinn regression gate failed'
    report['status']='passed'
except BaseException as failure:
    report.update(status='failed',failure=repr(failure))
finally:
    report['sources_unchanged']=all(rt.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
    report['runtimes_unchanged']=all(rt.sha256(Path(p))==h for p,h in report['runtime_sha256'].items())
    if not report['sources_unchanged'] or not report['runtimes_unchanged']:report['status']='failed'
    save()
print(report['status'],flush=True)
sys.exit(0 if report['status']=='passed' else 1)
