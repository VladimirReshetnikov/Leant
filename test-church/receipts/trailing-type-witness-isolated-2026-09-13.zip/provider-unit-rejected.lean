namespace Demo
universe u
def box {A : Type u} (x : A) : A × Unit := (x, ())
end Demo
def candidate : ((B : Type) → B → B) → Nat → Nat := fun f x => let ⟨g, _⟩ := Demo.box (f _root_.Unit); g _ x
#print axioms candidate
