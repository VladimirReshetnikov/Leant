from pathlib import Path
import hashlib,json,zipfile
ROOT=Path('C:/Leant')
CHECKOUT=Path('C:/Leant-validation/trailing-type-witness')
OUT=CHECKOUT/'dist-newstyle/trailing-type-witness-isolated-v2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
x=read(OUT/'results.json')
assert x['status']=='passed' and x['sources_unchanged'] and x['runtimes_unchanged']
assert (OUT/'controller.py').read_bytes()==(CHECKOUT/'validate_isolated_v2.py').read_bytes()
assert [(r['gate'],r['exit_code']) for r in x['gates']]==[(g,0) for g in ['strict-build','unit','last-atkey','signatures-djinn','signatures-exference']]
for name,value in x['source_hashes'].items(): assert sha(CHECKOUT/name)==value,name
for name,value in x['runtime_hashes'].items(): assert sha(Path(name))==value,name
unit=read(OUT/'unit/results.json')
assert unit['status']=='passed' and unit['inventory_count']==unit['expected_count']==707
assert unit['sources_unchanged'] and unit['executables_unchanged']
assert [(r['name'],r['exit_code']) for r in x['renderer_contract_checks']]==[('provider-original',0),('provider-unit-rejected',1)]
for r in x['renderer_contract_checks']: assert sha(OUT/(r['name']+'.lean'))==r['source_sha256']
b=read(OUT/'last-atkey/results.json')
assert b['status']=='passed' and b['accepted'] and b['candidate_count']==6 and b['false_control_count']==3 and b['passed_oracle_preflights']==2
assert b['sources_unchanged'] and b['executables_unchanged']
assert all(r['exit_code']==0 and not r['timed_out'] for r in b['processes'])
false={}
for r in b['cells']:
 assert r['status']=='passed' and r['accepted']
 if r['operation']=='reject_all':
  o=r['live_outcome']['observations']; assert o['passed']==0 and o['inconclusive']==0 and o['falsified']>0;false[r['engine']]=o['falsified']
 else:
  replay=r['replay']; assert replay['status']=='passed' and replay['candidate_declared_before_observation_helpers']
  assert replay['actual_axiom_inventories']==replay['expected_axiom_inventories']
  assert replay['actual_axiom_inventories']['BehaviorPartialReplay.candidate']==[]
  for name,axioms in replay['actual_axiom_inventories'].items():
   if axioms:
    assert r['operation']=='atKey' and name in ['BehaviorPartial.check_atKey','BehaviorPartialReplay.candidate_passes_original_oracle']
    assert axioms==['Classical.choice','Quot.sound','propext']
  assert r['finite_observation_count']=={'last':24,'atKey':54}[r['operation']]
for engine in ['djinn','exference']:
 s=read(OUT/('signatures-'+engine)/'results.json')
 assert s['case_count']==s['candidate_count']==s['axiom_free_count']==350
 assert s['kernel_replay_passed'] and s['kernel_exit_code']==s['leant_exit_code']==0
for row in x['processes']:
 assert not row['timed_out']
 assert row['exit_code']==(1 if row['label']=='provider-unit-rejected' else 0),row
# Preserve the unsuccessful first release gate without blending its outcome.
old=CHECKOUT/'dist-newstyle/trailing-type-witness-isolated-v1'
for name in ['results.json','change.diff','controller.py','unit/results.json','unit/unit.stdout.txt','unit/unit.stderr.txt']:
 p=old/name
 if p.exists():
  dest=OUT/'previous-attempt'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
(OUT/'packager.py').write_bytes(Path(__file__).read_bytes())
manifest={}; omitted={}
for p in sorted(OUT.rglob('*')):
 if not p.is_file():continue
 n=p.relative_to(OUT).as_posix();entry={'sha256':sha(p),'bytes':p.stat().st_size}
 if p.suffix in ('.exe','.o','.hi','.dyn_o','.dyn_hi','.olean','.ilean'):omitted[n]=entry
 else:manifest[n]=entry
archive=ROOT/'test-church/receipts/trailing-type-witness-isolated-2026-09-13.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in manifest:z.write(OUT/name,name)
 z.writestr('archive-manifest.json',json.dumps({'artifacts':manifest,'omitted_build_products':omitted},indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(manifest)|{'archive-manifest.json'}
 for n,expected in manifest.items():
  raw=z.read(n);assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256']
receipt={'schema':'leant-trailing-type-witness-isolated-v1','status':'passed','scope':'Isolated trailing-type renderer repair; separate contextual-constructor changes excluded.',
 'source_base_commit':x['base_commit'],'dependency_commit':x['dependency_commit'],
 'counts':{'unit_tests':707,'accepted_behavior_cells':6,'false_controls':3,'false_falsifications_by_engine':false,'signature_replays_by_engine':{'djinn':350,'exference':350},'frozen_source_files':len(x['source_hashes'])},
 'strict_build':'passed -Werror','renderer_contract_checks':x['renderer_contract_checks'],
 'sources_and_runtimes_unchanged':True,'raw_receipt_member':'results.json','behavior_receipt_member':'last-atkey/results.json',
 'archive':{'path':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'artifact_count':len(manifest),'all_members_rehashed':True},
 'boundaries':['All displayed candidates are independently replayed at full types; finite observations do not establish extensional equivalence.', 'The deliberately invalid Unit provider variant is rejected; its nonzero kernel exit is an expected negative check.', 'The earlier failed 705/707 run is retained separately in previous-attempt.', 'No contextual-constructor change or dependency promotion is accepted by these checks.']}
p=archive.with_suffix('.json');p.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2))
