"""Serialized acceptance of only the trailing-type renderer change."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'lib/Djex/test-church'))
import behavior_runtime as runtime

OUT = ROOT/'dist-newstyle/trailing-type-witness-isolated-v2'
OUT.mkdir(parents=True, exist_ok=False)
report = {'status': 'running', 'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
          'dependency_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT/'lib/Djex').decode().strip(),
          'gates': [], 'source_hashes': {}}
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT/'lib/Djex') == b''
for repo, prefix in ((ROOT, ''), (ROOT/'lib/Djex', 'lib/Djex/')):
    for name in subprocess.check_output(['git', 'ls-files', '-z'], cwd=repo).decode().split('\0'):
        path = repo/name
        if not name or not path.is_file() or '/receipts/' in name:
            continue
        if path.suffix not in ('.hs', '.lhs', '.py', '.cabal', '.lean') and name not in ('cabal.project', 'test-church/manifest.json', 'lean-toolchain'):
            continue
        relative = prefix+name
        report['source_hashes'][relative] = runtime.sha256(path)
        target = OUT/'source'/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes())
(OUT/'change.diff').write_bytes(subprocess.check_output(['git', 'diff', 'HEAD'], cwd=ROOT))
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
processes = runtime.Processes(OUT, 1800)
def save():
    report['processes'] = processes.rows
    runtime.write_json(OUT/'results.json', report)

def gate(label, command, guard):
    print('Starting '+label, flush=True)
    report['active_gate'] = label
    save()
    processes.timeout = guard
    result = processes.run(label, command, cwd=ROOT)
    report['gates'].append({'gate': label, 'exit_code': result.returncode})
    save()
    if result.returncode:
        raise RuntimeError(label+' failed; inspect its owned captures')
    print('Passed '+label, flush=True)

try:
    gate('strict-build', ['cabal', 'build', 'exe:leant', 'test:leant-synth-tests', 'exe:djex-fake-z3', '--ghc-options=-Werror', '-j1'], 1800)
    exe = ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/x/leant/build/leant/leant.exe'
    kernel = Path('C:/Users/vresh/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean.exe')
    backend = Path('C:/Users/vresh/AppData/Local/Python/pythoncore-3.14-64/Lib/site-packages/lean_interact/cache/augustepoiroux/repl/repl_v1.3.18_lean-toolchain-v4.32.0/.lake/build/bin/repl.exe')
    report['runtime_hashes'] = {str(p): runtime.sha256(p) for p in (exe, kernel, backend)}
    gate('unit', [sys.executable, '-X', 'utf8', '-B', 'test-recursive/run_unit.py', '--expected-count', '707', '--output', str(OUT/'unit')], 1500)
    # Check the exact provider-result strings whose renderer contract changed.
    # The added Unit proposal must be rejected at the original Nat target.
    preamble = "namespace Demo\nuniverse u\ndef box {A : Type u} (x : A) : A × Unit := (x, ())\nend Demo\n"
    contract_rows = []
    for name, term, expected_exit in (
        ('provider-original', 'fun f x => let ⟨g, _⟩ := Demo.box f; g _ x', 0),
        ('provider-unit-rejected', 'fun f x => let ⟨g, _⟩ := Demo.box (f _root_.Unit); g _ x', 1),
    ):
        module = OUT/(name+'.lean')
        module.write_text(preamble+'def candidate : ((B : Type) → B → B) → Nat → Nat := '+term+'\n#print axioms candidate\n', encoding='utf-8')
        result = processes.run(name, [str(kernel), str(module)], cwd=ROOT)
        if expected_exit == 0:
            assert result.returncode == 0 and 'does not depend on any axioms' in result.stdout
        else:
            assert result.returncode != 0 and 'error:' in result.stdout
        contract_rows.append({'name': name, 'expected_exit_code': expected_exit, 'exit_code': result.returncode, 'source_sha256': runtime.sha256(module)})
    report['renderer_contract_checks'] = contract_rows
    save()
    gate('last-atkey', [sys.executable, '-X', 'utf8', '-B', 'test-church/behavior_partial_probe.py', '--leant', str(exe),
         '--spec-dir', str(ROOT/'lib/Djex/test-church'), '--output', str(OUT/'last-atkey'), '--lean', str(kernel), '--lean-runtime', str(kernel), '--backend', str(backend),
         '--engine', 'djinn', '--engine', 'exference', '--engine', 'both', '--operation', 'last', '--operation', 'atKey',
         '--window', '65536', '--budget', '500000', '--steps', '100000', '--djinn-strategy', 'interleave', '--timeout', '90', '--process-timeout', '900'], 9000)
    for engine in ('djinn', 'exference'):
        label = 'signatures-'+engine
        gate(label, [sys.executable, '-X', 'utf8', '-B', 'test-church/run_corpus.py', '--leant', str(exe), '--engine', engine,
             '--window', '1', '--lean', str(kernel), '--toolchain', '', '--output', str(OUT/label)], 2400)
        result = json.loads((OUT/label/'results.json').read_text())
        assert result['case_count'] == result['candidate_count'] == result['axiom_free_count'] == 350
        assert result['kernel_replay_passed'] and result['kernel_exit_code'] == result['leant_exit_code'] == 0
    report['status'] = 'passed'
except BaseException as failure:
    report['status'] = 'failed'
    report['failure'] = type(failure).__name__+': '+str(failure)
finally:
    report['sources_unchanged'] = all(runtime.sha256(ROOT/name) == value for name, value in report['source_hashes'].items())
    report['runtimes_unchanged'] = all(runtime.sha256(Path(name)) == value for name, value in report.get('runtime_hashes', {}).items())
    if not report['sources_unchanged'] or not report['runtimes_unchanged']:
        report['status'] = 'failed'
    save()
print(report['status'], report.get('failure', ''), flush=True)
sys.exit(0 if report['status'] == 'passed' else 1)
