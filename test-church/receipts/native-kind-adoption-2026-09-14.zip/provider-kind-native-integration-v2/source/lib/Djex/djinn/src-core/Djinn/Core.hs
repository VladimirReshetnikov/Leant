{-# LANGUAGE BangPatterns #-}

-- |
-- The stable, validated interface to the Djinn core.
--
-- Build a checked t'Environment' from declarations, then ask 'inhabitResult'
-- for a checked shared result of a given type; 'inhabitGenerated' and
-- 'inhabit' are structured and rendered compatibility projections. Every
-- entry point validates its
-- input — names must be lexically valid, declarations are kind-checked
-- transactionally, class arguments must fit their parameters' inferred
-- kinds — so the proof machinery only ever sees well-formed data.  The
-- @Djinn.Internal.*@ modules expose the raw types and functions without
-- these guarantees and without any API-stability promise.
--
-- > ghci> let Right t = parseHType "(a, b) -> (b, a)"
-- > ghci> reportOutcome <$> inhabit defaultQueryOptions standardEnvironment [] "swap" t
-- > Right (Realized ["swap (a, b) = (b, a)"])
module Djinn.Core (
    -- * Names, types, and kinds
    HSymbol, HType, HKind, kStar, kArrow,
    parseHType, parseContextualHType, parseHKind, SynthesisTypeError(..),
    normalizeSynthesisType,
    toSynthesisType, fromSynthesisType,
    -- * Declarations
    Constructor, Declaration(..), SynthesisDeclaration,
    DjinnDeclarationNameRole(..),
    SynthesisDeclarationError(..), toSynthesisKind, fromSynthesisKind,
    toSynthesisDeclaration, fromSynthesisDeclaration,
    -- * Environments
    Environment, emptyEnvironment, standardEnvironment,
    PreparedEnvironment, prepareEnvironment, prepareSynthesisEnvironment,
    preparedEnvironmentSource, preparedEnvironmentInventory,
    SynthesisEnvironment, SynthesisInventory,
    SynthesisEnvironmentError(..),
    toSynthesisEnvironment, toSynthesisInventory,
    fromSynthesisEnvironment,
    declareSynthesisEnvironment, removeSynthesisDeclaration,
    declare, removeDeclaration, renderEnvironmentEditFailure,
    typeDeclarations, functionDeclarations, classDeclarations,
    -- * Queries
    Context, mkContext, resolveContext, resolveInstanceMethods,
    resolvePreparedContext, resolvePreparedInstanceMethods,
    QueryOptions(..), defaultQueryOptions, Strategy(..),
    DjinnCandidateDetails(..), DjinnCandidate,
    DjinnTermGraphTypeVariable, DjinnTermGraphType,
    DjinnTermGraphAbsence(..), DjinnTypedCandidate,
    DjinnQueryMetadata(..), DjinnResult, DjinnTypedResult,
    DjinnQueryOptionsError(..), DjinnQueryError(..),
    inhabitResult, inhabitResultPrepared, inhabitSynthesisResultPrepared,
    inhabitTypedSynthesisResultPrepared,
    DjinnSourceProviderEvidence(..),
    inhabitTypedSynthesisResultPreparedWithSourceGoal,
    inhabitTypedSynthesisResultPreparedWithKindedSourceGoal,
    inhabitTypedSynthesisStreamPreparedWithSourceGoal,
    inhabitTypedSynthesisStreamPreparedWithKindedSourceGoal,
    inhabitSynthesisResultPreparedWithInstantiationCandidates,
    inhabitTypedSynthesisResultPreparedWithInstantiationCandidates,
    inhabitSynthesisResultPreparedWithInstantiationAssignments,
    inhabitTypedSynthesisResultPreparedWithInstantiationAssignments,
    inhabitSynthesisResultPreparedWithKindedInstantiationAssignments,
    inhabitTypedSynthesisResultPreparedWithKindedInstantiationAssignments,
    GeneratedQueryReport(..), inhabitGenerated, inhabitGeneratedPrepared,
    QueryOutcome(..), QueryReport(..), inhabit
    ) where

import Control.DeepSeq (deepseq)
import Control.Monad (foldM, replicateM, unless, void, when)
import Data.Bifunctor (first)
import Data.Either (fromRight)
import Data.List (intercalate, isPrefixOf, mapAccumL)
import qualified Data.List as List
import qualified Data.Map.Strict as Map
import Data.Ratio ((%))
import qualified Data.Set as Set
import Numeric.Natural (Natural)
import Text.ParserCombinators.ReadP
    (ReadP, option, readP_to_S, skipSpaces)

import Language.Haskell.Synthesis.Constraint
    (Constraint(..), validateKnownConstraintArityWith)
import qualified Language.Haskell.Synthesis.Candidate as SharedCandidate
import qualified Language.Haskell.Synthesis.CandidateQuality as SharedQuality
import qualified Language.Haskell.Synthesis.Collection as SharedCollection
import qualified Language.Haskell.Synthesis.Declaration as SourceDeclaration
import qualified Language.Haskell.Synthesis.SourceKind as SourceKinds
import qualified Language.Haskell.Synthesis.SourceKind.Expansion as SourceKindExpansion
import qualified Language.Haskell.Synthesis.Environment as SharedEnvironment
import qualified Language.Haskell.Synthesis.Inventory as SharedInventory
import qualified Language.Haskell.Synthesis.Kind as SharedKind
import qualified Language.Haskell.Synthesis.KindInference as SharedKindInference
import qualified Language.Haskell.Synthesis.Name as SharedName
import qualified Language.Haskell.Synthesis.Generated as SharedGenerated
import qualified Language.Haskell.Synthesis.Query as SharedQuery
import qualified Language.Haskell.Synthesis.Search as SharedSearch
import qualified Language.Haskell.Synthesis.Type as SharedType
import qualified Language.Haskell.Synthesis.TypeAtom as SharedTypeAtom
import qualified Language.Haskell.Synthesis.Internal.TypedCandidate
    as SharedTypedCandidate

import Djinn.Internal.CheckedCandidate
    ( ValidatedCandidate
    , ValidatedResult
    , checkCandidateProofWith
    , convertCheckedCandidateWithEvidence
    , mkValidatedResult
    , projectValidatedResultWith
    , sortValidatedCandidates
    , validatedCandidateDetails
    , validatedCandidateOutput
    )
import Djinn.Internal.Environment
import qualified Djinn.Internal.ContextualInstantiation as Contextual
import Djinn.Internal.Declaration
import Djinn.Internal.GeneratedDeduplication
    ( deduplicateEtaEquivalentClausesOn, etaNormalClauseExpression )
import Djinn.Internal.HTypes
import Djinn.Internal.Instantiation
    ( closedMonotypeSubtrees
    , closedQuantifiedSubtrees
    , independentConstructionScopes
    , instantiationAxiomPremises
    , instantiationAxiomSymbols
    , instantiationVisibleApplications
    , instantiationAxioms
    , loadedInstantiationAxioms
    , queryDirectedInstantiationAxioms
    , queryCarrierInstantiationAxioms
    , queryConstructedInstantiationAxioms
    , scopedConstructionInstantiationAxioms
    , queryCorrelatedInstantiationAxioms
    , queryClosedInstantiationAxioms
    , providerInstantiationApplications
    , providerInstantiationAssignmentPremises
    , providerInstantiationPremiseBindings
    , providerInstantiationPremises
    , usesInstantiationEvidence
    )
import Djinn.Internal.LJT
import Djinn.Internal.PlanFamily (nextAdmittedPlanFamily)
import qualified Djinn.Internal.SourceEvidence as SourceEvidence
import qualified Djinn.Internal.SourceGraph as SourceGraph
import Djinn.Internal.ProofCheck.Evidence (checkProofWithEvidence)
import Djinn.Internal.ProofEnv
import Djinn.Internal.Type
import Djinn.Internal.TypeFormula
    ( PolarizedFormulaPlans
    , FormulaPolarity (..)
    , exactOpaqueFormulaPlan
    , polarizedFormulaPlanSkolems
    , polarizedFormulaPlanPositiveForallCount
    , maxCompleteForallFrontierSites
    , primaryFormulaPlan
    , negativeOpaqueFormulaSymbols
    , pairOpaqueFormulaPlans
    , pairOpenFormulaPlans
    , tripleOpaqueFormulaPlans
    , tripleOpenFormulaPlans
    , quadrupleOpaqueFormulaPlans
    , quadrupleOpenFormulaPlans
    , quintupleOpaqueFormulaPlans
    , quintupleOpenFormulaPlans
    , singleOpaqueFormulaPlans
    , singleOpenFormulaPlans
    , translatedFormula
    , translationIncomplete
    , translationIntroducedSkolems
    )

------------------------------------------------------------------
-- Kinds

-- | The kind of proper types, @*@.
kStar :: HKind
kStar = KStar

-- | A function kind, e.g. @kArrow kStar kStar@ is @* -> *@.
kArrow :: HKind -> HKind -> HKind
kArrow = KArrow

-- | Parse a type in Djinn's Haskell-like syntax, requiring the whole input to
-- be consumed. Explicit @forall@ is accepted at any type position, including
-- inside constructor applications. Checked queries reopen validated positive
-- occurrences in the polarized formula plan, including contextual ones under
-- dictionary-independent semantics; raw conversion and unsupported
-- occurrences retain one inert, alpha-aware atom.
parseHType :: String -> Either String HType
parseHType = parseWith pHType "type"

-- | Parse the complete type portion of a historical Djinn query, including
-- its optional class context.  Keeping full-consumption handling here lets
-- checked adapters reuse the compatibility grammar without importing raw
-- parser combinators or an internal parser module.
parseContextualHType :: String -> Either String ([Context], HType)
parseContextualHType = parseWith parser "contextual type"
  where
    parser = do
        contexts <- option [] pHContext
        goal <- pHType
        return (contexts, goal)

-- | Parse a kind, e.g. @\"(* -> *) -> *\"@.
parseHKind :: String -> Either String HKind
parseHKind = parseWith pHKind "kind"

parseWith :: ReadP a -> String -> String -> Either String a
parseWith parser what input =
    case [value | (value, "") <- readP_to_S parseAll input] of
        value : _ -> Right value
        [] -> Left $ "cannot parse " ++ what ++ ": " ++ show input
  where
    parseAll = do
        value <- parser
        skipSpaces
        return value

------------------------------------------------------------------
-- Declarations and environments

-- | Stored type declarations: @(name, (parameters, body, kind))@.
typeDeclarations :: Environment -> [(HSymbol, ([HSymbol], HType, HKind))]
typeDeclarations = envTypes

-- | Stored function assumptions.
functionDeclarations :: Environment -> [(HSymbol, HType)]
functionDeclarations = envFunctions

-- | Stored classes: @(name, (parameters with kinds, methods))@.
classDeclarations ::
    Environment -> [(HSymbol, ([(HSymbol, HKind)], [(HSymbol, HType)]))]
classDeclarations = envClasses

-- | No declarations at all: no types, no functions, no classes.
emptyEnvironment :: Environment
emptyEnvironment = Environment [] [] []

-- | Lower a shared structural environment through Djinn's stricter lexical,
-- dependency, and kind validation. Unsupported declarations fail before any
-- mutation is committed.
fromSynthesisEnvironment
    :: SynthesisEnvironment
    -> Either SynthesisEnvironmentError Environment
fromSynthesisEnvironment =
    fmap preparedEnvironmentSource . prepareSynthesisEnvironment

-- | The environment the interactive Djinn starts with: @()@, @Bool@,
-- @Either@, @Maybe@, @Void@, @type Not x = x -> Void@, and small @Eq@
-- and @Monad@ classes.
standardEnvironment :: Environment
standardEnvironment =
    either (error . ("Djinn.Core.standardEnvironment: " ++)) id $ do
        unitEnvironment <- trustedUnitEnvironment
        foldM (flip declare) unitEnvironment
            [ DataType "Either" ["a", "b"]
                [("Left", [a]), ("Right", [b])]
            , DataType "Maybe" ["a"] [("Nothing", []), ("Just", [a])]
            , DataType "Bool" [] [("False", []), ("True", [])]
            , DataType "Void" [] []
            , TypeSynonym "Not" ["x"] (htNot "x")
            , ClassDecl "Eq" ["a"]
                [("==", a `HTArrow` (a `HTArrow` HTCon "Bool"))]
            , ClassDecl "Monad" ["m"]
                [ ("return", a `HTArrow` ma)
                , (">>=", ma `HTArrow` ((a `HTArrow` mb) `HTArrow` mb))
                ]
            ]
  where
    a = HTVar "a"
    b = HTVar "b"
    m = HTVar "m"
    ma = HTApp m a
    mb = HTApp m b

-- @()@ is a grammar-level special form, not a constructor identifier that a
-- caller may repurpose.  Install exactly the standard nullary type and value
-- constructor through this private path. Even this trusted constant crosses
-- the operational shared preparation boundary; the historical raw validator
-- remains only a compatibility surface with its own diagnostic ordering.
trustedUnitEnvironment :: Either String Environment
trustedUnitEnvironment = first show $
    preparedEnvironmentSource <$> prepareEnvironment Environment
        { envTypes = [("()", ([], HTUnion [("()", [])], KStar))]
        , envFunctions = []
        , envClasses = []
        }

-- | Add (or overwrite, for the same name in the same category) one
-- declaration.  The whole environment is revalidated transactionally:
-- on 'Left' the original environment is still the one to use.
declare :: Declaration -> Environment -> Either String Environment
declare declaration = editEnvironment $ declareSynthesisEnvironment declaration

-- | Remove a declaration by name, from whichever category holds it.
-- Rejected if the name is not defined or if a remaining declaration
-- depends on it; on 'Left' the environment is unchanged.
removeDeclaration :: HSymbol -> Environment -> Either String Environment
removeDeclaration name = editEnvironment $ removeSynthesisDeclaration name

-- Raw environments remain a compatibility view, not a second editable
-- authority. Convert once, apply the same checked shared transaction used by
-- stable sessions, and project the exact sealed result back only on success.
editEnvironment
    :: (SynthesisEnvironment
        -> Either SynthesisEnvironmentError
            (SynthesisEnvironment, PreparedEnvironment))
    -> Environment
    -> Either String Environment
editEnvironment edit environment = do
    source <- first renderEnvironmentEditFailure $
        toSynthesisEnvironment environment
    (_, prepared) <- first renderEnvironmentEditFailure $ edit source
    return $ preparedEnvironmentSource prepared

-- | Keep the raw string API useful without reconstructing the discarded raw
-- candidate merely to recover category-specific legacy wording. This is the
-- one rendering authority for edit failures: the raw string API and the
-- stable adapter's structured diagnostics both consume it.
renderEnvironmentEditFailure :: SynthesisEnvironmentError -> String
renderEnvironmentEditFailure failure = case failure of
    InvalidSynthesisInventory
            (SharedInventory.UngroundedInventoryKind variable) ->
        "kind contains an unsolved variable: " ++ show (KVar variable)
    SynthesisEnvironmentDeclarationError NonCanonicalUnitDeclaration ->
        unitDeclarationMessage
    ProtectedSynthesisUnitDeclaration ->
        unitDeclarationMessage
    InvalidSynthesisEnvironment
            (SharedEnvironment.DuplicateValueDeclaration name) ->
        "Value name is already declared: " ++ SharedName.renderCanonical name
    InvalidSynthesisEnvironment
            (SharedEnvironment.DuplicateTypeDeclaration name) ->
        "Type name is already declared: " ++ SharedName.renderCanonical name
    SynthesisDeclarationNotFound name -> name ++ " is not defined"
    ProtectedSynthesisUnit -> "() is a built-in type and cannot be removed"
    _ -> show failure

unitDeclarationMessage :: String
unitDeclarationMessage = "() is a built-in type and cannot be declared"

requireName :: String -> (HSymbol -> Bool) -> HSymbol -> Either String ()
requireName what valid name
    | valid name = Right ()
    | otherwise = Left $ show name ++ " is not a valid " ++ what ++ " name"

------------------------------------------------------------------
-- Queries

-- | A class constraint represented by the backend-neutral synthesis
-- vocabulary.  Djinn retains ownership of class lookup, kind checking, and
-- instance-generation policy; its ordinary inhabitation queries treat the
-- finite nominal syntax as validation obligations rather than proof premises.
type Context = Constraint HType

-- | Build a context from Djinn's historical string class name.  Class
-- declarations are currently unqualified constructor identifiers, so this
-- bridge deliberately enforces the same namespace before constructing the
-- shared nominal value.
mkContext :: HSymbol -> [HType] -> Either String Context
mkContext className arguments = do
    requireName "class" (isDjinnDeclarationName ClassOwner) className
    case SharedName.parseName className of
        Left nameError -> Left $ SharedName.renderNameError nameError
        Right sharedName -> Right $ Constraint sharedName arguments

-- | Look up a class use, requiring exact arity, arguments that fit the
-- parameters' inferred kinds, and well-kinded instantiated methods.
-- Returns each method at its instantiated type.
resolveContext :: Environment -> Context -> Either String [(HSymbol, HType)]
resolveContext environment context = do
    prepared <- prepareCompatibilityEnvironment environment
    resolvePreparedContext prepared context

-- | Resolve one context against an already sealed environment.  Unlike the
-- historical wrapper, this path performs no whole-environment kind
-- conversion and is therefore suitable for repeated session queries.
resolvePreparedContext
    :: PreparedEnvironment -> Context -> Either String [(HSymbol, HType)]
resolvePreparedContext prepared context =
    concat <$> resolveContexts prepared [context]

-- | Resolve the methods of an instance target while checking the target and
-- all prerequisite contexts in one kind-variable scope.  The returned methods
-- belong only to the target and are instantiated exactly as by
-- 'resolveContext'.
resolveInstanceMethods :: Environment -> [Context] -> Context
                       -> Either String [(HSymbol, HType)]
resolveInstanceMethods environment prerequisites target = do
    prepared <- prepareCompatibilityEnvironment environment
    resolvePreparedInstanceMethods prepared prerequisites target

-- | Prepared counterpart of 'resolveInstanceMethods'.
resolvePreparedInstanceMethods :: PreparedEnvironment -> [Context] -> Context
                               -> Either String [(HSymbol, HType)]
resolvePreparedInstanceMethods prepared prerequisites target = do
    resolved <- resolveContexts prepared (target : prerequisites)
    case resolved of
        targetMethods : _ -> Right targetMethods
        [] -> Left "internal error: instance target was not resolved"

prepareCompatibilityEnvironment
    :: Environment -> Either String PreparedEnvironment
prepareCompatibilityEnvironment = first show . prepareEnvironment

-- The intermediate record keeps lookup/arity validation separate from the
-- joint kind check and substitution.  In particular, every argument and the
-- query goal must share one scope for their free type variables.
data ResolvedContext typeExpression = ResolvedContext {
    resolvedConstraint :: Constraint typeExpression,
    resolvedParameters :: [(HSymbol, HKind)],
    -- Keep sealed methods in the authoritative shared representation.  The
    -- compatibility API wraps only the final instantiated result, rather
    -- than routing substitution through the historical HType patterns in
    -- stable queries.
    resolvedMethods ::
        [(SharedName.Name, SharedType.Type HSymbol)]
    }

resolvedName :: ResolvedContext typeExpression -> HSymbol
resolvedName = SharedName.renderCanonical . constraintClass . resolvedConstraint

resolvedArguments :: ResolvedContext typeExpression -> [typeExpression]
resolvedArguments = constraintArguments . resolvedConstraint

resolveContexts :: PreparedEnvironment -> [Context]
                -> Either String [[(HSymbol, HType)]]
resolveContexts prepared contexts = do
    resolved <- mapM (lookupResolvedContext prepared) contexts
    checkKindObligations prepared $ concatMap argumentObligations resolved
    mapM (instantiateContext prepared) resolved

internalQueryFailure :: String -> Either DjinnQueryError value
internalQueryFailure =
    Left . DjinnInternalQueryFailure . ("internal error: " ++)

-- Class lookup and arity validation are representation-independent.  Raw and
-- native callers retain their input type tree in the polymorphic constraint;
-- the sealed parameters and methods come from the same shared class index.
lookupResolvedContext
    :: PreparedEnvironment
    -> Constraint typeExpression
    -> Either String (ResolvedContext typeExpression)
lookupResolvedContext prepared context = do
    -- Context is a shared, intentionally permissive syntax node.  Reassert
    -- Djinn's narrower class namespace even when a caller constructs that
    -- node directly instead of going through mkContext.
    requireName "class" (isDjinnDeclarationName ClassOwner) name
    case lookupPreparedSynthesisClass (constraintClass context) prepared of
        Nothing -> Left $ "Class not found: " ++ name
        Just (params, methods) -> do
            validateKnownConstraintArityWith
                (const $ Just $ length params)
                (\_ expected actual ->
                    "Class " ++ name ++ " expects " ++ show expected ++
                    " type argument(s), but got " ++ show actual)
                context
            Right ResolvedContext {
                resolvedConstraint = context,
                resolvedParameters = params,
                resolvedMethods = methods
                }
  where
    name = SharedName.renderCanonical $ constraintClass context

argumentObligations
    :: ResolvedContext HType
    -> [(String, HKind, HType)]
argumentObligations context =
    [ ("argument " ++ show argument ++ " of class " ++ resolvedName context,
       kind, argument)
    | ((_, kind), argument) <-
        zip (resolvedParameters context) (resolvedArguments context) ]

checkKindObligations :: PreparedEnvironment -> [(String, HKind, HType)]
                     -> Either String ()
checkKindObligations prepared =
    checkKindObligationsWith $ checkPreparedTypesKinds prepared

-- Retain the precise historical diagnostic when one type is independently
-- ill-kinded. If every component works alone, report the actual problem:
-- inconsistent kinds assigned to a free variable shared by components. Raw
-- and native query paths differ only in the checked type representation.
checkKindObligationsWith
    :: ([(HKind, source)] -> Either String ())
    -> [(String, HKind, source)]
    -> Either String ()
checkKindObligationsWith check obligations =
    case check [(kind, source) | (_, kind, source) <- obligations] of
        Right () -> Right ()
        Left jointError ->
            case [(label, message)
                    | (label, kind, source) <- obligations
                    , Left message <-
                        [check [(kind, source)]]] of
                (label, message) : _ -> Left $ label ++ ": " ++ message
                [] -> Left $
                    "inconsistent kinds across " ++
                    intercalate ", " [label | (label, _, _) <- obligations] ++
                    ": " ++ jointError

instantiateContext :: PreparedEnvironment -> ResolvedContext HType
                   -> Either String [(HSymbol, HType)]
instantiateContext prepared context = do
    arguments <- mapM projectArgument $ resolvedArguments context
    instantiateContextMethods prepared context arguments project
  where
    projectArgument source = first
        (("internal checked context projection failed: " ++) . show) $
        toSynthesisType source

    project label methodType = first
        (\failure -> label ++ "sealed method projection failed: "
            ++ show failure)
        $ fromSynthesisType methodType

-- Native shared-type context validation used by the Djex adapter. The raw
-- 'Context' operations above remain exact compatibility projections that can
-- inspect methods; ordinary search keeps only the goal and class arguments in
-- the common type tree through kind checking and synonym elaboration.
type SynthesisContext = Constraint (SharedType.Type HSymbol)

type ResolvedSynthesisContext =
    ResolvedContext (SharedType.Type HSymbol)

resolveSynthesisQueryContexts
    :: PreparedEnvironment
    -> (String, HKind, SharedType.Type HSymbol)
    -> [SynthesisContext]
    -> Either DjinnQueryError (SharedType.Type HSymbol)
resolveSynthesisQueryContexts prepared goalObligation contexts = do
    resolved <- queryFailure $
        mapM (lookupResolvedContext prepared) contexts
    let obligations = goalObligation :
            concatMap synthesisArgumentObligations resolved
    queryFailure $ checkSynthesisKindObligations prepared obligations
    elaborated <- queryFailure $ elaboratePreparedSynthesisTypes prepared
        [(kind, source) | (_, kind, source) <- obligations]
    case elaborated of
        [] -> internalQueryFailure "query elaboration dropped its goal"
        elaboratedGoal : elaboratedArguments
            | length elaboratedArguments == length obligations - 1 ->
                return elaboratedGoal
            | otherwise -> internalQueryFailure
                "query elaboration changed the context-argument batch shape"
  where
    queryFailure = first DjinnQueryFailure

synthesisArgumentObligations
    :: ResolvedSynthesisContext
    -> [(String, HKind, SharedType.Type HSymbol)]
synthesisArgumentObligations context =
    [ ( "argument " ++ renderSynthesisType argument ++ " of class " ++
          resolvedName context
      , kind
      , argument
      )
    | ((_, kind), argument) <- zip
        (resolvedParameters context)
        (resolvedArguments context)
    ]

checkSynthesisKindObligations
    :: PreparedEnvironment
    -> [(String, HKind, SharedType.Type HSymbol)]
    -> Either String ()
checkSynthesisKindObligations prepared =
    checkKindObligationsWith $
        checkPreparedSynthesisTypesKinds prepared

-- Shared instantiate-and-kind-check step for one resolved context. Each
-- method's non-class variables are implicitly quantified by that signature,
-- not shared with identically spelled variables in sibling methods; checking
-- one synthetic tuple would accidentally reunify them. The raw path
-- afterwards projects each checked method back to 'HType', while the native
-- path elaborates its synonyms; both attach the same historical
-- method-of-class label to their failures.
instantiateContextMethods
    :: PreparedEnvironment
    -> ResolvedContext argument
    -> [SharedType.Type HSymbol]
    -> (String -> SharedType.Type HSymbol -> Either String result)
    -> Either String [(HSymbol, result)]
instantiateContextMethods prepared context arguments finalize = do
    instantiated <- mapM instantiate $ resolvedMethods context
    mapM checkAndFinalize instantiated
  where
    instantiate (methodName, methodType) = do
        instantiatedType <- instantiateSynthesisMethod
            (resolvedParameters context) arguments methodType
        methodSymbol <- synthesisMethodSymbol methodName
        return (methodSymbol, instantiatedType)

    checkAndFinalize (methodSymbol, methodType) = do
        let label = methodLabel methodSymbol
        case checkPreparedSynthesisTypesKinds
                prepared [(KStar, methodType)] of
            Left message -> Left $ label ++ message
            Right () -> Right ()
        result <- finalize label methodType
        return (methodSymbol, result)

    methodLabel methodSymbol =
        "method " ++ prHSymbolOp methodSymbol ++ " of class " ++
        resolvedName context ++ ": "

-- Preserve Djinn's implicit method-local quantifier semantics on the common
-- tree. A local is renamed only when an active class-argument substitution
-- would otherwise capture its spelling. Both stable and compatibility
-- context resolution use this single substitution implementation.
instantiateSynthesisMethod
    :: [(HSymbol, HKind)]
    -> [SharedType.Type HSymbol]
    -> SharedType.Type HSymbol
    -> Either String (SharedType.Type HSymbol)
instantiateSynthesisMethod parameters arguments methodType = do
    renamed <- substitute renamings methodType
    substitute substitution renamed
  where
    parameterNames = map fst parameters
    substitution = zip parameterNames arguments
    methodVariables =
        SharedType.freeVariablesInFirstOccurrenceOrder methodType
    activeImages =
        [ argument
        | (parameter, argument) <- substitution
        , parameter `elem` methodVariables
        ]
    imageVariables = Set.fromList $ concatMap
        SharedType.freeVariablesInFirstOccurrenceOrder activeImages
    localVariables = filter (`notElem` parameterNames) methodVariables
    capturedLocals = filter (`Set.member` imageVariables) localVariables
    initiallyUnavailable = Set.fromList $
        parameterNames ++ methodVariables ++
        concatMap SharedType.freeVariablesInFirstOccurrenceOrder arguments
    (_, renamings) = mapAccumL allocateRenaming
        initiallyUnavailable capturedLocals

    allocateRenaming unavailable variable =
        let (fresh, unavailable') = freshPrimedVariable unavailable variable
        in ( unavailable'
           , (variable, SharedType.TypeVariable fresh)
           )

    substitute replacements = first show .
        SharedType.substituteTypeVariables freshTypeVariable Set.empty
            (Map.fromList replacements)

    freshTypeVariable unavailable variable =
        Just $ fst $ freshPrimedVariable unavailable variable

-- | Search breadth, ranking, result-limit, and fuel controls for one Djinn
-- query. Validation occurs at the checked query boundary before proof search.
data QueryOptions = QueryOptions {
    -- | Collect alternative solutions beyond the first.
    optionAlternatives :: Bool,
    -- | Rank solutions by the fraction of unused binders, then binder
    -- count; implies collecting alternatives.
    optionSorted :: Bool,
    -- | Positive raw-proof allowance shared across all formula plans.
    -- Rejected proofs and duplicates still count; reaching the bound may
    -- report 'SharedSearch.CandidateLimitReached' before search finishes.
    optionCutoff :: Int,
    -- | Shared choice-point budget; 'Nothing' removes this work bound.
    -- Higher-rank planning remains a bounded approximation. Explicit
    -- interleaved alternatives may enumerate infinitely many normal terms,
    -- or retain an unbounded size ladder when finiteness is not established.
    optionBudget :: Maybe Integer,
    -- | How proof search explores alternatives. 'DepthFirst' retains the
    -- historical plan schedule. 'Interleave' rotates ordinary choices;
    -- with explicit 'optionAlternatives' it also admits later formula plans
    -- and reusable-head normal terms under proof-or-64-choice turns. These
    -- turns share the query's existing proof/choice bounds. Sorting alone
    -- does not enable the additional term or plan enumeration.
    optionStrategy :: Strategy,
    -- | Structural quality influences finite search choices before the raw
    -- proof cutoff and ranks checked results afterward. Legacy preserves the
    -- historical unused-binder metric; the explicit strategy and alternative
    -- controls remain independent of the ranking profile.
    optionRanking :: SharedQuality.CandidateRankingPolicy,
    -- | Exact named-provider cost overrides. Unlisted providers cost one;
    -- names are semantic identities, not rendered spellings or lengths.
    optionProviderCosts :: Map.Map SharedName.Name Natural
    }
    deriving (Eq, Show)

-- | Prefer the best solution after considering up to 200 candidates, with
-- no choice-point budget.
defaultQueryOptions :: QueryOptions
defaultQueryOptions = QueryOptions {
    optionAlternatives = False,
    optionSorted = True,
    optionCutoff = 200,
    optionBudget = Nothing,
    optionStrategy = DepthFirst,
    optionRanking = SharedQuality.defaultCandidateRankingPolicy,
    optionProviderCosts = Map.empty
    }

-- | Ranking information retained with every checked Djinn candidate.
--
-- The historical compatibility API orders alternatives by the fraction of
-- unused binders and then by total binder count.  Keeping both inputs here
-- makes that backend-specific judgement inspectable without coupling the
-- shared candidate boundary to Djinn's policy.  The count is arbitrary-
-- precision because it is both observable metadata and the secondary rank.
data DjinnCandidateDetails = DjinnCandidateDetails {
    djinnUnusedBinderFraction :: Rational,
    djinnBinderCount :: Natural
    }
    deriving (Eq, Ord, Show)

-- | A checked Djinn result in the backend-neutral candidate envelope.
-- Djinn proves closed obligations, so its residual-constraint list is empty.
-- Give that invariantly empty slot the shared source-type representation at
-- construction time, so checked adapters can consume candidates verbatim.
type DjinnCandidate =
    SharedCandidate.Candidate (SharedType.Type HSymbol) DjinnCandidateDetails
        (SharedGenerated.FunctionClause HSymbol)

-- | Why a checked Djinn candidate cannot carry a shared source-typed graph.
--
-- The final clause is checked against its retained nominal source inventory
-- and complete request after proof restoration and lowering. Missing source
-- authority, unsupported dictionary evidence, or a bounded checking failure
-- remains explicit; formula atoms are never used as source type declarations.
data DjinnTermGraphAbsence
    = DjinnTermGraphSourceTypingContextUnavailable
    | DjinnTermGraphSourceTypingFailure String
    deriving (Eq, Ord, Show)

-- | Graph-local source identity domain. Flexible variables remain distinct
-- from the fresh rigid openings of nested foralls. The compatibility 'DjinnCandidate' type
-- deliberately retains its historical untagged variable domain.
type DjinnTermGraphTypeVariable = SharedType.Variable HSymbol

-- | Source-type vocabulary of a checked Djinn graph.
type DjinnTermGraphType = SharedType.Type DjinnTermGraphTypeVariable

-- | One checked compatibility candidate paired with its explicit typed-graph
-- availability.  The association is constructed before proof evidence is
-- erased from the final result.
type DjinnTypedCandidate =
    SharedTypedCandidate.TypedCandidate DjinnTermGraphAbsence
        DjinnTermGraphType HSymbol DjinnCandidate

-- | Djinn-specific explanatory data retained in the shared result batch.
-- Formula translation and the first explored proof are diagnostics rather
-- than operational search status or logical evidence.
data DjinnQueryMetadata = DjinnQueryMetadata {
    djinnTranslatedFormula :: String,
    djinnFirstExploredProof :: Maybe String
    }
    deriving (Eq, Show)

-- | Canonical structured result of one Djinn proof search.  The proof core
-- constructs the shared envelope directly; checked adapters consume this
-- value without unpacking and rebuilding an intermediate report.
type DjinnResult =
    SharedQuery.QueryResult DjinnQueryMetadata DjinnCandidate

-- | Canonical Djinn result retaining the typed-candidate association.
-- Logical evidence, completion, metadata, candidate ordering, and
-- compatibility output are identical to 'DjinnResult'.
type DjinnTypedResult =
    SharedQuery.QueryResult DjinnQueryMetadata DjinnTypedCandidate

-- | Failure from the canonical checked result path. Invalid controls,
-- ordinary input rejection, internal proof/projection failures, and an
-- impossible evidence/candidate mismatch remain distinguishable for
-- structured adapters; compatibility projections retain historical text.
data DjinnQueryError
    = DjinnQueryOptionsFailure DjinnQueryOptionsError
    | DjinnQueryFailure String
    | DjinnInstantiationCandidateFailure String
    | DjinnInstantiationAssignmentFailure String
    | DjinnInternalQueryFailure String
    | DjinnResultInvariantFailure SharedQuery.QueryResultInvariantError
    deriving (Eq, Show)

-- | Invalid controls rejected before proof search. Keeping the supplied value
-- makes the stable adapter able to classify options independently while the
-- historical string API can retain its exact message.
data DjinnQueryOptionsError
    = NonPositiveCandidateCutoff Int
    | NegativeChoicePointBudget Integer
    deriving (Eq, Show)

-- | Historical structured report retained only at the compatibility edge.
-- Proof search itself constructs 'DjinnResult'; this DTO is projected from
-- that checked value for callers of 'inhabitGenerated'.
data GeneratedQueryReport = GeneratedQueryReport {
    generatedReportFormula :: String,
    generatedReportProof :: Maybe String,
    generatedReportCompletion :: SharedSearch.Completion,
    generatedReportCandidates :: [DjinnCandidate],
    generatedReportEvidence :: SharedQuery.QueryEvidence
    }
    deriving (Eq, Show)

-- | The logical verdict of a compatibility 'inhabit' query, mirroring the
-- backend-independent evidence classification with the candidates already
-- rendered as Haskell.  Only 'Realized' carries clauses; the other
-- constructors distinguish a proved-uninhabitable goal from an undecided one.
data QueryOutcome
    -- | Rendered Haskell clauses, best candidate first, de-duplicated.
    = Realized [String]
    -- | The search space was exhausted: no total inhabitant exists.
    | Unrealizable
    -- | The only assumption that could realize the goal is the target
    -- name itself, which would print as general recursion.
    | UnrealizableWithoutSelfReference
    -- | The search budget expired or formula coverage remained incomplete;
    -- inhabitation is undecided.
    | Undecided
    deriving (Eq, Show)

-- | The result of a successful 'inhabit' call: the translated formula, the
-- search completion status, the scope-checked candidate clauses, and the
-- rendered 'QueryOutcome' derived from them.
data QueryReport = QueryReport {
    -- | The intuitionistic formula the goal type translated to.
    reportFormula :: String,
    -- | The first internal proof term, when one was found.
    reportProof :: Maybe String,
    -- | Whether the configured proof exploration finished normally or stopped
    -- at its choice-point or candidate bound. Logical negative evidence
    -- remains in 'reportOutcome' rather than being conflated with this status.
    reportCompletion :: SharedSearch.Completion,
    -- | Scope-checked backend-independent candidates. The rendered
    -- compatibility strings in 'Realized' are derived from these values.
    reportGeneratedClauses ::
        [SharedGenerated.FunctionClause HSymbol],
    -- | The verdict; 'Realized' holds the rendering of
    -- 'reportGeneratedClauses'.
    reportOutcome :: QueryOutcome
    }
    deriving (Show)

-- | Compatibility search that renders every canonical result as Haskell.
--
-- The target name is the defined identifier in the rendered clauses; a
-- same-named function assumption is excluded from the search rather than
-- rendered as recursion.  Contexts are resolved through the environment's
-- classes for arity and kind validation, but their methods do not become
-- proof premises.  'Left' reports invalid input or an internal rendering
-- failure, never an unprovable goal — that is 'Unrealizable'.
inhabit :: QueryOptions -> Environment -> [Context] -> HSymbol -> HType
        -> Either String QueryReport
inhabit options environment contexts name goal = do
    generated <- inhabitGenerated options environment contexts name goal
    -- Rendering belongs only to this compatibility layer.  Canonical callers
    -- retain the scope-checked clause and choose their own presentation policy.
    renderedClauses <- labeled "cannot render generated clause" $
        mapM (renderGeneratedClause . SharedCandidate.candidateOutput) $
            generatedReportCandidates generated
    return QueryReport {
        reportFormula = generatedReportFormula generated,
        reportProof = generatedReportProof generated,
        reportCompletion = generatedReportCompletion generated,
        reportGeneratedClauses =
            map SharedCandidate.candidateOutput $
                generatedReportCandidates generated,
        reportOutcome = evidenceOutcome
            (generatedReportEvidence generated) renderedClauses
        }
  where
    labeled what = either (Left . ((what ++ ": ") ++)) Right

-- | Canonical search for checked structured candidates without committing to
-- a rendering policy. The exact checked target becomes the candidate clause
-- name and the proof core constructs the shared result envelope directly.
--
-- Across all candidate-producing formula plans, at most @optionCutoff + 1@
-- proofs are observed. The extra observation is solely a truncation witness:
-- when present, neither the remaining proof stream nor 'searchExhausted' is
-- forced. When absent, reaching the end of the prefix has already established
-- whether proof search finished or spent its choice-point budget.
inhabitResult
    :: QueryOptions
    -> Environment
    -> [Context]
    -> SharedGenerated.DefinitionName
    -> HType
    -> Either DjinnQueryError DjinnResult
inhabitResult options environment contexts target goal = do
    first DjinnQueryOptionsFailure $ validateQueryOptions options
    prepared <- first DjinnQueryFailure $
        prepareCompatibilityEnvironment environment
    inhabitResultPreparedChecked options prepared contexts target goal

-- | Search using a sealed environment.  The context and goal obligations share
-- the cached kind and synonym assumptions prepared with the session; this
-- function never reconstructs them from 'envTypes'.
inhabitResultPrepared
    :: QueryOptions
    -> PreparedEnvironment
    -> [Context]
    -> SharedGenerated.DefinitionName
    -> HType
    -> Either DjinnQueryError DjinnResult
inhabitResultPrepared options prepared contexts target goal = do
    first DjinnQueryOptionsFailure $ validateQueryOptions options
    inhabitResultPreparedChecked options prepared contexts target goal

-- | Search a sealed Djinn environment while keeping the query in Djex's
-- common type representation through validation, kind checking, synonym
-- elaboration, and formula compilation. The
-- native path never crosses even the zero-copy historical 'HType' view.
inhabitSynthesisResultPrepared
    :: QueryOptions
    -> PreparedEnvironment
    -> [Constraint (SharedType.Type HSymbol)]
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError DjinnResult
inhabitSynthesisResultPrepared options prepared contexts target goal =
    inhabitSynthesisResultPreparedWithInstantiationCandidates
        options prepared contexts [] target goal

-- | Typed-result counterpart of 'inhabitSynthesisResultPrepared'.  This is
-- the canonical checked path; the compatibility runner is its graph-ignoring
-- projection.
inhabitTypedSynthesisResultPrepared
    :: QueryOptions
    -> PreparedEnvironment
    -> [Constraint (SharedType.Type HSymbol)]
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError DjinnTypedResult
inhabitTypedSynthesisResultPrepared options prepared contexts target goal =
    inhabitTypedSynthesisResultPreparedWithInstantiationCandidates
        options prepared contexts [] target goal

-- | Search a sealed Djinn environment with externally established,
-- provider-local type choices. Each association is checked against the exact
-- prepared provider and type/kind/synonym scope before it can add a separate
-- proof-producing search tail. The ordinary entrance above is the exact empty
-- evidence case.
inhabitSynthesisResultPreparedWithInstantiationCandidates
    :: QueryOptions
    -> PreparedEnvironment
    -> [Constraint (SharedType.Type HSymbol)]
    -> [SharedQuery.ProviderInstantiationCandidate HSymbol]
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError DjinnResult
inhabitSynthesisResultPreparedWithInstantiationCandidates options prepared
        contexts candidates target goal = do
    first DjinnQueryOptionsFailure $ validateQueryOptions options
    -- Resolution owns the observable query-failure order: class lookup and
    -- arity precede type inspection, while synonym saturation precedes full
    -- structural validation and kind inference. Elaboration returns the
    -- canonical alias-free types consumed at the formula boundary.
    inhabitSynthesisResultPreparedChecked
        options prepared contexts candidates
        (InferredProviderInstantiationAssignments []) target goal

-- | Typed-result counterpart of
-- 'inhabitSynthesisResultPreparedWithInstantiationCandidates'.
inhabitTypedSynthesisResultPreparedWithInstantiationCandidates
    :: QueryOptions
    -> PreparedEnvironment
    -> [Constraint (SharedType.Type HSymbol)]
    -> [SharedQuery.ProviderInstantiationCandidate HSymbol]
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError DjinnTypedResult
inhabitTypedSynthesisResultPreparedWithInstantiationCandidates options prepared
        contexts candidates target goal = do
    first DjinnQueryOptionsFailure $ validateQueryOptions options
    inhabitSynthesisTypedResultPreparedChecked
        options prepared contexts candidates
        (InferredProviderInstantiationAssignments []) target goal

-- | Search a sealed Djinn environment with externally established complete
-- leading-binder assignments for exact providers.  Each ordered vector is
-- validated and consumed directly, without reconstructing candidate tuples.
-- The historical and candidate entrances remain the exact empty-assignment
-- cases of the common checked worker.
inhabitSynthesisResultPreparedWithInstantiationAssignments
    :: QueryOptions
    -> PreparedEnvironment
    -> [Constraint (SharedType.Type HSymbol)]
    -> [SharedQuery.ProviderInstantiationAssignment HSymbol]
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError DjinnResult
inhabitSynthesisResultPreparedWithInstantiationAssignments options prepared
        contexts assignments target goal = do
    first DjinnQueryOptionsFailure $ validateQueryOptions options
    inhabitSynthesisResultPreparedChecked
        options prepared contexts []
        (InferredProviderInstantiationAssignments assignments) target goal

-- | Typed-result counterpart of
-- 'inhabitSynthesisResultPreparedWithInstantiationAssignments'.
inhabitTypedSynthesisResultPreparedWithInstantiationAssignments
    :: QueryOptions
    -> PreparedEnvironment
    -> [Constraint (SharedType.Type HSymbol)]
    -> [SharedQuery.ProviderInstantiationAssignment HSymbol]
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError DjinnTypedResult
inhabitTypedSynthesisResultPreparedWithInstantiationAssignments options prepared
        contexts assignments target goal = do
    first DjinnQueryOptionsFailure $ validateQueryOptions options
    inhabitSynthesisTypedResultPreparedChecked
        options prepared contexts []
        (InferredProviderInstantiationAssignments assignments) target goal

-- | Search a sealed Djinn environment with complete assignments whose exact
-- leading-binder ground kinds were retained by the caller. Supplied kinds are
-- checked against every occurrence in the provider body; unlike the
-- compatibility entrance above, an otherwise vacuous binder need not default
-- to @Type@.
inhabitSynthesisResultPreparedWithKindedInstantiationAssignments
    :: QueryOptions
    -> PreparedEnvironment
    -> [Constraint (SharedType.Type HSymbol)]
    -> [SharedQuery.KindedProviderInstantiationAssignment HSymbol]
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError DjinnResult
inhabitSynthesisResultPreparedWithKindedInstantiationAssignments options
        prepared contexts assignments target goal = do
    first DjinnQueryOptionsFailure $ validateQueryOptions options
    inhabitSynthesisResultPreparedChecked
        options prepared contexts []
        (KindedProviderInstantiationAssignments assignments) target goal

-- | Typed-result counterpart of
-- 'inhabitSynthesisResultPreparedWithKindedInstantiationAssignments'.
inhabitTypedSynthesisResultPreparedWithKindedInstantiationAssignments
    :: QueryOptions
    -> PreparedEnvironment
    -> [Constraint (SharedType.Type HSymbol)]
    -> [SharedQuery.KindedProviderInstantiationAssignment HSymbol]
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError DjinnTypedResult
inhabitTypedSynthesisResultPreparedWithKindedInstantiationAssignments options
        prepared contexts assignments target goal = do
    first DjinnQueryOptionsFailure $ validateQueryOptions options
    inhabitSynthesisTypedResultPreparedChecked
        options prepared contexts []
        (KindedProviderInstantiationAssignments assignments) target goal

-- | The provider evidence carried by a prepared source-aware request. Each
-- branch crosses the same bounded validation as its existing public runner.
data DjinnSourceProviderEvidence
    = DjinnSourceInstantiationCandidates
        [SharedQuery.ProviderInstantiationCandidate HSymbol]
    | DjinnSourceInstantiationAssignments
        [SharedQuery.ProviderInstantiationAssignment HSymbol]
    | DjinnSourceKindedInstantiationAssignments
        [SharedQuery.KindedProviderInstantiationAssignment HSymbol]

-- | Preserve the complete source goal while searching its already prepared
-- implicit form. The source and search types must have the exact contextual
-- relationship produced by leading-forall opening; an unrelated source goal
-- cannot acquire either a candidate graph or negative search evidence.
inhabitTypedSynthesisResultPreparedWithSourceGoal
    :: QueryOptions
    -> PreparedEnvironment
    -> SharedType.Type HSymbol
    -> [Constraint (SharedType.Type HSymbol)]
    -> DjinnSourceProviderEvidence
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError DjinnTypedResult
inhabitTypedSynthesisResultPreparedWithSourceGoal options prepared sourceGoal =
    inhabitTypedSynthesisResultPreparedWithSourceGoalInput options prepared (PlainSourceGoal sourceGoal)

inhabitTypedSynthesisResultPreparedWithKindedSourceGoal
    :: QueryOptions
    -> PreparedEnvironment
    -> SourceKinds.SourceTypeKinds HSymbol
    -> [Constraint (SharedType.Type HSymbol)]
    -> DjinnSourceProviderEvidence
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError DjinnTypedResult
inhabitTypedSynthesisResultPreparedWithKindedSourceGoal options prepared checked =
    inhabitTypedSynthesisResultPreparedWithSourceGoalInput options prepared (KindedSourceGoal checked)

inhabitTypedSynthesisResultPreparedWithSourceGoalInput
    :: QueryOptions
    -> PreparedEnvironment
    -> SourceGoalInput
    -> [Constraint (SharedType.Type HSymbol)]
    -> DjinnSourceProviderEvidence
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError DjinnTypedResult
inhabitTypedSynthesisResultPreparedWithSourceGoalInput options prepared sourceGoal
        contexts evidence target goal = do
    first DjinnQueryOptionsFailure $ validateQueryOptions options
    let (candidates, assignments) = case evidence of
            DjinnSourceInstantiationCandidates supplied ->
                (supplied, InferredProviderInstantiationAssignments [])
            DjinnSourceInstantiationAssignments supplied ->
                ([], InferredProviderInstantiationAssignments supplied)
            DjinnSourceKindedInstantiationAssignments supplied ->
                ([], KindedProviderInstantiationAssignments supplied)
    inhabitSynthesisTypedResultPreparedCheckedWithSourceGoal (Just sourceGoal)
        options prepared contexts candidates assignments target goal

-- | Incrementally enumerate checked candidates from a source-aware request.
-- Request validation is eager in the outer 'Either'; each lazy observation
-- then contains either a continuing singleton candidate, a terminal empty
-- result, or a terminal search failure. Dropping the tail cancels all future
-- proof search and source-graph construction. Candidate graph keys are unique
-- throughout the stream, rather than restarting at each singleton batch.
--
-- Candidates retain deterministic proof-plan encounter order. Global result
-- sorting and ranking require a complete pool and belong to the batch API;
-- this entrance deliberately does not apply them. Search strategy and local
-- provider costs still guide the same proof cursors. The configured raw-proof
-- cutoff and choice budget are shared by every resumed plan, including raw
-- proofs discarded by checking or cross-plan de-duplication.
-- Reaching the raw cutoff reports 'SharedSearch.CandidateLimitReached'
-- without inspecting another proof or choice. The historical sequential
-- batch runner probes for an overflow proof and can therefore observe a
-- different later completion (including choice exhaustion) at that boundary.
inhabitTypedSynthesisStreamPreparedWithSourceGoal
    :: QueryOptions
    -> PreparedEnvironment
    -> SharedType.Type HSymbol
    -> [Constraint (SharedType.Type HSymbol)]
    -> DjinnSourceProviderEvidence
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError [Either DjinnQueryError DjinnTypedResult]
inhabitTypedSynthesisStreamPreparedWithSourceGoal options prepared sourceGoal =
    inhabitTypedSynthesisStreamPreparedWithSourceGoalInput options prepared (PlainSourceGoal sourceGoal)

inhabitTypedSynthesisStreamPreparedWithKindedSourceGoal
    :: QueryOptions
    -> PreparedEnvironment
    -> SourceKinds.SourceTypeKinds HSymbol
    -> [Constraint (SharedType.Type HSymbol)]
    -> DjinnSourceProviderEvidence
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError [Either DjinnQueryError DjinnTypedResult]
inhabitTypedSynthesisStreamPreparedWithKindedSourceGoal options prepared checked =
    inhabitTypedSynthesisStreamPreparedWithSourceGoalInput options prepared (KindedSourceGoal checked)

inhabitTypedSynthesisStreamPreparedWithSourceGoalInput
    :: QueryOptions
    -> PreparedEnvironment
    -> SourceGoalInput
    -> [Constraint (SharedType.Type HSymbol)]
    -> DjinnSourceProviderEvidence
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError [Either DjinnQueryError DjinnTypedResult]
inhabitTypedSynthesisStreamPreparedWithSourceGoalInput options prepared sourceGoal
        contexts evidence target goal = do
    first DjinnQueryOptionsFailure $ validateQueryOptions options
    let (candidates, assignments) = case evidence of
            DjinnSourceInstantiationCandidates supplied ->
                (supplied, InferredProviderInstantiationAssignments [])
            DjinnSourceInstantiationAssignments supplied ->
                ([], InferredProviderInstantiationAssignments supplied)
            DjinnSourceKindedInstantiationAssignments supplied ->
                ([], KindedProviderInstantiationAssignments supplied)
    preparedSearch <- inhabitSynthesisPreparedSearchChecked (Just sourceGoal)
        options prepared contexts candidates assignments target goal
    pure $ preparedFormulaCandidateStream preparedSearch

-- | Compatibility projection of 'inhabitResult'.
inhabitGenerated :: QueryOptions -> Environment -> [Context] -> HSymbol -> HType
                 -> Either String GeneratedQueryReport
inhabitGenerated options environment contexts name goal = do
    target <- validateGeneratedQueryTarget name
    result <- first renderDjinnQueryError $
        inhabitResult options environment contexts target goal
    resultToGeneratedReport result

-- | Compatibility projection of 'inhabitResultPrepared'.
inhabitGeneratedPrepared
    :: QueryOptions -> PreparedEnvironment -> [Context] -> HSymbol -> HType
    -> Either String GeneratedQueryReport
inhabitGeneratedPrepared options prepared contexts name goal = do
    target <- validateGeneratedQueryTarget name
    result <- first renderDjinnQueryError $
        inhabitResultPrepared options prepared contexts target goal
    resultToGeneratedReport result

validateGeneratedQueryTarget
    :: HSymbol
    -> Either String SharedGenerated.DefinitionName
validateGeneratedQueryTarget name = do
    requireName "target" (isDjinnDeclarationName MethodOwner) name
    rawName <- first show $ SharedName.parseName name
    first show $ SharedGenerated.mkDefinitionName rawName

validateQueryOptions :: QueryOptions -> Either DjinnQueryOptionsError ()
validateQueryOptions options = do
    unless (optionCutoff options > 0) $
        Left $ NonPositiveCandidateCutoff $ optionCutoff options
    case optionBudget options of
        Just n | n < 0 -> Left $ NegativeChoicePointBudget n
        _ -> Right ()

inhabitSynthesisResultPreparedChecked
    :: QueryOptions
    -> PreparedEnvironment
    -> [Constraint (SharedType.Type HSymbol)]
    -> [SharedQuery.ProviderInstantiationCandidate HSymbol]
    -> ProviderInstantiationAssignmentEvidence
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError DjinnResult
inhabitSynthesisResultPreparedChecked options prepared contexts candidates
        assignmentEvidence target goal =
    SharedTypedCandidate.typedQueryResultCompatibility <$>
        inhabitSynthesisTypedResultPreparedChecked
            options prepared contexts candidates assignmentEvidence target goal

inhabitSynthesisTypedResultPreparedChecked
    :: QueryOptions
    -> PreparedEnvironment
    -> [Constraint (SharedType.Type HSymbol)]
    -> [SharedQuery.ProviderInstantiationCandidate HSymbol]
    -> ProviderInstantiationAssignmentEvidence
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError DjinnTypedResult
inhabitSynthesisTypedResultPreparedChecked options prepared contexts candidates
        assignmentEvidence target goal =
    inhabitSynthesisTypedResultPreparedCheckedWithSourceGoal Nothing
        options prepared contexts candidates assignmentEvidence target goal

inhabitSynthesisTypedResultPreparedCheckedWithSourceGoal
    :: Maybe SourceGoalInput
    -> QueryOptions
    -> PreparedEnvironment
    -> [Constraint (SharedType.Type HSymbol)]
    -> [SharedQuery.ProviderInstantiationCandidate HSymbol]
    -> ProviderInstantiationAssignmentEvidence
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError DjinnTypedResult
inhabitSynthesisTypedResultPreparedCheckedWithSourceGoal sourceGoal options
        prepared contexts candidates assignmentEvidence target goal = do
    validated <- inhabitSynthesisValidatedResultPreparedChecked
        sourceGoal options prepared contexts candidates assignmentEvidence target goal
    first DjinnResultInvariantFailure $
        projectValidatedTypedDjinnResult validated

-- All stable result views meet at this sidecar-retaining worker.  Projection
-- happens only after proof checking, conversion, cross-plan de-duplication,
-- and the configured final ordering step has moved whole associations into
-- their final order.
inhabitSynthesisValidatedResultPreparedChecked
    :: Maybe SourceGoalInput
    -> QueryOptions
    -> PreparedEnvironment
    -> [Constraint (SharedType.Type HSymbol)]
    -> [SharedQuery.ProviderInstantiationCandidate HSymbol]
    -> ProviderInstantiationAssignmentEvidence
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError ValidatedDjinnResult
inhabitSynthesisValidatedResultPreparedChecked sourceGoal options prepared
        contexts candidates assignmentEvidence target goal = do
    preparedSearch <- inhabitSynthesisPreparedSearchChecked sourceGoal options
        prepared contexts candidates assignmentEvidence target goal
    preparedFormulaBatchResult preparedSearch

-- Validation and formula-family preparation are shared by batch and streaming
-- execution. Neither constructing this record nor selecting one field forces
-- the other execution, and no cursor exists until that execution is observed.
inhabitSynthesisPreparedSearchChecked
    :: Maybe SourceGoalInput
    -> QueryOptions
    -> PreparedEnvironment
    -> [Constraint (SharedType.Type HSymbol)]
    -> [SharedQuery.ProviderInstantiationCandidate HSymbol]
    -> ProviderInstantiationAssignmentEvidence
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError PreparedFormulaSearch
inhabitSynthesisPreparedSearchChecked sourceGoal options prepared
        contexts candidates assignmentEvidence target goal = do
    elaboratedGoal <- resolveSynthesisQueryContexts prepared
        ( "goal type " ++ renderSynthesisType goal
        , KStar
        , goal
        )
        contexts
    let translatePlans =
            preparedEnvironmentPolarizedSynthesisFormulaPlans prepared
        translateNominalPlans =
            preparedEnvironmentNominalPolarizedSynthesisFormulaPlans prepared
        translateType translator label source =
            first (label ++) $ translator source
    -- Contexts have been checked against the same inventory and kind scope as
    -- the goal, but their methods are intentionally absent from proof search.
    -- A class method is polymorphic in its method-local variables; translating
    -- it to one monomorphic LJT premise made alpha-equivalent signatures
    -- depend on source spelling. Djinn supports the sound, useful subset in
    -- which the synthesized term does not require a class method.
    plans <- translatorFailure $
        translateType translatePlans "goal type: " elaboratedGoal
    let parametricDataRelevant =
            preparedEnvironmentQueryUsesParametricData prepared elaboratedGoal
    nominalPlans <- if parametricDataRelevant
        then translatorFailure $
            translateType translateNominalPlans
                "nominal goal type: " elaboratedGoal
        else Right plans
    checkedCandidates <- prepareProviderInstantiationCandidates
        prepared candidates
    checkedAssignments <- prepareProviderInstantiationAssignments
        prepared assignmentEvidence
    (checkedSourceGoal, checkedLexicalGoal) <- case sourceGoal of
        Nothing -> Right (elaboratedGoal, Nothing)
        Just (PlainSourceGoal original) -> do
            checked <- resolveSynthesisQueryContexts prepared
                ("source goal type " ++ renderSynthesisType original, KStar, original) []
            checkSourceSearchCorrespondence original contexts goal
            pure (checked, Nothing)
        Just (KindedSourceGoal checked) -> do
            checkSourceSearchCorrespondence (SourceKinds.sourceKindsType checked) contexts goal
            expanded <- first DjinnInternalQueryFailure $ expandSourceGoalKinds prepared checked
            pure (SourceKinds.sourceKindsType expanded, Just expanded)
    -- This table becomes authority only after the bounded assignment checker
    -- has checked every supplied kind, exact provider, and correlated vector.
    let providerKinds = case assignmentEvidence of
            InferredProviderInstantiationAssignments{} -> Map.empty
            KindedProviderInstantiationAssignments assignments -> Map.fromList
                [ ( SharedQuery.kindedProviderInstantiationAssignmentProvider assignment
                  , map fst $ SharedQuery.kindedProviderInstantiationAssignmentArguments assignment
                  )
                | assignment <- assignments
                ]
    sourceContext <- first DjinnInternalQueryFailure $ case checkedLexicalGoal of
        Nothing -> Right $ SourceEvidence.sourceTypingContextWithProviderKinds
            prepared checkedSourceGoal providerKinds
        Just checked -> SourceEvidence.sourceTypingContextWithCheckedGoal
            prepared checked providerKinds
    pure $ prepareFormulaSearch options sourceContext checkedCandidates checkedAssignments target
        elaboratedGoal
        parametricDataRelevant
        (null contexts && null (SharedType.typeConstraints checkedSourceGoal))
        plans nominalPlans
  where
    translatorFailure = first DjinnInternalQueryFailure

-- The checked source value stays separate from the implicit search projection.
data SourceGoalInput
    = PlainSourceGoal (SharedType.Type HSymbol)
    | KindedSourceGoal (SourceKinds.SourceTypeKinds HSymbol)

expandSourceGoalKinds
    :: PreparedEnvironment -> SourceKinds.SourceTypeKinds HSymbol
    -> Either String (SourceKinds.SourceTypeKinds HSymbol)
expandSourceGoalKinds prepared checked = do
    unless (SourceKinds.sourceKindAssumptions checked == SharedInventory.inventoryKindAssumptions inventory) $
        Left "checked source goal belongs to a different kind inventory"
    first show $ SourceKindExpansion.expandSourceTypeKinds fresh definitions checked
  where
    inventory = preparedEnvironmentInventory prepared
    definitions = Map.fromList
        [(name, (map SourceDeclaration.parameterVariable parameters, body))
        | SourceDeclaration.TypeSynonymDeclaration _ name parameters body <-
            SharedEnvironment.environmentDeclarations $ SharedInventory.inventoryEnvironment inventory]
    fresh reserved variable = Just $ choose $ variable ++ "'"
      where
        choose candidate | Set.member candidate reserved = choose $ candidate ++ "'"
                         | otherwise = candidate

-- The adapter normalizes and opens all leading binders before separating the
-- class context from the search goal. Reproduce that operation as one type,
-- retaining the variable identities shared by contexts and the goal. This
-- check intentionally precedes no historical validation and changes none of
-- the search inputs. The source type is independently elaborated above.
checkSourceSearchCorrespondence
    :: SharedType.Type HSymbol
    -> [Constraint (SharedType.Type HSymbol)]
    -> SharedType.Type HSymbol
    -> Either DjinnQueryError ()
checkSourceSearchCorrespondence source contexts goal = do
    normalizedSource <- normalize source
    opened <- first (DjinnInternalQueryFailure . show)
        $ fst <$> SharedType.implicitizeLeadingForalls
            (const (Nothing :: Maybe ())) freshTypeVariable Set.empty normalizedSource
    normalizedOpened <- normalize opened
    normalizedSearch <- normalize $ SharedType.ForallType [] contexts goal
    -- Normalization retains an empty forall wrapper. Compare the complete
    -- prenex decomposition so a context-free wrapper is immaterial, while
    -- actual binders, joint contexts, and every residual type boundary remain
    -- exact. In particular, the supplied search type cannot bind a variable
    -- which the source opening deliberately made implicit.
    unless (SharedType.splitLeadingForalls normalizedOpened ==
            SharedType.splitLeadingForalls normalizedSearch) $
        internalQueryFailure "prepared search goal does not match its preserved source goal"
  where
    normalize = first (DjinnInternalQueryFailure . show) . normalizeSynthesisType
    freshTypeVariable unavailable variable =
        Just $ fst $ freshPrimedVariable unavailable variable

inhabitResultPreparedChecked
    :: QueryOptions
    -> PreparedEnvironment
    -> [Context]
    -> SharedGenerated.DefinitionName
    -> HType
    -> Either DjinnQueryError DjinnResult
inhabitResultPreparedChecked options prepared contexts target goal = do
    -- Preserve the historical raw-API precedence before crossing the
    -- compatibility boundary: class lookup and arity errors precede errors in
    -- the goal, while synonym saturation precedes structural conversion.
    -- The native worker repeats these cheap checks against the shared class
    -- index, then owns elaboration, method instantiation, and proof search.
    resolved <- first DjinnQueryFailure $
        mapM (lookupResolvedContext prepared) contexts
    first DjinnQueryFailure $ checkKindObligations prepared $
        ("goal type " ++ show goal, KStar, goal) :
        concatMap argumentObligations resolved
    sharedGoal <- projectGoal goal
    sharedContexts <- projectContexts contexts
    inhabitSynthesisResultPreparedChecked
        options prepared sharedContexts []
        (InferredProviderInstantiationAssignments []) target sharedGoal
  where
    projectGoal source = case toSynthesisType source of
        Right projected -> Right projected
        Left failure -> internalQueryFailure $
            "checked raw goal projection failed: " ++ show failure

    projectContexts sources = case mapM (traverse toSynthesisType) sources of
        Right projected -> Right projected
        Left failure -> internalQueryFailure $
            "checked raw context projection failed: " ++ show failure

type PreparedProviderInstantiationCandidate =
    ( Symbol
    , SharedType.Type HSymbol
    , SharedGenerated.VisibleTypeArgument
    )

type PreparedProviderInstantiationAssignment =
    ( Symbol
    , [( SharedType.Type HSymbol
       , SharedGenerated.VisibleTypeArgument
       )]
    )

data ProviderInstantiationAssignmentEvidence
    = InferredProviderInstantiationAssignments
        [SharedQuery.ProviderInstantiationAssignment HSymbol]
    | KindedProviderInstantiationAssignments
        [SharedQuery.KindedProviderInstantiationAssignment HSymbol]

data ProviderInstantiationAssignmentInput
    = InferredProviderInstantiationAssignment
        (SharedQuery.ProviderInstantiationAssignment HSymbol)
    | KindedProviderInstantiationAssignment
        (SharedQuery.KindedProviderInstantiationAssignment HSymbol)

-- Validate external provider evidence only after the ordinary goal and
-- contexts have crossed their established request boundary. The list spine is
-- bounded before any element is entered, making cyclic caller-built evidence
-- a finite query failure. Types are then elaborated independently in source
-- order so one provider's binders cannot share kind variables with another;
-- closedness makes that independence semantic rather than merely diagnostic.
prepareProviderInstantiationCandidates
    :: PreparedEnvironment
    -> [SharedQuery.ProviderInstantiationCandidate HSymbol]
    -> Either DjinnQueryError [PreparedProviderInstantiationCandidate]
prepareProviderInstantiationCandidates prepared rawCandidates = do
    let maximumCandidates =
            SharedQuery.maximumProviderInstantiationCandidates
        observed = SharedCollection.observedListLength
            maximumCandidates rawCandidates
    when (observed > maximumCandidates)
        $ Left $ DjinnInstantiationCandidateFailure $
            "provider instantiation candidate count exceeds " ++
                show maximumCandidates
    (_, retained) <- foldM validateCandidate (Map.empty, []) $
        zip [0 :: Int ..] rawCandidates
    return $ reverse retained
  where
    (loadedSchemes, nominalLoadedSchemes, _) =
        preparedEnvironmentLoadedFunctionInstantiation prepared
    loadedProviders = Set.fromList $
        map fst loadedSchemes ++ map fst nominalLoadedSchemes

    validateCandidate (seen, retained) (index, candidate) = do
        let providerName =
                SharedQuery.providerInstantiationCandidateProvider candidate
            source = SharedQuery.providerInstantiationCandidateType candidate
            label = "provider instantiation candidate #" ++ show index ++
                " for " ++ SharedName.renderCanonical providerName ++ ": "
        providerSpelling <- first
            (DjinnInstantiationCandidateFailure . (label ++)) $
            synthesisFunctionSymbol providerName
        let provider = Symbol providerSpelling
        if provider `Set.member` loadedProviders
            then return ()
            else Left $ DjinnInstantiationCandidateFailure $ label ++
                "provider is not an exact loaded polymorphic value"
        elaborated <- first
            (DjinnInstantiationCandidateFailure . (label ++)) $
            elaboratePreparedSynthesisTypes prepared [(KStar, source)]
        checked <- case elaborated of
            [one] -> Right one
            _ -> Left $ DjinnInternalQueryFailure
                "provider candidate elaboration changed batch shape"
        unless (Set.null $ SharedType.freeVariables checked) $
            Left $ DjinnInstantiationCandidateFailure $
                label ++ "type is not closed"
        unless (null $ SharedType.typeConstraints checked) $
            Left $ DjinnInstantiationCandidateFailure $
                label ++ "type is not context-free"
        visible <- first
            (DjinnInstantiationCandidateFailure . (label ++) . show) $
            SharedGenerated.specifiedVisibleTypeArgument checked
        let key = SharedTypeAtom.alphaTypeKey checked
            providerKeys = Map.findWithDefault Set.empty provider seen
        if key `Set.member` providerKeys
            then Right (seen, retained)
            else Right
                ( Map.insert provider (Set.insert key providerKeys) seen
                , (provider, checked, visible) : retained
                )

-- Bound both list spines before entering caller-owned argument values.  Once
-- an assignment is known to have the exact provider arity, either infer its
-- binder kinds from the retained provider body or validate the caller's exact
-- positional kinds against that body, then elaborate each paired argument and
-- retain its visible syntax. The complete substituted provider body is
-- kind-checked as a final independent specialization guard.
-- Alpha-equivalent vectors are de-duplicated per provider without losing the
-- order or correlation within a vector.
prepareProviderInstantiationAssignments
    :: PreparedEnvironment
    -> ProviderInstantiationAssignmentEvidence
    -> Either DjinnQueryError [PreparedProviderInstantiationAssignment]
prepareProviderInstantiationAssignments prepared evidence = do
    let maximumAssignments =
            SharedQuery.maximumProviderInstantiationAssignments
        rawAssignments = case evidence of
            InferredProviderInstantiationAssignments assignments ->
                map InferredProviderInstantiationAssignment assignments
            KindedProviderInstantiationAssignments assignments ->
                map KindedProviderInstantiationAssignment assignments
        observed = SharedCollection.observedListLength
            maximumAssignments rawAssignments
    when (observed > maximumAssignments)
        $ Left $ DjinnInstantiationAssignmentFailure $
            "provider instantiation assignment count exceeds " ++
                show maximumAssignments
    (_, _, retained) <- foldM validateAssignment
        (Map.empty, Map.empty, []) $
        zip [0 :: Int ..] rawAssignments
    return $ reverse retained
  where
    (loadedSchemes, _, _) =
        preparedEnvironmentLoadedFunctionInstantiation prepared
    loadedSchemeSources = Map.fromList
        [ (provider, source)
        | (provider, formula) <- loadedSchemes
        , PVar opaque <- [formula]
        , Just source <- [opaqueSymbolSource opaque]
        ]

    validateAssignment
            (seenKinds, seenArguments, retained) (index, assignment) = do
        let (providerName, suppliedKinds, arguments) =
                case assignment of
                    InferredProviderInstantiationAssignment unkinded ->
                        let rawArguments =
                                SharedQuery.providerInstantiationAssignmentArguments
                                    unkinded
                        in
                        ( SharedQuery.providerInstantiationAssignmentProvider
                            unkinded
                        , Nothing
                        , rawArguments
                        )
                    KindedProviderInstantiationAssignment kinded ->
                        let rawArguments =
                                SharedQuery.kindedProviderInstantiationAssignmentArguments
                                    kinded
                        in
                        ( SharedQuery.kindedProviderInstantiationAssignmentProvider
                            kinded
                        , Just $ map fst rawArguments
                        , map snd rawArguments
                        )
            assignmentLabel =
                "provider instantiation assignment #" ++ show index ++ ": "
        let providerLabel = assignmentLabel ++ "provider " ++
                SharedName.renderCanonical providerName ++ ": "
        providerSpelling <- first
            (DjinnInstantiationAssignmentFailure . (providerLabel ++)) $
            synthesisFunctionSymbol providerName
        let provider = Symbol providerSpelling
        schemeSource <- case Map.lookup provider loadedSchemeSources of
            Just source -> Right source
            Nothing -> Left $ DjinnInstantiationAssignmentFailure $
                providerLabel ++
                    "provider is not an exact loaded polymorphic value"
        let (binders, schemeConstraints, schemeBody) =
                SharedType.splitLeadingForalls schemeSource
            arity = length binders
            -- A checked retained scheme supplies the finite exact bound.
            -- Overlong and cyclic caller spines are rejected after arity+1
            -- cells, before inspecting any argument value or kind.
            observedArguments = SharedCollection.observedListLength
                arity arguments
        unless (null schemeConstraints) $
            Left $ DjinnInstantiationAssignmentFailure $
                providerLabel ++ "provider scheme is not context-free"
        unless (arity >= 1) $
            Left $ DjinnInstantiationAssignmentFailure $
                providerLabel ++ "leading forall arity " ++ show arity ++
                    " is empty"
        unless (observedArguments == arity) $
            Left $ DjinnInstantiationAssignmentFailure $
                providerLabel ++ "expected " ++ show arity ++
                    " ordered argument(s), but received " ++
                    show observedArguments
        let kindAssumptions = SharedInventory.inventoryKindAssumptions $
                preparedEnvironmentInventory prepared
        groundBinderKinds <- case suppliedKinds of
            Nothing -> map snd <$> first
                (DjinnInstantiationAssignmentFailure .
                    (providerLabel ++) .
                    ("cannot infer provider binder kinds: " ++) . show)
                (SharedKindInference.inferSharedVariableKinds
                    kindAssumptions binders [schemeBody])
            Just suppliedGroundKinds -> do
                mapM_ (validateSuppliedKind providerLabel) $
                    zip [0 :: Int ..] suppliedGroundKinds
                first
                    (DjinnInstantiationAssignmentFailure .
                        (providerLabel ++) .
                        (("supplied provider binder kinds conflict with the " ++
                            "retained body: ") ++) . show) $
                    SharedKindInference.checkTypesKinds kindAssumptions $
                        (SharedKind.ProperTypeKind, schemeBody) :
                        zip suppliedGroundKinds
                            (map SharedType.TypeVariable binders)
                return suppliedGroundKinds
        case Map.lookup provider seenKinds of
            Just previousKinds | previousKinds /= groundBinderKinds ->
                Left $ DjinnInstantiationAssignmentFailure $
                    providerLabel ++
                        "binder kind vector conflicts with another " ++
                        "assignment for this provider; expected " ++
                        show previousKinds ++ ", but received " ++
                        show groundBinderKinds
            _ -> return ()
        let binderKinds = map fromGroundHKind groundBinderKinds
        checkedArguments <- mapM
            (validateArgument providerLabel) $
                zip3 [0 :: Int ..] binderKinds arguments
        instantiatedBody <- first
            (DjinnInstantiationAssignmentFailure .
                (providerLabel ++) .
                ("cannot instantiate provider body: " ++) . show) $
            SharedType.substituteTypeVariables freshTypeVariable Set.empty
                (Map.fromList $ zip binders $ map fst checkedArguments)
                schemeBody
        first (DjinnInstantiationAssignmentFailure .
                (providerLabel ++) .
                ("instantiated provider body is ill-kinded: " ++)) $
            checkPreparedSynthesisTypesKinds prepared [(KStar, instantiatedBody)]
        let key = map (SharedTypeAtom.alphaTypeKey . fst) checkedArguments
            providerKeys = Map.findWithDefault
                Set.empty provider seenArguments
            retainedKinds = Map.insert provider groundBinderKinds seenKinds
        if key `Set.member` providerKeys
            then Right (retainedKinds, seenArguments, retained)
            else Right
                ( retainedKinds
                , Map.insert provider (Set.insert key providerKeys)
                    seenArguments
                , (provider, checkedArguments) : retained
                )

    validateSuppliedKind providerLabel (argumentIndex, kind) =
        let maximumNodes =
                SharedQuery.maximumProviderInstantiationKindNodes
            observedNodes =
                SharedKind.observedKindNodeCount maximumNodes kind
            label = providerLabel ++ "argument #" ++
                show argumentIndex ++ ": "
        in unless (observedNodes <= maximumNodes) $
            Left $ DjinnInstantiationAssignmentFailure $
                label ++ "supplied ground kind node count exceeds " ++
                    show maximumNodes ++ " (observed " ++
                    show observedNodes ++ ")"

    validateArgument providerLabel (argumentIndex, binderKind, source) = do
        let label = providerLabel ++ "argument #" ++
                show argumentIndex ++ ": "
        elaborated <- first
            (DjinnInstantiationAssignmentFailure . (label ++)) $
            elaboratePreparedSynthesisTypes prepared [(binderKind, source)]
        checked <- case elaborated of
            [one] -> Right one
            _ -> Left $ DjinnInternalQueryFailure
                "provider assignment elaboration changed batch shape"
        unless (Set.null $ SharedType.freeVariables checked) $
            Left $ DjinnInstantiationAssignmentFailure $
                label ++ "type is not closed"
        visible <- first
            (DjinnInstantiationAssignmentFailure . (label ++) . show) $
            SharedGenerated.specifiedVisibleTypeArgument checked
        return (checked, visible)

    freshTypeVariable unavailable variable =
        Just $ fst $ freshPrimedVariable unavailable variable

-- Proof search is representation-independent once the checked source query
-- has become a formula. Both the native and raw entrances meet at this single
-- worker; validated class contexts add no premises here, while bounded
-- hypothesis-instantiation axioms occupy appended plans under erased
-- evidence.
data PreparedFormulaSearch = PreparedFormulaSearch
    { preparedFormulaBatchResult :: Either DjinnQueryError ValidatedDjinnResult
    , preparedFormulaCandidateStream :: [Either DjinnQueryError DjinnTypedResult]
    }

prepareFormulaSearch
    :: QueryOptions
    -> SourceEvidence.SourceTypingContext
    -> [PreparedProviderInstantiationCandidate]
    -> [PreparedProviderInstantiationAssignment]
    -> SharedGenerated.DefinitionName
    -> SharedType.Type HSymbol
    -> Bool
    -> Bool
    -> PolarizedFormulaPlans
    -> PolarizedFormulaPlans
    -> PreparedFormulaSearch
prepareFormulaSearch options sourceContext providerCandidates providerAssignments
        target elaboratedGoal parametricDataRelevant sourceNegativeEvidenceSound formulaPlans
        nominalFormulaPlans = PreparedFormulaSearch
    { preparedFormulaBatchResult = do
        results <- if interleavePlanAlternatives
            then runFairPlans (optionCutoff options) (optionBudget options) []
                (initialLanes carrierAlternativeSearchPlans) []
            else runPlans False [] False historicalFamilies
                collectAcrossPlans options (optionCutoff options) [] transportSearchPlans
        mergeFormulaPlanResults options results
    , preparedFormulaCandidateStream = streamPlans (optionCutoff options)
        (optionBudget options) Nothing Nothing Nothing [] 0
        (FormulaStreamQueues 0
            ([FormulaPlanLane (0, 0) False historicalFamilies transportSearchPlans Nothing], [])
            ([FormulaPlanLane (1, 0) False [] demandedStreamingPlans Nothing
                | interleavePlanAlternatives], [])
            ([FormulaPlanLane (2, 0) False [] otherStreamingCarrierPlans Nothing
                | interleavePlanAlternatives], []))
    }
  where
    initialLanes carrierPlans =
        FormulaPlanLane (0, 0) False historicalFamilies transportSearchPlans Nothing :
        [FormulaPlanLane (1, 0) False [] carrierPlans Nothing
        | interleavePlanAlternatives]
    historicalFamilies =
        [(False, contextualSearchPlans) | not interleavePlanAlternatives] ++
        [(False, initialSearchPlans), (True, loadedConstructedAccelerationPlans),
            (False, searchPlans)] ++ deferredInstantiationPlans
    -- Premise partitioning and deterministic plan-family derivation from
    -- the prepared environment and caller-checked evidence. The ordinary
    -- path consumes families sequentially; explicit interleaved alternatives
    -- admit their still-lazy plans incrementally while retaining live cursors.
    (premises, premiseTranslationIncomplete, premiseSpellings) =
        preparedEnvironmentPolarizedFunctionPremises prepared
    (nominalPremises, _, nominalPremiseSpellings) =
        preparedEnvironmentNominalPolarizedFunctionPremises prepared
    ( loadedSchemePremises
      , nominalLoadedSchemePremises
      , environmentClosedCandidates
      ) = preparedEnvironmentLoadedFunctionInstantiation prepared
    targetSymbol = Symbol $ SharedGenerated.definitionSpelling target
    activePremises = filter ((/= targetSymbol) . fst) premises
    targetPremises = filter ((== targetSymbol) . fst) premises
    activeNominalPremises =
        filter ((/= targetSymbol) . fst) nominalPremises
    targetNominalPremises =
        filter ((== targetSymbol) . fst) nominalPremises
    activeLoadedSchemePremises = filter
        ((/= targetSymbol) . fst) loadedSchemePremises
    targetLoadedSchemePremises = filter
        ((== targetSymbol) . fst) loadedSchemePremises
    activeNominalLoadedSchemePremises = filter
        ((/= targetSymbol) . fst) nominalLoadedSchemePremises
    targetNominalLoadedSchemePremises = filter
        ((== targetSymbol) . fst) nominalLoadedSchemePremises
    goalVariables =
        SharedType.freeVariablesInFirstOccurrenceOrder elaboratedGoal
    -- The complete source root is opened jointly, retaining the identities
    -- shared by its Givens and its body. No constraint below an arrow/product
    -- becomes a root assumption. Failed/ambiguous optional openings add no
    -- plan and, like all contextual plans, confer no negative evidence.
    contextualPlanEntries = rootContextualPlanEntries ++ nestedContextualPlanEntries
    rootContextualPlanEntries = do
        Right (Just opening) <- [prepareRootGivenOpening prepared
            (SourceEvidence.sourceTypingGoal sourceContext) elaboratedGoal]
        Right bodyFormula <- [preparedEnvironmentSynthesisFormulaTranslator prepared $
            rootGivenOpeningBody opening]
        let family = Contextual.contextualInstantiationAxioms
                [ sealed
                | (source, vector) <- contextualRequests
                    (rootGivenOpeningContexts opening) [bodyFormula]
                , Right () <- [Contextual.checkContextualInstantiationKinds
                    prepared opening source vector]
                , Right sealed <- [Contextual.sealContextualInstantiation contextualTypeCheck
                    (preparedEnvironmentSynthesisFormulaTranslator prepared) source vector]
                ]
            helpers = filter
                (all (`elem` rootGivenOpeningContexts opening) .
                    Contextual.contextualInstantiationObligations)
                $ Contextual.contextualInstantiations family
        Right erasure <- [SourceEvidence.rootGivenErasure sourceContext opening helpers]
        contextualPlans helpers [] erasure
    -- A nested qualification is introduced only by a checked bridge whose
    -- proof argument binds its dictionaries. It never extends the root pool.
    -- This first scope supports monomorphic qualifiers over the jointly
    -- opened root variables; nested forall eigenvariables remain opaque.
    nestedContextualPlanEntries = do
        Right candidates <- [prepareNestedGivenOpenings prepared
            (SourceEvidence.sourceTypingGoal sourceContext) elaboratedGoal]
        let openings = take SharedQuery.maximumProviderInstantiationAssignments candidates
        firstOpening : _ <- [openings]
        Right introductions <- [Contextual.contextualIntroductions prepared openings]
        Right bodyFormula <- [preparedEnvironmentSynthesisFormulaTranslator prepared elaboratedGoal]
        let available = map nestedGivenOpeningAvailableContexts openings
            family = Contextual.contextualInstantiationAxioms
                [ sealed
                | (source, vector) <- contextualRequests (concat available)
                    (bodyFormula : map Contextual.contextualIntroductionBodyFormula introductions)
                , Right () <- [Contextual.checkNestedContextualInstantiationKinds
                    prepared firstOpening source vector]
                , Right sealed <- [Contextual.sealContextualInstantiation contextualTypeCheck
                    (preparedEnvironmentSynthesisFormulaTranslator prepared) source vector]
                ]
            helpers = filter
                (\helper -> any (\givens -> all (`elem` givens) $
                    Contextual.contextualInstantiationObligations helper) available)
                $ Contextual.contextualInstantiations family
        Right erasure <- [SourceEvidence.nestedGivenErasure sourceContext helpers introductions]
        contextualPlans helpers introductions erasure
    contextualExactPremises = SharedCollection.distinctOn fst $
        activeLoadedSchemePremises ++ filter ((/= targetSymbol) . fst)
            (preparedEnvironmentFunctionPremises prepared)
    contextualTypeCheck = checkPreparedSynthesisTypesKindsWithRigids prepared
        (Set.fromList goalVariables) . (: []) . (,) KStar
    contextualPlans helpers introductions erasure =
        [ ((basePremises ++ [(symbol, form) | (symbol, _, form) <- selected] ++
                [premise | specialized, premise <- instantiationAxiomPremises loaded],
            [], Set.fromList [symbol | (symbol, _, _) <- selected] `Set.union`
                (if specialized then instantiationAxiomSymbols loaded else Set.empty),
            if specialized then instantiationVisibleApplications loaded else Map.empty,
            Map.fromList [(symbol, (source, [])) | (symbol, source, _) <- selected],
            goal, False), erasure)
        | specialized <- False : [True | not $ null $ instantiationAxiomPremises loaded]
        , selected <- if null constructors then [[]] else [[], constructors]
        , specialized || not (null helpers && null introductions && null selected)
        ]
      where
        goal = SourceEvidence.rootGivenErasureGoal erasure
        basePremises =
            [(Contextual.contextualInstantiationSymbol helper,
                Contextual.contextualInstantiationFormula helper) | helper <- helpers] ++
            [(Contextual.contextualIntroductionSymbol helper,
                Contextual.contextualIntroductionFormula helper) | helper <- introductions] ++
            contextualExactPremises
        -- Contextual helpers must compose with retained polymorphic values,
        -- including constructor functions of abstract native datatypes. The
        -- ordinary loaded plans do not carry lexical dictionary erasure, so
        -- specialization in those separate plans cannot supply this proof.
        -- Reuse the bounded, checked instantiation axioms in an additive
        -- contextual plan, retaining visible selections and the common budget.
        loaded = loadedInstantiationAxioms structuralTranslator visibleArgument
            (goalVariables ++ polarizedFormulaPlanSkolems formulaPlans ++ premiseSpellings)
            closedCandidates [goal] (map snd basePremises)
            (map snd activeLoadedSchemePremises)
        -- Contextual plans keep datatypes nominal so dictionary identities do
        -- not drift during structural translation. Offer their checked source
        -- constructors through the existing provider-rewrite boundary instead.
        -- The original plan remains first, and both spend the common budget.
        -- An unused context needs no method helper, but still needs constructor
        -- support. In that case add only the nonempty constructor plan.
        constructors =
            [ ( Symbol $ "$djinn$context-constructor$" ++ show index ++ "$" ++ show constructorIndex
              , Symbol name
              , foldr (:->) opaque fields)
            | (index, (opaque, Disj alternatives)) <- zip [0 :: Natural ..] $
                preparedEnvironmentDataConstructorViews prepared $ goal : map snd basePremises
            , (constructorIndex, (ConsDesc name arity, Conj fields)) <-
                zip [0 :: Natural ..] alternatives
            , arity == length fields
            ]
    contextualRequests availableContexts forms =
        let availableSources = SharedCollection.distinctOn SharedTypeAtom.alphaTypeKey
                [ source
                | symbol <- Set.toList $ Set.unions $
                    map (negativeOpaqueFormulaSymbols PositiveFormula) forms ++
                    map (negativeOpaqueFormulaSymbols NegativeFormula . snd) contextualExactPremises
                , Just source <- [opaqueSymbolSource symbol]
                , let (binders, contexts, _) = SharedType.splitLeadingForalls source
                , not $ null contexts
                , length binders <= SharedQuery.maximumProviderInstantiationArguments
                ]
            vocabulary = take SharedQuery.maximumProviderInstantiationCandidates $
                SharedCollection.distinctOn SharedTypeAtom.alphaTypeKey $
                    map SharedType.TypeVariable goalVariables ++
                    [argument | Constraint _ arguments <- availableContexts,
                        argument <- arguments] ++ closedMonotypeSubtrees elaboratedGoal ++
                    -- Qualified hypotheses need the same source-owned forall
                    -- choices as ordinary instantiation. Keep the existing
                    -- vocabulary prefix; lexical closure excludes subtrees
                    -- that would escape a nested binder. Kind and Given checks
                    -- still validate each complete contextual instantiation.
                    closedQuantifiedSubtrees elaboratedGoal
            tuples source =
                let (binders, _, _) = SharedType.splitLeadingForalls source
                    count = length binders
                in if count == 0 then [[]] else
                    map (replicate count) vocabulary ++ replicateM count vocabulary
            -- Charge optional proposals against the existing finite assignment
            -- bound before type checking/dedup. Proof search still spends its
            -- one shared raw-proof/choice allowance; this is no extra search.
        in take SharedQuery.maximumProviderInstantiationAssignments $
                roundRobin [[(source, vector) | vector <- tuples source]
                    | source <- availableSources]
      where
        roundRobin streams = case [(value, rest) | value : rest <- streams] of
            [] -> []
            nonempty -> map fst nonempty ++ roundRobin (map snd nonempty)
    contextualSearchPlans = map fst contextualPlanEntries
    contextualPlanErasure plan = lookup plan contextualPlanEntries
    queryClosedCandidates =
        SharedCollection.distinctOn SharedTypeAtom.alphaTypeKey $
            closedMonotypeSubtrees elaboratedGoal
    closedCandidates =
        SharedCollection.distinctOn SharedTypeAtom.alphaTypeKey $
            queryClosedCandidates ++
                environmentClosedCandidates
    checkedTranslator owned translator source = do
        checkPreparedSynthesisTypesKindsWithRigids prepared owned [(KStar, source)]
        translator source
    visibleArgument source = case
            checkPreparedSynthesisTypesKinds prepared [(KStar, source)] of
        Left _ -> Nothing
        Right () -> Just
            $ fromRight SharedGenerated.inferredVisibleTypeArgument
            $ SharedGenerated.specifiedVisibleTypeArgument source
    visibleArgumentInScope owned source = case
            checkPreparedSynthesisTypesKindsWithRigids prepared owned [(KStar, source)] of
        Left _ -> Nothing
        Right () -> Just
            $ fromRight SharedGenerated.inferredVisibleTypeArgument
            $ SharedGenerated.partiallySpecifiedVisibleTypeArgument source
    structuralOwnedRigids = Set.fromList $
        goalVariables ++ polarizedFormulaPlanSkolems formulaPlans ++ premiseSpellings
    nominalOwnedRigids = Set.fromList $
        goalVariables ++ polarizedFormulaPlanSkolems nominalFormulaPlans ++ nominalPremiseSpellings
    structuralTranslator = checkedTranslator structuralOwnedRigids $
        preparedEnvironmentSynthesisFormulaTranslator prepared
    nominalTranslator = checkedTranslator nominalOwnedRigids $
        preparedEnvironmentNominalSynthesisFormulaTranslator prepared
    collectAcrossPlans =
        optionAlternatives options || optionSorted options
    primary = primaryFormulaPlan formulaPlans
    primaryTranslationSound = not $
        translationIncomplete primary || premiseTranslationIncomplete
    -- Qualified source types may be inhabited through class methods which
    -- are intentionally absent from LJT. This includes qualifications below
    -- ordinary arrows, and historical requests carrying contexts separately.
    -- An exhaustive search of the dictionary-independent body cannot refute
    -- that complete source type. Positive proofs and their budgets are unchanged.
    primarySound = sourceNegativeEvidenceSound && primaryTranslationSound &&
        null activeLoadedSchemePremises
    alternativeForms
        | primaryTranslationSound = []
        | otherwise =
            exactOpaqueFormulaPlan formulaPlans :
            map translatedFormula
                (singleOpaqueFormulaPlans formulaPlans) ++
            map translatedFormula
                (singleOpenFormulaPlans formulaPlans) ++
            map translatedFormula
                (pairOpaqueFormulaPlans formulaPlans) ++
            map translatedFormula
                (pairOpenFormulaPlans formulaPlans) ++
            map translatedFormula
                (tripleOpaqueFormulaPlans formulaPlans) ++
            map translatedFormula
                (tripleOpenFormulaPlans formulaPlans) ++
            map translatedFormula
                (quadrupleOpaqueFormulaPlans formulaPlans) ++
            map translatedFormula
                (quadrupleOpenFormulaPlans formulaPlans) ++
            map translatedFormula
                (quintupleOpaqueFormulaPlans formulaPlans) ++
            map translatedFormula
                (quintupleOpenFormulaPlans formulaPlans)
    rawPlans =
        (translatedFormula primary, primarySound) :
        [ (formula, False)
        | formula <- alternativeForms
        ]
    plans = SharedCollection.distinctOn fst rawPlans
    nominalPlans = SharedCollection.distinctOn fst
        [ (formula, False)
        | formula <- formulaFamilyForms nominalFormulaPlans
        ]
    nominalProjectionDistinct =
        map fst nominalPlans /= map fst plans ||
            nominalPremises /= premises
    useNominalProjection =
        parametricDataRelevant &&
            not primaryTranslationSound && nominalProjectionDistinct
    -- The candidate spellings are source-level facts: the goal's free
    -- variables, every opened-forall skolem of the goal plans, and the
    -- sealed premise scopes. No rendered atom text is parsed back.
    activeAxioms = instantiationAxioms
        (preparedEnvironmentSynthesisFormulaTranslator prepared)
        visibleArgument
        (goalVariables ++
            polarizedFormulaPlanSkolems formulaPlans ++
            premiseSpellings)
        (map fst plans)
        (map snd activePremises)
    activeAxiomSymbols = instantiationAxiomSymbols activeAxioms
    activeAxiomPremises = instantiationAxiomPremises activeAxioms
    activeVisibleApplications =
        instantiationVisibleApplications activeAxioms
    targetAxioms = instantiationAxioms
        (preparedEnvironmentSynthesisFormulaTranslator prepared)
        visibleArgument
        (goalVariables ++
            polarizedFormulaPlanSkolems formulaPlans ++
            premiseSpellings)
        (map fst plans)
        (map snd targetPremises)
    targetAxiomPremises = instantiationAxiomPremises targetAxioms
    activeNominalAxioms = instantiationAxioms
        (preparedEnvironmentNominalSynthesisFormulaTranslator prepared)
        visibleArgument
        (goalVariables ++
            polarizedFormulaPlanSkolems nominalFormulaPlans ++
            nominalPremiseSpellings)
        (map fst nominalPlans)
        (map snd activeNominalPremises)
    activeNominalAxiomSymbols =
        instantiationAxiomSymbols activeNominalAxioms
    activeNominalAxiomPremises =
        instantiationAxiomPremises activeNominalAxioms
    activeNominalVisibleApplications =
        instantiationVisibleApplications activeNominalAxioms
    targetNominalAxioms = instantiationAxioms
        (preparedEnvironmentNominalSynthesisFormulaTranslator prepared)
        visibleArgument
        (goalVariables ++
            polarizedFormulaPlanSkolems nominalFormulaPlans ++
            nominalPremiseSpellings)
        (map fst nominalPlans)
        (map snd targetNominalPremises)
    targetNominalAxiomPremises =
        instantiationAxiomPremises targetNominalAxioms
    queryCorrelatedAxioms = queryCorrelatedInstantiationAxioms
        structuralTranslator
        visibleArgument
        activeAxioms
        (goalVariables ++
            polarizedFormulaPlanSkolems formulaPlans ++
            premiseSpellings)
        elaboratedGoal
        (map fst plans)
        (map snd premises)
    queryCorrelatedAxiomSymbols =
        instantiationAxiomSymbols queryCorrelatedAxioms
    queryCorrelatedAxiomPremises =
        instantiationAxiomPremises queryCorrelatedAxioms
    queryCorrelatedVisibleApplications =
        instantiationVisibleApplications queryCorrelatedAxioms
    nominalQueryCorrelatedAxioms =
        queryCorrelatedInstantiationAxioms
            nominalTranslator
            visibleArgument
            activeNominalAxioms
            (goalVariables ++
                polarizedFormulaPlanSkolems nominalFormulaPlans ++
                nominalPremiseSpellings)
            elaboratedGoal
            (map fst nominalPlans)
            (map snd nominalPremises)
    nominalQueryCorrelatedAxiomSymbols =
        instantiationAxiomSymbols nominalQueryCorrelatedAxioms
    nominalQueryCorrelatedAxiomPremises =
        instantiationAxiomPremises nominalQueryCorrelatedAxioms
    nominalQueryCorrelatedVisibleApplications =
        instantiationVisibleApplications nominalQueryCorrelatedAxioms
    queryDirectedAxioms = queryDirectedInstantiationAxioms
        structuralTranslator visibleArgument activeAxioms
        (goalVariables ++ polarizedFormulaPlanSkolems formulaPlans ++ premiseSpellings)
        elaboratedGoal (map fst plans)
        (map snd $ premises ++ activeLoadedSchemePremises)
    queryCarrierAxioms = queryCarrierInstantiationAxioms
        structuralTranslator visibleArgument
        (goalVariables ++ polarizedFormulaPlanSkolems formulaPlans ++ premiseSpellings)
        (map fst plans) (map snd $ premises ++ activeLoadedSchemePremises)
    nominalQueryDirectedAxioms = queryDirectedInstantiationAxioms
        nominalTranslator visibleArgument activeNominalAxioms
        (goalVariables ++ polarizedFormulaPlanSkolems nominalFormulaPlans ++ nominalPremiseSpellings)
        elaboratedGoal (map fst nominalPlans)
        (map snd $ nominalPremises ++ activeNominalLoadedSchemePremises)
    queryConstructedAxioms = queryConstructedInstantiationAxioms
        (preparedEnvironmentConstructedHypothesisTranslator prepared)
        visibleArgumentInScope
        (goalVariables ++ polarizedFormulaPlanSkolems formulaPlans ++ premiseSpellings)
        elaboratedGoal (map fst plans)
        (map snd $ premises ++ activeLoadedSchemePremises)
    nominalQueryConstructedAxioms = queryConstructedInstantiationAxioms
        (preparedEnvironmentNominalConstructedHypothesisTranslator prepared)
        visibleArgumentInScope
        (goalVariables ++ polarizedFormulaPlanSkolems nominalFormulaPlans ++ nominalPremiseSpellings)
        elaboratedGoal (map fst nominalPlans)
        (map snd $ nominalPremises ++ activeNominalLoadedSchemePremises)
    queryClosedAxioms = queryClosedInstantiationAxioms
        structuralTranslator
        visibleArgument
        (goalVariables ++
            polarizedFormulaPlanSkolems formulaPlans ++
            premiseSpellings)
        queryClosedCandidates
        (map fst plans)
        (map snd premises)
    queryClosedAxiomSymbols =
        instantiationAxiomSymbols queryClosedAxioms
    queryClosedAxiomPremises =
        instantiationAxiomPremises queryClosedAxioms
    queryClosedVisibleApplications =
        instantiationVisibleApplications queryClosedAxioms
    nominalQueryClosedAxioms = queryClosedInstantiationAxioms
        nominalTranslator
        visibleArgument
        (goalVariables ++
            polarizedFormulaPlanSkolems nominalFormulaPlans ++
            nominalPremiseSpellings)
        queryClosedCandidates
        (map fst nominalPlans)
        (map snd nominalPremises)
    nominalQueryClosedAxiomSymbols =
        instantiationAxiomSymbols nominalQueryClosedAxioms
    nominalQueryClosedAxiomPremises =
        instantiationAxiomPremises nominalQueryClosedAxioms
    nominalQueryClosedVisibleApplications =
        instantiationVisibleApplications nominalQueryClosedAxioms
    activeLoadedAxioms = loadedInstantiationAxioms
        structuralTranslator
        visibleArgument
        (goalVariables ++
            polarizedFormulaPlanSkolems formulaPlans ++
            premiseSpellings)
        closedCandidates
        (map fst plans)
        (map snd premises)
        (map snd activeLoadedSchemePremises)
    activeLoadedAxiomSymbols =
        instantiationAxiomSymbols activeLoadedAxioms
    activeLoadedAxiomPremises =
        instantiationAxiomPremises activeLoadedAxioms
    activeLoadedVisibleApplications =
        instantiationVisibleApplications activeLoadedAxioms
    targetLoadedAxioms = loadedInstantiationAxioms
        structuralTranslator
        visibleArgument
        (goalVariables ++
            polarizedFormulaPlanSkolems formulaPlans ++
            premiseSpellings)
        closedCandidates
        (map fst plans)
        (map snd premises)
        (map snd targetLoadedSchemePremises)
    targetLoadedAxiomPremises =
        instantiationAxiomPremises targetLoadedAxioms
    activeNominalLoadedAxioms = loadedInstantiationAxioms
        nominalTranslator
        visibleArgument
        (goalVariables ++
            polarizedFormulaPlanSkolems nominalFormulaPlans ++
            nominalPremiseSpellings)
        closedCandidates
        (map fst nominalPlans)
        (map snd nominalPremises)
        (map snd activeNominalLoadedSchemePremises)
    activeNominalLoadedAxiomSymbols =
        instantiationAxiomSymbols activeNominalLoadedAxioms
    activeNominalLoadedAxiomPremises =
        instantiationAxiomPremises activeNominalLoadedAxioms
    activeNominalLoadedVisibleApplications =
        instantiationVisibleApplications activeNominalLoadedAxioms
    targetNominalLoadedAxioms = loadedInstantiationAxioms
        nominalTranslator
        visibleArgument
        (goalVariables ++
            polarizedFormulaPlanSkolems nominalFormulaPlans ++
            nominalPremiseSpellings)
        closedCandidates
        (map fst nominalPlans)
        (map snd nominalPremises)
        (map snd targetNominalLoadedSchemePremises)
    targetNominalLoadedAxiomPremises =
        instantiationAxiomPremises targetNominalLoadedAxioms
    activeProviderInstantiations = providerInstantiationPremises
        "$djinn$provider-instantiation$active$"
        structuralTranslator
        (Just $
            preparedEnvironmentStructuralAssignmentFidelity prepared)
        activeLoadedSchemePremises
        providerCandidates
    activeProviderPremises = providerInstantiationPremiseBindings
        activeProviderInstantiations
    activeProviderApplications = providerInstantiationApplications
        activeProviderInstantiations
    activeProviderAssignmentInstantiations =
        providerInstantiationAssignmentPremises
            "$djinn$provider-assignment$active$"
            structuralTranslator
            (Just $
                preparedEnvironmentStructuralAssignmentFidelity prepared)
            activeLoadedSchemePremises
            providerAssignments
    activeProviderAssignmentPremises =
        providerInstantiationPremiseBindings
            activeProviderAssignmentInstantiations
    activeProviderAssignmentApplications =
        providerInstantiationApplications
            activeProviderAssignmentInstantiations
    activeAllProviderPremises =
        activeProviderPremises ++ activeProviderAssignmentPremises
    activeAllProviderApplications =
        activeProviderApplications `Map.union`
            activeProviderAssignmentApplications
    activeAllProviderSymbols = Map.keysSet activeAllProviderApplications
    activeAllProviderVisibleApplications =
        Map.map snd activeAllProviderApplications
    activeProviderAssignmentSymbols =
        Map.keysSet activeProviderAssignmentApplications
    activeProviderAssignmentVisibleApplications =
        Map.map snd activeProviderAssignmentApplications
    activeProviderAssignmentNames = Set.fromList $
        map fst $ Map.elems activeProviderAssignmentApplications
    targetProviderInstantiations = providerInstantiationPremises
        "$djinn$provider-instantiation$target$"
        structuralTranslator
        (Just $
            preparedEnvironmentStructuralAssignmentFidelity prepared)
        targetLoadedSchemePremises
        providerCandidates
    targetProviderPremises = providerInstantiationPremiseBindings
        targetProviderInstantiations
    targetProviderAssignmentInstantiations =
        providerInstantiationAssignmentPremises
            "$djinn$provider-assignment$target$"
            structuralTranslator
            (Just $
                preparedEnvironmentStructuralAssignmentFidelity prepared)
            targetLoadedSchemePremises
            providerAssignments
    targetProviderAssignmentPremises =
        providerInstantiationPremiseBindings
            targetProviderAssignmentInstantiations
    targetAllProviderPremises =
        targetProviderPremises ++ targetProviderAssignmentPremises
    activeNominalProviderInstantiations = providerInstantiationPremises
        "$djinn$nominal-provider-instantiation$active$"
        nominalTranslator
        Nothing
        activeNominalLoadedSchemePremises
        providerCandidates
    activeNominalProviderPremises = providerInstantiationPremiseBindings
        activeNominalProviderInstantiations
    activeNominalProviderApplications = providerInstantiationApplications
        activeNominalProviderInstantiations
    activeNominalProviderAssignmentInstantiations =
        providerInstantiationAssignmentPremises
            "$djinn$nominal-provider-assignment$active$"
            nominalTranslator
            Nothing
            activeNominalLoadedSchemePremises
            providerAssignments
    activeNominalProviderAssignmentPremises =
        providerInstantiationPremiseBindings
            activeNominalProviderAssignmentInstantiations
    activeNominalProviderAssignmentApplications =
        providerInstantiationApplications
            activeNominalProviderAssignmentInstantiations
    activeAllNominalProviderPremises =
        activeNominalProviderPremises ++
            activeNominalProviderAssignmentPremises
    activeAllNominalProviderApplications =
        activeNominalProviderApplications `Map.union`
            activeNominalProviderAssignmentApplications
    activeAllNominalProviderSymbols =
        Map.keysSet activeAllNominalProviderApplications
    activeAllNominalProviderVisibleApplications =
        Map.map snd activeAllNominalProviderApplications
    activeNominalProviderAssignmentSymbols =
        Map.keysSet activeNominalProviderAssignmentApplications
    activeNominalProviderAssignmentVisibleApplications =
        Map.map snd activeNominalProviderAssignmentApplications
    activeNominalProviderAssignmentNames = Set.fromList $
        map fst $ Map.elems activeNominalProviderAssignmentApplications
    targetNominalProviderInstantiations = providerInstantiationPremises
        "$djinn$nominal-provider-instantiation$target$"
        nominalTranslator
        Nothing
        targetNominalLoadedSchemePremises
        providerCandidates
    targetNominalProviderPremises = providerInstantiationPremiseBindings
        targetNominalProviderInstantiations
    targetNominalProviderAssignmentInstantiations =
        providerInstantiationAssignmentPremises
            "$djinn$nominal-provider-assignment$target$"
            nominalTranslator
            Nothing
            targetNominalLoadedSchemePremises
            providerAssignments
    targetNominalProviderAssignmentPremises =
        providerInstantiationPremiseBindings
            targetNominalProviderAssignmentInstantiations
    targetAllNominalProviderPremises =
        targetNominalProviderPremises ++
            targetNominalProviderAssignmentPremises
    useNominalLoadedProjection =
        parametricDataRelevant &&
            ( useNominalProjection ||
                activeNominalLoadedSchemePremises /=
                    activeLoadedSchemePremises ||
                activeNominalLoadedAxiomPremises /=
                    activeLoadedAxiomPremises
            )
    useNominalProviderProjection =
        parametricDataRelevant &&
            ( nominalProjectionDistinct ||
                activeAllNominalProviderPremises /=
                    activeAllProviderPremises ||
                targetAllNominalProviderPremises /=
                    targetAllProviderPremises
            )
    useNominalQueryCorrelatedProjection =
        parametricDataRelevant &&
            ( nominalProjectionDistinct ||
                nominalQueryCorrelatedAxiomPremises /=
                    queryCorrelatedAxiomPremises
            )
    useNominalQueryClosedProjection =
        parametricDataRelevant &&
            ( nominalProjectionDistinct ||
                nominalQueryClosedAxiomPremises /=
                    queryClosedAxiomPremises
            )
    useNominalQueryCorrelatedClosedProjection =
        parametricDataRelevant &&
            ( nominalProjectionDistinct ||
                nominalQueryCorrelatedAxiomPremises /=
                    queryCorrelatedAxiomPremises ||
                nominalQueryClosedAxiomPremises /=
                    queryClosedAxiomPremises
            )
    -- Preserve the complete historical structural/no-axiom prefix. This
    -- keeps first-result behavior, frontier ordering, and finite-budget
    -- observations stable; the nominal family shares only the cutoff and
    -- fuel left by that prefix and still precedes the structural axiom
    -- phase which previously formed the appended transport tail.
    structuralSearchPlans =
        [ ( premises, [], Set.empty, Map.empty, Map.empty
          , form, sound
          )
        | (form, sound) <- plans
        ]
    structuralAxiomSearchPlans =
        [ ( premises ++ activeAxiomPremises
          , targetAxiomPremises
          , activeAxiomSymbols
          , activeVisibleApplications
          , Map.empty
          , form
          , sound && null activeAxiomPremises
          )
        | not (null activeAxiomPremises) ||
            not (null targetAxiomPremises)
        , (form, sound) <- plans
        ]
    loadedStructuralSearchPlans =
        [ ( premises ++ loadedSchemePremises ++ activeAxiomPremises ++
                activeLoadedAxiomPremises
          , targetAxiomPremises ++ targetLoadedAxiomPremises
          , activeAxiomSymbols `Set.union` activeLoadedAxiomSymbols
          , activeVisibleApplications `Map.union`
                activeLoadedVisibleApplications
          , Map.empty
          , form
          , sound && null activeAxiomPremises &&
                null activeLoadedSchemePremises
          )
        | not (null loadedSchemePremises)
        , (form, sound) <- plans
        ]
    -- The nominal-data family is a complementary proof-producing
    -- approximation, never a refutation. Its premise views and erased
    -- instantiation axioms are compiled independently with the matching
    -- nominal translator, so structural candidate caps and ordering are
    -- unchanged. Pair each plain nominal form with its guarded transport
    -- form before moving to the next frontier; policy remains part of the
    -- search plan even when a formula happens to equal a structural view.
    nominalSearchPlans
        | not useNominalProjection = []
        | otherwise = concatMap nominalFormSearchPlans nominalPlans
    nominalFormSearchPlans (form, _) =
        ( nominalPremises, [], Set.empty, Map.empty, Map.empty
        , form, False
        ) :
        [ ( nominalPremises ++ activeNominalAxiomPremises
          , targetNominalAxiomPremises
          , activeNominalAxiomSymbols
          , activeNominalVisibleApplications
          , Map.empty
          , form
          , False
          )
        | not (null activeNominalAxiomPremises) ||
            not (null targetNominalAxiomPremises)
        ]
    loadedNominalSearchPlans
        | not useNominalLoadedProjection = []
        | otherwise =
            [ ( nominalPremises ++ nominalLoadedSchemePremises ++
                    activeNominalAxiomPremises ++
                    activeNominalLoadedAxiomPremises
              , targetNominalAxiomPremises ++
                    targetNominalLoadedAxiomPremises
              , activeNominalAxiomSymbols `Set.union`
                    activeNominalLoadedAxiomSymbols
              , activeNominalVisibleApplications `Map.union`
                    activeNominalLoadedVisibleApplications
              , Map.empty
              , form
              , False
              )
            | not (null nominalLoadedSchemePremises)
            , (form, _) <- nominalPlans
            ]
    -- Fairly correlated guarded-impredicative tuples form a separate
    -- positive-only tail.  Its axioms are exact instances whose complete
    -- result already occurs in the checked query.  The plan is appended
    -- after the formerly final query-closed family, preserving every
    -- established plan and candidate prefix while allowing the new local
    -- instance to compose with historical, provider, and loaded premises.
    queryCorrelatedStructuralSearchPlans =
        [ ( premises ++ loadedSchemePremises ++ activeAxiomPremises ++
                activeLoadedAxiomPremises ++ activeAllProviderPremises ++
                queryCorrelatedAxiomPremises
          , targetAxiomPremises ++ targetLoadedAxiomPremises ++
                targetAllProviderPremises
          , activeAxiomSymbols `Set.union` activeLoadedAxiomSymbols
                `Set.union` activeAllProviderSymbols
                `Set.union` queryCorrelatedAxiomSymbols
          , activeVisibleApplications `Map.union`
                activeLoadedVisibleApplications `Map.union`
                activeAllProviderVisibleApplications `Map.union`
                queryCorrelatedVisibleApplications
          , activeAllProviderApplications
          , form
          , False
          )
        | not (null queryCorrelatedAxiomPremises)
        , (form, _) <- plans
        ]
    queryCorrelatedNominalSearchPlans
        | not useNominalQueryCorrelatedProjection = []
        | otherwise =
            [ ( nominalPremises ++ nominalLoadedSchemePremises ++
                    activeNominalAxiomPremises ++
                    activeNominalLoadedAxiomPremises ++
                    activeAllNominalProviderPremises ++
                    nominalQueryCorrelatedAxiomPremises
              , targetNominalAxiomPremises ++
                    targetNominalLoadedAxiomPremises ++
                    targetAllNominalProviderPremises
              , activeNominalAxiomSymbols `Set.union`
                    activeNominalLoadedAxiomSymbols `Set.union`
                    activeAllNominalProviderSymbols `Set.union`
                    nominalQueryCorrelatedAxiomSymbols
              , activeNominalVisibleApplications `Map.union`
                    activeNominalLoadedVisibleApplications `Map.union`
                    activeAllNominalProviderVisibleApplications `Map.union`
                    nominalQueryCorrelatedVisibleApplications
              , activeAllNominalProviderApplications
              , form
              , False
              )
            | not (null nominalQueryCorrelatedAxiomPremises)
            , (form, _) <- nominalPlans
            ]
    -- Closed monotypes which occur in the checked query extend local
    -- hypothesis instantiation in the historically final family. Keeping
    -- this established positive-only superset unchanged after the loaded
    -- and provider families preserves every earlier plan and candidate
    -- prefix while still allowing one
    -- proof to mix an old variable/quantified axiom with a newly admitted
    -- closed instance. This established plan is also a superset of loaded
    -- and caller-supplied provider evidence, so the new local
    -- specialization can compose with either capability without moving or
    -- modifying their earlier priority plans.
    queryClosedStructuralSearchPlans =
        [ ( premises ++ loadedSchemePremises ++ activeAxiomPremises ++
                activeLoadedAxiomPremises ++ activeAllProviderPremises ++
                queryClosedAxiomPremises
          , targetAxiomPremises ++ targetLoadedAxiomPremises ++
                targetAllProviderPremises
          , activeAxiomSymbols `Set.union` activeLoadedAxiomSymbols
                `Set.union` activeAllProviderSymbols
                `Set.union` queryClosedAxiomSymbols
          , activeVisibleApplications `Map.union`
                activeLoadedVisibleApplications `Map.union`
                activeAllProviderVisibleApplications `Map.union`
                queryClosedVisibleApplications
          , activeAllProviderApplications
          , form
          , False
          )
        | not (null queryClosedAxiomPremises)
        , (form, _) <- plans
        ]
    queryClosedNominalSearchPlans
        | not useNominalQueryClosedProjection = []
        | otherwise =
            [ ( nominalPremises ++ nominalLoadedSchemePremises ++
                    activeNominalAxiomPremises ++
                    activeNominalLoadedAxiomPremises ++
                    activeAllNominalProviderPremises ++
                    nominalQueryClosedAxiomPremises
              , targetNominalAxiomPremises ++
                    targetNominalLoadedAxiomPremises ++
                    targetAllNominalProviderPremises
              , activeNominalAxiomSymbols `Set.union`
                    activeNominalLoadedAxiomSymbols `Set.union`
                    activeAllNominalProviderSymbols `Set.union`
                    nominalQueryClosedAxiomSymbols
              , activeNominalVisibleApplications `Map.union`
                    activeNominalLoadedVisibleApplications `Map.union`
                    activeAllNominalProviderVisibleApplications `Map.union`
                    nominalQueryClosedVisibleApplications
              , activeAllNominalProviderApplications
              , form
              , False
              )
            | not (null nominalQueryClosedAxiomPremises)
            , (form, _) <- nominalPlans
            ]
    -- A final additive superset permits one proof to compose the new
    -- correlated instance with the established query-closed family.  It
    -- is present only when both families contribute premises, so neither
    -- single-family tail is duplicated, and it follows both independent
    -- plans so their prefixes remain stable.
    queryCorrelatedClosedStructuralSearchPlans =
        [ ( premises ++ loadedSchemePremises ++ activeAxiomPremises ++
                activeLoadedAxiomPremises ++ activeAllProviderPremises ++
                queryCorrelatedAxiomPremises ++
                queryClosedAxiomPremises
          , targetAxiomPremises ++ targetLoadedAxiomPremises ++
                targetAllProviderPremises
          , activeAxiomSymbols `Set.union` activeLoadedAxiomSymbols
                `Set.union` activeAllProviderSymbols
                `Set.union` queryCorrelatedAxiomSymbols
                `Set.union` queryClosedAxiomSymbols
          , activeVisibleApplications `Map.union`
                activeLoadedVisibleApplications `Map.union`
                activeAllProviderVisibleApplications `Map.union`
                queryCorrelatedVisibleApplications `Map.union`
                queryClosedVisibleApplications
          , activeAllProviderApplications
          , form
          , False
          )
        | not (null queryCorrelatedAxiomPremises)
        , not (null queryClosedAxiomPremises)
        , (form, _) <- plans
        ]
    queryCorrelatedClosedNominalSearchPlans
        | not useNominalQueryCorrelatedClosedProjection = []
        | otherwise =
            [ ( nominalPremises ++ nominalLoadedSchemePremises ++
                    activeNominalAxiomPremises ++
                    activeNominalLoadedAxiomPremises ++
                    activeAllNominalProviderPremises ++
                    nominalQueryCorrelatedAxiomPremises ++
                    nominalQueryClosedAxiomPremises
              , targetNominalAxiomPremises ++
                    targetNominalLoadedAxiomPremises ++
                    targetAllNominalProviderPremises
              , activeNominalAxiomSymbols `Set.union`
                    activeNominalLoadedAxiomSymbols `Set.union`
                    activeAllNominalProviderSymbols `Set.union`
                    nominalQueryCorrelatedAxiomSymbols `Set.union`
                    nominalQueryClosedAxiomSymbols
              , activeNominalVisibleApplications `Map.union`
                    activeNominalLoadedVisibleApplications `Map.union`
                    activeAllNominalProviderVisibleApplications `Map.union`
                    nominalQueryCorrelatedVisibleApplications `Map.union`
                    nominalQueryClosedVisibleApplications
              , activeAllNominalProviderApplications
              , form
              , False
              )
            | not (null nominalQueryCorrelatedAxiomPremises)
            , not (null nominalQueryClosedAxiomPremises)
            , (form, _) <- nominalPlans
            ]
    -- Exact ordered assignments receive one positive-only priority plan.
    -- Replace the ordinary views of each assigned provider in this plan,
    -- then put its exact premise at the tail. LJT introduces folded
    -- environment arrows from left to right: a nominal empty premise
    -- encountered before later arrows is eliminated, while the tail
    -- premise reaches the final matching goal by direct identity and
    -- therefore preserves its visible type application. The unfiltered
    -- provider superset below remains available for proofs which compose
    -- an exact assignment with an ordinary use of that same provider.
    providerAssignmentPriorityStructuralSearchPlans =
        [ ( withoutProviders activeProviderAssignmentNames premises ++
                withoutProviders activeProviderAssignmentNames
                    loadedSchemePremises ++
                activeAxiomPremises ++ activeLoadedAxiomPremises ++
                activeProviderAssignmentPremises
          , []
          , activeAxiomSymbols `Set.union` activeLoadedAxiomSymbols
                `Set.union` activeProviderAssignmentSymbols
          , activeVisibleApplications `Map.union`
                activeLoadedVisibleApplications `Map.union`
                activeProviderAssignmentVisibleApplications
          , activeProviderAssignmentApplications
          , form
          , False
          )
        | not (null activeProviderAssignmentPremises)
        , (form, _) <- plans
        ]
    providerAssignmentPriorityNominalSearchPlans
        | not useNominalProviderProjection = []
        | otherwise =
            [ ( withoutProviders activeNominalProviderAssignmentNames
                    nominalPremises ++
                    withoutProviders activeNominalProviderAssignmentNames
                        nominalLoadedSchemePremises ++
                    activeNominalAxiomPremises ++
                    activeNominalLoadedAxiomPremises ++
                    activeNominalProviderAssignmentPremises
              , []
              , activeNominalAxiomSymbols `Set.union`
                    activeNominalLoadedAxiomSymbols `Set.union`
                    activeNominalProviderAssignmentSymbols
              , activeNominalVisibleApplications `Map.union`
                    activeNominalLoadedVisibleApplications `Map.union`
                    activeNominalProviderAssignmentVisibleApplications
              , activeNominalProviderAssignmentApplications
              , form
              , False
              )
            | not (null activeNominalProviderAssignmentPremises)
            , (form, _) <- nominalPlans
            ]
    -- The historical combined scalar-candidate and exact-assignment plan
    -- remains an unfiltered additive superset at its established position.
    -- This preserves legacy candidate ordering and allows one proof to use
    -- the same provider through both exact and ordinary instantiation.
    providerStructuralSearchPlans =
        [ ( premises ++ loadedSchemePremises ++
                activeAxiomPremises ++ activeLoadedAxiomPremises ++
                activeAllProviderPremises
          , targetAxiomPremises ++ targetLoadedAxiomPremises ++
                targetAllProviderPremises
          , activeAxiomSymbols `Set.union` activeLoadedAxiomSymbols
                `Set.union` activeAllProviderSymbols
          , activeVisibleApplications `Map.union`
                activeLoadedVisibleApplications `Map.union`
                activeAllProviderVisibleApplications
          , activeAllProviderApplications
          , form
          , False
          )
        | not (null activeAllProviderPremises) ||
            not (null targetAllProviderPremises)
        , (form, _) <- plans
        ]
    providerNominalSearchPlans
        | not useNominalProviderProjection = []
        | otherwise =
            [ ( nominalPremises ++ nominalLoadedSchemePremises ++
                    activeNominalAxiomPremises ++
                    activeNominalLoadedAxiomPremises ++
                    activeAllNominalProviderPremises
              , targetNominalAxiomPremises ++
                    targetNominalLoadedAxiomPremises ++
                    targetAllNominalProviderPremises
              , activeNominalAxiomSymbols `Set.union`
                    activeNominalLoadedAxiomSymbols `Set.union`
                    activeAllNominalProviderSymbols
              , activeNominalVisibleApplications `Map.union`
                    activeNominalLoadedVisibleApplications `Map.union`
                    activeAllNominalProviderVisibleApplications
              , activeAllNominalProviderApplications
              , form
              , False
              )
            | not (null activeAllNominalProviderPremises) ||
                not (null targetAllNominalProviderPremises)
            , (form, _) <- nominalPlans
            ]
    -- Try each independently justified specialization on the primary goal
    -- before putting every specialization into the same LJT context. The
    -- combined context can contain many mutually recursive implications and
    -- exhaust a budget even for a one-step Church eliminator. These small
    -- plans share the ordinary global budget and cannot establish a negative
    -- result. Combined families remain available for multi-instance terms.
    focusedInstantiationSearchPlans = focusedPlansOf
        [ (activeAxiomPremises, activeVisibleApplications)
        , (queryClosedAxiomPremises, queryClosedVisibleApplications)
        , (queryCorrelatedAxiomPremises, queryCorrelatedVisibleApplications)
        ]
    focusedPlansOf = focusedPlansWithPrefix "$djinn$focused$"
    focusedPlansWithPrefix symbolPrefix families =
        [ ( premises ++ loadedSchemePremises ++ [(focusedSymbol, formula)]
          , []
          , Set.singleton focusedSymbol
          , maybe Map.empty (Map.singleton focusedSymbol) $ Map.lookup symbol applications
          , Map.empty
          , translatedFormula primary
          , False
          )
        | (index, ((symbol, formula), applications)) <- zip [0 :: Int ..]
            [ (premise, applications)
            | (axioms, applications) <- families
            , premise <- axioms
            ]
        , let focusedSymbol = Symbol $ symbolPrefix ++ show index
        ]
    -- Explicit interleaving explores residual carriers alongside the old
    -- plan stream, retaining both continuations. Depth-first, first-only and
    -- sorted-only requests keep their established family policy and prefixes.
    -- Neither lane can refill the shared raw-proof or choice allowance.
    carrierAlternativeSearchPlans
        | not interleavePlanAlternatives = []
        | otherwise = contextualSearchPlans ++ commonResultInstantiationSearchPlans ++
            functionCarrierSearchPlans
    functionCarrierSearchPlans = focusedPlansWithPrefix "$djinn$carrier-focused$"
        [(instantiationAxiomPremises queryCarrierAxioms,
            instantiationVisibleApplications queryCarrierAxioms)]
    -- Streaming has no complete candidate pool to rank. Give exact instances
    -- whose final result is demanded by the primary goal an early live turn.
    -- A repeated alpha-equivalent quantified input needs only one bridge,
    -- reusable on both values; ordinary focused plans would suppress that
    -- singleton after an earlier projection or constant already succeeded.
    -- The carrier-focused policy instead checks that the bridge is actually
    -- used and retains its cursor alongside every historical continuation.
    --
    -- This is a positive-only scheduling heuristic over the existing bounded
    -- axiom inventory, not additional instantiation evidence or a completeness
    -- claim. Common groups retain their original symbol indices and member
    -- order. Batch, depth-first, and first-only schedules remain unchanged.
    demandedStreamingPlans = contextualSearchPlans ++ demandedCommonResultPlans ++ demandedSingletonPlans
    otherStreamingCarrierPlans = otherCommonResultPlans ++ functionCarrierSearchPlans
    demandedResult = instantiationResult $ translatedFormula primary
    demandedSingletonPlans = focusedPlansWithPrefix "$djinn$carrier-focused$demand$"
        [( [ premise
           | premise@(_, PVar _ :-> body) <- activeAxiomPremises
           , instantiationResult body == demandedResult
           ]
         , activeVisibleApplications
         )]
    demandedCommonResultPlans =
        [plan | (True, plan) <- classifiedCommonResultPlans]
    otherCommonResultPlans =
        [plan | (False, plan) <- classifiedCommonResultPlans]
    -- Several source schemes may cooperate at one exact result type. Keep
    -- those already-checked bridges together before the singleton carrier
    -- contexts, without importing every unrelated instantiation image. This
    -- is result-type grouping, not a claim that complete source assignment
    -- vectors coincide. Each member retains its own formula and any visible
    -- arguments; the historical all-axiom context remains available.
    -- The existing bounded historical axiom inventory bounds these groups.
    -- Their order follows first result occurrence, and heads within a group
    -- retain source encounter order. No tuple or additional axiom is created.
    commonResultInstantiationSearchPlans = map snd classifiedCommonResultPlans
    classifiedCommonResultPlans =
        [ (result == demandedResult,
          ( premises ++ loadedSchemePremises ++
                [(focusedSymbol, formula) | (_, focusedSymbol, formula) <- renamed]
          , []
          , Set.fromList [focusedSymbol | (_, focusedSymbol, _) <- renamed]
          , Map.fromList
                [(focusedSymbol, arguments)
                | (originalSymbol, focusedSymbol, _) <- renamed
                , Just arguments <- [Map.lookup originalSymbol activeVisibleApplications]]
          , Map.empty
          , translatedFormula primary
          , False
          ))
        | (groupIndex, (result, group)) <- zip [0 :: Int ..] commonResultInstantiationGroups
        , let renamed =
                [ (originalSymbol, Symbol $ "$djinn$carrier-focused$common$" ++
                        show groupIndex ++ "$" ++ show memberIndex, formula)
                | (memberIndex, (originalSymbol, formula)) <- zip [0 :: Int ..] group
                ]
        ]
    commonResultInstantiationGroups =
        [ (result, group)
        | result <- SharedCollection.distinctOn id
            [instantiationResult body | (_, PVar _ :-> body) <- activeAxiomPremises]
        , let group =
                [(symbol, formula)
                | (symbol, formula@(PVar _ :-> body)) <- activeAxiomPremises
                , instantiationResult body == result]
        , length group >= 2
        ]
    instantiationResult (_ :-> result) = instantiationResult result
    instantiationResult result = result
    interleavePlanAlternatives =
        optionAlternatives options && optionStrategy options == Interleave
    -- Richer compound instantiations remain an inhabitation fallback for
    -- first-only requests. Explicit alternative enumeration may also explore
    -- them after an earlier syntactic inhabitant, under the same global fuel.
    augmentDirected axioms basePlans =
        [ ( ps ++ instantiationAxiomPremises axioms, diagnostics
          , symbols `Set.union` instantiationAxiomSymbols axioms
          , visible `Map.union` instantiationVisibleApplications axioms
          , providers, form, False
          )
        | not $ null $ instantiationAxiomPremises axioms
        , (ps, diagnostics, symbols, visible, providers, form, _) <- basePlans
        ]
    initialSearchPlans =
        -- Exact assignment priority is absent for both the scalar-only
        -- and empty-evidence entrances, so their historical plan order is
        -- unchanged byte for byte.
        providerAssignmentPriorityStructuralSearchPlans ++
        providerAssignmentPriorityNominalSearchPlans ++
        take 1 structuralSearchPlans ++ recursiveDataSearchPlans
    -- Exact recursive atoms may be inspected through their declared one-layer
    -- constructor shape. Continuation views erase as representation identities;
    -- introduction premises resolve to actual constructors in the checked
    -- source inventory. Ordinary source checking validates the resulting tree.
    -- Do not infer non-inhabitation from this finite recursive approximation.
    recursiveDataSearchPlans = concat
        [ dataPlans [] Map.empty False ++
            concat
                [ dataPlans bridges applications True
                | (bridges, applications) <- instanceFamilies
                ]
        | Right translation <-
            [preparedEnvironmentDataViewFormula prepared 0 PositiveFormula elaboratedGoal]
        , Right (dataPremises, dataSpellings) <- [preparedEnvironmentDataViewFunctionPremises prepared]
        , let goal = translatedFormula translation
              sourceSequent = goal : map snd dataPremises
              sourceNegativeTypes = atomsAtPolarity False True goal `Set.union`
                  Set.unions [atomsAtPolarity False False form | (_, form) <- dataPremises]
              results = residualResults goal
              ownedSpellings = SharedCollection.distinctOn id $
                  goalVariables ++ translationIntroducedSkolems translation ++ dataSpellings
              instanceTranslator = checkedTranslator (Set.fromList ownedSpellings) $
                  preparedEnvironmentDataViewInstanceTranslator prepared
              activeDataPremises = filter ((/= targetSymbol) . fst) dataPremises
              -- A retained full source scheme is one opaque atom regardless
              -- of its body's datatype view. Keep these original quantified
              -- identities rather than rebuilding schemes from implicitized
              -- premise variables or rendered atom spellings.
              availableSchemes = activeLoadedSchemePremises
              instancePremises = activeDataPremises ++ availableSchemes
              localInstances = instantiationAxioms instanceTranslator visibleArgument
                  ownedSpellings [goal] (map snd activeDataPremises)
              loadedInstances = loadedInstantiationAxioms instanceTranslator visibleArgument
                  ownedSpellings closedCandidates [goal] (map snd activeDataPremises)
                  (map snd availableSchemes)
              directedInstances = queryDirectedInstantiationAxioms instanceTranslator visibleArgument
                  localInstances ownedSpellings elaboratedGoal [goal] (map snd instancePremises)
              carrierInstances = queryCarrierInstantiationAxioms instanceTranslator visibleArgument
                  ownedSpellings [goal] (map snd instancePremises)
              instanceImages = SharedCollection.distinctOn
                  (\(_, form, arguments) -> (form, arguments))
                  [ (symbol, form, Map.lookup symbol $ instantiationVisibleApplications family)
                  | family <- [localInstances, loadedInstances, directedInstances, carrierInstances]
                  , (symbol, form) <- instantiationAxiomPremises family
                  ]
              -- Exact demanded result images get a small coherent context
              -- first. The complete bounded image family remains a fallback
              -- for compositions using intermediate accumulator types.
              -- A small exact image must not wait behind every other
              -- accumulator specialization. Prefer singleton compositions
              -- whose result is demanded and which consume one of the
              -- query's actual recursive inputs. Both tests compare checked
              -- formula identities, not provider names or datatype spelling.
              -- The old grouped contexts remain after this additive prefix.
              goalRecursiveInputs = Set.fromList
                  [ opaque
                  | (opaque, _) <- preparedEnvironmentRecursiveDataViews prepared [goal]
                  , opaque `Set.member` atomsAtPolarity False True goal
                  ]
              preferredImages =
                  [ [image]
                  | image@(_, _ :-> body, _) <- instanceImages
                  , instantiationResult body `elem` results
                  , any (`Set.member` goalRecursiveInputs) $ argumentTypes body
                  ]
              imageGroups = SharedCollection.distinctOn
                  (map (\(_, form, arguments) -> (form, arguments))) $
                  preferredImages ++ [ images
                  | result <- results
                  , let images = [image | image@(_, _ :-> body, _) <- instanceImages,
                                          instantiationResult body == result]
                  , not $ null images
                  ] ++ [instanceImages | not $ null instanceImages]
              instanceFamilies =
                  [ ( [(symbol, form) | (symbol, form, _) <- renamed]
                    , Map.fromList [(symbol, arguments) | (symbol, _, Just arguments) <- renamed]
                    )
                  | (familyIndex, images) <- zip [0 :: Natural ..] imageGroups
                  , let renamed =
                          [ (Symbol $ "$djinn$carrier-focused$data$" ++ show familyIndex ++ "$" ++ show index,
                              form, arguments)
                          | (index, (_, form, arguments)) <- zip [0 :: Natural ..] images
                          ]
                  ]
              dataPlans bridges applications instantiated =
                  [ (planPremises ++ constructorPremises ++ selectedViews, [],
                      Set.fromList $ map fst selectedViews ++ map fst constructorPremises ++ map fst bridges,
                      applications, constructorApplications, goal, False)
                  | let planPremises = dataPremises ++ bridges ++
                              [scheme | instantiated, scheme <- availableSchemes]
                        sequent = goal : map snd planPremises
                        views = preparedEnvironmentDataConstructorViews prepared sequent
                        negativeTypes = atomsAtPolarity False True goal `Set.union`
                            Set.unions [atomsAtPolarity False False form | (_, form) <- planPremises]
                        positiveTypes = atomsAtPolarity True True goal `Set.union`
                            Set.unions [atomsAtPolarity True False form | (_, form) <- planPremises]
                        viewPremises =
                            [ (Symbol $ "$djinn$recursive-view$unfold$" ++ show index ++ "$" ++ show resultIndex,
                                (structural :-> result) :-> (opaque :-> result))
                            | (index, (opaque, structural)) <- zip [0 :: Natural ..] views
                            , opaque `Set.member` negativeTypes
                            , (resultIndex, result) <- zip [0 :: Natural ..] results
                            ]
                        constructors =
                            [ ( Symbol $ "$djinn$data-constructor$" ++ show index ++ "$" ++ show constructorIndex
                              , Symbol name
                              , foldr (:->) opaque fields)
                            | (index, (opaque, Disj alternatives)) <- zip [0 :: Natural ..] views
                            , opaque `Set.member` positiveTypes
                            , (constructorIndex, (ConsDesc name arity, Conj fields)) <-
                                zip [0 :: Natural ..] alternatives
                            , arity == length fields
                            ]
                  -- Existing cases preserve their constructor-free prefix.
                  -- Generic folds first compose constructors without forcing
                  -- one-layer cases; a second context permits both mechanisms.
                  , selectedViews <- if instantiated && not (null viewPremises)
                      then [[], viewPremises] else [viewPremises]
                  , selectedConstructors <- if null constructors then [[]]
                      else if instantiated then [constructors] else [[], constructors]
                  , let constructorPremises = [(symbol, form) | (symbol, _, form) <- selectedConstructors]
                        constructorApplications = Map.fromList
                            [(symbol, (source, [])) | (symbol, source, _) <- selectedConstructors]
                  ]
        , any ((`Set.member` sourceNegativeTypes) . fst) $
            preparedEnvironmentRecursiveDataViews prepared sourceSequent
        ]
      where
        -- Continuation form postpones selecting the scrutinized value until
        -- the goal's arguments are in scope. Direct R -> Shape R saturation
        -- would commit to a constructed nil before seeing those arguments,
        -- losing behaviorally distinct eliminations of the real inputs.
        residualResults (_ :-> remaining) = residualResults remaining
        residualResults (Conj fields) = concatMap residualResults fields
        residualResults resultFormula = [resultFormula]
        argumentTypes (argument :-> remaining) = argument : argumentTypes remaining
        argumentTypes _ = []
        atomsAtPolarity wanted polarity formula = case formula of
            atom@PVar{} | wanted == polarity -> Set.singleton atom
            left :-> right -> atomsAtPolarity wanted (not polarity) left
                `Set.union` atomsAtPolarity wanted polarity right
            Conj fields -> Set.unions $ map (atomsAtPolarity wanted polarity) fields
            Disj alternatives -> Set.unions $
                map (atomsAtPolarity wanted polarity . snd) alternatives
            _ -> Set.empty
    searchPlans =
        drop 1 structuralSearchPlans ++
        nominalSearchPlans ++
        focusedInstantiationSearchPlans ++
        structuralAxiomSearchPlans ++
        -- A productive historical loaded proof stream can consume the
        -- global candidate cutoff without finishing.  Run its strict
        -- provider-evidence superset first when that optional family
        -- exists; the empty-evidence plan list remains exactly historical.
        providerStructuralSearchPlans ++
        providerNominalSearchPlans ++
        loadedStructuralSearchPlans ++
        loadedNominalSearchPlans ++
        queryClosedStructuralSearchPlans ++
        queryClosedNominalSearchPlans ++
        queryCorrelatedStructuralSearchPlans ++
        queryCorrelatedNominalSearchPlans ++
        queryCorrelatedClosedStructuralSearchPlans ++
        queryCorrelatedClosedNominalSearchPlans
    -- One coherent view keeps quantified results opaque when the query
    -- already supplies exactly that scheme, while opening fresh obligations.
    -- It handles wide mixtures without enumerating subsets of forall sites.
    transportSearchPlans =
        [ ( suppliedPremises ++ loadedSchemePremises, [], Set.empty, Map.empty, Map.empty
          , translatedFormula translatedGoal, False
          )
        | let available = availableTransportSymbols primary premises
        , not $ Set.null available
        , Right translatedGoal <-
            [preparedEnvironmentTransportSynthesisFormula prepared available elaboratedGoal]
        , Right (suppliedPremises, _) <-
            [preparedEnvironmentTransportFunctionPremises prepared available]
        , novelTransportPlan formulaPlans plans premises translatedGoal suppliedPremises
        ] ++
        [ ( suppliedPremises ++ nominalLoadedSchemePremises, [], Set.empty
          , Map.empty, Map.empty
          , translatedFormula translatedGoal, False
          )
        | useNominalProjection
        , let available = availableTransportSymbols
                (primaryFormulaPlan nominalFormulaPlans) nominalPremises
        , not $ Set.null available
        , Right translatedGoal <-
            [preparedEnvironmentNominalTransportSynthesisFormula prepared available elaboratedGoal]
        , Right (suppliedPremises, _) <-
            [preparedEnvironmentNominalTransportFunctionPremises prepared available]
        , novelTransportPlan nominalFormulaPlans nominalPlans nominalPremises
            translatedGoal suppliedPremises
        ]
    availableTransportSymbols goal supplied = Set.unions $
        negativeOpaqueFormulaSymbols PositiveFormula (translatedFormula goal) :
        map (negativeOpaqueFormulaSymbols NegativeFormula . snd) supplied
    -- Existing views keep their established candidate order. A coherent view
    -- outside those frontiers runs first: otherwise a large cached consumer
    -- family could consume the entire budget before this one-step plan runs.
    novelTransportPlan sourcePlans existingGoals existingPremises goal supplied =
        -- Above the exhaustive occurrence frontier, try the coherent view
        -- without compiling thousands of older formulas just to compare them.
        -- This is a scheduling threshold, not a type-language restriction.
        polarizedFormulaPlanPositiveForallCount sourcePlans > maxCompleteForallFrontierSites ||
            translatedFormula goal `notElem` map fst existingGoals ||
            any (`Set.notMember` Set.fromList existingPremises)
                (filter ((/= targetSymbol) . fst) supplied)
    structuralConstructedFamilies = scopedConstructionInstantiationAxioms
        (preparedEnvironmentScopedSynthesisFormulaTranslator prepared) visibleArgumentInScope
        (goalVariables ++ polarizedFormulaPlanSkolems formulaPlans ++ premiseSpellings)
        (map fst plans) (map snd $ premises ++ activeLoadedSchemePremises)
        queryConstructedAxioms
    nominalConstructedFamilies = scopedConstructionInstantiationAxioms
        (preparedEnvironmentNominalScopedSynthesisFormulaTranslator prepared) visibleArgumentInScope
        (goalVariables ++ polarizedFormulaPlanSkolems nominalFormulaPlans ++ nominalPremiseSpellings)
        (map fst nominalPlans)
        (map snd $ nominalPremises ++ activeNominalLoadedSchemePremises)
        nominalQueryConstructedAxioms
    -- An available loaded scheme can construct a quantified result before the
    -- older generic loaded instances spend the choice budget. Keep the entire
    -- scoped family and its original source premises together; singleton
    -- aliases would lose the lexical ownership checked before erasure.
    -- Already successful primary/transport plans suppress this accelerator.
    loadedConstructedAccelerationPlans
        | not $ SharedType.containsForall elaboratedGoal = []
        | not hasLoadedConstructionSource = []
        | otherwise = concatMap (\axioms -> augmentDirected axioms
            [(activePremises ++ activeLoadedSchemePremises, [], Set.empty,
                Map.empty, Map.empty, translatedFormula primary, False)])
            structuralConstructedFamilies ++
            concatMap (\axioms -> augmentDirected axioms
                [(activeNominalPremises ++ activeNominalLoadedSchemePremises,
                    [], Set.empty, Map.empty, Map.empty,
                    translatedFormula $ primaryFormulaPlan nominalFormulaPlans, False)])
                nominalConstructedFamilies
    -- Providers beginning with an ordinary argument have no leading-scheme
    -- entry. Their result-position quantified atoms are nevertheless real
    -- available schemes once that argument is supplied. Use the same polarity
    -- as construction discovery, so a quantified argument obligation does not
    -- authorize this early plan. Target-named premises remain excluded.
    hasLoadedConstructionSource =
        not (null activeLoadedSchemePremises) ||
        not (null activeNominalLoadedSchemePremises) ||
        hasResidualConstructionSource formulaPlans activePremises ||
        hasResidualConstructionSource nominalFormulaPlans activeNominalPremises
    -- If an exact source already supplies the whole goal, its established
    -- opaque frontier can forward it directly. Keep that opportunity before
    -- speculative construction from quantifiers inside the supplied result
    -- (which may include an empty polytype). Leading-scheme plans retain
    -- their existing policy; this only gates newly eligible residual sources.
    hasResidualConstructionSource goalPlans available =
        any hasAvailableScheme available &&
        exactOpaqueFormulaPlan goalPlans `notElem` map snd available
    hasAvailableScheme =
        not . Set.null . negativeOpaqueFormulaSymbols NegativeFormula . snd
    -- Monotype results often need only forwarding (including self-application
    -- of an available complete polytype). Try those exact bridges before
    -- opening speculative construction scopes. Quantified goals retain the
    -- construction-first order needed by their argument introductions.
    deferredInstantiationPlans
        | SharedType.containsForall elaboratedGoal =
            [(inhabitationOnly, constructedSearchPlans), (inhabitationOnly, directedSearchPlans)]
        | otherwise = [(inhabitationOnly, directedSearchPlans), (inhabitationOnly, constructedSearchPlans)]
      where
        inhabitationOnly = not interleavePlanAlternatives
    constructedSearchPlans =
        concatMap (\axioms -> augmentDirected axioms
            (structuralSearchPlans ++ structuralAxiomSearchPlans ++
                providerStructuralSearchPlans ++ loadedStructuralSearchPlans ++
                queryClosedStructuralSearchPlans ++ queryCorrelatedStructuralSearchPlans))
            structuralConstructedFamilies ++
        concatMap (\axioms -> augmentDirected axioms
            (nominalSearchPlans ++ providerNominalSearchPlans ++ loadedNominalSearchPlans ++
                queryClosedNominalSearchPlans ++ queryCorrelatedNominalSearchPlans))
            nominalConstructedFamilies
    directedSearchPlans = instanceSearchPlans
        queryDirectedAxioms nominalQueryDirectedAxioms
    instanceSearchPlans structuralInstances nominalInstances =
        focusedPlansOf
            [(instantiationAxiomPremises structuralInstances,
                instantiationVisibleApplications structuralInstances)] ++
        augmentDirected structuralInstances
            (structuralSearchPlans ++ structuralAxiomSearchPlans ++
                providerStructuralSearchPlans ++ loadedStructuralSearchPlans ++
                queryClosedStructuralSearchPlans ++ queryCorrelatedStructuralSearchPlans) ++
        augmentDirected nominalInstances
            (nominalSearchPlans ++ providerNominalSearchPlans ++ loadedNominalSearchPlans ++
                queryClosedNominalSearchPlans ++ queryCorrelatedNominalSearchPlans)
    withoutProviders providerNames =
        filter ((`Set.notMember` providerNames) . fst)

    -- The streaming driver observes exactly one raw proof at a time using
    -- the same resumable cursors and checked plan machinery as the fair batch
    -- driver below. Only compact de-duplication expressions and the earliest
    -- successful ordinals survive delivery; consumed proof trees, source
    -- contexts and typed graphs are not accumulated in scheduler history.
    streamPlans candidateLimit budget firstCandidateOrdinal firstEvidenceOrdinal
            latest seen candidateKey queues
        | candidateLimit <= 0 = finishStream
            (SharedSearch.truncated SharedSearch.CandidateLimitReached) latest
        | otherwise = case takeFormulaStreamLane queues of
            Nothing -> finishStream SharedSearch.Finished latest
            Just (lane, remaining) -> case activateLaneWith startStreamingPlan suppress lane of
                Left failure -> [Left failure]
                Right Nothing -> resume candidateLimit budget latest seen candidateKey remaining
                Right (Just (FormulaPlanLane ordinal inhabitationOnly families pendingPlans (Just stream))) ->
                    advance ordinal inhabitationOnly families pendingPlans stream budget remaining
                Right (Just _) -> [Left $ DjinnInternalQueryFailure
                    "streaming proof-plan activation did not retain a cursor"]
      where
        -- Each family owns its local incremental plan queue. A turn ends at
        -- one raw proof or the existing finite choice quantum, so admitting
        -- more historical plans cannot dilute either carrier family's work
        -- share. The first turn remains historical, with no candidate lookahead.
        advance ordinal inhabitationOnly families pendingPlans stream currentBudget remaining =
                    case observeFormulaPlanStream stream of
                        FormulaStreamChoice continuation
                            | Just fuel <- currentBudget, fuel <= 0 -> finishStream
                                (SharedSearch.truncated SharedSearch.ChoicePointLimitReached) latest
                            | not interleavePlanAlternatives || formulaStreamWorkRemaining stream > 1 ->
                                advance ordinal inhabitationOnly families pendingPlans
                                    continuation {
                                        formulaStreamWorkRemaining = formulaStreamWorkRemaining stream - 1}
                                    (fmap (subtract 1) currentBudget) remaining
                            | otherwise -> resume candidateLimit (fmap (subtract 1) currentBudget)
                                latest seen candidateKey $
                                requeueStreamingPlan ordinal inhabitationOnly families pendingPlans
                                    continuation remaining
                        FormulaStreamProof proof continuation ->
                            case formulaStreamAssess stream $ SearchOutcome [proof] False currentBudget of
                                Left failure -> [Left failure]
                                Right result ->
                                    let candidates = formulaPlanCandidates result
                                        found = not $ null candidates
                                        nextCandidateOrdinal = noteOrdinal found ordinal firstCandidateOrdinal
                                        nextEvidenceOrdinal = noteOrdinal
                                            (formulaPlanEvidence result /= SharedQuery.NoEvidence)
                                            ordinal firstEvidenceOrdinal
                                        continued = continuation {
                                            formulaStreamProducedProof = True}
                                        nextQueues
                                            | interleavePlanAlternatives =
                                                requeueStreamingPlan ordinal inhabitationOnly
                                                    families pendingPlans continued remaining
                                            | not collectAcrossPlans && found = emptyFormulaStreamQueues
                                            | otherwise =
                                                prependFormulaStreamLane
                                                    (FormulaPlanLane ordinal inhabitationOnly families pendingPlans
                                                        (Just continued)) remaining
                                        nextLatest = Just $ streamPlanSummary result
                                        continue nextSeen nextKey = streamPlans (candidateLimit - 1) currentBudget
                                            nextCandidateOrdinal nextEvidenceOrdinal nextLatest nextSeen nextKey
                                            nextQueues
                                    in emitStreamCandidates result seen candidateKey candidates continue
                        FormulaStreamFinished
                            | formulaStreamProducedProof stream ->
                                resume candidateLimit currentBudget latest seen candidateKey $
                                    enqueueFormulaStreamLane
                                        (FormulaPlanLane (nextPlanOrdinal ordinal) inhabitationOnly
                                            families pendingPlans Nothing) remaining
                            | otherwise -> case formulaStreamAssess stream $ SearchOutcome [] False currentBudget of
                                Left failure -> [Left failure]
                                Right result ->
                                    let nextLatest = Just $ streamPlanSummary result
                                        nextEvidenceOrdinal = noteOrdinal
                                            (formulaPlanEvidence result /= SharedQuery.NoEvidence)
                                            ordinal firstEvidenceOrdinal
                                    in if evidenceCanBenefitFromAnotherPlan result
                                        then streamPlans candidateLimit (formulaPlanRemainingBudget result)
                                            firstCandidateOrdinal nextEvidenceOrdinal nextLatest seen candidateKey
                                            (enqueueFormulaStreamLane
                                                (FormulaPlanLane (nextPlanOrdinal ordinal) inhabitationOnly
                                                    families pendingPlans Nothing) remaining)
                                        else finishStream SharedSearch.Finished nextLatest
        resume nextLimit nextBudget = streamPlans nextLimit nextBudget
            firstCandidateOrdinal firstEvidenceOrdinal
        earlierThan ordinal = maybe False (< ordinal)
        suppress ordinal inhabitationOnly firstCandidateOnly =
            (inhabitationOnly &&
                (earlierThan ordinal firstCandidateOrdinal || earlierThan ordinal firstEvidenceOrdinal)) ||
            (firstCandidateOnly && earlierThan ordinal firstCandidateOrdinal)

        -- An empty terminal batch cannot repeat ValidatedCandidates, and a
        -- later incompatible formula view cannot refute an earlier witness.
        -- Truncation itself never becomes logical negative evidence.
        finishStream completion summary =
            [first DjinnResultInvariantFailure $ SharedQuery.mkQueryResult evidence $
                SharedSearch.SearchBatch (SharedSearch.Completed completion) metadata []]
          where
            metadata = maybe
                (DjinnQueryMetadata (show $ translatedFormula primary) Nothing)
                fst summary
            evidence
                | firstCandidateOrdinal /= Nothing = SharedQuery.NoEvidence
                | completion /= SharedSearch.Finished = SharedQuery.NoEvidence
                | otherwise = maybe SharedQuery.NoEvidence snd summary

    noteOrdinal False _ previous = previous
    noteOrdinal True ordinal previous = Just $ maybe ordinal (min ordinal) previous

    requeueStreamingPlan ordinal inhabitationOnly families pendingPlans stream queues =
        foldr enqueueFormulaStreamLane queues $
            requeuePlan ordinal inhabitationOnly families pendingPlans stream []

    -- Favor small compositions in carrier contexts whose residual result is
    -- demanded by the goal, including function-valued accumulators ending at
    -- that result. Other streaming cursors retain their existing work
    -- schedule; constructor composition uses the policy below in both APIs.
    -- Marker identities
    -- here are private planner provenance; the demand test compares formulae.
    startStreamingPlan plan@(planPremises, _, symbols, _, _, form, _) =
        case contextualPlanErasure plan of
            Just receipt -> startContextualFormulaPlan receipt sourceContext options target plan
            Nothing -> if constructorCompositionPlan plan
                then startConstructorCompositionPlan sourceContext options target plan
                else startFormulaPlanStreamWithNormalPriority prioritize sourceContext options target plan
      where
        carrierSymbol symbol =
            "$djinn$carrier-focused$" `isPrefixOf` symbolSpelling symbol
        relevant = [(symbol, formula) | (symbol, formula) <- planPremises,
            symbol `Set.member` symbols]
        prioritize = any carrierSymbol (Set.toList symbols) &&
            all ((== instantiationResult form) . instantiationResult . snd) relevant

    -- LJT may saturate a supplied fold with a closed constructor before the
    -- query's lambda-bound inputs are available. Open the exact outer arrow
    -- spine first in these contexts, so ordinary neutral argument search can
    -- select every compatible input, including distinct same-typed inputs in
    -- either order. Both APIs use the same charged introduction entrance and
    -- normal-form scheduling preference. Reconstructed proofs still check
    -- against the original sequent; source/provider authority is unchanged.
    -- This may replace an eta-short neutral prefix in these positive-only
    -- contexts. Historical and case-view plans retain their ordinary schedule.
    constructorCompositionPlan (_, _, symbols, _, _, _, _) =
        any (isPrefixOf "$djinn$carrier-focused$data$" . symbolSpelling) names &&
            not (any (isPrefixOf "$djinn$recursive-view$" . symbolSpelling) names)
      where
        names = Set.toList symbols

    streamPlanSummary result =
        ( DjinnQueryMetadata (formulaPlanFormula result) (formulaPlanFirstProof result)
        , case formulaPlanEvidence result of
            SharedQuery.ValidatedCandidates -> SharedQuery.NoEvidence
            other -> other
        )

    emitStreamCandidates _ seen candidateKey [] continue = continue seen candidateKey
    emitStreamCandidates result seen candidateKey (candidate : remaining) continue
        | any (SharedGenerated.alphaEquivalentExpression key) seen =
            emitStreamCandidates result seen candidateKey remaining continue
        | otherwise = case first DjinnResultInvariantFailure $
                SharedQuery.mkQueryResult SharedQuery.ValidatedCandidates $
                    SharedSearch.SearchBatch SharedSearch.Continuing
                        (fst $ streamPlanSummary result)
                        [projectValidatedTypedDjinnCandidate candidateKey candidate] of
            Left failure -> [Left failure]
            Right batch -> key `deepseq` (Right batch : emitStreamCandidates result (key : seen)
                (candidateKey + 1) remaining continue)
      where
        source = validatedCandidateOutput candidate
        key = etaNormalClauseExpression $ SourceEvidence.sourceCandidateComparisonClause source

    -- Advance active plans round-robin after one raw proof or a bounded
    -- quantum of choices. Every choice is still observed and charged before
    -- continuing the current turn. After a new plan's first turn, its cursor
    -- and still-lazy pending plan source get separate queue entries. Thus later
    -- formula views enter incrementally even when an earlier view has a
    -- prolific proof stream. No anchor is restarted and no continuation is
    -- discarded. Family admission retains the first-inhabitant-only rules;
    -- rejected and duplicate raw proofs still spend their original slots.
    runFairPlans candidateLimit budget completed front rear
        | candidateLimit <= 0 = finishFair
            (SharedSearch.truncated SharedSearch.CandidateLimitReached) budget completed
        | otherwise = case front of
            [] -> case reverse rear of
                [] -> finishFair SharedSearch.Finished budget completed
                next -> runFairPlans candidateLimit budget completed next []
            lane : remaining -> do
                active <- activateLane completed lane
                case active of
                    Nothing -> runFairPlans candidateLimit budget completed remaining rear
                    Just (FormulaPlanLane ordinal inhabitationOnly families pendingPlans (Just stream)) ->
                        case observeFormulaPlanStream stream of
                            FormulaStreamChoice continuation
                                | Just fuel <- budget, fuel <= 0 -> finishFair
                                    (SharedSearch.truncated SharedSearch.ChoicePointLimitReached)
                                    budget completed
                                | formulaStreamWorkRemaining stream > 1 ->
                                    runFairPlans candidateLimit (fmap (subtract 1) budget) completed
                                        (FormulaPlanLane ordinal inhabitationOnly families pendingPlans
                                            (Just continuation {
                                                formulaStreamWorkRemaining = formulaStreamWorkRemaining stream - 1})
                                            : remaining) rear
                                | otherwise -> runFairPlans candidateLimit
                                    (fmap (subtract 1) budget) completed remaining $
                                    requeuePlan ordinal inhabitationOnly families pendingPlans
                                        continuation rear
                            FormulaStreamProof proof continuation -> do
                                result <- formulaStreamAssess stream $
                                    SearchOutcome [proof] False budget
                                runFairPlans (candidateLimit - 1) budget ((ordinal, result) : completed)
                                    remaining $ requeuePlan ordinal inhabitationOnly families pendingPlans
                                        continuation {
                                            formulaStreamProducedProof = True} rear
                            FormulaStreamFinished
                                | formulaStreamProducedProof stream ->
                                    runFairPlans candidateLimit budget completed remaining $
                                        FormulaPlanLane (nextPlanOrdinal ordinal) inhabitationOnly
                                            families pendingPlans Nothing : rear
                                | otherwise -> do
                                    result <- formulaStreamAssess stream $
                                        SearchOutcome [] False budget
                                    let completed' = (ordinal, result) : completed
                                    if evidenceCanBenefitFromAnotherPlan result
                                        then runFairPlans candidateLimit
                                            (formulaPlanRemainingBudget result) completed' remaining $
                                            FormulaPlanLane (nextPlanOrdinal ordinal) inhabitationOnly
                                                families pendingPlans Nothing : rear
                                        else finishFair SharedSearch.Finished
                                            (formulaPlanRemainingBudget result) completed'
                    Just _ -> Left $ DjinnInternalQueryFailure
                        "fair proof-plan activation did not retain a cursor"

    -- Queue the active continuation before the next source admission on the
    -- following round. Splitting the source happens once per started plan:
    -- an already-suspended cursor has empty pending lists. Looking only at
    -- list constructors does not enumerate or compile future formula views.
    requeuePlan ordinal inhabitationOnly families pendingPlans stream rear =
        let continuation = FormulaPlanLane ordinal inhabitationOnly [] [] $
                Just stream {formulaStreamWorkRemaining = formulaPlanWorkQuantum}
        in case (families, pendingPlans) of
            ([], []) -> continuation : rear
            _ -> FormulaPlanLane (nextPlanOrdinal ordinal) inhabitationOnly
                families pendingPlans Nothing : continuation : rear

    finishFair completion budget completed = Right $ reverse $ case map snd completed of
        latest : earlier -> latest {formulaPlanCompletion = completion,
            formulaPlanRemainingBudget = budget} : earlier
        [] -> [FormulaPlanResult
            { formulaPlanFormula = show $ translatedFormula primary
            , formulaPlanFirstProof = Nothing
            , formulaPlanCompletion = completion
            , formulaPlanCandidates = []
            , formulaPlanEvidence = SharedQuery.NoEvidence
            , formulaPlanRemainingBudget = budget
            , formulaPlanProofCount = 0
            }]

    -- The source ordinal is scheduling metadata, not proof identity. Fast
    -- later/carrier results cannot suppress an earlier historical source.
    -- An admitted first-inhabitant accelerator can still be cancelled when
    -- an earlier source subsequently succeeds; consumed work and already
    -- emitted results remain in the global accounting/result stream.
    activateLane completed = activateLaneWith
        (\plan -> case contextualPlanErasure plan of
            Just receipt -> startContextualFormulaPlan receipt sourceContext options target plan
            Nothing -> if constructorCompositionPlan plan
                then startConstructorCompositionPlan sourceContext options target plan
                else startFormulaPlanStream sourceContext options target plan) $
        \ordinal inhabitationOnly firstCandidateOnly ->
        suppressPlan ordinal inhabitationOnly firstCandidateOnly completed
    activateLaneWith start suppress lane@(FormulaPlanLane ordinal inhabitationOnly families pendingPlans (Just stream))
        | suppress ordinal inhabitationOnly (formulaStreamFirstCandidateOnly stream) =
            activateLaneWith start suppress $ FormulaPlanLane (nextPlanOrdinal ordinal)
                inhabitationOnly families pendingPlans Nothing
        | otherwise = Right $ Just lane
    activateLaneWith start suppress (FormulaPlanLane ordinal _ families [] Nothing) =
        case nextAdmittedPlanFamily
                (\inhabitationOnly -> suppress ordinal inhabitationOnly False)
                families of
            Nothing -> Right Nothing
            Just (inhabitationOnly, familyPlans, remaining) ->
                activateLaneWith start suppress $ FormulaPlanLane ordinal inhabitationOnly
                    remaining familyPlans Nothing
    activateLaneWith start suppress (FormulaPlanLane ordinal inhabitationOnly families (plan : remaining) Nothing)
        | suppress ordinal inhabitationOnly False =
            activateLaneWith start suppress $ FormulaPlanLane ordinal False families [] Nothing
        | firstCandidateOnly
        , suppress ordinal False True =
            activateLaneWith start suppress $ FormulaPlanLane (nextPlanOrdinal ordinal)
                inhabitationOnly families remaining Nothing
        | otherwise = do
            stream <- start plan
            return $ Just $ FormulaPlanLane ordinal inhabitationOnly families remaining $
                Just stream {formulaStreamFirstCandidateOnly = firstCandidateOnly}
      where
        (_, _, symbols, _, _, _, _) = plan
        firstCandidateOnly = any isInhabitationFallbackSymbol $ Set.toList symbols

    suppressPlan ordinal inhabitationOnly firstCandidateOnly completed =
        (inhabitationOnly && (hasCandidate || hasEvidence)) ||
        (firstCandidateOnly && hasCandidate)
      where
        earlier = [result | (sourceOrdinal, result) <- completed, sourceOrdinal < ordinal]
        hasCandidate = any (not . null . formulaPlanCandidates) earlier
        hasEvidence = any ((/= SharedQuery.NoEvidence) . formulaPlanEvidence) earlier
    nextPlanOrdinal (lane, index) = (lane, index + 1)

    -- Do not even prepare an inhabitation-only fallback once historical search
    -- has found an inhabitant. Looking at a fallback's symbol set already
    -- forces axiom preparation, so deciding this from individual plan tuples
    -- would defeat the intended laziness.
    runPlans normalOnly deferred firstProofOnly ((inhabitationOnly, nextFamily) : remainingFamilies)
            collect currentOptions candidateLimit completed []
        | inhabitationOnly
        , any (not . null . formulaPlanCandidates) completed ||
            any ((/= SharedQuery.NoEvidence) . formulaPlanEvidence) completed =
            runPlans normalOnly deferred firstProofOnly remainingFamilies collect currentOptions candidateLimit completed []
        | otherwise =
            runPlans normalOnly deferred firstProofOnly remainingFamilies collect currentOptions candidateLimit completed nextFamily
    -- Product normal terms must not spend an earlier sequential plan's raw
    -- cutoff before later historical plans get their original turn. Remember
    -- only already-visited productive plans, then enumerate their extra grammar
    -- with the remaining global allowance. No historical cursor is restarted.
    runPlans False deferred False [] collect currentOptions candidateLimit completed []
        | optionAlternatives currentOptions && collect && not (null deferred) =
            runPlans True [] False [] collect currentOptions candidateLimit completed (reverse deferred)
    runPlans _ _ _ _ _ _ _ completed [] = Right $ reverse completed
    -- Focused contexts are a first-inhabitant accelerator. Once another plan
    -- has produced a term, enumerating that term again in singleton contexts
    -- would spend the raw-proof cutoff and starve later alternative families.
    runPlans normalOnly deferred firstProofOnly remainingFamilies collect currentOptions candidateLimit completed
            ((_, _, symbols, _, _, _, _) : remaining)
        | not normalOnly
        , any (not . null . formulaPlanCandidates) completed
        , any isInhabitationFallbackSymbol $ Set.toList symbols =
            runPlans normalOnly deferred firstProofOnly remainingFamilies collect currentOptions candidateLimit completed remaining
    runPlans normalOnly deferred firstProofOnly remainingFamilies collect currentOptions candidateLimit completed
            (plan@( planPremises
              , diagnosticOnlyPremises
              , axiomSymbols
              , visibleApplications
              , providerApplications
              , form
              , negativeEvidenceSound
              )
                : remaining) = do
        result <- case contextualPlanErasure plan of
            Nothing -> searchPreparedFormulaPlan sourceContext normalOnly firstProofOnly
                currentOptions candidateLimit target planPremises axiomSymbols
                visibleApplications providerApplications diagnosticOnlyPremises form
                (negativeEvidenceSound && not normalOnly)
            Just receipt -> searchContextualFormulaPlan receipt sourceContext normalOnly firstProofOnly
                currentOptions candidateLimit target plan
        let completed' = result : completed
            deferred'
                | not normalOnly && optionAlternatives currentOptions
                , formulaPlanProofCount result > 0
                , let (_, searchEnv, _) = formulaPlanSearchContext currentOptions target planPremises providerApplications
                , supportsProductTermAlternatives searchEnv form = plan : deferred
                | otherwise = deferred
            nextLimit = candidateLimit - formulaPlanProofCount result
            continue =
                formulaPlanFinished result &&
                not (firstProofOnly && formulaPlanProofCount result > 0) &&
                (collect || null (formulaPlanCandidates result)) &&
                evidenceCanBenefitFromAnotherPlan result
        if continue
            then runPlans normalOnly deferred' firstProofOnly remainingFamilies collect
                currentOptions {
                    optionBudget = formulaPlanRemainingBudget result
                    }
                nextLimit completed' remaining
            else Right $ reverse completed'

    isInhabitationFallbackSymbol (Symbol spelling) =
        "$djinn$focused$" `isPrefixOf` spelling ||
        (not interleavePlanAlternatives &&
            ("$djinn$query-directed-instantiation$" `isPrefixOf` spelling ||
                "$djinn$query-constructed-instantiation$" `isPrefixOf` spelling))
    isInhabitationFallbackSymbol _ = False

    prepared = SourceEvidence.sourceTypingPreparedEnvironment sourceContext

    -- A proof-backed target diagnostic is already the sharpest candidate-free
    -- result. A completed refutation may still be sharpened by a later
    -- target-instantiation plan, but only while finite search fuel remains;
    -- running that optional tail at zero fuel would replace established
    -- logical evidence with an operational truncation.
    evidenceCanBenefitFromAnotherPlan result =
        case formulaPlanEvidence result of
            SharedQuery.RequiresTargetReference -> False
            SharedQuery.ProvedUninhabitable ->
                formulaPlanRemainingBudget result /= Just 0
            _ -> True

    formulaFamilyForms familyPlans = SharedCollection.distinctOn id $
        translatedFormula (primaryFormulaPlan familyPlans) :
        exactOpaqueFormulaPlan familyPlans :
        map translatedFormula (singleOpaqueFormulaPlans familyPlans) ++
        map translatedFormula (singleOpenFormulaPlans familyPlans) ++
        map translatedFormula (pairOpaqueFormulaPlans familyPlans) ++
        map translatedFormula (pairOpenFormulaPlans familyPlans) ++
        map translatedFormula (tripleOpaqueFormulaPlans familyPlans) ++
        map translatedFormula (tripleOpenFormulaPlans familyPlans) ++
        map translatedFormula (quadrupleOpaqueFormulaPlans familyPlans) ++
        map translatedFormula (quadrupleOpenFormulaPlans familyPlans) ++
        map translatedFormula (quintupleOpaqueFormulaPlans familyPlans) ++
        map translatedFormula (quintupleOpenFormulaPlans familyPlans)

-- Goal plans retain their historical linear prefix: the fully opened
-- translation, the exact opaque fallback, one independently opaque positive
-- forall at a time, and one independently opened branch among opaque siblings.
-- Pairwise through quintic choices form deterministic bounded tails.
-- Global premises expose the same sound views simultaneously under
-- distinct internal proof identities, so one term may use different views at
-- different occurrences of a reusable source function. Every proof remains
-- checked against the exact goal formula that produced it.

-- One formula plan retains clauses before cross-plan de-duplication and
-- ranking. 'formulaPlanProofCount' counts raw proofs before either operation,
-- which makes the caller's cutoff global across every translation.
type ValidatedDjinnCandidate =
    ValidatedCandidate DjinnCandidateDetails
        SourceEvidence.SourceCandidate

type ValidatedDjinnResult =
    ValidatedResult DjinnQueryMetadata DjinnCandidateDetails
        SourceEvidence.SourceCandidate

-- | Package the final whole candidate association into the shared typed
-- envelope. Graph construction is lazy: compatibility projection does not
-- perform source checking or demand a later candidate's retained evidence.
projectValidatedTypedDjinnResult
    :: ValidatedDjinnResult
    -> Either SharedQuery.QueryResultInvariantError DjinnTypedResult
projectValidatedTypedDjinnResult =
    projectValidatedResultWith projectValidatedTypedDjinnCandidate

projectValidatedTypedDjinnCandidate
    :: Natural -> ValidatedDjinnCandidate -> DjinnTypedCandidate
projectValidatedTypedDjinnCandidate candidateKey validated =
    let sourceCandidate = validatedCandidateOutput validated
    in
    SharedTypedCandidate.mkKindedTypedCandidate
        (SharedCandidate.Candidate
            { SharedCandidate.candidateOutput =
                SourceEvidence.sourceCandidateClause sourceCandidate
            , SharedCandidate.candidateResidualConstraints = []
            , SharedCandidate.candidateDetails =
                validatedCandidateDetails validated
            })
        (first (DjinnTermGraphSourceTypingFailure . show) $
            SourceGraph.checkAnnotatedSourceClauseGraphWithKinds candidateKey
                (SourceEvidence.sourceCandidateContext sourceCandidate)
                (SourceEvidence.sourceCandidateAnnotations sourceCandidate)
                (SourceEvidence.sourceCandidateAnnotatedClause sourceCandidate))

data FormulaPlanResult = FormulaPlanResult
    { formulaPlanFormula :: String
    , formulaPlanFirstProof :: Maybe String
    , formulaPlanCompletion :: SharedSearch.Completion
    , formulaPlanCandidates :: [ValidatedDjinnCandidate]
    , formulaPlanEvidence :: SharedQuery.QueryEvidence
    , formulaPlanRemainingBudget :: Maybe Integer
    , formulaPlanProofCount :: Int
    }

type FormulaSearchPlan =
    ( [(Symbol, Formula)], [(Symbol, Formula)], Set.Set Symbol
    , Map.Map Symbol [SharedGenerated.VisibleTypeArgument]
    , Map.Map Symbol (Symbol, [SharedGenerated.VisibleTypeArgument])
    , Formula, Bool
    )

data FormulaPlanStream = FormulaPlanStream
    { formulaStreamCursor :: ProofSearchCursor
    , formulaStreamPendingIntroductions :: Int
    , formulaStreamAssess :: SearchOutcome -> Either DjinnQueryError FormulaPlanResult
    , formulaStreamProducedProof :: Bool
    , formulaStreamFirstCandidateOnly :: Bool
    , formulaStreamWorkRemaining :: Int
    }

data FormulaStreamObservation
    = FormulaStreamFinished
    | FormulaStreamChoice FormulaPlanStream
    | FormulaStreamProof Proof FormulaPlanStream

-- A focused sequent may have opened the query's outer arrows before entering
-- LJT. Charge every such introduction through the very same outer choice
-- counter, without observing its proof cursor or borrowing another budget.
observeFormulaPlanStream :: FormulaPlanStream -> FormulaStreamObservation
observeFormulaPlanStream stream
    | formulaStreamPendingIntroductions stream > 0 = FormulaStreamChoice
        stream {formulaStreamPendingIntroductions = formulaStreamPendingIntroductions stream - 1}
    | otherwise = case observeProofSearch $ formulaStreamCursor stream of
        ProofSearchFinished -> FormulaStreamFinished
        ProofSearchChoice continuation -> FormulaStreamChoice
            stream {formulaStreamCursor = continuation}
        ProofSearchResult proof continuation -> FormulaStreamProof proof
            stream {formulaStreamCursor = continuation}

-- Scheduling only: a raw proof preempts this turn, and every choice still
-- spends the shared query allowance. It is not a separate search budget.
formulaPlanWorkQuantum :: Int
formulaPlanWorkQuantum = 64

data FormulaPlanLane = FormulaPlanLane
    (Int, Int) Bool [(Bool, [FormulaSearchPlan])] [FormulaSearchPlan] (Maybe FormulaPlanStream)

-- Streaming rotates among historical, exact-demand, and other-carrier
-- families. Each remains a FIFO of active cursors and lazy plan sources.
-- Growing one family's plan population cannot reduce another's turn
-- frequency: function-valued accumulators retain their own turn alongside
-- direct result instances. Empty families lend their turns without probing
-- any proof cursor. The private source ordinal's first coordinate tags its
-- family; it is not candidate or proof identity.
data FormulaStreamQueues = FormulaStreamQueues
    Int ([FormulaPlanLane], [FormulaPlanLane])
        ([FormulaPlanLane], [FormulaPlanLane]) ([FormulaPlanLane], [FormulaPlanLane])

emptyFormulaStreamQueues :: FormulaStreamQueues
emptyFormulaStreamQueues = FormulaStreamQueues 0 ([], []) ([], []) ([], [])

takeFormulaStreamLane :: FormulaStreamQueues -> Maybe (FormulaPlanLane, FormulaStreamQueues)
takeFormulaStreamLane (FormulaStreamQueues preferred historical demanded carriers) =
    choose [preferred, (preferred + 1) `mod` 3, (preferred + 2) `mod` 3]
  where
    choose [] = Nothing
    choose (family : rest) = case popFamily family of
        Just selected -> Just selected
        Nothing -> choose rest
    popFamily 0 = fmap (\(lane, remaining) ->
        (lane, FormulaStreamQueues 1 remaining demanded carriers)) $ pop historical
    popFamily 1 = fmap (\(lane, remaining) ->
        (lane, FormulaStreamQueues 2 historical remaining carriers)) $ pop demanded
    popFamily _ = fmap (\(lane, remaining) ->
        (lane, FormulaStreamQueues 0 historical demanded remaining)) $ pop carriers
    pop (firstLane : remaining, rear) = Just (firstLane, (remaining, rear))
    pop ([], rear) = case reverse rear of
        [] -> Nothing
        firstLane : remaining -> Just (firstLane, (remaining, []))

enqueueFormulaStreamLane :: FormulaPlanLane -> FormulaStreamQueues -> FormulaStreamQueues
enqueueFormulaStreamLane lane@(FormulaPlanLane (family, _) _ _ _ _)
        (FormulaStreamQueues preferred (historical, historicalRear)
            (demanded, demandedRear) (carriers, carriersRear))
    | family == 1 = FormulaStreamQueues preferred
        (historical, historicalRear) (demanded, lane : demandedRear) (carriers, carriersRear)
    | family == 2 = FormulaStreamQueues preferred
        (historical, historicalRear) (demanded, demandedRear) (carriers, lane : carriersRear)
    | otherwise = FormulaStreamQueues preferred
        (historical, lane : historicalRear) (demanded, demandedRear) (carriers, carriersRear)

prependFormulaStreamLane :: FormulaPlanLane -> FormulaStreamQueues -> FormulaStreamQueues
prependFormulaStreamLane lane@(FormulaPlanLane (family, _) _ _ _ _)
        (FormulaStreamQueues preferred (historical, historicalRear)
            (demanded, demandedRear) (carriers, carriersRear))
    | family == 1 = FormulaStreamQueues preferred
        (historical, historicalRear) (lane : demanded, demandedRear) (carriers, carriersRear)
    | family == 2 = FormulaStreamQueues preferred
        (historical, historicalRear) (demanded, demandedRear) (lane : carriers, carriersRear)
    | otherwise = FormulaStreamQueues preferred
        (lane : historical, historicalRear) (demanded, demandedRear) (carriers, carriersRear)

-- The cursor and the independent checker use exactly the same renamed
-- assumptions. The callback only supplies an already-observed raw prefix;
-- it cannot add premises or bypass the existing checked conversion pipeline.
startFormulaPlanStream
    :: SourceEvidence.SourceTypingContext
    -> QueryOptions -> SharedGenerated.DefinitionName -> FormulaSearchPlan
    -> Either DjinnQueryError FormulaPlanStream
startFormulaPlanStream = startFormulaPlanStreamWithNormalPriority False

startFormulaPlanStreamWithNormalPriority
    :: Bool
    -> SourceEvidence.SourceTypingContext
    -> QueryOptions -> SharedGenerated.DefinitionName -> FormulaSearchPlan
    -> Either DjinnQueryError FormulaPlanStream
startFormulaPlanStreamWithNormalPriority prioritize =
    startFormulaPlanStreamWithGoalPolicy prioritize False

startConstructorCompositionPlan
    :: SourceEvidence.SourceTypingContext
    -> QueryOptions -> SharedGenerated.DefinitionName -> FormulaSearchPlan
    -> Either DjinnQueryError FormulaPlanStream
startConstructorCompositionPlan sourceContext options =
    startFormulaPlanStreamWithGoalPolicy True
        (optionAlternatives options && optionStrategy options == Interleave)
        sourceContext options

startFormulaPlanStreamWithGoalPolicy
    :: Bool -> Bool
    -> SourceEvidence.SourceTypingContext
    -> QueryOptions -> SharedGenerated.DefinitionName -> FormulaSearchPlan
    -> Either DjinnQueryError FormulaPlanStream
startFormulaPlanStreamWithGoalPolicy = startFormulaPlanStreamWithContextual Nothing

startContextualFormulaPlan
    :: SourceEvidence.RootGivenErasure -> SourceEvidence.SourceTypingContext
    -> QueryOptions -> SharedGenerated.DefinitionName -> FormulaSearchPlan
    -> Either DjinnQueryError FormulaPlanStream
startContextualFormulaPlan receipt =
    startFormulaPlanStreamWithContextual (Just receipt) False True

startFormulaPlanStreamWithContextual
    :: Maybe SourceEvidence.RootGivenErasure -> Bool -> Bool
    -> SourceEvidence.SourceTypingContext
    -> QueryOptions -> SharedGenerated.DefinitionName -> FormulaSearchPlan
    -> Either DjinnQueryError FormulaPlanStream
startFormulaPlanStreamWithContextual contextual prioritize introduce sourceContext options target
        (premises, diagnostics, symbols, visible, providers, form, negativeSound) = do
    let (proofEnv, internalEnv, mode) = formulaPlanSearchContext options target premises providers
        requiredContextual = Set.fromList
            [ internal
            | Just _ <- [contextual]
            , (internal, _) <- internalEnv
            , Var external <- [restoreProofTerm proofEnv $ Var internal]
            , "$djinn$context-instantiation$" `isPrefixOf` symbolSpelling external
            ]
        reserved = Set.fromList $
            Symbol (SharedGenerated.definitionSpelling target) :
            map fst (internalEnv ++ premises ++ diagnostics) ++
            concatMap (formulaSymbols . snd) (internalEnv ++ premises ++ diagnostics) ++
            formulaSymbols form ++ Set.toList symbols ++ Map.keys visible ++
            Map.keys providers ++ map fst (Map.elems providers)
        (introduced, searchGoal)
            | introduce = openFormulaGoal reserved 0 form
            | otherwise = ([], form)
        searchEnv = reverse introduced ++ internalEnv
        restoreGoal proof = foldr (Lam . fst) proof introduced
        assess outcome = do
            -- Check exactly the environment the cursor used before restoring
            -- the goal's lambda spine. The ordinary downstream checker then
            -- independently validates the wrapped proof at the original goal.
            unless (null introduced) $
                first (DjinnInternalQueryFailure . ("invalid opened-goal proof: " ++)) $
                    mapM_ (void . checkProofWithEvidence searchEnv searchGoal) $ searchProofs outcome
            searchPreparedFormulaPlanByWithContextual contextual sourceContext True
                (\_ _ _ -> Right outcome {searchProofs = map restoreGoal $ searchProofs outcome})
                options 1 target premises symbols visible providers diagnostics form negativeSound
    cursor <- first (DjinnInternalQueryFailure .
        ("invalid proof-search environment: " ++)) $
        (if not $ Set.null requiredContextual
            then startProofSearchWithAssumptionUseChecked requiredContextual
            -- Common-result bridges can cooperate across distinct argument
            -- branches. Try paths without repeated heads before unrestricted
            -- recursive compositions; every original continuation remains.
            else if any (isPrefixOf "$djinn$carrier-focused$common$" . symbolSpelling) $
                    Set.toList symbols
                then startProofSearchWithAcyclicHeadsChecked
            else if prioritize then startProofSearchWithNormalPriorityChecked else startProofSearchChecked)
            mode searchEnv searchGoal
    return FormulaPlanStream
        { formulaStreamCursor = cursor
        , formulaStreamPendingIntroductions = length introduced
        , formulaStreamAssess = assess
        , formulaStreamProducedProof = False
        , formulaStreamFirstCandidateOnly = False
        , formulaStreamWorkRemaining = formulaPlanWorkQuantum
        }
-- Freshness includes source/provider spellings as well as internal names:
-- restoring a free assumption must never capture it under a new lambda.
-- The domains are the original exact Formula nodes, with no substitution
-- or extra proof premise beyond the query's own arrow-introduction rule.
openFormulaGoal :: Set.Set Symbol -> Natural -> Formula -> ([(Symbol, Formula)], Formula)
openFormulaGoal used next (domain :-> result) =
    let (binder, following) = freshInput used next
        (remaining, final) = openFormulaGoal (Set.insert binder used) following result
    in ((binder, domain) : remaining, final)
openFormulaGoal _ _ result = ([], result)

freshInput :: Set.Set Symbol -> Natural -> (Symbol, Natural)
freshInput used next =
    let binder = Symbol $ "$djinn$query-input$" ++ show next
    in if binder `Set.member` used
        then freshInput used (next + 1)
        else (binder, next + 1)

-- The sequential entrance opens exactly the same sequent as its cursor
-- counterpart. Each introduction is charged before observing the underlying
-- search, including at zero/tiny budgets; no proof is produced on borrowed
-- fuel. Both independent checks still see the complete original goal.
searchContextualFormulaPlan
    :: SourceEvidence.RootGivenErasure -> SourceEvidence.SourceTypingContext
    -> Bool -> Bool -> QueryOptions -> Int -> SharedGenerated.DefinitionName
    -> FormulaSearchPlan -> Either DjinnQueryError FormulaPlanResult
searchContextualFormulaPlan receipt sourceContext normalOnly firstOnly options candidateLimit target
        (premises, diagnostics, symbols, visible, providers, form, _) =
    searchPreparedFormulaPlanByWithContextual (Just receipt) sourceContext False run
        options candidateLimit target premises symbols visible providers diagnostics form False
  where
    run mode internalEnv goal = do
        let reserved = Set.fromList $
                Symbol (SharedGenerated.definitionSpelling target) :
                map fst (internalEnv ++ premises ++ diagnostics) ++
                concatMap (formulaSymbols . snd) (internalEnv ++ premises ++ diagnostics) ++
                formulaSymbols goal ++ Set.toList symbols ++ Map.keys visible ++
                Map.keys providers ++ map fst (Map.elems providers)
            (introduced, opened) = openFormulaGoal reserved 0 goal
            count = fromIntegral $ length introduced
            restore proof = foldr (Lam . fst) proof introduced
            openedEnvironment = reverse introduced ++ internalEnv
        case searchBudget mode of
            Just fuel | fuel < count -> Right $ SearchOutcome [] True $ Just 0
            _ -> do
                outcome <- (if normalOnly then proveNormalAlternativesWithModeChecked
                    else if firstOnly then proveFirstWithModeChecked else proveWithModeChecked)
                    mode {searchBudget = fmap (subtract count) $ searchBudget mode,
                        searchTermAlternatives = normalOnly && searchTermAlternatives mode}
                    openedEnvironment opened
                -- The downstream owner checks and converts only this raw
                -- prefix. Checking the entire opened proof list first would
                -- force an unbounded tail before its candidate cutoff applies.
                mapM_ (void . checkProofWithEvidence openedEnvironment opened) $
                    take candidateLimit $ searchProofs outcome
                pure outcome {searchProofs = map restore $ searchProofs outcome}

formulaPlanSearchContext
    :: QueryOptions -> SharedGenerated.DefinitionName -> [(Symbol, Formula)]
    -> Map.Map Symbol (Symbol, [SharedGenerated.VisibleTypeArgument])
    -> (ProofEnvironment, [(Symbol, Formula)], SearchMode)
formulaPlanSearchContext options target externalEnv providerApplications =
    (proofEnv, internalEnv, mode)
  where
    proofEnv = prepareProofEnvironment
        (Symbol $ SharedGenerated.definitionSpelling target) externalEnv
    internalEnv = proofBindings proofEnv
    mode = (defaultSearchMode
                (optionAlternatives options || optionSorted options))
        { searchTermAlternatives = optionAlternatives options
        , searchStrategy = optionStrategy options
        , searchBudget = optionBudget options
        , searchRanking = optionRanking options
        , searchProviderCosts = optionProviderCosts options
        , searchProviderNames = Map.fromList
            [ (internal, sourceName)
            | (internal, _) <- internalEnv
            , Var restored <- [restoreProofTerm proofEnv $ Var internal]
            -- Synthetic exact specializations retain their source's price.
            , let provider = maybe restored fst $
                    Map.lookup restored providerApplications
            , Right sourceName <- [SharedName.parseName $ symbolSpelling provider]
            ]
        }

-- | One proof-search plan. The final flag authorizes logical negative
-- evidence only when translation covered every quantified subtree. Checked
-- proofs remain useful under an incomplete plan, but absence of one does not
-- establish that the original Haskell type is uninhabited. The extra premise
-- list is diagnostic-only: it contains target-derived instantiation axioms
-- or provider specializations which must never enter safe proof search. Other
-- instantiation axioms participate in search and proof checking under their
-- reserved symbols; their evidence is erased only after checking. The second
-- application map retains direct provider-local specializations: proof
-- checking sees their synthetic premise, then generated conversion rewrites a
-- synthetic occurrence through its exact provider before the existing visible
-- type-application lowering runs.
searchPreparedFormulaPlan
    :: SourceEvidence.SourceTypingContext
    -> Bool
    -> Bool
    -> QueryOptions
    -> Int
    -> SharedGenerated.DefinitionName
    -> [(Symbol, Formula)]
    -> Set.Set Symbol
    -> Map.Map Symbol [SharedGenerated.VisibleTypeArgument]
    -> Map.Map Symbol
        (Symbol, [SharedGenerated.VisibleTypeArgument])
    -> [(Symbol, Formula)]
    -> Formula
    -> Bool
    -> Either DjinnQueryError FormulaPlanResult
searchPreparedFormulaPlan sourceContext normalOnly firstProofOnly =
    searchPreparedFormulaPlanBy sourceContext False $ \mode ->
        if normalOnly then proveNormalAlternativesWithModeChecked mode
        else (if firstProofOnly then proveFirstWithModeChecked else proveWithModeChecked)
            mode {searchTermAlternatives = False}

searchPreparedFormulaPlanBy
    :: SourceEvidence.SourceTypingContext
    -> Bool
    -> (SearchMode -> [(Symbol, Formula)] -> Formula -> Either String SearchOutcome)
    -> QueryOptions
    -> Int
    -> SharedGenerated.DefinitionName
    -> [(Symbol, Formula)]
    -> Set.Set Symbol
    -> Map.Map Symbol [SharedGenerated.VisibleTypeArgument]
    -> Map.Map Symbol (Symbol, [SharedGenerated.VisibleTypeArgument])
    -> [(Symbol, Formula)]
    -> Formula
    -> Bool
    -> Either DjinnQueryError FormulaPlanResult
searchPreparedFormulaPlanBy = searchPreparedFormulaPlanByWithContextual Nothing

searchPreparedFormulaPlanByWithContextual
    :: Maybe SourceEvidence.RootGivenErasure
    -> SourceEvidence.SourceTypingContext
    -> Bool
    -> (SearchMode -> [(Symbol, Formula)] -> Formula -> Either String SearchOutcome)
    -> QueryOptions
    -> Int
    -> SharedGenerated.DefinitionName
    -> [(Symbol, Formula)]
    -> Set.Set Symbol
    -> Map.Map Symbol [SharedGenerated.VisibleTypeArgument]
    -> Map.Map Symbol (Symbol, [SharedGenerated.VisibleTypeArgument])
    -> [(Symbol, Formula)]
    -> Formula
    -> Bool
    -> Either DjinnQueryError FormulaPlanResult
searchPreparedFormulaPlanByWithContextual contextual sourceContext chargeDiagnosticChoices runProofSearch options candidateLimit target externalEnv
        axiomSymbols visibleApplications providerApplications
        diagnosticOnlyEnv form
        negativeEvidenceSound = do
    let name = SharedGenerated.definitionSpelling target
        (proofEnv, internalEnv, mode) =
            formulaPlanSearchContext options target externalEnv providerApplications
        internalFailure what = first $
            DjinnInternalQueryFailure . ((what ++ ": ") ++)
    outcome <- internalFailure "invalid proof-search environment" $
        runProofSearch mode internalEnv form
    case searchProofs outcome of
        [] -> do
            (failure, diagnosticRemaining) <-
                if searchExhausted outcome then
                    return (Undecided, remainingSearchBudget outcome)
                else if not negativeEvidenceSound then
                    return (Undecided, remainingSearchBudget outcome)
                else if not (targetWasExcluded proofEnv) then
                    return (Unrealizable, remainingSearchBudget outcome)
                else do
                    -- The safe search has already decided that no admissible
                    -- proof exists.  Reintroduce target-named assumptions only
                    -- to justify the sharper diagnostic, spending no more than
                    -- the first search's unused fuel.  Exhaustion here cannot
                    -- make the already-decided safe result 'Undecided'.
                    let diagnosticEnv =
                            proofBindingsIncludingTarget $
                                prepareProofEnvironment (Symbol name) $
                                    externalEnv ++ diagnosticOnlyEnv
                        diagnosticMode = mode {
                            searchAlternatives = False,
                            searchBudget = remainingSearchBudget outcome
                            }
                        diagnosticSearch
                            | chargeDiagnosticChoices = proveFirstWithModeChecked
                            | otherwise = proveWithModeChecked
                    diagnosticOutcome <- internalFailure
                        "invalid diagnostic proof-search environment" $
                        diagnosticSearch diagnosticMode diagnosticEnv form
                    let remaining
                            | chargeDiagnosticChoices = remainingSearchBudget diagnosticOutcome
                            | otherwise = remainingSearchBudget outcome
                    case searchProofs diagnosticOutcome of
                        diagnosticProof : _ -> do
                            internalFailure
                                "generated an invalid self-reference proof" $
                                void $ checkProofWithEvidence
                                    diagnosticEnv form diagnosticProof
                            return (UnrealizableWithoutSelfReference, remaining)
                        [] -> return (Unrealizable, remaining)
            return FormulaPlanResult {
                formulaPlanFormula = show form,
                formulaPlanFirstProof = Nothing,
                formulaPlanCompletion = queryCompletion outcome,
                formulaPlanCandidates = [],
                formulaPlanEvidence = outcomeEvidence failure,
                formulaPlanRemainingBudget = diagnosticRemaining,
                formulaPlanProofCount = 0
                }
        proofs@(_ : _) -> do
            -- Bound the raw proof stream before checking and conversion. The
            -- outer worker subtracts this count before a complementary plan,
            -- so duplicate printed clauses and both translations consume the
            -- same documented proof-candidate cutoff.
            let (internalProofs, overflow) =
                    splitAt candidateLimit proofs
                candidateLimitReached = not $ null overflow
                convertProof _ evidence =
                    (case contextual of
                        Nothing -> \context environment axioms visible providers definition proof ->
                            first SourceEvidence.InvalidContextualLowering $
                                SourceEvidence.lowerCheckedSourceCandidate context environment
                                    axioms visible providers definition proof
                        Just receipt -> SourceEvidence.admitCheckedContextualSourceCandidate receipt)
                        sourceContext
                        proofEnv axiomSymbols visibleApplications
                        providerApplications target evidence
            -- Preserve the historical error precedence by checking every raw
            -- proof before converting any of them. Each opaque intermediate
            -- retains the exact evidence returned for that same raw proof;
            -- conversion consumes the association directly rather than
            -- rebuilding it positionally after erasure.
            checkedProofs <- internalFailure "generated an invalid proof" $
                mapM
                    (checkCandidateProofWith $
                        checkProofWithEvidence internalEnv form)
                    internalProofs
            -- Each constructed argument introduces its own rigid scope. A
            -- raw propositional proof may reuse an axiom beneath that same
            -- introduction; it needs a fresh instance before it can become a
            -- source-language term. Keep counting it against the raw budget,
            -- but do not erase its scope evidence into a candidate.
            let independentProofs =
                    [ checked
                    | (internalProof, checked) <- zip internalProofs checkedProofs
                    , independentConstructionScopes axiomSymbols $
                        restoreProofTerm proofEnv internalProof
                    -- A carrier-only plan must contribute its new instance,
                    -- not refill the candidate pool with proofs available in
                    -- the historical context. Ignored-instance proofs still
                    -- consume the raw cutoff and their complete checking cost.
                    , Set.null requiredCarrierSymbols ||
                        usesInstantiationEvidence requiredCarrierSymbols
                            (restoreProofTerm proofEnv internalProof)
                    ]
                requiredCarrierSymbols = Set.filter
                    (isPrefixOf "$djinn$carrier-focused$" . symbolSpelling)
                    axiomSymbols
            admitted <- internalFailure
                "cannot construct generated clause" $
                mapM
                    (\checked -> case convertCheckedCandidateWithEvidence convertProof
                        (candidateDetails . SourceEvidence.sourceCandidateClause) checked of
                        Left (SourceEvidence.UnsupportedContextualErasure _) -> Right Nothing
                        Left (SourceEvidence.InvalidContextualLowering failure) -> Left failure
                        Right candidate -> Right $ Just candidate)
                    independentProofs
            -- Unsupported lexical erasures still consumed their raw proof and
            -- all cursor choices. Do not retry/refill, claim negative evidence,
            -- or detach another proof's source authority when omitting them.
            let generatedCandidates = [candidate | Just candidate <- admitted]
                firstProof = case internalProofs of
                    firstProofTerm : _ -> Just $ show firstProofTerm
                    [] -> Nothing
                completion
                    | candidateLimitReached = SharedSearch.truncated
                        SharedSearch.CandidateLimitReached
                    | otherwise = queryCompletion outcome
                evidence = case generatedCandidates of
                    [] -> SharedQuery.NoEvidence
                    _ : _ -> SharedQuery.ValidatedCandidates
            return FormulaPlanResult {
                formulaPlanFormula = show form,
                formulaPlanFirstProof = firstProof,
                formulaPlanCompletion = completion,
                formulaPlanCandidates = generatedCandidates,
                formulaPlanEvidence = evidence,
                formulaPlanRemainingBudget = remainingSearchBudget outcome,
                formulaPlanProofCount = length internalProofs
                }

formulaPlanFinished :: FormulaPlanResult -> Bool
formulaPlanFinished result =
    formulaPlanCompletion result == SharedSearch.Finished

-- Build the public result only after all requested plans have run. Whole
-- candidate/evidence associations are structurally de-duplicated across the
-- union and, when requested, stably ranked once; only then does the final
-- private result project to the historical shared result. Proof checking
-- remains plan-local above.
mergeFormulaPlanResults
    :: QueryOptions
    -> [FormulaPlanResult]
    -> Either DjinnQueryError ValidatedDjinnResult
mergeFormulaPlanResults _ [] = internalQueryFailure
    "rank-N formula planning produced no search plan"
mergeFormulaPlanResults options results = Right validatedResult
  where
    terminalPlan = last results
    metadataPlan = case filter
            (not . null . formulaPlanCandidates) results of
        result : _ -> result
        [] -> terminalPlan
    mergedCandidates = concatMap formulaPlanCandidates results
    -- Axiom-consuming proofs retain eta expansion because Haskell simplified
    -- subsumption is not closed under the propositional eta law. Use the
    -- historical eta-normal form only for alpha-aware de-duplication. This
    -- collapses safe expanded spellings against their earlier compact
    -- candidate without rewriting the first, potentially eta-sensitive output
    -- we retain.
    distinctCandidates = deduplicateEtaEquivalentClausesOn
        (SourceEvidence.sourceCandidateComparisonClause . validatedCandidateOutput) mergedCandidates
    candidates = SharedQuality.rankCandidatesByQuality (optionRanking options)
        (\name -> Map.findWithDefault (SharedQuality.defaultCandidateProviderCost name) name $ optionProviderCosts options)
        (SharedGenerated.functionClauseExpression . SourceEvidence.sourceCandidateClause . validatedCandidateOutput)
        historicallyRanked
    historicallyRanked
        | optionSorted options = sortValidatedCandidates distinctCandidates
        | otherwise = distinctCandidates
    evidence = case candidates of
        _ : _ -> SharedQuery.ValidatedCandidates
        [] -> formulaPlanEvidence terminalPlan
    validatedResult :: ValidatedDjinnResult
    validatedResult = mkValidatedResult
        evidence
        (formulaPlanCompletion terminalPlan)
        (DjinnQueryMetadata
            (formulaPlanFormula metadataPlan)
            (formulaPlanFirstProof metadataPlan))
        candidates

candidateDetails
    :: SharedGenerated.FunctionClause HSymbol
    -> DjinnCandidateDetails
candidateDetails clause
    | total == 0 = DjinnCandidateDetails 0 0
    | otherwise = DjinnCandidateDetails
        (toInteger unused % toInteger total)
        total
  where
    (unused, total) = List.foldl' countBinder (0, 0) $
        SharedGenerated.functionClauseBindingSites clause

    countBinder
        :: (Natural, Natural)
        -> Maybe HSymbol
        -> (Natural, Natural)
    countBinder (!unusedCount, !totalCount) binding =
        let !nextUnused =
                case binding of
                    Nothing -> unusedCount + 1
                    Just _ -> unusedCount
            !nextTotal = totalCount + 1
        in (nextUnused, nextTotal)

resultToGeneratedReport :: DjinnResult -> Either String GeneratedQueryReport
resultToGeneratedReport result = case SharedSearch.batchProgress search of
    SharedSearch.Completed completion -> Right GeneratedQueryReport {
        generatedReportFormula = djinnTranslatedFormula metadata,
        generatedReportProof = djinnFirstExploredProof metadata,
        generatedReportCompletion = completion,
        generatedReportCandidates = SharedSearch.batchCandidates search,
        generatedReportEvidence = SharedQuery.resultEvidence result
        }
    SharedSearch.Continuing -> Left
        "internal Djinn result invariant: proof search returned a continuing batch"
  where
    search = SharedQuery.resultSearch result
    metadata = SharedSearch.batchMetadata search

renderDjinnQueryError :: DjinnQueryError -> String
renderDjinnQueryError failure = case failure of
    DjinnQueryOptionsFailure optionsFailure ->
        renderDjinnQueryOptionsError optionsFailure
    DjinnQueryFailure message -> message
    DjinnInstantiationCandidateFailure message -> message
    DjinnInstantiationAssignmentFailure message -> message
    DjinnInternalQueryFailure message -> message
    DjinnResultInvariantFailure invariant ->
        "internal Djinn result invariant: " ++ show invariant

renderDjinnQueryOptionsError :: DjinnQueryOptionsError -> String
renderDjinnQueryOptionsError failure = case failure of
    NonPositiveCandidateCutoff _ -> "optionCutoff must be positive"
    NegativeChoicePointBudget _ -> "optionBudget must be non-negative"

outcomeEvidence :: QueryOutcome -> SharedQuery.QueryEvidence
outcomeEvidence outcome = case outcome of
    Realized{} -> SharedQuery.ValidatedCandidates
    Unrealizable -> SharedQuery.ProvedUninhabitable
    UnrealizableWithoutSelfReference -> SharedQuery.RequiresTargetReference
    Undecided -> SharedQuery.NoEvidence

evidenceOutcome :: SharedQuery.QueryEvidence -> [String] -> QueryOutcome
evidenceOutcome evidence rendered = case evidence of
    SharedQuery.ValidatedCandidates -> Realized rendered
    SharedQuery.ProvedUninhabitable -> Unrealizable
    SharedQuery.RequiresTargetReference -> UnrealizableWithoutSelfReference
    SharedQuery.NoEvidence -> Undecided

queryCompletion :: SearchOutcome -> SharedSearch.Completion
queryCompletion outcome
    | searchExhausted outcome =
        SharedSearch.truncated SharedSearch.ChoicePointLimitReached
    | otherwise = SharedSearch.Finished
