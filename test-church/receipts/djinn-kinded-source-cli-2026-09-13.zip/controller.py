from pathlib import Path
import os,sys,json
ROOT=Path('C:/Djex')
sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as rt
prior=ROOT/'dist-newstyle/lexical-kinds-root-regression-v1/results.json'
old=json.loads(prior.read_text(encoding='utf-8'))
assert old['sources_unchanged'] and old['runtimes_unchanged'] and old['build_exit_code']==0
assert all(r['exit_code']==0 for r in old['tests']) and len(old['tests'])==6
assert 'wall-clock guard' in old['failure']
assert all(rt.sha256(ROOT/p)==h for p,h in old['source_sha256'].items())
assert all(rt.sha256(Path(p))==h for p,h in old['runtime_sha256'].items())
OUT=rt.prepare_output_directory(ROOT/'dist-newstyle/lexical-kinds-root-cli-v1')
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
exe=next(Path(p) for p in old['runtime_sha256'] if Path(p).name=='djex-cli-tests.exe')
env=dict(os.environ,djex_datadir=str(ROOT),PYTHONDONTWRITEBYTECODE='1',TASTY_NUM_THREADS='1')
env['PATH']=os.pathsep.join(old['helper_path_prefix']+[env['PATH']])
report=dict(status='running',scope='Same frozen root source and runtimes; rerun CLI after the 1800-second outer controller guard. Search bounds are unchanged. Verbose test progress replaces --hide-successes.',source_sha256=old['source_sha256'],runtime_sha256=old['runtime_sha256'],prior_receipt_sha256=rt.sha256(prior),helper_path_prefix=old['helper_path_prefix'])
runner=rt.Processes(OUT,7200)
def save():
 report['processes']=runner.rows;rt.write_json(OUT/'results.json',report)
try:
 save()
 result=runner.run('djex-cli-tests',[str(exe),'--color=never','--num-threads=1'],cwd=ROOT,env=env)
 report.update(exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr,status='passed' if result.returncode==0 else 'failed')
 print(result.stdout[-2500:],result.stderr[-1500:],flush=True)
except BaseException as failure:
 report.update(status='failed',failure=repr(failure))
finally:
 report['sources_unchanged']=all(rt.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
 report['runtimes_unchanged']=all(rt.sha256(Path(p))==h for p,h in report['runtime_sha256'].items())
 if not report['sources_unchanged'] or not report['runtimes_unchanged']:report['status']='failed'
 save()
print(report['status'],flush=True)
sys.exit(0 if report['status']=='passed' else 1)
