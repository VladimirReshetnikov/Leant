set_option autoImplicit false
def UniverseReplay.accepted : ∀ A : Type 1, A → A :=
fun _ x => x
theorem UniverseReplay.passes : ULift.down (@UniverseReplay.accepted (ULift.{1,0} Nat) ⟨37⟩) = 37 ∧ ULift.down (@UniverseReplay.accepted (ULift.{1,0} Nat) ⟨53⟩) = 53 := by decide
#print axioms UniverseReplay.accepted
#print axioms UniverseReplay.passes
