from pathlib import Path
from types import SimpleNamespace
import os,sys,json,re,hashlib
ROOT=Path('C:/Leant')
OWNER=Path('C:/Leant-validation/strict-implicit-source')
sys.path[:0]=[str(ROOT/'test-context'),str(ROOT/'test-church'),str(ROOT/'lib/Djex/test-church')]
import run_production as existing
import behavior_partial_probe as pins
rt=existing.runtime
old_path=OWNER/'dist-newstyle/strict-implicit-release-v2/results.json'
old=json.loads(old_path.read_text(encoding='utf-8'))
assert old['status']=='passed' and old['sources_unchanged'] and old['runtimes_unchanged']
assert all(rt.sha256(OWNER/p)==h for p,h in old['source_sha256'].items())
exe=OWNER/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/x/leant/build/leant/leant.exe'
assert rt.sha256(exe)==old['runtime_sha256'][str(exe)]
OUT=rt.prepare_output_directory(ROOT/'dist-newstyle/public-universe-v1')
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
(OUT/'baseline-release-receipt.json').write_bytes(old_path.read_bytes())
specs=[]
for label,level,decls in [('one','1',[]),('parameter','u',['universe u'])]:
    lifted=f'ULift.{{{level},0}} Nat'
    specs += [dict(label='identity_'+label,type=f'∀ A : Type {level}, A → A',declarations=decls,
        oracle='fun A x => x',predicate=f'ULift.down (@{{f}} ({lifted}) ⟨37⟩) = 37 ∧ ULift.down (@{{f}} ({lifted}) ⟨53⟩) = 53'),
        dict(label='callback_'+label,type=f'∀ R : Type, ((∀ A : Type {level}, A → A) → R) → R',declarations=decls,
        oracle='fun R k => k (fun A x => x)',predicate=f'@{{f}} Nat (fun h => ULift.down (h ({lifted}) ⟨37⟩)) = 37 ∧ @{{f}} Nat (fun h => ULift.down (h ({lifted}) ⟨53⟩)) = 53')]
report=dict(status='running',scope='Public Type-1 and named-universe identity/callback baseline; own typed output and exact full-signature kernel replay. Contextual universe evidence remains separate.',source_hashes={str(OWNER/p):h for p,h in old['source_sha256'].items()},specifications=specs,results=[],executable_hashes={})
for path in [Path(__file__),Path(existing.__file__),Path(pins.__file__),Path(rt.__file__),ROOT/'test-church/run_corpus.py']:
    report['source_hashes'][str(path.resolve())]=rt.sha256(path)
kernel_path=existing.default_lean_runtime()
args=SimpleNamespace(leant=exe,lean=str(kernel_path),lean_runtime=kernel_path,backend=None,toolchain='')
leant,backend,lake,report['executable_hashes']=pins.runtime_identity(args,rt,report)
kernel=existing.pin_kernel(Path(report['runtime_identity']['kernel_runtime']))
runner=rt.Processes(OUT,120)
env=dict(os.environ,LEANT_BACKEND=str(backend),LEANT_SYNTH_TIMEOUT='20')
for k in ['LEANT_BACKEND_TRACE','LEANT_BACKEND_TRACE_REQUESTS']:env.pop(k,None)
def stable(mapping):return all(existing.unchanged(p,h) for p,h in mapping.items())
def save():report['processes']=runner.rows;rt.write_json(OUT/'results.json',report)
def kernel_source(label,spec,term):
    name='UniverseReplay.accepted';proof='UniverseReplay.passes'
    text='\n'.join(['set_option autoImplicit false',*spec['declarations'],f'def {name} : {spec["type"]} :=',term,f'theorem {proof} : '+spec['predicate'].replace('{f}',name)+' := by decide',f'#print axioms {name}',f'#print axioms {proof}',''])
    source=existing.saved_source(OUT,label+'.lean',text,[name,proof])
    source.update(existing.kernel_check(runner,label,source,kernel))
    return source
try:
    save()
    for spec in specs:
        spec['oracle_replay']=kernel_source(spec['label']+'-oracle',spec,spec['oracle']);save()
        if spec['oracle_replay']['status']!='passed':continue
        for engine in ['djinn','exference']:
            for mode in ['ordinary','where','false']:
                label='universe_'+spec['label']+'_'+engine+'_'+mode
                predicate='False' if mode=='false' else spec['predicate'].replace('{f}',label)
                command=':synth '+spec['type'] if mode=='ordinary' else f':synth {label} : {spec["type"]} where {predicate}'
                case=dict(name=label,type=spec['type'],command=command,mode='ordinary' if mode=='ordinary' else 'where',engine=engine,operation='universe_'+spec['label'],expected='no_candidate' if mode=='false' else 'candidate')
                source='\n'.join([':set synth-library off',':set synth-providers off',':set synth-classical off',':set synth-debug on',':set synth-ranking balanced',':set synth-shown 1',':set synth-window 60',':set synth-verify 12',':set synth-steps 4096',':set synth-queue 1024',':set synth-budget off',':set synth-djinn-strategy depth-first',':set synth-timeout 20',':set synth-engine '+engine,*spec['declarations'],command,':quit',''])
                row=dict(label=label,engine=engine,mode=mode,status='running',command=command)
                report['results'].append(row);save()
                try:
                    assert stable(report['executable_hashes']),'runtime changed'
                    live=runner.run(label+'-live',[leant,'--plain','--lake',lake],source=source,cwd=ROOT,env=env)
                    assert live.returncode==0,'live process failed'
                    text=live.stdout+live.stderr
                    existing.validate_settings(text.replace('synth budget: off (unbounded)','synth budget: off'),source)
                    block=existing.query_block(text,case)
                    row['live']=existing.candidate_result(block,case)
                    if row['live']['status']=='candidate':
                        term=row['live']['candidate']
                        assert not re.search(r'\b(sorry|admit|unsafe|axiom|native_decide|UniverseReplay)\b',term),'untrusted output'
                        row['owned']=existing.accepted_observation(block,case,term)
                        row['replay']=kernel_source(label+'-replay',spec,term)
                        assert row['replay']['status']=='passed','exact replay failed'
                        if mode=='where':assert row['live']['observations']['inconclusive']==0,'inconclusive positive'
                    row['status']='passed'
                except Exception as failure:row.update(status='failed',failure=repr(failure))
                save();print(label,row['status'],row.get('failure',''),flush=True)
    report['status']='passed' if len(report['results'])==24 and all(r['status']=='passed' for r in report['results']) else 'failed'
except BaseException as failure:report.update(status='failed',failure=repr(failure))
finally:
    report['sources_unchanged']=stable(report['source_hashes'])
    report['runtimes_unchanged']=stable(report['executable_hashes'])
    if not report['sources_unchanged'] or not report['runtimes_unchanged']:report['status']='failed'
    save()
print(report['status'],flush=True)
sys.exit(0 if report['status']=='passed' else 1)
