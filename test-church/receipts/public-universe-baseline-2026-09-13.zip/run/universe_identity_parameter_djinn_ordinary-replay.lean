set_option autoImplicit false
universe u
def UniverseReplay.accepted : ∀ A : Type u, A → A :=
fun _ x => x
theorem UniverseReplay.passes : ULift.down (@UniverseReplay.accepted (ULift.{u,0} Nat) ⟨37⟩) = 37 ∧ ULift.down (@UniverseReplay.accepted (ULift.{u,0} Nat) ⟨53⟩) = 53 := by decide
#print axioms UniverseReplay.accepted
#print axioms UniverseReplay.passes
