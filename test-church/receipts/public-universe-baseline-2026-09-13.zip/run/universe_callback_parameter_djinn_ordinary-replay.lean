set_option autoImplicit false
universe u
def UniverseReplay.accepted : ∀ R : Type, ((∀ A : Type u, A → A) → R) → R :=
fun _ f => f (fun _ x => x)
theorem UniverseReplay.passes : @UniverseReplay.accepted Nat (fun h => ULift.down (h (ULift.{u,0} Nat) ⟨37⟩)) = 37 ∧ @UniverseReplay.accepted Nat (fun h => ULift.down (h (ULift.{u,0} Nat) ⟨53⟩)) = 53 := by decide
#print axioms UniverseReplay.accepted
#print axioms UniverseReplay.passes
