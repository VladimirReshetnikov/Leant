from pathlib import Path
import hashlib,json,zipfile
ROOT=Path('C:/Leant')
CHECKOUT=Path('C:/Leant-validation/trailing-type-witness')
OUT=CHECKOUT/'dist-newstyle/matching-extended-native-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
snapshot=read(OUT/'snapshot.json'); data=read(OUT/'run/results.json')
assert snapshot['status']=='passed'
assert all(snapshot[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged'])
assert data['status']=='passed' and data['candidate_count']==12 and data['false_control_count']==2
assert data['sources_unchanged'] and data['executables_unchanged']
for name,value in snapshot['source_hashes'].items():assert sha(CHECKOUT/name)==value,name
for name,value in snapshot['runtime_hashes'].items():assert sha(Path(name))==value,name
for pins in [data['source_hashes'],data['executable_hashes']]:
 for name,value in pins.items():assert sha(Path(name))==value,name
assert (OUT/'controller.py').read_bytes()==(ROOT/'dist-newstyle/run-matching-extended-native-v1.py').read_bytes()
operations={'fromMaybe':18,'maybeToList':7,'isLeft':10,'either':15,'numeralSuccessor':15,'numeralAdd':75}
expected={(engine,op) for engine in ['djinn','both'] for op in operations}
assert {(r['engine'],r['operation']) for r in data['cells'] if r['operation']!='reject_all'}==expected
assert len(data['cells'])==14
assert all(r['exit_code']==0 and not r['timed_out'] for r in data['processes'])
false={}; empty_inventories=0
for row in data['cells']:
 assert row['status']=='passed'
 observations=row['live_outcome']['observations']
 if row['operation']=='reject_all':
  assert observations['passed']==0 and observations['falsified']>0 and observations['inconclusive']==0
  false[row['engine']]=observations['falsified']
 else:
  assert row['finite_observation_count']==operations[row['operation']]
  assert row['actual_provider_inventory']['count']==0
  replay=row['replay'];assert replay['status']=='passed' and replay['exit_code']==0
  assert replay['kernel_runtime_unchanged'] and replay['source_unchanged']
  assert replay['actual_axiom_inventories']==replay['expected_axiom_inventories']
  assert replay['actual_axiom_inventories']['BehaviorExtendedReplay.candidate']==[]
  assert all(axioms==[] for axioms in replay['actual_axiom_inventories'].values())
  empty_inventories+=len(replay['actual_axiom_inventories'])
oracle=data['oracle_controls'];assert oracle['status']=='passed' and oracle['exit_code']==0
assert oracle['actual_axiom_inventories']==oracle['expected_axiom_inventories']
assert oracle['positive_controls']==13 and oracle['fully_typed_wrong_controls']==14 and oracle['specialized_adapter_controls']==1
(OUT/'packager.py').write_bytes(Path(__file__).read_bytes())
manifest={};omitted={}
for p in sorted(OUT.rglob('*')):
 if not p.is_file():continue
 name=p.relative_to(OUT).as_posix();entry={'sha256':sha(p),'bytes':p.stat().st_size}
 if p.suffix in ['.exe','.o','.hi','.dyn_o','.dyn_hi','.olean','.ilean']:omitted[name]=entry
 else:manifest[name]=entry
archive=ROOT/'test-church/receipts/matching-extended-native-six-2026-09-13.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in manifest:z.write(OUT/name,name)
 z.writestr('archive-manifest.json',json.dumps({'artifacts':manifest,'omitted_build_products':omitted},indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(manifest)|{'archive-manifest.json'}
 for name,expected in manifest.items():
  raw=z.read(name);assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256']
receipt={'schema':'leant-matching-extended-six-v1','status':'passed','scope':'Six extended operations in Lean Djinn and Both, at original fixture settings.',
 'published_renderer_commit':snapshot['published_renderer_commit'],'source_base_commit':snapshot['source_base_commit'],'dependency_commit':snapshot['dependency_commit'],
 'counts':{'accepted_behavior_cells':12,'exact_candidate_replays':12,'actual_false_queries':2,'false_falsifications_by_engine':false,'finite_observations_per_engine':sum(operations.values()),'finite_observations_by_operation':operations,
 'positive_oracle_controls':13,'fully_typed_wrong_oracle_controls':14,'specialized_adapter_controls':1,'empty_candidate_replay_inventories':empty_inventories,'owned_processes':len(data['processes']),'frozen_source_files':len(snapshot['source_hashes'])},
 'settings':data['settings'],'sources_and_runtimes_unchanged':True,'all_owned_processes_exit_zero':True,'raw_receipt_member':'run/results.json',
 'archive':{'path':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'artifact_count':len(manifest),'all_members_rehashed':True},
 'boundaries':['This batch adds finite behavioral acceptance for its twelve operation/mode cells; it is not a current-revision replay of all 160 target cells.', 'The published renderer and tests are checked against the isolated source before execution. No source change or rebuild is claimed in this batch.', 'All exact candidate replay inventories are empty. Oracle controls retain their separately checked declared inventories.', 'Reference implementations and prior synthesized declarations do not enter the live search sessions.', 'Contextual-constructor changes and dependency promotion are outside this acceptance.']}
archive.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2))
