{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, NoPolyKinds #-}
module Main where
probe :: forall (f :: * -> *) a. a -> a
probe = ((\ @f @a -> (let { djexPoly54 :: forall djexSkolem54. forall djexBound0_0. djexBound0_0 -> djexBound0_0; djexPoly54 = (let { djexPoly35 :: forall djexSkolem35. djexSkolem35 -> djexSkolem35; djexPoly35 = (\(a :: djexSkolem35) -> a) } in djexPoly35) } in djexPoly54)) :: forall (f :: * -> *) a . a -> a)
main :: IO ()
main = print (probe @[] (7 :: Int) == 7)
