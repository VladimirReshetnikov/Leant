{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, NoPolyKinds #-}
module Main where
probe :: forall (f :: * -> *) b. ((forall (f :: *) a. a -> a) -> b) -> b
probe = ((\ @f @b -> (let { djexPoly230 :: forall djexSkolem230. forall djexBound0_0. ((forall djexBound1_0 djexBound1_1. djexBound1_1 -> djexBound1_1) -> djexBound0_0) -> djexBound0_0; djexPoly230 = (let { djexPoly189 :: forall djexSkolem189. ((forall djexBound0_0 djexBound0_1. djexBound0_1 -> djexBound0_1) -> djexSkolem189) -> djexSkolem189; djexPoly189 = (\(a :: (forall djexBound0_0 djexBound0_1. djexBound0_1 -> djexBound0_1) -> djexSkolem189) -> ((a) ((let { djexPoly119 :: forall djexSkolem119. forall djexBound0_0. djexBound0_0 -> djexBound0_0; djexPoly119 = (let { djexPoly90 :: forall djexSkolem90. djexSkolem90 -> djexSkolem90; djexPoly90 = (\(b :: djexSkolem90) -> b) } in djexPoly90) } in djexPoly119) :: forall djexBound0_0 djexBound0_1. djexBound0_1 -> djexBound0_1))) } in djexPoly189) } in djexPoly230)) :: forall (f :: * -> *) b . ((forall (f :: *) a . a -> a) -> b) -> b)
main :: IO ()
main = print (probe @[] (\h -> h @Int (7 :: Int)) == 7)
