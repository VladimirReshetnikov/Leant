{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, NoPolyKinds #-}
module Main where
identityOne :: forall (f :: * -> *) a. f a -> f a
identityOne = ((\ @f @a -> (let { djexPoly54 :: forall djexSkolem54. forall djexBound0_0. djexSkolem54 djexBound0_0 -> djexSkolem54 djexBound0_0; djexPoly54 = (let { djexPoly35 :: forall djexSkolem35. djexSkolem54 djexSkolem35 -> djexSkolem54 djexSkolem35; djexPoly35 = (\(a :: djexSkolem54 djexSkolem35) -> a) } in djexPoly35) } in djexPoly54)) :: forall (f :: * -> *) a . f a -> f a)
djinn_identity_named_where :: forall (f :: * -> *) a. f a -> f a
djinn_identity_named_where a = a
callbackOne :: forall b. ((forall (f :: * -> *) a. f a -> f a) -> b) -> b
callbackOne = ((\ @b -> (let { djexPoly170 :: forall djexSkolem170. ((forall djexBound0_0 djexBound0_1. djexBound0_0 djexBound0_1 -> djexBound0_0 djexBound0_1) -> djexSkolem170) -> djexSkolem170; djexPoly170 = (\(a :: (forall djexBound0_0 djexBound0_1. djexBound0_0 djexBound0_1 -> djexBound0_0 djexBound0_1) -> djexSkolem170) -> ((a) ((let { djexPoly104 :: forall djexSkolem104. forall djexBound0_0. djexSkolem104 djexBound0_0 -> djexSkolem104 djexBound0_0; djexPoly104 = (let { djexPoly77 :: forall djexSkolem77. djexSkolem104 djexSkolem77 -> djexSkolem104 djexSkolem77; djexPoly77 = (\(b :: djexSkolem104 djexSkolem77) -> b) } in djexPoly77) } in djexPoly104) :: forall djexBound0_0 djexBound0_1. djexBound0_0 djexBound0_1 -> djexBound0_0 djexBound0_1))) } in djexPoly170)) :: forall b . ((forall (f :: * -> *) a . f a -> f a) -> b) -> b)
djinn_callback_named_where :: forall b. ((forall (f :: * -> *) a. f a -> f a) -> b) -> b
djinn_callback_named_where a = a (\b -> b)
main :: IO ()
main = print [identityOne [1,2::Int] == [1,2], identityOne (Just True) == Just True, djinn_identity_named_where [1,2::Int] == [1,2], djinn_identity_named_where (Just True) == Just True, callbackOne (\h -> length (h [1,2,3::Int])) == 3, callbackOne (\h -> h (Just (7::Int))) == Just 7, djinn_callback_named_where (\h -> length (h [1,2,3::Int])) == 3, djinn_callback_named_where (\h -> h (Just (7::Int))) == Just 7]
