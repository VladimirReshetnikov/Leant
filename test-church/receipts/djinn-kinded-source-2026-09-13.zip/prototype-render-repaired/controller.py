from pathlib import Path
import json,os,subprocess,sys,re
ROOT=Path('C:/Djex-validation/public-kinded-source')
assert Path.cwd()==ROOT
sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as runtime
OUT=runtime.prepare_output_directory(ROOT/'dist-newstyle/lexical-kinds-public-v3')
empty=OUT/'empty-environment';empty.mkdir()
paths=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard']).decode().split('\0')
paths=sorted({p for p in paths if p and (ROOT/p).is_file() and Path(p).suffix in ['.hs','.cabal']})
exe=Path(subprocess.check_output(['cabal','list-bin','djex:exe:djex']).decode().strip())
previous=dict(source_sha256={p:runtime.sha256(ROOT/p) for p in paths},runtime_sha256={str(exe):runtime.sha256(exe)})
for p in paths:
 dest=OUT/'source'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((ROOT/p).read_bytes())
report=dict(status='running',scope='Discriminating public lexical kind probes; per-case exact emitted expression replay.',source_sha256=previous['source_sha256'],runtime_sha256=previous['runtime_sha256'],queries=[])
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
runner=runtime.Processes(OUT,60)
env=dict(os.environ,djex_datadir=str(ROOT),PYTHONDONTWRITEBYTECODE='1')
cases=[
 ('vacuous_root','forall (f :: * -> *) a. a -> a','probe @[] (7 :: Int) == 7'),
 ('vacuous_local','forall a. (forall (f :: * -> *). a) -> a','probe @Int (7 :: forall (f :: * -> *). Int) == 7'),
 ('vacuous_callback','forall b. ((forall (f :: * -> *) a. a -> a) -> b) -> b','probe (\\h -> h @[] (7 :: Int)) == 7'),
 ('shadowed_callback','forall (f :: * -> *) b. ((forall (f :: *) a. a -> a) -> b) -> b','probe @[] (\\h -> h @Int (7 :: Int)) == 7'),
 ('vacuous_result','forall a. a -> (forall (f :: * -> *). a)','probe @Int 7 @[] == 7'),
 ('adjacent_kinds','forall a. (forall (f :: * -> *). a) -> (forall (f :: *). a) -> (a,a)','probe @Int (7 :: forall (f :: * -> *). Int) (7 :: forall (f :: *). Int) == (7,7)'),
]
header='{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, NoPolyKinds #-}\nmodule Main where\n'
def save():
 report['processes']=runner.rows;runtime.write_json(OUT/'results.json',report)
try:
 save()
 for label,sig,observation in cases:
  row=dict(label=label,signature=sig,observation=observation);report['queries'].append(row)
  result=runner.run(label,[str(exe),'djinn','--environment',str(empty),'--render','expression','--select','first',sig],cwd=ROOT,env=env)
  row.update(exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr);save()
  print(label,'synthesis',result.returncode,result.stderr[-500:],flush=True)
  if result.returncode==0 and result.stdout.strip():
   fixture=OUT/(label+'.hs');fixture.write_text(header+'probe :: '+sig+'\nprobe = '+result.stdout.strip()+'\nmain :: IO ()\nmain = print ('+observation+')\n',encoding='utf-8')
   binary=OUT/(label+'.exe')
   compiled=runner.run(label+'-ghc',['ghc','-fforce-recomp',str(fixture),'-odir',str(OUT),'-hidir',str(OUT),'-o',str(binary)],cwd=ROOT,env=env)
   row['compile_exit_code']=compiled.returncode
   if compiled.returncode==0:
    replay=runner.run(label+'-replay',[str(binary)],cwd=ROOT,env=env)
    row.update(replay_exit_code=replay.returncode,replay_output=replay.stdout)
   else: row['compiler_error']=compiled.stderr
   save();print(label,'GHC',compiled.returncode,compiled.stderr[-1500:],flush=True)
 report['status']='completed'
except BaseException as failure:report['status']='failed';report['failure']=repr(failure)
finally:
 report['sources_unchanged']=all(runtime.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
 report['runtimes_unchanged']=all(runtime.sha256(Path(p))==h for p,h in report['runtime_sha256'].items())
 save()
print([(r['label'],r.get('exit_code'),r.get('compile_exit_code'),r.get('replay_output')) for r in report['queries']],flush=True)
