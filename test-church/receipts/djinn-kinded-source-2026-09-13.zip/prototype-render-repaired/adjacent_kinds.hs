{-# LANGUAGE RankNTypes, ImpredicativeTypes, KindSignatures, ScopedTypeVariables, TypeApplications, TypeAbstractions, NoPolyKinds #-}
module Main where
probe :: forall a. (forall (f :: * -> *). a) -> (forall (f :: *). a) -> (a,a)
probe = ((\ @a -> (let { djexPoly152 :: forall (djexSkolem152 :: *). (forall (djexBound0_0 :: (*) -> *). djexSkolem152) -> (forall (djexBound0_0 :: *). djexSkolem152) -> (djexSkolem152, djexSkolem152); djexPoly152 = (\(a :: forall (djexBound0_0 :: (*) -> *). djexSkolem152) (_ :: forall (djexBound0_0 :: *). djexSkolem152) -> (((a :: forall (djexBound0_0 :: (*) -> *). djexSkolem152) @(([]))), ((a :: forall (djexBound0_0 :: (*) -> *). djexSkolem152) @(([]))))) } in djexPoly152)) :: forall a .   (forall (f :: * -> *) . a) -> (forall (f :: *) . a) -> (a, a))
main :: IO ()
main = print (probe @Int (7 :: forall (f :: * -> *). Int) (7 :: forall (f :: *). Int) == (7,7))
