from pathlib import Path
import json,os,subprocess,sys
ROOT=Path('C:/Djex-validation/public-kinded-source')
assert Path.cwd()==ROOT
sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as runtime
OUT=runtime.prepare_output_directory(ROOT/'dist-newstyle/lexical-kinds-public-v1')
empty=OUT/'empty-environment';empty.mkdir()
previous=json.loads((ROOT/'dist-newstyle/source-kind-requests-v2/results.json').read_bytes())
paths=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard']).decode().split('\0')
paths=sorted({p for p in paths if p and (ROOT/p).is_file() and Path(p).suffix in ['.hs','.cabal']})
report=dict(status='running',scope='Original public kinded-source queries after Djinn lexical kind integration; exact replay is a separate gate.',source_sha256={p:runtime.sha256(ROOT/p) for p in paths},queries=[])
for p in paths:
 out=OUT/'source'/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((ROOT/p).read_bytes())
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
exe=Path(subprocess.check_output(['cabal','list-bin','djex:exe:djex']).decode().strip())
report['runtime_sha256']={str(exe):runtime.sha256(exe)}
runner=runtime.Processes(OUT,120)
env=dict(os.environ,djex_datadir=str(ROOT),PYTHONDONTWRITEBYTECODE='1')
def save():
 report['processes']=runner.rows;runtime.write_json(OUT/'results.json',report)
try:
 save()
 for row in previous['processes']:
  label=row.get('label','')
  if not label.startswith('djinn_'):continue
  command=row['command'][:];command[0]=str(exe)
  position=command.index('--environment')+1;command[position]=str(empty)
  source=Path(row['input_path']).read_text(encoding='utf-8') if 'input_path' in row else None
  result=runner.run(label,command,source=source,cwd=ROOT,env=env)
  report['queries'].append(dict(label=label,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr))
  save()
  if source:
   lines=source.splitlines()
   lines=[line.split(' where ')[0]+' where Prelude.False' if line.startswith(':synth ') else line for line in lines]
   result=runner.run(label+'-false',command,source='\n'.join(lines)+'\n',cwd=ROOT,env=env)
   report['queries'].append(dict(label=label+'-false',exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr));save()
 report['status']='completed'
except BaseException as failure:report['status']='failed';report['failure']=repr(failure)
finally:
 report['sources_unchanged']=all(runtime.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
 report['runtimes_unchanged']=all(runtime.sha256(Path(p))==h for p,h in report['runtime_sha256'].items())
 save()
for query in report['queries']:print(query['label'],query['exit_code'],query['stdout'][-1600:],query['stderr'][-1600:],flush=True)
