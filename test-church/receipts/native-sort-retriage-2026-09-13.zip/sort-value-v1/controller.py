from pathlib import Path
import json, os, subprocess, sys
ROOT=Path('C:/Leant-validation/product-integration')
sys.path.insert(0,str(ROOT/'lib/Djex/test-church'))
import behavior_runtime as rt
PIN='eea33f2464ea5424cd4e74557d0b5368829a8cd8'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT/'lib/Djex',text=True).strip()==PIN
baseline=ROOT/'dist-newstyle/product-native-baseline-v1/results.json'
old=json.loads(baseline.read_text(encoding='utf-8'))
assert old['status']=='failed' and old['sources_unchanged'] and old['runtimes_unchanged']
assert [row['status'] for row in old['results']]==['passed','failed','passed']
OUT=rt.prepare_output_directory(ROOT/'dist-newstyle/sort-value-v1')
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
files=[Path(__file__),ROOT/'test-context/run_products.py',ROOT/'test-unit/SortSourceSpec.hs']
for base in [ROOT,ROOT/'lib/Djex']:
    names=subprocess.check_output(['git','ls-files','-z'],cwd=base).decode().split('\0')
    files += [base/p for p in names if p.endswith(('.hs','.cabal','.lean','.py')) and (base/p).is_file()]
source={}
for path in files:
    key=path.relative_to(ROOT).as_posix(); source[key]=rt.sha256(path)
    target=OUT/'source'/key;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(path.read_bytes())
report=dict(status='running',scope='Structured source sort values, native product public gates and full native units on the published product dependency.',djex_pin=PIN,source_sha256=source,runtime_sha256={},gates=[],baseline_receipt_sha256=rt.sha256(baseline))
runner=rt.Processes(OUT,1800)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',leant_datadir=str(ROOT),djex_datadir=str(ROOT/'lib/Djex'))
def save():report['processes']=runner.rows;rt.write_json(OUT/'results.json',report)
try:
    save()
    build=runner.run('strict-build',['cabal','build','leant:exe:leant','leant:test:leant-synth-tests','--ghc-options=-Werror','-j1'],cwd=ROOT,env=env)
    report['gates'].append(dict(label='strict-build',exit_code=build.returncode));save()
    assert build.returncode==0,'strict native build failed'
    bins={}
    for target in ['leant:exe:leant','leant:test:leant-synth-tests','djex:exe:djex-fake-z3']:
        binary=Path(subprocess.check_output(['cabal','list-bin',target],cwd=ROOT).decode().strip())
        assert binary.is_file();bins[target]=binary;report['runtime_sha256'][str(binary)]=rt.sha256(binary)
    env['PATH']=str(bins['djex:exe:djex-fake-z3'].parent)+os.pathsep+env['PATH'];save()
    probe=runner.run('public-products',[sys.executable,'-X','utf8','-B','test-context/run_products.py','--leant',str(bins['leant:exe:leant']),'--engine','djinn','--output',str(OUT/'public-products')],cwd=ROOT,env=env)
    report['gates'].append(dict(label='public-products',exit_code=probe.returncode));save()
    print(probe.stdout[-3000:],probe.stderr[-1000:],flush=True)
    assert probe.returncode==0,'native product public gate failed'
    unit=runner.run('full-native-units',[str(bins['leant:test:leant-synth-tests']),'--num-threads','1'],cwd=ROOT,env=env)
    report['gates'].append(dict(label='full-native-units',exit_code=unit.returncode));save()
    assert unit.returncode==0 and 'All 724 tests passed' in unit.stdout,'native units failed or inventory changed'
    report['status']='passed'
except BaseException as failure:report.update(status='failed',failure=repr(failure))
finally:
    report['sources_unchanged']=all(rt.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
    report['runtimes_unchanged']=all(rt.sha256(Path(p))==h for p,h in report['runtime_sha256'].items())
    if not report['sources_unchanged'] or not report['runtimes_unchanged']:report['status']='failed'
    save()
print(report['status'],report.get('failure',''),flush=True)
sys.exit(0 if report['status']=='passed' else 1)

