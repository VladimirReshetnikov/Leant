set_option autoImplicit false
def ProductReplay.accepted : ∀ A : Type, (∀ F : Type → Type, A) → (∀ F : Type, A) → A × A :=
fun _ _ f => ⟨f _root_.PUnit.{(0 + 1)}, f _root_.PUnit.{(0 + 1)}⟩
theorem ProductReplay.passes : @ProductReplay.accepted Nat (fun _ => 7) (fun _ => 7) = (7,7) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
