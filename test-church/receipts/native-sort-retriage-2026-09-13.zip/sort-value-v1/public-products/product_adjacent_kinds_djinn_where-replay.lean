set_option autoImplicit false
def ProductReplay.accepted : ∀ A : Type, (∀ F : Type → Type, A) → (∀ F : Type, A) → A × A :=
fun _ f g => ⟨f (fun x => x), g _root_.PUnit.{(0 + 1)}⟩
theorem ProductReplay.passes : @ProductReplay.accepted Nat (fun _ => 7) (fun _ => 9) = (7,9) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
