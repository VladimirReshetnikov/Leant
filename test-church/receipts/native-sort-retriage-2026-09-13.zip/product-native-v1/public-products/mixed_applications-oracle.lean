set_option autoImplicit false
def ProductReplay.accepted : ∀ A B : Type, (A → B) → A → A → B × B :=
fun A B convert left right => (convert left, convert right)
theorem ProductReplay.passes : @ProductReplay.accepted Nat Nat (fun x => x + 1) 7 9 = (8,10) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
