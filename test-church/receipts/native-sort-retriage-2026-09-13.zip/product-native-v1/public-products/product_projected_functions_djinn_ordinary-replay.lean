set_option autoImplicit false
def ProductReplay.accepted : ∀ A B : Type, ((A → B) × (A → B)) → A → B × B :=
fun _ _ ⟨f, g⟩ x => ⟨f x, g x⟩
theorem ProductReplay.passes : @ProductReplay.accepted Nat Nat ((fun x => x + 1), (fun x => x + 1)) 3 = (4,4) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
