set_option autoImplicit false
def ProductReplay.accepted : ∀ A B : Type, ((A → B) × (A → B)) → A → B × B :=
fun A B functions value => (functions.1 value, functions.2 value)
theorem ProductReplay.passes : @ProductReplay.accepted Nat Nat ((fun x => x + 1), (fun x => x * 2)) 3 = (4,6) ∧ @ProductReplay.accepted Nat Nat ((fun x => x + 1), (fun x => x * 2)) 5 = (6,10) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
