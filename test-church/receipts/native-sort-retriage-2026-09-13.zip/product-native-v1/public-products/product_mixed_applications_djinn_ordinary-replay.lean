set_option autoImplicit false
def ProductReplay.accepted : ∀ A B : Type, (A → B) → A → A → B × B :=
fun _ _ f x y => ⟨f x, f y⟩
theorem ProductReplay.passes : @ProductReplay.accepted Nat Nat (fun x => x + 1) 7 7 = (8,8) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
