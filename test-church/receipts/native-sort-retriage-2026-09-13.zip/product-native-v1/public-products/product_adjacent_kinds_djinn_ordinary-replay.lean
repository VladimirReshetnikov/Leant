set_option autoImplicit false
def ProductReplay.accepted : ∀ A : Type, (∀ F : Type → Type, A) → (∀ F : Type, A) → A × A :=
fun _ f _ => ⟨f (fun x => x), f (fun y => y)⟩
theorem ProductReplay.passes : @ProductReplay.accepted Nat (fun _ => 7) (fun _ => 7) = (7,7) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
