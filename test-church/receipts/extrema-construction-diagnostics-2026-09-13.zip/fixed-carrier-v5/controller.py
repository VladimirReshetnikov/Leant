from pathlib import Path
import json, os, subprocess, sys
ROOT = Path('C:/Djex-validation/public-kinded-source')
assert Path.cwd() == ROOT
baseline = Path('C:/Leant/dist-newstyle/extrema-baseline-v2/results.json')
audit = json.loads(baseline.with_name('INTERRUPTION.json').read_text())
assert audit['status'] == 'interrupted_controller_and_child_verified_absent' and audit['sources_unchanged'] and audit['runtimes_unchanged']
sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as runtime
OUT = runtime.prepare_output_directory(ROOT/'dist-newstyle/extrema-fixed-carrier-v5')
paths = subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=ROOT).decode().split('\0')
paths = sorted({p for p in paths if p and (ROOT/p).is_file() and Path(p).suffix in {'.hs','.cabal'}})
report = dict(status='running',scope='Diagnostic for maximumBy at a fixed a -> a list carrier and a comparator result. No public synthesis acceptance.',
    source_base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    source_sha256={p:runtime.sha256(ROOT/p) for p in paths},baseline_sha256=runtime.sha256(baseline),gates=[])
for p in paths:
    target=OUT/'source'/p
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes((ROOT/p).read_bytes())
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
runner=runtime.Processes(OUT,1200)
env=dict(os.environ,djex_datadir=str(ROOT),PYTHONDONTWRITEBYTECODE='1')
def save():
    report['processes']=runner.rows
    runtime.write_json(OUT/'results.json',report)
try:
    save()
    result=runner.run('strict-build',['cabal','build','djex:test:djinn-tests','--ghc-options=-Werror','-j1'],cwd=ROOT,env=env)
    report['build_exit_code']=result.returncode
    save()
    assert result.returncode==0,'strict build failed'
    binary=Path(subprocess.check_output(['cabal','list-bin','djex:test:djinn-tests'],cwd=ROOT).decode().strip())
    report['runtime_sha256']={str(binary):runtime.sha256(binary)}
    runner.timeout=180
    result=runner.run('fixed-carrier-construction',[str(binary),'-p','diagnose extrema','--timeout','120s','--num-threads','1'],cwd=ROOT,env=env)
    report['gates'].append(dict(name='fixed-carrier-construction',exit_code=result.returncode,output=result.stdout))
except BaseException as failure:
    report['failure']=repr(failure)
finally:
    report['sources_unchanged']=all(runtime.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
    report['runtimes_unchanged']=all(runtime.sha256(Path(p))==h for p,h in report.get('runtime_sha256',{}).items())
    report['controller_unchanged']=(OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
    report['status']='completed' if len(report['gates'])==1 and all(report[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged']) else 'failed'
    save()
print(json.dumps({k:report.get(k) for k in ['status','build_exit_code','gates','failure']},indent=2),flush=True)
raise SystemExit(0 if report['status']=='completed' else 1)
