from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path('C:/Leant'); OTHER=Path('C:/Djex'); D=ROOT/'dist-newstyle'
sha=lambda b:hashlib.sha256(b).hexdigest()
folders=['priority3-native-int-at-baseline-v1','priority3-int-provider-admission-v1','priority3-int-provider-admission-v2','priority3-session-provider-names-v1','priority3-declaration-regression-v1']
reports={f:json.loads((D/f/'results.json').read_text()) for f in folders}
assert reports[folders[-1]]['status']=='passed'
assert reports[folders[-2]]['status']=='passed'
assert all(r['status']!='running' for r in reports.values())
for key in ('sources_unchanged','runtimes_unchanged'):assert reports[folders[-1]][key]
for p,h in reports[folders[-1]]['source_sha256'].items():assert sha((ROOT/p).read_bytes())==h,p
for p,h in reports[folders[-1]]['runtime_sha256'].items():assert sha(Path(p).read_bytes())==h,p
members={}
def put(name,data):
    assert name not in members,name
    members[name]=data
for folder in folders:
    for p in sorted((D/folder).rglob('*')):
        if p.is_file() and p.suffix.lower() not in ('.exe','.dll','.o','.hi','.pyc'):
            put('runs/'+folder+'/'+p.relative_to(D/folder).as_posix(),p.read_bytes())
# Restore the exact pre-repair source cited by the original baseline.
for name,digest in reports[folders[0]]['source_hashes'].items():
    p=Path(name)
    if p.is_relative_to(D/folders[0]):continue
    data=p.read_bytes()
    if sha(data)!=digest:
        assert p.is_relative_to(ROOT),name
        data=subprocess.check_output(['git','show','fba867128a920106fd4d5b3bdfc3cdc9810b0cad:'+p.relative_to(ROOT).as_posix()],cwd=ROOT)
    assert sha(data)==digest,name
    if p.is_relative_to(ROOT):archive='Leant/'+p.relative_to(ROOT).as_posix()
    elif p.is_relative_to(OTHER):archive='Djex/'+p.relative_to(OTHER).as_posix()
    else:archive='external-backend/'+p.name
    put('baseline-source/'+archive,data)
put('baseline-source/Leant/src/Leant/Synth/Replay.hs',subprocess.check_output(['git','show','fba867128a920106fd4d5b3bdfc3cdc9810b0cad:src/Leant/Synth/Replay.hs'],cwd=ROOT))
for name in ['probe-int-provider-admission.py','probe-int-provider-metadata.py','run-provider-declaration-regression.py','priority3-declarations-build-v2.log','priority3-declaration-metadata-v3.json.txt']:
    put('controllers-and-diagnostics/'+name,(D/name).read_bytes())
put('controllers-and-diagnostics/package-session-provider-identity.py',Path(__file__).read_bytes())
base='session-provider-identity-2026-09-14'
path=ROOT/'test-church/receipts'/f'{base}.zip'
assert not path.exists(),path
with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):z.writestr(name,data)
with zipfile.ZipFile(path) as z:
    assert len(z.namelist())==len(members)
    for name,data in members.items():assert z.read(name)==data,name
index=dict(scope='Qualified native session provider identity accepted; original Int indexing remains unsuccessful and scheduler admission remains open.',archive=path.name,archive_sha256=sha(path.read_bytes()),archive_bytes=path.stat().st_size,member_count=len(members),runs=[dict(directory=f,status=reports[f]['status'],receipt_sha256=sha((D/f/'results.json').read_bytes())) for f in folders],acceptance=dict(native_tests=768,public_inventory_sessions=6,literal_false_queries=9,indexing_candidates_accepted=0),members=[dict(path=n,sha256=sha(b),bytes=len(b)) for n,b in sorted(members.items())])
for root in [ROOT,OTHER]:
    target=root/'test-church/receipts'/path.name
    if root!=ROOT:
        assert not target.exists(),target
        target.write_bytes(path.read_bytes())
    destination=target.with_suffix('.json');assert not destination.exists(),destination
    destination.write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
print({k:index[k] for k in ['archive_sha256','archive_bytes','member_count']})
