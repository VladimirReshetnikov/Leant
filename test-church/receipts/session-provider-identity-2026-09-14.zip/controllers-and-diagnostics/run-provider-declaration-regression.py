from pathlib import Path
import json, os, re, sys, shutil, subprocess
ROOT=Path('C:/Leant')
sys.path.insert(0,str(ROOT/'lib/Djex/test-church'))
import behavior_runtime as rt
out=rt.prepare_output_directory(ROOT/'dist-newstyle/priority3-declaration-regression-v1')
runner=rt.Processes(out,2400)
tracked=subprocess.check_output(['git','ls-files','--recurse-submodules'],cwd=ROOT).decode().splitlines()
paths={ROOT/p for p in tracked if Path(p).suffix in ('.hs','.cabal') or p in ('cabal.project',)}
paths.update([Path(__file__),ROOT/'test-context/run_session_provider_names.py',Path(rt.__file__)])
sources={str(p.relative_to(ROOT)):rt.sha256(p) for p in sorted(paths)}
for p in paths:
    dest=out/'source'/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
report=dict(status='running',scope='Strict native build and all 768 native unit tests for qualified provider replay metadata.',source_sha256=sources)
def save():
    report['processes']=runner.rows;rt.write_json(out/'results.json',report)
def resolve(component):
    return Path(subprocess.check_output(['cabal','list-bin',component],cwd=ROOT).decode().strip())
try:
    save()
    built=runner.run('strict-build',['cabal','build','leant:exe:leant','leant:test:leant-synth-tests','--ghc-options=-Werror','-j1'],cwd=ROOT)
    assert built.returncode==0,'strict build failed'
    exe=resolve('leant:test:leant-synth-tests');leant=resolve('leant:exe:leant');fake=resolve('djex:exe:djex-fake-z3')
    report['runtime_sha256']={str(p):rt.sha256(p) for p in (exe,leant,fake)}
    env={k:v for k,v in os.environ.items() if not k.upper().startswith('TASTY_')}
    env.update(PYTHONDONTWRITEBYTECODE='1',leant_datadir=str(ROOT),djex_datadir=str(ROOT/'lib/Djex'))
    env['PATH']=str(fake.parent)+os.pathsep+env['PATH']
    assert Path(shutil.which('djex-fake-z3',path=env['PATH'])).resolve()==fake.resolve()
    report['fake_solver_path']=str(fake)
    listing=runner.run('inventory',[exe,'--list-tests'],cwd=ROOT,env=env)
    assert listing.returncode==0
    report['inventory']=listing.stdout.splitlines();report['test_count']=len(report['inventory'])
    assert report['test_count']==768,report['test_count']
    save()
    tested=runner.run('full-native',[exe,'--num-threads','1'],cwd=ROOT,env=env)
    assert tested.returncode==0 and re.findall(r'All (\d+) tests passed',tested.stdout)==['768'],'full native failure'
    report['status']='passed'
except BaseException as error:
    report.update(status='failed',failure=repr(error))
finally:
    report['sources_unchanged']=all(rt.sha256(ROOT/p)==h for p,h in sources.items())
    report['runtimes_unchanged']=all(rt.sha256(Path(p))==h for p,h in report.get('runtime_sha256',{}).items())
    if not report['sources_unchanged'] or not report['runtimes_unchanged']:report['status']='failed'
    save()
print(report['status'],report.get('failure',''),flush=True)
sys.exit(0 if report['status']=='passed' else 1)
