"""Diagnostic only: admit providers after one checked structural candidate.

The unchanged public at input is read from the baseline. Only synth-verify
changes from 65536 to 1; the signature, 168 observations, provider, search
window, steps, choice budget and deadline remain exact. This is not acceptance
at the original verification allowance and does not build or edit product code.
"""
from pathlib import Path
import json
import os
import sys

ROOT = Path('C:/Leant')
sys.path.insert(0, 'C:/Djex/test-church')
import behavior_runtime as rt

baseline = ROOT / 'dist-newstyle/priority3-native-int-at-baseline-v1'
receipt = json.loads((baseline / 'results.json').read_text())
assert receipt['status'] != 'running', 'Finish the original baseline first'
out = rt.prepare_output_directory(ROOT / 'dist-newstyle/priority3-int-provider-admission-v2')
pins = receipt['runtime_identity']
original = (baseline / 'partial_exference_at.txt').read_text(encoding='utf-8')
assert original.count(':set synth-verify 65536\n') == 1
source = original.replace(':set synth-verify 65536\n', ':set synth-verify 1\n', 1)
assert source.replace(':set synth-verify 1\n', ':set synth-verify 65536\n', 1) == original
(out / 'original.txt').write_text(original, encoding='utf-8')
(out / 'diagnostic.txt').write_text(source, encoding='utf-8')
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
hashes = dict(receipt['executable_hashes'])
hashes[pins['leant']] = rt.sha256(Path(pins['leant']))
source_paths = list((ROOT / 'src').rglob('*.hs'))
source_hashes = {str(p): rt.sha256(p) for p in source_paths}
for path in source_paths:
    saved = out / 'source' / path.relative_to(ROOT)
    saved.parent.mkdir(parents=True, exist_ok=True)
    saved.write_bytes(path.read_bytes())
def stable():
    return all(rt.sha256(Path(path)) == expected for path, expected in hashes.items())
assert stable(), 'Pinned baseline runtime changed'
runner = rt.Processes(out, 900)
report = dict(status='running', scope=__doc__, baseline_receipt_sha256=rt.sha256(baseline / 'results.json'),
              original_source_sha256=rt.sha256(out / 'original.txt'),
              diagnostic_source_sha256=rt.sha256(out / 'diagnostic.txt'),
              executable_hashes=hashes, runtime_identity=pins,
              acceptance_at_original_limits=False, source_hashes=source_hashes,
              change_under_test='Qualified declaration metadata from successful synthesis replay')
def save():
    report['processes'] = runner.rows
    rt.write_json(out / 'results.json', report)
try:
    save()
    result = runner.run('provider-admission',
        [pins['leant'], '--plain', '--lake', pins['backend_lake_runtime']],
        source=source, cwd=ROOT,
        env=dict(os.environ, LEANT_BACKEND=pins['backend'], LEANT_SYNTH_TIMEOUT='90',
                 PYTHONDONTWRITEBYTECODE='1'))
    transcript = result.stdout + result.stderr
    report['provider_lines'] = [line for line in transcript.splitlines()
                                if line.startswith('debug provider: ')]
    report['behavioral_summaries'] = [line for line in transcript.splitlines()
                                     if line.startswith('supplied behavioral assertion:')]
    report['exit_code'] = result.returncode
    report['status'] = 'completed' if result.returncode == 0 else 'failed'
except BaseException as error:
    report.update(status='failed', failure=repr(error))
finally:
    report['sources_unchanged'] = all(rt.sha256(Path(p)) == h for p, h in source_hashes.items())
    report['runtimes_unchanged'] = stable()
    if not report['runtimes_unchanged'] or not report['sources_unchanged']:
        report['status'] = 'failed'
    save()
print(report['status'], 'providers=', len(report.get('provider_lines', [])), flush=True)
sys.exit(0 if report['status'] == 'completed' else 1)
