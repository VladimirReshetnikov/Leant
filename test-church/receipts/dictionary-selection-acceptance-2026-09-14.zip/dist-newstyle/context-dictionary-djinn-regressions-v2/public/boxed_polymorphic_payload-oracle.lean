set_option autoImplicit false
class SelectedPoly.Dictionary (α : Type) where tag : Nat
structure SelectedPoly.Box (α : Type 1) where value : α
universe u
structure SelectedPoly.GenericBox (α : Type u) where value : α
def ProductReplay.accepted : ∀ A : Type, [SelectedPoly.Dictionary A] → (∀ β : Type, β → Nat) → SelectedPoly.Box (∀ β : Type, β → Nat) :=
fun (A : Type) [d : SelectedPoly.Dictionary A] payload => ⟨payload⟩
theorem ProductReplay.passes : (@ProductReplay.accepted Nat (@SelectedPoly.Dictionary.mk Nat 7) (fun _ _ => 37)).value Bool true = 37 ∧ (@ProductReplay.accepted Nat (@SelectedPoly.Dictionary.mk Nat 11) (fun _ _ => 53)).value Unit () = 53 := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
