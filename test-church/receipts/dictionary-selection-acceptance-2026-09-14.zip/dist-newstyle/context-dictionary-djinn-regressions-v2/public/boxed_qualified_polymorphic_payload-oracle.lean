set_option autoImplicit false
class SelectedPoly.Dictionary (α : Type) where tag : Nat
structure SelectedPoly.Box (α : Type 1) where value : α
universe u
structure SelectedPoly.GenericBox (α : Type u) where value : α
def ProductReplay.accepted : ∀ A : Type, [SelectedPoly.Dictionary A] → (∀ β : Type, [SelectedPoly.Dictionary β] → β → Nat) → SelectedPoly.Box (∀ β : Type, [SelectedPoly.Dictionary β] → β → Nat) :=
fun (A : Type) [d : SelectedPoly.Dictionary A] payload => ⟨payload⟩
theorem ProductReplay.passes : let result := (@ProductReplay.accepted Nat (@SelectedPoly.Dictionary.mk Nat 7) (fun (β : Type) [d : SelectedPoly.Dictionary β] _ => d.tag)).value; @result Bool (@SelectedPoly.Dictionary.mk Bool 37) true = 37 ∧ @result Unit (@SelectedPoly.Dictionary.mk Unit 53) () = 53 := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
