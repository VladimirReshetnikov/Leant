set_option autoImplicit false
class SelectedPoly.Dictionary (α : Type) where tag : Nat
structure SelectedPoly.Box (α : Type 1) where value : α
universe u
structure SelectedPoly.GenericBox (α : Type u) where value : α
def ProductReplay.accepted : ∀ A : Type, [SelectedPoly.Dictionary A] → ∀ β : Type 1, β → SelectedPoly.GenericBox.{1} β :=
((fun (leantType170 : Type) => (fun [leantGiven2x0 : @_root_.«SelectedPoly».«Dictionary» (leantType170)] => (fun (leantType119 : Type (0 + 1)) => (fun (leantLocal9 : leantType119) => @(let leantHead77 : (leantType119 → (@_root_.«SelectedPoly».«GenericBox».{(0 + 1)} (leantType119))) := @(let leantHead44 : (∀ {leantBound0x0 : Type (0 + 1)}, (leantBound0x0 → (@_root_.«SelectedPoly».«GenericBox».{(0 + 1)} (leantBound0x0)))) := @_root_.«SelectedPoly».«GenericBox».«mk».{(0 + 1)}; @leantHead44 (leantType119)); @leantHead77 (@leantLocal9 : leantType119)))))) : (∀ (leantBound0x0 : Type) [@_root_.«SelectedPoly».«Dictionary» (leantBound0x0)], (∀ (leantBound1x0 : Type (0 + 1)), (leantBound1x0 → (@_root_.«SelectedPoly».«GenericBox».{(0 + 1)} (leantBound1x0))))))
theorem ProductReplay.passes : (@ProductReplay.accepted Nat (@SelectedPoly.Dictionary.mk Nat 7) (ULift.{1} Nat) ⟨37⟩).value.down = 37 ∧ (@ProductReplay.accepted Nat (@SelectedPoly.Dictionary.mk Nat 11) (ULift.{1} Nat) ⟨53⟩).value.down = 53 := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
