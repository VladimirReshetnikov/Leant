set_option autoImplicit false
class SelectedPoly.Dictionary (α : Type) where tag : Nat
structure SelectedPoly.Box (α : Type 1) where value : α
universe u
structure SelectedPoly.GenericBox (α : Type u) where value : α
inductive SelectedPoly.Pair (α : Type 1) (β : Type) where | mk : α → β → SelectedPoly.Pair α β
def ProductReplay.accepted : ∀ A : Type, [SelectedPoly.Dictionary A] → ∀ Z : Type, (∀ β : Type, β → Nat) → Z → SelectedPoly.Pair (∀ β : Type, β → Nat) Z :=
fun (A : Type) [d : SelectedPoly.Dictionary A] (Z : Type) payload value => SelectedPoly.Pair.mk payload value
theorem ProductReplay.passes : match @ProductReplay.accepted Nat (@SelectedPoly.Dictionary.mk Nat 7) Nat (fun _ _ => 37) 53 with | .mk payload value => payload Bool true = 37 ∧ value = 53 := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
