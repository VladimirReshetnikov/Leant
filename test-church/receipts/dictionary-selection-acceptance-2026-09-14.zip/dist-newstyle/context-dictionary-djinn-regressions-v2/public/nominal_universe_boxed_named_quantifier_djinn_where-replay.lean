set_option autoImplicit false
class SelectedPoly.Dictionary (α : Type) where tag : Nat
structure SelectedPoly.Box (α : Type 1) where value : α
universe u
structure SelectedPoly.GenericBox (α : Type u) where value : α
def ProductReplay.accepted : ∀ A : Type, [SelectedPoly.Dictionary A] → (∀ β : Type u, β → Nat) → SelectedPoly.GenericBox.{u+1} (∀ β : Type u, β → Nat) :=
((fun (leantType230 : Type) => (fun [leantGiven2x0 : @_root_.«SelectedPoly».«Dictionary» (leantType230)] => (fun (leantLocal5 : (∀ (leantBound0x0 : Type «u»), (leantBound0x0 → @_root_.«Nat»))) => @(let leantHead152 : ((∀ (leantBound0x0 : Type «u»), (leantBound0x0 → @_root_.«Nat»)) → (@_root_.«SelectedPoly».«GenericBox».{(«u» + 1)} ((∀ (leantBound0x0 : Type «u»), (leantBound0x0 → @_root_.«Nat»))))) := @(let leantHead35 : (∀ {leantBound0x0 : Type («u» + 1)}, (leantBound0x0 → (@_root_.«SelectedPoly».«GenericBox».{(«u» + 1)} (leantBound0x0)))) := @_root_.«SelectedPoly».«GenericBox».«mk».{(«u» + 1)}; @leantHead35 ((∀ (leantBound0x0 : Type «u»), (leantBound0x0 → @_root_.«Nat»)))); @leantHead152 ((fun (leantType135 : Type «u») => @(let leantHead104 : (∀ (leantBound0x0 : Type «u»), (leantBound0x0 → @_root_.«Nat»)) := @leantLocal5; @leantHead104 (leantType135))) : (∀ (leantBound0x0 : Type «u»), (leantBound0x0 → @_root_.«Nat»))))))) : (∀ (leantBound0x0 : Type) [@_root_.«SelectedPoly».«Dictionary» (leantBound0x0)], ((∀ (leantBound1x0 : Type «u»), (leantBound1x0 → @_root_.«Nat»)) → (@_root_.«SelectedPoly».«GenericBox».{(«u» + 1)} ((∀ (leantBound1x0 : Type «u»), (leantBound1x0 → @_root_.«Nat»)))))))
theorem ProductReplay.passes : (@ProductReplay.accepted.{u} Nat (@SelectedPoly.Dictionary.mk Nat 7) (fun _ _ => 37)).value PUnit.{u+1} PUnit.unit = 37 ∧ (@ProductReplay.accepted.{u} Nat (@SelectedPoly.Dictionary.mk Nat 11) (fun _ _ => 53)).value PUnit.{u+1} PUnit.unit = 53 := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
