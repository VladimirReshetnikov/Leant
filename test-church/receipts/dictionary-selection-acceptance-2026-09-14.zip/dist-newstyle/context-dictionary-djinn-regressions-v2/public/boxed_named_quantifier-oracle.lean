set_option autoImplicit false
class SelectedPoly.Dictionary (α : Type) where tag : Nat
structure SelectedPoly.Box (α : Type 1) where value : α
universe u
structure SelectedPoly.GenericBox (α : Type u) where value : α
def ProductReplay.accepted : ∀ A : Type, [SelectedPoly.Dictionary A] → (∀ β : Type u, β → Nat) → SelectedPoly.GenericBox.{u+1} (∀ β : Type u, β → Nat) :=
fun (A : Type) [d : SelectedPoly.Dictionary A] payload => ⟨payload⟩
theorem ProductReplay.passes : (@ProductReplay.accepted.{u} Nat (@SelectedPoly.Dictionary.mk Nat 7) (fun _ _ => 37)).value PUnit.{u+1} PUnit.unit = 37 ∧ (@ProductReplay.accepted.{u} Nat (@SelectedPoly.Dictionary.mk Nat 11) (fun _ _ => 53)).value PUnit.{u+1} PUnit.unit = 53 := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
