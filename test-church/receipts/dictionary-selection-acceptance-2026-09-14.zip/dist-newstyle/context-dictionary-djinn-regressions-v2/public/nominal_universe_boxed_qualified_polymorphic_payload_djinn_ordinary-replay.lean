set_option autoImplicit false
class SelectedPoly.Dictionary (α : Type) where tag : Nat
structure SelectedPoly.Box (α : Type 1) where value : α
universe u
structure SelectedPoly.GenericBox (α : Type u) where value : α
def ProductReplay.accepted : ∀ A : Type, [SelectedPoly.Dictionary A] → (∀ β : Type, [SelectedPoly.Dictionary β] → β → Nat) → SelectedPoly.Box (∀ β : Type, [SelectedPoly.Dictionary β] → β → Nat) :=
((fun (leantType119 : Type) => (fun [leantGiven2x0 : @_root_.«SelectedPoly».«Dictionary» (leantType119)] => (fun (leantLocal5 : (∀ (leantBound0x0 : Type) [@_root_.«SelectedPoly».«Dictionary» (leantBound0x0)], (leantBound0x0 → @_root_.«Nat»))) => @(let leantHead65 : ((∀ (leantBound0x0 : Type) [@_root_.«SelectedPoly».«Dictionary» (leantBound0x0)], (leantBound0x0 → @_root_.«Nat»)) → (@_root_.«SelectedPoly».«Box» ((∀ (leantBound0x0 : Type) [@_root_.«SelectedPoly».«Dictionary» (leantBound0x0)], (leantBound0x0 → @_root_.«Nat»))))) := @(let leantHead35 : (∀ {leantBound0x0 : Type (0 + 1)}, (leantBound0x0 → (@_root_.«SelectedPoly».«Box» (leantBound0x0)))) := @_root_.«SelectedPoly».«Box».«mk»; @leantHead35 ((∀ (leantBound0x0 : Type) [@_root_.«SelectedPoly».«Dictionary» (leantBound0x0)], (leantBound0x0 → @_root_.«Nat»)))); @leantHead65 (@leantLocal5 : (∀ (leantBound0x0 : Type) [@_root_.«SelectedPoly».«Dictionary» (leantBound0x0)], (leantBound0x0 → @_root_.«Nat»))))))) : (∀ (leantBound0x0 : Type) [@_root_.«SelectedPoly».«Dictionary» (leantBound0x0)], ((∀ (leantBound1x0 : Type) [@_root_.«SelectedPoly».«Dictionary» (leantBound1x0)], (leantBound1x0 → @_root_.«Nat»)) → (@_root_.«SelectedPoly».«Box» ((∀ (leantBound1x0 : Type) [@_root_.«SelectedPoly».«Dictionary» (leantBound1x0)], (leantBound1x0 → @_root_.«Nat»)))))))
theorem ProductReplay.passes : True := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
