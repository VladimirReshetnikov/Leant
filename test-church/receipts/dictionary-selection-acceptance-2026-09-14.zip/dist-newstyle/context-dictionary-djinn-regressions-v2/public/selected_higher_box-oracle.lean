set_option autoImplicit false
class SelectedPoly.Dictionary (α : Type) where tag : Nat
structure SelectedPoly.Box (α : Type 1) where value : α
universe u
structure SelectedPoly.GenericBox (α : Type u) where value : α
def ProductReplay.accepted : ∀ A : Type, [SelectedPoly.Dictionary A] → ∀ β : Type 1, β → SelectedPoly.GenericBox.{1} β :=
fun (A : Type) [d : SelectedPoly.Dictionary A] (β : Type 1) payload => ⟨payload⟩
theorem ProductReplay.passes : (@ProductReplay.accepted Nat (@SelectedPoly.Dictionary.mk Nat 7) (ULift.{1} Nat) ⟨37⟩).value.down = 37 ∧ (@ProductReplay.accepted Nat (@SelectedPoly.Dictionary.mk Nat 11) (ULift.{1} Nat) ⟨53⟩).value.down = 53 := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
