set_option autoImplicit false
class SelectionProbe.Dictionary (α : Type) where tag : Nat
inductive SelectionProbe.Witness (α : Type 1) (R : Type) where | mk : R → α → SelectionProbe.Witness α R
def ProductReplay.accepted : ∀ A R : Type, [SelectionProbe.Dictionary A] → (∀ α : Type 1, [SelectionProbe.Dictionary A] → α → SelectionProbe.Witness α R) → (∀ β : Type, β → Nat) → SelectionProbe.Witness (∀ β : Type, β → Nat) R :=
fun (A R : Type) [d : SelectionProbe.Dictionary A] consumer payload => @consumer (∀ β : Type, β → Nat) d payload
theorem ProductReplay.passes : (match @ProductReplay.accepted Nat Nat (@SelectionProbe.Dictionary.mk Nat 7) (fun α [d : SelectionProbe.Dictionary Nat] payload => (@SelectionProbe.Witness.mk α Nat d.tag payload)) (fun _ _ => 37) with | .mk value payload => value = 7 ∧ payload Bool true = 37) ∧ (match @ProductReplay.accepted Nat Nat (@SelectionProbe.Dictionary.mk Nat 11) (fun α [d : SelectionProbe.Dictionary Nat] payload => (@SelectionProbe.Witness.mk α Nat d.tag payload)) (fun _ _ => 53) with | .mk value payload => value = 11 ∧ payload Unit () = 53) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
