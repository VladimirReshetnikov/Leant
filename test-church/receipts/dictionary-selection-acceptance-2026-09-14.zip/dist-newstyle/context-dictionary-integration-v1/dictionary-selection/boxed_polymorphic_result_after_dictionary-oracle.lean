set_option autoImplicit false
class SelectionProbe.Dictionary (α : Type) where tag : Nat
inductive SelectionProbe.Witness (α : Type 1) (R : Type) where | mk : R → α → SelectionProbe.Witness α R
inductive SelectionProbe.Box (α : Type 1) where | mk : α → SelectionProbe.Box α
def ProductReplay.accepted : ∀ A R : Type, [SelectionProbe.Dictionary A] → (∀ α : Type 1, [SelectionProbe.Dictionary A] → α → SelectionProbe.Witness α R) → (SelectionProbe.Box (∀ β : Type, β → Nat)) → SelectionProbe.Witness (SelectionProbe.Box (∀ β : Type, β → Nat)) R :=
fun (A R : Type) [d : SelectionProbe.Dictionary A] consumer payload => @consumer (SelectionProbe.Box (∀ β : Type, β → Nat)) d payload
theorem ProductReplay.passes : (match @ProductReplay.accepted Nat Nat (@SelectionProbe.Dictionary.mk Nat 7) (fun α [d : SelectionProbe.Dictionary Nat] payload => (@SelectionProbe.Witness.mk α Nat d.tag payload)) (@SelectionProbe.Box.mk (∀ β : Type, β → Nat) (fun _ _ => 37)) with | .mk value (.mk payload) => value = 7 ∧ payload Bool true = 37) ∧ (match @ProductReplay.accepted Nat Nat (@SelectionProbe.Dictionary.mk Nat 11) (fun α [d : SelectionProbe.Dictionary Nat] payload => (@SelectionProbe.Witness.mk α Nat d.tag payload)) (@SelectionProbe.Box.mk (∀ β : Type, β → Nat) (fun _ _ => 53)) with | .mk value (.mk payload) => value = 11 ∧ payload Unit () = 53) := by decide
#print axioms ProductReplay.accepted
#print axioms ProductReplay.passes
