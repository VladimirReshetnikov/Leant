-- Independent source reset segment 0
namespace Higher
axiom Token : Type
axiom Wrap : Type → Type
axiom Pair : Type → Type → Type
axiom Triple : Type → Type → Type → Type
class Choice (F G : Type → Type) (a : Type) (hidden : Type 1) : Prop where
  witness : True
instance : Choice Wrap (Pair Nat) Bool (∀ x : Type, x → x) :=
  ⟨True.intro⟩
axiom global {F G : Type → Type} {a : Type} {hidden : Type 1}
    [Choice F G a hidden] : F a → G a → Token
class VacuousChoice (F : Type → Type) : Prop where
  witness : True
instance : VacuousChoice Wrap := ⟨True.intro⟩
axiom VacuousToken : Type
axiom vacuous {F : Type → Type} [VacuousChoice F] : VacuousToken
class MultiVacuousChoice (F : Type → Type) (G : Type → Type → Type) : Prop where
  witness : True
instance : MultiVacuousChoice Wrap (Triple Nat) := ⟨True.intro⟩
axiom MultiVacuousToken : Type
axiom multiVacuous {F : Type → Type} {G : Type → Type → Type}
    [MultiVacuousChoice F G] : MultiVacuousToken
class AlternativeChoice (F : Type → Type) : Prop where
  witness : True
instance : AlternativeChoice Wrap := ⟨True.intro⟩
instance : AlternativeChoice (Pair Nat) := ⟨True.intro⟩
axiom AlternativeToken : Type
axiom alternative {F : Type → Type} [AlternativeChoice F] : AlternativeToken
end Higher

noncomputable def goldenReplayQuery5Candidate1 : Higher.VacuousToken :=
  Higher.vacuous («F» := Higher.Wrap)
#print axioms goldenReplayQuery5Candidate1
noncomputable def goldenReplayQuery5Candidate2 : Higher.VacuousToken :=
  match Sum.inr (Higher.vacuous («F» := Higher.Wrap)) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery5Candidate2
noncomputable def goldenReplayQuery5Candidate3 : Higher.VacuousToken :=
  match Sum.inl (Higher.vacuous («F» := Higher.Wrap)) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery5Candidate3
noncomputable def goldenReplayQuery6Candidate1 : Higher.MultiVacuousToken :=
  Higher.multiVacuous («F» := Higher.Wrap) («G» := (@Higher.Triple Nat))
#print axioms goldenReplayQuery6Candidate1
noncomputable def goldenReplayQuery6Candidate2 : Higher.MultiVacuousToken :=
  match Sum.inr (Higher.multiVacuous («F» := Higher.Wrap) («G» := (@Higher.Triple Nat))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery6Candidate2
noncomputable def goldenReplayQuery6Candidate3 : Higher.MultiVacuousToken :=
  match Sum.inl (Higher.multiVacuous («F» := Higher.Wrap) («G» := (@Higher.Triple Nat))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery6Candidate3
noncomputable def goldenReplayQuery9Candidate1 : Higher.VacuousToken :=
  Higher.vacuous («F» := Higher.Wrap)
#print axioms goldenReplayQuery9Candidate1
noncomputable def goldenReplayQuery9Candidate2 : Higher.VacuousToken :=
  match Sum.inl (Higher.vacuous («F» := Higher.Wrap)) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery9Candidate2
noncomputable def goldenReplayQuery9Candidate3 : Higher.VacuousToken :=
  match Sum.inr (Higher.vacuous («F» := Higher.Wrap)) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery9Candidate3
noncomputable def goldenReplayQuery10Candidate1 : Higher.MultiVacuousToken :=
  Higher.multiVacuous («F» := Higher.Wrap) («G» := (@Higher.Triple Nat))
#print axioms goldenReplayQuery10Candidate1
noncomputable def goldenReplayQuery10Candidate2 : Higher.MultiVacuousToken :=
  match Sum.inl (Higher.multiVacuous («F» := Higher.Wrap) («G» := (@Higher.Triple Nat))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery10Candidate2
noncomputable def goldenReplayQuery10Candidate3 : Higher.MultiVacuousToken :=
  match Sum.inr (Higher.multiVacuous («F» := Higher.Wrap) («G» := (@Higher.Triple Nat))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery10Candidate3
noncomputable def goldenReplayQuery11Candidate1 : Higher.AlternativeToken :=
  Higher.alternative («F» := Higher.Wrap)
#print axioms goldenReplayQuery11Candidate1
noncomputable def goldenReplayQuery11Candidate2 : Higher.AlternativeToken :=
  Higher.alternative («F» := (@Higher.Pair Nat))
#print axioms goldenReplayQuery11Candidate2
noncomputable def goldenReplayQuery11Candidate3 : Higher.AlternativeToken :=
  match Sum.inl (Higher.alternative («F» := (@Higher.Pair Nat))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery11Candidate3
noncomputable def goldenReplayQuery11Candidate4 : Higher.AlternativeToken :=
  match Sum.inl (Higher.alternative («F» := Higher.Wrap)) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery11Candidate4
noncomputable def goldenReplayQuery11Candidate5 : Higher.AlternativeToken :=
  match Sum.inr (Higher.alternative («F» := (@Higher.Pair Nat))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery11Candidate5
