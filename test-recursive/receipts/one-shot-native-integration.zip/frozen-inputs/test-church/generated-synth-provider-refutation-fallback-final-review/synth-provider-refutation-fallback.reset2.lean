-- Independent source reset segment 2

inductive RefutationBoth.Void : Type
class RefutationBoth.Choice (a : Type 1) : Prop where witness : True
instance : RefutationBoth.Choice (∀ x : Type, x → x) := ⟨True.intro⟩
axiom RefutationBoth.impossible {a : Type 1} [RefutationBoth.Choice a] :
  RefutationBoth.Void

noncomputable def goldenReplayQuery2Candidate1 : RefutationBoth.Void :=
  RefutationBoth.impossible («a» := (∀ (a0_0 : Type _), a0_0 → a0_0))
#print axioms goldenReplayQuery2Candidate1
noncomputable def goldenReplayQuery2Candidate2 : RefutationBoth.Void :=
  match Sum.inl (RefutationBoth.impossible («a» := (∀ (a0_0 : Type _), a0_0 → a0_0))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery2Candidate2
noncomputable def goldenReplayQuery2Candidate3 : RefutationBoth.Void :=
  match Sum.inr (RefutationBoth.impossible («a» := (∀ (a0_0 : Type _), a0_0 → a0_0))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery2Candidate3
