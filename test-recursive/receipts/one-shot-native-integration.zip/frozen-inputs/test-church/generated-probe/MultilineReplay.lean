-- Generated exclusively from synthesized candidates and the manifest.
set_option linter.unusedVariables false
def ChurchCorpus.integerZero : Int := 0

-- Church.hs:1 identity (total)
def ChurchCorpus.identity : Unit → Unit :=
  fun value =>
    let result := value
    result
#print axioms ChurchCorpus.identity
