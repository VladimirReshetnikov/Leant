from pathlib import Path
path=Path('test/synth-church-rankn.txt')
text=path.read_text(encoding='utf-8')
explicit=':synth (∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) → G (∀ c : Type, X → c → c) (∀ d : Type, d → d))'
implicit=explicit.replace('∀ a : Type 1,','∀ {a : Type 1},').replace('∀ b : Type 1,','∀ {b : Type 1},')
inner=lambda value:value.replace('∀ c : Type,','∀ {c : Type},').replace('∀ d : Type,','∀ {d : Type},')
assert text.count(explicit)==3
assert implicit not in text
text=text.replace(explicit,'\n'.join([explicit,implicit,inner(explicit),inner(implicit)]))
assert sum(line.startswith(':synth ') for line in text.splitlines())==66
path.write_text(text,encoding='utf-8')
