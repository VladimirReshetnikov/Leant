import json
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parents[2]
exe = root / 'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/t/leant-synth-tests/build/leant-synth-tests/leant-synth-tests.exe'
log = Path(__file__).with_name('timeout-fixture.log')
with log.open('w', encoding='utf-8') as output:
    process = subprocess.Popen([str(exe), '--num-threads', '1', '--pattern',
        '/reject invalid setup responses/ && /reject timeout/'],
        cwd=root, stdout=output, stderr=subprocess.STDOUT)
    print(json.dumps({'owned_parent_pid': process.pid}), flush=True)
    try:
        process.wait(timeout=12)
        print(json.dumps({'exit_code': process.returncode}), flush=True)
    except subprocess.TimeoutExpired:
        print('Bounded fixture timed out; terminating only its owned tree.', flush=True)
        subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], check=True)
        process.wait(timeout=5)
print(log.read_text(encoding='utf-8'), flush=True)
