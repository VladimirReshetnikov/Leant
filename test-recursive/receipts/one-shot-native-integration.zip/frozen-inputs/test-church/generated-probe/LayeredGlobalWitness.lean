namespace ChurchLayered
axiom Seed : Type
axiom seed : Seed
axiom G2 : Type 1 → Type 1 → Type 1
axiom G3 : Type 1 → Type 1 → Type 1 → Type 1
axiom maker2 : Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G2 a b
axiom maker3 : Seed → ∀ a b : Type 1, a → b → Seed → ∀ c : Type 1, c → G3 a b c

noncomputable def binary :
    G2 (∀ a : Type, a → a) (∀ a : Type, a → a → a) :=
  maker2 seed _ (fun _ x => x) seed _ (fun _ x _ => x)

noncomputable def ternary :
    G3 (∀ a : Type, a → a) (∀ a : Type, a → a → a) (∀ a : Type, a → a) :=
  maker3 seed _ _ (fun _ x => x) (fun _ x _ => x) seed _ (fun _ x => x)

#print axioms binary
#print axioms ternary
end ChurchLayered
#print axioms ChurchLayered.binary
#print axioms ChurchLayered.ternary
