def binaryAlternating : (∀ (Seed : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) → G (∀ a : Type, a → a) (∀ b : Type, b → b)) :=
  fun _ _ x f => let g := f x (∀ (a0_0 : _), a0_0 → a0_0) (fun _ y => y); let h := g x; h _ (fun _ z => z)
#print axioms binaryAlternating
