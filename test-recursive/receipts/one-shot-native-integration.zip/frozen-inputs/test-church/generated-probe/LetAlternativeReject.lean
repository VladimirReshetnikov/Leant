example : ∀ F : Type 1 → Type 1, (Unit → ∀ a : Type 1, a → F a) → F (∀ b : Type, b → b) :=
  fun _ f => let g := f ⟨⟩ _; @g _ (fun _ x => x)
