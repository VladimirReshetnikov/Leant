from pathlib import Path
import subprocess, os
root=Path.cwd()
source=(root/'test/synth-church-rankn.txt').read_text(encoding='utf-8')
queries=[x for x in source.splitlines() if x.startswith(':synth ')][:18][-2:]
commands='\n'.join([':set synth-library off',':set synth-providers off',':set synth-classical off',':set synth-debug on',':set synth-window 1',':set synth-verify 1',':set synth-shown 1',':set synth-engine exference',*queries,':quit'])+'\n'
(root/'test-church/generated-probe/alternating-debug.txt').write_text(commands,encoding='utf-8')
exe=root/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/x/leant/build/leant/leant.exe'
with (root/'test-church/generated-probe/alternating-debug.output.txt').open('w',encoding='utf-8') as out:
 p=subprocess.run([str(exe),'--plain'],input=commands,stdout=out,stderr=subprocess.STDOUT,text=True,encoding='utf-8',env=dict(os.environ,LEANT_SYNTH_TIMEOUT='30'))
print(p.returncode)
