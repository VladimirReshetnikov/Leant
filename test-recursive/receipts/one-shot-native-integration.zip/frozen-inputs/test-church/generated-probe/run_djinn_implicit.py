from pathlib import Path
import subprocess,os,json,hashlib
root=Path.cwd()
report=json.loads((root/'test-church/generated-fixtures-acceptance/results.json').read_text(encoding='utf-8'))
fixture=next(row for row in report['fixtures'] if row['fixture']=='synth-church-rankn')
queries=[row['lean_type'] for row in fixture['results'] if row['candidate'] is None]
assert len(queries)==3
commands=[':set synth-library off',':set synth-providers off',':set synth-classical off',':set synth-debug on',':set synth-steps 4096',':set synth-window 1',':set synth-verify 1',':set synth-shown 1',':set synth-engine djinn']
commands += [':synth '+query for query in queries]+[':quit']
source='\n'.join(commands)+'\n'
(root/'test-church/generated-probe/djinn-implicit.txt').write_text(source,encoding='utf-8')
exe=root/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/x/leant/build/leant/leant.exe'
print(hashlib.sha256(exe.read_bytes()).hexdigest(),flush=True)
with (root/'test-church/generated-probe/djinn-implicit.output.txt').open('w',encoding='utf-8') as out:
 p=subprocess.run([str(exe),'--plain'],input=source,stdout=out,stderr=subprocess.STDOUT,text=True,encoding='utf-8',env=dict(os.environ,LEANT_SYNTH_TIMEOUT='90'))
print(p.returncode)
