from pathlib import Path
import subprocess, os
root=Path.cwd()
source=(root/'test/synth-church-layered-providers.txt').read_text(encoding='utf-8')
source=source.split(':set synth-engine djinn')[0]+':set synth-debug on\n:set synth-steps 10000\n:set synth-engine exference\n'+'\n'.join([x for x in source.splitlines() if x.startswith(':synth ')][:2])+ '\n:quit\n'
(root/'test-church/generated-probe/layered-global-debug.txt').write_text(source,encoding='utf-8')
exe=root/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/x/leant/build/leant/leant.exe'
with (root/'test-church/generated-probe/layered-global-debug.output.txt').open('w',encoding='utf-8') as out:
 p=subprocess.run([str(exe),'--plain'],input=source,stdout=out,stderr=subprocess.STDOUT,text=True,encoding='utf-8',env=dict(os.environ,LEANT_SYNTH_TIMEOUT='30'))
print(p.returncode)
