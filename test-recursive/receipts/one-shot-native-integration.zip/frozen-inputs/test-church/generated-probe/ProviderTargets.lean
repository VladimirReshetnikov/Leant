noncomputable section
-- These axioms model explicitly supplied opaque primitives. This fixture
-- checks provider discovery and kernel typing relative to that environment;
-- closed Church-corpus acceptance uses no axioms.
namespace ChurchProviders8
axiom Token : Type
class Choice (t0 t1 t2 t3 t4 t5 t6 t7 : Type 1) : Prop where witness : True
instance : Choice (∀ A : Type, A → A) (∀ A : Type, A → A → A) (∀ A : Type, A → A → A → A) (∀ A : Type, A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A → A → A) := ⟨True.intro⟩
axiom chosen {t0 t1 t2 t3 t4 t5 t6 t7 : Type 1} [Choice t0 t1 t2 t3 t4 t5 t6 t7] : Token
end ChurchProviders8

namespace ChurchProviders12
axiom Token : Type
class Choice (t0 t1 t2 t3 t4 t5 t6 t7 t8 t9 t10 t11 : Type 1) : Prop where witness : True
instance : Choice (∀ A : Type, A → A) (∀ A : Type, A → A → A) (∀ A : Type, A → A → A → A) (∀ A : Type, A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A → A → A → A → A → A → A) := ⟨True.intro⟩
axiom chosen {t0 t1 t2 t3 t4 t5 t6 t7 t8 t9 t10 t11 : Type 1} [Choice t0 t1 t2 t3 t4 t5 t6 t7 t8 t9 t10 t11] : Token
end ChurchProviders12


example : ChurchProviders8.Token := ChurchProviders8.chosen (t0 := (∀ A : Type, A → A)) (t1 := (∀ A : Type, A → A → A)) (t2 := (∀ A : Type, A → A → A → A)) (t3 := (∀ A : Type, A → A → A → A → A)) (t4 := (∀ A : Type, A → A → A → A → A → A)) (t5 := (∀ A : Type, A → A → A → A → A → A → A)) (t6 := (∀ A : Type, A → A → A → A → A → A → A → A)) (t7 := (∀ A : Type, A → A → A → A → A → A → A → A → A))
example : ChurchProviders12.Token := ChurchProviders12.chosen (t0 := (∀ A : Type, A → A)) (t1 := (∀ A : Type, A → A → A)) (t2 := (∀ A : Type, A → A → A → A)) (t3 := (∀ A : Type, A → A → A → A → A)) (t4 := (∀ A : Type, A → A → A → A → A → A)) (t5 := (∀ A : Type, A → A → A → A → A → A → A)) (t6 := (∀ A : Type, A → A → A → A → A → A → A → A)) (t7 := (∀ A : Type, A → A → A → A → A → A → A → A → A)) (t8 := (∀ A : Type, A → A → A → A → A → A → A → A → A → A)) (t9 := (∀ A : Type, A → A → A → A → A → A → A → A → A → A → A)) (t10 := (∀ A : Type, A → A → A → A → A → A → A → A → A → A → A → A)) (t11 := (∀ A : Type, A → A → A → A → A → A → A → A → A → A → A → A → A))
