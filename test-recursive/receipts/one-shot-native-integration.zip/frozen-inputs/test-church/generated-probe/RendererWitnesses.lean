set_option linter.unusedVariables false
example : ∀ (A : Type _) (B : Type _), (A → B) → B → B :=
  fun _ _ f x => match Sum.inr x with | .inl a => f a | .inr b => b
example : ∀ (A B : Prop), (A → B) → B → B :=
  fun _ _ f x => match Or.inr x with | .inl a => f a | .inr b => b
example : ∀ F : Type 1 → Type 1, (∀ a : Type 1, a → F a) → F (∀ b : Type, b → b) :=
  fun _ f => @f _ (fun _ x => x)
example : ∀ F : Type 1 → Type 1 → Type 1, (∀ a b : Type 1, a → b → F a b) → F (∀ a : Type, a → a) (∀ b : Type, b → b → b) :=
  fun _ f => @f _ _ (fun _ x => x) (fun _ y _ => y)
example : ∀ (F : Type 1 → Type 1) (A : Type), (∀ a : Type 1, a → F a) → F (∀ B : Type, A → B → B) :=
  fun _ _ f => @f _ (fun _ _ x => x)
