from pathlib import Path
import importlib.util, json, subprocess, hashlib

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('drift',Path(__file__).with_name('replay_golden_drift.py'))
drift=importlib.util.module_from_spec(spec)
spec.loader.exec_module(drift)
spec2=importlib.util.spec_from_file_location('corpus',ROOT/'test-church/run_corpus.py')
corpus=importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(corpus)
source=(ROOT/'test/synth-provider-constraint-closure.txt').read_text(encoding='utf-8-sig')
out=ROOT/'test-church/generated-closure-bounded-final'
actual=(out/'synth-provider-constraint-closure.output.txt').read_text(encoding='utf-8')
queries=drift.parse_queries(actual)
rows=[]
index=0
for segment_index,segment in enumerate(source.split(':reset')):
    goal_types=[line[len(':synth '):] for line in segment.splitlines() if line.startswith(':synth ')]
    selected=queries[index:index+len(goal_types)]
    assert [row['type'] for row in selected]==goal_types
    lines=['set_option linter.unusedVariables false']
    lines += [line for line in segment.splitlines() if not line.startswith(':')]
    lines += ['noncomputable section']
    names=[]
    expected=set()
    for qi,row in enumerate(selected):
        namespace=row['type'].split('.')[0]
        expected={namespace+'.Token',namespace+'.global'}
        for term in row['terms']:
            name=f'ClosureReplay{qi}_{term["label"]}'
            names.append(name)
            lines += [f'def {name} : {row["type"]} := {term["term"]}',f'#print axioms {name}']
    text='\n'.join(lines)+'\n'
    target=out/f'replay-segment{segment_index}.lean'
    target.write_text(text,encoding='utf-8')
    run=subprocess.run(['lean','+leanprover/lean4:v4.32.0',str(target)],cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
    output=run.stdout+run.stderr
    target.with_suffix('.kernel.txt').write_text(output,encoding='utf-8')
    correct=all(corpus.reported_axioms(run.stdout,name)==expected for name in names)
    rows.append(dict(segment=segment_index,candidates=len(names),kernel_exit_code=run.returncode,
        exact_axioms=correct,source_sha256=hashlib.sha256(text.encode()).hexdigest()))
    print(rows[-1],flush=True)
    assert run.returncode==0 and correct,output
    index+=len(selected)
assert index==len(queries)==6
(out/'replay-results.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
