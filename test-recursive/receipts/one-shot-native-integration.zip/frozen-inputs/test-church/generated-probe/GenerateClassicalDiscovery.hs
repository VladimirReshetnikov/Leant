module Main where
import Leant.Synth.Fragment
import System.IO

main :: IO ()
main = do
  hSetEncoding stdout utf8
  writeFile "test-church/generated-classical-diagnosis/Discovery.lean" $
    "import Lean\nset_option maxHeartbeats 200000\n" ++ synthPrelude []
      ++ serializerProgram "(∀ p q : Prop, (p → q) ∨ (q → p))"
      ++ providerProgram [] (ProviderQuery ["Or"] (Just "Or"))
