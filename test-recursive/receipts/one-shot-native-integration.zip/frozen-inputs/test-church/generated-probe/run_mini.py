from pathlib import Path
import subprocess
import sys
root = Path(__file__).resolve().parents[2]
log = Path(__file__).with_name('timeout-mini.log')
with log.open('w') as output:
    child = subprocess.Popen([str(root / 'test-church/generated-probe/timeout-mini.exe'), *sys.argv[1:]], cwd=root, stdout=output, stderr=subprocess.STDOUT)
    print(f'Owned parent PID {child.pid}', flush=True)
    try:
        child.wait(timeout=8)
    except subprocess.TimeoutExpired:
        subprocess.run(['taskkill', '/PID', str(child.pid), '/T', '/F'], check=True)
        child.wait(timeout=5)
print(log.read_text(), flush=True)
