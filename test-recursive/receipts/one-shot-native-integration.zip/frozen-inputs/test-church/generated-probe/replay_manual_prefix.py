from pathlib import Path
import hashlib, importlib.util, json, re, subprocess, sys

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'test-church/generated-manual-prefix-review'
OUT.mkdir(exist_ok=True)

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

review=load('review',ROOT/'test-church/generated-probe/replay_golden_drift.py')
corpus=load('corpus',ROOT/'test-church/run_corpus.py')
source_path=ROOT/'test/synth-manual.txt'
golden_path=source_path.with_suffix('.golden')
capture_path=ROOT/'test-church/generated-goldens-final/transcripts/synth-manual.output.txt'
source=source_path.read_text(encoding='utf-8-sig')
golden=golden_path.read_text(encoding='utf-8-sig')
actual=capture_path.read_text(encoding='utf-8-sig')
source_lines=source.splitlines(keepends=True)
query_lines=[i for i,line in enumerate(source_lines) if line.startswith(':synth ')]
last_query=21
prefix=''.join(source_lines[:query_lines[last_query]+1])

def through_query(text,index):
    queries=list(re.finditer(r'(?m)^λ> :synth ',text))
    start=queries[index].start()
    tail=text.find('\n',start)
    next_prompt=re.search(r'(?m)^λ>',text[tail+1:])
    if next_prompt is None:
        raise ValueError('the requested query has no completed next-prompt boundary')
    return text[:tail+1+next_prompt.start()]

before_prefix=through_query(golden,last_query)
actual_prefix=through_query(actual,last_query)
before=review.validate_correspondence(prefix,before_prefix)
after=review.validate_correspondence(prefix,actual_prefix)
changes,segments=review.replay_segments(prefix,before,after)
assert [change['query_index'] for change in changes]==[18,21],changes
assert [change['after_count'] for change in changes]==[3,5]
assert len(segments)==1
segment=segments[0]
assert len(segment['declarations'])==8
assert 'opaque P' not in segment['source'] and 'opaque Q' not in segment['source']
target=OUT/'ManualPrefix.lean'
target.write_text(segment['source'],encoding='utf-8')
(OUT/'source-prefix.txt').write_text(prefix,encoding='utf-8')
(OUT/'actual-prefix.txt').write_text(actual_prefix,encoding='utf-8')
result=subprocess.run(['lean','+leanprover/lean4:v4.32.0',str(target.resolve())],
    cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
output=result.stdout+result.stderr
(OUT/'kernel-output.txt').write_text(output,encoding='utf-8')
inventories={name:corpus.reported_axioms(result.stdout,name) for name in segment['declarations']}
sha=lambda text:hashlib.sha256(text.encode('utf-8')).hexdigest()
report={
    'fixture':'synth-manual.txt','completed_through_query_index':last_query,
    'leant_executable_sha256':'addfac35b9d82955fc871c177b582a8c043475c0171c22cb17977e0e9f5b9869',
    'source_file_sha256':hashlib.sha256(source_path.read_bytes()).hexdigest(),
    'golden_before_sha256':hashlib.sha256(golden_path.read_bytes()).hexdigest(),
    'prefix_hash_normalization':'UTF-8 without BOM; universal newlines normalized to LF',
    'source_prefix_sha256':sha(prefix),'actual_prefix_sha256':sha(actual_prefix),
    'replay_source_sha256':sha(segment['source']),
    'changed_queries':changes,'omitted_inspections':segment['omitted_inspections'],
    'query_sha256':{str(index):sha(after[index]['type']) for index in [18,21]},
    'candidate_count':8,'kernel_exit_code':result.returncode,
    'axiom_inventories':{name:None if value is None else sorted(value) for name,value in inventories.items()},
    'passed':result.returncode==0 and all(value==set() for value in inventories.values()) and 'sorryAx' not in output,
}
(OUT/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2,ensure_ascii=False))
if not report['passed']:
    print(output)
    raise SystemExit(1)
