module Main where
import Leant.Synth.Engine
import Leant.Synth.Fragment
import System.IO
import Control.Exception (evaluate)
import Control.DeepSeq (force)
import Data.Time.Clock
import qualified Data.Set as Set

main :: IO ()
main = do
  hSetBuffering stdout NoBuffering
  let nat = FParamRec True "Nat" "Nat" [] [("Nat.zero",[]),("Nat.succ",[FAtom False "Nat"])]
      int = FParamInd "Int" "Int" [] [("Int.ofNat",[nat]),("Int.negSucc",[nat])]
      bool = FAll True "a" (FArr (FVar "a") (FArr (FVar "a") (FVar "a")))
      cases = [("no arguments",bool), ("opaque Int", FArr (FAtom False "Int") (FArr (FAtom False "Int") bool)), ("expanded Int",FArr int (FArr int bool))]
  mapM_ (\(name, goal) -> do
    putStrLn name
    start <- getCurrentTime
    output <- evaluate $ force $ take 1200 $ show $ synthesize EngineExference 4096 goal
    putStrLn output
    stop <- getCurrentTime
    print $ diffUTCTime stop start) cases
  putStrLn "expanded Int without multi-constructor patterns"
  let goal = FArr int (FArr int bool)
  print $ fmap (take 1200 . show . projectDetailedSynthOutcome) $
    synthesizeWithProvidersSkippingDetailedWithMultiConstructorPatterns False EngineExference 4096 Set.empty [] goal
