from pathlib import Path
path=Path('test/synth-church-rankn.txt')
text=path.read_text(encoding='utf-8')
original=':synth (∀ (Seed : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) → G (∀ a : Type, a → a) (∀ b : Type, b → b))'
closed=original.replace('G (∀ a : Type, a → a) (∀ b : Type, b → b)', 'G (∀ {a : Type}, a → a) (∀ b : Type, b → b)')
assert text.count(original)==3 and closed not in text
text=text.replace(original, original+'\n'+closed)
assert sum(line.startswith(':synth ') for line in text.splitlines())==69
path.write_text(text,encoding='utf-8')
