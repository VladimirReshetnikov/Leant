from pathlib import Path
import json, subprocess, time

ROOT=Path(__file__).resolve().parents[2]
EXE=ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/x/leant/build/leant/leant.exe'
OUT=ROOT/'test-church/generated-classical-diagnosis'
OUT.mkdir(exist_ok=True)
query=':synth (∀ p q : Prop, (p → q) ∨ (q → p))'
variants={
    'default':[],
    'no-library':[':set synth-library off'],
    'no-providers':[':set synth-providers off'],
    'minimal':[':set synth-library off',':set synth-providers off'],
}
rows=[]
for name,settings in variants.items():
    source='\n'.join([':set synth-debug on',':set synth-timeout 3']+settings+[query,':quit',''])
    (OUT/(name+'.txt')).write_text(source,encoding='utf-8')
    started=time.monotonic()
    with (OUT/(name+'.output.txt')).open('w',encoding='utf-8') as output:
        process=subprocess.Popen([str(EXE),'--plain'],cwd=ROOT,stdin=subprocess.PIPE,stdout=output,stderr=subprocess.STDOUT,text=True,encoding='utf-8')
        expired=False
        try:
            process.communicate(source,timeout=40)
        except subprocess.TimeoutExpired:
            expired=True
            subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True)
            process.wait(timeout=10)
    row=dict(name=name,returncode=process.returncode,external_timeout=expired,seconds=time.monotonic()-started)
    rows.append(row)
    (OUT/'results.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
    print(row,flush=True)
