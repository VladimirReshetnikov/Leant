class Marker (α : Type 1) where
  marker : Unit
instance {α : Type 1} : Marker α := ⟨()⟩

def implicitOnly : ∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed →
    (Seed → ∀ {a : Type 1}, a → Seed → ∀ {b : Type 1}, b → G a b) →
    G (∀ c : Type, X → c → c) (∀ d : Type, d → d) :=
  fun Seed X G s f => @f s (∀ c : Type, X → c → c) (fun _ _ x => x) s _ (fun _ x => x)
#print axioms implicitOnly

def instanceHoles : ∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed →
    (Seed → ∀ {a : Type 1}, ∀ [Marker a], a → Seed → ∀ {b : Type 1}, ∀ [Marker b], b → G a b) →
    G (∀ c : Type, X → c → c) (∀ d : Type, d → d) :=
  fun Seed X G s f => @f s (∀ c : Type, X → c → c) _ (fun _ _ x => x) s _ _ (fun _ x => x)
#print axioms instanceHoles

def instanceTerms : ∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed →
    (Seed → ∀ {a : Type 1}, ∀ [Marker a], a → Seed → ∀ {b : Type 1}, ∀ [Marker b], b → G a b) →
    G (∀ c : Type, X → c → c) (∀ d : Type, d → d) :=
  fun Seed X G s f => @f s (∀ c : Type, X → c → c) (inferInstance) (fun _ _ x => x) s _ (inferInstance) (fun _ x => x)
#print axioms instanceTerms

def targetInnerImplicit : ∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed →
    (Seed → ∀ {a : Type 1}, a → Seed → ∀ {b : Type 1}, b → G a b) →
    G (∀ {c : Type}, X → c → c) (∀ {d : Type}, d → d) :=
  fun Seed X G s f => @f s (∀ c : Type, X → c → c) (fun _ _ x => x) s _ (fun x => x)
#print axioms targetInnerImplicit
