from pathlib import Path
import subprocess, os,hashlib
root=Path.cwd()
open_ty='(∀ c : Type, X → c → c)'
id_ty='(∀ d : Type, d → d)'
prefix='∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed → '
source='(Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b)'
implicit='(Seed → ∀ {a : Type 1}, a → Seed → ∀ {b : Type 1}, b → G a b)'
result='G '+open_ty+' '+id_ty
queries=[prefix+source+' → '+result,prefix+implicit+' → '+result,prefix+source+' → ('+result+' × '+result+')']
commands=[':set synth-library off',':set synth-providers off',':set synth-classical off',':set synth-debug on',':set synth-steps 4096',':set synth-window 1',':set synth-verify 1',':set synth-shown 1',':set synth-engine exference']
for i,q in enumerate(queries):
 if i==2: commands.append(':set synth-steps 10000')
 commands.append(':synth ('+q+')')
commands.append(':quit')
source='\n'.join(commands)+'\n'
(root/'test-church/generated-probe/ambient-combinations.txt').write_text(source,encoding='utf-8')
exe=root/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/x/leant/build/leant/leant.exe'
print(hashlib.sha256(exe.read_bytes()).hexdigest(),flush=True)
with (root/'test-church/generated-probe/ambient-combinations.output.txt').open('w',encoding='utf-8') as out:
 p=subprocess.run([str(exe),'--plain'],input=source,stdout=out,stderr=subprocess.STDOUT,text=True,encoding='utf-8',env=dict(os.environ,LEANT_SYNTH_TIMEOUT='90'))
print(p.returncode)
