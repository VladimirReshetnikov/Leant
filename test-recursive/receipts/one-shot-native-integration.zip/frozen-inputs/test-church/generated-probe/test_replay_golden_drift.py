"""Ignored pure selfchecks: no Lean executable or production fixtures used."""
import contextlib
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import replay_golden_drift as replay


def transcript(commands):
    return '\n'.join('λ> ' + command for command in commands) + '\n'


class ReplaySelfchecks(unittest.TestCase):
    def test_multiline_relative_indentation(self):
        output = transcript([':synth Unit → Unit\n  it1  fun x =>\n    let value :=\n      x\n    value\nnote: done', ':quit'])
        term = replay.parse_queries(output)[0]['terms'][0]['term']
        self.assertEqual(term, 'fun x =>\n    let value :=\n      x\n    value')

    def test_nonindented_continuation_is_not_silently_truncated(self):
        output = transcript([':synth Unit\n  it1  (\n⟨⟩\n)\n', ':quit'])
        self.assertEqual(replay.parse_queries(output)[0]['terms'][0]['term'], '(\n⟨⟩\n)')

    def test_reset_routes_to_independent_environments(self):
        source = 'axiom Before : Type\n:synth Before\n:reset\naxiom After : Type\n:synth After\n:quit\n'
        old = transcript(['axiom Before : Type', ':synth Before\n  it1  first', ':reset\nsession reset',
                          'axiom After : Type', ':synth After\n  it1  second', ':quit'])
        actual = old.replace('it1  first', 'it1  firstNew').replace('it1  second', 'it1  secondNew')
        before = replay.validate_correspondence(source, old)
        after = replay.validate_correspondence(source, actual)
        changes, segments = replay.replay_segments(source, before, after)
        self.assertEqual([row['segment'] for row in changes], [0, 1])
        self.assertIn('axiom Before', segments[0]['source'])
        self.assertNotIn('axiom After', segments[0]['source'])
        self.assertIn('axiom After', segments[1]['source'])
        self.assertNotIn('axiom Before', segments[1]['source'])
        self.assertNotIn('goldenReplayQuery0', segments[1]['source'])

    def test_engine_interleaving_and_reset_acknowledgment(self):
        source = ':set synth-engine djinn\n:synth Unit\n:reset\n:synth Unit\n:quit\n'
        good = transcript([':set synth-engine djinn\nsynth engine: djinn', ':synth Unit\n  it1  ⟨⟩',
                           ':reset\nsession reset', ':synth Unit\n  it1  ⟨⟩', ':quit'])
        replay.validate_correspondence(source, good)
        with self.assertRaisesRegex(ValueError, 'acknowledged'):
            replay.validate_correspondence(source, good.replace('session reset', 'reset failed'))
        with self.assertRaisesRegex(ValueError, 'sequence'):
            replay.validate_correspondence(source, good.replace('λ> :reset\nsession reset\n', ''))

    def test_partial_capture_and_query_mismatch_fail(self):
        source = ':synth Unit\n:quit\n'
        for output in [transcript([':synth Unit\n  it1  ⟨⟩']), transcript([':synth Nat\n  it1  0', ':quit'])]:
            with self.subTest(output=output), self.assertRaises(ValueError):
                replay.validate_correspondence(source, output)

    def test_lost_success_and_duplicate_labels_fail(self):
        left = replay.parse_queries(transcript([':synth Unit\n  it1  ⟨⟩']))
        right = replay.parse_queries(transcript([':synth Unit\nno term']))
        with self.assertRaisesRegex(ValueError, 'lost all'):
            replay.replay_segments(':synth Unit', left, right)
        with self.assertRaisesRegex(ValueError, 'candidate label'):
            replay.parse_queries(transcript([':synth Unit\n  it1  ⟨⟩\n  it1  ⟨⟩']))

    def test_proof_mode_fails_closed(self):
        for source in [':prove Unit\n:synth\n', ':synth\n', ':abort\n', ':set synth-prove on\n']:
            with self.subTest(source=source), self.assertRaises(ValueError):
                replay.validate_source(source)

    def test_diff_preserves_indentation_and_checks_baseline(self):
        self.assertEqual(replay.apply_diff('a\n', ['@@ -1 +1,2 @@', '-a', '+b', '+    c']), 'b\n    c\n')
        self.assertEqual(replay.apply_diff('', ['@@ -0,0 +1 @@', '+first']), 'first\n')
        with self.assertRaisesRegex(ValueError, 'mismatch'):
            replay.apply_diff('other\n', ['@@ -1 +1 @@', '-a', '+b'])

    def test_raw_capture_cli_records_hash_without_starting_lean(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'test').mkdir()
            captures = root / 'captures'
            captures.mkdir()
            source = ':synth Unit\n:quit\n'
            (root / 'test/sample.txt').write_text(source, encoding='utf-8')
            (root / 'test/sample.golden').write_text(transcript([':synth Unit\n  it1  Unit.unit', ':quit']), encoding='utf-8')
            (captures / 'sample.output.txt').write_text(transcript([':synth Unit\n  it1  ⟨⟩', ':quit']), encoding='utf-8')
            with patch.object(replay, 'ROOT', root), patch.object(replay.subprocess, 'run') as run:
                with contextlib.redirect_stdout(io.StringIO()):
                    self.assertEqual(replay.main(['--captures-dir', str(captures), '--output', str(root / 'out'),
                                                  '--executable-sha256', 'a' * 64]), 0)
                run.assert_not_called()
            report = (root / 'out/results.json').read_text(encoding='utf-8')
            self.assertIn('"leant_executable_sha256": "' + 'a' * 64 + '"', report)
            self.assertTrue((root / 'out/sample.reset0.lean').is_file())


if __name__ == '__main__':
    unittest.main()
