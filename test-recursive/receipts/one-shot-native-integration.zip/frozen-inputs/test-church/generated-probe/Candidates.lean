-- Generated exclusively from synthesized candidates and the manifest.
set_option linter.unusedVariables false
def ChurchCorpus.integerZero : Int := 0

-- Church.hs:164 true (total)
def ChurchCorpus.church_case_007 : (∀ (church0 : Type _), (church0 → (church0 → church0))) :=
  fun _ _ x => x
#print axioms ChurchCorpus.church_case_007

-- Church.hs:189 fst (total)
def ChurchCorpus.church_case_014 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church2 : Type _), ((church0 → (church1 → church2)) → church2)) → church0)) :=
  fun _ _ f => f _ (fun x _ => x)
#print axioms ChurchCorpus.church_case_014

-- Church.hs:222 cons (total)
def ChurchCorpus.church_case_022 : (∀ (church0 : Type _), (church0 → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2)))))) :=
  fun _ _ f => f
#print axioms ChurchCorpus.church_case_022

-- Church.hs:251 head (requires_partiality)
def ChurchCorpus.church_case_028 : (∀ (church0 : Type _), (church0 → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → church0))) :=
  fun _ x _ => x
#print axioms ChurchCorpus.church_case_028

-- Church.hs:371 zip (total)
def ChurchCorpus.church_case_050 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5)))))) :=
  fun _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_050

-- Church.hs:397 map (total)
def ChurchCorpus.church_case_056 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → church1) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_056

-- Church.hs:409 length (needs_int_provider)
def ChurchCorpus.church_case_060 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → Int)) :=
  fun _ _ => .ofNat (.zero)
#print axioms ChurchCorpus.church_case_060

-- Church.hs:536 transpose (total)
def ChurchCorpus.church_case_089 : (∀ (church0 : Type _), ((∀ (church2 : Type _), (((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (church4 → church4)) → (church4 → church4))))) :=
  fun _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_089
