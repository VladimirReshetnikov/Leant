from pathlib import Path
import subprocess, os,hashlib
root=Path.cwd()
source='\n'.join([':set synth-library off',':set synth-providers off',':set synth-classical off',':set synth-debug on',':set synth-steps 4096',':set synth-window 1',':set synth-verify 1',':set synth-shown 1',':set synth-engine exference',':synth (∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) → G (∀ c : Type, X → c → c) (∀ d : Type, d → d))',':quit'])+'\n'
(root/'test-church/generated-probe/ambient-layered-debug.txt').write_text(source,encoding='utf-8')
exe=root/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/x/leant/build/leant/leant.exe'
print(hashlib.sha256(exe.read_bytes()).hexdigest(),flush=True)
with (root/'test-church/generated-probe/ambient-layered-debug.output.txt').open('w',encoding='utf-8') as out:
 p=subprocess.run([str(exe),'--plain'],input=source,stdout=out,stderr=subprocess.STDOUT,text=True,encoding='utf-8',env=dict(os.environ,LEANT_SYNTH_TIMEOUT='30'))
print(p.returncode)
