"""Index the thirteen reviewed final-run drifts without changing any baseline."""
from collections import Counter
import importlib.util
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
SHA = 'addfac35b9d82955fc871c177b582a8c043475c0171c22cb17977e0e9f5b9869'
CASES = [
    ('synth-manual', 'generated-manual-complete-review', [(13, ())]),
    ('synth-parametric-rankn', 'generated-parametric-complete-review', [
        (8, ()), (3, ('Demo.Secret',)), (6, ('Demo.Secret', 'Demo.secretValue'))]),
    ('synth-provider-argument-rankn', 'generated-provider-argument-final-review', [
        (6, ('ProviderLambda.Result', 'ProviderLambda.consume'))]),
    ('synth-provider-bound-context-head', 'generated-provider-bound-context-final-review', [
        (6, ('BoundContextHead.Pair', 'BoundContextHead.Token', 'BoundContextHead.chosen'))]),
    ('synth-provider-contextual-assignment', 'generated-provider-contextual-final-review', [
        (5, ('ContextualOnly.Token', 'ContextualOnly.chosen')),
        (3, ('HigherContext.Token', 'HigherContext.chosen'))]),
    ('synth-provider-higher-kind-assignment', 'generated-provider-higher-kind-final-review', [
        (6, ('Higher.VacuousToken', 'Higher.Wrap', 'Higher.vacuous')),
        (6, ('Higher.MultiVacuousToken', 'Higher.Triple', 'Higher.Wrap', 'Higher.multiVacuous')),
        (2, ('Higher.AlternativeToken', 'Higher.Wrap', 'Higher.alternative')),
        (3, ('Higher.AlternativeToken', 'Higher.Pair', 'Higher.alternative'))]),
    ('synth-provider-implicit-visible-result', 'generated-synth-provider-implicit-visible-result-final-review', [
        (5, ('ImplicitVisible.Result', 'ImplicitVisible.Token', 'ImplicitVisible.token')),
        (10, ('DomainCollision.Box', 'DomainCollision.Result', 'DomainCollision.selected'))]),
    ('synth-provider-metadata-fitting', 'generated-synth-provider-metadata-fitting-final-review', [
        (4, ('MetadataFitting.Marker', 'MetadataFitting.make'))]),
    ('synth-provider-refutation-fallback', 'generated-synth-provider-refutation-fallback-final-review', [
        (2, ('RefutationExference.impossible',)), (3, ('RefutationBoth.impossible',))]),
    ('synth-provider-structural-assignment', 'generated-synth-provider-structural-assignment-final-review', [
        (3, ('StructuralContext.Fixed', 'StructuralContext.Token', 'StructuralContext.choose'))]),
    ('synth-quantified-provider', 'generated-synth-quantified-provider-final-review', [
        (5, ('Gap.Token', 'Gap.polyGlobal'))]),
    ('synth-quartic-rankn', 'generated-synth-quartic-rankn-final-review', [(10, ())]),
    ('synth-six-binder-rankn', 'generated-synth-six-binder-rankn-final-review', [
        (5, ('SixBinder.Token', 'SixBinder.chosen'))]),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def inventory(values):
    assert len(values) == 1, values
    if values[0] == 'does not depend on any axioms':
        return ()
    match = re.fullmatch(r'depends on axioms: \[([^\]]*)\]', values[0], re.S)
    assert match, values
    return tuple(sorted(word.strip() for word in match[1].split(',')))


spec = importlib.util.spec_from_file_location('drift', Path(__file__).with_name('replay_golden_drift.py'))
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
rows = []
for fixture, directory, allowed in CASES:
    report_path = ROOT / 'test-church' / directory / 'results.json'
    report = read(report_path)
    row = report['fixtures'][0]
    assert row['fixture'] == fixture + '.txt'
    assert row['status'] == 'passed' and row['lost_successful_queries'] == 0
    assert row['leant_executable_sha256'] == SHA
    source = ROOT / 'test' / row['fixture']
    capture = Path(row['raw_capture_path'])
    assert digest(source) == row['source_sha256']
    assert digest(capture) == row['raw_capture_sha256']
    current_queries = helper.validate_correspondence(
        source.read_text(encoding='utf-8-sig'), capture.read_text(encoding='utf-8-sig'))
    actual = Counter()
    changed = list(row['changed_queries'])
    evidence = [{'path': str(report_path), 'sha256': digest(report_path)}]
    kernel_files = []
    for segment in row['segments']:
        assert segment['kernel_exit_code'] == 0 and segment['passed']
        assert set(segment['declarations']) == set(segment['axiom_inventories'])
        actual.update(inventory(value) for value in segment['axiom_inventories'].values())
        replay = Path(segment['replay_path'])
        kernel = replay.with_suffix('.kernel.txt')
        kernel_files.append({'source': str(replay), 'source_sha256': digest(replay),
                             'kernel_output': str(kernel), 'kernel_output_sha256': digest(kernel)})
    if fixture == 'synth-manual':
        prefix_dir = ROOT / 'test-church/generated-manual-prefix-review'
        prefix_path = prefix_dir / 'results.json'
        prefix = read(prefix_path)
        assert prefix['passed'] and prefix['kernel_exit_code'] == 0
        assert prefix['leant_executable_sha256'] == SHA
        assert prefix['source_file_sha256'] == digest(source)
        assert prefix['candidate_count'] == 8
        assert all(value == [] for value in prefix['axiom_inventories'].values())
        prefix_queries = helper.parse_queries((prefix_dir / 'actual-prefix.txt').read_text(encoding='utf-8-sig'))
        for query in prefix['changed_queries']:
            index = query['query_index']
            assert prefix_queries[index] == current_queries[index]
        changed = prefix['changed_queries'] + changed
        assert len({query['query_index'] for query in changed}) == len(changed)
        actual[()] += prefix['candidate_count']
        evidence.insert(0, {'path': str(prefix_path), 'sha256': digest(prefix_path)})
        kernel_files.insert(0, {'source': str(prefix_dir / 'ManualPrefix.lean'),
                               'source_sha256': digest(prefix_dir / 'ManualPrefix.lean'),
                               'kernel_output': str(prefix_dir / 'kernel-output.txt'),
                               'kernel_output_sha256': digest(prefix_dir / 'kernel-output.txt')})
    expected = Counter({tuple(sorted(names)): count for count, names in allowed})
    assert actual == expected, (fixture, actual, expected)
    assert sum(actual.values()) == sum(query['after_count'] for query in changed)
    rows.append({
        'fixture': row['fixture'],
        'changed_query_count': len(changed),
        'changed_query_indices': [query['query_index'] for query in changed],
        'actual_term_count': sum(actual.values()),
        'kernel_status': 'passed',
        'exact_axiom_inventory_counts': [
            {'term_count': count, 'axioms': list(names)} for names, count in sorted(actual.items())],
        'empty_axiom_count': actual[()],
        'source_query_count': row['source_query_count'],
        'successful_query_count': row['successful_query_count'],
        'lost_successful_queries': 0,
        'source_sha256': digest(source),
        'raw_capture_path': str(capture),
        'raw_capture_sha256': digest(capture),
        'reports': evidence,
        'kernel_files': kernel_files,
    })

summary = {
    'status': 'passed',
    'scope': 'Thirteen new ordinary baseline drifts from the complete final addfac run; excludes four previously reviewed/published baseline fixtures.',
    'leant_executable_sha256': SHA,
    'fixture_count': len(rows),
    'changed_query_count': sum(row['changed_query_count'] for row in rows),
    'actual_term_count': sum(row['actual_term_count'] for row in rows),
    'empty_axiom_count': sum(row['empty_axiom_count'] for row in rows),
    'supplied_premise_term_count': sum(row['actual_term_count'] - row['empty_axiom_count'] for row in rows),
    'lost_successful_queries': 0,
    'manual_prefix_note': 'The eight previously replayed prefix candidates match the completed final raw transcript exactly; combined with five final-query terms, counted once.',
    'diagnostic_note': 'Contextual-assignment retains two additional bounded-search progress notes for each failed Exference/both query. Distinct raw queue counts normalize to the same telemetry placeholder; no stronger negative claim or new error.',
    'baseline_note': 'This index does not update or compare final goldens. Root owns final normalized capture comparison and retains original live aggregate exit separately.',
    'excluded_prior_actual_term_count': 44,
    'fixtures': rows,
}
assert (summary['fixture_count'], summary['changed_query_count'], summary['actual_term_count'],
        summary['empty_axiom_count'], summary['supplied_premise_term_count']) == (13, 34, 114, 31, 83)
output = ROOT / 'test-church/generated-final-drift-index'
output.mkdir(exist_ok=True)
(output / 'results.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
lines = [
    '# Final ordinary-transcript drift review', '',
    f'Executable SHA256: `{SHA}`.', '',
    'All 114 exact displayed terms in 34 changed queries across 13 newly drifting fixtures passed independent Lean kernel replay. 31 have empty axiom inventories; 83 depend exactly on the fixture-declared premises listed below. No previously successful query lost its result. The four earlier reviewed baseline fixtures and their 44 terms are excluded.', '',
    '| Fixture | Changed queries | Actual terms replayed | Exact axiom inventory (term count) | Evidence |',
    '|---|---:|---:|---|---|',
]
for row in rows:
    inventories = '; '.join(
        f"{item['term_count']} × " + ('empty' if not item['axioms'] else ', '.join(item['axioms']))
        for item in row['exact_axiom_inventory_counts'])
    evidence = ', '.join(f"[report {i+1}]({Path(item['path']).as_posix()})" for i, item in enumerate(row['reports']))
    lines.append(f"| {row['fixture']} | {row['changed_query_count']} | {row['actual_term_count']} | {inventories} | {evidence} |")
lines += ['', summary['manual_prefix_note'], '', summary['diagnostic_note'], '', summary['baseline_note'], '']
(output / 'README.md').write_text('\n'.join(lines), encoding='utf-8')
print(json.dumps({key: summary[key] for key in ('status', 'fixture_count', 'changed_query_count', 'actual_term_count', 'empty_axiom_count', 'supplied_premise_term_count')}, indent=2))
