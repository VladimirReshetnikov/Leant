"""Replay changed ordinary synthesis terms in independent reset-local environments.

This ignored review aid never updates goldens. --log reconstructs complete
unified diffs; --captures-dir reads LEANT_GOLDEN_LOG_DIR captures. The executable
hash is caller-supplied capture provenance, not a fresh execution claim.
Changed proof-mode fixtures remain unsupported and fail closed.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
HUNK = re.compile(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@')
PROMPT = re.compile(r'^λ>[ \t]?(.*)$')
CANDIDATE = re.compile(r'^[ \t]+it([0-9]+)[ \t]+(.+)$')
VOLATILE = ('no Lake project', 'starting Lean backend', 'backend responding', 'replaying session')
DIAGNOSTIC = re.compile(r'^(?:note:|debug |warning:|error:|REPL error:|synthesis engine error:)')
RESULT_NAME = re.compile(r'\bit[0-9]*\b')


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def normalized(text):
    lines = [line.rstrip() for line in text.splitlines() if not line.startswith(VOLATILE)]
    return re.sub(r'queue limit pruned [0-9]+',
                  'queue limit pruned <machine-dependent>', '\n'.join(lines)) + '\n'


def apply_diff(before, lines):
    old, after = before.splitlines(), []
    offset = cursor = hunks = 0
    while cursor < len(lines):
        match = HUNK.match(lines[cursor])
        if not match:
            cursor += 1
            continue
        hunks += 1
        old_count, new_count = int(match[2] or '1'), int(match[4] or '1')
        start = int(match[1]) - (1 if old_count else 0)
        if start < offset or start > len(old):
            raise ValueError('overlapping or out-of-range diff hunk')
        after.extend(old[offset:start])
        offset, consumed, produced = start, 0, 0
        cursor += 1
        while consumed < old_count or produced < new_count:
            if cursor >= len(lines) or not lines[cursor] or lines[cursor][0] not in ' +-':
                raise ValueError('incomplete diff hunk')
            prefix, body = lines[cursor][0], lines[cursor][1:]
            if prefix in ' -':
                if offset >= len(old) or old[offset] != body:
                    raise ValueError(f'diff baseline mismatch at line {offset + 1}: {body!r}')
                offset += 1
                consumed += 1
            if prefix in ' +':
                after.append(body)
                produced += 1
            if consumed > old_count or produced > new_count:
                raise ValueError('diff hunk exceeds its recorded counts')
            cursor += 1
    if not hunks:
        raise ValueError('no complete unified-diff hunks found')
    after.extend(old[offset:])
    return '\n'.join(after) + '\n'


def command_blocks(text):
    blocks, current = [], None
    for line in text.splitlines():
        prompt = PROMPT.match(line)
        if prompt:
            current = {'command': prompt[1], 'lines': []}
            blocks.append(current)
        elif current is not None:
            current['lines'].append(line)
    return blocks


def parse_queries(text):
    queries, segment = [], 0
    for block in command_blocks(text):
        command = block['command']
        if command == ':reset':
            segment += 1
        if not command.startswith(':synth '):
            continue
        terms, active = [], None

        def finish():
            nonlocal active
            if active is not None:
                # Only empty separator lines are omitted. Continuation
                # indentation is part of the exact displayed term.
                while active['lines'] and not active['lines'][-1].strip():
                    active['lines'].pop()
                term = '\n'.join(active['lines'])
                if re.search(r'\b(?:sorry|admit|sorryAx)\b', term):
                    raise ValueError('unchecked proof marker in displayed candidate')
                terms.append({'label': active['label'], 'term': term})
                active = None

        for line in block['lines']:
            match = CANDIDATE.match(line)
            if match:
                finish()
                active = {'label': int(match[1]), 'lines': [match[2]]}
            elif DIAGNOSTIC.match(line):
                finish()
            elif active is not None:
                active['lines'].append(line)
        finish()
        if [term['label'] for term in terms] != list(range(1, len(terms) + 1)):
            raise ValueError('duplicate, missing, or out-of-order candidate label')
        queries.append({'type': command[len(':synth '):], 'segment': segment, 'terms': terms})
    return queries


def validate_source(source):
    commands = []
    for line in source.splitlines():
        if not line.startswith(':'):
            continue
        supported_setting = line.startswith(':set ') and not any(
            'prove' in part for part in line.split()[1:2])
        if (line in (':reset', ':quit') or supported_setting
                or line.startswith((':synth ', ':type ', ':print '))):
            commands.append(line)
        else:
            raise ValueError(f'unsupported proof/state command: {line}')
    return commands


def validate_correspondence(source, text):
    expected = validate_source(source)
    blocks = [block for block in command_blocks(text) if block['command'].startswith(':')]
    if [block['command'] for block in blocks] != expected:
        raise ValueError('source/output command sequence differs (including settings and resets)')
    for block in blocks:
        if block['command'] == ':reset' and block['lines'][:1] != ['session reset']:
            raise ValueError('reset was not acknowledged')
        if block['command'].startswith(':set synth-engine '):
            engine = block['command'].split()[-1]
            if block['lines'][:1] != [f'synth engine: {engine}']:
                raise ValueError('engine selection was not acknowledged')
    queries = parse_queries(text)
    if [row['type'] for row in queries] != [line[len(':synth '):] for line in expected if line.startswith(':synth ')]:
        raise ValueError('source/output synthesis query sequence differs')
    return queries


def replay_segments(source, before, after):
    if len(before) != len(after) or any(
            (left['type'], left['segment']) != (right['type'], right['segment'])
            for left, right in zip(before, after)):
        raise ValueError('old/new query sequences or reset segments differ')
    if any(left['terms'] and not right['terms'] for left, right in zip(before, after)):
        raise ValueError('a previously successful query lost all candidates')
    changed = {i for i, pair in enumerate(zip(before, after)) if pair[0] != pair[1]}
    segments = [{'index': 0, 'lines': [], 'declarations': [], 'omitted_inspections': []}]
    current, query_index, functions, rows = segments[0], 0, set(), []
    for line_number, line in enumerate(source.splitlines(), start=1):
        if line == ':reset':
            current = {'index': len(segments), 'lines': [], 'declarations': [], 'omitted_inspections': []}
            segments.append(current)
            functions = set()
        elif line.startswith(':synth '):
            if query_index in changed:
                left, right = before[query_index], after[query_index]
                previous = {term['term'] for term in left['terms']}
                actual = {term['term'] for term in right['terms']}
                rows.append({'query_index': query_index, 'segment': current['index'],
                             'source_line': line_number, 'type': right['type'],
                             'before_count': len(left['terms']), 'after_count': len(right['terms']),
                             'added': sorted(actual - previous), 'removed': sorted(previous - actual)})
                for term in right['terms']:
                    if RESULT_NAME.search(term['term']):
                        raise ValueError('candidate refers to an unreconstructed REPL result binding')
                    name = f'goldenReplayQuery{query_index}Candidate{term["label"]}'
                    current['lines'].extend([
                        f'noncomputable def {name} : {right["type"]} :=',
                        '\n'.join('  ' + part for part in term['term'].splitlines()),
                        f'#print axioms {name}',
                    ])
                    current['declarations'].append(name)
            query_index += 1
        elif line.startswith(':'):
            continue  # validate_source rejected unsupported state transitions.
        else:
            declaration = re.match(r'^(?:(?:private|protected|noncomputable|unsafe)\s+)*def\s+(\S+)', line)
            if declaration:
                functions.add(declaration[1])
            first = line.split(maxsplit=1)[0] if line.strip() else ''
            inspection = line.startswith(('#eval ', '#check ', '#print '))
            # Ordinary evaluations create private REPL result bindings only.
            # Omit their inspection/output, but reject later retained uses of
            # those names rather than inventing definitions for their values.
            evaluation = not line[:1].isspace() and (
                bool(re.match(r'^[0-9]', line)) or first in functions
                or bool(re.match(r'^it[0-9]*(?:\s|$)', line)))
            if inspection or evaluation:
                current['omitted_inspections'].append({'source_line': line_number, 'text': line})
            else:
                if RESULT_NAME.search(line) and not line.lstrip().startswith('--'):
                    raise ValueError('source declaration uses an unreconstructed REPL result binding')
                current['lines'].append(line)
    for segment in segments:
        # Separate modules, rather than namespaces, prevent declaration,
        # instance, notation, option, and universe leakage across :reset.
        segment['source'] = ('-- Independent source reset segment ' + str(segment['index']) + '\n'
                             + '\n'.join(segment.pop('lines')) + '\n')
    return rows, segments


def fixture_name(value):
    name = value if value.endswith('.txt') else value + '.txt'
    if not re.fullmatch(r'[A-Za-z0-9_-]+\.txt', name):
        raise ValueError(f'unsupported fixture filename: {value!r}')
    return name


def inputs_from_log(path, selected):
    result = []
    for section in re.split(r'(?m)^(?:FAIL|ok   ) ', path.read_text(encoding='utf-8-sig'))[1:]:
        lines, title = section.splitlines(), section.splitlines()[0]
        if not re.fullmatch(r'[A-Za-z0-9_-]+\.txt', title):
            if title.split()[0] in selected:
                raise ValueError(f'cannot reconstruct unsuccessful fixture: {title}; use raw captures')
            continue
        if selected and title not in selected:
            continue
        if len(lines) > 1 and lines[1].startswith('--- '):
            result.append((title, lines[1:]))
    if len({name for name, _ in result}) != len(result):
        raise ValueError('duplicate completed fixture diff')
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    inputs = parser.add_mutually_exclusive_group()
    inputs.add_argument('--log', type=Path)
    inputs.add_argument('--captures-dir', type=Path, help='raw LEANT_GOLDEN_LOG_DIR directory')
    parser.add_argument('--fixture', action='append', default=[], help='fixture stem or .txt; repeatable')
    parser.add_argument('--executable-sha256', required=True, help='hash recorded for the captured Leant build')
    parser.add_argument('--output', type=Path, default=ROOT / 'test-church/generated-golden-drift')
    parser.add_argument('--replay', action='store_true', help='run Lean; omission only prepares files')
    args = parser.parse_args(argv)
    if not re.fullmatch(r'[0-9a-fA-F]{64}', args.executable_sha256):
        parser.error('--executable-sha256 requires 64 hexadecimal digits')
    selected = {fixture_name(name) for name in args.fixture}
    if args.captures_dir:
        inputs = [(fixture_name(path.name[:-len('.output.txt')]), path)
                  for path in sorted(args.captures_dir.glob('*.output.txt'))]
        inputs = [(name, path) for name, path in inputs if not selected or name in selected]
        mode = 'raw_capture'
    else:
        inputs = inputs_from_log(args.log or ROOT / 'test-church/generated/final-goldens.log', selected)
        mode = 'reconstructed_diff'
    if not inputs or selected - {name for name, _ in inputs}:
        parser.error('no complete input for every selected fixture')
    args.output.mkdir(parents=True, exist_ok=True)
    report = {'leant_executable_sha256': args.executable_sha256.lower(),
              'hash_provenance': 'caller-supplied capture hash; this helper does not run Leant',
              'input_mode': mode, 'kernel_replay_requested': args.replay, 'fixtures': []}
    failed = False
    for fixture, captured in inputs:
        source_path = ROOT / 'test' / fixture
        source_bytes = source_path.read_bytes()
        source = source_bytes.decode('utf-8-sig')
        baseline_bytes = source_path.with_suffix('.golden').read_bytes()
        old = baseline_bytes.decode('utf-8-sig')
        actual = captured.read_text(encoding='utf-8-sig') if mode == 'raw_capture' else apply_diff(normalized(old), captured)
        stem = fixture[:-4]
        (args.output / (stem + '.actual.txt')).write_text(actual, encoding='utf-8')
        row = {'fixture': fixture, 'golden_before_sha256': sha256(baseline_bytes),
               'source_sha256': sha256(source_bytes), 'actual_sha256': sha256(actual.encode('utf-8')),
               'input_mode': mode, 'leant_executable_sha256': args.executable_sha256.lower()}
        if mode == 'raw_capture':
            row['raw_capture_path'] = str(captured.resolve())
            row['raw_capture_sha256'] = sha256(captured.read_bytes())
        try:
            validate_source(source)
        except ValueError:
            if normalized(actual) == normalized(old):
                row.update(status='unchanged_unsupported_mode_not_replayed', changed_queries=[], segments=[])
                report['fixtures'].append(row)
                print(f'{fixture}: unchanged unsupported mode; not replayed', flush=True)
                continue
            raise
        before = validate_correspondence(source, old)
        after = validate_correspondence(source, actual)
        changes, segments = replay_segments(source, before, after)
        row.update(status='prepared', changed_queries=changes, source_query_count=len(after),
                   successful_query_count=sum(bool(query['terms']) for query in after),
                   lost_successful_queries=0, segments=[])
        for segment in segments:
            if not segment['declarations']:
                continue
            suffix = f'{stem}.reset{segment["index"]}'
            target = args.output / (suffix + '.lean')
            target.write_text(segment.pop('source'), encoding='utf-8')
            segment['replay_path'] = str(target.resolve())
            if args.replay:
                result = subprocess.run(['lean', '+leanprover/lean4:v4.32.0', str(target.resolve())],
                                        cwd=ROOT, capture_output=True, text=True, encoding='utf-8')
                output = result.stdout + result.stderr
                (args.output / (suffix + '.kernel.txt')).write_text(output, encoding='utf-8')
                inventories = {name: re.findall(r"(?m)^'" + re.escape(name)
                    + r"' (does not depend on any axioms|depends on axioms:\s*\[[^\]]*\])", output)
                    for name in segment['declarations']}
                passed = (result.returncode == 0 and 'sorryAx' not in output
                          and all(len(items) == 1 for items in inventories.values()))
                segment.update(kernel_exit_code=result.returncode, passed=passed, axiom_inventories=inventories)
                failed |= not passed
            row['segments'].append(segment)
        if args.replay:
            row['status'] = 'passed' if all(segment['passed'] for segment in row['segments']) else 'failed'
        count = sum(len(segment['declarations']) for segment in row['segments'])
        print(f'{fixture}: {len(changes)} changed queries; {count} actual terms; {row["status"]}', flush=True)
        report['fixtures'].append(row)
    (args.output / 'results.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
