set_option linter.unusedVariables false
example : (∀ (F : Type → Type → Type → Type → Type → Type → Type → Type → Type) (A B C D E G H I : Type), (∀ a b c d e f g h : Type, F a b c d e f g h) → F I H G E D C B A) := fun _ _ _ _ _ _ _ _ _ x => x _ _ _ _ _ _ _ _
example : (∀ (F : Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type) (A B C D E G H I J K L M : Type), (∀ a b c d e f g h i j k l : Type, F a b c d e f g h i j k l) → F M L K J I H G E D C B A) := fun _ _ _ _ _ _ _ _ _ _ _ _ _ x => x _ _ _ _ _ _ _ _ _ _ _ _
example : (∀ F : Type 1 → Type 1, (∀ a : Type 1, a → F a) → F (∀ b : Type, b → b)) := fun _ f => f _ (fun _ x => x)
example : (∀ F : Type 1 → Type 1 → Type 1, (∀ a b : Type 1, a → b → F a b) → F (∀ a : Type, a → a) (∀ b : Type, b → b → b)) := fun _ f => f _ _ (fun _ x => x) (fun _ x _ => x)
example : (∀ F : Type 1 → Type 1, (∀ {a : Type 1}, a → F a) → F (∀ {b : Type}, b → b)) := fun _ f => f (fun x => x)
example : (∀ F : Type 1 → Type 1, (Unit → ∀ a : Type 1, a → F a) → F (∀ b : Type, b → b)) := fun _ f => f () _ (fun _ x => x)
example : (∀ F : Type 1 → Type 1, (Unit → ∀ {a : Type 1}, a → F a) → F (∀ {b : Type}, b → b)) := fun _ f => f () (fun x => x)
example : (∀ R : Type, ((∀ {A : Type}, ((∀ {B : Type}, B → B) → A) → A) → R) → R) := fun _ f => f (fun g => g (fun x => x))
example : (∀ R : Type, (((∀ {A : Type}, A → A) → (∀ {B : Type}, B → B)) → R) → R) := fun _ f => f (fun _ => fun x => x)
example : (∀ a b c : Type _, (a → b) → (c → b) → (∀ r : Type _, (a → r) → (c → r) → r) → b) := fun _ _ _ f g h => h _ f g
