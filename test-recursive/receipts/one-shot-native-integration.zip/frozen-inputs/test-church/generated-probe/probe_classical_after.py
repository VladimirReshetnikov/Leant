from pathlib import Path
import hashlib, json, subprocess, time

root=Path(__file__).resolve().parents[2]
exe=root/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/x/leant/build/leant/leant.exe'
out=root/'test-church/generated-classical-bounded-final'
out.mkdir(exist_ok=True)
source='\n'.join([
    ':set synth-debug on', ':set synth-timeout 3',
    ':synth (∀ p q : Prop, (p → q) ∨ (q → p))', ':quit', '',
])
(out/'input.txt').write_text(source,encoding='utf-8')
before=hashlib.sha256(exe.read_bytes()).hexdigest()
started=time.monotonic()
with (out/'output.txt').open('w',encoding='utf-8') as output:
    process=subprocess.Popen([str(exe),'--plain'],cwd=root,stdin=subprocess.PIPE,
        stdout=output,stderr=subprocess.STDOUT,text=True,encoding='utf-8')
    expired=False
    try:
        process.communicate(source,timeout=45)
    except subprocess.TimeoutExpired:
        expired=True
        subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True)
        process.wait(timeout=10)
report=dict(returncode=process.returncode,external_timeout=expired,
    seconds=time.monotonic()-started,leant_executable_sha256=before,
    leant_executable_unchanged=before==hashlib.sha256(exe.read_bytes()).hexdigest())
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report),flush=True)
