module Main where
import Control.Concurrent
import Control.Exception
import Control.Monad
import Data.Time.Clock
import System.Environment
import System.IO
import Leant.Backend
import Leant.Json

main :: IO ()
main = do
  hSetBuffering stdout NoBuffering
  args <- getArgs
  case args of
    ["env", childMode] -> do
      void $ forkIO $ forever $ threadDelay 10000
      void $ hGetLine stdin
      hPutStrLn stderr "child received request"
      hFlush stderr
      when (childMode == "child-partial") $ do
        hPutStr stdout "{\"env\":"
        hFlush stdout
      when (childMode == "child-tail") $ do
        hPutStrLn stdout "{\"env\":1}\n"
        replicateM_ 100 $ hPutStrLn stdout "unread tail"
        hFlush stdout
      threadDelay 30000000
    _ -> do
      me <- getExecutablePath
      print =<< getCurrentTime
      putStrLn "spawning"
      let childMode = case args of
            ["partial"] -> "child-partial"
            ["tail"] -> "child-tail"
            _ -> "child"
      backend <- spawnBackend $ BackendConfig me childMode "C:\\Leant"
      void $ forkIO $ do
        threadDelay 2000000
        putStrLn "independent timer fired"
      putStrLn "spawned; entering one-second request"
      result <- request backend (Just 1) $ JObj []
      print =<< getCurrentTime
      print result
      putStrLn "killing"
      killBackend backend
      putStrLn "killed"
