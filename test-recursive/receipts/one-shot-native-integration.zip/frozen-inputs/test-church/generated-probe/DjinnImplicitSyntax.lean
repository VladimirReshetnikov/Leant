set_option linter.unusedVariables false

def closed : ∀ (Seed : Type) (G : Type 1 → Type 1 → Type 1), Seed →
    (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) →
    G (∀ {c : Type}, c → c) (∀ d : Type, d → d) :=
  fun _ _ x f => f x _ (fun {_} y => y) x _ (fun _ z => z)
#print axioms closed

def openExplicit : ∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed →
    (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) →
    G (∀ {c : Type}, X → c → c) (∀ {d : Type}, d → d) :=
  fun _ _ _ x f => f x _ (fun {_} _ y => y) x _ (fun z => z)
#print axioms openExplicit

def openImplicit : ∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed →
    (Seed → ∀ {a : Type 1}, a → Seed → ∀ {b : Type 1}, b → G a b) →
    G (∀ {c : Type}, X → c → c) (∀ {d : Type}, d → d) :=
  fun _ _ _ x f => f x (fun {_} _ y => y) x (fun z => z)
#print axioms openImplicit
