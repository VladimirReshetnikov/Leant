-- Independent source reset segment 0
namespace MetadataFitting

axiom Marker (a : Type 1) : Type

class Choice (a : Type 1) : Prop where
  witness : True

instance implicitChoice : Choice (∀ {A : Type}, A → A) :=
  ⟨True.intro⟩

instance explicitChoice : Choice (∀ (A : Type), A → A) :=
  ⟨True.intro⟩

axiom make {a : Type 1} [Choice a] : a → Marker a

end MetadataFitting

noncomputable def goldenReplayQuery0Candidate1 : MetadataFitting.Marker (∀ (A : Type), A → A) :=
  MetadataFitting.make (fun _ x => x)
#print axioms goldenReplayQuery0Candidate1
noncomputable def goldenReplayQuery0Candidate2 : MetadataFitting.Marker (∀ (A : Type), A → A) :=
  MetadataFitting.make («a» := (∀ (a0_0 : Type _), a0_0 → a0_0)) (fun _ x => x)
#print axioms goldenReplayQuery0Candidate2
noncomputable def goldenReplayQuery1Candidate1 : MetadataFitting.Marker (∀ (A : Type), A → A) :=
  MetadataFitting.make (fun _ x => x)
#print axioms goldenReplayQuery1Candidate1
noncomputable def goldenReplayQuery1Candidate2 : MetadataFitting.Marker (∀ (A : Type), A → A) :=
  MetadataFitting.make («a» := (∀ (a0_0 : Type _), a0_0 → a0_0)) (fun _ x => x)
#print axioms goldenReplayQuery1Candidate2
