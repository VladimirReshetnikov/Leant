-- Independent source reset segment 0
namespace BoundContextHead

axiom Token : Type
axiom Pair : Type → Type → Type

class Choice (F : Type → Type) : Prop where
  witness : True

instance : Choice (Pair Nat) := ⟨True.intro⟩

axiom chosen {F : Type → Type → Type} [Choice (F Nat)] : Token

end BoundContextHead

noncomputable def goldenReplayQuery1Candidate1 : BoundContextHead.Token :=
  BoundContextHead.chosen («F» := BoundContextHead.Pair)
#print axioms goldenReplayQuery1Candidate1
noncomputable def goldenReplayQuery1Candidate2 : BoundContextHead.Token :=
  match Sum.inl (BoundContextHead.chosen («F» := BoundContextHead.Pair)) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery1Candidate2
noncomputable def goldenReplayQuery1Candidate3 : BoundContextHead.Token :=
  match Sum.inr (BoundContextHead.chosen («F» := BoundContextHead.Pair)) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery1Candidate3
noncomputable def goldenReplayQuery2Candidate1 : BoundContextHead.Token :=
  BoundContextHead.chosen («F» := BoundContextHead.Pair)
#print axioms goldenReplayQuery2Candidate1
noncomputable def goldenReplayQuery2Candidate2 : BoundContextHead.Token :=
  match Sum.inl (BoundContextHead.chosen («F» := BoundContextHead.Pair)) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery2Candidate2
noncomputable def goldenReplayQuery2Candidate3 : BoundContextHead.Token :=
  match Sum.inr (BoundContextHead.chosen («F» := BoundContextHead.Pair)) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery2Candidate3
