-- Generated exclusively from synthesized candidates and the manifest.
set_option linter.unusedVariables false
def ChurchCorpus.integerZero : Int := 0

-- Church.hs:229 uncons (total)
def ChurchCorpus.church_case_024 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church4 : Type _), (church4 → (((∀ (church3 : Type _), ((church0 → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → church3)) → church3)) → church4) → church4))))) :=
  fun _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_024
