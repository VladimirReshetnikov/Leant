-- Independent source reset segment 0
noncomputable def goldenReplayQuery1Candidate1 : (∀ Q R Z M : Type, (∀ A B C D E : Type, Q) → (∀ A B C D E : Type, R) → (∀ A B C D E : Type, Z) → (∀ A B C D E : Type, M) → (∀ V W X Y U : Type, Q) × (∀ V W X Y U : Type, R) × (∀ V W X Y U : Type, Z) × (∀ V W X Y U : Type, M) × (∀ E : Type, E → E) × (∀ F : Type, F → F) × (∀ G : Type, G → G) × (∀ H : Type, H → H)) :=
  fun _ _ _ _ f g h f1 => ⟨f, ⟨g, ⟨h, ⟨f1, ⟨fun _ x => x, ⟨fun _ y => y, ⟨fun _ z => z, fun _ w => w⟩⟩⟩⟩⟩⟩⟩
#print axioms goldenReplayQuery1Candidate1
noncomputable def goldenReplayQuery1Candidate2 : (∀ Q R Z M : Type, (∀ A B C D E : Type, Q) → (∀ A B C D E : Type, R) → (∀ A B C D E : Type, Z) → (∀ A B C D E : Type, M) → (∀ V W X Y U : Type, Q) × (∀ V W X Y U : Type, R) × (∀ V W X Y U : Type, Z) × (∀ V W X Y U : Type, M) × (∀ E : Type, E → E) × (∀ F : Type, F → F) × (∀ G : Type, G → G) × (∀ H : Type, H → H)) :=
  fun _ _ _ _ f g h f1 => ⟨f, ⟨g, ⟨h, ⟨f1, ⟨fun _ x => x, ⟨fun _ y => y, ⟨fun _ z => z, fun _ w => match Sum.inl w with | .inl a => a | .inr b => b⟩⟩⟩⟩⟩⟩⟩
#print axioms goldenReplayQuery1Candidate2
noncomputable def goldenReplayQuery1Candidate3 : (∀ Q R Z M : Type, (∀ A B C D E : Type, Q) → (∀ A B C D E : Type, R) → (∀ A B C D E : Type, Z) → (∀ A B C D E : Type, M) → (∀ V W X Y U : Type, Q) × (∀ V W X Y U : Type, R) × (∀ V W X Y U : Type, Z) × (∀ V W X Y U : Type, M) × (∀ E : Type, E → E) × (∀ F : Type, F → F) × (∀ G : Type, G → G) × (∀ H : Type, H → H)) :=
  fun _ _ _ _ f g h f1 => ⟨f, ⟨g, ⟨h, ⟨f1, ⟨fun _ x => x, ⟨fun _ y => y, ⟨fun _ z => z, fun _ w => match Sum.inr w with | .inl a => a | .inr b => b⟩⟩⟩⟩⟩⟩⟩
#print axioms goldenReplayQuery1Candidate3
noncomputable def goldenReplayQuery1Candidate4 : (∀ Q R Z M : Type, (∀ A B C D E : Type, Q) → (∀ A B C D E : Type, R) → (∀ A B C D E : Type, Z) → (∀ A B C D E : Type, M) → (∀ V W X Y U : Type, Q) × (∀ V W X Y U : Type, R) × (∀ V W X Y U : Type, Z) × (∀ V W X Y U : Type, M) × (∀ E : Type, E → E) × (∀ F : Type, F → F) × (∀ G : Type, G → G) × (∀ H : Type, H → H)) :=
  fun _ _ _ _ f g h f1 => ⟨f, ⟨g, ⟨h, ⟨f1, ⟨fun _ x => x, ⟨fun _ y => y, ⟨fun _ z => match Sum.inl z with | .inl a => a | .inr b => b, fun _ w => w⟩⟩⟩⟩⟩⟩⟩
#print axioms goldenReplayQuery1Candidate4
noncomputable def goldenReplayQuery1Candidate5 : (∀ Q R Z M : Type, (∀ A B C D E : Type, Q) → (∀ A B C D E : Type, R) → (∀ A B C D E : Type, Z) → (∀ A B C D E : Type, M) → (∀ V W X Y U : Type, Q) × (∀ V W X Y U : Type, R) × (∀ V W X Y U : Type, Z) × (∀ V W X Y U : Type, M) × (∀ E : Type, E → E) × (∀ F : Type, F → F) × (∀ G : Type, G → G) × (∀ H : Type, H → H)) :=
  fun _ _ _ _ f g h f1 => ⟨f, ⟨g, ⟨h, ⟨f1, ⟨fun _ x => x, ⟨fun _ y => y, ⟨fun _ z => match Sum.inr z with | .inl a => a | .inr b => b, fun _ w => w⟩⟩⟩⟩⟩⟩⟩
#print axioms goldenReplayQuery1Candidate5
noncomputable def goldenReplayQuery2Candidate1 : (∀ Q R Z M : Type, (∀ A B C D E : Type, Q) → (∀ A B C D E : Type, R) → (∀ A B C D E : Type, Z) → (∀ A B C D E : Type, M) → (∀ V W X Y U : Type, Q) × (∀ V W X Y U : Type, R) × (∀ V W X Y U : Type, Z) × (∀ V W X Y U : Type, M) × (∀ E : Type, E → E) × (∀ F : Type, F → F) × (∀ G : Type, G → G) × (∀ H : Type, H → H)) :=
  fun _ _ _ _ f g h f1 => ⟨f, ⟨g, ⟨h, ⟨f1, ⟨fun _ x => x, ⟨fun _ y => y, ⟨fun _ z => z, fun _ w => w⟩⟩⟩⟩⟩⟩⟩
#print axioms goldenReplayQuery2Candidate1
noncomputable def goldenReplayQuery2Candidate2 : (∀ Q R Z M : Type, (∀ A B C D E : Type, Q) → (∀ A B C D E : Type, R) → (∀ A B C D E : Type, Z) → (∀ A B C D E : Type, M) → (∀ V W X Y U : Type, Q) × (∀ V W X Y U : Type, R) × (∀ V W X Y U : Type, Z) × (∀ V W X Y U : Type, M) × (∀ E : Type, E → E) × (∀ F : Type, F → F) × (∀ G : Type, G → G) × (∀ H : Type, H → H)) :=
  fun _ _ _ _ f g h f1 => ⟨f, ⟨g, ⟨h, ⟨fun x y _ _ _ => f1 x x x x y, ⟨fun _ z => z, ⟨fun _ w => w, ⟨fun _ x1 => x1, fun _ x2 => x2⟩⟩⟩⟩⟩⟩⟩
#print axioms goldenReplayQuery2Candidate2
noncomputable def goldenReplayQuery2Candidate3 : (∀ Q R Z M : Type, (∀ A B C D E : Type, Q) → (∀ A B C D E : Type, R) → (∀ A B C D E : Type, Z) → (∀ A B C D E : Type, M) → (∀ V W X Y U : Type, Q) × (∀ V W X Y U : Type, R) × (∀ V W X Y U : Type, Z) × (∀ V W X Y U : Type, M) × (∀ E : Type, E → E) × (∀ F : Type, F → F) × (∀ G : Type, G → G) × (∀ H : Type, H → H)) :=
  fun _ _ _ _ f g h f1 => ⟨f, ⟨g, ⟨h, ⟨fun x _ _ _ _ => f1 x x x x x, ⟨fun _ y => y, ⟨fun _ z => z, ⟨fun _ w => w, fun _ x1 => x1⟩⟩⟩⟩⟩⟩⟩
#print axioms goldenReplayQuery2Candidate3
noncomputable def goldenReplayQuery2Candidate4 : (∀ Q R Z M : Type, (∀ A B C D E : Type, Q) → (∀ A B C D E : Type, R) → (∀ A B C D E : Type, Z) → (∀ A B C D E : Type, M) → (∀ V W X Y U : Type, Q) × (∀ V W X Y U : Type, R) × (∀ V W X Y U : Type, Z) × (∀ V W X Y U : Type, M) × (∀ E : Type, E → E) × (∀ F : Type, F → F) × (∀ G : Type, G → G) × (∀ H : Type, H → H)) :=
  fun _ _ _ _ f g h f1 => ⟨f, ⟨g, ⟨h, ⟨f1, ⟨fun _ x => x, ⟨fun _ y => y, ⟨fun _ z => z, fun _ w => match Sum.inl w with | .inl a => a | .inr b => b⟩⟩⟩⟩⟩⟩⟩
#print axioms goldenReplayQuery2Candidate4
noncomputable def goldenReplayQuery2Candidate5 : (∀ Q R Z M : Type, (∀ A B C D E : Type, Q) → (∀ A B C D E : Type, R) → (∀ A B C D E : Type, Z) → (∀ A B C D E : Type, M) → (∀ V W X Y U : Type, Q) × (∀ V W X Y U : Type, R) × (∀ V W X Y U : Type, Z) × (∀ V W X Y U : Type, M) × (∀ E : Type, E → E) × (∀ F : Type, F → F) × (∀ G : Type, G → G) × (∀ H : Type, H → H)) :=
  fun _ _ _ _ f g h f1 => ⟨f, ⟨g, ⟨h, ⟨f1, ⟨fun _ x => x, ⟨fun _ y => y, ⟨fun _ z => z, fun _ w => match Sum.inr w with | .inl a => a | .inr b => b⟩⟩⟩⟩⟩⟩⟩
#print axioms goldenReplayQuery2Candidate5
