set_option linter.unusedVariables false
noncomputable section
def ChurchFixture.case0 : (∀ (F : Type → Type → Type → Type → Type → Type → Type → Type → Type) (A B C D E G H I : Type), (∀ a b c d e f g h : Type, F a b c d e f g h) → F I H G E D C B A) :=
  fun _ _ _ _ _ _ _ _ _ x => x _ _ _ _ _ _ _ _
#print axioms ChurchFixture.case0
def ChurchFixture.case1 : (∀ (F : Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type) (A B C D E G H I J K L M : Type), (∀ a b c d e f g h i j k l : Type, F a b c d e f g h i j k l) → F M L K J I H G E D C B A) :=
  fun _ _ _ _ _ _ _ _ _ _ _ _ _ x => x _ _ _ _ _ _ _ _ _ _ _ _
#print axioms ChurchFixture.case1
def ChurchFixture.case2 : (∀ F : Type 1 → Type 1, (∀ a : Type 1, a → F a) → F (∀ b : Type, b → b)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms ChurchFixture.case2
def ChurchFixture.case4 : (∀ (F : Type 1 → Type 1) (A : Type), (∀ a : Type 1, a → F a) → F (∀ B : Type, A → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms ChurchFixture.case4
def ChurchFixture.case5 : (∀ F : Type 1 → Type 1, (∀ {a : Type 1}, a → F a) → F (∀ {b : Type}, b → b)) :=
  fun _ f => f (fun x => x)
#print axioms ChurchFixture.case5
def ChurchFixture.case6 : (∀ F : Type 1 → Type 1, (Unit → ∀ a : Type 1, a → F a) → F (∀ b : Type, b → b)) :=
  fun _ f => f ⟨⟩ _ (fun _ x => x)
#print axioms ChurchFixture.case6
def ChurchFixture.case7 : (∀ F : Type 1 → Type 1, (Unit → ∀ {a : Type 1}, a → F a) → F (∀ {b : Type}, b → b)) :=
  fun _ f => f ⟨⟩ (fun x => x)
#print axioms ChurchFixture.case7
def ChurchFixture.case8 : (∀ R : Type, ((∀ {A : Type}, ((∀ {B : Type}, B → B) → A) → A) → R) → R) :=
  fun _ f => f (fun g => g (fun x => x))
#print axioms ChurchFixture.case8
def ChurchFixture.case9 : (∀ R : Type, (((∀ {A : Type}, A → A) → (∀ {B : Type}, B → B)) → R) → R) :=
  fun _ f => f (fun _ => fun x => x)
#print axioms ChurchFixture.case9
def ChurchFixture.case10 : (∀ a b c : Type _, (a → b) → (c → b) → (∀ r : Type _, (a → r) → (c → r) → r) → b) :=
  fun _ _ _ f g h => h _ f g
#print axioms ChurchFixture.case10
def ChurchFixture.case11 : (∀ (F : Type → Type → Type → Type → Type → Type → Type → Type → Type) (A B C D E G H I : Type), (∀ a b c d e f g h : Type, F a b c d e f g h) → F I H G E D C B A) :=
  fun _ _ _ _ _ _ _ _ _ x => x _ _ _ _ _ _ _ _
#print axioms ChurchFixture.case11
def ChurchFixture.case12 : (∀ (F : Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type) (A B C D E G H I J K L M : Type), (∀ a b c d e f g h i j k l : Type, F a b c d e f g h i j k l) → F M L K J I H G E D C B A) :=
  fun _ _ _ _ _ _ _ _ _ _ _ _ _ x => x _ _ _ _ _ _ _ _ _ _ _ _
#print axioms ChurchFixture.case12
def ChurchFixture.case13 : (∀ F : Type 1 → Type 1, (∀ a : Type 1, a → F a) → F (∀ b : Type, b → b)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms ChurchFixture.case13
def ChurchFixture.case14 : (∀ F : Type 1 → Type 1 → Type 1, (∀ a b : Type 1, a → b → F a b) → F (∀ a : Type, a → a) (∀ b : Type, b → b → b)) :=
  fun _ f => f _ _ (fun _ x => x) (fun _ _ y => y)
#print axioms ChurchFixture.case14
def ChurchFixture.case15 : (∀ (F : Type 1 → Type 1) (A : Type), (∀ a : Type 1, a → F a) → F (∀ B : Type, A → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms ChurchFixture.case15
def ChurchFixture.case16 : (∀ F : Type 1 → Type 1, (∀ {a : Type 1}, a → F a) → F (∀ {b : Type}, b → b)) :=
  fun _ f => f (fun x => x)
#print axioms ChurchFixture.case16
def ChurchFixture.case17 : (∀ F : Type 1 → Type 1, (Unit → ∀ a : Type 1, a → F a) → F (∀ b : Type, b → b)) :=
  fun _ f => let g := f ⟨⟩; g _ (fun _ x => x)
#print axioms ChurchFixture.case17
def ChurchFixture.case18 : (∀ F : Type 1 → Type 1, (Unit → ∀ {a : Type 1}, a → F a) → F (∀ {b : Type}, b → b)) :=
  fun _ f => let g := f ⟨⟩; g (fun x => x)
#print axioms ChurchFixture.case18
def ChurchFixture.case19 : (∀ R : Type, ((∀ {A : Type}, ((∀ {B : Type}, B → B) → A) → A) → R) → R) :=
  fun _ f => f (fun g => g (fun x => x))
#print axioms ChurchFixture.case19
def ChurchFixture.case20 : (∀ R : Type, (((∀ {A : Type}, A → A) → (∀ {B : Type}, B → B)) → R) → R) :=
  fun _ f => f (fun g => g)
#print axioms ChurchFixture.case20
def ChurchFixture.case21 : (∀ a b c : Type _, (a → b) → (c → b) → (∀ r : Type _, (a → r) → (c → r) → r) → b) :=
  fun _ _ _ f g h => h _ f g
#print axioms ChurchFixture.case21
def ChurchFixture.case22 : (∀ (F : Type → Type → Type → Type → Type → Type → Type → Type → Type) (A B C D E G H I : Type), (∀ a b c d e f g h : Type, F a b c d e f g h) → F I H G E D C B A) :=
  fun _ _ _ _ _ _ _ _ _ x => x _ _ _ _ _ _ _ _
#print axioms ChurchFixture.case22
def ChurchFixture.case23 : (∀ (F : Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type) (A B C D E G H I J K L M : Type), (∀ a b c d e f g h i j k l : Type, F a b c d e f g h i j k l) → F M L K J I H G E D C B A) :=
  fun _ _ _ _ _ _ _ _ _ _ _ _ _ x => x _ _ _ _ _ _ _ _ _ _ _ _
#print axioms ChurchFixture.case23
def ChurchFixture.case24 : (∀ F : Type 1 → Type 1, (∀ a : Type 1, a → F a) → F (∀ b : Type, b → b)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms ChurchFixture.case24
def ChurchFixture.case25 : (∀ F : Type 1 → Type 1 → Type 1, (∀ a b : Type 1, a → b → F a b) → F (∀ a : Type, a → a) (∀ b : Type, b → b → b)) :=
  fun _ f => f _ _ (fun _ x => x) (fun _ _ y => y)
#print axioms ChurchFixture.case25
def ChurchFixture.case26 : (∀ (F : Type 1 → Type 1) (A : Type), (∀ a : Type 1, a → F a) → F (∀ B : Type, A → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms ChurchFixture.case26
def ChurchFixture.case27 : (∀ F : Type 1 → Type 1, (∀ {a : Type 1}, a → F a) → F (∀ {b : Type}, b → b)) :=
  fun _ f => f (fun x => x)
#print axioms ChurchFixture.case27
def ChurchFixture.case28 : (∀ F : Type 1 → Type 1, (Unit → ∀ a : Type 1, a → F a) → F (∀ b : Type, b → b)) :=
  fun _ f => let g := f ⟨⟩; g _ (fun _ x => x)
#print axioms ChurchFixture.case28
def ChurchFixture.case29 : (∀ F : Type 1 → Type 1, (Unit → ∀ {a : Type 1}, a → F a) → F (∀ {b : Type}, b → b)) :=
  fun _ f => let g := f ⟨⟩; g (fun x => x)
#print axioms ChurchFixture.case29
def ChurchFixture.case30 : (∀ R : Type, ((∀ {A : Type}, ((∀ {B : Type}, B → B) → A) → A) → R) → R) :=
  fun _ f => f (fun g => g (fun x => x))
#print axioms ChurchFixture.case30
def ChurchFixture.case31 : (∀ R : Type, (((∀ {A : Type}, A → A) → (∀ {B : Type}, B → B)) → R) → R) :=
  fun _ f => f (fun g => g)
#print axioms ChurchFixture.case31
def ChurchFixture.case32 : (∀ a b c : Type _, (a → b) → (c → b) → (∀ r : Type _, (a → r) → (c → r) → r) → b) :=
  fun _ _ _ f g h => h _ f g
#print axioms ChurchFixture.case32
