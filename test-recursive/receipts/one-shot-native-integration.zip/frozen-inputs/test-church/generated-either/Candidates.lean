-- Generated exclusively from synthesized candidates and the manifest.
set_option linter.unusedVariables false
def ChurchCorpus.integerZero : Int := 0
