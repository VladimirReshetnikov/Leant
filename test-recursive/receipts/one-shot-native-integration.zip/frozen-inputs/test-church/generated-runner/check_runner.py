from pathlib import Path
import os
import shutil
import subprocess

root = Path(__file__).resolve().parent
suite = root / "test"
binary = root / "bin"
suite.mkdir(exist_ok=True)
binary.mkdir(exist_ok=True)
shutil.copyfile(root.parents[1] / "test/run-tests.sh", suite / "run-tests.sh")
(suite / "mock.txt").write_text(":quit\n", encoding="utf-8")
fake = binary / "fake-leant"
(binary / "cabal").write_text(
    "#!/usr/bin/env bash\nprintf '%s\\n' '" + fake.as_posix() + "'\n", encoding="utf-8")
env = dict(os.environ)
env["PATH"] = str(binary) + os.pathsep + env["PATH"]
bash = r"C:\Program Files\Git\bin\bash.exe"

def check(label, output, exit_code, update, expected_exit, baseline, expected_baseline):
    fake.write_text("#!/usr/bin/env bash\nprintf '%s\\n' '" + output
                    + "'\nexit " + str(exit_code) + "\n", encoding="utf-8")
    (suite / "mock.golden").write_text(baseline, encoding="utf-8")
    command = [bash, "--noprofile", "--norc", "run-tests.sh"]
    if update:
        command.append("-u")
    run = subprocess.run(command, cwd=suite, env=env, capture_output=True,
                         text=True, encoding="utf-8")
    assert run.returncode == expected_exit, (label, run.returncode, run.stdout, run.stderr)
    actual = (suite / "mock.golden").read_text(encoding="utf-8")
    assert actual == expected_baseline, (label, actual)
    print(label + ": PASS")
    print(run.stdout.strip())

check("nonzero child cannot update", "failed-child", 23, True, 1, "baseline\n", "baseline\n")
check("successful child can update", "accepted", 0, True, 0, "baseline\n", "accepted\n")
check("successful comparison", "accepted", 0, False, 0, "accepted\n", "accepted\n")
check("ordinary mismatch", "different", 0, False, 1, "accepted\n", "accepted\n")
check("filter failure cannot update", "starting Lean backend...", 0, True, 1,
      "baseline\n", "baseline\n")
