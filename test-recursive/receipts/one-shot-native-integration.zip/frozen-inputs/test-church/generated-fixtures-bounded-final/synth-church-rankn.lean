set_option linter.unusedVariables false
noncomputable section
def ChurchFixture.case0 : (∀ (F : Type → Type → Type → Type → Type → Type → Type → Type → Type) (A B C D E G H I : Type), (∀ a b c d e f g h : Type, F a b c d e f g h) → F I H G E D C B A) :=
  fun _ _ _ _ _ _ _ _ _ x => x _ _ _ _ _ _ _ _
#print axioms ChurchFixture.case0
def ChurchFixture.case1 : (∀ (F : Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type) (A B C D E G H I J K L M : Type), (∀ a b c d e f g h i j k l : Type, F a b c d e f g h i j k l) → F M L K J I H G E D C B A) :=
  fun _ _ _ _ _ _ _ _ _ _ _ _ _ x => x _ _ _ _ _ _ _ _ _ _ _ _
#print axioms ChurchFixture.case1
def ChurchFixture.case2 : (∀ F : Type 1 → Type 1, (∀ a : Type 1, a → F a) → F (∀ b : Type, b → b)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms ChurchFixture.case2
def ChurchFixture.case3 : (∀ F : Type 1 → Type 1 → Type 1, (∀ a b : Type 1, a → b → F a b) → F (∀ a : Type, a → a) (∀ b : Type, b → b → b)) :=
  fun _ f => f _ _ (fun _ x => x) (fun _ _ y => y)
#print axioms ChurchFixture.case3
def ChurchFixture.case4 : (∀ (F : Type 1 → Type 1) (A : Type), (∀ a : Type 1, a → F a) → F (∀ B : Type, A → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms ChurchFixture.case4
def ChurchFixture.case5 : (∀ F : Type 1 → Type 1, (∀ {a : Type 1}, a → F a) → F (∀ {b : Type}, b → b)) :=
  fun _ f => f (fun x => x)
#print axioms ChurchFixture.case5
def ChurchFixture.case6 : (∀ F : Type 1 → Type 1, (Unit → ∀ a : Type 1, a → F a) → F (∀ b : Type, b → b)) :=
  fun _ f => f ⟨⟩ _ (fun _ x => x)
#print axioms ChurchFixture.case6
def ChurchFixture.case7 : (∀ F : Type 1 → Type 1, (Unit → ∀ {a : Type 1}, a → F a) → F (∀ {b : Type}, b → b)) :=
  fun _ f => f ⟨⟩ (fun x => x)
#print axioms ChurchFixture.case7
def ChurchFixture.case8 : (∀ R : Type, ((∀ {A : Type}, ((∀ {B : Type}, B → B) → A) → A) → R) → R) :=
  fun _ f => f (fun g => g (fun x => x))
#print axioms ChurchFixture.case8
def ChurchFixture.case9 : (∀ R : Type, (((∀ {A : Type}, A → A) → (∀ {B : Type}, B → B)) → R) → R) :=
  fun _ f => f (fun _ => fun x => x)
#print axioms ChurchFixture.case9
def ChurchFixture.case10 : (∀ a b c : Type _, (a → b) → (c → b) → (∀ r : Type _, (a → r) → (c → r) → r) → b) :=
  fun _ _ _ f g h => h _ f g
#print axioms ChurchFixture.case10
def ChurchFixture.case11 : (∀ A : Type, ((∀ B : Type, ((∀ C : Type, ((∀ D : Type, D → D) → C) → C) → B) → B) → A) → A) :=
  fun _ f => f (fun _ g => g (fun _ h => h (fun _ x => x)))
#print axioms ChurchFixture.case11
def ChurchFixture.case12 : (∀ {A : Type}, ((∀ {B : Type}, ((∀ {C : Type}, ((∀ {D : Type}, D → D) → C) → C) → B) → B) → A) → A) :=
  fun f => f (fun g => g (fun h => h (fun x => x)))
#print axioms ChurchFixture.case12
def ChurchFixture.case13 : (∀ (F : Type 1 → Type 1) (G H K : Type → Type), (∀ a : Type 1, a → F a) → (∀ a : Type, G a → H a) → (∀ a : Type, H a → K a) → F (∀ a : Type, G a → K a)) :=
  fun _ _ _ _ f g h => f _ (fun _ x => h _ (g _ x))
#print axioms ChurchFixture.case13
def ChurchFixture.case14 : (∀ F : Type 1 → Type 1, (∀ a : Type 1, a → F a) → F (∀ b : Type, b → F (∀ c : Type, c → c))) :=
  fun _ f => f _ (fun _ _ => f _ (fun _ x => x))
#print axioms ChurchFixture.case14
def ChurchFixture.case15 : (∀ F : Type 1 → Type 1, (∀ a : Type 1, a → F a) → F (∀ b : Type, b → F (∀ c : Type, b → c → b))) :=
  fun _ f => f _ (fun _ x => f _ (fun _ _ _ => x))
#print axioms ChurchFixture.case15
def ChurchFixture.case16 : (∀ (Seed : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) → G (∀ a : Type, a → a) (∀ b : Type, b → b)) :=
  fun _ _ x f => f x _ (fun _ y => y) x _ (fun _ z => z)
#print axioms ChurchFixture.case16
def ChurchFixture.case17 : (∀ (Seed : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) → G (∀ {a : Type}, a → a) (∀ b : Type, b → b)) :=
  fun _ _ x f => f x _ (fun {_} y => y) x _ (fun _ z => z)
#print axioms ChurchFixture.case17
def ChurchFixture.case18 : (∀ (Seed : Type) (G : Type 1 → Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a b : Type 1, a → b → Seed → ∀ c : Type 1, c → G a b c) → G (∀ a : Type, a → a) (∀ b : Type, b → b → b) (∀ c : Type, c → c)) :=
  fun _ _ x f => f x _ _ (fun _ y => y) (fun _ _ z => z) x _ (fun _ w => w)
#print axioms ChurchFixture.case18
def ChurchFixture.case19 : (∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) → G (∀ c : Type, X → c → c) (∀ d : Type, d → d)) :=
  fun _ _ _ x f => f x _ (fun _ _ y => y) x _ (fun _ z => z)
#print axioms ChurchFixture.case19
def ChurchFixture.case20 : (∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ {a : Type 1}, a → Seed → ∀ {b : Type 1}, b → G a b) → G (∀ c : Type, X → c → c) (∀ d : Type, d → d)) :=
  fun _ _ _ x f => f x (fun _ _ y => y) x (fun _ z => z)
#print axioms ChurchFixture.case20
def ChurchFixture.case21 : (∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) → G (∀ {c : Type}, X → c → c) (∀ {d : Type}, d → d)) :=
  fun _ _ _ x f => f x _ (fun {_} _ y => y) x _ (fun z => z)
#print axioms ChurchFixture.case21
def ChurchFixture.case22 : (∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ {a : Type 1}, a → Seed → ∀ {b : Type 1}, b → G a b) → G (∀ {c : Type}, X → c → c) (∀ {d : Type}, d → d)) :=
  fun _ _ _ x f => f x (fun {_} _ y => y) x (fun z => z)
#print axioms ChurchFixture.case22
def ChurchFixture.case23 : (∀ (F : Type → Type → Type → Type → Type → Type → Type → Type → Type) (A B C D E G H I : Type), (∀ a b c d e f g h : Type, F a b c d e f g h) → F I H G E D C B A) :=
  fun _ _ _ _ _ _ _ _ _ x => x _ _ _ _ _ _ _ _
#print axioms ChurchFixture.case23
def ChurchFixture.case24 : (∀ (F : Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type) (A B C D E G H I J K L M : Type), (∀ a b c d e f g h i j k l : Type, F a b c d e f g h i j k l) → F M L K J I H G E D C B A) :=
  fun _ _ _ _ _ _ _ _ _ _ _ _ _ x => x _ _ _ _ _ _ _ _ _ _ _ _
#print axioms ChurchFixture.case24
def ChurchFixture.case25 : (∀ F : Type 1 → Type 1, (∀ a : Type 1, a → F a) → F (∀ b : Type, b → b)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms ChurchFixture.case25
def ChurchFixture.case26 : (∀ F : Type 1 → Type 1 → Type 1, (∀ a b : Type 1, a → b → F a b) → F (∀ a : Type, a → a) (∀ b : Type, b → b → b)) :=
  fun _ f => f _ _ (fun _ x => x) (fun _ _ y => y)
#print axioms ChurchFixture.case26
def ChurchFixture.case27 : (∀ (F : Type 1 → Type 1) (A : Type), (∀ a : Type 1, a → F a) → F (∀ B : Type, A → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms ChurchFixture.case27
def ChurchFixture.case28 : (∀ F : Type 1 → Type 1, (∀ {a : Type 1}, a → F a) → F (∀ {b : Type}, b → b)) :=
  fun _ f => f (fun x => x)
#print axioms ChurchFixture.case28
def ChurchFixture.case29 : (∀ F : Type 1 → Type 1, (Unit → ∀ a : Type 1, a → F a) → F (∀ b : Type, b → b)) :=
  fun _ f => let g := f ⟨⟩; g _ (fun _ x => x)
#print axioms ChurchFixture.case29
def ChurchFixture.case30 : (∀ F : Type 1 → Type 1, (Unit → ∀ {a : Type 1}, a → F a) → F (∀ {b : Type}, b → b)) :=
  fun _ f => let g := f ⟨⟩; g (fun x => x)
#print axioms ChurchFixture.case30
def ChurchFixture.case31 : (∀ R : Type, ((∀ {A : Type}, ((∀ {B : Type}, B → B) → A) → A) → R) → R) :=
  fun _ f => f (fun g => g (fun x => x))
#print axioms ChurchFixture.case31
def ChurchFixture.case32 : (∀ R : Type, (((∀ {A : Type}, A → A) → (∀ {B : Type}, B → B)) → R) → R) :=
  fun _ f => f (fun g => g)
#print axioms ChurchFixture.case32
def ChurchFixture.case33 : (∀ a b c : Type _, (a → b) → (c → b) → (∀ r : Type _, (a → r) → (c → r) → r) → b) :=
  fun _ _ _ f g h => h _ f g
#print axioms ChurchFixture.case33
def ChurchFixture.case34 : (∀ A : Type, ((∀ B : Type, ((∀ C : Type, ((∀ D : Type, D → D) → C) → C) → B) → B) → A) → A) :=
  fun _ f => f (fun _ g => g (fun _ h => h (fun _ x => x)))
#print axioms ChurchFixture.case34
def ChurchFixture.case35 : (∀ {A : Type}, ((∀ {B : Type}, ((∀ {C : Type}, ((∀ {D : Type}, D → D) → C) → C) → B) → B) → A) → A) :=
  fun f => f (fun g => g (fun h => h (fun x => x)))
#print axioms ChurchFixture.case35
def ChurchFixture.case36 : (∀ (F : Type 1 → Type 1) (G H K : Type → Type), (∀ a : Type 1, a → F a) → (∀ a : Type, G a → H a) → (∀ a : Type, H a → K a) → F (∀ a : Type, G a → K a)) :=
  fun _ _ _ _ f g h => f _ (fun _ x => h _ (g _ x))
#print axioms ChurchFixture.case36
def ChurchFixture.case37 : (∀ F : Type 1 → Type 1, (∀ a : Type 1, a → F a) → F (∀ b : Type, b → F (∀ c : Type, c → c))) :=
  fun _ f => f _ (fun _ _ => f _ (fun _ x => x))
#print axioms ChurchFixture.case37
def ChurchFixture.case38 : (∀ F : Type 1 → Type 1, (∀ a : Type 1, a → F a) → F (∀ b : Type, b → F (∀ c : Type, b → c → b))) :=
  fun _ f => f _ (fun _ _ => f _ (fun _ x _ => x))
#print axioms ChurchFixture.case38
def ChurchFixture.case39 : (∀ (Seed : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) → G (∀ a : Type, a → a) (∀ b : Type, b → b)) :=
  fun _ _ x f => let g := f x (∀ (a0_0 : _), a0_0 → a0_0) (fun _ y => y); let h := g x; h _ (fun _ z => z)
#print axioms ChurchFixture.case39
def ChurchFixture.case40 : (∀ (Seed : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) → G (∀ {a : Type}, a → a) (∀ b : Type, b → b)) :=
  fun _ _ x f => let g := f x (∀ (a0_0 : _), a0_0 → a0_0) (fun _ y => y); let h := g x; h _ (fun _ z => z)
#print axioms ChurchFixture.case40
def ChurchFixture.case41 : (∀ (Seed : Type) (G : Type 1 → Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a b : Type 1, a → b → Seed → ∀ c : Type 1, c → G a b c) → G (∀ a : Type, a → a) (∀ b : Type, b → b → b) (∀ c : Type, c → c)) :=
  fun _ _ x f => let g := f x (∀ (a0_0 : _), a0_0 → a0_0) (∀ (a0_0 : _), a0_0 → a0_0 → a0_0) (fun _ y => y); let h := g (fun _ z _ => z); let f1 := h x; f1 _ (fun _ w => w)
#print axioms ChurchFixture.case41
def ChurchFixture.case42 : (∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) → G (∀ c : Type, X → c → c) (∀ d : Type, d → d)) :=
  fun _ _ _ x f => f x (∀ (a0_0 : _), _ → a0_0 → a0_0) (fun _ _ y => y) x _ (fun _ z => z)
#print axioms ChurchFixture.case42
def ChurchFixture.case43 : (∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ {a : Type 1}, a → Seed → ∀ {b : Type 1}, b → G a b) → G (∀ c : Type, X → c → c) (∀ d : Type, d → d)) :=
  fun _ _ _ x f => @f x (∀ (a0_0 : _), _ → a0_0 → a0_0) (fun _ _ y => y) x _ (fun _ z => z)
#print axioms ChurchFixture.case43
def ChurchFixture.case44 : (∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) → G (∀ {c : Type}, X → c → c) (∀ {d : Type}, d → d)) :=
  fun _ _ _ x f => f x (∀ (a0_0 : _), _ → a0_0 → a0_0) (fun _ _ y => y) x _ (fun z => z)
#print axioms ChurchFixture.case44
def ChurchFixture.case45 : (∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ {a : Type 1}, a → Seed → ∀ {b : Type 1}, b → G a b) → G (∀ {c : Type}, X → c → c) (∀ {d : Type}, d → d)) :=
  fun _ _ _ x f => @f x (∀ (a0_0 : _), _ → a0_0 → a0_0) (fun _ _ y => y) x _ (fun z => z)
#print axioms ChurchFixture.case45
def ChurchFixture.case46 : (∀ (F : Type → Type → Type → Type → Type → Type → Type → Type → Type) (A B C D E G H I : Type), (∀ a b c d e f g h : Type, F a b c d e f g h) → F I H G E D C B A) :=
  fun _ _ _ _ _ _ _ _ _ x => x _ _ _ _ _ _ _ _
#print axioms ChurchFixture.case46
def ChurchFixture.case47 : (∀ (F : Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type → Type) (A B C D E G H I J K L M : Type), (∀ a b c d e f g h i j k l : Type, F a b c d e f g h i j k l) → F M L K J I H G E D C B A) :=
  fun _ _ _ _ _ _ _ _ _ _ _ _ _ x => x _ _ _ _ _ _ _ _ _ _ _ _
#print axioms ChurchFixture.case47
def ChurchFixture.case48 : (∀ F : Type 1 → Type 1, (∀ a : Type 1, a → F a) → F (∀ b : Type, b → b)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms ChurchFixture.case48
def ChurchFixture.case49 : (∀ F : Type 1 → Type 1 → Type 1, (∀ a b : Type 1, a → b → F a b) → F (∀ a : Type, a → a) (∀ b : Type, b → b → b)) :=
  fun _ f => f _ _ (fun _ x => x) (fun _ _ y => y)
#print axioms ChurchFixture.case49
def ChurchFixture.case50 : (∀ (F : Type 1 → Type 1) (A : Type), (∀ a : Type 1, a → F a) → F (∀ B : Type, A → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms ChurchFixture.case50
def ChurchFixture.case51 : (∀ F : Type 1 → Type 1, (∀ {a : Type 1}, a → F a) → F (∀ {b : Type}, b → b)) :=
  fun _ f => f (fun x => x)
#print axioms ChurchFixture.case51
def ChurchFixture.case52 : (∀ F : Type 1 → Type 1, (Unit → ∀ a : Type 1, a → F a) → F (∀ b : Type, b → b)) :=
  fun _ f => let g := f ⟨⟩; g _ (fun _ x => x)
#print axioms ChurchFixture.case52
def ChurchFixture.case53 : (∀ F : Type 1 → Type 1, (Unit → ∀ {a : Type 1}, a → F a) → F (∀ {b : Type}, b → b)) :=
  fun _ f => let g := f ⟨⟩; g (fun x => x)
#print axioms ChurchFixture.case53
def ChurchFixture.case54 : (∀ R : Type, ((∀ {A : Type}, ((∀ {B : Type}, B → B) → A) → A) → R) → R) :=
  fun _ f => f (fun g => g (fun x => x))
#print axioms ChurchFixture.case54
def ChurchFixture.case55 : (∀ R : Type, (((∀ {A : Type}, A → A) → (∀ {B : Type}, B → B)) → R) → R) :=
  fun _ f => f (fun g => g)
#print axioms ChurchFixture.case55
def ChurchFixture.case56 : (∀ a b c : Type _, (a → b) → (c → b) → (∀ r : Type _, (a → r) → (c → r) → r) → b) :=
  fun _ _ _ f g h => h _ f g
#print axioms ChurchFixture.case56
def ChurchFixture.case57 : (∀ A : Type, ((∀ B : Type, ((∀ C : Type, ((∀ D : Type, D → D) → C) → C) → B) → B) → A) → A) :=
  fun _ f => f (fun _ g => g (fun _ h => h (fun _ x => x)))
#print axioms ChurchFixture.case57
def ChurchFixture.case58 : (∀ {A : Type}, ((∀ {B : Type}, ((∀ {C : Type}, ((∀ {D : Type}, D → D) → C) → C) → B) → B) → A) → A) :=
  fun f => f (fun g => g (fun h => h (fun x => x)))
#print axioms ChurchFixture.case58
def ChurchFixture.case59 : (∀ (F : Type 1 → Type 1) (G H K : Type → Type), (∀ a : Type 1, a → F a) → (∀ a : Type, G a → H a) → (∀ a : Type, H a → K a) → F (∀ a : Type, G a → K a)) :=
  fun _ _ _ _ f g h => f _ (fun _ x => h _ (g _ x))
#print axioms ChurchFixture.case59
def ChurchFixture.case60 : (∀ F : Type 1 → Type 1, (∀ a : Type 1, a → F a) → F (∀ b : Type, b → F (∀ c : Type, c → c))) :=
  fun _ f => f _ (fun _ _ => f _ (fun _ x => x))
#print axioms ChurchFixture.case60
def ChurchFixture.case61 : (∀ F : Type 1 → Type 1, (∀ a : Type 1, a → F a) → F (∀ b : Type, b → F (∀ c : Type, b → c → b))) :=
  fun _ f => f _ (fun _ _ => f _ (fun _ x _ => x))
#print axioms ChurchFixture.case61
def ChurchFixture.case62 : (∀ (Seed : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) → G (∀ a : Type, a → a) (∀ b : Type, b → b)) :=
  fun _ _ x f => let g := f x (∀ (a0_0 : _), a0_0 → a0_0) (fun _ y => y); let h := g x; h _ (fun _ z => z)
#print axioms ChurchFixture.case62
def ChurchFixture.case63 : (∀ (Seed : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) → G (∀ {a : Type}, a → a) (∀ b : Type, b → b)) :=
  fun _ _ x f => let g := f x (∀ (a0_0 : _), a0_0 → a0_0) (fun _ y => y); let h := g x; h _ (fun _ z => z)
#print axioms ChurchFixture.case63
def ChurchFixture.case64 : (∀ (Seed : Type) (G : Type 1 → Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a b : Type 1, a → b → Seed → ∀ c : Type 1, c → G a b c) → G (∀ a : Type, a → a) (∀ b : Type, b → b → b) (∀ c : Type, c → c)) :=
  fun _ _ x f => let g := f x (∀ (a0_0 : _), a0_0 → a0_0) (∀ (a0_0 : _), a0_0 → a0_0 → a0_0) (fun _ y => y); let h := g (fun _ z _ => z); let f1 := h x; f1 _ (fun _ w => w)
#print axioms ChurchFixture.case64
def ChurchFixture.case65 : (∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) → G (∀ c : Type, X → c → c) (∀ d : Type, d → d)) :=
  fun _ _ _ x f => f x (∀ (a0_0 : _), _ → a0_0 → a0_0) (fun _ _ y => y) x _ (fun _ z => z)
#print axioms ChurchFixture.case65
def ChurchFixture.case66 : (∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ {a : Type 1}, a → Seed → ∀ {b : Type 1}, b → G a b) → G (∀ c : Type, X → c → c) (∀ d : Type, d → d)) :=
  fun _ _ _ x f => @f x (∀ (a0_0 : _), _ → a0_0 → a0_0) (fun _ _ y => y) x _ (fun _ z => z)
#print axioms ChurchFixture.case66
def ChurchFixture.case67 : (∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G a b) → G (∀ {c : Type}, X → c → c) (∀ {d : Type}, d → d)) :=
  fun _ _ _ x f => f x (∀ (a0_0 : _), _ → a0_0 → a0_0) (fun _ _ y => y) x _ (fun z => z)
#print axioms ChurchFixture.case67
def ChurchFixture.case68 : (∀ (Seed X : Type) (G : Type 1 → Type 1 → Type 1), Seed → (Seed → ∀ {a : Type 1}, a → Seed → ∀ {b : Type 1}, b → G a b) → G (∀ {c : Type}, X → c → c) (∀ {d : Type}, d → d)) :=
  fun _ _ _ x f => @f x (∀ (a0_0 : _), _ → a0_0 → a0_0) (fun _ _ y => y) x _ (fun z => z)
#print axioms ChurchFixture.case68
