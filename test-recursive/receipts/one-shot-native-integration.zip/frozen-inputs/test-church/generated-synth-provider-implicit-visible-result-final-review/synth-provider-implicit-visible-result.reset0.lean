-- Independent source reset segment 0
namespace ImplicitVisible

axiom Source : Type
axiom Result : Type
axiom Token : Type

class Choice (a : Type 1) : Prop where
  witness : True

instance : Choice (∀ {P : Prop} (A : Type), P → A → Result) :=
  ⟨True.intro⟩

axiom token {a : Type 1} [Choice a] : Token
axiom box {a : Type 1} [Choice a] : a × Unit

end ImplicitVisible

noncomputable def goldenReplayQuery1Candidate1 : ImplicitVisible.Token :=
  ImplicitVisible.token («a» := (∀ {a0_0 : Prop} (a0_1 : Type _), a0_0 → a0_1 → (ImplicitVisible.Result)))
#print axioms goldenReplayQuery1Candidate1
noncomputable def goldenReplayQuery1Candidate2 : ImplicitVisible.Token :=
  match Sum.inl (ImplicitVisible.token («a» := (∀ {a0_0 : Prop} (a0_1 : Type _), a0_0 → a0_1 → (ImplicitVisible.Result)))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery1Candidate2
noncomputable def goldenReplayQuery3Candidate1 : ImplicitVisible.Token :=
  ImplicitVisible.token («a» := (∀ {a0_0 : Prop} (a0_1 : Type _), a0_0 → a0_1 → (ImplicitVisible.Result)))
#print axioms goldenReplayQuery3Candidate1
noncomputable def goldenReplayQuery3Candidate2 : ImplicitVisible.Token :=
  match Sum.inl (ImplicitVisible.token («a» := (∀ {a0_0 : Prop} (a0_1 : Type _), a0_0 → a0_1 → (ImplicitVisible.Result)))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery3Candidate2
noncomputable def goldenReplayQuery3Candidate3 : ImplicitVisible.Token :=
  match Sum.inr (ImplicitVisible.token («a» := (∀ {a0_0 : Prop} (a0_1 : Type _), a0_0 → a0_1 → (ImplicitVisible.Result)))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery3Candidate3

namespace DomainCollision

axiom Result : Type
axiom Box (a : Type 1) : Type

class Choice (a : Type 1) : Prop where
  witness : True

instance choicePropType :
    Choice (∀ {P : Prop} (A : Type), (P → A) → Result) :=
  ⟨True.intro⟩

instance choiceTypeProp :
    Choice (∀ {A : Type} (P : Prop), (A → P) → Result) :=
  ⟨True.intro⟩

axiom selected {a : Type 1} [Choice a] : Box a

end DomainCollision

noncomputable def goldenReplayQuery6Candidate1 : DomainCollision.Box (∀ {P : Prop} (A : Type), (P → A) → DomainCollision.Result) :=
  DomainCollision.selected («a» := (∀ {a0_0 : Prop} (a0_1 : Type _), (a0_0 → a0_1) → (DomainCollision.Result)))
#print axioms goldenReplayQuery6Candidate1
noncomputable def goldenReplayQuery6Candidate2 : DomainCollision.Box (∀ {P : Prop} (A : Type), (P → A) → DomainCollision.Result) :=
  DomainCollision.selected
#print axioms goldenReplayQuery6Candidate2
noncomputable def goldenReplayQuery6Candidate3 : DomainCollision.Box (∀ {P : Prop} (A : Type), (P → A) → DomainCollision.Result) :=
  match Sum.inr (DomainCollision.selected («a» := (∀ {a0_0 : Prop} (a0_1 : Type _), (a0_0 → a0_1) → (DomainCollision.Result)))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery6Candidate3
noncomputable def goldenReplayQuery6Candidate4 : DomainCollision.Box (∀ {P : Prop} (A : Type), (P → A) → DomainCollision.Result) :=
  match Sum.inr DomainCollision.selected with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery6Candidate4
noncomputable def goldenReplayQuery6Candidate5 : DomainCollision.Box (∀ {P : Prop} (A : Type), (P → A) → DomainCollision.Result) :=
  match Sum.inl DomainCollision.selected with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery6Candidate5
noncomputable def goldenReplayQuery7Candidate1 : DomainCollision.Box (∀ {P : Prop} (A : Type), (P → A) → DomainCollision.Result) :=
  DomainCollision.selected
#print axioms goldenReplayQuery7Candidate1
noncomputable def goldenReplayQuery7Candidate2 : DomainCollision.Box (∀ {P : Prop} (A : Type), (P → A) → DomainCollision.Result) :=
  DomainCollision.selected («a» := (∀ {a0_0 : Prop} (a0_1 : Type _), (a0_0 → a0_1) → (DomainCollision.Result)))
#print axioms goldenReplayQuery7Candidate2
noncomputable def goldenReplayQuery7Candidate3 : DomainCollision.Box (∀ {P : Prop} (A : Type), (P → A) → DomainCollision.Result) :=
  match Sum.inr DomainCollision.selected with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery7Candidate3
noncomputable def goldenReplayQuery7Candidate4 : DomainCollision.Box (∀ {P : Prop} (A : Type), (P → A) → DomainCollision.Result) :=
  match Sum.inr (DomainCollision.selected («a» := (∀ {a0_0 : Prop} (a0_1 : Type _), (a0_0 → a0_1) → (DomainCollision.Result)))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery7Candidate4
noncomputable def goldenReplayQuery7Candidate5 : DomainCollision.Box (∀ {P : Prop} (A : Type), (P → A) → DomainCollision.Result) :=
  match Sum.inl DomainCollision.selected with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery7Candidate5
