-- Type formation only; no inhabitants or synthesis claims.
#check (fun (witness : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → church1) → ((church2 → church1) → ((∀ (church3 : Type _), ((church0 → church3) → ((church2 → church3) → church3))) → church1))))) => witness)
