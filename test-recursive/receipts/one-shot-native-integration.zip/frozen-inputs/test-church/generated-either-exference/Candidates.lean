-- Generated exclusively from synthesized candidates and the manifest.
set_option linter.unusedVariables false
def ChurchCorpus.integerZero : Int := 0

-- Church.hs:624 either (total)
def ChurchCorpus.church_case_109 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → church1) → ((church2 → church1) → ((∀ (church3 : Type _), ((church0 → church3) → ((church2 → church3) → church3))) → church1)))) :=
  fun _ _ _ f g h => h _ f g
#print axioms ChurchCorpus.church_case_109
