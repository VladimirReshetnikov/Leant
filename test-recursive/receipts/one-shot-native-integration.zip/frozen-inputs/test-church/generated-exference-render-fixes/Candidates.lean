-- Generated exclusively from synthesized candidates and the manifest.
set_option linter.unusedVariables false
def ChurchCorpus.integerZero : Int := 0

-- Church.hs:218 nil (total)
def ChurchCorpus.church_case_021 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) :=
  fun _ _ f x => match Sum.inr x with | .inl a => f a x | .inr b => b
#print axioms ChurchCorpus.church_case_021

-- Church.hs:551 nothing (total)
def ChurchCorpus.church_case_091 : (∀ (church0 : Type _) (church1 : Type _), (church1 → ((church0 → church1) → church1))) :=
  fun _ _ x f => match Sum.inr x with | .inl a => f a | .inr b => b
#print axioms ChurchCorpus.church_case_091

-- Church.hs:596 left (total)
def ChurchCorpus.church_case_101 : (∀ (church0 : Type _) (church1 : Type _), (church0 → (∀ (church2 : Type _), ((church0 → church2) → ((church1 → church2) → church2))))) :=
  fun _ _ x _ f g => match Sum.inr x with | .inl a => g a | .inr b => f b
#print axioms ChurchCorpus.church_case_101

-- Church.hs:599 right (total)
def ChurchCorpus.church_case_102 : (∀ (church0 : Type _) (church1 : Type _), (church0 → (∀ (church2 : Type _), ((church1 → church2) → ((church0 → church2) → church2))))) :=
  fun _ _ x _ f g => match Sum.inr x with | .inl a => f a | .inr b => g b
#print axioms ChurchCorpus.church_case_102

-- Church.hs:681 associationMap (total)
def ChurchCorpus.church_case_121 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((church0 → church1) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))))))) :=
  fun _ _ f g h _ f1 x => h _ (fun y z => f1 (let f2 := f y; fun _ f3 => f3 y (g (let f4 := f2 y _; f4 y y))) z) x
#print axioms ChurchCorpus.church_case_121

-- Church.hs:702 invert (total)
def ChurchCorpus.church_case_123 : (∀ (church0 : Type _) (church1 : Type _), ((church1 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church1 → ((∀ (church5 : Type _), ((church0 → (church5 → church5)) → (church5 → church5))) → church6)) → church6)) → (church7 → church7)) → (church7 → church7)))))) :=
  fun _ _ f g _ h x => g _ (fun f1 y => h (fun _ f2 => f1 _ (fun z w => f2 w (fun _ f3 x1 => f3 z (f3 (let f4 := f w; let f5 := f4 w _; f5 z z) x1)))) y) x
#print axioms ChurchCorpus.church_case_123

-- Church.hs:709 merge (total)
def ChurchCorpus.church_case_124 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (church5 → church5)) → (church5 → church5))) → (∀ (church8 : Type _), (((∀ (church7 : Type _), ((church0 → ((∀ (church6 : Type _), ((church1 → (church6 → church6)) → (church6 → church6))) → church7)) → church7)) → (church8 → church8)) → (church8 → church8)))))) :=
  fun _ _ f g _ h x => g _ (fun f1 y => f1 _ (fun f2 z => h (fun _ f3 => f2 _ (fun w x1 => f3 w (fun _ f4 x2 => f4 x1 (f4 (let f5 := f w; let f6 := f5 w _; f6 x1 x1) x2)))) z) y) x
#print axioms ChurchCorpus.church_case_124

-- Church.hs:714 mergeWith (total)
def ChurchCorpus.church_case_125 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church0 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → (((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → church2) → ((∀ (church7 : Type _), (((∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))) → (church7 → church7)) → (church7 → church7))) → (∀ (church9 : Type _), (((∀ (church8 : Type _), ((church0 → (church2 → church8)) → church8)) → (church9 → church9)) → (church9 → church9))))))) :=
  fun _ _ _ f g h _ f1 x => h _ (fun f2 y => f2 _ (fun f3 z => f1 (fun _ f4 => f3 _ (fun w x1 => f4 w (g (fun _ f5 x2 => f5 x1 (f5 (let f6 := f w; let f7 := f6 w _; f7 x1 x1) x2))))) z) y) x
#print axioms ChurchCorpus.church_case_125

-- Church.hs:720 collapse (total)
def ChurchCorpus.church_case_126 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church0 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → ((church1 → (church1 → (∀ (church4 : Type _), (church4 → (church4 → church4))))) → ((∀ (church8 : Type _), (((∀ (church7 : Type _), ((church0 → ((∀ (church6 : Type _), (((∀ (church5 : Type _), ((church1 → (church2 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))) → church7)) → church7)) → (church8 → church8)) → (church8 → church8))) → (∀ (church11 : Type _), (((∀ (church10 : Type _), (((∀ (church9 : Type _), ((church0 → (church1 → church9)) → church9)) → (church2 → church10)) → church10)) → (church11 → church11)) → (church11 → church11))))))) :=
  fun _ _ _ f g h _ f1 x => h _ (fun f2 y => f2 _ (fun z f3 => f3 _ (fun f4 w => f1 (let f5 := f z; fun _ f6 => f4 _ (fun x1 x2 => f6 (let f7 := g x1; fun _ f8 => let f9 := f7 x1 _; f8 (let f10 := f5 (f9 z z) _; f10 z z) x1) x2)) w) y)) x
#print axioms ChurchCorpus.church_case_126

-- Church.hs:781 keySelect (total)
def ChurchCorpus.church_case_137 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (∀ (church2 : Type _), (church2 → (church2 → church2)))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6)))))) :=
  fun _ _ f g _ h x => g _ (fun f1 y => h (fun _ f2 => f1 _ (fun z w => f2 z (let f3 := f z _; f3 w w))) y) x
#print axioms ChurchCorpus.church_case_137

-- Church.hs:789 keySortBy (total)
def ChurchCorpus.church_case_139 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church0 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → ((church1 → church0) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church1 → (church2 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church1 → (church2 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))))))) :=
  fun _ _ _ f g h _ f1 x => h _ (fun f2 y => f1 f2 (f1 (fun _ f3 => f2 _ (fun z w => f3 (let f4 := f (g z); let f5 := f4 (g z) _; f5 z z) w)) y)) x
#print axioms ChurchCorpus.church_case_139

-- Church.hs:793 keySort (total)
def ChurchCorpus.church_case_140 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6)))))) :=
  fun _ _ f g _ h x => g _ (fun f1 y => h f1 (h (fun _ f2 => f1 _ (fun z w => f2 (let f3 := f z; let f4 := f3 z _; f4 z z) w)) y)) x
#print axioms ChurchCorpus.church_case_140

-- Church.hs:812 keyIntersection (total)
def ChurchCorpus.church_case_144 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (church5 → church5)) → (church5 → church5))) → (∀ (church8 : Type _), (((∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church1 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))) → (church8 → church8)) → (church8 → church8)))))) :=
  fun _ _ f g _ h x => h (fun _ f1 y => g _ (fun f2 z => f2 _ (fun f3 w => f1 f3 (f1 (fun _ f4 => f3 _ (fun x1 x2 => f4 (let f5 := f x1; let f6 := f5 x1 _; f6 x1 x1) x2)) w)) z) y) x
#print axioms ChurchCorpus.church_case_144

-- Church.hs:859 nubBy (total)
def ChurchCorpus.church_case_151 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y _; f2 y y) z) x
#print axioms ChurchCorpus.church_case_151

-- Church.hs:863 nubOn (total)
def ChurchCorpus.church_case_152 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((church1 → church0) → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))))))) :=
  fun _ _ f g h _ f1 x => h _ (fun y z => f1 (let w := g y; let f2 := f w; let f3 := f2 w _; f3 y y) z) x
#print axioms ChurchCorpus.church_case_152

-- Church.hs:907 countsBy (total)
def ChurchCorpus.church_case_161 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (Int → church3)) → church3)) → (church4 → church4)) → (church4 → church4)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; fun _ f2 => let f3 := f1 y _; f2 (f3 y y) (.negSucc (.zero))) z) x
#print axioms ChurchCorpus.church_case_161

-- Church.hs:911 countsByKey (total)
def ChurchCorpus.church_case_162 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((church1 → church0) → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (Int → church4)) → church4)) → (church5 → church5)) → (church5 → church5))))))) :=
  fun _ _ f g h _ f1 x => h _ (fun y z => f1 (let w := g y; fun _ f2 => let f3 := f w; let f4 := f3 w _; f2 (f4 w w) (.ofNat (.zero))) z) x
#print axioms ChurchCorpus.church_case_162

-- Church.hs:916 tallyBy (total)
def ChurchCorpus.church_case_163 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (Int → church3)) → church3)) → (church4 → church4)) → (church4 → church4)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; fun _ f2 => let f3 := f1 y _; f2 (f3 y y) (.negSucc (.zero))) z) x
#print axioms ChurchCorpus.church_case_163

-- Church.hs:925 positionIndexBy (total)
def ChurchCorpus.church_case_165 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → ((∀ (church3 : Type _), ((Int → (church3 → church3)) → (church3 → church3))) → church4)) → church4)) → (church5 → church5)) → (church5 → church5)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (fun _ f1 => f1 y (fun _ f2 w => f2 (.negSucc (let f3 := f y; let f4 := f3 y _; f4 (.zero) (.zero))) w)) z) x
#print axioms ChurchCorpus.church_case_165

-- Church.hs:1034 deleteDuplicatesBy (total)
def ChurchCorpus.church_case_182 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y _; f2 y y) z) x
#print axioms ChurchCorpus.church_case_182

-- Church.hs:1067 quickStep (total)
def ChurchCorpus.church_case_189 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))) → ((∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), ((church0 → (church5 → church5)) → (church5 → church5))))))) :=
  fun _ f g h _ z0 z1 => g (fun _ f1 x => h _ (fun y z => f1 (let f2 := f y; let f3 := f2 y _; f3 y y) z) x) _ z0 z1
#print axioms ChurchCorpus.church_case_189

-- Church.hs:1074 mergesort (total)
def ChurchCorpus.church_case_190 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y _; f2 y y) z) x
#print axioms ChurchCorpus.church_case_190

-- Church.hs:1081 sortOn (total)
def ChurchCorpus.church_case_191 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((church1 → church0) → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))))))) :=
  fun _ _ f g h _ f1 x => h _ (fun y z => f1 (let w := g y; let f2 := f w; let f3 := f2 w _; f3 y y) z) x
#print axioms ChurchCorpus.church_case_191

-- Church.hs:1087 quicksort (total)
def ChurchCorpus.church_case_192 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y _; f2 y y) z) x
#print axioms ChurchCorpus.church_case_192

-- Church.hs:1092 heapsort (total)
def ChurchCorpus.church_case_193 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y _; f2 y y) z) x
#print axioms ChurchCorpus.church_case_193

-- Church.hs:1097 introsort (total)
def ChurchCorpus.church_case_194 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y _; f2 y y) z) x
#print axioms ChurchCorpus.church_case_194

-- Church.hs:1249 uniqueBy (total)
def ChurchCorpus.church_case_218 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y _; f2 y y) z) x
#print axioms ChurchCorpus.church_case_218

-- Church.hs:1505 fromList (total)
def ChurchCorpus.church_case_259 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6)))))) :=
  fun _ _ f g _ h x => g _ (fun f1 y => h f1 (h (fun _ f2 => f1 _ (fun z w => f2 (let f3 := f z; let f4 := f3 z _; f4 z z) w)) y)) x
#print axioms ChurchCorpus.church_case_259

-- Church.hs:1510 fromListWith (total)
def ChurchCorpus.church_case_260 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → church0)) → ((church1 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church1 → (church0 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church1 → (church0 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))))))) :=
  fun _ _ f g h _ f1 x => h _ (fun f2 y => f1 f2 (f1 (fun _ f3 => f2 _ (fun z w => f3 z (f w (let f4 := g z; let f5 := f4 z _; f5 w w)))) y)) x
#print axioms ChurchCorpus.church_case_260

-- Church.hs:1539 mapKeysWith (total)
def ChurchCorpus.church_case_265 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church0 → church0)) → ((church1 → (church1 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → ((church2 → church1) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church2 → (church0 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church1 → (church0 → church6)) → church6)) → (church7 → church7)) → (church7 → church7)))))))) :=
  fun _ _ _ f g h f1 _ f2 x => f1 _ (fun f3 y => f3 _ (fun z w => f2 (let f4 := g (h z); let f5 := f w; fun _ f6 => f6 (h z) (f5 (let f7 := f4 (h z) _; f7 w w))) y)) x
#print axioms ChurchCorpus.church_case_265

-- Church.hs:1561 filterValues (total)
def ChurchCorpus.church_case_269 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (∀ (church2 : Type _), (church2 → (church2 → church2)))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church1 → (church0 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church1 → (church0 → church5)) → church5)) → (church6 → church6)) → (church6 → church6)))))) :=
  fun _ _ f g _ h x => g _ (fun f1 y => h (fun _ f2 => f1 _ (fun z w => f2 z (let f3 := f w _; f3 w w))) y) x
#print axioms ChurchCorpus.church_case_269

-- Church.hs:1588 unionsWith (total)
def ChurchCorpus.church_case_274 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → church0)) → ((church1 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church1 → (church0 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church1 → (church0 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))))))) :=
  fun _ _ f g h _ f1 x => h _ (fun f2 y => f2 _ (fun f3 z => f1 f3 (f1 (fun _ f4 => f3 _ (fun w x1 => f4 w (f x1 (let f5 := g w; let f6 := f5 w _; f6 x1 x1)))) z)) y) x
#print axioms ChurchCorpus.church_case_274

-- Church.hs:1593 unions (total)
def ChurchCorpus.church_case_275 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church1 → church6)) → church6)) → (church7 → church7)) → (church7 → church7)))))) :=
  fun _ _ f g _ h x => g _ (fun f1 y => f1 _ (fun f2 z => h f2 (h (fun _ f3 => f2 _ (fun w x1 => f3 (let f4 := f w; let f5 := f4 w _; f5 w w) x1)) z)) y) x
#print axioms ChurchCorpus.church_case_275

-- Church.hs:1785 sortBy (total)
def ChurchCorpus.church_case_319 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y _; f2 y y) z) x
#print axioms ChurchCorpus.church_case_319

-- Church.hs:1788 sort (total)
def ChurchCorpus.church_case_320 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y _; f2 y y) z) x
#print axioms ChurchCorpus.church_case_320

-- Church.hs:1794 nub (total)
def ChurchCorpus.church_case_322 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y _; f2 y y) z) x
#print axioms ChurchCorpus.church_case_322

-- Church.hs:1797 tally (total)
def ChurchCorpus.church_case_323 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (Int → church3)) → church3)) → (church4 → church4)) → (church4 → church4)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; fun _ f2 => let f3 := f1 y _; f2 (f3 y y) (.negSucc (.zero))) z) x
#print axioms ChurchCorpus.church_case_323

-- Church.hs:1800 counts (total)
def ChurchCorpus.church_case_324 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (Int → church3)) → church3)) → (church4 → church4)) → (church4 → church4)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; fun _ f2 => let f3 := f1 y _; f2 (f3 y y) (.negSucc (.zero))) z) x
#print axioms ChurchCorpus.church_case_324

-- Church.hs:1806 positionIndex (total)
def ChurchCorpus.church_case_326 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → ((∀ (church3 : Type _), ((Int → (church3 → church3)) → (church3 → church3))) → church4)) → church4)) → (church5 → church5)) → (church5 → church5)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (fun _ f1 => f1 y (fun _ f2 w => f2 (.negSucc (let f3 := f y; let f4 := f3 y _; f4 (.zero) (.zero))) w)) z) x
#print axioms ChurchCorpus.church_case_326

-- Church.hs:1836 unique (total)
def ChurchCorpus.church_case_336 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y _; f2 y y) z) x
#print axioms ChurchCorpus.church_case_336
