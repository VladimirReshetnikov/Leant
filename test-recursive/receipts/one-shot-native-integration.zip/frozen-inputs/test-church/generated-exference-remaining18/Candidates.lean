-- Generated exclusively from synthesized candidates and the manifest.
set_option linter.unusedVariables false
def ChurchCorpus.integerZero : Int := 0

-- Church.hs:81 ltInt (total)
def ChurchCorpus.church_case_000 : (Int → (Int → (∀ (church0 : Type _), (church0 → (church0 → church0))))) :=
  fun _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_000

-- Church.hs:84 gtInt (total)
def ChurchCorpus.church_case_001 : (Int → (Int → (∀ (church0 : Type _), (church0 → (church0 → church0))))) :=
  fun _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_001

-- Church.hs:87 leInt (total)
def ChurchCorpus.church_case_002 : (Int → (Int → (∀ (church0 : Type _), (church0 → (church0 → church0))))) :=
  fun _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_002

-- Church.hs:92 eqInt (total)
def ChurchCorpus.church_case_003 : (Int → (Int → (∀ (church0 : Type _), (church0 → (church0 → church0))))) :=
  fun _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_003

-- Church.hs:95 geInt (total)
def ChurchCorpus.church_case_004 : (Int → (Int → (∀ (church0 : Type _), (church0 → (church0 → church0))))) :=
  fun _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_004

-- Church.hs:421 splitAt (total)
def ChurchCorpus.church_case_064 : (∀ (church0 : Type _), (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church4 : Type _), (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → church4)) → church4))))) :=
  fun _ _ f _ g => g f f
#print axioms ChurchCorpus.church_case_064

-- Church.hs:443 partitionEvery (total)
def ChurchCorpus.church_case_070 : (∀ (church0 : Type _), (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_070

-- Church.hs:448 partitionStep (total)
def ChurchCorpus.church_case_071 : (∀ (church0 : Type _), (Int → (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (church3 → church3)) → (church3 → church3))))))) :=
  fun _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_071

-- Church.hs:459 windows (total)
def ChurchCorpus.church_case_072 : (∀ (church0 : Type _), (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_072

-- Church.hs:474 replicate (total)
def ChurchCorpus.church_case_076 : (∀ (church0 : Type _), (Int → (church0 → (∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1)))))) :=
  fun _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_076

-- Church.hs:749 mapMaybeValues (total)
def ChurchCorpus.church_case_131 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (∀ (church3 : Type _), (church3 → ((church1 → church3) → church3)))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church2 → (church0 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church2 → (church1 → church6)) → church6)) → (church7 → church7)) → (church7 → church7)))))) :=
  fun _ _ _ f g _ h x => g _ (fun f1 y => f1 _ (fun z w => let f2 := f w; f2 _ y (fun x1 => h (fun _ f3 => f3 z x1) y))) x
#print axioms ChurchCorpus.church_case_131

-- Church.hs:1062 partition3 (total)
def ChurchCorpus.church_case_188 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church0 → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (((∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))) → ((∀ (church5 : Type _), ((church0 → (church5 → church5)) → (church5 → church5))) → ((∀ (church6 : Type _), ((church0 → (church6 → church6)) → (church6 → church6))) → church1))) → church1))))) :=
  fun _ _ f x g h => let f1 := f x; let f2 := f1 x; f2 _ (h g g g) (h g g g)
#print axioms ChurchCorpus.church_case_188

-- Church.hs:1190 mismatch (total)
def ChurchCorpus.church_case_207 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (church6 → (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → church6) → church6))))))) :=
  fun _ _ f g h _ x f1 => g _ (fun y z => h _ (fun w x1 => let f2 := f y; let f3 := f2 w; f3 _ x1 (f1 (fun _ f4 => f4 y w))) z) x
#print axioms ChurchCorpus.church_case_207

-- Church.hs:1215 searchN (total)
def ChurchCorpus.church_case_212 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (Int → (church1 → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), (church4 → ((Int → church4) → church4)))))))) :=
  fun _ _ f x y g _ z h => g _ (fun w x1 => let f1 := f w; let f2 := f1 y; f2 _ x1 (h x)) z
#print axioms ChurchCorpus.church_case_212

-- Church.hs:1533 mapMaybeWithKey (total)
def ChurchCorpus.church_case_264 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (∀ (church3 : Type _), (church3 → ((church2 → church3) → church3))))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church2 → church6)) → church6)) → (church7 → church7)) → (church7 → church7)))))) :=
  fun _ _ _ f g _ h x => g _ (fun f1 y => f1 _ (fun z w => let f2 := f z; let f3 := f2 w; f3 _ y (fun x1 => h (fun _ f4 => f4 z x1) y))) x
#print axioms ChurchCorpus.church_case_264

-- Church.hs:1741 iterateN (total)
def ChurchCorpus.church_case_305 : (∀ (church0 : Type _), (Int → ((church0 → church0) → (church0 → (∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))))))) :=
  fun _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_305

-- Church.hs:1744 range (total)
def ChurchCorpus.church_case_306 : (Int → (Int → (∀ (church0 : Type _), ((Int → (church0 → church0)) → (church0 → church0))))) :=
  fun x y _ f z => f x (f y z)
#print axioms ChurchCorpus.church_case_306
