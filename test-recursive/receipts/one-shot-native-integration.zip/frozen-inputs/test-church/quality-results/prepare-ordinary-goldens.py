"""Prepare, then explicitly apply reviewed goldens from the completed E0 run.

Default mode writes only a new ignored preview directory. --apply consumes that
frozen preview, requires the passed explicit-query audit and a root approval note
for proof/control review, backs up every original golden, and updates only rows
whose ORIGINAL live comparison reported drift. No synthesis or kernel is run.
The only subprocess is Git Bash executing the extracted production update filter.
"""
import argparse
from datetime import datetime, timezone
import difflib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
COMPARATOR = HERE / "compare-composite-captures.py"
EXPECTED_EXE = "e0b9c87cae0bc34d59c8d5a34a58fdd5005676913969a80d5503d7281081d025"
EXPECTED_RUNNER = "2ab1f5ca729cdd795d3f208024a58c97072a34aa3f664dd1047a09cf0292b4fa"
EXPECTED_WRAPPER = "f7f3ce13583268514cea87e307950d3549031477bad8342086fef93f74ee7e80"
EXPECTED_COMPARATOR = "45eeced37b947730ea995eb97cda286aaa47b051e4276b7b21ab254671b869c2"
if hashlib.sha256(COMPARATOR.read_bytes()).hexdigest() != EXPECTED_COMPARATOR:
    raise SystemExit("The receipt validator changed; review it before preparing or applying goldens")
spec = importlib.util.spec_from_file_location("composite_receipt_gates", COMPARATOR)
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
require, digest = gate.require, gate.digest
ROOT, QUALITY = gate.ROOT, gate.QUALITY
LIVE = gate.ORDINARY_DIRECTORY / "results.json"


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def parse_json(data):
    return json.loads(data.decode("utf-8-sig"), object_pairs_hook=unique_object)


def now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value, *, replace=False):
    data = (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
    if replace:
        temporary = path.with_name(path.name + ".next")
        with temporary.open("xb") as stream:
            stream.write(data)
        os.replace(temporary, path)
    else:
        with path.open("xb") as stream:
            stream.write(data)


def output_path(path, protected=()):
    path = path.resolve()
    require(path.is_relative_to(QUALITY.resolve()) and path != QUALITY.resolve(),
            "Output must be a new directory below ignored quality-results")
    for directory in (gate.ORDINARY_DIRECTORY, gate.COMPACT_DIRECTORY, *protected):
        require(not path.is_relative_to(directory.resolve()),
                f"Output must not be inside preserved evidence: {directory}")
    require(not path.exists() or path.is_dir() and not any(path.iterdir()),
            f"Refusing to overwrite a nonempty output directory: {path}")
    return path


def update_script(runner_bytes):
    source = runner_bytes.decode("utf-8-sig").replace("\r\n", "\n")
    matches = re.findall(r"^filter\(\) \{\n.*?^\}", source, re.MULTILINE | re.DOTALL)
    require(len(matches) == 1, "Expected exactly one production filter definition")
    # Mirror run-tests.sh -u. Queue counts must remain numeric here; only the
    # later comparison normalizes that telemetry. Command substitution removes
    # trailing newlines, and printf adds exactly the runner's final newline.
    return "set -uo pipefail\n" + matches[0] + "\n" + r'''
if ! actual=$(filter); then exit 2; fi
printf '%s\n' "$actual"
'''


def normalized_update(raw, script):
    process = subprocess.run(
        [str(gate.BASH), "--noprofile", "--norc", "-c", script,
         "prepare-reviewed-ordinary-goldens"],
        input=raw, capture_output=True, cwd=ROOT, timeout=30)
    require(process.returncode == 0 and not process.stderr,
            "Production update filtering failed: " + process.stderr.decode("utf-8", errors="replace"))
    require(process.stdout.strip() and b"\x00" not in process.stdout,
            "Refusing an empty or NUL-containing golden proposal")
    process.stdout.decode("utf-8")
    return process.stdout


def collect(inputs):
    require(gate.EXPECTED_EXE == EXPECTED_EXE and len(gate.ORDINARY) == 26,
            "Receipt validator is pinned to another executable or fixture inventory")
    inputs.read(Path(__file__))
    inputs.read(COMPARATOR)
    inputs.read(gate.BASH)
    live_bytes = inputs.read(LIVE)
    live = parse_json(live_bytes)
    require(live["runner_sha256"] == EXPECTED_RUNNER and
            live["wrapper_sha256"] == EXPECTED_WRAPPER,
            "The production runner or capture wrapper differs from the reviewed version")
    rows, executable = gate.validate_ordinary(live, inputs)
    script = update_script(inputs.read(ROOT / "test/run-tests.sh", EXPECTED_RUNNER))
    proposals = []
    for name in gate.ORDINARY:
        row = rows[name]
        original = live["initial_fixture_inputs"][name]
        golden = ROOT / "test" / (name + ".golden")
        # The generic offline comparator permits reviewed changes; preparation
        # and application instead require every ordinary golden still original.
        before = inputs.read(golden, original["golden_sha256"])
        if row["status"] != "baseline_drift_review_pending":
            continue
        raw = inputs.read(row["raw_capture_path"], row["raw_capture_sha256"])
        after = normalized_update(raw, script)
        require(before != after, f"{name}: original drift produces no golden byte change")
        proposals.append({"fixture": name + ".txt", "golden_path": str(golden),
            "source_sha256": original["source_sha256"],
            "original_golden_sha256": digest(before),
            "raw_capture_path": row["raw_capture_path"],
            "raw_capture_sha256": digest(raw), "proposed_golden_sha256": digest(after),
            "original_runner_exit_code": row["runner_exit_code"],
            "original_status": row["status"], "before": before, "after": after})
    require(proposals, "No original drift rows need an update")
    return live, rows, proposals, {"live_receipt_path": str(LIVE),
        "live_receipt_sha256": digest(live_bytes),
        "captured_executable_path": str(executable),
        "captured_executable_sha256": EXPECTED_EXE,
        "production_runner_sha256": EXPECTED_RUNNER,
        "capture_wrapper_sha256": EXPECTED_WRAPPER,
        "production_update_script_sha256": digest(script.encode("utf-8")),
        "original_live_runner_exit_code": live["exit_code"],
        "original_live_status": live["status"],
        "live_fixture_count": 26, "live_synthesis_command_count": 175}


def public_row(row):
    return {key: value for key, value in row.items() if key not in ("before", "after")}


def validate_audit(path, inputs, provenance, rows):
    data = inputs.read(path)
    audit = parse_json(data)
    required = {"status": "passed", "validation_mode": "offline_saved_replay_audit",
        "live_fixture_count": 26, "live_synthesis_command_count": 175,
        "explicit_fixture_count": 24, "explicit_query_count": 170,
        "live_receipt_sha256": provenance["live_receipt_sha256"],
        "captured_leant_executable_sha256": EXPECTED_EXE,
        "original_live_runner_exit_code": provenance["original_live_runner_exit_code"]}
    require(all(audit.get(key) == value for key, value in required.items()),
            "Explicit-query audit is incomplete or refers to different live evidence")
    gate.same_path(audit["live_receipt_path"], LIVE)
    inputs.read(HERE / "validate-ordinary-replay.py", audit["validator_sha256"])
    for prefix in ("policy", "replay_receipt"):
        inputs.read(audit[prefix + "_path"], audit[prefix + "_sha256"])
    expected = {name + ".txt" for name in gate.ORDINARY
                if name not in ("prove-suggest", "synth-prove")}
    reviewed = audit["fixtures"]
    require(len(reviewed) == 24 and {row["fixture"] for row in reviewed} == expected,
            "Explicit-query audit has missing, duplicate, or unexpected fixtures")
    for review in reviewed:
        live_row = rows[Path(review["fixture"]).stem]
        original = live_row["source_before"]
        require(review["source_sha256"] == original["source_sha256"] and
                review["original_golden_sha256"] == original["golden_sha256"] and
                review["raw_capture_sha256"] == live_row["raw_capture_sha256"],
                "Explicit-query audit source/golden/capture identity differs")
        for segment in review["segments"]:
            for prefix in ("replay", "kernel_output"):
                inputs.read(segment[prefix + "_path"], segment[prefix + "_sha256"])
    return {"path": str(path.resolve()), "sha256": digest(data),
            "validated_fields": required, "replayed_term_count": audit["replayed_term_count"]}


LIMITATIONS = [
    "No new synthesis, compiler, or kernel process is run by this helper.",
    "The saved explicit-query audit is checked, not rerun; its stated limitations remain in force.",
    "Proof-mode/tactic behavior, negative diagnoses, evaluations, and other control changes require root review.",
    "Additional review evidence is preserved by hash; no pass status is inferred from its filename.",
    "Golden text agreement does not establish semantic equivalence or improved behavior.",
    "Original live exit codes and all original reports/captures remain unchanged.",
]


def preview(args):
    require(args.preview is None and args.audit is None and not args.review_evidence and
            args.approval_note is None, "Review/apply arguments require --apply")
    output = output_path(args.output or QUALITY / "ordinary-golden-preview")
    inputs = gate.Inputs()
    live, _, proposals, provenance = collect(inputs)
    inputs.recheck()
    output.mkdir(parents=True, exist_ok=True)
    (output / "proposed").mkdir()
    (output / "diffs").mkdir()
    receipt = {"status": "prepared", "validation_mode": "offline_ordinary_golden_preview",
        "prepared_utc": now(), **provenance, "tracked_files_changed": False,
        "external_review_approved": False, "limitations": LIMITATIONS,
        "selected_fixture_count": len(proposals),
        "unchanged_original_match_count": 26 - len(proposals),
        "input_sha256": {str(path): sha for path, sha in inputs.hashes.items()}, "fixtures": []}
    for row in proposals:
        stem = Path(row["fixture"]).stem
        proposed = output / "proposed" / (stem + ".golden")
        difference = output / "diffs" / (stem + ".diff")
        with proposed.open("xb") as stream:
            stream.write(row["after"])
        diff = "".join(difflib.unified_diff(
            row["before"].decode("utf-8-sig").splitlines(keepends=True),
            row["after"].decode("utf-8").splitlines(keepends=True),
            fromfile="original/" + stem + ".golden", tofile="proposed/" + stem + ".golden"))
        with difference.open("xb") as stream:
            stream.write(diff.encode("utf-8"))
        receipt["fixtures"].append({**public_row(row), "proposal_path": str(proposed),
            "diff_path": str(difference), "diff_sha256": digest(diff.encode("utf-8"))})
    inputs.recheck()
    write_json(output / "preview.json", receipt)
    print(f"Prepared {len(proposals)} original drift proposals; no tracked files changed: {output}")


def apply(args):
    require(args.preview is not None and args.audit is not None and
            args.approval_note is not None and args.approval_note.strip(),
            "--apply requires --preview, --audit, and an explicit root --approval-note")
    preview_path = args.preview.resolve(strict=True)
    require(preview_path.is_relative_to(QUALITY.resolve()), "Preview must be under quality-results")
    output = output_path(args.output or QUALITY / "ordinary-golden-application", (preview_path.parent,))
    inputs = gate.Inputs()
    prepared = parse_json(inputs.read(preview_path))
    require(prepared["status"] == "prepared" and
            prepared["validation_mode"] == "offline_ordinary_golden_preview" and
            prepared["tracked_files_changed"] is False,
            "Input is not an untouched preparation receipt")
    for path, sha in prepared["input_sha256"].items():
        inputs.read(path, sha)
    _, rows, proposals, provenance = collect(inputs)
    require(all(prepared[key] == value for key, value in provenance.items()),
            "Live evidence or production normalization changed after preview")
    require(prepared["selected_fixture_count"] == len(proposals) and
            [row["fixture"] for row in prepared["fixtures"]] ==
            [row["fixture"] for row in proposals], "Preview drift selection differs")
    for row, prior in zip(proposals, prepared["fixtures"], strict=True):
        require(all(prior[key] == value for key, value in public_row(row).items()),
                f"Preview metadata differs: {row['fixture']}")
        gate.same_path(prior["proposal_path"], preview_path.parent / "proposed" /
                       (Path(row["fixture"]).stem + ".golden"))
        require(inputs.read(prior["proposal_path"], row["proposed_golden_sha256"]) == row["after"],
                "Proposal differs from production-filtered capture")
        inputs.read(prior["diff_path"], prior["diff_sha256"])
    audit = validate_audit(args.audit, inputs, provenance, rows)
    evidence = [{"path": str(path.resolve()), "sha256": digest(inputs.read(path))}
                for path in args.review_evidence]
    inputs.recheck()
    output.mkdir(parents=True, exist_ok=True)
    (output / "originals").mkdir()
    (output / "staged").mkdir()
    journal_path = output / "application.json"
    journal = {"status": "preflight_passed", "validation_mode": "offline_reviewed_golden_application",
        "started_utc": now(), **provenance, "preview_path": str(preview_path),
        "preview_sha256": digest(preview_path.read_bytes()), "explicit_query_audit": audit,
        "root_approval_note": args.approval_note, "external_review_evidence": evidence,
        "external_proof_and_control_review_asserted_by_invocation": True,
        "is_new_kernel_validation": False, "limitations": LIMITATIONS,
        "selected_fixture_count": len(proposals), "applied_fixture_count": 0,
        "replacement_attempt_count": 0,
        "input_sha256": {str(path): sha for path, sha in inputs.hashes.items()}, "fixtures": []}
    write_json(journal_path, journal)
    try:
        # Back up every original before touching any tracked path. A failure is
        # journalled and never silently rolled back or retried over new evidence.
        for row in proposals:
            stem = Path(row["fixture"]).stem
            backup = output / "originals" / (stem + ".golden")
            staged = output / "staged" / (stem + ".golden")
            for path, data in ((backup, row["before"]), (staged, row["after"])):
                with path.open("xb") as stream:
                    stream.write(data)
            journal["fixtures"].append({**public_row(row), "backup_path": str(backup),
                "backup_sha256": digest(backup.read_bytes()), "status": "backed_up"})
        inputs.recheck()
        journal["status"] = "applying"
        write_json(journal_path, journal, replace=True)
        for row, result in zip(proposals, journal["fixtures"], strict=True):
            target = Path(row["golden_path"])
            inputs.recheck()
            require(digest(target.read_bytes()) == row["original_golden_sha256"],
                    f"Golden changed before replacement: {target}")
            journal["replacement_attempt_count"] += 1
            result["status"] = "replacement_pending"
            write_json(journal_path, journal, replace=True)
            os.replace(output / "staged" / target.name, target)
            # Change only this input's expected value; every other frozen input
            # remains subject to the same check before the next replacement.
            inputs.hashes[target.resolve()] = row["proposed_golden_sha256"]
            require(digest(target.read_bytes()) == row["proposed_golden_sha256"],
                    f"Golden replacement did not preserve proposed bytes: {target}")
            result["status"] = "applied"
            journal["applied_fixture_count"] += 1
            write_json(journal_path, journal, replace=True)
        inputs.recheck()
        journal["status"] = "applied"
        journal["finished_utc"] = now()
        journal["next_step"] = "Run the separate production-normalizer composite comparison; this helper is not that comparison."
        write_json(journal_path, journal, replace=True)
    except BaseException as error:
        journal["status"] = "failed_during_application" if journal["replacement_attempt_count"] else "failed_before_application"
        journal["finished_utc"] = now()
        journal["error"] = str(error)
        journal["current_golden_sha256"] = {row["golden_path"]:
            digest(Path(row["golden_path"]).read_bytes()) for row in proposals}
        write_json(journal_path, journal, replace=True)
        raise
    print(f"Applied {len(proposals)} reviewed drift proposals; original bytes backed up: {output}")


def main():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--preview", type=Path, help="Frozen preview.json, required only with --apply")
    parser.add_argument("--audit", type=Path, help="Passed offline_saved_replay_audit receipt, required with --apply")
    parser.add_argument("--approval-note", help="Root assertion covering proof-mode, diagnostics, evaluations, and controls")
    parser.add_argument("--review-evidence", action="append", type=Path, default=[],
                        help="Optional proof/control receipt or note; preserved by hash, with no invented status schema")
    args = parser.parse_args()
    (apply if args.apply else preview)(args)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, OSError, subprocess.SubprocessError) as error:
        print(f"FAILED: {error}", file=sys.stderr)
        raise SystemExit(2)
