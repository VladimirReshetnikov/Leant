module Main (main) where

import Control.Monad (forM_)
import Data.Foldable (toList)
import Data.List (nub)
import qualified Data.Map.Strict as Map
import qualified Data.Set as Set
import qualified Language.Haskell.Djex as Djex
import Leant.Synth.Engine
import Leant.Synth.Fragment (Frag (..))
import System.IO (BufferMode (LineBuffering), hSetBuffering, stdout)

-- Exact shape of the live quality fixture:
-- forall A R : Type, (A -> R -> R) -> R -> R.
nilGoal :: Frag
nilGoal = FAll True "A" $ FAll True "R" $
  FArr (FArr (FVar "A") $ FArr (FVar "R") $ FVar "R") $
    FArr (FVar "R") $ FVar "R"

probeLimits :: SynthLimits
probeLimits = defaultSynthLimits
  { synthLimitRanking = Djex.defaultCandidateRankingPolicy
  , synthLimitShown = 4
  , synthLimitTried = 12
  , synthLimitWindow = 12
  , synthLimitBudget = Just 10000
  , synthLimitQueue = 1024
  }

main :: IO ()
main = do
  hSetBuffering stdout LineBuffering
  putStrLn $ "fragment = " ++ show nilGoal
  putStrLn $ "limits = " ++ show probeLimits
  putStrLn "Exference maximum steps = 10000"
  putStrLn "Pure Engine probe: no Main wall-clock wrapper or Lean verification."
  case inspectExferencePreparation [] [] nilGoal nilGoal of
    Left failure -> putStrLn $ "preparation failed: " ++ failure
    Right preparation -> do
      putStrLn $ "prepared source goal = " ++ show (inspectedSourceGoal preparation)
      putStrLn $ "prepared search goal = " ++ show (inspectedSearchGoal preparation)
      putStrLn $ "prepared declarations = " ++ show (inspectedDeclarations preparation)
      putStrLn $ "prepared constructor map = " ++ show (inspectedConstructorMap preparation)
      directTypedTrace preparation
  case synthesizeWithProvidersSkippingDetailedWith
      probeLimits EngineExference 10000 Set.empty [] nilGoal of
    Left failure -> putStrLn $ "synthesis failed: " ++ failure
    Right (DetailedSynthCandidates groups notes) -> do
      putStrLn $ "notes = " ++ show notes
      forM_ (zip [0 :: Int ..] $ take 4 groups) $ \(index, group) -> do
        putStrLn $ "group " ++ show index ++ " route = " ++ show (detailedCandidateGroupRoute group)
        putStrLn $ "group " ++ show index ++ " variants = " ++ show (detailedCandidateGroupVariants group)
        case detailedCandidateGroupSemanticSidecar group of
          Nothing -> putStrLn "semantic sidecar = absent"
          Just semantic -> do
            let authority = typedCandidateSemanticAuthorityInspection semantic
                request = inspectedAuthorityRequest authority
                policy = inspectedAuthorityPolicy authority
                candidate = typedCandidateSemanticCandidate semantic
                compatibility = Djex.typedCandidateCompatibility candidate
            putStrLn $ "request goal = " ++ show (Djex.requestGoal request)
            putStrLn $ "request options = " ++ show (Djex.requestOptions request)
            putStrLn $ "non-strict constructor arities = " ++ show
              (Map.toList $ Djex.exferenceNonStrictConstructors policy)
            putStrLn $ "source rating overrides = " ++ show
              (Map.toList $ Djex.exferenceRatingOverrides policy)
            putStrLn $ "compatibility expression = " ++ show
              (Djex.functionClauseExpression $ Djex.candidateOutput compatibility)
            case Djex.typedCandidateTermGraph candidate of
              Left failure -> putStrLn $ "typed graph unavailable = " ++ show failure
              Right graph -> do
                putStrLn "typed graph = available"
                putStrLn $ "erased typed graph = " ++ show (Djex.eraseTermGraph graph)
    Right other -> putStrLn $ "synthesis outcome = " ++ show other

-- Recreate Engine.exferenceRun's initial strict lane through public Djex
-- entrances, before rendering can discard a graph-absence reason.
directTypedTrace :: PreparedSynthesisInspection -> IO ()
directTypedTrace preparation = do
  putStrLn "DIRECT PUBLIC TYPED QUERY (before Leant rendering)"
  standard <- requireDiagnostic Djex.standardDjinnSession
  let declarations = Djex.environmentDeclarations (Djex.djinnSessionEnvironment standard)
        ++ inspectedDeclarations preparation
      goal = inspectedSearchGoal preparation
      names = nub $ concatMap Djex.declarationTypeVariables declarations ++ toList goal
      table = Map.fromList $ zip names [0 :: Int ..]
      -- This is Engine's total-on-the-collected-inventory conversion: every
      -- declaration and goal variable was inserted into the same table above.
      convert variable = Djex.FlexibleVariable (table Map.! variable)
  arities <- requireShown $ leanNonStrictConstructorArities
    (inspectedConstructorMap preparation) declarations
  let policy = Djex.defaultExferenceSessionPolicy
        { Djex.exferenceNonStrictConstructors = arities }
      options = Djex.defaultExferenceOptions
        { Djex.exferenceAllowUnused = False
        , Djex.exferenceMaximumSteps = 10000
        , Djex.exferenceCandidateRanking = Djex.defaultCandidateRankingPolicy
        , Djex.exferenceProviderCosts = Map.empty
        , Djex.exferenceMultiConstructorPatterns = True
        , Djex.exferenceMaximumQueueSize = Just 1024
        }
  environment <- requireShown $ Djex.mkEnvironment
    (map (Djex.mapDeclarationTypeVariables convert) declarations)
  session <- requireDiagnostic $ Djex.mkExferenceSessionWithPolicy policy environment
  targetName <- requireShown $ Djex.mkIdentifier "leantSynth"
  target <- requireShown $ Djex.mkDefinitionName targetName
  let query = Djex.QueryRequest
        { Djex.requestTarget = target
        , Djex.requestGoal = fmap convert goal
        , Djex.requestContexts = []
        , Djex.requestOptions = options
        }
  request <- requireDiagnostic $ Djex.mkExferenceRequest query
  putStrLn $ "direct variable table = " ++ show (Map.toList table)
  putStrLn $ "direct converted goal = " ++ show (Djex.requestGoal query)
  putStrLn $ "direct options = " ++ show options
  putStrLn $ "direct constructor authority = " ++ show (Map.toList arities)
  results <- requireDiagnostic $
    Djex.runExferenceTypedQueryWithKindedInstantiationAssignments session [] request
  let candidates = take 12 $ concatMap (Djex.batchCandidates . Djex.resultSearch) results
  forM_ (zip [0 :: Int ..] candidates) $ \(index, candidate) -> do
    let compatibility = Djex.functionClauseExpression $ Djex.candidateOutput
          $ Djex.typedCandidateCompatibility candidate
        constructorArity name = fromIntegral <$> Map.lookup name arities
    putStrLn $ "direct candidate " ++ show index ++ " compatibility = " ++ show compatibility
    putStrLn $ "direct candidate " ++ show index ++ " standalone reduction (diagnostic only) = "
      ++ show (Djex.reduceKnownConstructorCasesBy id constructorArity compatibility)
    case Djex.typedCandidateTermGraph candidate of
      Left failure -> putStrLn $ "direct candidate " ++ show index
        ++ " typed graph unavailable = " ++ show failure
      Right graph -> putStrLn $ "direct candidate " ++ show index
        ++ " erased typed graph = " ++ show (Djex.eraseTermGraph graph)
  putStrLn $ "direct observed candidate count (at most 12) = " ++ show (length candidates)

requireShown :: Show failure => Either failure value -> IO value
requireShown = either (ioError . userError . show) pure

requireDiagnostic :: Either Djex.Diagnostic value -> IO value
requireDiagnostic = either (ioError . userError . Djex.renderDiagnostic) pure
