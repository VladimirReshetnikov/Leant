"""Prepare exact synth-prove replay from its terminal E0 ordinary-fixture row.

This helper never starts Lean, Leant, a compiler, or any subprocess. It creates
a successful replay module, a separate expected-#eval-error module, and a
preparation receipt. Root must run and inspect both modules independently.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
QUALITY = ROOT / "test-church/quality-results"
EXE = "e0b9c87cae0bc34d59c8d5a34a58fdd5005676913969a80d5503d7281081d025"
SOURCE_HASH = "969b5dc63585338a3c36d814eaa41ffbd9841c0ee364bcb049141805df41fa59"
GOLDEN_HASH = "24bf049d11ab886243a11897b420bf18a8f466e7d5ca584e7aeeb916a5fb03f4"
PROMPT = re.compile(r"^(λ|⊢)>[ \t]?(.*)$")
CANDIDATE = re.compile(r"^[ \t]+it([0-9]+)[ \t]+(.+)$")
DIAGNOSTIC = re.compile(r"^(?:note:|debug |warning:|error:|REPL error:|synthesis engine error:)")
CLASSICAL = ["Classical.choice", "Quot.sound", "propext"]
QUERY_BLOCKS = [1, 6, 9, 13, 15]
PROOF_TYPES = [
    "∀ p : Prop, Decidable p → Decidable (¬ p)",
    "∀ (p q : Prop) (h : p → q) (hp : p), q ∧ p",
]
EXPECTED_PROMPTS = ["λ", "⊢", "⊢", "⊢", "λ", "⊢", "⊢", "⊢", "⊢",
                    "λ", "λ", "λ", "λ", "λ", "λ", "λ", "λ"]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_hashed(path, expected):
    data = path.read_bytes()
    require(sha(data) == expected, f"Recorded hash mismatch: {path}")
    return data


def command_blocks(text):
    blocks = []
    for line in text.splitlines():
        prompt = PROMPT.match(line)
        if prompt:
            blocks.append({"prompt": prompt[1], "command": prompt[2], "lines": []})
        elif blocks:
            blocks[-1]["lines"].append(line)
    return blocks


def terms_in(block):
    terms, active = [], None

    def finish():
        nonlocal active
        if active is not None:
            while active["lines"] and not active["lines"][-1].strip():
                active["lines"].pop()
            term = "\n".join(active["lines"])
            require(term and not re.search(r"\b(?:sorry|admit|sorryAx|axiom|unsafe)\b", term),
                    "Unchecked or empty candidate")
            require(not re.search(r"\bit(?:[0-9]+)?(?:\b|!)", term),
                    "Candidate depends on an unreconstructed generated binding")
            terms.append({"label": active["label"], "term": term})
            active = None

    for line in block["lines"]:
        candidate = CANDIDATE.match(line)
        if candidate:
            finish()
            active = {"label": int(candidate[1]), "lines": [candidate[2]]}
        elif DIAGNOSTIC.match(line):
            finish()
        elif active is not None:
            active["lines"].append(line)
    finish()
    require([term["label"] for term in terms] == list(range(1, len(terms) + 1)),
            "Missing, extra, duplicate, or reordered candidate labels")
    return terms


def main():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, default=QUALITY / "ordinary-final/results.json")
    parser.add_argument("--output", type=Path, default=QUALITY / "synth-prove-review")
    args = parser.parse_args()
    report_path, out = args.report.resolve(), args.output.resolve()
    require(report_path == (QUALITY / "ordinary-final/results.json").resolve(), "Unexpected live receipt")
    require(out.is_relative_to(QUALITY.resolve()) and out != QUALITY.resolve(), "Output must stay under quality-results")
    require(not out.exists() or out.is_dir() and not any(out.iterdir()), "Output must be a new empty directory")
    report_bytes = report_path.read_bytes()
    report = json.loads(report_bytes.decode("utf-8-sig"))
    require(report["validation_mode"] == "live_ordinary_golden_comparison", "Wrong receipt mode")
    rows = [row for row in report["fixtures"] if row["fixture"] == "synth-prove.txt"]
    require(len(rows) == 1, "Expected exactly one terminal synth-prove row")
    row = rows[0]
    require(row["status"] in ("original_golden_matched", "baseline_drift_review_pending") and
            row["finished_utc"] is not None, "Fixture is incomplete or has a process/capture failure")
    matched = row["status"] == "original_golden_matched"
    outcome = ("ok   " if matched else "FAIL ") + "synth-prove.txt"
    require(row["runner_exit_code"] == (0 if matched else 1) and row["outcome_lines"] == [outcome],
            "Original terminal outcome is inconsistent")
    executable = Path(report["initial_executable"]["path"]).resolve()
    for snapshot in (report["initial_executable"], row["executable_before"], row["executable_after"]):
        require(snapshot["sha256"] == EXE and snapshot["matches_initial"] is True and
                snapshot["resolution_exit_code"] == 0 and Path(snapshot["path"]).resolve() == executable,
                "Wrong or unstable E0 executable identity")
    read_hashed(executable, EXE)
    source_path, golden_path = ROOT / "test/synth-prove.txt", ROOT / "test/synth-prove.golden"
    source_bytes = read_hashed(source_path, SOURCE_HASH)
    golden_bytes = read_hashed(golden_path, GOLDEN_HASH)
    for snapshot in (report["initial_fixture_inputs"]["synth-prove"], row["source_before"], row["source_after"]):
        require(snapshot["source_sha256"] == SOURCE_HASH and snapshot["golden_sha256"] == GOLDEN_HASH and
                snapshot["synthesis_command_count"] == 5 and Path(snapshot["source_path"]).resolve() == source_path.resolve()
                and Path(snapshot["golden_path"]).resolve() == golden_path.resolve(), "Source/golden snapshot changed")
    capture = QUALITY / "ordinary-final/transcripts/synth-prove.output.txt"
    require(Path(row["raw_capture_path"]).resolve() == capture.resolve(), "Unexpected capture path")
    raw = read_hashed(capture, row["raw_capture_sha256"])
    commands = [line for line in source_bytes.decode("utf-8-sig").splitlines() if line.strip()]
    blocks = command_blocks(raw.decode("utf-8-sig"))
    require([block["command"] for block in blocks] == commands and
            [block["prompt"] for block in blocks] == EXPECTED_PROMPTS,
            "Capture does not preserve all source commands and proof/ordinary prompt identities")
    require([i for i, command in enumerate(commands) if command == ":synth" or command.startswith(":synth ")]
            == QUERY_BLOCKS, "Changed two-bare/three-explicit query inventory")
    for index, block in enumerate(blocks):
        errors = [line for line in block["lines"] if re.match(r"^(?:error:|REPL error:|synthesis engine error:|Lean error:)", line)]
        require(index == 11 or not errors, f"Unexpected error in command {index}: {errors}")
    for index in (2, 7):
        require("All goals accomplished 🎉" in blocks[index]["lines"] and
                "finish with :qed [NAME], inspect with :script" in blocks[index]["lines"],
                "Fresh exact-it1 application did not close its proof goal")
    require("(synthesizing with hypotheses p q h hp as premises)" in blocks[6]["lines"],
            "Second bare synthesis lost its captured-context identity")
    require("synth classical: off" in blocks[12]["lines"] and "synth classical: on" in blocks[14]["lines"],
            "Classical setting switch was not acknowledged")
    saved = "saved: theorem mp_and : ∀ p q : Prop, (p → q) → p → q ∧ p"
    require(saved in blocks[8]["lines"], "Saved theorem name/type changed")
    query_rows = []
    for query_index, block_index in enumerate(QUERY_BLOCKS):
        block = blocks[block_index]
        ty = PROOF_TYPES[query_index] if query_index < 2 else block["command"][len(":synth "):]
        query_rows.append({"query_index": query_index, "source_line": block_index + 1,
                           "prompt": block["prompt"], "source_command": block["command"],
                           "wrapped_type": ty, "captured_arguments": ["p", "q", "h", "hp"] if query_index == 1 else [],
                           "terms": terms_in(block), "raw_response_lines": block["lines"]})
    require(all(query_rows[i]["terms"] for i in (0, 1, 2, 4)) and not query_rows[3]["terms"],
            "Successful/constructive-negative query statuses changed")
    require(len(query_rows[2]["terms"]) >= 2, "#check it2 lacks a fresh second Option candidate")
    negative = blocks[13]["lines"]
    require("provably uninhabited — no closed term of this polymorphic type exists" in negative and
            "(constructively — a classical proof may still exist; this is not a disproof of the proposition)" in negative,
            "Constructive negative diagnosis/qualification changed; review separately")
    first = query_rows[0]["terms"][0]["term"]
    second = query_rows[1]["terms"][0]["term"]
    abort_lines = blocks[3]["lines"]
    require(abort_lines and abort_lines[0] == "left prove mode; the script was:" and
            "\n".join(abort_lines[1:]).strip() == "exact (" + first + ")",
            "Printed abort script is not the exact selected first candidate splice")
    check_text = "\n".join(blocks[10]["lines"]).strip()
    require(check_text == "it (a b : Type) : Option a → Option b → Option (a × b)",
            "Fresh #check it2 changed; inspect rather than silently adapting the replay")
    error_text = "\n".join(blocks[11]["lines"]).strip()
    require(error_text.startswith("error: Application type mismatch: The argument\n") and
            "\n  some 3\nhas type\n  Option " in error_text and
            "\nbut is expected to have type\n  Type\nin the application\n  it (some 3)" in error_text and
            error_text.count("error:") == 1, "#eval did not produce the expected specific argument-type error")

    lean = ["-- Prepared from exact fresh synth-prove output; not yet kernel-validated.",
            "set_option linter.unusedVariables false", "noncomputable section", "namespace SynthProveReplay", ""]
    declarations = []
    for query in query_rows:
        for candidate in query["terms"]:
            name = f"q{query['query_index']}_it{candidate['label']}"
            lean += [f"def {name} : {query['wrapped_type']} :=",
                     "\n".join("  " + line for line in candidate["term"].splitlines()),
                     f"#print axioms {name}", ""]
            declarations.append({"name": "SynthProveReplay." + name,
                                 "query_index": query["query_index"], "label": candidate["label"],
                                 "allowed_axioms": CLASSICAL if query["query_index"] == 4 else []})
    lean += [f"def abort_exact_replayed : {PROOF_TYPES[0]} := by",
             "  exact (" + first + ")", "#print axioms abort_exact_replayed", "",
             "theorem mp_and : ∀ p q : Prop, (p → q) → p → q ∧ p := by",
             "  intro p q h hp", "  exact ((" + second + ") p q h hp)",
             "#print axioms mp_and", "#check mp_and", "#check q2_it2", "end SynthProveReplay", ""]
    # Indent every line of the exact term's tactic embedding equally, preserving
    # its relative layout. Candidate definitions above retain that text too.
    for prefix, term, suffix in (("  exact (", first, ")"), ("  exact ((", second, ") p q h hp)")):
        index = lean.index(prefix + term + suffix)
        lean[index] = prefix + term.replace("\n", "\n  ") + suffix
    declarations += [{"name": "SynthProveReplay.abort_exact_replayed", "allowed_axioms": []},
                     {"name": "SynthProveReplay.mp_and", "allowed_axioms": []}]
    option_first = query_rows[2]["terms"][0]["term"]
    error_module = "\n".join([
        "-- Expected failure only: do not repair the fixture by supplying type arguments.",
        "set_option linter.unusedVariables false", "noncomputable section",
        f"def it : {query_rows[2]['wrapped_type']} :=",
        "\n".join("  " + line for line in option_first.splitlines()),
        "#eval (it (some 3) (some true) : Option (Nat × Bool))", ""])
    require(report_path.read_bytes() == report_bytes, "Live receipt changed during preparation; retry after it settles")
    read_hashed(source_path, SOURCE_HASH)
    read_hashed(golden_path, GOLDEN_HASH)
    read_hashed(capture, row["raw_capture_sha256"])
    read_hashed(executable, EXE)
    out.mkdir(parents=True, exist_ok=True)
    successful_path, error_path = out / "Successful.lean", out / "ExpectedEvalError.lean"
    successful_path.write_text("\n".join(lean), encoding="utf-8", newline="\n")
    error_path.write_text(error_module, encoding="utf-8", newline="\n")
    prepared = {
        "validation_mode": "preparation_only_from_terminal_fixture_capture", "created_utc": datetime.now(timezone.utc).isoformat(),
        "kernel_replay_run": False, "synthesis_run": False, "independent_validation_passed": None,
        "source_path": str(source_path), "source_sha256": SOURCE_HASH,
        "original_golden_path": str(golden_path), "original_golden_sha256": GOLDEN_HASH,
        "original_report_path": str(report_path), "original_report_sha256": sha(report_bytes),
        "original_fixture_row": row, "capture_path": str(capture), "capture_sha256": sha(raw),
        "leant_executable_sha256": EXE, "executable_current_hash_rechecked": True,
        "query_count": 5, "bare_proof_query_count": 2, "explicit_query_count": 3,
        "candidate_count": sum(len(query["terms"]) for query in query_rows), "queries": query_rows,
        "successful_module": str(successful_path), "successful_module_sha256": sha(successful_path.read_bytes()),
        "expected_error_module": str(error_path), "expected_error_module_sha256": sha(error_path.read_bytes()),
        "expected_axiom_allowances": declarations, "recorded_abort_script": "exact (" + first + ")",
        "recorded_save_message": saved, "recorded_check_output": check_text, "recorded_expected_error": error_text,
        "expected_error_acceptance": "Nonzero Lean exit with exactly the Application type mismatch at the #eval command: some 3 has Option type where Type is expected. Reject all other errors; successful-module checking must pass independently.",
        "negative_query_review": "Constructive no-inhabitant classification and its non-disproof qualification retained verbatim; positive replay does not prove that diagnosis.",
        "proof_session_review": "The abort session is replayed independently but remains aborted in original history; mp_and uses the exact selected function applied to p q h hp.",
        "next_steps": [f"lean +leanprover/lean4:v4.32.0 {successful_path}",
                       f"lean +leanprover/lean4:v4.32.0 {error_path}",
                       "Require exactly one #print axioms inventory per listed declaration, no sorryAx, and each inventory within its indexed allowance; record actual inventories and reject unexpected dependencies.",
                       "Preserve separate process exits and outputs. Neither the expected error nor this preparation receipt certifies successful candidate replay."],
    }
    (out / "prepared.json").write_text(json.dumps(prepared, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    print(f"Prepared 5 query identities, {prepared['candidate_count']} exact terms and 2 tactic applications; no Lean execution.")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
        print(f"Proof replay preparation refused: {error}", file=sys.stderr)
        raise SystemExit(2)
