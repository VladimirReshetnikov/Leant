axiom Demo.Token : Type
class Demo.C (a : Type 1) : Prop where
  witness : True
instance : Demo.C (∀ x : Type, x → x) := ⟨True.intro⟩
axiom Demo.polyGlobal {a : Type 1} [Demo.C a] : Demo.Token

axiom Gap.Token : Type
class Gap.C (a : Type 1) : Prop where
  witness : True
instance : Gap.C (∀ x : Type, x → x) := ⟨True.intro⟩
abbrev Gap.Contextual := {a : Type} → [Inhabited a] → a
instance : Gap.C Gap.Contextual := ⟨True.intro⟩
axiom Gap.polyGlobal {a : Type 1} [Gap.C a] : Gap.Token


noncomputable def gapExferenceCandidate1 : Gap.Token :=
  Gap.polyGlobal («a» := (∀ {a0_0 : Type _}, [@Inhabited a0_0] → a0_0))
#print axioms gapExferenceCandidate1

noncomputable def gapExferenceCandidate2 : Gap.Token :=
  Gap.polyGlobal («a» := (∀ (a0_0 : Type _), a0_0 → a0_0))
#print axioms gapExferenceCandidate2
