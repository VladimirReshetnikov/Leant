-- Independent source reset segment 0
namespace ContextualOnly

axiom Token : Type

class Pick (a : Type 1) : Prop where
  witness : True

abbrev Choice := {a : Type} → [Inhabited a] → a → a

instance : Pick Choice := ⟨True.intro⟩

axiom chosen {a : Type 1} [Pick a] : Token

end ContextualOnly

namespace HigherContext

axiom Token : Type

class Mark (f : Type → Type) : Prop where
  witness : True

abbrev Choice := {a : Type} → [Mark List] → a → a

class Pick (a : Type 1) : Prop where
  witness : True

instance : Pick Choice := ⟨True.intro⟩

axiom chosen {a : Type 1} [Pick a] : Token

end HigherContext

namespace DependentContext

class Dep where
  T : Type

abbrev Choice := [d : Dep] → d.T

class Pick (a : Type 1) : Prop where
  witness : True

instance : Pick Choice := ⟨True.intro⟩

axiom Token : Type

axiom chosen {a : Type 1} [Pick a] : Token

end DependentContext

noncomputable def goldenReplayQuery1Candidate1 : ContextualOnly.Token :=
  ContextualOnly.chosen («a» := (∀ {a0_0 : Type _}, [@Inhabited a0_0] → a0_0 → a0_0))
#print axioms goldenReplayQuery1Candidate1
noncomputable def goldenReplayQuery2Candidate1 : ContextualOnly.Token :=
  ContextualOnly.chosen («a» := (∀ {a0_0 : Type _}, [@Inhabited a0_0] → a0_0 → a0_0))
#print axioms goldenReplayQuery2Candidate1
noncomputable def goldenReplayQuery5Candidate1 : HigherContext.Token :=
  HigherContext.chosen («a» := (∀ {a0_0 : Type _}, [@HigherContext.Mark List] → a0_0 → a0_0))
#print axioms goldenReplayQuery5Candidate1
