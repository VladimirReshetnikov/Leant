-- Independent source reset segment 1

inductive RefutationExference.Void : Type
class RefutationExference.Choice (a : Type 1) : Prop where witness : True
instance : RefutationExference.Choice (∀ x : Type, x → x) := ⟨True.intro⟩
axiom RefutationExference.impossible {a : Type 1}
    [RefutationExference.Choice a] : RefutationExference.Void

noncomputable def goldenReplayQuery1Candidate1 : RefutationExference.Void :=
  RefutationExference.impossible («a» := (∀ (a0_0 : Type _), a0_0 → a0_0))
#print axioms goldenReplayQuery1Candidate1
