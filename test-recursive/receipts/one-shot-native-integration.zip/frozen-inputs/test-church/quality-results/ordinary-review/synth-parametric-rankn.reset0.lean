-- Independent source reset segment 0
axiom Demo.Secret : Type
axiom Demo.secretValue : Demo.Secret
inductive Demo.Guard (a : Type 1) : Type 1 where
| mk : Demo.Secret → a → Demo.Guard a

inductive Demo.Phantom2 (a b : Type 1) : Type 1 where
| mk : Demo.Phantom2 a b

def Demo.termByType (_ : Type) : Nat := 0
inductive Demo.Tag (n : Nat) : Type where
| mk : Demo.Tag n

noncomputable def goldenReplayQuery0Candidate1 : ((∀ a : Type 1, Option a) → Option (∀ b : Type, b → b)) :=
  fun x => x _
#print axioms goldenReplayQuery0Candidate1
noncomputable def goldenReplayQuery1Candidate1 : ((∀ a b : Type 1, Demo.Phantom2 a b) → Demo.Phantom2 (∀ x : Type, x → x) (∀ y : Type, y → y)) :=
  fun x => x _ _
#print axioms goldenReplayQuery1Candidate1
noncomputable def goldenReplayQuery3Candidate1 : Demo.Secret :=
  Demo.secretValue
#print axioms goldenReplayQuery3Candidate1
noncomputable def goldenReplayQuery4Candidate1 : (Unit → Demo.Secret) :=
  fun x => let y := x; match y with | _ => Demo.secretValue
#print axioms goldenReplayQuery4Candidate1
