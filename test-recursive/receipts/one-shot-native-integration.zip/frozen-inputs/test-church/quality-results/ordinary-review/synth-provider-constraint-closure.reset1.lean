-- Independent source reset segment 1

namespace ClosureSubgoal
axiom Token : Type
private class Need (a : Type 1) : Prop where witness : True
private class Seed (a : Type 1) : Prop where witness : True
private instance : Need (∀ x : Type, x → x) := ⟨True.intro⟩
private instance [Need a] : Seed a := ⟨True.intro⟩
axiom global {a : Type 1} [Seed a] : Token
end ClosureSubgoal

noncomputable def goldenReplayQuery3Candidate1 : ClosureSubgoal.Token :=
  ClosureSubgoal.global («a» := (∀ (a0_0 : Type _), a0_0 → a0_0))
#print axioms goldenReplayQuery3Candidate1
