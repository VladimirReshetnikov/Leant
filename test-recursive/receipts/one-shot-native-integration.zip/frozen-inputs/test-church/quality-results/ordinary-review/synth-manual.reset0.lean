-- Independent source reset segment 0
def double (n : Nat) : Nat := n + n
noncomputable def goldenReplayQuery12Candidate1 : ((S → A × S) → (A → S → B × S) → S → B × S) :=
  fun f g x => match f x with | ⟨y, z⟩ => g y z
#print axioms goldenReplayQuery12Candidate1
noncomputable def goldenReplayQuery12Candidate2 : ((S → A × S) → (A → S → B × S) → S → B × S) :=
  fun f g x => match f x with | ⟨y, _⟩ => g y x
#print axioms goldenReplayQuery12Candidate2
noncomputable def goldenReplayQuery12Candidate3 : ((S → A × S) → (A → S → B × S) → S → B × S) :=
  fun f g x => match f x with | ⟨y, z⟩ => (match g y x with | ⟨w, _⟩ => ⟨w, z⟩)
#print axioms goldenReplayQuery12Candidate3
noncomputable def goldenReplayQuery12Candidate4 : ((S → A × S) → (A → S → B × S) → S → B × S) :=
  fun f g x => match f x with | ⟨y, _⟩ => (match g y x with | ⟨z, _⟩ => ⟨z, x⟩)
#print axioms goldenReplayQuery12Candidate4
noncomputable def goldenReplayQuery12Candidate5 : ((S → A × S) → (A → S → B × S) → S → B × S) :=
  fun f g x => match f x with | ⟨y, z⟩ => (match g y z with | ⟨w, _⟩ => ⟨w, x⟩)
#print axioms goldenReplayQuery12Candidate5
noncomputable def goldenReplayQuery13Candidate1 : ((A → R) → R) → (A → (B → R) → R) → (B → R) → R :=
  fun f g h => f (fun x => g x h)
#print axioms goldenReplayQuery13Candidate1
noncomputable def goldenReplayQuery13Candidate2 : ((A → R) → R) → (A → (B → R) → R) → (B → R) → R :=
  fun f g h => f (fun x => g x (fun y => f (fun _ => h y)))
#print axioms goldenReplayQuery13Candidate2
noncomputable def goldenReplayQuery13Candidate3 : ((A → R) → R) → (A → (B → R) → R) → (B → R) → R :=
  fun f g h => f (fun x => f (fun _ => g x h))
#print axioms goldenReplayQuery13Candidate3
noncomputable def goldenReplayQuery13Candidate4 : ((A → R) → R) → (A → (B → R) → R) → (B → R) → R :=
  fun f g h => f (fun x => f (fun _ => g x (fun y => f (fun _ => h y))))
#print axioms goldenReplayQuery13Candidate4
noncomputable def goldenReplayQuery13Candidate5 : ((A → R) → R) → (A → (B → R) → R) → (B → R) → R :=
  fun f g h => f (fun x => g x (fun y => g x (fun _ => h y)))
#print axioms goldenReplayQuery13Candidate5
axiom Wrap : Type 1 → Type
noncomputable def goldenReplayQuery18Candidate1 : (∀ (F : Type 1 → Type), (∀ a : Type 1, F a) → F (∀ b : Type, b → b)) :=
  fun _ x => x _
#print axioms goldenReplayQuery18Candidate1
noncomputable def goldenReplayQuery18Candidate2 : (∀ (F : Type 1 → Type), (∀ a : Type 1, F a) → F (∀ b : Type, b → b)) :=
  fun _ x => match Sum.inl (x _) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery18Candidate2
noncomputable def goldenReplayQuery18Candidate3 : (∀ (F : Type 1 → Type), (∀ a : Type 1, F a) → F (∀ b : Type, b → b)) :=
  fun _ x => match Sum.inr (x _) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery18Candidate3
noncomputable def goldenReplayQuery19Candidate1 : (∀ p q : Prop, Decidable p → Decidable q → Decidable (p ∧ q)) :=
  fun _ _ x y => match x with | .isFalse k => (match y with | .isFalse k1 => .isFalse (fun ⟨_, z⟩ => k1 z) | .isTrue _ => .isFalse (fun ⟨w, _⟩ => k w)) | .isTrue x1 => (match y with | .isFalse k2 => .isFalse (fun ⟨_, x2⟩ => k2 x2) | .isTrue x3 => .isTrue ⟨x1, x3⟩)
#print axioms goldenReplayQuery19Candidate1
opaque P : Nat → Prop
opaque Q : Prop
noncomputable def goldenReplayQuery30Candidate1 : ((A → B → C) → (A → B) → A → C) :=
  fun f g x => f x (g x)
#print axioms goldenReplayQuery30Candidate1
