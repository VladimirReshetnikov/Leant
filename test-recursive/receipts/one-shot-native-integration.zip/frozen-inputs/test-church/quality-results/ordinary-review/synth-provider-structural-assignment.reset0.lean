-- Independent source reset segment 0
namespace StructuralDirect

axiom Token : Type
axiom LeftType : Type
axiom RightType : Type

class Choice (F : Type → Type → Type) (G : Type → Type) : Prop where
  witness : True

instance : Choice Prod (Sum LeftType) := ⟨True.intro⟩

axiom consume {F : Type → Type → Type} {G : Type → Type}
    [Choice F G] : F LeftType RightType → G RightType → Token

abbrev Goal :=
  Prod LeftType RightType → Sum LeftType RightType → Token

end StructuralDirect

namespace StructuralContext

axiom Token : Type
axiom Fixed : Type

class Binary (F : Type → Type → Type) : Prop where
  witness : True

class Unary (G : Type → Type) : Prop where
  witness : True

abbrev Selected :=
  {a : Type} → [Binary Prod] → [Unary (Sum Fixed)] → a → a

class Pick (selected : Type 1) : Prop where
  witness : True

instance : Pick Selected := ⟨True.intro⟩

axiom choose {selected : Type 1} [Pick selected] : Token

end StructuralContext

noncomputable def goldenReplayQuery2Candidate1 : StructuralDirect.Goal :=
  fun x y => let _ := x; match y with | .inl _ => StructuralDirect.consume x y | .inr _ => StructuralDirect.consume x y
#print axioms goldenReplayQuery2Candidate1
noncomputable def goldenReplayQuery2Candidate2 : StructuralDirect.Goal :=
  fun x y => let _ := x; match y with | .inl _ => StructuralDirect.consume («F» := Prod) («G» := (Sum (StructuralDirect.LeftType))) x y | .inr _ => StructuralDirect.consume x y
#print axioms goldenReplayQuery2Candidate2
noncomputable def goldenReplayQuery2Candidate3 : StructuralDirect.Goal :=
  fun x y => let ⟨z, w⟩ := x; match y with | .inl _ => StructuralDirect.consume x y | .inr _ => StructuralDirect.consume («F» := Prod) («G» := (Sum (StructuralDirect.LeftType))) ⟨z, w⟩ y
#print axioms goldenReplayQuery2Candidate3
noncomputable def goldenReplayQuery2Candidate4 : StructuralDirect.Goal :=
  fun x y => let ⟨z, _⟩ := x; match y with | .inl _ => StructuralDirect.consume x y | .inr w => StructuralDirect.consume («F» := Prod) («G» := (Sum (StructuralDirect.LeftType))) ⟨z, w⟩ y
#print axioms goldenReplayQuery2Candidate4
noncomputable def goldenReplayQuery2Candidate5 : StructuralDirect.Goal :=
  fun x y => let ⟨_, z⟩ := x; match y with | .inl _ => StructuralDirect.consume x y | .inr _ => StructuralDirect.consume («F» := Prod) («G» := (Sum (StructuralDirect.LeftType))) x (.inr z)
#print axioms goldenReplayQuery2Candidate5
noncomputable def goldenReplayQuery4Candidate1 : StructuralDirect.Goal :=
  StructuralDirect.consume («F» := Prod) («G» := (Sum (StructuralDirect.LeftType)))
#print axioms goldenReplayQuery4Candidate1
noncomputable def goldenReplayQuery4Candidate2 : StructuralDirect.Goal :=
  fun ⟨x, y⟩ => StructuralDirect.consume («F» := Prod) («G» := (Sum (StructuralDirect.LeftType))) ⟨x, y⟩
#print axioms goldenReplayQuery4Candidate2
noncomputable def goldenReplayQuery4Candidate3 : StructuralDirect.Goal :=
  fun ⟨x, y⟩ _ => StructuralDirect.consume («F» := Prod) («G» := (Sum (StructuralDirect.LeftType))) ⟨x, y⟩ (.inl x)
#print axioms goldenReplayQuery4Candidate3
noncomputable def goldenReplayQuery4Candidate4 : StructuralDirect.Goal :=
  fun ⟨x, y⟩ _ => StructuralDirect.consume («F» := Prod) («G» := (Sum (StructuralDirect.LeftType))) ⟨x, y⟩ (.inr y)
#print axioms goldenReplayQuery4Candidate4
noncomputable def goldenReplayQuery5Candidate1 : StructuralContext.Token :=
  StructuralContext.choose («selected» := (∀ {a0_0 : Type _}, [@StructuralContext.Binary Prod] → [@StructuralContext.Unary (Sum (StructuralContext.Fixed))] → a0_0 → a0_0))
#print axioms goldenReplayQuery5Candidate1
