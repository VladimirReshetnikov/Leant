-- Independent source reset segment 0
inductive Demo.RecBox (a : Type 1) : Type 1 where
| step : a → Demo.RecBox a → Demo.RecBox a


opaque Demo.Seed : Type
inductive Demo.Inner (a : Type 1) : Type 1 where
| done : a → Demo.Inner a
| again : Demo.Inner a → Demo.Inner a

inductive Demo.Outer (a : Type 1) : Type 1 where
| wrap : Demo.Inner a → Demo.Outer a
| again : Demo.Outer a → Demo.Outer a


inductive Demo.Headed (a : Type 1) : Type 1 where
| mk : a → Demo.Headed a → Demo.Headed a

noncomputable def goldenReplayQuery3Candidate1 : (Demo.Headed (∀ x : Type, x → x) → (∀ x : Type, x → x)) :=
  fun x => let y := x; match y with | ⟨f, _⟩ => f
#print axioms goldenReplayQuery3Candidate1
noncomputable def goldenReplayQuery3Candidate2 : (Demo.Headed (∀ x : Type, x → x) → (∀ x : Type, x → x)) :=
  fun x => let y := x; match y with | ⟨_, _⟩ => (fun _ z => z)
#print axioms goldenReplayQuery3Candidate2
noncomputable def goldenReplayQuery3Candidate3 : (Demo.Headed (∀ x : Type, x → x) → (∀ x : Type, x → x)) :=
  fun x => let y := x; match y with | ⟨f, _⟩ => (fun _ z => f _ (f _ z))
#print axioms goldenReplayQuery3Candidate3
noncomputable def goldenReplayQuery3Candidate4 : (Demo.Headed (∀ x : Type, x → x) → (∀ x : Type, x → x)) :=
  fun x => let y := x; match y with | ⟨f, _⟩ => (fun _ z => f _ (f _ (f _ z)))
#print axioms goldenReplayQuery3Candidate4
