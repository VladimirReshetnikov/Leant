-- Independent source reset segment 0
namespace ClosureGood
axiom Token : Type
private class LeftChoice (a : Type 1) : Prop where witness : True
private class RightChoice (b : Type 1) : Prop where witness : True
private instance : LeftChoice (∀ x : Type, x → x) := ⟨True.intro⟩
private instance : RightChoice (∀ x : Type, x → x → x) := ⟨True.intro⟩
axiom global {a b : Type 1} [LeftChoice a] [RightChoice b] : Token
end ClosureGood

noncomputable def goldenReplayQuery1Candidate1 : ClosureGood.Token :=
  ClosureGood.global («a» := (∀ (a0_0 : Type _), a0_0 → a0_0)) («b» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0))
#print axioms goldenReplayQuery1Candidate1
