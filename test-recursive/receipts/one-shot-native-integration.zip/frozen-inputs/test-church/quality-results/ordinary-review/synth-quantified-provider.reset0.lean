-- Independent source reset segment 0
axiom Demo.Token : Type
class Demo.C (a : Type 1) : Prop where
  witness : True
instance : Demo.C (∀ x : Type, x → x) := ⟨True.intro⟩
axiom Demo.polyGlobal {a : Type 1} [Demo.C a] : Demo.Token

axiom Gap.Token : Type
class Gap.C (a : Type 1) : Prop where
  witness : True
instance : Gap.C (∀ x : Type, x → x) := ⟨True.intro⟩
abbrev Gap.Contextual := {a : Type} → [Inhabited a] → a
instance : Gap.C Gap.Contextual := ⟨True.intro⟩
axiom Gap.polyGlobal {a : Type 1} [Gap.C a] : Gap.Token

noncomputable def goldenReplayQuery0Candidate1 : Gap.Token :=
  Gap.polyGlobal («a» := (∀ {a0_0 : Type _}, [@Inhabited a0_0] → a0_0))
#print axioms goldenReplayQuery0Candidate1
noncomputable def goldenReplayQuery0Candidate2 : Gap.Token :=
  Gap.polyGlobal («a» := (∀ (a0_0 : Type _), a0_0 → a0_0))
#print axioms goldenReplayQuery0Candidate2
noncomputable def goldenReplayQuery1Candidate1 : Gap.Token :=
  Gap.polyGlobal («a» := (∀ {a0_0 : Type _}, [@Inhabited a0_0] → a0_0))
#print axioms goldenReplayQuery1Candidate1
noncomputable def goldenReplayQuery1Candidate2 : Gap.Token :=
  Gap.polyGlobal («a» := (∀ (a0_0 : Type _), a0_0 → a0_0))
#print axioms goldenReplayQuery1Candidate2
noncomputable def goldenReplayQuery1Candidate3 : Gap.Token :=
  Gap.polyGlobal («a» := (∀ {a0_0 : Type _}, [@Inhabited a0_0] → a0_0))
#print axioms goldenReplayQuery1Candidate3
noncomputable def goldenReplayQuery2Candidate1 : Gap.Token :=
  Gap.polyGlobal («a» := (∀ {a0_0 : Type _}, [@Inhabited a0_0] → a0_0))
#print axioms goldenReplayQuery2Candidate1
noncomputable def goldenReplayQuery2Candidate2 : Gap.Token :=
  Gap.polyGlobal («a» := (∀ (a0_0 : Type _), a0_0 → a0_0))
#print axioms goldenReplayQuery2Candidate2
noncomputable def goldenReplayQuery4Candidate1 : ((∀ x : Type, x → x) → Demo.Token) :=
  fun f => f _ (Demo.polyGlobal («a» := (∀ (a0_0 : Type _), a0_0 → a0_0)))
#print axioms goldenReplayQuery4Candidate1
noncomputable def goldenReplayQuery4Candidate2 : ((∀ x : Type, x → x) → Demo.Token) :=
  fun f => f _ (f _ (Demo.polyGlobal («a» := (∀ (a0_0 : Type _), a0_0 → a0_0))))
#print axioms goldenReplayQuery4Candidate2
noncomputable def goldenReplayQuery4Candidate3 : ((∀ x : Type, x → x) → Demo.Token) :=
  fun f => f _ (f _ (f _ (Demo.polyGlobal («a» := (∀ (a0_0 : Type _), a0_0 → a0_0)))))
#print axioms goldenReplayQuery4Candidate3
noncomputable def goldenReplayQuery5Candidate1 : ((∀ x : Type, x → x) → Demo.Token) :=
  fun _ => Demo.polyGlobal («a» := (∀ (a0_0 : Type _), a0_0 → a0_0))
#print axioms goldenReplayQuery5Candidate1
noncomputable def goldenReplayQuery5Candidate2 : ((∀ x : Type, x → x) → Demo.Token) :=
  fun f => f _ (Demo.polyGlobal («a» := (∀ (a0_0 : Type _), a0_0 → a0_0)))
#print axioms goldenReplayQuery5Candidate2
noncomputable def goldenReplayQuery7Candidate1 : ((∀ x : Type, x → x) → ({a : Type 1} → Demo.Token) → Demo.Token) :=
  fun f x => f _ (@x (∀ (a0_0 : Type _), a0_0 → a0_0))
#print axioms goldenReplayQuery7Candidate1
noncomputable def goldenReplayQuery7Candidate2 : ((∀ x : Type, x → x) → ({a : Type 1} → Demo.Token) → Demo.Token) :=
  fun f x => f _ (f _ (@x (∀ (a0_0 : Type _), a0_0 → a0_0)))
#print axioms goldenReplayQuery7Candidate2
noncomputable def goldenReplayQuery7Candidate3 : ((∀ x : Type, x → x) → ({a : Type 1} → Demo.Token) → Demo.Token) :=
  fun f x => f _ (f _ (f _ (@x (∀ (a0_0 : Type _), a0_0 → a0_0))))
#print axioms goldenReplayQuery7Candidate3
