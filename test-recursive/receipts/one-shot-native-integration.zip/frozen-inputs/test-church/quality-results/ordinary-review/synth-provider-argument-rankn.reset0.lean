-- Independent source reset segment 0
axiom ProviderLambda.Result : Type
axiom ProviderLambda.consume : (∀ A : Type, A → A) → ProviderLambda.Result
noncomputable def goldenReplayQuery0Candidate1 : ProviderLambda.Result :=
  ProviderLambda.consume (fun _ x => x)
#print axioms goldenReplayQuery0Candidate1
noncomputable def goldenReplayQuery1Candidate1 : ProviderLambda.Result :=
  ProviderLambda.consume (fun _ x => x)
#print axioms goldenReplayQuery1Candidate1
