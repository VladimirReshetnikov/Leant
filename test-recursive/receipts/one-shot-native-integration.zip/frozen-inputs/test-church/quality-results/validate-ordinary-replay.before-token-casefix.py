"""Audit saved ordinary drift replays; never run a compiler or change a receipt.

This is an ignored, snapshot-specific review aid. Run only AFTER the live
26-fixture wrapper and the 24-fixture --replay helper have both finished, and
BEFORE updating the original goldens. --selfcheck uses synthetic data only.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import importlib.util
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
POLICY_HASH = "621876d842da30fb1905d212f56342b729e9fe36e623c8ab158cd713823e3384"
HELPER_HASH = "90aaaf1a5c49fad25b00bf38b95ba3ea48a3a078542eb11d34466cd8b5f1611b"
EXE_HASH = "e0b9c87cae0bc34d59c8d5a34a58fdd5005676913969a80d5503d7281081d025"
PROOF_FIXTURES = {"prove-suggest.txt", "synth-prove.txt"}
INVENTORY = re.compile(
    r"(?m)^'([^'\r\n]+)' (does not depend on any axioms|depends on axioms:\s*\[[^\]]*\])\s*$")
DECLARATION = re.compile(r"goldenReplayQuery(\d+)Candidate(\d+)\Z")
BAD_DIAGNOSTIC = re.compile(r"(?m)^(?:error:|REPL error:|synthesis engine error:|unknown command|usage:)")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_hashed(path, expected=None):
    data = path.read_bytes()
    actual = digest(data)
    require(expected is None or actual == expected, f"hash mismatch: {path}")
    return data, actual


def unique_object(pairs):
    obj = {}
    for key, value in pairs:
        require(key not in obj, f"duplicate JSON key: {key}")
        obj[key] = value
    return obj


def read_json(path, expected=None):
    data, sha = read_hashed(path, expected)
    return json.loads(data.decode("utf-8-sig"), object_pairs_hook=unique_object), sha


def indexed(rows, field, label):
    require(isinstance(rows, list), f"{label} is not an array")
    keys = [row[field] for row in rows]
    require(len(set(keys)) == len(keys), f"duplicate {label}")
    return dict(zip(keys, rows))


def same_path(recorded, expected):
    require(isinstance(recorded, str) and Path(recorded).resolve() == expected.resolve(),
            f"unexpected path: {recorded!r}; expected {expected}")


def source_queries(source):
    rows, segment = [], 0
    for number, line in enumerate(source.splitlines(), 1):
        if line == ":reset":
            segment += 1
        elif line.startswith(":synth "):
            rows.append({"query_index": len(rows), "source_line": number,
                         "reset_segment": segment, "goal": line[len(":synth "):]})
    return rows, segment + 1


def kernel_inventories(output, declarations, policies):
    require(not re.search(r"\b(?:sorry|admit|sorryAx)\b", output), "unchecked kernel proof marker")
    require(not BAD_DIAGNOSTIC.search(output), "kernel error diagnostic")
    matches = list(INVENTORY.finditer(output))
    names = [match[1] for match in matches]
    require(len(set(names)) == len(names), "duplicate kernel inventory")
    require(set(names) == set(declarations), "missing or unexpected kernel inventory")
    # Also reject malformed inventory headers which the valid-inventory regex
    # did not consume, rather than silently ignoring a second/truncated record.
    headers = re.findall(r"(?m)^'([^'\r\n]+)' (?:does not depend|depends on axioms)", output)
    require(headers == names, "malformed or duplicate kernel inventory header")
    raw, checked = {}, []
    for match in matches:
        name, statement = match[1], match[2]
        identity = DECLARATION.fullmatch(name)
        require(identity is not None, f"unexpected replay declaration {name}")
        query_index, candidate_label = map(int, identity.groups())
        require(query_index in policies and candidate_label > 0, f"unindexed declaration {name}")
        axioms = ([] if statement == "does not depend on any axioms" else
                  [part.strip() for part in statement.split("[", 1)[1][:-1].split(",") if part.strip()])
        require(len(axioms) == len(set(axioms)), f"duplicate axiom in {name}")
        allowed = policies[query_index]["allowed_axioms"]
        require(isinstance(allowed, list) and all(isinstance(a, str) for a in allowed),
                f"malformed allowance for query {query_index}")
        require(set(axioms) <= set(allowed),
                f"{name}: unlisted axioms {sorted(set(axioms) - set(allowed))}")
        raw[name] = [statement]
        checked.append({"declaration": name, "query_index": query_index,
                        "candidate_label": candidate_label, "axioms": axioms,
                        "allowed_axioms": allowed})
    return raw, checked


def load_helper():
    path = ROOT / "test-church/generated-probe/replay_golden_drift.py"
    read_hashed(path, HELPER_HASH)
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location("frozen_ordinary_replay_helper", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # Only pure parsing functions are called below.
    return module


def check_snapshot(snapshot, name, source_sha, golden_sha, count):
    same_path(snapshot["source_path"], ROOT / "test" / name)
    same_path(snapshot["golden_path"], (ROOT / "test" / name).with_suffix(".golden"))
    require(snapshot["source_sha256"] == source_sha and snapshot["golden_sha256"] == golden_sha,
            f"source/original-golden snapshot mismatch: {name}")
    require(snapshot["synthesis_command_count"] == count, f"live query count mismatch: {name}")


def check_executable(snapshot, initial):
    require(snapshot["resolution_exit_code"] == 0 and snapshot["matches_initial"] is True,
            "failed or changed executable resolution")
    require(snapshot["sha256"] == EXE_HASH, "wrong executable capture hash")
    same_path(snapshot["path"], Path(initial["path"]))


def check_live(live, policy_names, live_path):
    require(live["validation_mode"] == "live_ordinary_golden_comparison", "wrong live receipt mode")
    require(live["live_execution_complete"] is True and live["finished_utc"], "live run is incomplete")
    require(live["expected_fixture_count"] == live["completed_fixture_count"] == 26 and
            live["expected_query_count"] == 175, "wrong live fixture/query coverage")
    require(live["errors"] == [] and all(live[key] is True for key in
            ("executable_unchanged", "fixture_inputs_unchanged", "runner_unchanged")),
            "live identity or process failure")
    require(live["baseline_updates"] is False and live["synth_timeout_seconds"] == 600,
            "live run changed baselines or configured budget")
    require((live["status"], live["exit_code"]) in {
        ("live_comparison_failed_review_required", 1),
        ("all_original_goldens_matched_kernel_review_not_run", 0)}, "unsuccessful live wrapper")
    requested = live["requested_fixtures"]
    require(len(requested) == 26 and set(requested) == policy_names | PROOF_FIXTURES,
            "wrong or duplicate requested live fixtures")
    rows = indexed(live["fixtures"], "fixture", "live fixtures")
    require(list(rows) == requested, "missing or reordered live rows")
    same_path(live["repository"], ROOT)
    same_path(live["captures_directory"], live_path.parent / "transcripts")
    same_path(live["runner_path"], ROOT / "test/run-tests.sh")
    same_path(live["wrapper_path"], HERE / "run-remaining-quality.ps1")
    read_hashed(Path(live["runner_path"]), live["runner_sha256"])
    read_hashed(Path(live["wrapper_path"]), live["wrapper_sha256"])
    initial = live["initial_executable"]
    snapshots = indexed(live["executable_snapshots"], "label", "executable snapshots")
    expected_labels = {"initial", "final"} | {f"{Path(n).stem}.{side}"
                       for n in requested for side in ("before", "after")}
    require(set(snapshots) == expected_labels, "missing executable snapshot")
    require(snapshots["initial"] == initial and snapshots["final"] == live["final_executable"],
            "top-level executable snapshots differ")
    for snapshot in snapshots.values():
        check_executable(snapshot, initial)
    require(set(live["initial_fixture_inputs"]) == set(live["final_fixture_inputs"]) ==
            {Path(n).stem for n in requested}, "missing full input snapshots")
    total = 0
    for name, row in rows.items():
        stem = Path(name).stem
        require(row["finished_utc"], f"unfinished live row: {name}")
        outcome = {"original_golden_matched": (0, [f"ok   {name}"]),
                   "baseline_drift_review_pending": (1, [f"FAIL {name}"])}.get(row["status"])
        require(outcome is not None and (row["runner_exit_code"], row["outcome_lines"]) == outcome,
                f"runner/capture failure: {name}")
        same_path(row["command"]["cwd"], ROOT)
        same_path(row["command"]["executable"], Path(live["bash_path"]))
        require(row["command"]["arguments"] == ["--noprofile", "--norc", "test/run-tests.sh", stem],
                f"unexpected live command or golden-update option: {name}")
        same_path(row["runner_log"], live_path.parent / f"{stem}.runner.log")
        log = Path(row["runner_log"]).read_text(encoding="utf-8-sig")
        require(re.findall(r"(?m)^(?:ok   |FAIL |MISSING |updated )[^\r\n]*", log) == outcome[1],
                f"runner log outcome mismatch: {name}")
        for side in ("before", "after"):
            require(row[f"executable_{side}"] == snapshots[f"{stem}.{side}"],
                    f"fixture executable provenance mismatch: {name}")
        source, source_sha = read_hashed(ROOT / "test" / name)
        _, golden_sha = read_hashed((ROOT / "test" / name).with_suffix(".golden"))
        count = sum(line == ":synth" or line.startswith(":synth ")
                    for line in source.decode("utf-8-sig").splitlines())
        total += count
        for snapshot in (row["source_before"], row["source_after"],
                         live["initial_fixture_inputs"][stem], live["final_fixture_inputs"][stem]):
            check_snapshot(snapshot, name, source_sha, golden_sha, count)
        capture = live_path.parent / "transcripts" / f"{stem}.output.txt"
        same_path(row["raw_capture_path"], capture)
        read_hashed(capture, row["raw_capture_sha256"])
    require(total == 175, "actual live source command count differs")
    require(live["all_original_comparisons_passed"] == all(
            row["status"] == "original_golden_matched" for row in rows.values()),
            "original-comparison summary disagrees with rows")
    return rows


def validate(policy_path, replay_path, live_path):
    policy, policy_sha = read_json(policy_path, POLICY_HASH)
    replay, replay_sha = read_json(replay_path)
    live, live_sha = read_json(live_path)
    helper = load_helper()
    policies = indexed(policy["fixtures"], "fixture", "policy fixtures")
    require(len(policies) == 24 and sum(row["query_count"] for row in policies.values()) == 170,
            "wrong policy coverage")
    live_rows = check_live(live, set(policies), live_path)
    require(replay["input_mode"] == "raw_capture" and replay["kernel_replay_requested"] is True,
            "replay was only prepared or uses reconstructed diffs")
    require(replay["leant_executable_sha256"] == EXE_HASH, "replay executable hash differs")
    rows = indexed(replay["fixtures"], "fixture", "replay fixtures")
    require(set(rows) == set(policies), "replay must cover exactly all 24 indexed fixtures")
    reviewed = []
    for name, fixed in policies.items():
        row, live_row = rows[name], live_rows[name]
        stem = Path(name).stem
        require(row["status"] == "passed" and row["input_mode"] == "raw_capture" and
                row["leant_executable_sha256"] == EXE_HASH, f"incomplete replay: {name}")
        source_path, golden_path = ROOT / "test" / name, (ROOT / "test" / name).with_suffix(".golden")
        same_path(fixed["source_path"], source_path)
        same_path(fixed["golden_path"], golden_path)
        source_bytes, source_sha = read_hashed(source_path, fixed["source_sha256"])
        old_bytes, golden_sha = read_hashed(golden_path, fixed["golden_sha256"])
        require(row["source_sha256"] == source_sha and row["golden_before_sha256"] == golden_sha,
                f"replay source/original golden mismatch: {name}")
        source, old = source_bytes.decode("utf-8-sig"), old_bytes.decode("utf-8-sig")
        source_rows, reset_count = source_queries(source)
        query_policies = indexed(fixed["queries"], "query_index", f"{name} policy queries")
        require(list(query_policies) == list(range(fixed["query_count"])) and
                len(source_rows) == fixed["query_count"] and reset_count == fixed["reset_segment_count"],
                f"policy query/reset count mismatch: {name}")
        for expected in source_rows:
            require(all(query_policies[expected["query_index"]][key] == value
                        for key, value in expected.items()), f"policy query/reset identity mismatch: {name}")
        capture_path = live_path.parent / "transcripts" / f"{stem}.output.txt"
        same_path(row["raw_capture_path"], capture_path)
        _, capture_sha = read_hashed(capture_path, live_row["raw_capture_sha256"])
        require(row["raw_capture_sha256"] == capture_sha, f"replay capture mismatch: {name}")
        actual = capture_path.read_text(encoding="utf-8-sig")
        require(not BAD_DIAGNOSTIC.search(actual), f"error diagnostic in explicit fixture: {name}")
        require(row["actual_sha256"] == digest(actual.encode("utf-8")), f"actual text hash mismatch: {name}")
        actual_path = replay_path.parent / f"{stem}.actual.txt"
        require(actual_path.read_text(encoding="utf-8") == actual, f"saved actual text mismatch: {name}")
        before = helper.validate_correspondence(source, old)
        after = helper.validate_correspondence(source, actual)
        for index, previous in enumerate(before):
            p = query_policies[index]
            require(p["golden_candidate_count"] == len(previous["terms"]) and
                    p["golden_had_candidate"] == bool(previous["terms"]),
                    f"original success/count mismatch: {name}:{index}")
        changes, expected_segments = helper.replay_segments(source, before, after)
        require(row["changed_queries"] == changes, f"changed-query receipt mismatch: {name}")
        require(row["source_query_count"] == len(after) and
                row["successful_query_count"] == sum(bool(q["terms"]) for q in after) and
                row["lost_successful_queries"] == 0, f"query/success receipt mismatch: {name}")
        expected_segments = [segment for segment in expected_segments if segment["declarations"]]
        segments = indexed(row["segments"], "index", f"{name} replay segments")
        require(list(segments) == [s["index"] for s in expected_segments], f"missing/reset-mixed segment: {name}")
        segment_reviews = []
        for expected in expected_segments:
            segment = segments[expected["index"]]
            for key in ("declarations", "omitted_inspections"):
                require(segment[key] == expected[key], f"segment {key} mismatch: {name}")
            require(segment["passed"] is True and segment["kernel_exit_code"] == 0,
                    f"failed or unfinished kernel replay: {name}")
            prefix = replay_path.parent / f'{stem}.reset{expected["index"]}'
            lean_path = prefix.with_suffix(prefix.suffix + ".lean")
            kernel_path = prefix.with_suffix(prefix.suffix + ".kernel.txt")
            same_path(segment["replay_path"], lean_path)
            require(lean_path.read_text(encoding="utf-8") == expected["source"],
                    f"replay source differs from exact captured terms/reset environment: {lean_path}")
            output = kernel_path.read_text(encoding="utf-8")
            raw, inventories = kernel_inventories(output, expected["declarations"], query_policies)
            require(segment["axiom_inventories"] == raw, f"kernel inventory receipt mismatch: {kernel_path}")
            segment_reviews.append({"reset_segment": expected["index"],
                "replay_path": str(lean_path), "replay_sha256": read_hashed(lean_path)[1],
                "kernel_output_path": str(kernel_path), "kernel_output_sha256": read_hashed(kernel_path)[1],
                "inventories": inventories, "omitted_inspections": expected["omitted_inspections"]})
        reviewed.append({"fixture": name, "source_sha256": source_sha,
            "original_golden_sha256": golden_sha, "raw_capture_sha256": capture_sha,
            "saved_actual_sha256": read_hashed(actual_path)[1], "source_query_count": len(after),
            "successful_query_count": row["successful_query_count"],
            "changed_query_indices": [change["query_index"] for change in changes],
            "not_newly_replayed_query_indices": [i for i in range(len(after))
                if i not in {change["query_index"] for change in changes}],
            "negative_query_indices": [i for i, q in enumerate(after) if not q["terms"]],
            "segments": segment_reviews})
    # Detect receipt replacement during this audit; no input is rewritten.
    read_hashed(policy_path, policy_sha)
    read_hashed(replay_path, replay_sha)
    read_hashed(live_path, live_sha)
    return {"status": "passed", "validation_mode": "offline_saved_replay_audit",
        "audited_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "validator_sha256": read_hashed(Path(__file__))[1],
        "policy_path": str(policy_path), "policy_sha256": policy_sha,
        "replay_receipt_path": str(replay_path), "replay_receipt_sha256": replay_sha,
        "live_receipt_path": str(live_path), "live_receipt_sha256": live_sha,
        "replay_helper_sha256": HELPER_HASH, "captured_leant_executable_sha256": EXE_HASH,
        "original_live_runner_exit_code": live["exit_code"],
        "live_fixture_count": 26, "live_synthesis_command_count": 175,
        "explicit_fixture_count": 24, "explicit_query_count": 170,
        "replayed_term_count": sum(len(s["inventories"]) for f in reviewed for s in f["segments"]),
        "limitations": ["No compiler, kernel, synthesis, or subprocess was run by this validator.",
            "Kernel exit codes are recorded helper results, cross-checked with exact replay files and saved inventories.",
            "Unchanged queries have correspondence checks only, not fresh independent kernel replay.",
            "Negative diagnoses, diagnostic drift, proof-mode fixtures, evaluations, and omitted inspections require separate review.",
            "Axiom subsets permit the indexed source assumptions; they do not imply term equivalence or improved behavior.",
            "Executable identity is historical capture provenance, not a new execution or current-binary assertion."],
        "fixtures": reviewed}


def selfcheck():
    policies = {0: {"allowed_axioms": []}, 2: {"allowed_axioms": ["Demo.Token", "Demo.make"]}}
    a, b = "goldenReplayQuery0Candidate1", "goldenReplayQuery2Candidate3"
    empty = f"'{a}' does not depend on any axioms\n"
    full = f"'{b}' depends on axioms: [Demo.Token,\n Demo.make]\n"
    require(kernel_inventories(empty + full, [a, b], policies)[1][1]["axioms"] ==
            ["Demo.Token", "Demo.make"], "multiline inventory selfcheck")
    count = 1
    cases = [(empty + empty, [a]), ("", [a]), (empty + "sorryAx\n", [a]),
             (full.replace("Demo.make", "Classical.choice"), [b]),
             (empty + f"'{a}' depends on axioms: [", [a]),
             (empty + "error: failed\n", [a]), (empty + full, [a]),
             (full.replace("Demo.make", "Demo.Token"), [b])]
    for output, declarations in cases:
        try:
            kernel_inventories(output, declarations, policies)
        except ValueError:
            count += 1
        else:
            raise AssertionError("invalid inventory was accepted")
    try:
        json.loads('{"a": 1, "a": 2}', object_pairs_hook=unique_object)
    except ValueError:
        count += 1
    else:
        raise AssertionError("duplicate JSON key accepted")
    queries, reset_count = source_queries(":synth A\n:reset\n:synth B\n:reset\n:synth C\n")
    require(reset_count == 3 and [q["reset_segment"] for q in queries] == [0, 1, 2], "reset routing selfcheck")
    count += 1
    # Two reset-local definitions deliberately reuse one name. Preparation
    # must not splice either declaration into the other replay environment.
    helper = load_helper()
    source = "def seed : Nat := 0\n:synth Nat\n:reset\ndef seed : Nat := 1\n:synth Nat\n"
    before = [{"type": "Nat", "segment": i, "terms": [{"label": 1, "term": "0"}]} for i in range(2)]
    after = [{"type": "Nat", "segment": i, "terms": [{"label": 1, "term": "seed"}]} for i in range(2)]
    _, segments = helper.replay_segments(source, before, after)
    require(len(segments) == 2 and "def seed : Nat := 1" not in segments[0]["source"] and
            "def seed : Nat := 0" not in segments[1]["source"], "replay reset isolation selfcheck")
    count += 1
    after[1]["terms"] = []
    try:
        helper.replay_segments(source, before, after)
    except ValueError:
        count += 1
    else:
        raise AssertionError("lost successful query accepted")
    try:
        check_live({"validation_mode": "live_ordinary_golden_comparison", "live_execution_complete": False},
                   set(), HERE / "nonexistent-synthetic.json")
    except ValueError:
        count += 1
    else:
        raise AssertionError("incomplete live receipt accepted")
    print(f"PASS: {count} pure inventory/duplicate-key/reset/incomplete-receipt selfchecks; no kernel processes used")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--policy", type=Path, default=HERE / "ordinary-axiom-policy.json")
    parser.add_argument("--replay-receipt", type=Path, default=HERE / "ordinary-review/results.json")
    parser.add_argument("--live-receipt", type=Path, default=HERE / "ordinary-final/results.json")
    parser.add_argument("--output", type=Path, help="optional NEW audit JSON; existing paths are refused")
    parser.add_argument("--selfcheck", action="store_true")
    args = parser.parse_args()
    if args.selfcheck:
        selfcheck()
        return 0
    try:
        report = validate(args.policy.resolve(), args.replay_receipt.resolve(), args.live_receipt.resolve())
        text = json.dumps(report, indent=2, ensure_ascii=False) + "\n"
        if args.output:
            with args.output.open("x", encoding="utf-8") as stream:
                stream.write(text)
        else:
            print(text, end="")
        return 0
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(f"REJECTED: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
