"""Compare all 30 preserved E0 captures with the current reviewed goldens.

Run only after ordinary-final/results.json is complete. No Leant or Lean process
is started, and no original report, capture, or golden is changed. Git Bash is
used only to execute the production transcript normalization functions.
Independent review of ordinary baseline changes remains external: this report
is a text comparison, not a new kernel-validation or live-synthesis receipt.
"""
import argparse
from datetime import datetime, timezone
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
QUALITY = ROOT / "test-church/quality-results"
COMPACT_DIRECTORY = QUALITY / "fixtures-repair"
ORDINARY_DIRECTORY = QUALITY / "ordinary-final"
EXPECTED_EXE = "e0b9c87cae0bc34d59c8d5a34a58fdd5005676913969a80d5503d7281081d025"
BASH = Path(r"C:\Program Files\Git\bin\bash.exe")
UNRECORDED = object()
COMPACT = {
    "synth-church": 9, "synth-church-rankn": 69,
    "synth-church-providers": 6, "synth-church-layered-providers": 6,
}
ORDINARY = (
    "prove-suggest", "synth-basic", "synth-both-frontier", "synth-djinn-providers",
    "synth-five-binder-rankn", "synth-inductives", "synth-instance-implicit",
    "synth-library", "synth-manual", "synth-parametric-rankn", "synth-prove",
    "synth-provider-argument-rankn", "synth-provider-bound-context-head",
    "synth-provider-constraint-closure", "synth-provider-contextual-assignment",
    "synth-provider-higher-kind-assignment", "synth-provider-implicit-visible-result",
    "synth-provider-metadata-fitting", "synth-provider-refutation-fallback",
    "synth-provider-structural-assignment", "synth-quantified-provider",
    "synth-quartic-rankn", "synth-query-closed-rankn", "synth-quintic-rankn",
    "synth-recursive-rankn", "synth-six-binder-rankn",
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


class Inputs:
    """Remember observed bytes, then reject any change during comparison."""

    def __init__(self):
        self.hashes = {}

    def read(self, path, expected_hash=UNRECORDED):
        path = Path(path).resolve(strict=True)
        data = path.read_bytes()
        actual_hash = digest(data)
        if expected_hash is not UNRECORDED:
            require(actual_hash == expected_hash, f"Recorded hash mismatch: {path}")
        require(path not in self.hashes or self.hashes[path] == actual_hash,
                f"Input changed during comparison: {path}")
        self.hashes[path] = actual_hash
        return data

    def recheck(self):
        for path, expected in self.hashes.items():
            require(digest(path.read_bytes()) == expected,
                    f"Input changed during comparison: {path}")


def same_path(actual, expected):
    require(Path(actual).resolve() == Path(expected).resolve(),
            f"Unexpected recorded path: {actual}; expected {expected}")


def query_count(source_bytes):
    return len(re.findall(r"^:synth(?:\s|$)", source_bytes.decode("utf-8-sig"), re.MULTILINE))


def validate_ordinary(run, inputs):
    require(run["validation_mode"] == "live_ordinary_golden_comparison", "Wrong ordinary receipt mode")
    require(run["live_execution_complete"] is True and run["completed_fixture_count"] == 26,
            "The ordinary live run is incomplete; do not compare partial captures")
    require(run["expected_fixture_count"] == 26 and run["expected_query_count"] == 175,
            "Wrong ordinary receipt inventory")
    require(run["requested_fixtures"] == [name + ".txt" for name in ORDINARY] and
            [row["fixture"] for row in run["fixtures"]] == run["requested_fixtures"],
            "Missing, duplicate, reordered, or unexpected ordinary fixtures")
    require(run["errors"] == [] and run["baseline_updates"] is False and
            all(run[key] is True for key in
                ("executable_unchanged", "fixture_inputs_unchanged", "runner_unchanged")),
            "Ordinary live run did not preserve executable/input identity")
    require(run["synth_timeout_seconds"] == 600, "Unexpected ordinary synthesis timeout")
    same_path(run["repository"], ROOT)
    same_path(run["captures_directory"], ORDINARY_DIRECTORY / "transcripts")
    same_path(run["runner_path"], ROOT / "test/run-tests.sh")
    same_path(run["wrapper_path"], QUALITY / "run-remaining-quality.ps1")
    same_path(run["bash_path"], BASH)
    inputs.read(run["runner_path"], run["runner_sha256"])
    inputs.read(run["wrapper_path"], run["wrapper_sha256"])

    initial = run["initial_executable"]
    executable_path = Path(initial["path"]).resolve(strict=True)
    labels = ["initial"] + [name + suffix for name in ORDINARY
                              for suffix in (".before", ".after")] + ["final"]
    snapshots = run["executable_snapshots"]
    require([snapshot["label"] for snapshot in snapshots] == labels,
            "Incomplete executable snapshot sequence")
    by_label = {snapshot["label"]: snapshot for snapshot in snapshots}
    require(initial == by_label["initial"] and run["final_executable"] == by_label["final"],
            "Initial/final executable snapshots disagree")
    for snapshot in snapshots:
        require(snapshot["sha256"] == EXPECTED_EXE and snapshot["matches_initial"] is True and
                snapshot["resolution_exit_code"] == 0, "Wrong or unstable executable snapshot")
        same_path(snapshot["path"], executable_path)
        command = snapshot["command"]
        same_path(command["cwd"], ROOT)
        same_path(command["executable"], BASH)
        require(command["arguments"] == ["--noprofile", "--norc", "-c", "cabal list-bin exe:leant"],
                "Unexpected executable resolution command")
    inputs.read(executable_path, EXPECTED_EXE)
    require(set(run["initial_fixture_inputs"]) == set(ORDINARY) and
            set(run["final_fixture_inputs"]) == set(ORDINARY), "Incomplete fixture snapshots")

    rows = {}
    for row in run["fixtures"]:
        name = Path(row["fixture"]).stem
        require(row["status"] in ("original_golden_matched", "baseline_drift_review_pending"),
                f"{name}: process/capture failure is not reviewable golden drift")
        matched = row["status"] == "original_golden_matched"
        expected_outcome = ("ok   " if matched else "FAIL ") + name + ".txt"
        require(row["runner_exit_code"] == (0 if matched else 1) and
                row["outcome_lines"] == [expected_outcome], f"{name}: inconsistent original outcome")
        same_path(row["runner_log"], ORDINARY_DIRECTORY / (name + ".runner.log"))
        log = inputs.read(row["runner_log"]).decode("utf-8-sig")
        outcomes = [line for line in log.splitlines()
                    if re.match(r"^(?:ok   |FAIL |MISSING |updated )", line)]
        require(outcomes == [expected_outcome], f"{name}: runner log contradicts receipt")
        command = row["command"]
        same_path(command["executable"], BASH)
        same_path(command["cwd"], ROOT)
        require(command["arguments"] == ["--noprofile", "--norc", "test/run-tests.sh", name],
                f"{name}: unexpected runner invocation")
        require(row["executable_before"] == by_label[name + ".before"] and
                row["executable_after"] == by_label[name + ".after"],
                f"{name}: per-fixture executable snapshot mismatch")
        original = run["initial_fixture_inputs"][name]
        source_path = ROOT / "test" / (name + ".txt")
        source_bytes = inputs.read(source_path, original["source_sha256"])
        for snapshot in (original, row["source_before"], row["source_after"],
                         run["final_fixture_inputs"][name]):
            same_path(snapshot["source_path"], source_path)
            same_path(snapshot["golden_path"], source_path.with_suffix(".golden"))
            require(snapshot["source_sha256"] == original["source_sha256"] and
                    snapshot["golden_sha256"] == original["golden_sha256"] and
                    snapshot["synthesis_command_count"] == query_count(source_bytes),
                    f"{name}: original source/golden snapshots disagree")
        require(re.fullmatch(r"[0-9a-f]{64}", original["golden_sha256"]),
                f"{name}: missing original golden hash")
        same_path(row["raw_capture_path"], ORDINARY_DIRECTORY / "transcripts" / (name + ".output.txt"))
        inputs.read(row["raw_capture_path"], row["raw_capture_sha256"])
        rows[name] = row
    all_matched = all(row["status"] == "original_golden_matched" for row in rows.values())
    require(run["all_original_comparisons_passed"] is all_matched and
            run["exit_code"] == (0 if all_matched else 1) and
            run["status"] == ("all_original_goldens_matched_kernel_review_not_run" if all_matched
                               else "live_comparison_failed_review_required"),
            "Original ordinary aggregate status is inconsistent")
    require(sum(query_count(inputs.read(ROOT / "test" / (name + ".txt")))
                for name in ORDINARY) == 175, "Ordinary source command count changed")
    return rows, executable_path


def validate_compact(run, inputs):
    require(run["leant_executable_sha256"] == EXPECTED_EXE and
            run["leant_executable_unchanged"] is True, "Wrong or unstable compact executable")
    names = [row["fixture"] for row in run["fixtures"]]
    require(len(names) == 4 and set(names) == set(COMPACT), "Wrong compact fixture inventory")
    helper_path = QUALITY / "review-compact-captures.py"
    inputs.read(helper_path)
    for dependency in ("run_fixtures.py", "run_corpus.py"):
        inputs.read(ROOT / "test-church" / dependency)
    spec = importlib.util.spec_from_file_location("compact_receipt_review", helper_path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    require(helper.EXPECTED_EXE == EXPECTED_EXE and helper.EXPECTED == COMPACT,
            "Compact receipt helper is pinned to another acceptance inventory")
    rows, reviews = {}, {}
    for row in run["fixtures"]:
        name = row["fixture"]
        # Reparse exact terms, reconstruct recorded kernel input, and check
        # recorded vectors/axioms. This helper function starts no subprocess.
        review, _, _ = helper.inspect_fixture(name, COMPACT[name], row, COMPACT_DIRECTORY, True)
        reviews[name] = review
        inputs.read(ROOT / "test" / (name + ".txt"), row["fixture_source_raw_sha256"])
        for field in ("raw_output", "kernel_source", "kernel_output"):
            inputs.read(row[field + "_path"], row[field + "_sha256"])
        rows[name] = row
    require(sum(review["axiom_free_count"] for review in reviews.values()) == 78,
            "Wrong compact axiom-free inventory")
    return rows, reviews


def production_normalizer(runner_bytes):
    source = runner_bytes.decode("utf-8-sig").replace("\r\n", "\n")
    definitions = []
    for name in ("filter", "normalize_volatile_search_counts"):
        matches = re.findall(r"^" + name + r"\(\) \{\n.*?^\}", source, re.MULTILINE | re.DOTALL)
        require(len(matches) == 1, f"Expected one production {name} definition")
        definitions.append(matches[0])
    return "set -uo pipefail\n" + "\n".join(definitions) + r'''
if [ "$1" = actual ]; then
  if ! actual=$(filter); then exit 2; fi
  printf '%s\n' "$actual" | normalize_volatile_search_counts
else
  normalize_volatile_search_counts
fi
'''


def normalize(data, mode, script):
    result = subprocess.run(
        [str(BASH), "--noprofile", "--norc", "-c", script, "composite-capture-comparison", mode],
        input=data, capture_output=True, cwd=ROOT, timeout=30)
    require(result.returncode == 0,
            f"Production {mode} normalization failed: {result.stderr.decode('utf-8', errors='replace')}")
    return result.stdout


def main():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=QUALITY / "composite-comparison")
    args = parser.parse_args()
    output = args.output.resolve()
    require(output.is_relative_to(QUALITY.resolve()) and output != QUALITY.resolve(),
            "Output must be a new directory under quality-results")
    require(not output.exists() or output.is_dir() and not any(output.iterdir()),
            "Refusing to overwrite existing comparison evidence")
    inputs = Inputs()
    inputs.read(Path(__file__))
    ordinary_report = ORDINARY_DIRECTORY / "results.json"
    compact_report = COMPACT_DIRECTORY / "results.json"
    ordinary_bytes = inputs.read(ordinary_report)
    compact_bytes = inputs.read(compact_report)
    ordinary = json.loads(ordinary_bytes.decode("utf-8-sig"))
    compact = json.loads(compact_bytes.decode("utf-8-sig"))
    ordinary_rows, executable_path = validate_ordinary(ordinary, inputs)
    compact_rows, compact_reviews = validate_compact(compact, inputs)
    names = sorted(set(ORDINARY) | set(COMPACT))
    require(len(ORDINARY) == len(set(ORDINARY)) == 26 and len(names) == 30 and
            set(ORDINARY).isdisjoint(COMPACT), "Composite inventory is not disjoint 26+4")
    require(names == sorted(path.stem for path in (ROOT / "test").glob("*.txt")),
            "Current source fixture inventory differs from the exact 30 captures")
    source_texts = [inputs.read(ROOT / "test" / (name + ".txt")).decode("utf-8-sig") for name in names]
    explicit_count = sum(len(re.findall(r"^:synth[ \t]+\S", source, re.MULTILINE)) for source in source_texts)
    proof_mode_count = sum(len(re.findall(r"^:synth[ \t]*\r?$", source, re.MULTILINE)) for source in source_texts)
    require(explicit_count == 263 and proof_mode_count == 2,
            "Explicit-type/proof-mode command split changed")
    runner_path = ROOT / "test/run-tests.sh"
    runner_bytes = inputs.read(runner_path, ordinary["runner_sha256"])
    script = production_normalizer(runner_bytes)
    rows, diffs = [], []
    for name in names:
        is_compact = name in COMPACT
        receipt_row = (compact_rows if is_compact else ordinary_rows)[name]
        source_path = ROOT / "test" / (name + ".txt")
        golden_path = source_path.with_suffix(".golden")
        source = inputs.read(source_path)
        capture_path = Path(receipt_row["raw_output_path" if is_compact else "raw_capture_path"])
        captured = inputs.read(capture_path)
        golden = inputs.read(golden_path)
        actual = normalize(captured, "actual", script)
        # Pass raw golden bytes unchanged to the production normalizer. Its
        # platform text-mode handling is preserved: the audited MSYS sed strips
        # CRLF on both pipe and file input. Raw hashes still bind original bytes.
        expected = normalize(golden, "golden", script)
        passed = actual == expected
        diff = "".join(difflib.unified_diff(
            expected.decode("utf-8").splitlines(keepends=True),
            actual.decode("utf-8").splitlines(keepends=True),
            fromfile=str(golden_path), tofile=str(capture_path)))
        original_golden = (receipt_row["golden_before_sha256"] if is_compact
                           else receipt_row["source_before"]["golden_sha256"])
        rows.append({
            "fixture": name + ".txt", "capture_group": "compact" if is_compact else "ordinary",
            "source_path": str(source_path), "source_sha256": digest(source),
            "synthesis_command_count": query_count(source),
            "raw_capture_path": str(capture_path), "raw_capture_sha256": digest(captured),
            "original_status": receipt_row["golden_status" if is_compact else "status"],
            "original_live_exit_code": receipt_row["live_exit_code"] if is_compact else None,
            "original_runner_exit_code": receipt_row["runner_exit_code"] if not is_compact else None,
            "original_golden_sha256": original_golden,
            "current_golden_path": str(golden_path), "current_golden_sha256": digest(golden),
            "golden_changed_since_live_comparison": digest(golden) != original_golden,
            "normalized_capture_sha256": digest(actual), "normalized_golden_sha256": digest(expected),
            "recorded_kernel_artifacts_revalidated": is_compact,
            "independent_baseline_review": "external; not certified by this text comparison",
            "passed": passed,
        })
        diffs.append((name, diff))
    require(sum(row["synthesis_command_count"] for row in rows) == 265, "Wrong composite command count")
    require(sum(row["synthesis_command_count"] for row in rows if row["capture_group"] == "compact") == 90,
            "Wrong compact command count")
    inputs.recheck()
    passed = all(row["passed"] for row in rows)
    result = {
        "validation_mode": "offline_comparison_of_two_preserved_live_capture_groups",
        "created_utc": datetime.now(timezone.utc).isoformat(), "passed": passed,
        "helper_sha256": digest(Path(__file__).read_bytes()),
        "leant_executable_path": str(executable_path), "leant_executable_sha256": EXPECTED_EXE,
        "both_live_receipts_preserved_executable_identity": True,
        "current_executable_hash_rechecked": True,
        "original_ordinary_report_path": str(ordinary_report), "original_ordinary_report_sha256": digest(ordinary_bytes),
        "original_ordinary_exit_code": ordinary["exit_code"], "original_ordinary_status": ordinary["status"],
        "original_compact_report_path": str(compact_report), "original_compact_report_sha256": digest(compact_bytes),
        "original_compact_runner_exit_code": None,
        "compact_exit_note": "Compact report records per-fixture live exits and golden statuses, not its shell exit.",
        "capture_provenance": [
            {"group": "compact", "fixture_count": 4, "synthesis_command_count": 90,
             "configured_synthesis_timeout_seconds": 30, "directory": str(COMPACT_DIRECTORY)},
            {"group": "ordinary", "fixture_count": 26, "synthesis_command_count": 175,
             "configured_synthesis_timeout_seconds": 600, "directory": str(ORDINARY_DIRECTORY / "transcripts")},
        ],
        "timeout_scope": "Synthesis settings, not end-to-end startup/serialization/kernel-replay deadlines.",
        "normalization": "Exact production Bash filter and queue-count functions; actual command-substitution semantics; goldens receive only queue-count normalization.",
        "runner_path": str(runner_path), "runner_sha256": digest(runner_bytes),
        "normalization_script_sha256": digest(script.encode("utf-8")),
        "fixture_count": 30, "synthesis_command_count": 265,
        "explicit_type_query_count": explicit_count, "proof_mode_synthesis_command_count": proof_mode_count,
        "compact_recorded_kernel_artifacts_revalidated": True,
        "compact_axiom_free_count": sum(row["axiom_free_count"] for row in compact_reviews.values()),
        "compact_exact_declared_premise_count": 12,
        "ordinary_independent_review": "External; no replay metadata is required or inferred by this comparator.",
        "is_kernel_validation": False, "synthesis_rerun": False, "kernel_rerun": False,
        "source_goldens_modified": False, "original_receipts_modified": False,
        "checked_input_hashes": {str(path): value for path, value in inputs.hashes.items()},
        "fixtures": rows,
    }
    output.mkdir(parents=True, exist_ok=True)
    for name, diff in diffs:
        (output / (name + ".diff")).write_text(diff, encoding="utf-8", newline="\n")
    (output / "comparison.diff").write_text("".join(diff for _, diff in diffs), encoding="utf-8", newline="\n")
    (output / "normalization.sh").write_text(script, encoding="utf-8", newline="\n")
    (output / "results.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n",
                                          encoding="utf-8", newline="\n")
    print(f"Offline composite comparison: {sum(row['passed'] for row in rows)}/30; 265 synthesis commands; "
          f"original ordinary exit={ordinary['exit_code']}; no synthesis or kernel rerun")
    return 0 if passed else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, KeyError, TypeError, OSError, subprocess.SubprocessError) as error:
        print(f"Composite comparison refused: {error}", file=sys.stderr)
        raise SystemExit(2)
