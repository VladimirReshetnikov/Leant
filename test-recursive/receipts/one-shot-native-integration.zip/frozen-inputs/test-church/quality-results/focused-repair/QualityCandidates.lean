set_option linter.unusedVariables false
axiom Quality.Token : Type
axiom Quality.cheap : Unit → Quality.Token
axiom Quality.expensive : Quality.Token
def Quality.case0_1 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case0_1
def Quality.case0_2 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case0_2
def Quality.case0_3 : (∀ A : Type, A → A → A) :=
  fun _ _ x => match Sum.inl x with | .inl a => a | .inr b => b
#print axioms Quality.case0_3
def Quality.case0_4 : (∀ A : Type, A → A → A) :=
  fun _ x y => match Sum.inl y with | .inl _ => x | .inr a => a
#print axioms Quality.case0_4
def Quality.case1_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ f x => match Sum.inr x with | .inl a => f a x | .inr b => b
#print axioms Quality.case1_1
def Quality.case1_2 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ f x => match Sum.inr x with | .inl a => f a (f a x) | .inr b => b
#print axioms Quality.case1_2
def Quality.case1_3 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ f x => match Sum.inr x with | .inl a => f a (f a (f a x)) | .inr b => b
#print axioms Quality.case1_3
def Quality.case1_4 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ f x => match Sum.inr x with | .inl a => f a (f a (f a (f a x))) | .inr b => b
#print axioms Quality.case1_4
def Quality.case2_1 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case2_1
def Quality.case2_2 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case2_2
def Quality.case3_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ _ x => x
#print axioms Quality.case3_1
def Quality.case4_1 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case4_1
def Quality.case4_2 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case4_2
example : (Quality.case4_1 Nat 11 29 = 11 ∨ Quality.case4_2 Nat 11 29 = 11) ∧ (Quality.case4_1 Nat 11 29 = 29 ∨ Quality.case4_2 Nat 11 29 = 29) := by decide
def Quality.case5_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ _ x => x
#print axioms Quality.case5_1
