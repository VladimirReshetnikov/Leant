"""Pure saved-output review of the full post-dedup run against E0 captures.

No process, synthesis, compiler, kernel, or golden update is run. The result is
a candidate/control comparison, never a proof or semantic-equivalence receipt.
Run only after dedup-compatibility/results.json is terminal. E0 ordinary inputs
use ordinary-final (26 fixtures, 600-second allowance); E0 compact inputs use
fixtures-repair (4 fixtures, 30 seconds). The fresh full run uses 30 seconds.
"""
import argparse
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
QUALITY = ROOT / "test-church/quality-results"
FRESH = QUALITY / "dedup-compatibility"
OLD_ORDINARY = QUALITY / "ordinary-final"
OLD_COMPACT = QUALITY / "fixtures-repair"
E0 = "e0b9c87cae0bc34d59c8d5a34a58fdd5005676913969a80d5503d7281081d025"
RUNNER_SHA = "2ab1f5ca729cdd795d3f208024a58c97072a34aa3f664dd1047a09cf0292b4fa"
WRAPPER_SHA = "04e1d195a69f2148bd9e89adff1099102d6d9bd14d433daff6405d7616f03635"
E0_ORDINARY_RECEIPT_SHA = "b628affc980301d690293f6bac0b65bfc2dffeda3864df2fa189ac74bc41eda4"
E0_COMPACT_RECEIPT_SHA = "c9a4a9651fbef932866deb405d30e4f35b94288adce5e2fc3ba5e1b14e2c1f96"
COMPACT = {"synth-church": 9, "synth-church-rankn": 69,
           "synth-church-providers": 6, "synth-church-layered-providers": 6}
ORDER = (
    "synth-quantified-provider", "prove-suggest", "synth-basic", "synth-both-frontier",
    "synth-church", "synth-church-layered-providers", "synth-church-providers",
    "synth-church-rankn", "synth-djinn-providers", "synth-five-binder-rankn",
    "synth-inductives", "synth-instance-implicit", "synth-library", "synth-manual",
    "synth-parametric-rankn", "synth-prove", "synth-provider-argument-rankn",
    "synth-provider-bound-context-head", "synth-provider-constraint-closure",
    "synth-provider-contextual-assignment", "synth-provider-higher-kind-assignment",
    "synth-provider-implicit-visible-result", "synth-provider-metadata-fitting",
    "synth-provider-refutation-fallback", "synth-provider-structural-assignment",
    "synth-quartic-rankn", "synth-query-closed-rankn", "synth-quintic-rankn",
    "synth-recursive-rankn", "synth-six-binder-rankn",
)
PROMPT = re.compile(r"^(λ|⊢[0-9]*|…)>[ \t]?(.*)$")
CANDIDATE = re.compile(r"^[ \t]+it([0-9]+)[ \t]+(.+)$")
DIAGNOSTIC = re.compile(r"^(?:note:|debug |warning:|error:|REPL error:|Lean error:|synthesis engine error:)")
VOLATILE = ("no Lake project", "starting Lean backend", "backend responding", "replaying session")


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"Duplicate JSON key: {key}")
        result[key] = value
    return result


class Inputs:
    def __init__(self):
        self.hashes = {}

    def read(self, path, expected=None):
        path = Path(path).resolve(strict=True)
        data = path.read_bytes()
        actual = digest(data)
        require(expected is None or actual == expected, f"Recorded hash mismatch: {path}")
        require(path not in self.hashes or self.hashes[path] == actual, f"Input changed: {path}")
        self.hashes[path] = actual
        return data

    def json(self, path, expected=None):
        return json.loads(self.read(path, expected).decode("utf-8-sig"), object_pairs_hook=unique_object)

    def recheck(self):
        for path, expected in self.hashes.items():
            require(digest(path.read_bytes()) == expected, f"Input changed during review: {path}")


def same_path(actual, expected):
    require(Path(actual).resolve() == Path(expected).resolve(), f"Unexpected path: {actual}")


def filtered(raw):
    # Pure parsing counterpart of run-tests.sh's filter and command-substitution
    # newline handling. Do not normalize queue telemetry: report its changes.
    # Reject unsupported whitespace instead of guessing a GNU-sed locale rule.
    text = raw.decode("utf-8-sig").replace("\r", "")
    lines = []
    for line in text.split("\n"):
        require(not line or not line[-1].isspace() or line[-1] in " \t\v\f",
                "Non-ASCII trailing whitespace needs separate production-normalizer review")
        line = line.rstrip(" \t\v\f")
        if not line.startswith(VOLATILE):
            lines.append(line)
    return "\n".join(lines).rstrip("\n") + "\n"


def blocks(raw, source):
    # The ordinary replay parser recognizes λ>, while its proof-mode companion
    # also recognizes ⊢>. Retain numbered multi-goal prompts and …> too so every
    # echoed source line is checked and goal-count prompt changes stay visible.
    preamble, result = [], []
    for line in filtered(raw).splitlines():
        prompt = PROMPT.match(line)
        if prompt:
            result.append({"prompt": prompt[1], "command": prompt[2], "lines": []})
        elif result:
            result[-1]["lines"].append(line)
        else:
            preamble.append(line)
    expected = [line.rstrip(" \t\v\f") for line in source.decode("utf-8-sig").splitlines()]
    require([block["command"] for block in result] == expected,
            "Source/capture echo correspondence failed; missing or additional commands cannot be silently paired")
    return preamble, result


def terms_and_controls(block):
    # Preserve continuation indentation as in replay_golden_drift.parse_queries.
    terms, used, active = [], set(), []

    def finish():
        nonlocal active
        if not active:
            return
        while active and not block["lines"][active[-1]].strip():
            active.pop()
        first = CANDIDATE.match(block["lines"][active[0]])
        term = "\n".join([first[2]] + [block["lines"][i] for i in active[1:]])
        terms.append({"label": int(first[1]), "term": term})
        used.update(active)
        active = []

    for index, line in enumerate(block["lines"]):
        if CANDIDATE.match(line):
            finish()
            active = [index]
        elif DIAGNOSTIC.match(line):
            finish()
        elif active:
            active.append(index)
    finish()
    require([row["label"] for row in terms] == list(range(1, len(terms) + 1)),
            "Missing, duplicate, or reordered candidate labels")
    return terms, [line for index, line in enumerate(block["lines"]) if index not in used]


def terminal_ordinary(run, names, exe, directory, *, fresh):
    require(run["live_execution_complete"] is True and run["completed_fixture_count"] == len(names),
            f"Live run is not terminal: {directory}")
    require(run["requested_fixtures"] == [name + ".txt" for name in names] and
            [row["fixture"] for row in run["fixtures"]] == run["requested_fixtures"],
            "Missing, duplicated, reordered, or extra fixture rows")
    require(run["expected_fixture_count"] == len(names) and run["errors"] == [] and
            run["baseline_updates"] is False and all(run[key] is True for key in
            ("executable_unchanged", "fixture_inputs_unchanged", "runner_unchanged")),
            "Live receipt has incomplete inventory, mutation, or identity failures")
    require(run["runner_sha256"] == RUNNER_SHA, "Production runner differs")
    require(run["synth_timeout_seconds"] == (30 if fresh else 600), "Unexpected synthesis allowance")
    same_path(run["repository"], ROOT)
    same_path(run["captures_directory"], directory / "transcripts")
    labels = ["initial"] + [name + suffix for name in names for suffix in (".before", ".after")] + ["final"]
    snapshots = run["executable_snapshots"]
    require([row["label"] for row in snapshots] == labels, "Incomplete executable snapshot sequence")
    lookup = {row["label"]: row for row in snapshots}
    require(run["initial_executable"] == lookup["initial"] and run["final_executable"] == lookup["final"],
            "Initial/final executable snapshots disagree")
    for snapshot in snapshots:
        require(snapshot["sha256"] == exe and snapshot["matches_initial"] is True and
                snapshot["resolution_exit_code"] == 0 and
                (not fresh or snapshot["matches_required"] is True), "Wrong or unstable executable")
        same_path(snapshot["path"], snapshots[0]["path"])
    rows = {}
    for row in run["fixtures"]:
        name = Path(row["fixture"]).stem
        require(row["finished_utc"] and row["status"] in
                ("original_golden_matched", "baseline_drift_review_pending"),
                f"{name}: unfinished/process-failure output cannot be treated as a complete comparison")
        matched = row["status"] == "original_golden_matched"
        require(row["runner_exit_code"] == (0 if matched else 1) and row["outcome_lines"] ==
                [("ok   " if matched else "FAIL ") + name + ".txt"], "Inconsistent original outcome")
        require(row["executable_before"] == lookup[name + ".before"] and
                row["executable_after"] == lookup[name + ".after"], "Per-fixture executable mismatch")
        require(row["command"]["arguments"] == ["--noprofile", "--norc", "test/run-tests.sh",
                name + ".txt" if fresh else name], "Runner pattern differs from recorded coverage")
        original = run["initial_fixture_inputs"][name]
        for snapshot in (row["source_before"], row["source_after"], run["final_fixture_inputs"][name]):
            require(snapshot == original, f"{name}: source/golden snapshots disagree")
        same_path(row["raw_capture_path"], directory / "transcripts" / (name + ".output.txt"))
        if fresh:
            require(row["wrapper_sha256_before"] == row["wrapper_sha256_after"] == WRAPPER_SHA and
                    row["runner_sha256_before"] == row["runner_sha256_after"] == RUNNER_SHA and
                    row["all_fixture_inventory_sha256_before"] == row["all_fixture_inventory_sha256_after"] ==
                    run["initial_fixture_inventory_sha256"], "Per-fixture input inventory changed")
        rows[name] = row
    return rows


def review_fixture(name, source, before, after):
    old_preamble, left = blocks(before, source)
    new_preamble, right = blocks(after, source)
    queries, controls, proof_queries = [], [], []
    segment, engine, query_index = 0, "session default", 0
    for line_number, (old, new) in enumerate(zip(left, right, strict=True), 1):
        command = new["command"]
        if command == ":reset":
            segment += 1
            engine = "session default"
        if command.startswith(":set synth-engine "):
            engine = command.rsplit(" ", 1)[1]
        if command != ":synth" and not command.startswith(":synth "):
            if old != new:
                controls.append({"source_line": line_number, "command": command, "before": old, "after": new})
            continue
        prior_terms, prior_controls = terms_and_controls(old)
        fresh_terms, fresh_controls = terms_and_controls(new)
        a, b = [x["term"] for x in prior_terms], [x["term"] for x in fresh_terms]
        labels = defaultdict(list)
        for term in fresh_terms:
            labels[term["term"]].append(term["label"])
        row = {"query_index": query_index, "source_line": line_number, "reset_segment": segment,
            "engine": engine, "command": command, "prior_candidate_count": len(a),
            "fresh_candidate_count": len(b), "candidate_list_changed": a != b,
            "first_term_changed": (a[:1] != b[:1]),
            "new_spellings": [{"term": term, "fresh_labels": indices} for term, indices in labels.items() if term not in set(a)],
            "removed_spellings": list(dict.fromkeys(term for term in a if term not in set(b))),
            "exact_duplicates": [{"term": term, "fresh_labels": indices} for term, indices in labels.items() if len(indices) > 1],
            "query_control_changed": prior_controls != fresh_controls or old["prompt"] != new["prompt"],
            "prior_query_controls": prior_controls, "fresh_query_controls": fresh_controls,
            "prior_prompt": old["prompt"], "fresh_prompt": new["prompt"]}
        if a != b or row["exact_duplicates"]:
            row.update(prior_candidates=prior_terms, fresh_candidates=fresh_terms)
        if command == ":synth":
            row["prior_candidate_output_lost"] = bool(a) and not b
            row["proof_success_inferred"] = False
            proof_queries.append(row)
        else:
            row["lost_prior_success"] = bool(a) and not b
            queries.append(row)
        query_index += 1
    return {"fixture": name + ".txt", "explicit_queries": queries, "bare_proof_queries": proof_queries,
        "non_query_control_differences": controls,
        "preamble_difference": None if old_preamble == new_preamble else {"before": old_preamble, "after": new_preamble},
        "proof_mode_review_required": name in ("prove-suggest", "synth-prove"),
        "proof_success_inferred": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected-exe-sha256", required=True)
    parser.add_argument("--output", type=Path, default=QUALITY / "dedup-capture-review")
    args = parser.parse_args()
    expected = args.expected_exe_sha256.lower()
    require(re.fullmatch(r"[0-9a-f]{64}", expected) and expected != E0,
            "Supply the new executable hash, distinct from historical E0")
    output = args.output.resolve()
    require(output.is_relative_to(QUALITY.resolve()) and output not in (QUALITY.resolve(), FRESH.resolve()) and
            not any(output.is_relative_to(path.resolve()) for path in (FRESH, OLD_ORDINARY, OLD_COMPACT)),
            "Output must be a new ignored directory outside original evidence")
    require(not output.exists() or output.is_dir() and not any(output.iterdir()), "Refusing nonempty output overwrite")
    inputs = Inputs()
    inputs.read(Path(__file__))
    inputs.read(ROOT / "test/run-tests.sh", RUNNER_SHA)
    inputs.read(QUALITY / "run-post-dedup-quality.ps1", WRAPPER_SHA)
    fresh = inputs.json(FRESH / "results.json")
    ordinary = inputs.json(OLD_ORDINARY / "results.json", E0_ORDINARY_RECEIPT_SHA)
    compact = inputs.json(OLD_COMPACT / "results.json", E0_COMPACT_RECEIPT_SHA)
    require(fresh["validation_mode"] == "live_post_dedup_golden_comparison" and
            fresh["required_executable_sha256"] == expected and fresh["expected_query_count"] == 265 and
            fresh["wrapper_unchanged"] is True and fresh["wrapper_sha256"] == fresh["final_wrapper_sha256"] == WRAPPER_SHA,
            "Wrong fresh run or wrapper")
    new_rows = terminal_ordinary(fresh, ORDER, expected, FRESH, fresh=True)
    # Historical E0 is checked through its saved snapshots. Its original path
    # now contains the rebuilt executable and must NOT be rehashed as E0.
    old_order = tuple(sorted(set(ORDER) - set(COMPACT)))
    require(ordinary["validation_mode"] == "live_ordinary_golden_comparison" and
            ordinary["expected_query_count"] == 175, "Wrong E0 ordinary inventory")
    old_rows = terminal_ordinary(ordinary, old_order, E0, OLD_ORDINARY, fresh=False)
    require(compact["leant_executable_sha256"] == E0 and compact["leant_executable_unchanged"] is True and
            len(compact["fixtures"]) == 4 and {row["fixture"] for row in compact["fixtures"]} == set(COMPACT),
            "Wrong E0 compact inventory")
    compact_rows = {row["fixture"]: row for row in compact["fixtures"]}
    inputs.read(fresh["final_executable"]["path"], expected)
    reviews, inventory_lines = [], []
    for name in ORDER:
        new = new_rows[name]
        original = new["source_before"]
        source_path = ROOT / "test" / (name + ".txt")
        same_path(original["source_path"], source_path)
        same_path(original["golden_path"], source_path.with_suffix(".golden"))
        source = inputs.read(source_path, original["source_sha256"])
        inputs.read(source_path.with_suffix(".golden"), original["golden_sha256"])
        inventory_lines.append(f'{name}\t{original["source_sha256"]}\t{original["golden_sha256"]}')
        if name in COMPACT:
            old = compact_rows[name]
            require(old["live_exit_code"] == 0 and old["validation_passed_before_golden"] is True and
                    old["kernel_exit_code"] == 0 and old["case_count"] == old["candidate_count"] == COMPACT[name],
                    "E0 compact row was incomplete")
            old_source_hash, old_capture, old_hash = old["fixture_source_raw_sha256"], old["raw_output_path"], old["raw_output_sha256"]
            same_path(old_capture, OLD_COMPACT / (name + ".output.txt"))
            old_outcome = {"live_exit_code": old["live_exit_code"], "golden_status": old["golden_status"]}
        else:
            old = old_rows[name]
            old_source_hash, old_capture, old_hash = old["source_before"]["source_sha256"], old["raw_capture_path"], old["raw_capture_sha256"]
            old_outcome = {"runner_exit_code": old["runner_exit_code"], "status": old["status"]}
        require(old_source_hash == original["source_sha256"], f"{name}: source differs between E0 and fresh run")
        before = inputs.read(old_capture, old_hash)
        after = inputs.read(new["raw_capture_path"], new["raw_capture_sha256"])
        review = review_fixture(name, source, before, after)
        require(len(review["explicit_queries"]) + len(review["bare_proof_queries"]) == original["synthesis_command_count"],
                f"{name}: query count differs from receipt")
        review["provenance"] = {"source_sha256": old_source_hash,
            "prior_capture_path": old_capture, "prior_capture_sha256": old_hash,
            "fresh_capture_path": new["raw_capture_path"], "fresh_capture_sha256": new["raw_capture_sha256"],
            "prior_original_outcome": old_outcome,
            "fresh_original_outcome": {"runner_exit_code": new["runner_exit_code"], "status": new["status"]}}
        reviews.append(review)
    inventory_hash = digest(("\n".join(inventory_lines) + "\n").encode("utf-8"))
    require(fresh["initial_fixture_inventory_sha256"] == fresh["final_fixture_inventory_sha256"] == inventory_hash,
            "Fresh source/golden inventory hash differs")
    queries = [query for fixture in reviews for query in fixture["explicit_queries"]]
    proof_queries = [query for fixture in reviews for query in fixture["bare_proof_queries"]]
    require(len(reviews) == 30 and len(queries) == 263 and len(proof_queries) == 2, "Wrong final comparison coverage")
    counts = {"fixture_count": 30, "explicit_query_count": 263, "bare_proof_query_count": 2,
        "lost_prior_success_count": sum(query["lost_prior_success"] for query in queries),
        "new_spelling_count": sum(len(query["new_spellings"]) for query in queries),
        "queries_with_exact_duplicates": sum(bool(query["exact_duplicates"]) for query in queries),
        "changed_candidate_lists": sum(query["candidate_list_changed"] for query in queries),
        "query_control_difference_count": sum(query["query_control_changed"] for query in queries),
        "non_query_control_difference_count": sum(len(row["non_query_control_differences"]) for row in reviews),
        "preamble_difference_count": sum(row["preamble_difference"] is not None for row in reviews),
        "bare_proof_changed_candidate_lists": sum(query["candidate_list_changed"] for query in proof_queries),
        "bare_proof_query_control_difference_count": sum(query["query_control_changed"] for query in proof_queries),
        "bare_proof_queries_with_exact_duplicates": sum(bool(query["exact_duplicates"]) for query in proof_queries),
        "bare_proof_candidate_output_losses": sum(query["prior_candidate_output_lost"] for query in proof_queries)}
    failed = (counts["lost_prior_success_count"] or counts["queries_with_exact_duplicates"] or
              counts["bare_proof_candidate_output_losses"] or counts["bare_proof_queries_with_exact_duplicates"])
    report = {"status": "regression_review_required" if failed else "comparison_complete_review_pending",
        "validation_mode": "pure_saved_candidate_and_control_comparison", "created_utc": datetime.now(timezone.utc).isoformat(),
        "prior_executable_sha256": E0, "fresh_executable_sha256": expected,
        "prior_synthesis_timeout_seconds": {"ordinary_26": 600, "compact_4": 30}, "fresh_synthesis_timeout_seconds": 30,
        "fresh_original_runner_exit_code": fresh["exit_code"], "fresh_original_status": fresh["status"],
        "is_kernel_validation": False, "proof_success_inferred": False, "counts": counts,
        "limitations": ["Exact spelling means after CR/startup/trailing-ASCII-whitespace filtering; bound names, type arguments, and continuation indentation are preserved.",
            "This pure parsing filter does not run GNU Bash/sed; the separate production-normalizer golden comparison remains authoritative.",
            "Queue totals remain literal so all diagnostic changes are reported.",
            "Changed terms need independent replay. Unchanged printed terms are not new kernel evidence.",
            "Proof-mode prompts, candidate output, tactics, evaluations, and saved declarations require explicit review; text equality does not prove goal closure.",
            "A lost success under the tighter timeout must not become accepted golden drift; review or rerun that fixture separately at 600 seconds."],
        "input_sha256": {str(path): value for path, value in inputs.hashes.items()}, "fixtures": reviews}
    inputs.recheck()
    output.mkdir(parents=True, exist_ok=True)
    with (output / "results.json").open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(report, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    text = ["# Saved post-dedup comparison", "", f"Status: {report['status']}", "", json.dumps(counts, indent=2), "",
        "This is not kernel validation. Review every changed term/control and both proof fixtures.", ""]
    for row in reviews:
        changed = [query for query in row["explicit_queries"] if query["candidate_list_changed"] or query["query_control_changed"]]
        if changed or row["non_query_control_differences"] or row["preamble_difference"] or row["proof_mode_review_required"]:
            text.append(f"- {row['fixture']}: {len(changed)} changed explicit query responses; {len(row['non_query_control_differences'])} changed non-query blocks; proof review {row['proof_mode_review_required']}.")
    (output / "README.md").write_text("\n".join(text) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"status": report["status"], "counts": counts, "output": str(output)}, indent=2))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    try:
        raise SystemExit(main())
    except (ValueError, KeyError, OSError) as error:
        print(f"REVIEW GATE FAILED: {error}", file=sys.stderr)
        raise SystemExit(2)
