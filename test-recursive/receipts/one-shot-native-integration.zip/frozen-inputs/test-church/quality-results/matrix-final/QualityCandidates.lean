set_option linter.unusedVariables false
axiom Quality.Token : Type
axiom Quality.cheap : Unit → Quality.Token
axiom Quality.expensive : Quality.Token
def Quality.case0_1 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case0_1
def Quality.case0_2 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case0_2
def Quality.case1_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ _ x => x
#print axioms Quality.case1_1
def Quality.case2_1 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, y⟩
#print axioms Quality.case2_1
def Quality.case3_1 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, x⟩
#print axioms Quality.case3_1
def Quality.case4_1 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms Quality.case4_1
def Quality.case5_1 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms Quality.case5_1
noncomputable def Quality.case6_1 : Quality.Token :=
  Quality.cheap ⟨⟩
#print axioms Quality.case6_1
def Quality.case7_1 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case7_1
def Quality.case7_2 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case7_2
def Quality.case8_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ _ x => x
#print axioms Quality.case8_1
def Quality.case9_1 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, y⟩
#print axioms Quality.case9_1
def Quality.case10_1 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, x⟩
#print axioms Quality.case10_1
def Quality.case11_1 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms Quality.case11_1
def Quality.case12_1 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms Quality.case12_1
noncomputable def Quality.case13_1 : Quality.Token :=
  Quality.cheap ⟨⟩
#print axioms Quality.case13_1
def Quality.case14_1 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case14_1
def Quality.case14_2 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case14_2
def Quality.case15_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ _ x => x
#print axioms Quality.case15_1
def Quality.case16_1 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, y⟩
#print axioms Quality.case16_1
def Quality.case17_1 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, x⟩
#print axioms Quality.case17_1
def Quality.case18_1 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms Quality.case18_1
def Quality.case19_1 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms Quality.case19_1
noncomputable def Quality.case20_1 : Quality.Token :=
  Quality.cheap ⟨⟩
#print axioms Quality.case20_1
def Quality.case21_1 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case21_1
def Quality.case21_2 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case21_2
example : (Quality.case21_1 Nat 11 29 = 11 ∨ Quality.case21_2 Nat 11 29 = 11) ∧ (Quality.case21_1 Nat 11 29 = 29 ∨ Quality.case21_2 Nat 11 29 = 29) := by decide
def Quality.case22_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ _ x => x
#print axioms Quality.case22_1
def Quality.case23_1 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, y⟩
#print axioms Quality.case23_1
def Quality.case24_1 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, x⟩
#print axioms Quality.case24_1
def Quality.case25_1 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms Quality.case25_1
def Quality.case26_1 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms Quality.case26_1
noncomputable def Quality.case27_1 : Quality.Token :=
  Quality.cheap ⟨⟩
#print axioms Quality.case27_1
def Quality.case28_1 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case28_1
def Quality.case28_2 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case28_2
def Quality.case28_3 : (∀ A : Type, A → A → A) :=
  fun _ _ x => match Sum.inl x with | .inl a => a | .inr b => b
#print axioms Quality.case28_3
def Quality.case28_4 : (∀ A : Type, A → A → A) :=
  fun _ x y => match Sum.inl y with | .inl _ => x | .inr a => a
#print axioms Quality.case28_4
def Quality.case29_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ f x => match Sum.inr x with | .inl a => f a x | .inr b => b
#print axioms Quality.case29_1
def Quality.case29_2 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ f x => match Sum.inr x with | .inl a => f a (f a x) | .inr b => b
#print axioms Quality.case29_2
def Quality.case29_3 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ f x => match Sum.inr x with | .inl a => f a (f a (f a x)) | .inr b => b
#print axioms Quality.case29_3
def Quality.case29_4 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ f x => match Sum.inr x with | .inl a => f a (f a (f a (f a x))) | .inr b => b
#print axioms Quality.case29_4
def Quality.case30_1 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, y⟩
#print axioms Quality.case30_1
def Quality.case30_2 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, match Sum.inr y with | .inl a => a | .inr b => b⟩
#print axioms Quality.case30_2
def Quality.case30_3 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, match Sum.inl y with | .inl a => a | .inr b => b⟩
#print axioms Quality.case30_3
def Quality.case30_4 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨match Sum.inl x with | .inl a => a | .inr b => b, y⟩
#print axioms Quality.case30_4
def Quality.case31_1 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, x⟩
#print axioms Quality.case31_1
def Quality.case31_2 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, match Sum.inl x with | .inl a => a | .inr b => b⟩
#print axioms Quality.case31_2
def Quality.case31_3 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, match Sum.inr x with | .inl a => a | .inr b => b⟩
#print axioms Quality.case31_3
def Quality.case31_4 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨match Sum.inr x with | .inl a => a | .inr b => b, x⟩
#print axioms Quality.case31_4
def Quality.case32_1 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms Quality.case32_1
def Quality.case32_2 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => match Sum.inr x with | .inl a => a | .inr b => b)
#print axioms Quality.case32_2
def Quality.case32_3 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => match Sum.inl x with | .inl a => a | .inr b => b)
#print axioms Quality.case32_3
def Quality.case33_1 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms Quality.case33_1
def Quality.case33_2 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (match Sum.inr f with | .inl a => a | .inr _ => (fun _ _ x => x))
#print axioms Quality.case33_2
noncomputable def Quality.case34_1 : Quality.Token :=
  Quality.expensive
#print axioms Quality.case34_1
noncomputable def Quality.case34_2 : Quality.Token :=
  Quality.cheap ⟨⟩
#print axioms Quality.case34_2
noncomputable def Quality.case34_3 : Quality.Token :=
  let a := ⟨⟩; let b := a; match b with | _ => Quality.cheap a
#print axioms Quality.case34_3
noncomputable def Quality.case34_4 : Quality.Token :=
  match Sum.inl (Quality.cheap ⟨⟩) with | .inl a => a | .inr b => b
#print axioms Quality.case34_4
def Quality.case35_1 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case35_1
def Quality.case35_2 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case35_2
def Quality.case36_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ _ x => x
#print axioms Quality.case36_1
def Quality.case37_1 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, y⟩
#print axioms Quality.case37_1
def Quality.case38_1 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, x⟩
#print axioms Quality.case38_1
def Quality.case39_1 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms Quality.case39_1
def Quality.case40_1 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms Quality.case40_1
noncomputable def Quality.case41_1 : Quality.Token :=
  Quality.expensive
#print axioms Quality.case41_1
noncomputable def Quality.case41_2 : Quality.Token :=
  Quality.cheap ⟨⟩
#print axioms Quality.case41_2
noncomputable def Quality.case41_3 : Quality.Token :=
  let a := ⟨⟩; let b := a; match b with | _ => Quality.cheap a
#print axioms Quality.case41_3
def Quality.case42_1 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case42_1
def Quality.case42_2 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case42_2
def Quality.case43_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ _ x => x
#print axioms Quality.case43_1
def Quality.case44_1 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, y⟩
#print axioms Quality.case44_1
def Quality.case45_1 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, x⟩
#print axioms Quality.case45_1
def Quality.case46_1 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms Quality.case46_1
def Quality.case47_1 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms Quality.case47_1
noncomputable def Quality.case48_1 : Quality.Token :=
  Quality.expensive
#print axioms Quality.case48_1
noncomputable def Quality.case48_2 : Quality.Token :=
  Quality.cheap ⟨⟩
#print axioms Quality.case48_2
noncomputable def Quality.case48_3 : Quality.Token :=
  let a := ⟨⟩; let b := a; match b with | _ => Quality.cheap a
#print axioms Quality.case48_3
def Quality.case49_1 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case49_1
def Quality.case49_2 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case49_2
example : (Quality.case49_1 Nat 11 29 = 11 ∨ Quality.case49_2 Nat 11 29 = 11) ∧ (Quality.case49_1 Nat 11 29 = 29 ∨ Quality.case49_2 Nat 11 29 = 29) := by decide
def Quality.case50_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ _ x => x
#print axioms Quality.case50_1
def Quality.case51_1 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, y⟩
#print axioms Quality.case51_1
def Quality.case52_1 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, x⟩
#print axioms Quality.case52_1
def Quality.case53_1 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms Quality.case53_1
def Quality.case54_1 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms Quality.case54_1
noncomputable def Quality.case55_1 : Quality.Token :=
  Quality.expensive
#print axioms Quality.case55_1
noncomputable def Quality.case55_2 : Quality.Token :=
  Quality.cheap ⟨⟩
#print axioms Quality.case55_2
noncomputable def Quality.case55_3 : Quality.Token :=
  let a := ⟨⟩; let b := a; match b with | _ => Quality.cheap a
#print axioms Quality.case55_3
def Quality.case56_1 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case56_1
def Quality.case56_2 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case56_2
def Quality.case56_3 : (∀ A : Type, A → A → A) :=
  fun _ _ x => match Sum.inl x with | .inl a => a | .inr b => b
#print axioms Quality.case56_3
def Quality.case56_4 : (∀ A : Type, A → A → A) :=
  fun _ x y => match Sum.inl y with | .inl _ => x | .inr a => a
#print axioms Quality.case56_4
def Quality.case57_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ _ x => x
#print axioms Quality.case57_1
def Quality.case57_2 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ f x => match Sum.inr x with | .inl a => f a x | .inr b => b
#print axioms Quality.case57_2
def Quality.case57_3 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ f x => match Sum.inr x with | .inl a => f a (f a x) | .inr b => b
#print axioms Quality.case57_3
def Quality.case57_4 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ f x => match Sum.inr x with | .inl a => f a (f a (f a x)) | .inr b => b
#print axioms Quality.case57_4
def Quality.case58_1 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, y⟩
#print axioms Quality.case58_1
def Quality.case58_2 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, match Sum.inr y with | .inl a => a | .inr b => b⟩
#print axioms Quality.case58_2
def Quality.case58_3 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, match Sum.inl y with | .inl a => a | .inr b => b⟩
#print axioms Quality.case58_3
def Quality.case58_4 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨match Sum.inl x with | .inl a => a | .inr b => b, y⟩
#print axioms Quality.case58_4
def Quality.case59_1 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, x⟩
#print axioms Quality.case59_1
def Quality.case59_2 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, match Sum.inl x with | .inl a => a | .inr b => b⟩
#print axioms Quality.case59_2
def Quality.case59_3 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, match Sum.inr x with | .inl a => a | .inr b => b⟩
#print axioms Quality.case59_3
def Quality.case59_4 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨match Sum.inr x with | .inl a => a | .inr b => b, x⟩
#print axioms Quality.case59_4
def Quality.case60_1 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms Quality.case60_1
def Quality.case60_2 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => match Sum.inr x with | .inl a => a | .inr b => b)
#print axioms Quality.case60_2
def Quality.case60_3 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => match Sum.inl x with | .inl a => a | .inr b => b)
#print axioms Quality.case60_3
def Quality.case61_1 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms Quality.case61_1
def Quality.case61_2 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (match Sum.inr f with | .inl a => a | .inr _ => (fun _ _ x => x))
#print axioms Quality.case61_2
noncomputable def Quality.case62_1 : Quality.Token :=
  Quality.cheap ⟨⟩
#print axioms Quality.case62_1
noncomputable def Quality.case62_2 : Quality.Token :=
  let a := ⟨⟩; let b := a; match b with | _ => Quality.cheap a
#print axioms Quality.case62_2
noncomputable def Quality.case62_3 : Quality.Token :=
  match Sum.inl (Quality.cheap ⟨⟩) with | .inl a => a | .inr b => b
#print axioms Quality.case62_3
noncomputable def Quality.case62_4 : Quality.Token :=
  match Sum.inr (Quality.cheap ⟨⟩) with | .inl a => a | .inr b => b
#print axioms Quality.case62_4
def Quality.case63_1 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case63_1
def Quality.case63_2 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case63_2
def Quality.case64_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ _ x => x
#print axioms Quality.case64_1
def Quality.case65_1 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, y⟩
#print axioms Quality.case65_1
def Quality.case66_1 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, x⟩
#print axioms Quality.case66_1
def Quality.case67_1 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms Quality.case67_1
def Quality.case68_1 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms Quality.case68_1
noncomputable def Quality.case69_1 : Quality.Token :=
  Quality.cheap ⟨⟩
#print axioms Quality.case69_1
def Quality.case70_1 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case70_1
def Quality.case70_2 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case70_2
def Quality.case71_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ _ x => x
#print axioms Quality.case71_1
def Quality.case72_1 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, y⟩
#print axioms Quality.case72_1
def Quality.case73_1 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, x⟩
#print axioms Quality.case73_1
def Quality.case74_1 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms Quality.case74_1
def Quality.case75_1 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms Quality.case75_1
noncomputable def Quality.case76_1 : Quality.Token :=
  Quality.cheap ⟨⟩
#print axioms Quality.case76_1
def Quality.case77_1 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case77_1
def Quality.case77_2 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case77_2
example : (Quality.case77_1 Nat 11 29 = 11 ∨ Quality.case77_2 Nat 11 29 = 11) ∧ (Quality.case77_1 Nat 11 29 = 29 ∨ Quality.case77_2 Nat 11 29 = 29) := by decide
def Quality.case78_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ _ x => x
#print axioms Quality.case78_1
def Quality.case79_1 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, y⟩
#print axioms Quality.case79_1
def Quality.case80_1 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, x⟩
#print axioms Quality.case80_1
def Quality.case81_1 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms Quality.case81_1
def Quality.case82_1 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms Quality.case82_1
noncomputable def Quality.case83_1 : Quality.Token :=
  Quality.cheap ⟨⟩
#print axioms Quality.case83_1
