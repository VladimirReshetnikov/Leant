set_option linter.unusedVariables false
axiom Quality.Token : Type
axiom Quality.cheap : Unit → Quality.Token
axiom Quality.expensive : Quality.Token
def Quality.case0_1 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case0_1
def Quality.case0_2 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case0_2
def Quality.case0_3 : (∀ A : Type, A → A → A) :=
  fun _ _ x => match Sum.inl x with | .inl a => a | .inr b => b
#print axioms Quality.case0_3
def Quality.case0_4 : (∀ A : Type, A → A → A) :=
  fun _ x y => match Sum.inl y with | .inl _ => x | .inr a => a
#print axioms Quality.case0_4
def Quality.case1_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ _ x => x
#print axioms Quality.case1_1
def Quality.case1_2 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ f x => match Sum.inr x with | .inl a => f a x | .inr b => b
#print axioms Quality.case1_2
def Quality.case1_3 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ f x => match Sum.inr x with | .inl a => f a (f a x) | .inr b => b
#print axioms Quality.case1_3
def Quality.case1_4 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ f x => match Sum.inr x with | .inl a => f a (f a (f a x)) | .inr b => b
#print axioms Quality.case1_4
def Quality.case2_1 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, y⟩
#print axioms Quality.case2_1
def Quality.case2_2 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, match Sum.inr y with | .inl a => a | .inr b => b⟩
#print axioms Quality.case2_2
def Quality.case2_3 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, match Sum.inl y with | .inl a => a | .inr b => b⟩
#print axioms Quality.case2_3
def Quality.case2_4 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨match Sum.inl x with | .inl a => a | .inr b => b, y⟩
#print axioms Quality.case2_4
def Quality.case3_1 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, x⟩
#print axioms Quality.case3_1
def Quality.case3_2 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, match Sum.inl x with | .inl a => a | .inr b => b⟩
#print axioms Quality.case3_2
def Quality.case3_3 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, match Sum.inr x with | .inl a => a | .inr b => b⟩
#print axioms Quality.case3_3
def Quality.case3_4 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨match Sum.inr x with | .inl a => a | .inr b => b, x⟩
#print axioms Quality.case3_4
def Quality.case4_1 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms Quality.case4_1
def Quality.case4_2 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => match Sum.inr x with | .inl a => a | .inr b => b)
#print axioms Quality.case4_2
def Quality.case4_3 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => match Sum.inl x with | .inl a => a | .inr b => b)
#print axioms Quality.case4_3
def Quality.case5_1 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms Quality.case5_1
def Quality.case5_2 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (match Sum.inr f with | .inl a => a | .inr _ => (fun _ _ x => x))
#print axioms Quality.case5_2
noncomputable def Quality.case6_1 : Quality.Token :=
  Quality.cheap ⟨⟩
#print axioms Quality.case6_1
noncomputable def Quality.case6_2 : Quality.Token :=
  let a := ⟨⟩; let b := a; match b with | _ => Quality.cheap a
#print axioms Quality.case6_2
noncomputable def Quality.case6_3 : Quality.Token :=
  match Sum.inl (Quality.cheap ⟨⟩) with | .inl a => a | .inr b => b
#print axioms Quality.case6_3
noncomputable def Quality.case6_4 : Quality.Token :=
  match Sum.inr (Quality.cheap ⟨⟩) with | .inl a => a | .inr b => b
#print axioms Quality.case6_4
def Quality.case7_1 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case7_1
def Quality.case7_2 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case7_2
def Quality.case8_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ _ x => x
#print axioms Quality.case8_1
def Quality.case9_1 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, y⟩
#print axioms Quality.case9_1
def Quality.case10_1 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, x⟩
#print axioms Quality.case10_1
def Quality.case11_1 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms Quality.case11_1
def Quality.case12_1 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms Quality.case12_1
noncomputable def Quality.case13_1 : Quality.Token :=
  Quality.cheap ⟨⟩
#print axioms Quality.case13_1
def Quality.case14_1 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case14_1
def Quality.case14_2 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case14_2
def Quality.case15_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ _ x => x
#print axioms Quality.case15_1
def Quality.case16_1 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, y⟩
#print axioms Quality.case16_1
def Quality.case17_1 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, x⟩
#print axioms Quality.case17_1
def Quality.case18_1 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms Quality.case18_1
def Quality.case19_1 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms Quality.case19_1
noncomputable def Quality.case20_1 : Quality.Token :=
  Quality.cheap ⟨⟩
#print axioms Quality.case20_1
def Quality.case21_1 : (∀ A : Type, A → A → A) :=
  fun _ _ x => x
#print axioms Quality.case21_1
def Quality.case21_2 : (∀ A : Type, A → A → A) :=
  fun _ x _ => x
#print axioms Quality.case21_2
example : (Quality.case21_1 Nat 11 29 = 11 ∨ Quality.case21_2 Nat 11 29 = 11) ∧ (Quality.case21_1 Nat 11 29 = 29 ∨ Quality.case21_2 Nat 11 29 = 29) := by decide
def Quality.case22_1 : (∀ A R : Type, (A → R → R) → R → R) :=
  fun _ _ _ x => x
#print axioms Quality.case22_1
def Quality.case23_1 : (∀ A B : Type, A → B → A × B) :=
  fun _ _ x y => ⟨x, y⟩
#print axioms Quality.case23_1
def Quality.case24_1 : (∀ A : Type, A → A × A) :=
  fun _ x => ⟨x, x⟩
#print axioms Quality.case24_1
def Quality.case25_1 : (∀ F : Type 1 → Type 1, (∀ A : Type 1, A → F A) → F (∀ B : Type, B → B)) :=
  fun _ f => f _ (fun _ x => x)
#print axioms Quality.case25_1
def Quality.case26_1 : (∀ (X : Type) (F : Type 1 → Type 1), (∀ A : Type 1, A → F A) → F (∀ B : Type, X → B → B)) :=
  fun _ _ f => f _ (fun _ _ x => x)
#print axioms Quality.case26_1
noncomputable def Quality.case27_1 : Quality.Token :=
  Quality.cheap ⟨⟩
#print axioms Quality.case27_1
