"""Combine disjoint fresh engine runs; no synthesis or kernel execution."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
EXE = "42c0c9c0a46a35302a04691a93fc68099c5e80bd91305e9a927ba9de9cec5cae"
SETTINGS = dict(window=12, shown=4, steps=10000, budget=10000, timeout=30)
hashes = {}

def read(path):
    data = path.read_bytes()
    hashes[str(path)] = hashlib.sha256(data).hexdigest()
    return data

def key(row):
    return row["engine"], row["policy"], row["name"]

read(Path(__file__))
build = json.loads(read(HERE / "dedup-build-acceptance.json").decode("utf-8-sig"))
assert hashlib.sha256(read(Path(build["executable_path"]))).hexdigest() == EXE
rows, inventories, nil_comparisons, runs = [], [], [], []
proofs = 0
for name, engines in (("matrix-dedup", {"djinn", "exference"}), ("matrix-dedup-both", {"both"})):
    directory = HERE / name
    report = json.loads(read(directory / "results.json"))
    assert report["passed"] and report["executable_unchanged"]
    assert report["executable_sha256"] == EXE and report["settings"] == SETTINGS
    assert report["live_exit_code"] == report["kernel_exit_code"] == 0
    assert {row["engine"] for row in report["results"]} == engines
    assert report["query_count"] == 28 * len(engines)
    assert report["term_count"] == sum(len(row["terms"]) for row in report["results"])
    assert len(report["inventories"]) == report["term_count"]
    assert all(item["within_declared_premises"] and item["actual"] is not None for item in report["inventories"].values())
    query_bytes = read(directory / "queries.txt")
    # The probe hashes its LF source string before Windows write_text emits CRLF.
    logical_queries = query_bytes.decode("utf-8").replace("\r\n", "\n").encode("utf-8")
    assert hashlib.sha256(logical_queries).hexdigest() == report["source_sha256"]
    module = read(directory / "QualityCandidates.lean").decode("utf-8")
    module_proofs = sum(line.startswith("example : ") for line in module.splitlines())
    assert module_proofs == len(engines)
    read(directory / "kernel-output.txt")
    read(directory / "live-output.txt")
    proofs += module_proofs
    rows.extend(report["results"])
    inventories.extend(report["inventories"].values())
    nil_comparisons.extend(report["paired_nil_comparisons"])
    runs.append({"receipt": str(directory / "results.json"), "engines": sorted(engines),
                 "query_count": report["query_count"], "term_count": report["term_count"]})
historical = json.loads(read(HERE / "matrix-final/results.json"))
prior = {key(row): row for row in historical["results"]}
current = {key(row): row for row in rows}
assert len(rows) == len(current) == len(prior) == 84 and set(current) == set(prior)
changed = [list(k) for k in current if (current[k]["type"], current[k]["terms"]) != (prior[k]["type"], prior[k]["terms"])]
assert len(nil_comparisons) == 3 and all(item["passed"] for item in nil_comparisons)
assert proofs == 3
assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest for path, digest in hashes.items())
report = {"passed": True, "validation_mode": "aggregate_of_disjoint_completed_live_and_kernel_engine_runs",
    "executable_sha256": EXE, "settings": SETTINGS, "query_count": len(rows),
    "term_count": len(inventories), "empty_axiom_inventory_count": sum(not item["actual"] for item in inventories),
    "declared_premise_inventory_count": sum(bool(item["actual"]) for item in inventories),
    "paired_nil_comparison_count": 3, "projection_diversity_proof_count": proofs,
    "changed_type_or_term_lists_from_E0": changed, "runs": runs, "inputs_sha256": hashes,
    "aggregation_ran_synthesis_or_kernel": False}
output = HERE / "matrix-dedup-complete.json"
with output.open("x", encoding="utf-8") as stream:
    json.dump(report, stream, indent=2)
    stream.write("\n")
print(json.dumps({k: v for k, v in report.items() if k != "inputs_sha256"}, indent=2))
