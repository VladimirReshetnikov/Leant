"""Review preserved compact-fixture captures; never run Leant/Lean or edit goldens.

First use --report LIVE/results.json --output NEW_REVIEW_DIRECTORY to prepare
proposals. After root reviews and applies them, use the same --report with
--compare-only and a different empty --output directory for offline comparison.
The original live report and its golden-mismatch statuses remain untouched.
"""
import argparse
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
QUALITY = ROOT / "test-church/quality-results"
sys.path.insert(0, str(ROOT / "test-church"))
from run_fixtures import normalized_output
from run_corpus import parse_results, reported_axioms, validate_settings

EXPECTED_EXE = "e0b9c87cae0bc34d59c8d5a34a58fdd5005676913969a80d5503d7281081d025"
EXPECTED = {
    "synth-church": 9,
    "synth-church-rankn": 69,
    "synth-church-providers": 6,
    "synth-church-layered-providers": 6,
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def telemetry(text):
    return re.sub(r"queue limit pruned \d+", "queue limit pruned <machine-dependent>", text)


def checked_artifact(row, field, expected_path):
    path = Path(row[field + "_path"]).resolve()
    require(path == expected_path.resolve(), f"Unexpected {field} path: {path}")
    require(digest(path.read_bytes()) == row[field + "_sha256"], f"Changed artifact: {path}")
    return path


def inspect_fixture(name, count, row, report_directory, compare_only):
    require(row["live_exit_code"] == 0, f"{name}: live process failed")
    require(row["validation_passed_before_golden"] is True, f"{name}: pre-golden checks failed")
    require(row["candidate_count"] == row["case_count"] == count, f"{name}: wrong candidate count")
    require(row["kernel_exit_code"] == 0, f"{name}: kernel failed")
    require(row["exact_provider_vectors"] is True and row["expected_axioms"] is True,
            f"{name}: vector or axiom gate failed")
    require(row["golden_status"] in ("matched", "mismatch"),
            f"{name}: expected a comparison against an existing, unmodified golden")
    require(row["golden_comparison_passed"] is (row["golden_status"] == "matched") and
            row["passed"] is row["golden_comparison_passed"], f"{name}: inconsistent original status")
    require(row["golden_before_sha256"] == row["golden_after_sha256"],
            f"{name}: original run changed its golden")

    source_path = ROOT / "test" / (name + ".txt")
    source = source_path.read_text(encoding="utf-8-sig")
    require(digest(source_path.read_bytes()) == row["fixture_source_raw_sha256"],
            f"{name}: source file bytes changed")
    require(digest(source.encode("utf-8")) == row["fixture_source_sha256"],
            f"{name}: consumed source text changed")
    require(not any(line.startswith(":reset") for line in source.splitlines()),
            f"{name}: reset-local environments require a different replay helper")
    raw_path = checked_artifact(row, "raw_output", report_directory / (name + ".output.txt"))
    replay_path = checked_artifact(row, "kernel_source", report_directory / (name + ".lean"))
    kernel_path = checked_artifact(row, "kernel_output", report_directory / (name + ".kernel.txt"))
    output = raw_path.read_text(encoding="utf-8")
    normalized = normalized_output(output)
    require(digest(normalized.encode("utf-8")) == row["normalized_output_sha256"],
            f"{name}: normalized capture differs from its recorded hash")
    validate_settings(output, source)
    query_lines = [(number, line) for number, line in enumerate(source.splitlines(), start=1)
                   if line.startswith(":synth ")]
    require(len(query_lines) == count, f"{name}: changed query inventory")
    cases = [{"id": f"case{index}", "name": f"case{index}", "fixture_line": number,
              "lean_type": line[len(":synth "):]} for index, (number, line) in enumerate(query_lines)]
    results = parse_results(output, cases)
    require(results == row["results"], f"{name}: capture terms do not match the recorded results")
    require(all(result["status"] == "candidate" and result["candidate"] for result in results),
            f"{name}: missing live candidate")

    environment = [line for line in source.splitlines() if not line.startswith(":")]
    replay_lines = ["set_option linter.unusedVariables false", *environment, "noncomputable section"]
    kernel_output = kernel_path.read_text(encoding="utf-8")
    require("sorryAx" not in kernel_output, f"{name}: unchecked kernel dependency")
    declarations = []
    inventories = {}
    for index, result in enumerate(results):
        term = result["candidate"]
        declaration = f"ChurchFixture.case{index}"
        declarations.append(declaration)
        replay_lines += [f"def {declaration} : {result['lean_type']} :=",
                         "\n".join("  " + line for line in term.splitlines()),
                         f"#print axioms {declaration}"]
        if name == "synth-church-providers":
            width = 8 if "ChurchProviders8" in result["lean_type"] else 12
            require(all(f"(«t{slot}» :=" in term for slot in range(width)),
                    f"{name} case{index}: missing displayed exact provider slot")
            expected_axioms = {f"ChurchProviders{width}.Token", f"ChurchProviders{width}.chosen"}
        elif name == "synth-church-layered-providers":
            width = 2 if "ChurchLayered.G2" in result["lean_type"] else 3
            expected_axioms = {"ChurchLayered.Seed", "ChurchLayered.seed",
                               f"ChurchLayered.G{width}", f"ChurchLayered.maker{width}"}
        else:
            expected_axioms = set()
        actual_axioms = reported_axioms(kernel_output, declaration)
        require(actual_axioms == expected_axioms, f"{name} case{index}: unexpected axiom inventory")
        inventories[declaration] = sorted(actual_axioms)
    require(replay_path.read_text(encoding="utf-8") == "\n".join(replay_lines) + "\n",
            f"{name}: recorded kernel source does not replay these exact live terms")
    printed_names = re.findall(r"(?m)^'(ChurchFixture\.case\d+)' ", kernel_output)
    require(printed_names == declarations, f"{name}: missing, extra, reordered, or duplicate inventories")
    axiom_free_count = sum(not names for names in inventories.values())
    require(axiom_free_count == row["axiom_free_count"] == (count if name in
            ("synth-church", "synth-church-rankn") else 0), f"{name}: axiom-free count mismatch")

    golden_path = source_path.with_suffix(".golden")
    golden_bytes = golden_path.read_bytes()
    if not compare_only:
        require(digest(golden_bytes) == row["golden_before_sha256"],
                f"{name}: golden changed since live comparison; use --compare-only after reviewed edits")
    golden_text = golden_path.read_text(encoding="utf-8")
    matches = telemetry(golden_text) == telemetry(normalized)
    diff = "".join(difflib.unified_diff(
        golden_text.splitlines(keepends=True), normalized.splitlines(keepends=True),
        fromfile=str(golden_path), tofile=f"preserved-capture/{name}.golden"))
    return {
        "fixture": name, "candidate_count": count,
        "original_live_exit_code": row["live_exit_code"],
        "original_passed": row["passed"], "original_golden_status": row["golden_status"],
        "original_golden_sha256": row["golden_before_sha256"],
        "current_golden_sha256": digest(golden_bytes),
        "fixture_source_raw_sha256": row["fixture_source_raw_sha256"],
        "raw_output_path": str(raw_path), "raw_output_sha256": row["raw_output_sha256"],
        "normalized_output_sha256": row["normalized_output_sha256"],
        "kernel_source_sha256": row["kernel_source_sha256"],
        "kernel_output_sha256": row["kernel_output_sha256"],
        "recorded_kernel_validation_rechecked": True,
        "axiom_free_count": axiom_free_count, "axiom_inventories": inventories,
        "current_golden_matches_capture": matches,
    }, normalized, diff


def main():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--compare-only", action="store_true")
    args = parser.parse_args()
    report_path = args.report.resolve()
    output_directory = args.output.resolve()
    require(output_directory.is_relative_to(QUALITY.resolve()), "Output must stay under quality-results")
    require(not output_directory.exists() or not any(output_directory.iterdir()),
            "Refusing to overwrite an existing review directory")
    report_bytes = report_path.read_bytes()
    report = json.loads(report_bytes.decode("utf-8-sig"))
    require(report["leant_executable_sha256"] == EXPECTED_EXE and
            report["leant_executable_unchanged"] is True, "Wrong or unstable live executable receipt")
    names = [row["fixture"] for row in report["fixtures"]]
    require(len(names) == 4 and set(names) == set(EXPECTED), "Expected exactly the four compact fixtures")
    by_name = {row["fixture"]: row for row in report["fixtures"]}
    prepared = [inspect_fixture(name, count, by_name[name], report_path.parent, args.compare_only)
                for name, count in EXPECTED.items()]
    require(digest(report_path.read_bytes()) == digest(report_bytes), "Live report changed during review")
    output_directory.mkdir(parents=True, exist_ok=True)
    rows, diffs = [], []
    for row, normalized, diff in prepared:
        name = row["fixture"]
        if not args.compare_only:
            proposal = output_directory / ("proposed-" + name + ".golden")
            proposal.write_text(normalized, encoding="utf-8", newline="\n")
            row["proposal_path"] = str(proposal)
            row["proposal_sha256"] = digest(proposal.read_bytes())
        (output_directory / (name + ".diff")).write_text(diff, encoding="utf-8", newline="\n")
        diffs.append(diff)
        rows.append(row)
        print(f"{name}: {row['candidate_count']} recorded kernel-checked terms; "
              f"current golden {'matches' if row['current_golden_matches_capture'] else 'differs'}")
    (output_directory / "review.diff").write_text("".join(diffs), encoding="utf-8", newline="\n")
    all_match = all(row["current_golden_matches_capture"] for row in rows)
    result = {
        "validation_mode": "offline_comparison_of_preserved_live_captures" if args.compare_only
                           else "offline_proposal_preparation_from_preserved_live_captures",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "helper_sha256": digest(Path(__file__).read_bytes()),
        "original_live_report_path": str(report_path), "original_live_report_sha256": digest(report_bytes),
        "leant_executable_sha256": EXPECTED_EXE, "leant_executable_stability_from_live_receipt": True,
        "normalization": "run_fixtures.normalized_output plus its queue-count telemetry regex for comparison",
        "fixture_count": 4, "candidate_count": 90, "axiom_free_count": 78,
        "exact_declared_premise_count": 12, "recorded_live_and_kernel_validation_rechecked": True,
        "synthesis_rerun": False, "kernel_rerun": False, "source_goldens_modified": False,
        "all_current_goldens_match_captures": all_match, "fixtures": rows,
    }
    (output_directory / "results.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    return 1 if args.compare_only and not all_match else 0


if __name__ == "__main__":
    raise SystemExit(main())
