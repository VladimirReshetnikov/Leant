set_option linter.unusedVariables false
namespace ChurchLayered
axiom Seed : Type
axiom seed : Seed
axiom G2 : Type 1 → Type 1 → Type 1
axiom G3 : Type 1 → Type 1 → Type 1 → Type 1
axiom maker2 : Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G2 a b
axiom maker3 : Seed → ∀ a b : Type 1, a → b → Seed → ∀ c : Type 1, c → G3 a b c
end ChurchLayered
noncomputable section
def ChurchFixture.case0 : (ChurchLayered.G2 (∀ a : Type, a → a) (∀ a : Type, a → a → a)) :=
  ChurchLayered.maker2 ChurchLayered.seed _ (fun _ x => x) ChurchLayered.seed _ (fun _ _ y => y)
#print axioms ChurchFixture.case0
def ChurchFixture.case1 : (ChurchLayered.G3 (∀ a : Type, a → a) (∀ a : Type, a → a → a) (∀ a : Type, a → a)) :=
  ChurchLayered.maker3 ChurchLayered.seed _ _ (fun _ x => x) (fun _ _ y => y) ChurchLayered.seed _ (fun _ z => z)
#print axioms ChurchFixture.case1
def ChurchFixture.case2 : (ChurchLayered.G2 (∀ a : Type, a → a) (∀ a : Type, a → a → a)) :=
  let f := ChurchLayered.maker2 ChurchLayered.seed (∀ (a0_0 : _), a0_0 → a0_0) (fun _ x => x); let g := f ChurchLayered.seed; g _ (fun _ y _ => y)
#print axioms ChurchFixture.case2
def ChurchFixture.case3 : (ChurchLayered.G3 (∀ a : Type, a → a) (∀ a : Type, a → a → a) (∀ a : Type, a → a)) :=
  let f := ChurchLayered.maker3 ChurchLayered.seed (∀ (a0_0 : _), a0_0 → a0_0) (∀ (a0_0 : _), a0_0 → a0_0 → a0_0) (fun _ x => x); let g := f (fun _ _ y => y); let h := g ChurchLayered.seed; h _ (fun _ z => z)
#print axioms ChurchFixture.case3
def ChurchFixture.case4 : (ChurchLayered.G2 (∀ a : Type, a → a) (∀ a : Type, a → a → a)) :=
  let f := ChurchLayered.maker2 ChurchLayered.seed (∀ (a0_0 : _), a0_0 → a0_0) (fun _ x => x); let g := f ChurchLayered.seed; g _ (fun _ y _ => y)
#print axioms ChurchFixture.case4
def ChurchFixture.case5 : (ChurchLayered.G3 (∀ a : Type, a → a) (∀ a : Type, a → a → a) (∀ a : Type, a → a)) :=
  let f := ChurchLayered.maker3 ChurchLayered.seed (∀ (a0_0 : _), a0_0 → a0_0) (∀ (a0_0 : _), a0_0 → a0_0 → a0_0) (fun _ x => x); let g := f (fun _ _ y => y); let h := g ChurchLayered.seed; h _ (fun _ z => z)
#print axioms ChurchFixture.case5
