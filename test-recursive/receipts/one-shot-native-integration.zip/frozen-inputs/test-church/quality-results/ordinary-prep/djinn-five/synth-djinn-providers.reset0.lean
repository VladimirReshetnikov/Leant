-- Independent source reset segment 0
axiom Demo.Seed : Type
axiom Demo.seedValue : Demo.Seed
universe u
inductive Demo.SealedBox (a : Type u) : Type u where
| mk (value : a) (proof : value = value) : Demo.SealedBox a

def Demo.sealedBox {a : Type u} (value : a) : Demo.SealedBox a :=
  .mk value rfl

def Demo.seedIdentity (value : Demo.Seed) : Demo.Seed := value

axiom Demo.Input : Type → Type
axiom Demo.Middle : Type → Type
axiom Demo.Output : Type → Type
axiom Demo.Index : Type
axiom Demo.consume {a : Type} : Demo.Middle a → Demo.Output a
axiom Demo.produce {a : Type} : Demo.Input a → Demo.Middle a

axiom Demo.Token : Type
class Demo.C (a : Type) : Prop where witness : True
instance : Demo.C Nat := ⟨True.intro⟩
axiom Demo.global {a : Type} [Demo.C a] : Demo.Token

noncomputable def goldenReplayQuery7Candidate1 : (Demo.Seed → Demo.SealedBox Demo.Seed) :=
  Demo.sealedBox
#print axioms goldenReplayQuery7Candidate1

noncomputable def goldenReplayQuery8Candidate1 : (Nat → Demo.Token) :=
  fun x => match x with | .zero => Demo.global («a» := Nat) | .succ _ => Demo.global («a» := Nat)
#print axioms goldenReplayQuery8Candidate1
noncomputable def goldenReplayQuery10Candidate1 : (Nat → Demo.Token) :=
  fun _ => Demo.global («a» := Nat)
#print axioms goldenReplayQuery10Candidate1
