-- Independent source reset segment 0
noncomputable def goldenReplayQuery3Candidate1 : (List a → List a → List a) :=
  fun x _ => x
#print axioms goldenReplayQuery3Candidate1
noncomputable def goldenReplayQuery3Candidate2 : (List a → List a → List a) :=
  fun _ x => x
#print axioms goldenReplayQuery3Candidate2
noncomputable def goldenReplayQuery3Candidate3 : (List a → List a → List a) :=
  fun x _ => List.reverse x
#print axioms goldenReplayQuery3Candidate3
noncomputable def goldenReplayQuery3Candidate4 : (List a → List a → List a) :=
  fun x y => List.append x y
#print axioms goldenReplayQuery3Candidate4
noncomputable def goldenReplayQuery3Candidate5 : (List a → List a → List a) :=
  fun x _ => List.append x x
#print axioms goldenReplayQuery3Candidate5
