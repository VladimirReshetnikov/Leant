set_option linter.unusedVariables false
-- These axioms model explicitly supplied opaque primitives. This fixture
-- checks provider discovery and kernel typing relative to that environment;
-- closed Church-corpus acceptance uses no axioms.
namespace ChurchProviders8
axiom Token : Type
class Choice (t0 t1 t2 t3 t4 t5 t6 t7 : Type 1) : Prop where witness : True
instance : Choice (∀ A : Type, A → A) (∀ A : Type, A → A → A) (∀ A : Type, A → A → A → A) (∀ A : Type, A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A → A → A) := ⟨True.intro⟩
axiom chosen {t0 t1 t2 t3 t4 t5 t6 t7 : Type 1} [Choice t0 t1 t2 t3 t4 t5 t6 t7] : Token
end ChurchProviders8

namespace ChurchProviders12
axiom Token : Type
class Choice (t0 t1 t2 t3 t4 t5 t6 t7 t8 t9 t10 t11 : Type 1) : Prop where witness : True
instance : Choice (∀ A : Type, A → A) (∀ A : Type, A → A → A) (∀ A : Type, A → A → A → A) (∀ A : Type, A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A → A → A → A → A → A) (∀ A : Type, A → A → A → A → A → A → A → A → A → A → A → A → A) := ⟨True.intro⟩
axiom chosen {t0 t1 t2 t3 t4 t5 t6 t7 t8 t9 t10 t11 : Type 1} [Choice t0 t1 t2 t3 t4 t5 t6 t7 t8 t9 t10 t11] : Token
end ChurchProviders12

noncomputable section
def ChurchFixture.case0 : ChurchProviders8.Token :=
  ChurchProviders8.chosen («t0» := (∀ (a0_0 : Type _), a0_0 → a0_0)) («t1» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0)) («t2» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0)) («t3» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0)) («t4» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0)) («t5» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0)) («t6» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0)) («t7» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0))
#print axioms ChurchFixture.case0
def ChurchFixture.case1 : ChurchProviders12.Token :=
  ChurchProviders12.chosen («t0» := (∀ (a0_0 : Type _), a0_0 → a0_0)) («t1» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0)) («t2» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0)) («t3» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0)) («t4» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0)) («t5» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0)) («t6» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0)) («t7» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0)) («t8» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0)) («t9» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0)) («t10» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0)) («t11» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0))
#print axioms ChurchFixture.case1
