-- Generated exclusively from synthesized candidates and the manifest.
set_option linter.unusedVariables false
def ChurchCorpus.integerZero : Int := 0

-- Church.hs:81 ltInt (total)
def ChurchCorpus.church_case_000 : (Int → (Int → (∀ (church0 : Type _), (church0 → (church0 → church0))))) :=
  fun _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_000

-- Church.hs:84 gtInt (total)
def ChurchCorpus.church_case_001 : (Int → (Int → (∀ (church0 : Type _), (church0 → (church0 → church0))))) :=
  fun _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_001

-- Church.hs:87 leInt (total)
def ChurchCorpus.church_case_002 : (Int → (Int → (∀ (church0 : Type _), (church0 → (church0 → church0))))) :=
  fun _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_002

-- Church.hs:92 eqInt (total)
def ChurchCorpus.church_case_003 : (Int → (Int → (∀ (church0 : Type _), (church0 → (church0 → church0))))) :=
  fun _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_003

-- Church.hs:95 geInt (total)
def ChurchCorpus.church_case_004 : (Int → (Int → (∀ (church0 : Type _), (church0 → (church0 → church0))))) :=
  fun _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_004

-- Church.hs:147 eqFromLE (total)
def ChurchCorpus.church_case_005 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))))) :=
  fun _ f => f
#print axioms ChurchCorpus.church_case_005

-- Church.hs:151 ltFromLE (total)
def ChurchCorpus.church_case_006 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))))) :=
  fun _ f => f
#print axioms ChurchCorpus.church_case_006

-- Church.hs:164 true (total)
def ChurchCorpus.church_case_007 : (∀ (church0 : Type _), (church0 → (church0 → church0))) :=
  fun _ x _ => x
#print axioms ChurchCorpus.church_case_007

-- Church.hs:167 false (total)
def ChurchCorpus.church_case_008 : (∀ (church0 : Type _), (church0 → (church0 → church0))) :=
  fun _ x _ => x
#print axioms ChurchCorpus.church_case_008

-- Church.hs:170 not (total)
def ChurchCorpus.church_case_009 : ((∀ (church0 : Type _), (church0 → (church0 → church0))) → (∀ (church1 : Type _), (church1 → (church1 → church1)))) :=
  fun f => f
#print axioms ChurchCorpus.church_case_009

-- Church.hs:173 and (total)
def ChurchCorpus.church_case_010 : ((∀ (church0 : Type _), (church0 → (church0 → church0))) → ((∀ (church1 : Type _), (church1 → (church1 → church1))) → (∀ (church2 : Type _), (church2 → (church2 → church2))))) :=
  fun f g _ x y => f _ x (g _ y x)
#print axioms ChurchCorpus.church_case_010

-- Church.hs:176 or (total)
def ChurchCorpus.church_case_011 : ((∀ (church0 : Type _), (church0 → (church0 → church0))) → ((∀ (church1 : Type _), (church1 → (church1 → church1))) → (∀ (church2 : Type _), (church2 → (church2 → church2))))) :=
  fun f g _ x y => f _ x (g _ y x)
#print axioms ChurchCorpus.church_case_011

-- Church.hs:179 xor (total)
def ChurchCorpus.church_case_012 : ((∀ (church0 : Type _), (church0 → (church0 → church0))) → ((∀ (church1 : Type _), (church1 → (church1 → church1))) → (∀ (church2 : Type _), (church2 → (church2 → church2))))) :=
  fun f g _ x y => f _ x (g _ y x)
#print axioms ChurchCorpus.church_case_012

-- Church.hs:186 pair (total)
def ChurchCorpus.church_case_013 : (∀ (church0 : Type _) (church1 : Type _), (church0 → (church1 → (∀ (church2 : Type _), ((church0 → (church1 → church2)) → church2))))) :=
  fun _ _ x y _ f => f x y
#print axioms ChurchCorpus.church_case_013

-- Church.hs:189 fst (total)
def ChurchCorpus.church_case_014 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church2 : Type _), ((church0 → (church1 → church2)) → church2)) → church0)) :=
  fun _ _ f => f _ (fun x _ => x)
#print axioms ChurchCorpus.church_case_014

-- Church.hs:192 snd (total)
def ChurchCorpus.church_case_015 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church2 : Type _), ((church1 → (church0 → church2)) → church2)) → church0)) :=
  fun _ _ f => f _ (fun _ x => x)
#print axioms ChurchCorpus.church_case_015

-- Church.hs:195 swap (total)
def ChurchCorpus.church_case_016 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church2 : Type _), ((church0 → (church1 → church2)) → church2)) → (∀ (church3 : Type _), ((church1 → (church0 → church3)) → church3)))) :=
  fun _ _ f _ g => f _ (fun x y => g y x)
#print axioms ChurchCorpus.church_case_016

-- Church.hs:198 curry (total)
def ChurchCorpus.church_case_017 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → church2) → (church0 → (church1 → church2)))) :=
  fun _ _ _ f x y => f (fun _ g => g x y)
#print axioms ChurchCorpus.church_case_017

-- Church.hs:201 uncurry (total)
def ChurchCorpus.church_case_018 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → church2)) → ((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → church2))) :=
  fun _ _ _ f g => g _ f
#print axioms ChurchCorpus.church_case_018

-- Church.hs:204 pairToList (total)
def ChurchCorpus.church_case_019 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church2 : Type _), ((church0 → (church1 → church2)) → church2)) → (∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → church3) → ((church1 → church3) → church3))) → (church4 → church4)) → (church4 → church4))))) :=
  fun _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_019

-- Church.hs:207 bimapPair (total)
def ChurchCorpus.church_case_020 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _) (church3 : Type _), ((church0 → church1) → ((church2 → church3) → ((∀ (church4 : Type _), ((church0 → (church2 → church4)) → church4)) → (∀ (church5 : Type _), ((church1 → (church3 → church5)) → church5)))))) :=
  fun _ _ _ _ f g h _ f1 => h _ (fun x y => f1 (f x) (g y))
#print axioms ChurchCorpus.church_case_020

-- Church.hs:218 nil (total)
def ChurchCorpus.church_case_021 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) :=
  fun _ _ _ x => x
#print axioms ChurchCorpus.church_case_021

-- Church.hs:222 cons (total)
def ChurchCorpus.church_case_022 : (∀ (church0 : Type _), (church0 → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2)))))) :=
  fun _ x f _ g y => g x (f _ g y)
#print axioms ChurchCorpus.church_case_022

-- Church.hs:226 snoc (total)
def ChurchCorpus.church_case_023 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (church0 → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2)))))) :=
  fun _ f x _ g y => g x (f _ g y)
#print axioms ChurchCorpus.church_case_023

-- Church.hs:229 uncons (total)
def ChurchCorpus.church_case_024 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church4 : Type _), (church4 → (((∀ (church3 : Type _), ((church0 → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → church3)) → church3)) → church4) → church4))))) :=
  fun _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_024

-- Church.hs:232 unsnoc (total)
def ChurchCorpus.church_case_025 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church4 : Type _), (church4 → (((∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (church0 → church3)) → church3)) → church4) → church4))))) :=
  fun _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_025

-- Church.hs:238 singleton (total)
def ChurchCorpus.church_case_026 : (∀ (church0 : Type _), (church0 → (∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))))) :=
  fun _ x _ f => f x
#print axioms ChurchCorpus.church_case_026

-- Church.hs:244 caseList (total)
def ChurchCorpus.church_case_027 : (∀ (church0 : Type _) (church1 : Type _), (church0 → ((church1 → ((∀ (church2 : Type _), ((church1 → (church2 → church2)) → (church2 → church2))) → church0)) → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → church0)))) :=
  fun _ _ x _ _ => x
#print axioms ChurchCorpus.church_case_027

-- Church.hs:251 head (requires_partiality)
def ChurchCorpus.church_case_028 : (∀ (church0 : Type _), (church0 → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → church0))) :=
  fun _ x _ => x
#print axioms ChurchCorpus.church_case_028

-- Church.hs:254 null (total)
def ChurchCorpus.church_case_029 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), (church2 → (church2 → church2))))) :=
  fun _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_029

-- Church.hs:257 tail (total)
def ChurchCorpus.church_case_030 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))))) :=
  fun _ f => f
#print axioms ChurchCorpus.church_case_030

-- Church.hs:264 last (requires_partiality)
def ChurchCorpus.church_case_031 : (∀ (church0 : Type _), (church0 → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → church0))) :=
  fun _ x _ => x
#print axioms ChurchCorpus.church_case_031

-- Church.hs:267 init (total)
def ChurchCorpus.church_case_032 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))))) :=
  fun _ f => f
#print axioms ChurchCorpus.church_case_032

-- Church.hs:270 at (requires_partiality)
def ChurchCorpus.church_case_033 : (∀ (church0 : Type _), (church0 → (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → church0)))) :=
  fun _ x y _ => match y with | .ofNat z => (match z with | .zero => x | .succ _ => x) | .negSucc w => (match w with | .zero => x | .succ _ => x)
#print axioms ChurchCorpus.church_case_033

-- Church.hs:276 any (total)
def ChurchCorpus.church_case_034 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), (church3 → (church3 → church3)))))) :=
  fun _ f g _ x y => g _ (fun z w => let h := f z; h _ y w) x
#print axioms ChurchCorpus.church_case_034

-- Church.hs:279 all (total)
def ChurchCorpus.church_case_035 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), (church3 → (church3 → church3)))))) :=
  fun _ f g _ x y => g _ (fun z w => let h := f z; h _ y w) x
#print axioms ChurchCorpus.church_case_035

-- Church.hs:286 foldr (total)
def ChurchCorpus.church_case_036 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → church1)))) :=
  fun _ _ f x g => g _ f x
#print axioms ChurchCorpus.church_case_036

-- Church.hs:289 foldl (total)
def ChurchCorpus.church_case_037 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → church0)) → (church0 → ((∀ (church2 : Type _), ((church1 → (church2 → church2)) → (church2 → church2))) → church0)))) :=
  fun _ _ f x g => g _ (fun y z => f z y) x
#print axioms ChurchCorpus.church_case_037

-- Church.hs:292 foldl1 (requires_partiality)
def ChurchCorpus.church_case_038 : (∀ (church0 : Type _), (church0 → ((church0 → (church0 → church0)) → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → church0)))) :=
  fun _ x f g => f x (g _ f x)
#print axioms ChurchCorpus.church_case_038

-- Church.hs:295 foldr1 (requires_partiality)
def ChurchCorpus.church_case_039 : (∀ (church0 : Type _), (church0 → ((church0 → (church0 → church0)) → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → church0)))) :=
  fun _ x f g => f x (g _ f x)
#print axioms ChurchCorpus.church_case_039

-- Church.hs:299 scanr (total)
def ChurchCorpus.church_case_040 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))))))) :=
  fun _ _ f x g _ h y => h x (g _ (fun z => h (f z x)) y)
#print axioms ChurchCorpus.church_case_040

-- Church.hs:305 mapAccumR (total)
def ChurchCorpus.church_case_041 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (∀ (church3 : Type _), ((church0 → (church2 → church3)) → church3)))) → (church0 → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), ((church0 → ((∀ (church5 : Type _), ((church2 → (church5 → church5)) → (church5 → church5))) → church6)) → church6)))))) :=
  fun _ _ _ _ x _ _ f => f x (fun _ _ y => y)
#print axioms ChurchCorpus.church_case_041

-- Church.hs:310 scanl (total)
def ChurchCorpus.church_case_042 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → church0)) → (church0 → ((∀ (church2 : Type _), ((church1 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))))))) :=
  fun _ _ f x g _ h y => h x (g _ (fun z => h (f x z)) y)
#print axioms ChurchCorpus.church_case_042

-- Church.hs:317 mapAccumL (total)
def ChurchCorpus.church_case_043 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (∀ (church3 : Type _), ((church0 → (church2 → church3)) → church3)))) → (church0 → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), ((church0 → ((∀ (church5 : Type _), ((church2 → (church5 → church5)) → (church5 → church5))) → church6)) → church6)))))) :=
  fun _ _ _ _ x _ _ f => f x (fun _ _ y => y)
#print axioms ChurchCorpus.church_case_043

-- Church.hs:325 zipWith (total)
def ChurchCorpus.church_case_044 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → church2)) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), ((church2 → (church5 → church5)) → (church5 → church5))))))) :=
  fun _ _ _ f g h _ f1 => h _ (fun x => g _ (fun y => f1 (f y x)))
#print axioms ChurchCorpus.church_case_044

-- Church.hs:332 zipWithN (total)
def ChurchCorpus.church_case_045 : (∀ (church0 : Type _) (church1 : Type _), (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → church1) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), ((church1 → (church5 → church5)) → (church5 → church5)))))) :=
  fun _ _ f g _ h => g _ (fun f1 => h (f f1))
#print axioms ChurchCorpus.church_case_045

-- Church.hs:339 scanl2 (total)
def ChurchCorpus.church_case_046 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (church2 → church0))) → (church0 → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church2 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), ((church0 → (church5 → church5)) → (church5 → church5)))))))) :=
  fun _ _ _ f x g h _ f1 => f1 (g _ (fun y => h _ (fun z w => f w y z)) x)
#print axioms ChurchCorpus.church_case_046

-- Church.hs:352 scanlN (total)
def ChurchCorpus.church_case_047 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → ((∀ (church2 : Type _), ((church1 → (church2 → church2)) → (church2 → church2))) → church0)) → (church0 → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), ((church0 → (church5 → church5)) → (church5 → church5))))))) :=
  fun _ _ f x g _ h y => h x (g _ (fun f1 => h (f x f1)) y)
#print axioms ChurchCorpus.church_case_047

-- Church.hs:360 mapAccumL2 (total)
def ChurchCorpus.church_case_048 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _) (church3 : Type _), ((church0 → (church1 → (church2 → (∀ (church4 : Type _), ((church0 → (church3 → church4)) → church4))))) → (church0 → ((∀ (church5 : Type _), ((church1 → (church5 → church5)) → (church5 → church5))) → ((∀ (church6 : Type _), ((church2 → (church6 → church6)) → (church6 → church6))) → (∀ (church8 : Type _), ((church0 → ((∀ (church7 : Type _), ((church3 → (church7 → church7)) → (church7 → church7))) → church8)) → church8))))))) :=
  fun _ _ _ _ _ x _ _ _ f => f x (fun _ _ y => y)
#print axioms ChurchCorpus.church_case_048

-- Church.hs:368 mapAccumLN (total)
def ChurchCorpus.church_case_049 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church0 → (church2 → church4)) → church4)))) → (church0 → ((∀ (church6 : Type _), (((∀ (church5 : Type _), ((church1 → (church5 → church5)) → (church5 → church5))) → (church6 → church6)) → (church6 → church6))) → (∀ (church8 : Type _), ((church0 → ((∀ (church7 : Type _), ((church2 → (church7 → church7)) → (church7 → church7))) → church8)) → church8)))))) :=
  fun _ _ _ _ x _ _ f => f x (fun _ _ y => y)
#print axioms ChurchCorpus.church_case_049

-- Church.hs:371 zip (total)
def ChurchCorpus.church_case_050 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5)))))) :=
  fun _ _ f g _ h => g _ (fun x => f _ (fun y => h (fun _ f1 => f1 y x)))
#print axioms ChurchCorpus.church_case_050

-- Church.hs:374 unzip (total)
def ChurchCorpus.church_case_051 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church1 → church2)) → church2)) → (church3 → church3)) → (church3 → church3))) → (∀ (church6 : Type _), (((∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))) → ((∀ (church5 : Type _), ((church1 → (church5 → church5)) → (church5 → church5))) → church6)) → church6)))) :=
  fun _ _ _ _ f => f (fun _ _ x => x) (fun _ _ y => y)
#print axioms ChurchCorpus.church_case_051

-- Church.hs:380 unfoldr (total)
def ChurchCorpus.church_case_052 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (∀ (church3 : Type _), (church3 → (((∀ (church2 : Type _), ((church1 → (church0 → church2)) → church2)) → church3) → church3)))) → (church0 → (∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4)))))) :=
  fun _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_052

-- Church.hs:387 unfoldTree (total)
def ChurchCorpus.church_case_053 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (∀ (church3 : Type _), ((church1 → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → church3)) → church3))) → (church0 → (∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4)))))) :=
  fun _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_053

-- Church.hs:391 append (total)
def ChurchCorpus.church_case_054 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ h (f _ h x)
#print axioms ChurchCorpus.church_case_054

-- Church.hs:394 appendEither (total)
def ChurchCorpus.church_case_055 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → church4) → ((church1 → church4) → church4))) → (church5 → church5)) → (church5 → church5)))))) :=
  fun _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_055

-- Church.hs:397 map (total)
def ChurchCorpus.church_case_056 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → church1) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ _ f g _ h => g _ (fun x => h (f x))
#print axioms ChurchCorpus.church_case_056

-- Church.hs:400 concat (total)
def ChurchCorpus.church_case_057 : (∀ (church0 : Type _), ((∀ (church2 : Type _), (((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))))) :=
  fun _ f _ g => f _ (fun h => h _ g)
#print axioms ChurchCorpus.church_case_057

-- Church.hs:403 concatMap (total)
def ChurchCorpus.church_case_058 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (∀ (church2 : Type _), ((church1 → (church2 → church2)) → (church2 → church2)))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4)))))) :=
  fun _ _ f g _ h x => g _ (fun y z => let f1 := f y; f1 _ h z) x
#print axioms ChurchCorpus.church_case_058

-- Church.hs:406 filter (total)
def ChurchCorpus.church_case_059 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h y (let f1 := f y; f1 _ z x)) x
#print axioms ChurchCorpus.church_case_059

-- Church.hs:409 length (needs_int_provider)
def ChurchCorpus.church_case_060 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → Int)) :=
  fun _ _ => .negSucc (.zero)
#print axioms ChurchCorpus.church_case_060

-- Church.hs:412 reverse (total)
def ChurchCorpus.church_case_061 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))))) :=
  fun _ f => f
#print axioms ChurchCorpus.church_case_061

-- Church.hs:415 take (total)
def ChurchCorpus.church_case_062 : (∀ (church0 : Type _), (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2)))))) :=
  fun _ x f => match x with | .ofNat y => (match y with | .zero => f | .succ _ => f) | .negSucc z => (match z with | .zero => f | .succ _ => f)
#print axioms ChurchCorpus.church_case_062

-- Church.hs:418 drop (total)
def ChurchCorpus.church_case_063 : (∀ (church0 : Type _), (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2)))))) :=
  fun _ x f => match x with | .ofNat y => (match y with | .zero => f | .succ _ => f) | .negSucc z => (match z with | .zero => f | .succ _ => f)
#print axioms ChurchCorpus.church_case_063

-- Church.hs:421 splitAt (total)
def ChurchCorpus.church_case_064 : (∀ (church0 : Type _), (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church4 : Type _), (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → church4)) → church4))))) :=
  fun _ _ f _ g => g f f
#print axioms ChurchCorpus.church_case_064

-- Church.hs:424 takeLast (total)
def ChurchCorpus.church_case_065 : (∀ (church0 : Type _), (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2)))))) :=
  fun _ x f => match x with | .ofNat y => (match y with | .zero => f | .succ _ => f) | .negSucc z => (match z with | .zero => f | .succ _ => f)
#print axioms ChurchCorpus.church_case_065

-- Church.hs:427 dropLast (total)
def ChurchCorpus.church_case_066 : (∀ (church0 : Type _), (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2)))))) :=
  fun _ x f => match x with | .ofNat y => (match y with | .zero => f | .succ _ => f) | .negSucc z => (match z with | .zero => f | .succ _ => f)
#print axioms ChurchCorpus.church_case_066

-- Church.hs:430 takeWhile (total)
def ChurchCorpus.church_case_067 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h y (let f1 := f y; f1 _ z x)) x
#print axioms ChurchCorpus.church_case_067

-- Church.hs:433 dropWhile (total)
def ChurchCorpus.church_case_068 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h y (let f1 := f y; f1 _ z x)) x
#print axioms ChurchCorpus.church_case_068

-- Church.hs:438 partition (total)
def ChurchCorpus.church_case_069 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church5 : Type _), (((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))) → church5)) → church5))))) :=
  fun _ f g _ h => g _ (fun x y => let f1 := f x; f1 _ y y) (h g g)
#print axioms ChurchCorpus.church_case_069

-- Church.hs:443 partitionEvery (total)
def ChurchCorpus.church_case_070 : (∀ (church0 : Type _), (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_070

-- Church.hs:448 partitionStep (total)
def ChurchCorpus.church_case_071 : (∀ (church0 : Type _), (Int → (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (church3 → church3)) → (church3 → church3))))))) :=
  fun _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_071

-- Church.hs:459 windows (total)
def ChurchCorpus.church_case_072 : (∀ (church0 : Type _), (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_072

-- Church.hs:463 inits (total)
def ChurchCorpus.church_case_073 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (church3 → church3)) → (church3 → church3))))) :=
  fun _ f _ g => g f
#print axioms ChurchCorpus.church_case_073

-- Church.hs:466 tails (total)
def ChurchCorpus.church_case_074 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (church3 → church3)) → (church3 → church3))))) :=
  fun _ f _ g => g f
#print axioms ChurchCorpus.church_case_074

-- Church.hs:471 span (total)
def ChurchCorpus.church_case_075 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church5 : Type _), (((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))) → church5)) → church5))))) :=
  fun _ f g _ h => g _ (fun x y => let f1 := f x; f1 _ y y) (h g g)
#print axioms ChurchCorpus.church_case_075

-- Church.hs:474 replicate (total)
def ChurchCorpus.church_case_076 : (∀ (church0 : Type _), (Int → (church0 → (∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1)))))) :=
  fun _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_076

-- Church.hs:479 lexicographicLE (total)
def ChurchCorpus.church_case_077 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), (church3 → (church3 → church3))))))) :=
  fun _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_077

-- Church.hs:489 compose (total)
def ChurchCorpus.church_case_078 : (∀ (church0 : Type _), ((∀ (church1 : Type _), (((church0 → church0) → (church1 → church1)) → (church1 → church1))) → (church0 → church0))) :=
  fun _ f => f _ (fun g => g)
#print axioms ChurchCorpus.church_case_078

-- Church.hs:494 composeFlatten (total)
def ChurchCorpus.church_case_079 : (∀ (church0 : Type _), ((∀ (church2 : Type _), (((church0 → (∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1)))) → (church2 → church2)) → (church2 → church2))) → (church0 → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f x _ g y => f _ (fun h z => let f1 := h x; f1 _ g z) y
#print axioms ChurchCorpus.church_case_079

-- Church.hs:499 cartesianWith (total)
def ChurchCorpus.church_case_080 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → church2)) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), ((church2 → (church5 → church5)) → (church5 → church5))))))) :=
  fun _ _ _ f g h _ f1 => h _ (fun x => g _ (fun y => f1 (f y x)))
#print axioms ChurchCorpus.church_case_080

-- Church.hs:505 cartesian (total)
def ChurchCorpus.church_case_081 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5)))))) :=
  fun _ _ f g _ h => g _ (fun x => f _ (fun y => h (fun _ f1 => f1 y x)))
#print axioms ChurchCorpus.church_case_081

-- Church.hs:512 cartesianN (total)
def ChurchCorpus.church_case_082 : (∀ (church0 : Type _), ((∀ (church2 : Type _), (((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (church4 → church4)) → (church4 → church4))))) :=
  fun _ f => f
#print axioms ChurchCorpus.church_case_082

-- Church.hs:515 intersperse (total)
def ChurchCorpus.church_case_083 : (∀ (church0 : Type _), (church0 → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2)))))) :=
  fun _ x f _ g y => g x (f _ g y)
#print axioms ChurchCorpus.church_case_083

-- Church.hs:519 riffle (total)
def ChurchCorpus.church_case_084 : (∀ (church0 : Type _), (church0 → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2)))))) :=
  fun _ x f _ g y => g x (f _ g y)
#print axioms ChurchCorpus.church_case_084

-- Church.hs:522 rotateLeftN (total)
def ChurchCorpus.church_case_085 : (∀ (church0 : Type _), (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2)))))) :=
  fun _ x f => match x with | .ofNat y => (match y with | .zero => f | .succ _ => f) | .negSucc z => (match z with | .zero => f | .succ _ => f)
#print axioms ChurchCorpus.church_case_085

-- Church.hs:525 rotateRightN (total)
def ChurchCorpus.church_case_086 : (∀ (church0 : Type _), (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2)))))) :=
  fun _ x f => match x with | .ofNat y => (match y with | .zero => f | .succ _ => f) | .negSucc z => (match z with | .zero => f | .succ _ => f)
#print axioms ChurchCorpus.church_case_086

-- Church.hs:528 rotateLeft (total)
def ChurchCorpus.church_case_087 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))))) :=
  fun _ f => f
#print axioms ChurchCorpus.church_case_087

-- Church.hs:531 rotateRight (total)
def ChurchCorpus.church_case_088 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))))) :=
  fun _ f => f
#print axioms ChurchCorpus.church_case_088

-- Church.hs:536 transpose (total)
def ChurchCorpus.church_case_089 : (∀ (church0 : Type _), ((∀ (church2 : Type _), (((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (church4 → church4)) → (church4 → church4))))) :=
  fun _ f => f
#print axioms ChurchCorpus.church_case_089

-- Church.hs:548 just (total)
def ChurchCorpus.church_case_090 : (∀ (church0 : Type _), (church0 → (∀ (church1 : Type _), (church1 → ((church0 → church1) → church1))))) :=
  fun _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_090

-- Church.hs:551 nothing (total)
def ChurchCorpus.church_case_091 : (∀ (church0 : Type _) (church1 : Type _), (church1 → ((church0 → church1) → church1))) :=
  fun _ _ x _ => x
#print axioms ChurchCorpus.church_case_091

-- Church.hs:554 isNothing (total)
def ChurchCorpus.church_case_092 : (∀ (church0 : Type _), ((∀ (church1 : Type _), (church1 → ((church0 → church1) → church1))) → (∀ (church2 : Type _), (church2 → (church2 → church2))))) :=
  fun _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_092

-- Church.hs:558 fromJust (requires_partiality)
def ChurchCorpus.church_case_093 : (∀ (church0 : Type _), (church0 → ((∀ (church1 : Type _), (church1 → ((church0 → church1) → church1))) → church0))) :=
  fun _ x f => f _ x (fun y => y)
#print axioms ChurchCorpus.church_case_093

-- Church.hs:562 fromMaybe (total)
def ChurchCorpus.church_case_094 : (∀ (church0 : Type _), (church0 → ((∀ (church1 : Type _), (church1 → ((church0 → church1) → church1))) → church0))) :=
  fun _ x f => f _ x (fun y => y)
#print axioms ChurchCorpus.church_case_094

-- Church.hs:567 maybeToList (total)
def ChurchCorpus.church_case_095 : (∀ (church0 : Type _), ((∀ (church1 : Type _), (church1 → ((church0 → church1) → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))))) :=
  fun _ f _ g x => f _ x (fun y => g y x)
#print axioms ChurchCorpus.church_case_095

-- Church.hs:571 listToMaybe (total)
def ChurchCorpus.church_case_096 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), (church2 → ((church0 → church2) → church2))))) :=
  fun _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_096

-- Church.hs:576 catMaybes (total)
def ChurchCorpus.church_case_097 : (∀ (church0 : Type _), ((∀ (church2 : Type _), (((∀ (church1 : Type _), (church1 → ((church0 → church1) → church1))) → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))))) :=
  fun _ f _ g => f _ (fun h x => h _ x (fun y => g y x))
#print axioms ChurchCorpus.church_case_097

-- Church.hs:579 mapMaybe (total)
def ChurchCorpus.church_case_098 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (∀ (church2 : Type _), (church2 → ((church1 → church2) → church2)))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4)))))) :=
  fun _ _ f g _ h x => g _ (fun y z => let f1 := f y; f1 _ z (fun w => h w x)) x
#print axioms ChurchCorpus.church_case_098

-- Church.hs:584 squashMaybe (total)
def ChurchCorpus.church_case_099 : (∀ (church0 : Type _), ((∀ (church2 : Type _), (church2 → (((∀ (church1 : Type _), (church1 → ((church0 → church1) → church1))) → church2) → church2))) → (∀ (church3 : Type _), (church3 → ((church0 → church3) → church3))))) :=
  fun _ f _ x g => f _ x (fun h => h _ x g)
#print axioms ChurchCorpus.church_case_099

-- Church.hs:589 sequence (total)
def ChurchCorpus.church_case_100 : (∀ (church0 : Type _), ((∀ (church2 : Type _), (((∀ (church1 : Type _), (church1 → ((church0 → church1) → church1))) → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (church4 → (((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → church4) → church4))))) :=
  fun _ f _ x g => f _ (fun h y => h _ y (fun z => g (fun _ f1 => f1 z))) x
#print axioms ChurchCorpus.church_case_100

-- Church.hs:596 left (total)
def ChurchCorpus.church_case_101 : (∀ (church0 : Type _) (church1 : Type _), (church0 → (∀ (church2 : Type _), ((church0 → church2) → ((church1 → church2) → church2))))) :=
  fun _ _ x _ f _ => f x
#print axioms ChurchCorpus.church_case_101

-- Church.hs:599 right (total)
def ChurchCorpus.church_case_102 : (∀ (church0 : Type _) (church1 : Type _), (church0 → (∀ (church2 : Type _), ((church1 → church2) → ((church0 → church2) → church2))))) :=
  fun _ _ x _ _ f => f x
#print axioms ChurchCorpus.church_case_102

-- Church.hs:602 isLeft (total)
def ChurchCorpus.church_case_103 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church2 : Type _), ((church0 → church2) → ((church1 → church2) → church2))) → (∀ (church3 : Type _), (church3 → (church3 → church3))))) :=
  fun _ _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_103

-- Church.hs:605 isRight (total)
def ChurchCorpus.church_case_104 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church2 : Type _), ((church0 → church2) → ((church1 → church2) → church2))) → (∀ (church3 : Type _), (church3 → (church3 → church3))))) :=
  fun _ _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_104

-- Church.hs:608 fromLeft (requires_partiality)
def ChurchCorpus.church_case_105 : (∀ (church0 : Type _) (church1 : Type _), (church0 → ((∀ (church2 : Type _), ((church0 → church2) → ((church1 → church2) → church2))) → church0))) :=
  fun _ _ x _ => x
#print axioms ChurchCorpus.church_case_105

-- Church.hs:611 fromRight (requires_partiality)
def ChurchCorpus.church_case_106 : (∀ (church0 : Type _) (church1 : Type _), (church0 → ((∀ (church2 : Type _), ((church1 → church2) → ((church0 → church2) → church2))) → church0))) :=
  fun _ _ x _ => x
#print axioms ChurchCorpus.church_case_106

-- Church.hs:615 maybeEither (total)
def ChurchCorpus.church_case_107 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church4 : Type _), (((∀ (church2 : Type _), (church2 → ((church0 → church2) → church2))) → church4) → (((∀ (church3 : Type _), (church3 → ((church1 → church3) → church3))) → church4) → church4))) → (∀ (church6 : Type _), (church6 → (((∀ (church5 : Type _), ((church0 → church5) → ((church1 → church5) → church5))) → church6) → church6))))) :=
  fun _ _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_107

-- Church.hs:621 eitherMaybe (total)
def ChurchCorpus.church_case_108 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church3 : Type _), (church3 → (((∀ (church2 : Type _), ((church0 → church2) → ((church1 → church2) → church2))) → church3) → church3))) → (∀ (church6 : Type _), (((∀ (church4 : Type _), (church4 → ((church0 → church4) → church4))) → church6) → (((∀ (church5 : Type _), (church5 → ((church1 → church5) → church5))) → church6) → church6))))) :=
  fun _ _ _ _ f _ => f (fun _ x _ => x)
#print axioms ChurchCorpus.church_case_108

-- Church.hs:624 either (total)
def ChurchCorpus.church_case_109 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → church1) → ((church2 → church1) → ((∀ (church3 : Type _), ((church0 → church3) → ((church2 → church3) → church3))) → church1)))) :=
  fun _ _ _ f g h => h _ f g
#print axioms ChurchCorpus.church_case_109

-- Church.hs:627 lefts (total)
def ChurchCorpus.church_case_110 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → church2) → ((church1 → church2) → church2))) → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))))) :=
  fun _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_110

-- Church.hs:630 rights (total)
def ChurchCorpus.church_case_111 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → church2) → ((church1 → church2) → church2))) → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))))) :=
  fun _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_111

-- Church.hs:633 partitionEithers (total)
def ChurchCorpus.church_case_112 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → church2) → ((church1 → church2) → church2))) → (church3 → church3)) → (church3 → church3))) → (∀ (church6 : Type _), (((∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))) → ((∀ (church5 : Type _), ((church1 → (church5 → church5)) → (church5 → church5))) → church6)) → church6)))) :=
  fun _ _ _ _ f => f (fun _ _ x => x) (fun _ _ y => y)
#print axioms ChurchCorpus.church_case_112

-- Church.hs:645 lookup (total)
def ChurchCorpus.church_case_113 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → (church1 → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church2 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church6 : Type _), (church6 → ((church2 → church6) → church6))))))) :=
  fun _ _ _ f x g _ y h => g _ (fun f1 z => f1 _ (fun w x1 => let f2 := f w; let f3 := f2 x; f3 _ z (h x1))) y
#print axioms ChurchCorpus.church_case_113

-- Church.hs:649 lookupDefault (total)
def ChurchCorpus.church_case_114 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → (church2 → (church1 → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church2 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → church2))))) :=
  fun _ _ _ f x y g => g _ (fun h z => h _ (fun w x1 => let f1 := f w; let f2 := f1 y; f2 _ z x1)) x
#print axioms ChurchCorpus.church_case_114

-- Church.hs:653 keyExists (total)
def ChurchCorpus.church_case_115 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → (church1 → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church2 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church6 : Type _), (church6 → (church6 → church6))))))) :=
  fun _ _ _ _ _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_115

-- Church.hs:657 keyMember (total)
def ChurchCorpus.church_case_116 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → (church1 → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church2 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church6 : Type _), (church6 → (church6 → church6))))))) :=
  fun _ _ _ _ _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_116

-- Church.hs:661 keyFree (total)
def ChurchCorpus.church_case_117 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → (church1 → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church2 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church6 : Type _), (church6 → (church6 → church6))))))) :=
  fun _ _ _ _ _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_117

-- Church.hs:668 keyValueMap (total)
def ChurchCorpus.church_case_118 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → church2)) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), ((church2 → (church5 → church5)) → (church5 → church5)))))) :=
  fun _ _ _ f g _ h => g _ (fun f1 => h (f1 _ f))
#print axioms ChurchCorpus.church_case_118

-- Church.hs:672 mapKeys (total)
def ChurchCorpus.church_case_119 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → church1) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church2 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church1 → (church2 → church5)) → church5)) → (church6 → church6)) → (church6 → church6)))))) :=
  fun _ _ _ f g _ h => g _ (fun f1 => h (fun _ f2 => f1 _ (fun x => f2 (f x))))
#print axioms ChurchCorpus.church_case_119

-- Church.hs:676 dictFromLists (total)
def ChurchCorpus.church_case_120 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5)))))) :=
  fun _ _ f g _ h => g _ (fun x => f _ (fun y => h (fun _ f1 => f1 y x)))
#print axioms ChurchCorpus.church_case_120

-- Church.hs:681 associationMap (total)
def ChurchCorpus.church_case_121 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((church0 → church1) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))))))) :=
  fun _ _ f g h _ f1 x => h _ (fun y z => f1 (let f2 := f y; fun _ f3 => f3 y (g (let f4 := f2 y; f4 _ y y))) z) x
#print axioms ChurchCorpus.church_case_121

-- Church.hs:687 insertOrUpdate (total)
def ChurchCorpus.church_case_122 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church0 → (church1 → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6)))))))) :=
  fun _ _ f x y g _ h z => h (fun _ f1 => f1 (let f2 := f x; let f3 := f2 x; f3 _ x x) y) (g _ h z)
#print axioms ChurchCorpus.church_case_122

-- Church.hs:702 invert (total)
def ChurchCorpus.church_case_123 : (∀ (church0 : Type _) (church1 : Type _), ((church1 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church1 → ((∀ (church5 : Type _), ((church0 → (church5 → church5)) → (church5 → church5))) → church6)) → church6)) → (church7 → church7)) → (church7 → church7)))))) :=
  fun _ _ f g _ h x => g _ (fun f1 y => f1 _ (fun z w => h (fun _ f2 => f2 w (fun _ f3 x1 => let f4 := f w; f3 z (let f5 := f4 w; f5 _ x1 x1))) y)) x
#print axioms ChurchCorpus.church_case_123

-- Church.hs:709 merge (total)
def ChurchCorpus.church_case_124 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (church5 → church5)) → (church5 → church5))) → (∀ (church8 : Type _), (((∀ (church7 : Type _), ((church0 → ((∀ (church6 : Type _), ((church1 → (church6 → church6)) → (church6 → church6))) → church7)) → church7)) → (church8 → church8)) → (church8 → church8)))))) :=
  fun _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_124

-- Church.hs:714 mergeWith (total)
def ChurchCorpus.church_case_125 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church0 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → (((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → church2) → ((∀ (church7 : Type _), (((∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))) → (church7 → church7)) → (church7 → church7))) → (∀ (church9 : Type _), (((∀ (church8 : Type _), ((church0 → (church2 → church8)) → church8)) → (church9 → church9)) → (church9 → church9))))))) :=
  fun _ _ _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_125

-- Church.hs:720 collapse (total)
def ChurchCorpus.church_case_126 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church0 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → ((church1 → (church1 → (∀ (church4 : Type _), (church4 → (church4 → church4))))) → ((∀ (church8 : Type _), (((∀ (church7 : Type _), ((church0 → ((∀ (church6 : Type _), (((∀ (church5 : Type _), ((church1 → (church2 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))) → church7)) → church7)) → (church8 → church8)) → (church8 → church8))) → (∀ (church11 : Type _), (((∀ (church10 : Type _), (((∀ (church9 : Type _), ((church0 → (church1 → church9)) → church9)) → (church2 → church10)) → church10)) → (church11 → church11)) → (church11 → church11))))))) :=
  fun _ _ _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_126

-- Church.hs:728 eitherDict (total)
def ChurchCorpus.church_case_127 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → ((∀ (church6 : Type _), (((∀ (church5 : Type _), ((church2 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))) → (∀ (church9 : Type _), (((∀ (church8 : Type _), (((∀ (church7 : Type _), ((church0 → church7) → ((church2 → church7) → church7))) → (church1 → church8)) → church8)) → (church9 → church9)) → (church9 → church9)))))) :=
  fun _ _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_127

-- Church.hs:733 chain (total)
def ChurchCorpus.church_case_128 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church0 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → ((church1 → (church1 → (∀ (church4 : Type _), (church4 → (church4 → church4))))) → ((∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))) → ((∀ (church8 : Type _), (((∀ (church7 : Type _), ((church1 → (church2 → church7)) → church7)) → (church8 → church8)) → (church8 → church8))) → (∀ (church10 : Type _), (((∀ (church9 : Type _), ((church0 → (church2 → church9)) → church9)) → (church10 → church10)) → (church10 → church10)))))))) :=
  fun _ _ _ _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_128

-- Church.hs:738 chainN (total)
def ChurchCorpus.church_case_129 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church0 → church2)) → church2)) → (church3 → church3)) → (church3 → church3))) → ((∀ (church6 : Type _), (((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church0 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (church6 → church6)) → (church6 → church6))) → (∀ (church8 : Type _), (((∀ (church7 : Type _), ((church0 → (church0 → church7)) → church7)) → (church8 → church8)) → (church8 → church8))))))) :=
  fun _ _ f _ => f
#print axioms ChurchCorpus.church_case_129

-- Church.hs:743 mapValues (total)
def ChurchCorpus.church_case_130 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → church1) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church2 → (church0 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church2 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6)))))) :=
  fun _ _ _ f g _ h => g _ (fun f1 => h (fun _ f2 => f1 _ (fun x y => f2 x (f y))))
#print axioms ChurchCorpus.church_case_130

-- Church.hs:749 mapMaybeValues (total)
def ChurchCorpus.church_case_131 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (∀ (church3 : Type _), (church3 → ((church1 → church3) → church3)))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church2 → (church0 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church2 → (church1 → church6)) → church6)) → (church7 → church7)) → (church7 → church7)))))) :=
  fun _ _ _ f g _ h x => g _ (fun f1 y => f1 _ (fun z w => let f2 := f w; f2 _ y (fun x1 => h (fun _ f3 => f3 z x1) y))) x
#print axioms ChurchCorpus.church_case_131

-- Church.hs:757 cartesianDict (total)
def ChurchCorpus.church_case_132 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _) (church3 : Type _), ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church2 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → ((∀ (church7 : Type _), (((∀ (church6 : Type _), ((church1 → (church3 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))) → (∀ (church11 : Type _), (((∀ (church10 : Type _), (((∀ (church8 : Type _), ((church0 → (church1 → church8)) → church8)) → ((∀ (church9 : Type _), ((church2 → (church3 → church9)) → church9)) → church10)) → church10)) → (church11 → church11)) → (church11 → church11)))))) :=
  fun _ _ _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_132

-- Church.hs:764 deleteKey (total)
def ChurchCorpus.church_case_133 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church0 → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))))))) :=
  fun _ _ f x g _ h y => g _ h (let f1 := f x; let f2 := f1 x; f2 _ y y)
#print axioms ChurchCorpus.church_case_133

-- Church.hs:768 keyTake (total)
def ChurchCorpus.church_case_134 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church1 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))))))) :=
  fun _ _ f g h _ f1 x => h _ f1 (g _ (fun y z => let f2 := f y; let f3 := f2 y; f3 _ z x) x)
#print axioms ChurchCorpus.church_case_134

-- Church.hs:772 keyTakeOrdered (total)
def ChurchCorpus.church_case_135 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church1 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))))))) :=
  fun _ _ f g h _ f1 x => h _ f1 (g _ (fun y z => let f2 := f y; let f3 := f2 y; f3 _ z x) x)
#print axioms ChurchCorpus.church_case_135

-- Church.hs:777 keyDrop (total)
def ChurchCorpus.church_case_136 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church1 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))))))) :=
  fun _ _ f g h _ f1 x => h _ f1 (g _ (fun y z => let f2 := f y; let f3 := f2 y; f3 _ z x) x)
#print axioms ChurchCorpus.church_case_136

-- Church.hs:781 keySelect (total)
def ChurchCorpus.church_case_137 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (∀ (church2 : Type _), (church2 → (church2 → church2)))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6)))))) :=
  fun _ _ f g _ h x => g _ (fun f1 y => h (fun _ f2 => f1 _ (fun z w => f2 z (let f3 := f z; f3 _ w w))) y) x
#print axioms ChurchCorpus.church_case_137

-- Church.hs:785 upsertWith (total)
def ChurchCorpus.church_case_138 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church0 → (church1 → ((church1 → church1) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))))))))) :=
  fun _ _ f x y g h _ f1 z => h _ f1 (f1 (fun _ f2 => f2 (let f3 := f x; let f4 := f3 x; f4 _ x x) (g y)) z)
#print axioms ChurchCorpus.church_case_138

-- Church.hs:789 keySortBy (total)
def ChurchCorpus.church_case_139 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church0 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → ((church1 → church0) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church1 → (church2 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church1 → (church2 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))))))) :=
  fun _ _ _ f g h _ f1 x => h _ (fun f2 y => f2 _ (fun z w => f1 (fun _ f3 => f3 (let f4 := f (g z); let f5 := f4 (g z); f5 _ z z) w) y)) x
#print axioms ChurchCorpus.church_case_139

-- Church.hs:793 keySort (total)
def ChurchCorpus.church_case_140 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6)))))) :=
  fun _ _ f g _ h x => g _ (fun f1 y => h (fun _ f2 => f1 _ (fun z w => f2 (let f3 := f z; let f4 := f3 z; f4 _ z z) w)) y) x
#print axioms ChurchCorpus.church_case_140

-- Church.hs:797 unionKeys (total)
def ChurchCorpus.church_case_141 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (church5 → church5)) → (church5 → church5))) → (∀ (church6 : Type _), ((church0 → (church6 → church6)) → (church6 → church6)))))) :=
  fun _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_141

-- Church.hs:802 intersectionKeys (total)
def ChurchCorpus.church_case_142 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (church5 → church5)) → (church5 → church5))) → (∀ (church6 : Type _), ((church0 → (church6 → church6)) → (church6 → church6)))))) :=
  fun _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_142

-- Church.hs:807 keyComplement (total)
def ChurchCorpus.church_case_143 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church0 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → ((∀ (church8 : Type _), (((∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church2 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))) → (church8 → church8)) → (church8 → church8))) → (∀ (church10 : Type _), (((∀ (church9 : Type _), ((church0 → (church1 → church9)) → church9)) → (church10 → church10)) → (church10 → church10))))))) :=
  fun _ _ _ _ f _ => f
#print axioms ChurchCorpus.church_case_143

-- Church.hs:812 keyIntersection (total)
def ChurchCorpus.church_case_144 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (church5 → church5)) → (church5 → church5))) → (∀ (church8 : Type _), (((∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church1 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))) → (church8 → church8)) → (church8 → church8)))))) :=
  fun _ _ _ f => f
#print axioms ChurchCorpus.church_case_144

-- Church.hs:818 keyUnion (total)
def ChurchCorpus.church_case_145 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((church0 → church1) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (church5 → church5)) → (church5 → church5))) → (∀ (church8 : Type _), (((∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church1 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))) → (church8 → church8)) → (church8 → church8))))))) :=
  fun _ _ _ _ f => f
#print axioms ChurchCorpus.church_case_145

-- Church.hs:828 turn (total)
def ChurchCorpus.church_case_146 : (∀ (church0 : Type _), ((∀ (church2 : Type _), (((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (church4 → church4)) → (church4 → church4))))) :=
  fun _ f => f
#print axioms ChurchCorpus.church_case_146

-- Church.hs:832 unturn (total)
def ChurchCorpus.church_case_147 : (∀ (church0 : Type _), ((∀ (church2 : Type _), (((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (church4 → church4)) → (church4 → church4))))) :=
  fun _ f => f
#print axioms ChurchCorpus.church_case_147

-- Church.hs:840 subsequences (total)
def ChurchCorpus.church_case_148 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (church3 → church3)) → (church3 → church3))))) :=
  fun _ f _ g => g f
#print axioms ChurchCorpus.church_case_148

-- Church.hs:845 permutations (total)
def ChurchCorpus.church_case_149 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (church3 → church3)) → (church3 → church3))))) :=
  fun _ f _ g => g f
#print axioms ChurchCorpus.church_case_149

-- Church.hs:855 on (total)
def ChurchCorpus.church_case_150 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church0 → church1)) → ((church2 → church0) → (church2 → (church2 → church1))))) :=
  fun _ _ _ f g x y => f (g x) (g y)
#print axioms ChurchCorpus.church_case_150

-- Church.hs:859 nubBy (total)
def ChurchCorpus.church_case_151 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y; f2 _ y y) z) x
#print axioms ChurchCorpus.church_case_151

-- Church.hs:863 nubOn (total)
def ChurchCorpus.church_case_152 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((church1 → church0) → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))))))) :=
  fun _ _ f g h _ f1 x => h _ (fun y z => f1 (let f2 := f (g y); let f3 := f2 (g y); f3 _ y y) z) x
#print axioms ChurchCorpus.church_case_152

-- Church.hs:867 deleteBy (total)
def ChurchCorpus.church_case_153 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (church0 → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))))))) :=
  fun _ f x g _ h y => g _ h (let f1 := f x; let f2 := f1 x; f2 _ y y)
#print axioms ChurchCorpus.church_case_153

-- Church.hs:871 deleteFirstsBy (total)
def ChurchCorpus.church_case_154 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))))))) :=
  fun _ f g h _ f1 x => h _ f1 (g _ (fun y z => let f2 := f y; let f3 := f2 y; f3 _ z x) x)
#print axioms ChurchCorpus.church_case_154

-- Church.hs:876 unionBy (total)
def ChurchCorpus.church_case_155 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))))))) :=
  fun _ f g h _ f1 x => h _ f1 (g _ (fun y z => let f2 := f y; let f3 := f2 y; f3 _ z x) x)
#print axioms ChurchCorpus.church_case_155

-- Church.hs:880 intersectBy (total)
def ChurchCorpus.church_case_156 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))))))) :=
  fun _ f g h _ f1 x => h _ f1 (g _ (fun y z => let f2 := f y; let f3 := f2 y; f3 _ z x) x)
#print axioms ChurchCorpus.church_case_156

-- Church.hs:885 groupBy (total)
def ChurchCorpus.church_case_157 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (church4 → church4)) → (church4 → church4)))))) :=
  fun _ f g _ h x => g _ (fun y z => let f1 := f y; let f2 := f1 y; f2 _ z (h g x)) x
#print axioms ChurchCorpus.church_case_157

-- Church.hs:891 groupOn (total)
def ChurchCorpus.church_case_158 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((church1 → church0) → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church5 : Type _), (((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (church5 → church5)) → (church5 → church5))))))) :=
  fun _ _ f g h _ f1 x => h _ (fun y z => let f2 := f (g y); let f3 := f2 (g y); f3 _ z (f1 h x)) x
#print axioms ChurchCorpus.church_case_158

-- Church.hs:897 gatherBy (total)
def ChurchCorpus.church_case_159 : (∀ (church0 : Type _) (church1 : Type _), ((church1 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((church0 → church1) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))) → (church5 → church5)) → (church5 → church5))))))) :=
  fun _ _ f g h _ f1 x => h _ (fun y z => let f2 := f (g y); let f3 := f2 (g y); f3 _ z (f1 h x)) x
#print axioms ChurchCorpus.church_case_159

-- Church.hs:902 gather (total)
def ChurchCorpus.church_case_160 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (church4 → church4)) → (church4 → church4)))))) :=
  fun _ f g _ h x => g _ (fun y z => let f1 := f y; let f2 := f1 y; f2 _ z (h g x)) x
#print axioms ChurchCorpus.church_case_160

-- Church.hs:907 countsBy (total)
def ChurchCorpus.church_case_161 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (Int → church3)) → church3)) → (church4 → church4)) → (church4 → church4)))))) :=
  fun _ f g _ h x => g _ (fun y z => let f1 := f y; let f2 := f1 y; f2 _ (h (fun _ f3 => f3 y (.negSucc (.zero))) z) z) x
#print axioms ChurchCorpus.church_case_161

-- Church.hs:911 countsByKey (total)
def ChurchCorpus.church_case_162 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((church1 → church0) → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (Int → church4)) → church4)) → (church5 → church5)) → (church5 → church5))))))) :=
  fun _ _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_162

-- Church.hs:916 tallyBy (total)
def ChurchCorpus.church_case_163 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (Int → church3)) → church3)) → (church4 → church4)) → (church4 → church4)))))) :=
  fun _ f g _ h x => g _ (fun y z => let f1 := f y; let f2 := f1 y; f2 _ (h (fun _ f3 => f3 y (.negSucc (.zero))) z) z) x
#print axioms ChurchCorpus.church_case_163

-- Church.hs:920 countDistinctBy (needs_int_provider)
def ChurchCorpus.church_case_164 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → Int))) :=
  fun _ f g => .ofNat (g _ (fun x y => match y with | .zero => (let h := f x; let f1 := h x; f1 _ y y) | .succ z => z) (.zero))
#print axioms ChurchCorpus.church_case_164

-- Church.hs:925 positionIndexBy (total)
def ChurchCorpus.church_case_165 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → ((∀ (church3 : Type _), ((Int → (church3 → church3)) → (church3 → church3))) → church4)) → church4)) → (church5 → church5)) → (church5 → church5)))))) :=
  fun _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_165

-- Church.hs:933 pick (total)
def ChurchCorpus.church_case_166 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church3 : Type _), (((∀ (church2 : Type _), (church2 → (church2 → church2))) → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))) → ((∀ (church5 : Type _), ((church1 → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → church6) → ((church1 → church6) → church6))) → (church7 → church7)) → (church7 → church7))))))) :=
  fun _ _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_166

-- Church.hs:938 pick' (total)
def ChurchCorpus.church_case_167 : (∀ (church0 : Type _), ((∀ (church2 : Type _), (((∀ (church1 : Type _), (church1 → (church1 → church1))) → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), ((church0 → (church5 → church5)) → (church5 → church5))))))) :=
  fun _ f g h _ f1 x => h _ f1 (f _ (fun f2 y => f2 _ y (g _ f1 x)) x)
#print axioms ChurchCorpus.church_case_167

-- Church.hs:949 isSubstring (total)
def ChurchCorpus.church_case_168 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → (church5 → church5))))))) :=
  fun _ _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_168

-- Church.hs:957 isSubseq (total)
def ChurchCorpus.church_case_169 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → (church5 → church5))))))) :=
  fun _ _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_169

-- Church.hs:965 isPrefixOf (total)
def ChurchCorpus.church_case_170 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → (church5 → church5))))))) :=
  fun _ _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_170

-- Church.hs:971 break (total)
def ChurchCorpus.church_case_171 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church5 : Type _), (((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))) → church5)) → church5))))) :=
  fun _ f g _ h => g _ (fun x y => let f1 := f x; f1 _ y y) (h g g)
#print axioms ChurchCorpus.church_case_171

-- Church.hs:979 elemBy (total)
def ChurchCorpus.church_case_172 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church0 → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), (church4 → (church4 → church4))))))) :=
  fun _ _ f x g _ y z => g _ (fun w x1 => let h := f x; let f1 := h w; f1 _ z x1) y
#print axioms ChurchCorpus.church_case_172

-- Church.hs:989 findIndex (total)
def ChurchCorpus.church_case_173 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), (church3 → ((Int → church3) → church3)))))) :=
  fun _ f g _ x h => g _ (fun y z => let f1 := f y; f1 _ z (h (.negSucc (.zero)))) x
#print axioms ChurchCorpus.church_case_173

-- Church.hs:993 findIndices (total)
def ChurchCorpus.church_case_174 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((Int → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => let f1 := f y; f1 _ z (h (.negSucc (.zero)) z)) x
#print axioms ChurchCorpus.church_case_174

-- Church.hs:997 elemIndex (total)
def ChurchCorpus.church_case_175 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church0 → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), (church4 → ((Int → church4) → church4))))))) :=
  fun _ _ f x g _ y h => g _ (fun z w => let f1 := f x; let f2 := f1 z; f2 _ w (h (.negSucc (.zero)))) y
#print axioms ChurchCorpus.church_case_175

-- Church.hs:1005 isSuffixOf (total)
def ChurchCorpus.church_case_176 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → (church5 → church5))))))) :=
  fun _ _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_176

-- Church.hs:1010 maximumBy (requires_partiality)
def ChurchCorpus.church_case_177 : (∀ (church0 : Type _), (church0 → ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → church0)))) :=
  fun _ x f g => g _ (fun y z => let h := f y; let f1 := h z; f1 _ x z) x
#print axioms ChurchCorpus.church_case_177

-- Church.hs:1015 maximumOn (requires_partiality)
def ChurchCorpus.church_case_178 : (∀ (church0 : Type _) (church1 : Type _), (church1 → ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((church1 → church0) → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → church1))))) :=
  fun _ _ x f g h => h _ (fun y z => let f1 := f (g z); let f2 := f1 (g y); f2 _ z y) x
#print axioms ChurchCorpus.church_case_178

-- Church.hs:1020 minimumBy (requires_partiality)
def ChurchCorpus.church_case_179 : (∀ (church0 : Type _), (church0 → ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → church0)))) :=
  fun _ x f g => g _ (fun y z => let h := f y; let f1 := h z; f1 _ x z) x
#print axioms ChurchCorpus.church_case_179

-- Church.hs:1025 minimumOn (requires_partiality)
def ChurchCorpus.church_case_180 : (∀ (church0 : Type _) (church1 : Type _), (church1 → ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((church1 → church0) → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → church1))))) :=
  fun _ _ x f g h => h _ (fun y z => let f1 := f (g z); let f2 := f1 (g y); f2 _ z y) x
#print axioms ChurchCorpus.church_case_180

-- Church.hs:1030 minMaxBy (requires_partiality)
def ChurchCorpus.church_case_181 : (∀ (church0 : Type _), (church0 → ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church0 → church3)) → church3)))))) :=
  fun _ x f g _ h => h x (g _ (fun y z => let f1 := f y; let f2 := f1 z; f2 _ z x) x)
#print axioms ChurchCorpus.church_case_181

-- Church.hs:1034 deleteDuplicatesBy (total)
def ChurchCorpus.church_case_182 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y; f2 _ y y) z) x
#print axioms ChurchCorpus.church_case_182

-- Church.hs:1038 complementBy (total)
def ChurchCorpus.church_case_183 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), ((church0 → (church5 → church5)) → (church5 → church5))))))) :=
  fun _ _ f g h _ f1 x => g _ (fun y z => f1 (h _ (fun w x1 => let f2 := f x1; let f3 := f2 w; f3 _ x1 y) y) z) x
#print axioms ChurchCorpus.church_case_183

-- Church.hs:1042 containsAllBy (total)
def ChurchCorpus.church_case_184 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → (church5 → church5))))))) :=
  fun _ _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_184

-- Church.hs:1046 containsAnyBy (total)
def ChurchCorpus.church_case_185 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → (church5 → church5))))))) :=
  fun _ _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_185

-- Church.hs:1050 containsNoneBy (total)
def ChurchCorpus.church_case_186 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → (church5 → church5))))))) :=
  fun _ _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_186

-- Church.hs:1054 containsOnlyBy (total)
def ChurchCorpus.church_case_187 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → (church5 → church5))))))) :=
  fun _ _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_187

-- Church.hs:1062 partition3 (total)
def ChurchCorpus.church_case_188 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church0 → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (((∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))) → ((∀ (church5 : Type _), ((church0 → (church5 → church5)) → (church5 → church5))) → ((∀ (church6 : Type _), ((church0 → (church6 → church6)) → (church6 → church6))) → church1))) → church1))))) :=
  fun _ _ f x g h => h g (fun _ f1 y => f1 (let f2 := f x; let f3 := f2 x; f3 _ x x) y) g
#print axioms ChurchCorpus.church_case_188

-- Church.hs:1067 quickStep (total)
def ChurchCorpus.church_case_189 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))) → ((∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), ((church0 → (church5 → church5)) → (church5 → church5))))))) :=
  fun _ f g h _ z0 z1 => g (fun _ f1 x => h _ (fun y z => f1 (let f2 := f y; let f3 := f2 y; f3 _ y y) z) x) _ z0 z1
#print axioms ChurchCorpus.church_case_189

-- Church.hs:1074 mergesort (total)
def ChurchCorpus.church_case_190 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y; f2 _ y y) z) x
#print axioms ChurchCorpus.church_case_190

-- Church.hs:1081 sortOn (total)
def ChurchCorpus.church_case_191 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((church1 → church0) → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))))))) :=
  fun _ _ f g h _ f1 x => h _ (fun y z => f1 (let f2 := f (g y); let f3 := f2 (g y); f3 _ y y) z) x
#print axioms ChurchCorpus.church_case_191

-- Church.hs:1087 quicksort (total)
def ChurchCorpus.church_case_192 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y; f2 _ y y) z) x
#print axioms ChurchCorpus.church_case_192

-- Church.hs:1092 heapsort (total)
def ChurchCorpus.church_case_193 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y; f2 _ y y) z) x
#print axioms ChurchCorpus.church_case_193

-- Church.hs:1097 introsort (total)
def ChurchCorpus.church_case_194 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y; f2 _ y y) z) x
#print axioms ChurchCorpus.church_case_194

-- Church.hs:1107 nthElement (total)
def ChurchCorpus.church_case_195 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (Int → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))))))) :=
  fun _ _ x f => match x with | .ofNat y => (match y with | .zero => f | .succ _ => f) | .negSucc z => (match z with | .zero => f | .succ _ => f)
#print axioms ChurchCorpus.church_case_195

-- Church.hs:1112 nthElement' (total)
def ChurchCorpus.church_case_196 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (Int → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))))))) :=
  fun _ _ x f => match x with | .ofNat y => (match y with | .zero => f | .succ _ => f) | .negSucc z => (match z with | .zero => f | .succ _ => f)
#print axioms ChurchCorpus.church_case_196

-- Church.hs:1139 longestCommonPrefix (total)
def ChurchCorpus.church_case_197 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))))))) :=
  fun _ f g h _ f1 x => h _ f1 (g _ (fun y z => let f2 := f y; let f3 := f2 y; f3 _ z x) x)
#print axioms ChurchCorpus.church_case_197

-- Church.hs:1143 longestCommonSuffix (total)
def ChurchCorpus.church_case_198 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))))))) :=
  fun _ f g h _ f1 x => h _ f1 (g _ (fun y z => let f2 := f y; let f3 := f2 y; f3 _ z x) x)
#print axioms ChurchCorpus.church_case_198

-- Church.hs:1149 longestCommonSublist (total)
def ChurchCorpus.church_case_199 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))))))) :=
  fun _ f g h _ f1 x => h _ f1 (g _ (fun y z => let f2 := f y; let f3 := f2 y; f3 _ z x) x)
#print axioms ChurchCorpus.church_case_199

-- Church.hs:1161 none (total)
def ChurchCorpus.church_case_200 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), (church3 → (church3 → church3)))))) :=
  fun _ f g _ x y => g _ (fun z w => let h := f z; h _ y w) x
#print axioms ChurchCorpus.church_case_200

-- Church.hs:1165 findIf (total)
def ChurchCorpus.church_case_201 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), (church3 → ((church0 → church3) → church3)))))) :=
  fun _ f g _ x h => g _ (fun y z => let f1 := f y; f1 _ z (h y)) x
#print axioms ChurchCorpus.church_case_201

-- Church.hs:1169 findIfNot (total)
def ChurchCorpus.church_case_202 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), (church3 → ((church0 → church3) → church3)))))) :=
  fun _ f g _ x h => g _ (fun y z => let f1 := f y; f1 _ z (h y)) x
#print axioms ChurchCorpus.church_case_202

-- Church.hs:1173 find (total)
def ChurchCorpus.church_case_203 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church1 → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), (church4 → ((church0 → church4) → church4))))))) :=
  fun _ _ f x g _ y h => g _ (fun z w => let f1 := f z; let f2 := f1 x; f2 _ w (h z)) y
#print axioms ChurchCorpus.church_case_203

-- Church.hs:1177 findLast (total)
def ChurchCorpus.church_case_204 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), (church3 → ((church0 → church3) → church3)))))) :=
  fun _ f g _ x h => g _ (fun y z => let f1 := f y; f1 _ z (h y)) x
#print axioms ChurchCorpus.church_case_204

-- Church.hs:1181 countIf (needs_int_provider)
def ChurchCorpus.church_case_205 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → Int))) :=
  fun _ f g => .negSucc (g _ (fun x y => match y with | .zero => (let h := f x; h _ y y) | .succ z => z) (.zero))
#print axioms ChurchCorpus.church_case_205

-- Church.hs:1185 count (needs_int_provider)
def ChurchCorpus.church_case_206 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church1 → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → Int)))) :=
  fun _ _ f x g => .negSucc (g _ (fun y z => match z with | .zero => (let h := f y; let f1 := h x; f1 _ z z) | .succ w => w) (.zero))
#print axioms ChurchCorpus.church_case_206

-- Church.hs:1190 mismatch (total)
def ChurchCorpus.church_case_207 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (church6 → (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → church6) → church6))))))) :=
  fun _ _ f g h _ x f1 => g _ (fun y z => h _ (fun w x1 => let f2 := f y; let f3 := f2 w; f3 _ x1 (f1 (fun _ f4 => f4 y w))) z) x
#print axioms ChurchCorpus.church_case_207

-- Church.hs:1195 adjacentFind (total)
def ChurchCorpus.church_case_208 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), (church3 → ((church0 → church3) → church3)))))) :=
  fun _ f g _ x h => g _ (fun y z => let f1 := f y; let f2 := f1 y; f2 _ z (h y)) x
#print axioms ChurchCorpus.church_case_208

-- Church.hs:1201 search (total)
def ChurchCorpus.church_case_209 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → ((Int → church5) → church5))))))) :=
  fun _ _ f g h _ x f1 => g _ (fun y z => h _ (fun w x1 => let f2 := f y; let f3 := f2 w; f3 _ x1 (f1 (.negSucc (.zero)))) z) x
#print axioms ChurchCorpus.church_case_209

-- Church.hs:1205 findEnd (total)
def ChurchCorpus.church_case_210 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → ((Int → church5) → church5))))))) :=
  fun _ _ f g h _ x f1 => g _ (fun y z => h _ (fun w x1 => let f2 := f y; let f3 := f2 w; f3 _ x1 (f1 (.negSucc (.zero)))) z) x
#print axioms ChurchCorpus.church_case_210

-- Church.hs:1210 findFirstOf (total)
def ChurchCorpus.church_case_211 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → ((church0 → church5) → church5))))))) :=
  fun _ _ f g h _ x f1 => g _ (fun y z => h _ (fun w x1 => let f2 := f y; let f3 := f2 w; f3 _ x1 (f1 y)) z) x
#print axioms ChurchCorpus.church_case_211

-- Church.hs:1215 searchN (total)
def ChurchCorpus.church_case_212 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (Int → (church1 → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), (church4 → ((Int → church4) → church4)))))))) :=
  fun _ _ f x y g _ z h => g _ (fun w x1 => let f1 := f w; let f2 := f1 y; f2 _ x1 z) (h x)
#print axioms ChurchCorpus.church_case_212

-- Church.hs:1228 rotate (total)
def ChurchCorpus.church_case_213 : (∀ (church0 : Type _), (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2)))))) :=
  fun _ x f => match x with | .ofNat y => (match y with | .zero => f | .succ _ => f) | .negSucc z => (match z with | .zero => f | .succ _ => f)
#print axioms ChurchCorpus.church_case_213

-- Church.hs:1232 removeIf (total)
def ChurchCorpus.church_case_214 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h y (let f1 := f y; f1 _ z x)) x
#print axioms ChurchCorpus.church_case_214

-- Church.hs:1236 remove (total)
def ChurchCorpus.church_case_215 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church1 → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))))))) :=
  fun _ _ f x g _ h y => g _ (fun z w => h (let f1 := f z; let f2 := f1 x; f2 _ z z) w) y
#print axioms ChurchCorpus.church_case_215

-- Church.hs:1240 replaceIf (total)
def ChurchCorpus.church_case_216 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → (church0 → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))))))) :=
  fun _ f x g _ h y => h x (g _ h (let f1 := f x; f1 _ y y))
#print axioms ChurchCorpus.church_case_216

-- Church.hs:1244 replace (total)
def ChurchCorpus.church_case_217 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (church0 → (church0 → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))))) :=
  fun _ f x y g _ h z => g _ h (let f1 := f y; let f2 := f1 x; f2 _ z z)
#print axioms ChurchCorpus.church_case_217

-- Church.hs:1249 uniqueBy (total)
def ChurchCorpus.church_case_218 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y; f2 _ y y) z) x
#print axioms ChurchCorpus.church_case_218

-- Church.hs:1258 isPartitioned (total)
def ChurchCorpus.church_case_219 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), (church3 → (church3 → church3)))))) :=
  fun _ f g _ x y => g _ (fun z w => let h := f z; h _ y w) x
#print axioms ChurchCorpus.church_case_219

-- Church.hs:1263 partitionPoint (needs_int_provider)
def ChurchCorpus.church_case_220 : (∀ (church0 : Type _), ((church0 → (∀ (church1 : Type _), (church1 → (church1 → church1)))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → Int))) :=
  fun _ f g => .negSucc (g _ (fun x y => match y with | .zero => (let h := f x; h _ y y) | .succ z => z) (.zero))
#print axioms ChurchCorpus.church_case_220

-- Church.hs:1267 isSorted (total)
def ChurchCorpus.church_case_221 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), (church3 → (church3 → church3)))))) :=
  fun _ f g _ x y => g _ (fun z w => let h := f z; let f1 := h z; f1 _ y w) x
#print axioms ChurchCorpus.church_case_221

-- Church.hs:1272 isSortedUntil (needs_int_provider)
def ChurchCorpus.church_case_222 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → Int))) :=
  fun _ f g => .ofNat (g _ (fun x y => match y with | .zero => (let h := f x; let f1 := h x; f1 _ y y) | .succ z => z) (.zero))
#print axioms ChurchCorpus.church_case_222

-- Church.hs:1284 lowerBound (needs_int_provider)
def ChurchCorpus.church_case_223 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (church0 → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → Int)))) :=
  fun _ _ _ _ => .negSucc (.zero)
#print axioms ChurchCorpus.church_case_223

-- Church.hs:1289 upperBound (needs_int_provider)
def ChurchCorpus.church_case_224 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (church0 → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → Int)))) :=
  fun _ _ _ _ => .negSucc (.zero)
#print axioms ChurchCorpus.church_case_224

-- Church.hs:1294 binarySearch (total)
def ChurchCorpus.church_case_225 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (church0 → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), (church3 → (church3 → church3))))))) :=
  fun _ f x g _ z0 z1 => f x (g _ (fun y z => let h := f y; let f1 := h z; f1 _ z y) x) _ z0 z1
#print axioms ChurchCorpus.church_case_225

-- Church.hs:1299 equalRange (needs_int_provider)
def ChurchCorpus.church_case_226 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (church0 → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((Int → (Int → church3)) → church3)))))) :=
  fun _ _ _ _ _ f => f (.negSucc (.zero)) (.negSucc (.zero))
#print axioms ChurchCorpus.church_case_226

-- Church.hs:1308 mergeBy (total)
def ChurchCorpus.church_case_227 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))))))) :=
  fun _ f g h _ f1 x => h _ f1 (g _ (fun y z => let f2 := f y; let f3 := f2 y; f3 _ z x) x)
#print axioms ChurchCorpus.church_case_227

-- Church.hs:1313 includes (total)
def ChurchCorpus.church_case_228 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), (church4 → (church4 → church4))))))) :=
  fun _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_228

-- Church.hs:1322 setOp (total)
def ChurchCorpus.church_case_229 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), (church2 → (church2 → church2))) → ((∀ (church3 : Type _), (church3 → (church3 → church3))) → ((∀ (church4 : Type _), (church4 → (church4 → church4))) → ((∀ (church5 : Type _), (church5 → (church5 → church5))) → ((∀ (church6 : Type _), ((church0 → (church6 → church6)) → (church6 → church6))) → ((∀ (church7 : Type _), ((church0 → (church7 → church7)) → (church7 → church7))) → (∀ (church8 : Type _), ((church0 → (church8 → church8)) → (church8 → church8))))))))))) :=
  fun _ _ _ _ _ _ f _ => f
#print axioms ChurchCorpus.church_case_229

-- Church.hs:1336 setUnion (total)
def ChurchCorpus.church_case_230 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))))))) :=
  fun _ f g h _ f1 x => h _ f1 (g _ (fun y z => let f2 := f y; let f3 := f2 y; f3 _ z x) x)
#print axioms ChurchCorpus.church_case_230

-- Church.hs:1341 setIntersection (total)
def ChurchCorpus.church_case_231 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))))))) :=
  fun _ f g h _ f1 x => h _ f1 (g _ (fun y z => let f2 := f y; let f3 := f2 y; f3 _ z x) x)
#print axioms ChurchCorpus.church_case_231

-- Church.hs:1346 setDifference (total)
def ChurchCorpus.church_case_232 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))))))) :=
  fun _ f g h _ f1 x => h _ f1 (g _ (fun y z => let f2 := f y; let f3 := f2 y; f3 _ z x) x)
#print axioms ChurchCorpus.church_case_232

-- Church.hs:1351 setSymmetricDifference (total)
def ChurchCorpus.church_case_233 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))))))) :=
  fun _ f g h _ f1 x => h _ f1 (g _ (fun y z => let f2 := f y; let f3 := f2 y; f3 _ z x) x)
#print axioms ChurchCorpus.church_case_233

-- Church.hs:1359 maxBy (total)
def ChurchCorpus.church_case_234 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (church0 → (church0 → church0)))) :=
  fun _ f x y => let g := f x; let h := g y; h _ x x
#print axioms ChurchCorpus.church_case_234

-- Church.hs:1363 minBy (total)
def ChurchCorpus.church_case_235 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (church0 → (church0 → church0)))) :=
  fun _ f x y => let g := f x; let h := g y; h _ x x
#print axioms ChurchCorpus.church_case_235

-- Church.hs:1368 minmaxBy (total)
def ChurchCorpus.church_case_236 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (church0 → (church0 → (∀ (church2 : Type _), ((church0 → (church0 → church2)) → church2)))))) :=
  fun _ f x y _ g => g x (let h := f y; let f1 := h x; f1 _ y y)
#print axioms ChurchCorpus.church_case_236

-- Church.hs:1372 clamp (total)
def ChurchCorpus.church_case_237 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (church0 → (church0 → (church0 → church0))))) :=
  fun _ f x y z => let g := f x; let h := g y; h _ z x
#print axioms ChurchCorpus.church_case_237

-- Church.hs:1377 minmaxElement (requires_partiality)
def ChurchCorpus.church_case_238 : (∀ (church0 : Type _), (church0 → ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church0 → church3)) → church3)))))) :=
  fun _ x f g _ h => h x (g _ (fun y z => let f1 := f y; let f2 := f1 z; f2 _ z x) x)
#print axioms ChurchCorpus.church_case_238

-- Church.hs:1382 equalBy (total)
def ChurchCorpus.church_case_239 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → (church5 → church5))))))) :=
  fun _ _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_239

-- Church.hs:1387 lexicographicalLess (total)
def ChurchCorpus.church_case_240 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), (church4 → (church4 → church4))))))) :=
  fun _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_240

-- Church.hs:1393 compareBy (needs_int_provider)
def ChurchCorpus.church_case_241 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → Int)))) :=
  fun _ _ _ _ => .negSucc (.zero)
#print axioms ChurchCorpus.church_case_241

-- Church.hs:1402 isPermutation (total)
def ChurchCorpus.church_case_242 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), (church4 → (church4 → church4))))))) :=
  fun _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_242

-- Church.hs:1408 nextPermutation (total)
def ChurchCorpus.church_case_243 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (church4 → (((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → church4) → church4)))))) :=
  fun _ f g _ x h => g _ (fun y z => let f1 := f y; let f2 := f1 y; f2 _ z (h g)) x
#print axioms ChurchCorpus.church_case_243

-- Church.hs:1418 prevPermutation (total)
def ChurchCorpus.church_case_244 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (church4 → (((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → church4) → church4)))))) :=
  fun _ f g _ x h => g _ (fun y z => let f1 := f y; let f2 := f1 y; f2 _ z (h g)) x
#print axioms ChurchCorpus.church_case_244

-- Church.hs:1432 member (total)
def ChurchCorpus.church_case_245 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → (church1 → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church2 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church6 : Type _), (church6 → (church6 → church6))))))) :=
  fun _ _ _ _ _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_245

-- Church.hs:1436 notMember (total)
def ChurchCorpus.church_case_246 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → (church1 → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church2 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church6 : Type _), (church6 → (church6 → church6))))))) :=
  fun _ _ _ _ _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_246

-- Church.hs:1440 findWithDefault (total)
def ChurchCorpus.church_case_247 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), (church0 → ((church1 → (church2 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → (church2 → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church1 → (church0 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → church0))))) :=
  fun _ _ _ x f y g => g _ (fun h z => h _ (fun w x1 => let f1 := f w; let f2 := f1 y; f2 _ z x1)) x
#print axioms ChurchCorpus.church_case_247

-- Church.hs:1444 atKey (requires_partiality)
def ChurchCorpus.church_case_248 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), (church2 → ((church0 → (church1 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → (church1 → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church2 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → church2))))) :=
  fun _ _ _ x f y g => g _ (fun h z => h _ (fun w x1 => let f1 := f w; let f2 := f1 y; f2 _ z x1)) x
#print axioms ChurchCorpus.church_case_248

-- Church.hs:1448 keys (total)
def ChurchCorpus.church_case_249 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church1 → church2)) → church2)) → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))))) :=
  fun _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_249

-- Church.hs:1452 values (total)
def ChurchCorpus.church_case_250 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church1 → church2)) → church2)) → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))))) :=
  fun _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_250

-- Church.hs:1456 elems (total)
def ChurchCorpus.church_case_251 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church1 → church2)) → church2)) → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))))) :=
  fun _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_251

-- Church.hs:1460 sizeDict (needs_int_provider)
def ChurchCorpus.church_case_252 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church1 → church2)) → church2)) → (church3 → church3)) → (church3 → church3))) → Int)) :=
  fun _ _ _ => .negSucc (.zero)
#print axioms ChurchCorpus.church_case_252

-- Church.hs:1464 nullDict (total)
def ChurchCorpus.church_case_253 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church1 → church2)) → church2)) → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), (church4 → (church4 → church4))))) :=
  fun _ _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_253

-- Church.hs:1468 singletonDict (total)
def ChurchCorpus.church_case_254 : (∀ (church0 : Type _) (church1 : Type _), (church0 → (church1 → (∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church1 → church2)) → church2)) → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ _ x y _ f => f (fun _ g => g x y)
#print axioms ChurchCorpus.church_case_254

-- Church.hs:1472 lookupAll (total)
def ChurchCorpus.church_case_255 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → (church1 → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church2 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church6 : Type _), ((church2 → (church6 → church6)) → (church6 → church6))))))) :=
  fun _ _ _ f x g _ h y => g _ (fun f1 z => h (f1 _ (fun w x1 => let f2 := f w; let f3 := f2 x; f3 _ x1 x1)) z) y
#print axioms ChurchCorpus.church_case_255

-- Church.hs:1477 countKey (needs_int_provider)
def ChurchCorpus.church_case_256 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → (church1 → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church2 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → Int)))) :=
  fun _ _ _ _ _ _ => .negSucc (.zero)
#print axioms ChurchCorpus.church_case_256

-- Church.hs:1486 insert (total)
def ChurchCorpus.church_case_257 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church0 → (church1 → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6)))))))) :=
  fun _ _ f x y g _ h z => h (fun _ f1 => f1 (let f2 := f x; let f3 := f2 x; f3 _ x x) y) (g _ h z)
#print axioms ChurchCorpus.church_case_257

-- Church.hs:1493 insertWith (total)
def ChurchCorpus.church_case_258 : (∀ (church0 : Type _) (church1 : Type _), ((church1 → (church1 → church1)) → ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church0 → (church1 → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))))))))) :=
  fun _ _ _ _ _ _ f => f
#print axioms ChurchCorpus.church_case_258

-- Church.hs:1505 fromList (total)
def ChurchCorpus.church_case_259 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6)))))) :=
  fun _ _ f g _ h x => g _ (fun f1 y => h (fun _ f2 => f1 _ (fun z w => f2 (let f3 := f z; let f4 := f3 z; f4 _ z z) w)) y) x
#print axioms ChurchCorpus.church_case_259

-- Church.hs:1510 fromListWith (total)
def ChurchCorpus.church_case_260 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → church0)) → ((church1 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church1 → (church0 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church1 → (church0 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))))))) :=
  fun _ _ f g h _ f1 x => h _ (fun f2 y => f1 (fun _ f3 => f2 _ (fun z w => f3 z (f (let f4 := g z; let f5 := f4 z; f5 _ w w) w))) y) x
#print axioms ChurchCorpus.church_case_260

-- Church.hs:1515 adjust (total)
def ChurchCorpus.church_case_261 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((church1 → church1) → (church0 → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6)))))))) :=
  fun _ _ _ _ _ f => f
#print axioms ChurchCorpus.church_case_261

-- Church.hs:1521 alter (total)
def ChurchCorpus.church_case_262 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (((∀ (church3 : Type _), (church3 → ((church1 → church3) → church3))) → (∀ (church4 : Type _), (church4 → ((church1 → church4) → church4)))) → (church0 → ((∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))) → (∀ (church8 : Type _), (((∀ (church7 : Type _), ((church0 → (church1 → church7)) → church7)) → (church8 → church8)) → (church8 → church8)))))))) :=
  fun _ _ _ _ _ f => f
#print axioms ChurchCorpus.church_case_262

-- Church.hs:1528 mapWithKey (total)
def ChurchCorpus.church_case_263 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → church2)) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church2 → church5)) → church5)) → (church6 → church6)) → (church6 → church6)))))) :=
  fun _ _ _ f g _ h => g _ (fun f1 => h (fun _ f2 => f1 _ (fun x y => f2 x (f x y))))
#print axioms ChurchCorpus.church_case_263

-- Church.hs:1533 mapMaybeWithKey (total)
def ChurchCorpus.church_case_264 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (∀ (church3 : Type _), (church3 → ((church2 → church3) → church3))))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church2 → church6)) → church6)) → (church7 → church7)) → (church7 → church7)))))) :=
  fun _ _ _ f g _ h x => g _ (fun f1 y => f1 _ (fun z w => let f2 := f z; let f3 := f2 w; f3 _ y (fun x1 => h (fun _ f4 => f4 z x1) x))) x
#print axioms ChurchCorpus.church_case_264

-- Church.hs:1539 mapKeysWith (total)
def ChurchCorpus.church_case_265 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church0 → church0)) → ((church1 → (church1 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → ((church2 → church1) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church2 → (church0 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church1 → (church0 → church6)) → church6)) → (church7 → church7)) → (church7 → church7)))))))) :=
  fun _ _ _ _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_265

-- Church.hs:1543 update (total)
def ChurchCorpus.church_case_266 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((church1 → (∀ (church3 : Type _), (church3 → ((church1 → church3) → church3)))) → (church0 → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church1 → church6)) → church6)) → (church7 → church7)) → (church7 → church7)))))))) :=
  fun _ _ _ _ _ f => f
#print axioms ChurchCorpus.church_case_266

-- Church.hs:1548 updateWithKey (total)
def ChurchCorpus.church_case_267 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((church0 → (church1 → (∀ (church3 : Type _), (church3 → ((church1 → church3) → church3))))) → (church0 → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church1 → church6)) → church6)) → (church7 → church7)) → (church7 → church7)))))))) :=
  fun _ _ _ _ _ f => f
#print axioms ChurchCorpus.church_case_267

-- Church.hs:1557 filterWithKey (total)
def ChurchCorpus.church_case_268 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6)))))) :=
  fun _ _ f g _ h x => g _ (fun f1 y => f1 _ (fun z w => let f2 := f z; let f3 := f2 w; f3 _ y (h f1 x))) x
#print axioms ChurchCorpus.church_case_268

-- Church.hs:1561 filterValues (total)
def ChurchCorpus.church_case_269 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (∀ (church2 : Type _), (church2 → (church2 → church2)))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church1 → (church0 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church1 → (church0 → church5)) → church5)) → (church6 → church6)) → (church6 → church6)))))) :=
  fun _ _ f g _ h x => g _ (fun f1 y => h (fun _ f2 => f1 _ (fun z w => f2 z (let f3 := f w; f3 _ w w))) y) x
#print axioms ChurchCorpus.church_case_269

-- Church.hs:1566 partitionDict (total)
def ChurchCorpus.church_case_270 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church9 : Type _), (((∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))) → ((∀ (church8 : Type _), (((∀ (church7 : Type _), ((church0 → (church1 → church7)) → church7)) → (church8 → church8)) → (church8 → church8))) → church9)) → church9))))) :=
  fun _ _ f g _ h => g _ (fun f1 x => f1 _ (fun y z => let f2 := f y; let f3 := f2 z; f3 _ x x)) (h g g)
#print axioms ChurchCorpus.church_case_270

-- Church.hs:1573 unionWith (total)
def ChurchCorpus.church_case_271 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → church0)) → ((church1 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church1 → (church0 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → ((∀ (church6 : Type _), (((∀ (church5 : Type _), ((church1 → (church0 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))) → (∀ (church8 : Type _), (((∀ (church7 : Type _), ((church1 → (church0 → church7)) → church7)) → (church8 → church8)) → (church8 → church8)))))))) :=
  fun _ _ _ _ f _ => f
#print axioms ChurchCorpus.church_case_271

-- Church.hs:1578 unionWithKey (total)
def ChurchCorpus.church_case_272 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (church1 → church1))) → ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → ((∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))) → (∀ (church8 : Type _), (((∀ (church7 : Type _), ((church0 → (church1 → church7)) → church7)) → (church8 → church8)) → (church8 → church8)))))))) :=
  fun _ _ _ _ f _ => f
#print axioms ChurchCorpus.church_case_272

-- Church.hs:1583 union (total)
def ChurchCorpus.church_case_273 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → ((∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))) → (∀ (church8 : Type _), (((∀ (church7 : Type _), ((church0 → (church1 → church7)) → church7)) → (church8 → church8)) → (church8 → church8))))))) :=
  fun _ _ _ f _ => f
#print axioms ChurchCorpus.church_case_273

-- Church.hs:1588 unionsWith (total)
def ChurchCorpus.church_case_274 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → church0)) → ((church1 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church1 → (church0 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church1 → (church0 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))))))) :=
  fun _ _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_274

-- Church.hs:1593 unions (total)
def ChurchCorpus.church_case_275 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church1 → church6)) → church6)) → (church7 → church7)) → (church7 → church7)))))) :=
  fun _ _ f g _ h x => g _ (fun f1 y => f1 _ (fun f2 z => h (fun _ f3 => f2 _ (fun w x1 => f3 (let f4 := f w; let f5 := f4 w; f5 _ w w) x1)) z) y) x
#print axioms ChurchCorpus.church_case_275

-- Church.hs:1598 intersectionWith (total)
def ChurchCorpus.church_case_276 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _) (church3 : Type _), ((church0 → (church1 → church2)) → ((church3 → (church3 → (∀ (church4 : Type _), (church4 → (church4 → church4))))) → ((∀ (church6 : Type _), (((∀ (church5 : Type _), ((church3 → (church0 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))) → ((∀ (church8 : Type _), (((∀ (church7 : Type _), ((church3 → (church1 → church7)) → church7)) → (church8 → church8)) → (church8 → church8))) → (∀ (church10 : Type _), (((∀ (church9 : Type _), ((church3 → (church2 → church9)) → church9)) → (church10 → church10)) → (church10 → church10)))))))) :=
  fun _ _ _ _ _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_276

-- Church.hs:1603 intersectionWithKey (total)
def ChurchCorpus.church_case_277 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _) (church3 : Type _), ((church0 → (church1 → (church2 → church3))) → ((church0 → (church0 → (∀ (church4 : Type _), (church4 → (church4 → church4))))) → ((∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))) → ((∀ (church8 : Type _), (((∀ (church7 : Type _), ((church0 → (church2 → church7)) → church7)) → (church8 → church8)) → (church8 → church8))) → (∀ (church10 : Type _), (((∀ (church9 : Type _), ((church0 → (church3 → church9)) → church9)) → (church10 → church10)) → (church10 → church10)))))))) :=
  fun _ _ _ _ _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_277

-- Church.hs:1608 intersection (total)
def ChurchCorpus.church_case_278 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church0 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → ((∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church2 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))) → (∀ (church9 : Type _), (((∀ (church8 : Type _), ((church0 → (church1 → church8)) → church8)) → (church9 → church9)) → (church9 → church9))))))) :=
  fun _ _ _ _ f _ => f
#print axioms ChurchCorpus.church_case_278

-- Church.hs:1613 difference (total)
def ChurchCorpus.church_case_279 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church0 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → ((∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church2 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))) → (∀ (church9 : Type _), (((∀ (church8 : Type _), ((church0 → (church1 → church8)) → church8)) → (church9 → church9)) → (church9 → church9))))))) :=
  fun _ _ _ _ f _ => f
#print axioms ChurchCorpus.church_case_279

-- Church.hs:1618 differenceWith (total)
def ChurchCorpus.church_case_280 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (∀ (church3 : Type _), (church3 → ((church0 → church3) → church3))))) → ((church2 → (church2 → (∀ (church4 : Type _), (church4 → (church4 → church4))))) → ((∀ (church6 : Type _), (((∀ (church5 : Type _), ((church2 → (church0 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))) → ((∀ (church8 : Type _), (((∀ (church7 : Type _), ((church2 → (church1 → church7)) → church7)) → (church8 → church8)) → (church8 → church8))) → (∀ (church10 : Type _), (((∀ (church9 : Type _), ((church2 → (church0 → church9)) → church9)) → (church10 → church10)) → (church10 → church10)))))))) :=
  fun _ _ _ _ _ f _ => f
#print axioms ChurchCorpus.church_case_280

-- Church.hs:1623 differenceWithKey (total)
def ChurchCorpus.church_case_281 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (church2 → (∀ (church3 : Type _), (church3 → ((church1 → church3) → church3)))))) → ((church0 → (church0 → (∀ (church4 : Type _), (church4 → (church4 → church4))))) → ((∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))) → ((∀ (church8 : Type _), (((∀ (church7 : Type _), ((church0 → (church2 → church7)) → church7)) → (church8 → church8)) → (church8 → church8))) → (∀ (church10 : Type _), (((∀ (church9 : Type _), ((church0 → (church1 → church9)) → church9)) → (church10 → church10)) → (church10 → church10)))))))) :=
  fun _ _ _ _ _ f _ => f
#print axioms ChurchCorpus.church_case_281

-- Church.hs:1628 restrictKeys (total)
def ChurchCorpus.church_case_282 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → ((∀ (church5 : Type _), ((church0 → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church1 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))))))) :=
  fun _ _ f g h _ f1 x => g _ f1 (h _ (fun y z => let f2 := f y; let f3 := f2 y; f3 _ z x) x)
#print axioms ChurchCorpus.church_case_282

-- Church.hs:1632 withoutKeys (total)
def ChurchCorpus.church_case_283 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → ((∀ (church5 : Type _), ((church0 → (church5 → church5)) → (church5 → church5))) → (∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church1 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))))))) :=
  fun _ _ f g h _ f1 x => g _ f1 (h _ (fun y z => let f2 := f y; let f3 := f2 y; f3 _ z x) x)
#print axioms ChurchCorpus.church_case_283

-- Church.hs:1637 foldrWithKey (total)
def ChurchCorpus.church_case_284 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (church2 → church2))) → (church2 → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → church2)))) :=
  fun _ _ _ f x g => g _ (fun h y => h _ (fun z w => f z w y)) x
#print axioms ChurchCorpus.church_case_284

-- Church.hs:1642 foldlWithKey (total)
def ChurchCorpus.church_case_285 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (church2 → church0))) → (church0 → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church1 → (church2 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → church0)))) :=
  fun _ _ _ f x g => g _ (fun h y => h _ (f y)) x
#print axioms ChurchCorpus.church_case_285

-- Church.hs:1647 isSubmapOfBy (total)
def ChurchCorpus.church_case_286 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → ((church2 → (church2 → (∀ (church4 : Type _), (church4 → (church4 → church4))))) → ((∀ (church6 : Type _), (((∀ (church5 : Type _), ((church2 → (church0 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))) → ((∀ (church8 : Type _), (((∀ (church7 : Type _), ((church2 → (church1 → church7)) → church7)) → (church8 → church8)) → (church8 → church8))) → (∀ (church9 : Type _), (church9 → (church9 → church9)))))))) :=
  fun _ _ _ _ _ _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_286

-- Church.hs:1653 isSubmapOf (total)
def ChurchCorpus.church_case_287 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((church1 → (church1 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church1 → (church0 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → ((∀ (church7 : Type _), (((∀ (church6 : Type _), ((church1 → (church0 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))) → (∀ (church8 : Type _), (church8 → (church8 → church8)))))))) :=
  fun _ _ _ _ _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_287

-- Church.hs:1657 disjoint (total)
def ChurchCorpus.church_case_288 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church0 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → ((∀ (church7 : Type _), (((∀ (church6 : Type _), ((church0 → (church2 → church6)) → church6)) → (church7 → church7)) → (church7 → church7))) → (∀ (church8 : Type _), (church8 → (church8 → church8))))))) :=
  fun _ _ _ _ _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_288

-- Church.hs:1665 accumulate (total)
def ChurchCorpus.church_case_289 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → church0)) → (church0 → ((∀ (church2 : Type _), ((church1 → (church2 → church2)) → (church2 → church2))) → church0)))) :=
  fun _ _ f x g => g _ (fun y z => f z y) x
#print axioms ChurchCorpus.church_case_289

-- Church.hs:1669 reduce (requires_partiality)
def ChurchCorpus.church_case_290 : (∀ (church0 : Type _), (church0 → ((church0 → (church0 → church0)) → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → church0)))) :=
  fun _ x f g => f x (g _ f x)
#print axioms ChurchCorpus.church_case_290

-- Church.hs:1674 innerProduct (total)
def ChurchCorpus.church_case_291 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _) (church3 : Type _), ((church0 → (church1 → church0)) → ((church2 → (church3 → church1)) → (church0 → ((∀ (church4 : Type _), ((church2 → (church4 → church4)) → (church4 → church4))) → ((∀ (church5 : Type _), ((church3 → (church5 → church5)) → (church5 → church5))) → church0)))))) :=
  fun _ _ _ _ f g x h f1 => h _ (fun y => f1 _ (fun z w => f w (g y z))) x
#print axioms ChurchCorpus.church_case_291

-- Church.hs:1679 partialSum (total)
def ChurchCorpus.church_case_292 : (∀ (church0 : Type _), ((church0 → (church0 → church0)) → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2)))))) :=
  fun _ f g _ h => g _ (fun x => h (f x x))
#print axioms ChurchCorpus.church_case_292

-- Church.hs:1683 adjacentDifference (total)
def ChurchCorpus.church_case_293 : (∀ (church0 : Type _), ((church0 → (church0 → church0)) → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2)))))) :=
  fun _ f g _ h => g _ (fun x => h (f x x))
#print axioms ChurchCorpus.church_case_293

-- Church.hs:1689 inclusiveScan (total)
def ChurchCorpus.church_case_294 : (∀ (church0 : Type _), ((church0 → (church0 → church0)) → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2)))))) :=
  fun _ f g _ h => g _ (fun x => h (f x x))
#print axioms ChurchCorpus.church_case_294

-- Church.hs:1694 exclusiveScan (total)
def ChurchCorpus.church_case_295 : (∀ (church0 : Type _), ((church0 → (church0 → church0)) → (church0 → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))))))) :=
  fun _ f x g _ h => h (f x (g _ f x))
#print axioms ChurchCorpus.church_case_295

-- Church.hs:1699 transformReduce (total)
def ChurchCorpus.church_case_296 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → church0)) → ((church1 → church0) → (church0 → ((∀ (church2 : Type _), ((church1 → (church2 → church2)) → (church2 → church2))) → church0))))) :=
  fun _ _ f g x h => h _ (fun y z => f z (g y)) x
#print axioms ChurchCorpus.church_case_296

-- Church.hs:1704 transformReduce2 (total)
def ChurchCorpus.church_case_297 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _) (church3 : Type _), ((church0 → (church1 → church0)) → ((church2 → (church3 → church1)) → (church0 → ((∀ (church4 : Type _), ((church2 → (church4 → church4)) → (church4 → church4))) → ((∀ (church5 : Type _), ((church3 → (church5 → church5)) → (church5 → church5))) → church0)))))) :=
  fun _ _ _ _ f g x h f1 => h _ (fun y => f1 _ (fun z w => f w (g y z))) x
#print axioms ChurchCorpus.church_case_297

-- Church.hs:1709 transformInclusiveScan (total)
def ChurchCorpus.church_case_298 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → church0)) → ((church1 → church0) → ((∀ (church2 : Type _), ((church1 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))))))) :=
  fun _ _ f g h _ f1 => h _ (fun x => f1 (f (g x) (g x)))
#print axioms ChurchCorpus.church_case_298

-- Church.hs:1714 transformExclusiveScan (total)
def ChurchCorpus.church_case_299 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → church0)) → ((church1 → church0) → (church0 → ((∀ (church2 : Type _), ((church1 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))))) :=
  fun _ _ f g x h _ f1 y => f1 x (h _ (fun z => f1 (f (g z) x)) y)
#print axioms ChurchCorpus.church_case_299

-- Church.hs:1726 isJust (total)
def ChurchCorpus.church_case_300 : (∀ (church0 : Type _), ((∀ (church1 : Type _), (church1 → ((church0 → church1) → church1))) → (∀ (church2 : Type _), (church2 → (church2 → church2))))) :=
  fun _ _ _ x _ => x
#print axioms ChurchCorpus.church_case_300

-- Church.hs:1729 dup (total)
def ChurchCorpus.church_case_301 : (∀ (church0 : Type _), (church0 → (∀ (church1 : Type _), ((church0 → (church0 → church1)) → church1)))) :=
  fun _ x _ f => f x x
#print axioms ChurchCorpus.church_case_301

-- Church.hs:1732 andList (total)
def ChurchCorpus.church_case_302 : ((∀ (church1 : Type _), (((∀ (church0 : Type _), (church0 → (church0 → church0))) → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), (church2 → (church2 → church2)))) :=
  fun f _ x y => f _ (fun g => g _ y) x
#print axioms ChurchCorpus.church_case_302

-- Church.hs:1735 orList (total)
def ChurchCorpus.church_case_303 : ((∀ (church1 : Type _), (((∀ (church0 : Type _), (church0 → (church0 → church0))) → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), (church2 → (church2 → church2)))) :=
  fun f _ x y => f _ (fun g => g _ y) x
#print axioms ChurchCorpus.church_case_303

-- Church.hs:1738 cycleN (total)
def ChurchCorpus.church_case_304 : (∀ (church0 : Type _), (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2)))))) :=
  fun _ x f => match x with | .ofNat y => (match y with | .zero => f | .succ _ => f) | .negSucc z => (match z with | .zero => f | .succ _ => f)
#print axioms ChurchCorpus.church_case_304

-- Church.hs:1741 iterateN (total)
def ChurchCorpus.church_case_305 : (∀ (church0 : Type _), (Int → ((church0 → church0) → (church0 → (∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))))))) :=
  fun _ _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_305

-- Church.hs:1744 range (total)
def ChurchCorpus.church_case_306 : (Int → (Int → (∀ (church0 : Type _), ((Int → (church0 → church0)) → (church0 → church0))))) :=
  fun x y _ f z => f x (f y z)
#print axioms ChurchCorpus.church_case_306

-- Church.hs:1747 factorial (total)
def ChurchCorpus.church_case_307 : (Int → Int) :=
  fun x => match x with | .ofNat y => (match y with | .zero => x | .succ z => .negSucc z) | .negSucc w => (match w with | .zero => x | .succ x1 => .negSucc x1)
#print axioms ChurchCorpus.church_case_307

-- Church.hs:1750 isPalindrome (total)
def ChurchCorpus.church_case_308 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), (church3 → (church3 → church3)))))) :=
  fun _ f g _ x y => g _ (fun z w => let h := f z; let f1 := h z; f1 _ y w) x
#print axioms ChurchCorpus.church_case_308

-- Church.hs:1753 isRotation (total)
def ChurchCorpus.church_case_309 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), (church4 → (church4 → church4))))))) :=
  fun _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_309

-- Church.hs:1757 notElemBy (total)
def ChurchCorpus.church_case_310 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church0 → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), (church4 → (church4 → church4))))))) :=
  fun _ _ f x g _ y z => g _ (fun w x1 => let h := f x; let f1 := h w; f1 _ z x1) y
#print axioms ChurchCorpus.church_case_310

-- Church.hs:1760 removeOnce (total)
def ChurchCorpus.church_case_311 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (church0 → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))))))) :=
  fun _ f x g _ h y => g _ h (let f1 := f x; let f2 := f1 x; f2 _ y y)
#print axioms ChurchCorpus.church_case_311

-- Church.hs:1763 replaceOnce (total)
def ChurchCorpus.church_case_312 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (church0 → (church0 → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))))) :=
  fun _ f x y g _ h z => g _ h (let f1 := f y; let f2 := f1 x; f2 _ z z)
#print axioms ChurchCorpus.church_case_312

-- Church.hs:1767 intercalate (total)
def ChurchCorpus.church_case_313 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → ((∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4)))))) :=
  fun _ f g _ h x => f _ h (g _ (fun f1 => f1 _ h) x)
#print axioms ChurchCorpus.church_case_313

-- Church.hs:1770 sum (needs_int_provider)
def ChurchCorpus.church_case_314 : ((∀ (church0 : Type _), ((Int → (church0 → church0)) → (church0 → church0))) → Int) :=
  fun _ => .negSucc (.zero)
#print axioms ChurchCorpus.church_case_314

-- Church.hs:1773 product (needs_int_provider)
def ChurchCorpus.church_case_315 : ((∀ (church0 : Type _), ((Int → (church0 → church0)) → (church0 → church0))) → Int) :=
  fun _ => .negSucc (.zero)
#print axioms ChurchCorpus.church_case_315

-- Church.hs:1776 maximum (requires_partiality)
def ChurchCorpus.church_case_316 : (∀ (church0 : Type _), (church0 → ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → church0)))) :=
  fun _ x f g => g _ (fun y z => let h := f y; let f1 := h z; f1 _ x z) x
#print axioms ChurchCorpus.church_case_316

-- Church.hs:1779 minimum (requires_partiality)
def ChurchCorpus.church_case_317 : (∀ (church0 : Type _), (church0 → ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → church0)))) :=
  fun _ x f g => g _ (fun y z => let h := f y; let f1 := h z; f1 _ x z) x
#print axioms ChurchCorpus.church_case_317

-- Church.hs:1782 minMax (requires_partiality)
def ChurchCorpus.church_case_318 : (∀ (church0 : Type _), (church0 → ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church0 → church3)) → church3)))))) :=
  fun _ x f g _ h => h x (g _ (fun y z => let f1 := f y; let f2 := f1 z; f2 _ z x) x)
#print axioms ChurchCorpus.church_case_318

-- Church.hs:1785 sortBy (total)
def ChurchCorpus.church_case_319 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y; f2 _ y y) z) x
#print axioms ChurchCorpus.church_case_319

-- Church.hs:1788 sort (total)
def ChurchCorpus.church_case_320 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y; f2 _ y y) z) x
#print axioms ChurchCorpus.church_case_320

-- Church.hs:1791 group (total)
def ChurchCorpus.church_case_321 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (church4 → church4)) → (church4 → church4)))))) :=
  fun _ f g _ h x => g _ (fun y z => let f1 := f y; let f2 := f1 y; f2 _ z (h g x)) x
#print axioms ChurchCorpus.church_case_321

-- Church.hs:1794 nub (total)
def ChurchCorpus.church_case_322 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y; f2 _ y y) z) x
#print axioms ChurchCorpus.church_case_322

-- Church.hs:1797 tally (total)
def ChurchCorpus.church_case_323 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (Int → church3)) → church3)) → (church4 → church4)) → (church4 → church4)))))) :=
  fun _ f g _ h x => g _ (fun y z => let f1 := f y; let f2 := f1 y; f2 _ (h (fun _ f3 => f3 y (.negSucc (.zero))) z) z) x
#print axioms ChurchCorpus.church_case_323

-- Church.hs:1800 counts (total)
def ChurchCorpus.church_case_324 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (Int → church3)) → church3)) → (church4 → church4)) → (church4 → church4)))))) :=
  fun _ f g _ h x => g _ (fun y z => let f1 := f y; let f2 := f1 y; f2 _ (h (fun _ f3 => f3 y (.negSucc (.zero))) z) z) x
#print axioms ChurchCorpus.church_case_324

-- Church.hs:1803 countDistinct (needs_int_provider)
def ChurchCorpus.church_case_325 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → Int))) :=
  fun _ f g => .ofNat (g _ (fun x y => match y with | .zero => (let h := f x; let f1 := h x; f1 _ y y) | .succ z => z) (.zero))
#print axioms ChurchCorpus.church_case_325

-- Church.hs:1806 positionIndex (total)
def ChurchCorpus.church_case_326 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → ((∀ (church3 : Type _), ((Int → (church3 → church3)) → (church3 → church3))) → church4)) → church4)) → (church5 → church5)) → (church5 → church5)))))) :=
  fun _ _ _ _ _ x => x
#print axioms ChurchCorpus.church_case_326

-- Church.hs:1809 elem (total)
def ChurchCorpus.church_case_327 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church0 → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), (church4 → (church4 → church4))))))) :=
  fun _ _ f x g _ y z => g _ (fun w x1 => let h := f x; let f1 := h w; f1 _ z x1) y
#print axioms ChurchCorpus.church_case_327

-- Church.hs:1812 notElem (total)
def ChurchCorpus.church_case_328 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church0 → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), (church4 → (church4 → church4))))))) :=
  fun _ _ f x g _ y z => g _ (fun w x1 => let h := f x; let f1 := h w; f1 _ z x1) y
#print axioms ChurchCorpus.church_case_328

-- Church.hs:1815 delete (total)
def ChurchCorpus.church_case_329 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → (church0 → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))))))) :=
  fun _ f x g _ h y => g _ h (let f1 := f x; let f2 := f1 x; f2 _ y y)
#print axioms ChurchCorpus.church_case_329

-- Church.hs:1818 intersect (total)
def ChurchCorpus.church_case_330 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), ((church0 → (church4 → church4)) → (church4 → church4))))))) :=
  fun _ f g h _ f1 x => h _ f1 (g _ (fun y z => let f2 := f y; let f3 := f2 y; f3 _ z x) x)
#print axioms ChurchCorpus.church_case_330

-- Church.hs:1821 complement (total)
def ChurchCorpus.church_case_331 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), ((church0 → (church5 → church5)) → (church5 → church5))))))) :=
  fun _ _ f g h _ f1 x => g _ (fun y z => f1 (h _ (fun w x1 => let f2 := f x1; let f3 := f2 w; f3 _ x1 y) y) z) x
#print axioms ChurchCorpus.church_case_331

-- Church.hs:1824 containsAll (total)
def ChurchCorpus.church_case_332 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → (church5 → church5))))))) :=
  fun _ _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_332

-- Church.hs:1827 containsAny (total)
def ChurchCorpus.church_case_333 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → (church5 → church5))))))) :=
  fun _ _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_333

-- Church.hs:1830 containsNone (total)
def ChurchCorpus.church_case_334 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → (church5 → church5))))))) :=
  fun _ _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_334

-- Church.hs:1833 containsOnly (total)
def ChurchCorpus.church_case_335 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → (church5 → church5))))))) :=
  fun _ _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_335

-- Church.hs:1836 unique (total)
def ChurchCorpus.church_case_336 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ (fun y z => h (let f1 := f y; let f2 := f1 y; f2 _ y y) z) x
#print axioms ChurchCorpus.church_case_336

-- Church.hs:1839 isPrefix (total)
def ChurchCorpus.church_case_337 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → (church5 → church5))))))) :=
  fun _ _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_337

-- Church.hs:1842 isSuffix (total)
def ChurchCorpus.church_case_338 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church1 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → ((∀ (church4 : Type _), ((church1 → (church4 → church4)) → (church4 → church4))) → (∀ (church5 : Type _), (church5 → (church5 → church5))))))) :=
  fun _ _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_338

-- Church.hs:1845 compareThreeWay (needs_int_provider)
def ChurchCorpus.church_case_339 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → Int)))) :=
  fun _ _ _ _ => .negSucc (.zero)
#print axioms ChurchCorpus.church_case_339

-- Church.hs:1848 lexLess (total)
def ChurchCorpus.church_case_340 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → (∀ (church4 : Type _), (church4 → (church4 → church4))))))) :=
  fun _ f g h _ x y => g _ (fun z w => h _ (fun x1 x2 => let f1 := f z; let f2 := f1 x1; f2 _ x2 w) y) x
#print axioms ChurchCorpus.church_case_340

-- Church.hs:1851 nextPermutationBy (total)
def ChurchCorpus.church_case_341 : (∀ (church0 : Type _), ((church0 → (church0 → (∀ (church1 : Type _), (church1 → (church1 → church1))))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church4 : Type _), (church4 → (((∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3))) → church4) → church4)))))) :=
  fun _ f g _ x h => g _ (fun y z => let f1 := f y; let f2 := f1 y; f2 _ z (h g)) x
#print axioms ChurchCorpus.church_case_341

-- Church.hs:1854 associationThread (total)
def ChurchCorpus.church_case_342 : (∀ (church0 : Type _) (church1 : Type _), ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → ((∀ (church3 : Type _), ((church1 → (church3 → church3)) → (church3 → church3))) → (∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church1 → church4)) → church4)) → (church5 → church5)) → (church5 → church5)))))) :=
  fun _ _ f g _ h => g _ (fun x => f _ (fun y => h (fun _ f1 => f1 y x)))
#print axioms ChurchCorpus.church_case_342

-- Church.hs:1857 assocInsert (total)
def ChurchCorpus.church_case_343 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church0 → (church1 → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6)))))))) :=
  fun _ _ f x y g _ h z => h (fun _ f1 => f1 (let f2 := f x; let f3 := f2 x; f3 _ x x) y) (g _ h z)
#print axioms ChurchCorpus.church_case_343

-- Church.hs:1860 assocDelete (total)
def ChurchCorpus.church_case_344 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church0 → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6))))))) :=
  fun _ _ f x g _ h y => g _ h (let f1 := f x; let f2 := f1 x; f2 _ y y)
#print axioms ChurchCorpus.church_case_344

-- Church.hs:1863 insertOrAssign (total)
def ChurchCorpus.church_case_345 : (∀ (church0 : Type _) (church1 : Type _), ((church0 → (church0 → (∀ (church2 : Type _), (church2 → (church2 → church2))))) → (church0 → (church1 → ((∀ (church4 : Type _), (((∀ (church3 : Type _), ((church0 → (church1 → church3)) → church3)) → (church4 → church4)) → (church4 → church4))) → (∀ (church6 : Type _), (((∀ (church5 : Type _), ((church0 → (church1 → church5)) → church5)) → (church6 → church6)) → (church6 → church6)))))))) :=
  fun _ _ f x y g _ h z => h (fun _ f1 => f1 (let f2 := f x; let f3 := f2 x; f3 _ x x) y) (g _ h z)
#print axioms ChurchCorpus.church_case_345

-- Church.hs:849 interleave (total)
def ChurchCorpus.church_case_346 : (∀ (church0 : Type _), (church0 → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church3 : Type _), (((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ x f _ g => g (fun _ h y => h x (f _ h y))
#print axioms ChurchCorpus.church_case_346

-- Church.hs:1100 go (total)
def ChurchCorpus.church_case_347 : (∀ (church0 : Type _), (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2)))))) :=
  fun _ x f => match x with | .ofNat y => (match y with | .zero => f | .succ _ => f) | .negSucc z => (match z with | .zero => f | .succ _ => f)
#print axioms ChurchCorpus.church_case_347

-- Church.hs:1120 introselect (total)
def ChurchCorpus.church_case_348 : (∀ (church0 : Type _), (Int → (Int → ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → (∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))))))) :=
  fun _ x y f => match x with | .ofNat z => (match z with | .zero => (match y with | .ofNat w => (match w with | .zero => f | .succ _ => f) | .negSucc x1 => (match x1 with | .zero => f | .succ _ => f)) | .succ _ => (match y with | .ofNat x2 => (match x2 with | .zero => f | .succ _ => f) | .negSucc x3 => (match x3 with | .zero => f | .succ _ => f))) | .negSucc x4 => (match x4 with | .zero => (match y with | .ofNat x5 => (match x5 with | .zero => f | .succ _ => f) | .negSucc x6 => (match x6 with | .zero => f | .succ _ => f)) | .succ _ => (match y with | .ofNat x7 => (match x7 with | .zero => f | .succ _ => f) | .negSucc x8 => (match x8 with | .zero => f | .succ _ => f)))
#print axioms ChurchCorpus.church_case_348

-- Church.hs:1325 go (total)
def ChurchCorpus.church_case_349 : (∀ (church0 : Type _), ((∀ (church1 : Type _), ((church0 → (church1 → church1)) → (church1 → church1))) → ((∀ (church2 : Type _), ((church0 → (church2 → church2)) → (church2 → church2))) → (∀ (church3 : Type _), ((church0 → (church3 → church3)) → (church3 → church3)))))) :=
  fun _ f g _ h x => g _ h (f _ h x)
#print axioms ChurchCorpus.church_case_349
