"""Offline production-normalizer comparison after review; never runs synthesis."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
EXE = "42c0c9c0a46a35302a04691a93fc68099c5e80bd91305e9a927ba9de9cec5cae"
HELPER = HERE / "compare-composite-captures.py"
assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == "45eeced37b947730ea995eb97cda286aaa47b051e4276b7b21ab254671b869c2"
spec = importlib.util.spec_from_file_location("production_comparison", HELPER)
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
inputs = gate.Inputs()
inputs.read(Path(__file__))
inputs.read(HELPER)
run_path = HERE / "dedup-compatibility/results.json"
run = json.loads(inputs.read(run_path).decode("utf-8-sig"))
review_path = HERE / "dedup-capture-review/results.json"
review = json.loads(inputs.read(review_path).decode("utf-8-sig"))
assert review["input_sha256"][str(run_path.resolve())] == gate.digest(inputs.read(run_path))
assert run["live_execution_complete"] and run["completed_fixture_count"] == 30
assert not run["errors"] and all(run[key] for key in (
    "executable_unchanged", "fixture_inputs_unchanged", "runner_unchanged", "wrapper_unchanged"))
assert run["required_executable_sha256"] == review["fresh_executable_sha256"] == EXE
assert review["counts"]["lost_prior_success_count"] == 0
assert review["counts"]["queries_with_exact_duplicates"] == 0
assert review["counts"]["bare_proof_candidate_output_losses"] == 0
assert review["counts"]["bare_proof_queries_with_exact_duplicates"] == 0
inputs.read(run["final_executable"]["path"], EXE)
runner = inputs.read(ROOT / "test/run-tests.sh", run["runner_sha256"])
script = gate.production_normalizer(runner)
rows = []
for row in run["fixtures"]:
    assert row["status"] in ("original_golden_matched", "baseline_drift_review_pending")
    source = row["source_before"]
    inputs.read(source["source_path"], source["source_sha256"])
    capture = inputs.read(row["raw_capture_path"], row["raw_capture_sha256"])
    golden = inputs.read(source["golden_path"])
    actual = gate.normalize(capture, "actual", script)
    expected = gate.normalize(golden, "golden", script)
    rows.append({"fixture": row["fixture"], "matched": actual == expected,
        "synthesis_command_count": source["synthesis_command_count"],
        "original_runner_exit_code": row["runner_exit_code"],
        "capture_sha256": gate.digest(capture), "golden_sha256": gate.digest(golden),
        "golden_changed_after_live_run": gate.digest(golden) != source["golden_sha256"],
        "normalized_capture_sha256": gate.digest(actual), "normalized_golden_sha256": gate.digest(expected)})
assert len(rows) == 30 and sum(row["synthesis_command_count"] for row in rows) == 265
inputs.recheck()
output = HERE / "dedup-final-comparison"
output.mkdir(exist_ok=False)
report = {"passed": all(row["matched"] for row in rows),
    "validation_mode": "offline_production_normalizer_comparison_of_preserved_post_dedup_captures",
    "executable_sha256": EXE, "original_live_runner_exit_code": run["exit_code"],
    "fixture_count": 30, "synthesis_command_count": 265,
    "live_synthesis_rerun": False, "kernel_rerun": False,
    "inputs_sha256": {str(path): digest for path, digest in inputs.hashes.items()}, "fixtures": rows}
(output / "results.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: value for key, value in report.items() if key not in ("fixtures", "inputs_sha256")}, indent=2))
raise SystemExit(0 if report["passed"] else 1)
