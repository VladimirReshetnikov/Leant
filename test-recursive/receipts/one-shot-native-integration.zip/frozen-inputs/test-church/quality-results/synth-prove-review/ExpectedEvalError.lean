-- Expected failure only: do not repair the fixture by supplying type arguments.
set_option linter.unusedVariables false
noncomputable section
def it : (∀ a b : Type, Option a → Option b → Option (a × b)) :=
  fun _ _ _ _ => .none
#eval (it (some 3) (some true) : Option (Nat × Bool))
