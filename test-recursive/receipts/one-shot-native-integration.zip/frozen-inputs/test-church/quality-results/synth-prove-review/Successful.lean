-- Prepared from exact fresh synth-prove output; not yet kernel-validated.
set_option linter.unusedVariables false
noncomputable section
namespace SynthProveReplay

def q0_it1 : ∀ p : Prop, Decidable p → Decidable (¬ p) :=
  fun _ x => match x with | .isFalse k => .isTrue k | .isTrue y => .isFalse (fun k1 => k1 y)
#print axioms q0_it1

def q1_it1 : ∀ (p q : Prop) (h : p → q) (hp : p), q ∧ p :=
  fun _ _ f x => ⟨f x, x⟩
#print axioms q1_it1

def q2_it1 : (∀ a b : Type, Option a → Option b → Option (a × b)) :=
  fun _ _ _ _ => .none
#print axioms q2_it1

def q2_it2 : (∀ a b : Type, Option a → Option b → Option (a × b)) :=
  fun _ _ x y => match x with | .none => (.none) | .some z => (match y with | .none => (.none) | .some w => .some ⟨z, w⟩)
#print axioms q2_it2

def q4_it1 : (∀ p : Prop, p ∨ ¬ p) :=
  fun _ => Classical.em _
#print axioms q4_it1

def q4_it2 : (∀ p : Prop, p ∨ ¬ p) :=
  fun _ => match Classical.em _ with | .inl x => .inl x | .inr k => .inr k
#print axioms q4_it2

def abort_exact_replayed : ∀ p : Prop, Decidable p → Decidable (¬ p) := by
  exact (fun _ x => match x with | .isFalse k => .isTrue k | .isTrue y => .isFalse (fun k1 => k1 y))
#print axioms abort_exact_replayed

theorem mp_and : ∀ p q : Prop, (p → q) → p → q ∧ p := by
  intro p q h hp
  exact ((fun _ _ f x => ⟨f x, x⟩) p q h hp)
#print axioms mp_and
#check mp_and
#check q2_it2
end SynthProveReplay
