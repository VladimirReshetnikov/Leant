"""Check shipped acceptance inputs against their exact workspace bytes."""
from pathlib import Path
import hashlib, json, sys, tarfile

root = Path(__file__).resolve().parents[2]
directory = Path(sys.argv[1]) if len(sys.argv) > 1 else root / 'test-church/generated-sdist-primary'
packages = [
    ('leant-0.1.0', root, [
        'leant.cabal', 'src/Main.hs', 'src/Leant/Synth/Fragment.hs',
        'src/Leant/Synth/Engine.hs', 'src/Leant/Synth/Render.hs',
        'test/run-tests.sh',
        *[str(path.relative_to(root)).replace('\\', '/')
          for path in sorted((root / 'test').glob('*.txt'))],
        *[str(path.relative_to(root)).replace('\\', '/')
          for path in sorted((root / 'test').glob('*.golden'))],
        *['test-church/' + name for name in [
            'README.md', 'run_corpus.py', 'run_fixtures.py', 'test_run_corpus.py',
            'check-provider-discovery.hs', 'UniverseProbe.lean', 'MixedSpineSyntax.lean']],
    ]),
    ('djex-2026.7.17', root / 'lib/Djex', [
        'djex.cabal', 'docs/examples/Church.hs', 'test-church/manifest.json',
        'test-church/README.md', 'docs/rank-n-impredicative-synthesis.tex',
        'docs/rank-n-impredicative-synthesis.pdf',
    ]),
]
reports = []
for name, workspace, required in packages:
    path = directory / (name + '.tar.gz')
    with tarfile.open(path, 'r:gz') as archive:
        for relative in required:
            member = archive.extractfile(name + '/' + relative)
            if member is None or member.read() != (workspace / relative).read_bytes():
                raise SystemExit(f'Archive input missing or changed: {name}/{relative}')
    reports.append({'package': name, 'required_files_verified': len(required),
                    'tarball_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    print(f'{name}: {len(required)} required source/acceptance files match workspace bytes')
(directory / 'verification.json').write_text(json.dumps(reports, indent=2) + '\n', encoding='utf-8')
