"""Compare preserved live output with reviewed final golden files.

This is an offline comparison, not a new synthesis run. The original runner
exit status and every changed baseline remain explicit in the report.
"""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')

root = Path(__file__).resolve().parents[2]
capture_dir = root / 'test-church/generated-goldens-final'
runner_bytes = (root / 'test/run-tests.sh').read_bytes()
runner_source = runner_bytes.decode('utf-8-sig').replace('\r\n', '\n')
normalizers = []
for name in ('filter', 'normalize_volatile_search_counts'):
    definitions = re.findall(r'^' + name + r'\(\) \{\n.*?^\}',
                             runner_source, re.MULTILINE | re.DOTALL)
    assert len(definitions) == 1, f'Expected one production {name} definition'
    normalizers.append(definitions[0])
normalization_script = 'set -uo pipefail\n' + '\n'.join(normalizers) + r'''
if [ "$1" = actual ]; then
  if ! actual=$(filter); then exit 2; fi
  printf '%s\n' "$actual" | normalize_volatile_search_counts
else
  normalize_volatile_search_counts
fi
'''


def normalized(data, mode):
    # Reuse the production definitions and its command-substitution semantics.
    # Goldens only undergo queue-count normalization, exactly as in the runner.
    result = subprocess.run(
        [r'C:\Program Files\Git\bin\bash.exe', '--noprofile', '--norc', '-c',
         normalization_script, 'final-capture-comparison', mode],
        input=data, capture_output=True, cwd=root, check=True)
    return result.stdout.decode('utf-8')
run = json.loads((capture_dir / 'results.json').read_text(encoding='utf-8-sig'))
expected_hash = 'addfac35b9d82955fc871c177b582a8c043475c0171c22cb17977e0e9f5b9869'
assert run['leant_executable_sha256'] == expected_hash
assert run['leant_executable_unchanged'] is True
log = (capture_dir / 'runner.log').read_text(encoding='utf-8-sig')
outcomes = re.findall(r'^(ok  |FAIL) (.+)$', log, re.MULTILINE)
fixtures = sorted((root / 'test').glob('*.txt'))
assert len(outcomes) == len(fixtures) == 30, 'Incomplete original live run'
assert sorted(name for _, name in outcomes) == [p.name for p in fixtures], (
    'Missing, duplicate, or failed-process fixture result')
assert run['exit_code'] == (1 if any(kind == 'FAIL' for kind, _ in outcomes) else 0)
rows = []
for fixture in fixtures:
    captured = capture_dir / 'transcripts' / (fixture.stem + '.output.txt')
    golden = fixture.with_suffix('.golden')
    source_bytes, actual_bytes, expected_bytes = (
        fixture.read_bytes(), captured.read_bytes(), golden.read_bytes())
    source = source_bytes.decode('utf-8-sig')
    actual = normalized(actual_bytes, 'actual')
    expected = normalized(expected_bytes, 'golden')
    passed = actual == expected
    if not passed:
        print(''.join(difflib.unified_diff(expected.splitlines(True),
                                         actual.splitlines(True),
                                         fromfile=str(golden), tofile=str(captured))))
    rows.append({
        'fixture': fixture.name,
        'source_sha256': hashlib.sha256(source_bytes).hexdigest(),
        'raw_capture_sha256': hashlib.sha256(actual_bytes).hexdigest(),
        'final_golden_sha256': hashlib.sha256(expected_bytes).hexdigest(),
        'synthesis_command_count': len(re.findall(r'^:synth(?:\s|$)', source, re.MULTILINE)),
        'passed': passed,
    })
report = {
    'validation_mode': 'offline_comparison_of_preserved_full_live_run',
    'original_live_run_exit_code': run['exit_code'],
    'original_baseline_drift_fixtures': [name for kind, name in outcomes if kind == 'FAIL'],
    'leant_executable_sha256': expected_hash,
    'leant_executable_unchanged_during_live_run': True,
    'normalization': 'production runner function definitions and command-substitution semantics',
    'runner_sha256': hashlib.sha256(runner_bytes).hexdigest(),
    'fixture_count': len(rows),
    'synthesis_command_count': sum(row['synthesis_command_count'] for row in rows),
    'passed': all(row['passed'] for row in rows),
    'fixtures': rows,
}
assert report['synthesis_command_count'] == 265
(capture_dir / 'final-comparison.json').write_text(
    json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(f"Final captured transcript comparison: {sum(r['passed'] for r in rows)}/30; "
      f"265 commands; original live exit={run['exit_code']}")
raise SystemExit(0 if report['passed'] else 1)
