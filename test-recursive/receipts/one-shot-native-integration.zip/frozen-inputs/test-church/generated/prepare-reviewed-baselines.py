"""Prepare minimal baseline proposals from explicitly selected, reviewed reports."""
from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')
root = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location(
    'review', root / 'test-church/generated-probe/replay_golden_drift.py')
review = importlib.util.module_from_spec(spec)
spec.loader.exec_module(review)
for argument in sys.argv[1:]:
    directory = root / 'test-church' / argument
    report = json.loads((directory / 'results.json').read_text(encoding='utf-8-sig'))
    assert report['kernel_replay_requested'] is True
    for row in report['fixtures']:
        assert row['status'] == 'passed' and row['lost_successful_queries'] == 0
        assert all(segment['passed'] for segment in row['segments'])
        fixture = root / 'test' / row['fixture']
        golden = fixture.with_suffix('.golden')
        raw = Path(row['raw_capture_path'])
        assert hashlib.sha256(fixture.read_bytes()).hexdigest() == row['source_sha256']
        assert hashlib.sha256(golden.read_bytes()).hexdigest() == row['golden_before_sha256']
        assert hashlib.sha256(raw.read_bytes()).hexdigest() == row['raw_capture_sha256']
        before = golden.read_text(encoding='utf-8-sig').splitlines()
        normalized_before = review.normalized('\n'.join(before)).splitlines()
        after = review.normalized(raw.read_text(encoding='utf-8-sig')).splitlines()
        proposal = []
        for tag, a, b, c, d in difflib.SequenceMatcher(
                None, normalized_before, after, autojunk=False).get_opcodes():
            proposal.extend(before[a:b] if tag == 'equal' else after[c:d])
        target = directory / ('proposed-' + golden.name)
        target.write_text('\n'.join(proposal) + '\n', encoding='utf-8', newline='\n')
        print(''.join(difflib.unified_diff(
            [line + '\n' for line in before], [line + '\n' for line in proposal],
            fromfile=str(golden), tofile=str(target))))
