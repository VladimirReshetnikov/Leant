set_option linter.unusedVariables false
namespace ClosureGood
axiom Token : Type
private class LeftChoice (a : Type 1) : Prop where witness : True
private class RightChoice (b : Type 1) : Prop where witness : True
private instance : LeftChoice (∀ x : Type, x → x) := ⟨True.intro⟩
private instance : RightChoice (∀ x : Type, x → x → x) := ⟨True.intro⟩
axiom global {a b : Type 1} [LeftChoice a] [RightChoice b] : Token
end ClosureGood

noncomputable section
def ClosureReplay0_1 : ClosureGood.Token := ClosureGood.global («a» := (∀ (a0_0 : Type _), a0_0 → a0_0)) («b» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0))
#print axioms ClosureReplay0_1
def ClosureReplay1_1 : ClosureGood.Token := ClosureGood.global («a» := (∀ (a0_0 : Type _), a0_0 → a0_0)) («b» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0))
#print axioms ClosureReplay1_1
def ClosureReplay1_2 : ClosureGood.Token := match Sum.inl (ClosureGood.global («a» := (∀ (a0_0 : Type _), a0_0 → a0_0)) («b» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0))) with | .inl a => a | .inr b => b
#print axioms ClosureReplay1_2
def ClosureReplay1_3 : ClosureGood.Token := match Sum.inr (ClosureGood.global («a» := (∀ (a0_0 : Type _), a0_0 → a0_0)) («b» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0))) with | .inl a => a | .inr b => b
#print axioms ClosureReplay1_3
