set_option linter.unusedVariables false


namespace ClosureControl
axiom Token : Type
private abbrev P1 := ∀ x : Type, x → x
private abbrev P2 := ∀ x : Type, x → x → x
private abbrev P3 := ∀ x : Type, x → x → x → x
private abbrev P4 := ∀ x : Type, x → x → x → x → x
private abbrev GoodA := ∀ x : Type, (x → x) → x → x
private abbrev GoodB := ∀ x : Type, (x → x → x) → x → x
private class PairChoice (a b : Type 1) : Prop where witness : True
private class RequiredChoice (a b : Type 1) : Prop where witness : True
private instance (priority := 1) : PairChoice GoodA GoodB := ⟨True.intro⟩
private instance : PairChoice P1 P1 := ⟨True.intro⟩
private instance : PairChoice P1 P2 := ⟨True.intro⟩
private instance : PairChoice P1 P3 := ⟨True.intro⟩
private instance : PairChoice P1 P4 := ⟨True.intro⟩
private instance : PairChoice P2 P1 := ⟨True.intro⟩
private instance : PairChoice P2 P2 := ⟨True.intro⟩
private instance : PairChoice P2 P3 := ⟨True.intro⟩
private instance : PairChoice P2 P4 := ⟨True.intro⟩
private instance : PairChoice P3 P1 := ⟨True.intro⟩
private instance : PairChoice P3 P2 := ⟨True.intro⟩
private instance : PairChoice P3 P3 := ⟨True.intro⟩
private instance : PairChoice P3 P4 := ⟨True.intro⟩
private instance : PairChoice P4 P1 := ⟨True.intro⟩
private instance : PairChoice P4 P2 := ⟨True.intro⟩
private instance : PairChoice P4 P3 := ⟨True.intro⟩
private instance : PairChoice P4 P4 := ⟨True.intro⟩
private instance : RequiredChoice GoodA GoodB := ⟨True.intro⟩
axiom global {a b : Type 1} [PairChoice a b] [RequiredChoice a b] : Token
end ClosureControl

noncomputable section
def ClosureReplay0_1 : ClosureControl.Token := ClosureControl.global («a» := (∀ (a0_0 : Type _), (a0_0 → a0_0) → a0_0 → a0_0)) («b» := (∀ (a0_0 : Type _), (a0_0 → a0_0 → a0_0) → a0_0 → a0_0))
#print axioms ClosureReplay0_1
def ClosureReplay1_1 : ClosureControl.Token := ClosureControl.global («a» := (∀ (a0_0 : Type _), (a0_0 → a0_0) → a0_0 → a0_0)) («b» := (∀ (a0_0 : Type _), (a0_0 → a0_0 → a0_0) → a0_0 → a0_0))
#print axioms ClosureReplay1_1
def ClosureReplay1_2 : ClosureControl.Token := match Sum.inl (ClosureControl.global («a» := (∀ (a0_0 : Type _), (a0_0 → a0_0) → a0_0 → a0_0)) («b» := (∀ (a0_0 : Type _), (a0_0 → a0_0 → a0_0) → a0_0 → a0_0))) with | .inl a => a | .inr b => b
#print axioms ClosureReplay1_2
def ClosureReplay1_3 : ClosureControl.Token := match Sum.inr (ClosureControl.global («a» := (∀ (a0_0 : Type _), (a0_0 → a0_0) → a0_0 → a0_0)) («b» := (∀ (a0_0 : Type _), (a0_0 → a0_0 → a0_0) → a0_0 → a0_0))) with | .inl a => a | .inr b => b
#print axioms ClosureReplay1_3
