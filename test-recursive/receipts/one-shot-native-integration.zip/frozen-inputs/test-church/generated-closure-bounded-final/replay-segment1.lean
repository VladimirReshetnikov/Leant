set_option linter.unusedVariables false


namespace ClosureSubgoal
axiom Token : Type
private class Need (a : Type 1) : Prop where witness : True
private class Seed (a : Type 1) : Prop where witness : True
private instance : Need (∀ x : Type, x → x) := ⟨True.intro⟩
private instance [Need a] : Seed a := ⟨True.intro⟩
axiom global {a : Type 1} [Seed a] : Token
end ClosureSubgoal

noncomputable section
def ClosureReplay0_1 : ClosureSubgoal.Token := ClosureSubgoal.global («a» := (∀ (a0_0 : Type _), a0_0 → a0_0))
#print axioms ClosureReplay0_1
def ClosureReplay1_1 : ClosureSubgoal.Token := ClosureSubgoal.global («a» := (∀ (a0_0 : Type _), a0_0 → a0_0))
#print axioms ClosureReplay1_1
def ClosureReplay1_2 : ClosureSubgoal.Token := match Sum.inl (ClosureSubgoal.global («a» := (∀ (a0_0 : Type _), a0_0 → a0_0))) with | .inl a => a | .inr b => b
#print axioms ClosureReplay1_2
def ClosureReplay1_3 : ClosureSubgoal.Token := match Sum.inr (ClosureSubgoal.global («a» := (∀ (a0_0 : Type _), a0_0 → a0_0))) with | .inl a => a | .inr b => b
#print axioms ClosureReplay1_3
