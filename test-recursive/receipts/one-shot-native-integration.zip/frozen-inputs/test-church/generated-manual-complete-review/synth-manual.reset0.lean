-- Independent source reset segment 0
def double (n : Nat) : Nat := n + n
axiom Wrap : Type 1 → Type
opaque P : Nat → Prop
opaque Q : Prop
noncomputable def goldenReplayQuery30Candidate1 : ((A → B → C) → (A → B) → A → C) :=
  fun f g x => f x (g x)
#print axioms goldenReplayQuery30Candidate1
noncomputable def goldenReplayQuery30Candidate2 : ((A → B → C) → (A → B) → A → C) :=
  fun f g x => f x (g (match Sum.inl x with | .inl a => a | .inr b => b))
#print axioms goldenReplayQuery30Candidate2
noncomputable def goldenReplayQuery30Candidate3 : ((A → B → C) → (A → B) → A → C) :=
  fun f g x => f x (g (match Sum.inr x with | .inl a => a | .inr b => b))
#print axioms goldenReplayQuery30Candidate3
noncomputable def goldenReplayQuery30Candidate4 : ((A → B → C) → (A → B) → A → C) :=
  fun f g x => f x (match Sum.inr (g x) with | .inl a => a | .inr b => b)
#print axioms goldenReplayQuery30Candidate4
noncomputable def goldenReplayQuery30Candidate5 : ((A → B → C) → (A → B) → A → C) :=
  fun f g x => f x (match Sum.inr (g x) with | .inl a => g a | .inr b => b)
#print axioms goldenReplayQuery30Candidate5
