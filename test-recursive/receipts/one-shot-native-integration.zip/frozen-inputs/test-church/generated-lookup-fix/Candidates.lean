-- Generated exclusively from synthesized candidates and the manifest.
set_option linter.unusedVariables false
def ChurchCorpus.integerZero : Int := 0

-- Church.hs:1472 lookupAll (total)
def ChurchCorpus.church_case_255 : (∀ (church0 : Type _) (church1 : Type _) (church2 : Type _), ((church0 → (church1 → (∀ (church3 : Type _), (church3 → (church3 → church3))))) → (church1 → ((∀ (church5 : Type _), (((∀ (church4 : Type _), ((church0 → (church2 → church4)) → church4)) → (church5 → church5)) → (church5 → church5))) → (∀ (church6 : Type _), ((church2 → (church6 → church6)) → (church6 → church6))))))) :=
  fun _ _ _ f x g _ h y => g _ (fun f1 z => h (f1 _ (fun w x1 => let f2 := f w; let f3 := f2 x; f3 _ x1 x1)) z) y
#print axioms ChurchCorpus.church_case_255
