set_option linter.unusedVariables false
universe u v w
abbrev Church.Bool := ∀ e : Type u, e → e → e
abbrev Church.Pair (a : Type u) (b : Type v) := ∀ e : Type w, (a → b → e) → e
abbrev Church.List (a : Type u) := ∀ e : Type v, (a → e → e) → e → e
abbrev Church.Maybe (a : Type u) := ∀ e : Type v, e → (a → e) → e

noncomputable section
def ChurchFixture.case0 : Church.Bool :=
  fun _ _ x => x
#print axioms ChurchFixture.case0
def ChurchFixture.case1 : (∀ a b : Type _, Church.Pair a b → a) :=
  fun _ _ f => f _ (fun x _ => x)
#print axioms ChurchFixture.case1
def ChurchFixture.case2 : (∀ a : Type _, Church.List a → Church.Maybe (Church.Pair a (Church.List a))) :=
  fun _ _ _ x _ => x
#print axioms ChurchFixture.case2
def ChurchFixture.case3 : (∀ a b : Type _, (a → b) → Church.List a → Church.List b) :=
  fun _ _ _ _ _ _ x => x
#print axioms ChurchFixture.case3
def ChurchFixture.case4 : (∀ a b : Type _, Church.List (Church.Pair a b) → Church.Pair (Church.List a) (Church.List b)) :=
  fun _ _ _ _ f => f (fun _ _ x => x) (fun _ _ y => y)
#print axioms ChurchFixture.case4
def ChurchFixture.case5 : (∀ a : Type _, Church.List (Church.List a) → Church.List a) :=
  fun _ _ _ _ x => x
#print axioms ChurchFixture.case5
def ChurchFixture.case6 : (∀ a : Type _, Church.List a → Church.List (Church.List a)) :=
  fun _ _ _ _ x => x
#print axioms ChurchFixture.case6
def ChurchFixture.case7 : (∀ a : Type _, a → Church.List a → a) :=
  fun _ x _ => x
#print axioms ChurchFixture.case7
def ChurchFixture.case8 : (∀ F : Type 1 → Type 1, (∀ a : Type 1, F a) → F (∀ b : Type, b → b)) :=
  fun _ x => x _
#print axioms ChurchFixture.case8
