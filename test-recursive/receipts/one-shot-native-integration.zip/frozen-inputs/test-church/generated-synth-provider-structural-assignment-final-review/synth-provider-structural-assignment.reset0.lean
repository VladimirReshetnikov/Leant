-- Independent source reset segment 0
namespace StructuralDirect

axiom Token : Type
axiom LeftType : Type
axiom RightType : Type

class Choice (F : Type → Type → Type) (G : Type → Type) : Prop where
  witness : True

instance : Choice Prod (Sum LeftType) := ⟨True.intro⟩

axiom consume {F : Type → Type → Type} {G : Type → Type}
    [Choice F G] : F LeftType RightType → G RightType → Token

abbrev Goal :=
  Prod LeftType RightType → Sum LeftType RightType → Token

end StructuralDirect

namespace StructuralContext

axiom Token : Type
axiom Fixed : Type

class Binary (F : Type → Type → Type) : Prop where
  witness : True

class Unary (G : Type → Type) : Prop where
  witness : True

abbrev Selected :=
  {a : Type} → [Binary Prod] → [Unary (Sum Fixed)] → a → a

class Pick (selected : Type 1) : Prop where
  witness : True

instance : Pick Selected := ⟨True.intro⟩

axiom choose {selected : Type 1} [Pick selected] : Token

end StructuralContext

noncomputable def goldenReplayQuery5Candidate1 : StructuralContext.Token :=
  StructuralContext.choose («selected» := (∀ {a0_0 : Type _}, [@StructuralContext.Binary Prod] → [@StructuralContext.Unary (Sum (StructuralContext.Fixed))] → a0_0 → a0_0))
#print axioms goldenReplayQuery5Candidate1
noncomputable def goldenReplayQuery5Candidate2 : StructuralContext.Token :=
  match Sum.inl (StructuralContext.choose («selected» := (∀ {a0_0 : Type _}, [@StructuralContext.Binary Prod] → [@StructuralContext.Unary (Sum (StructuralContext.Fixed))] → a0_0 → a0_0))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery5Candidate2
noncomputable def goldenReplayQuery5Candidate3 : StructuralContext.Token :=
  match Sum.inr (StructuralContext.choose («selected» := (∀ {a0_0 : Type _}, [@StructuralContext.Binary Prod] → [@StructuralContext.Unary (Sum (StructuralContext.Fixed))] → a0_0 → a0_0))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery5Candidate3
