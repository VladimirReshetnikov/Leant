import Lean
set_option maxHeartbeats 200000
theorem Or.zzzzAfter : True := True.intro
#print axioms Or.zzzzAfter
namespace LeantSynth
open Lean Meta

def esc (s : String) : String :=
  "\"" ++ s.foldl (fun a c =>
    if c == '\"' || c == '\\' then a ++ "\\" ++ toString c
    else a.push c) "" ++ "\""

def atomOf (e : Expr) : MetaM String := do
  let safe := e.getUsedConstants.isEmpty && !e.isSort
  let pp ← Meta.ppExpr e
  pure ("(atom " ++ (if safe then "safe" else "unsafe") ++ " "
    ++ esc (toString pp) ++ ")")

-- Peel every term/type binder and expose the nominal head of a result.
-- Provider discovery uses this only for ranking; failure to find a head
-- leaves the provider in the lower-priority bounded pool.
partial def resultHead? (e : Expr) : MetaM (Option Name) := do
  let e ← whnfR e.consumeMData
  match e with
  | Expr.forallE n dom body bi =>
    withLocalDecl n bi dom fun fv =>
      resultHead? (body.instantiate1 fv)
  | _ => pure e.getAppFn.constName?

-- Type constructors and type families are not term inhabitants.
partial def resultIsSort (e : Expr) : MetaM Bool := do
  let e ← whnfR e.consumeMData
  match e with
  | Expr.forallE n dom body bi =>
    withLocalDecl n bi dom fun fv =>
      resultIsSort (body.instantiate1 fv)
  | _ => pure e.isSort

-- A quantified fragment variable may itself be a first-order type
-- constructor.  Admit only kind arrows whose domains and final result
-- are universes; Nat → Type and dependent term-indexed families stay
-- opaque because their argument is a term, not a proper type.
partial def isTypeKind (e : Expr) : MetaM Bool := do
  let e ← whnfR e.consumeMData
  match e with
  | Expr.sort _ => pure true
  | Expr.forallE n dom body bi =>
    let dom ← whnfR dom.consumeMData
    if !dom.isSort then pure false
    else withLocalDecl n bi dom fun fv =>
      isTypeKind (body.instantiate1 fv)
  | _ => pure false

-- Preserve the admitted ground kind of an exact provider argument.
-- Every accepted domain is itself a universe, so the arrow count is
-- enough to reconstruct Djex's Type -> ... -> Type kind language.
partial def typeKindArity? (remaining : Nat) (e : Expr)
    : MetaM (Option Nat) := do
  let e ← whnfR e.consumeMData
  match e with
  | Expr.sort _ => pure (some 0)
  | Expr.forallE n dom body bi =>
    match remaining with
    | 0 => pure none
    | Nat.succ remaining =>
      let dom ← whnfR dom.consumeMData
      if !dom.isSort then pure none
      else withLocalDecl n bi dom fun fv => do
        match ← typeKindArity? remaining (body.instantiate1 fv) with
        | none => pure none
        | some arity => pure (some (arity + 1))
  | _ => pure none

-- Retain the source binder names corresponding to the leading FAlls
-- emitted by go. Instance binders erased below are deliberately skipped
-- so Render can use named Lean arguments without exposing dictionaries.
partial def leadingTypeBinderNames (fuel : Nat) (e : Expr)
    : MetaM (Array String) := do
  match fuel with
  | 0 => pure #[]
  | Nat.succ fuel => do
    let e ← instantiateMVars e
    let e ← whnfR e.consumeMData
    match e with
    | Expr.forallE n t b bi =>
      let t ← whnfR t.consumeMData
      if b.hasLooseBVars then
        if ← isTypeKind t then
          withLocalDecl n bi t fun fv => do
            let rest ← leadingTypeBinderNames fuel
              (b.instantiate1 fv)
            let spelling := if n.isAnonymous then "" else n.toString
            pure (#[spelling] ++ rest)
        else pure #[]
      else if bi.isInstImplicit then
        leadingTypeBinderNames fuel b
      else if bi.isExplicit then
        pure #[]
      else do
        if ← isTypeKind t then do
          let rest ← leadingTypeBinderNames fuel b
          let spelling := if n.isAnonymous then "" else n.toString
          pure (#[spelling] ++ rest)
        else pure #[]
    | _ => pure #[]

-- Share an inductive family across occurrences only when every applied
-- parameter is a proper type.  Term parameters and dependent family
-- arguments keep the established occurrence-local representation.
def allProperTypeParams (args : Array Expr) : MetaM Bool := do
  for arg in args do
    let argType ← whnfR (← inferType arg)
    if !argType.isSort then return false
  pure true

-- Higher-kinded exact context arguments retain either an enclosing bound
-- variable or a canonical nominal head. Prod and Sum have matching
-- structural identities in Djex; the remaining logical or
-- sort-polymorphic constructors do not.
def unsupportedHigherKindNominalHead (name : Name) : Bool :=
  name == ``And || name == ``PProd
    || name == ``Or || name == ``PSum
    || name == ``Iff || name == ``Not

def exactContextArgumentKindArity? (fuel : Nat) (argument : Expr)
    : MetaM (Option Nat) := do
  let kind ← whnfR (← inferType argument)
  match ← typeKindArity? fuel kind with
  | none => pure none
  | some arity =>
    if arity > 64 then pure none
    else if arity == 0 then pure (some 0)
    else match argument.getAppFn with
      | Expr.fvar _ =>
        if ← allProperTypeParams argument.getAppArgs then
          pure (some arity)
        else pure none
      | Expr.const name _ =>
        if unsupportedHigherKindNominalHead name then pure none
        else if ← allProperTypeParams argument.getAppArgs then
          pure (some arity)
        else pure none
      | _ => pure none

mutual

partial def go (providerMode exactAssignmentMode : Bool)
    (fuel depth : Nat)
    (blocked : List String) (e : Expr)
    : MetaM String := do
  match fuel with
  | 0 => pure "(depth)"
  | Nat.succ fuel => do
    let e ← instantiateMVars e
    let e ← whnfR e.consumeMData
    if e.isSort then atomOf e
    else match e with
    | Expr.fvar _ => do
      let t ← whnfR (← inferType e)
      if t.isSort then
        pure ("(var " ++ esc (toString (← Meta.ppExpr e)) ++ ")")
      else atomOf e
    | Expr.forallE _ t b bi =>
      if b.hasLooseBVars then do
        -- A dependent instance telescope cannot be represented by the
        -- exact contextual wire. Mark that provider or assignment as
        -- truncated; ordinary goal behavior retains its established path.
        if (providerMode || exactAssignmentMode) && bi.isInstImplicit
          then pure "(depth)"
        else if ← isTypeKind t then
          withLocalDeclD (Name.mkSimple ("s" ++ toString depth)) t
              fun fv => do
            let inner ← go providerMode exactAssignmentMode fuel
              (depth + 1) blocked
              (b.instantiate1 fv)
            let tag := if bi.isExplicit then "(all " else "(alli "
            pure (tag ++ esc ("s" ++ toString depth) ++ " "
              ++ inner ++ ")")
        else atomOf e
      else if bi.isInstImplicit then
        -- Typeclass evidence is reconstructed by Lean when a value is
        -- applied, so Djex never consumes it as a term premise. Providers
        -- and exact assignments preserve a bounded semantic class
        -- application. Unsupported provider contexts fail closed; ordinary
        -- goal mode retains only its legacy render marker.
        if providerMode then do
          match ← exactContextFragment? true false fuel depth blocked t b with
          | none => pure "(depth)"
          | some context => pure context
        else if exactAssignmentMode then do
          let legacy : MetaM String := do
            let instanceType ← Meta.ppExpr t
            let r ← go false false fuel depth blocked b
            pure ("(inst " ++ esc (toString instanceType) ++ " "
              ++ r ++ ")")
          match ← exactContextFragment? false true fuel depth blocked t b with
          | none => legacy
          | some context => pure context
        else do
          let instanceType ← Meta.ppExpr t
          let r ← go providerMode false fuel depth blocked b
          pure ("(inst " ++ esc (toString instanceType) ++ " "
            ++ r ++ ")")
      else if bi.isExplicit then do
        let d ← go providerMode exactAssignmentMode fuel depth blocked t
        let r ← go providerMode exactAssignmentMode fuel depth blocked b
        pure ("(-> " ++ d ++ " " ++ r ++ ")")
      else do
        let typeKind ← isTypeKind t
        if providerMode && !typeKind then atomOf e
        else do
          -- An unused ordinary implicit type parameter still needs a
          -- scheme binder so Djex can choose a visible instantiation.
          -- Goal mode retains the historical elaborator-binder model;
          -- provider mode admits only first-order type-kind binders.
          let r ← go providerMode exactAssignmentMode fuel depth blocked b
          pure ("(alli " ++ esc ("i" ++ toString depth) ++ " "
            ++ r ++ ")")
    | _ =>
      match e.getAppFn with
      | Expr.const n _ => do
        let args := e.getAppArgs
        let bin (tag : String) : MetaM String := do
          let a ← go providerMode exactAssignmentMode fuel depth blocked args[0]!
          let b ← go providerMode exactAssignmentMode fuel depth blocked args[1]!
          pure ("(" ++ tag ++ " " ++ a ++ " " ++ b ++ ")")
        if args.size == 0 &&
            (n == ``False || n == ``Empty || n == ``PEmpty) then
          pure "(bot)"
        else if args.size == 0 &&
            (n == ``True || n == ``Unit || n == ``PUnit) then
          pure "(top)"
        else if args.size == 2 && n == ``Prod then
          bin "lean-prod"
        else if args.size == 2 &&
            (n == ``And || n == ``PProd) then
          bin "prod"
        else if args.size == 2 &&
            (n == ``Or || n == ``Sum || n == ``PSum) then
          bin "sum"
        else if args.size == 2 && n == ``Iff then do
          let a ← go providerMode exactAssignmentMode fuel depth blocked args[0]!
          let b ← go providerMode exactAssignmentMode fuel depth blocked args[1]!
          pure ("(prod (-> " ++ a ++ " " ++ b ++ ") (-> "
            ++ b ++ " " ++ a ++ "))")
        else if args.size == 1 && n == ``Not then do
          let a ← go providerMode exactAssignmentMode fuel depth blocked args[0]!
          pure ("(-> " ++ a ++ " (bot))")
        else do
          match ← indOf providerMode exactAssignmentMode fuel depth blocked e with
          | some s => pure s
          | none =>
            match ← recOf providerMode exactAssignmentMode fuel depth blocked e with
            | some s => pure s
            | none =>
              match ← appOf providerMode exactAssignmentMode fuel depth blocked e with
              | some s => pure s
              | none => atomOf e
      | _ =>
        match ← appOf providerMode exactAssignmentMode fuel depth blocked e with
        | some s => pure s
        | none => atomOf e

-- Render one supported class binder using the same bounded semantic wire
-- for provider schemes and exact assignment payloads. The caller chooses
-- how the body is serialized and whether an unsupported context may use a
-- legacy fallback.
partial def exactContextFragment?
    (bodyProviderMode bodyExactAssignmentMode : Bool)
    (fuel depth : Nat) (blocked : List String)
    (contextType body : Expr) : MetaM (Option String) := do
  let classType ← whnfR contextType.consumeMData
  match ← Meta.isClass? classType with
  | none => pure none
  | some className => do
    let arguments := classType.getAppArgs
    if arguments.size > 128 then pure none
    else do
      let mut rendered := ""
      for argument in arguments do
        match ← exactContextArgumentFragment? fuel depth
            blocked argument with
        | none => return none
        | some (arity, fragment) =>
          rendered := rendered ++ " (kinded "
            ++ toString arity ++ " " ++ fragment ++ ")"
      let r ← go bodyProviderMode bodyExactAssignmentMode
        fuel depth blocked body
      pure (some ("(exact-context " ++ esc className.toString
        ++ " (arguments" ++ rendered ++ ") " ++ r ++ ")"))

-- Serialize one exact context argument together with the ground kind
-- arity checked above. Proper arguments keep their full exact fragment;
-- higher-kinded arguments retain an enclosing bound variable or spell
-- the constant head canonically with only supplied proper arguments.
partial def exactContextArgumentFragment? (fuel depth : Nat)
    (blocked : List String) (argument : Expr)
    : MetaM (Option (Nat × String)) := do
  match ← exactContextArgumentKindArity? fuel argument with
  | none => pure none
  | some 0 => do
    let fragment ← go false true fuel depth blocked argument
    pure (some (0, fragment))
  | some arity =>
    match argument with
    | Expr.fvar _ => do
      let variableText ← Meta.ppExpr argument
      pure (some (arity, "(var " ++ esc (toString variableText)
        ++ ")"))
    | _ => match argument.getAppFn with
      | Expr.fvar _ => do
        let pp ← Meta.ppExpr argument
        let key := toString pp
        if blocked.contains key then pure none
        else do
          let headPP ← Meta.ppExpr argument.getAppFn
          let head := "(app-variable " ++ esc (toString headPP) ++ ")"
          let safe := argument.getUsedConstants.isEmpty && !argument.isSort
          let mut rendered := ""
          for suppliedArgument in argument.getAppArgs do
            let fragment ←
              go false true fuel depth blocked suppliedArgument
            rendered := rendered ++ " " ++ fragment
          pure (some (arity, "(app "
            ++ (if safe then "safe" else "unsafe") ++ " "
            ++ esc key ++ " " ++ head ++ rendered ++ ")"))
      | Expr.const name _ => do
        let supplied := argument.getAppArgs
        let mut rendered := ""
        for suppliedArgument in supplied do
          let fragment ←
            go false true fuel depth blocked suppliedArgument
          rendered := rendered ++ " " ++ fragment
        pure (some (arity, "(nominal " ++ esc name.toString
          ++ rendered ++ ")"))
      | _ => pure none

-- Preserve applications whose head is a bound type function or a rigid
-- Lean constant, whose result is a type, and whose arguments are all
-- proper types.  Term indices,
-- proof arguments, and other dependent applications remain one opaque
-- atom.  A blocked recursive occurrence also remains an atom so recOf's
-- constructor-premise knot keeps sharing the exact occurrence key.
partial def appOf (providerMode exactAssignmentMode : Bool)
    (fuel depth : Nat)
    (blocked : List String) (e : Expr)
    : MetaM (Option String) := do
  let args := e.getAppArgs
  let resultType ← whnfR (← inferType e)
  if !resultType.isSort || args.isEmpty then pure none
  else do
    let pp ← Meta.ppExpr e
    let key := toString pp
    if blocked.contains key then pure none
    else do
      for arg in args do
        let argType ← whnfR (← inferType arg)
        if !argType.isSort then return none
      let head? ← match e.getAppFn with
        | Expr.fvar _ => do
          let headPP ← Meta.ppExpr e.getAppFn
          pure (some ("(app-variable " ++ esc (toString headPP) ++ ")"))
        | Expr.const n _ =>
          pure (some ("(app-nominal " ++ esc n.toString ++ ")"))
        | _ => pure none
      match head? with
      | none => pure none
      | some head => do
        let safe := e.getUsedConstants.isEmpty && !e.isSort
        let mut rendered := ""
        for arg in args do
          let argument ← go providerMode exactAssignmentMode fuel depth blocked arg
          rendered := rendered ++ " " ++ argument
        pure (some ("(app "
          ++ (if safe then "safe" else "unsafe") ++ " "
          ++ esc key ++ " " ++ head ++ rendered ++ ")"))

-- Phase 2: a non-recursive, non-indexed, non-mutual, non-nested
-- inductive applied to all of its parameters expands into a
-- generalized sum of products, provided every constructor field is
-- explicit and non-dependent.  Proper-type parameter vectors retain
-- their exact family head for query-wide sharing; term/dependent
-- parameter vectors keep the occurrence-local ind representation.
partial def indOf (providerMode exactAssignmentMode : Bool)
    (fuel depth : Nat)
    (blocked : List String) (e : Expr)
    : MetaM (Option String) := do
  match e.getAppFn with
  | Expr.const n us =>
    match (← getEnv).find? n with
    | some (ConstantInfo.inductInfo iv) =>
      if iv.numIndices != 0 || iv.isRec || iv.isNested
          || iv.isUnsafe || iv.all.length != 1
          || e.getAppNumArgs != iv.numParams then
        pure none
      else do
        let args := e.getAppArgs
        let mut ctors := ""
        for c in iv.ctors do
          let ct ← inferType (mkAppN (Expr.const c us) args)
          match ← ctorFields providerMode exactAssignmentMode fuel depth blocked ct with
          | none => return none
          | some fs =>
            ctors := ctors ++ " (ctor " ++ esc c.toString ++ fs ++ ")"
        let pp ← Meta.ppExpr e
        let key := toString pp
        if ← allProperTypeParams args then do
          let mut params := ""
          for arg in args do
            let param ← go providerMode exactAssignmentMode fuel depth blocked arg
            params := params ++ " " ++ param
          pure (some ("(param-ind " ++ esc n.toString ++ " "
            ++ esc key ++ " (params" ++ params ++ ")"
            ++ ctors ++ ")"))
        else
          pure (some ("(ind " ++ esc key ++ ctors ++ ")"))
    | _ => pure none
  | _ => pure none

-- Preserve bounded constructor structure for a recursive (or nested)
-- inductive.  Djinn consumes these constructors as introduction rules;
-- Exference may additionally inspect one layer.  Emit only constructors
-- whose instantiated fields are explicit and
-- non-dependent, with this occurrence's own key blocked so field
-- occurrences of the type serialize as the matching atom.
partial def recOf (providerMode exactAssignmentMode : Bool)
    (fuel depth : Nat)
    (blocked : List String) (e : Expr)
    : MetaM (Option String) := do
  match e.getAppFn with
  | Expr.const n us =>
    match (← getEnv).find? n with
    | some (ConstantInfo.inductInfo iv) =>
      if iv.numIndices != 0 || !(iv.isRec || iv.isNested)
          || iv.isUnsafe || iv.all.length != 1
          || e.getAppNumArgs != iv.numParams then
        pure none
      else do
        let pp ← Meta.ppExpr e
        let key := toString pp
        if blocked.contains key then pure none
        else do
          let args := e.getAppArgs
          let properParams ← allProperTypeParams args
          let mut params := ""
          for arg in args do
            let param ← go providerMode exactAssignmentMode fuel depth blocked arg
            params := params ++ " " ++ param
          let blocked := key :: blocked
          let mut ctors := ""
          let mut found := false
          let mut complete := true
          for c in iv.ctors do
            let ct ← inferType (mkAppN (Expr.const c us) args)
            match ← ctorFields providerMode exactAssignmentMode fuel depth blocked ct with
            | none => complete := false
            | some fs =>
              found := true
              ctors := ctors ++ " (ctor " ++ esc c.toString
                ++ fs ++ ")"
          if !found then pure none
          else if properParams then
            pure (some ("(param-rec "
              ++ (if complete then "complete" else "partial")
              ++ " " ++ esc n.toString ++ " " ++ esc key
              ++ " (params" ++ params ++ ")" ++ ctors ++ ")"))
          else pure (some ("(rec "
            ++ (if complete then "complete" else "partial")
            ++ " " ++ esc key ++ " (params" ++ params ++ ")"
            ++ ctors ++ ")"))
    | _ => pure none
  | _ => pure none

partial def ctorFields (providerMode exactAssignmentMode : Bool)
    (fuel depth : Nat)
    (blocked : List String) (t : Expr)
    : MetaM (Option String) := do
  let t ← whnfR t
  match t with
  | Expr.forallE _ dom body bi =>
    if body.hasLooseBVars || !bi.isExplicit then pure none
    else do
      let d ← go providerMode exactAssignmentMode fuel depth blocked dom
      match ← ctorFields providerMode exactAssignmentMode fuel depth blocked body with
      | none => pure none
      | some rest => pure (some (" " ++ d ++ rest))
  | _ => pure (some "")

end

-- Open only the provider prefix represented by its serialized FAlls,
-- retaining erased instance constraints next to the fresh type metas
-- they can determine. The exact source prefix supplies its type arity;
-- ordinary serializer fuel bounds intervening instance binders.
partial def providerEvidenceSpine (fuel remainingTypes : Nat)
    (e : Expr) : MetaM (Array Expr × Array Expr) := do
  match fuel with
  | 0 => pure (#[], #[])
  | Nat.succ fuel => do
    let e ← instantiateMVars e
    let e ← whnfR e.consumeMData
    match e with
    | Expr.forallE n t b bi => do
      let t ← instantiateMVars t
      let t ← whnfR t.consumeMData
      if b.hasLooseBVars then
        if remainingTypes == 0 then pure (#[], #[])
        else if ← isTypeKind t then do
          let typeArg ← mkFreshExprMVar t MetavarKind.natural n
          let (types, constraints) ← providerEvidenceSpine fuel
            (remainingTypes - 1) (b.instantiate1 typeArg)
          pure (#[typeArg] ++ types, constraints)
        else pure (#[], #[])
      else if bi.isInstImplicit then do
        let (types, constraints) ← providerEvidenceSpine fuel
          remainingTypes b
        pure (types, #[t] ++ constraints)
      else if bi.isExplicit || remainingTypes == 0 then
        pure (#[], #[])
      else if ← isTypeKind t then do
        let typeArg ← mkFreshExprMVar t MetavarKind.natural n
        let (types, constraints) ← providerEvidenceSpine fuel
          (remainingTypes - 1) b
        pure (#[typeArg] ++ types, constraints)
      else pure (#[], #[])
    | _ => pure (#[], #[])

-- Preserve canonical identity for a bare or partially applied nominal
-- constructor. Prod and Sum share Djex's structural pair/Either identity;
-- Prop-valued and sort-polymorphic structural heads remain unsupported.
def providerNominalCandidateFragment? (fuel : Nat) (candidate : Expr)
    : MetaM (Option String) := do
  match candidate.getAppFn with
  | Expr.const n _ =>
    if unsupportedHigherKindNominalHead n then
      pure none
    else do
      let mut rendered := ""
      for arg in candidate.getAppArgs do
        let argType ← whnfR (← inferType arg)
        if !argType.isSort then return none
        -- A nominal supplied argument has no exact-domain metadata.
        -- Preserve a nested class binder only as FInst so the parser
        -- retains the vector and the engine can reject it locally.
        let argument ← go false false fuel 0 [] arg
        rendered := rendered ++ " " ++ argument
      pure (some ("(nominal " ++ esc n.toString ++ rendered ++ ")"))
  | _ => pure none

-- Record only semantic forall-domain classes, never pretty-printed Lean
-- syntax. This traversal mirrors the fragment shapes whose FAll nodes
-- become visible type syntax on the Haskell side: logical arguments and
-- proper-type application/inductive parameters recurse in source order;
-- constructor inventories remain nominal metadata and opaque atoms stop.
def providerForallDomainTag? (domain : Expr)
    : MetaM (Option String) := do
  let domain ← whnfR domain.consumeMData
  match domain with
  | Expr.sort .zero => pure (some "prop")
  | Expr.sort (.succ _) => pure (some "type")
  | Expr.sort _ => pure (some "sort")
  | _ => pure none

partial def providerForallDomains? (fuel depth : Nat) (e : Expr)
    : MetaM (Option (Array String)) := do
  match fuel with
  | 0 => pure none
  | Nat.succ fuel => do
    let e ← instantiateMVars e
    let e ← whnfR e.consumeMData
    if e.isSort then pure (some #[])
    else match e with
    | Expr.fvar _ => pure (some #[])
    | Expr.forallE _ domain body binderInfo =>
      if binderInfo.isInstImplicit then do
        -- A dictionary-dependent result is not an ordinary Haskell class
        -- context and must not fall back to one opaque pretty-printed atom.
        if body.hasLooseBVars then pure none
        else do
          -- Exact assignments retain only genuine class applications whose
          -- ordered arguments have bounded ground kinds. Proper arguments
          -- contribute their complete visible forall metadata; a nominal
          -- higher-kinded head contributes only its supplied proper args.
          let classType ← whnfR domain.consumeMData
          match ← Meta.isClass? classType with
          | none => pure none
          | some _ => do
            let arguments := classType.getAppArgs
            if arguments.size > 128 then return none
            let mut domains := #[]
            for argument in arguments do
              match ← exactContextArgumentKindArity? fuel argument with
              | none => return none
              | some arity =>
                let nestedArguments :=
                  if arity == 0 then #[argument] else argument.getAppArgs
                for nestedArgument in nestedArguments do
                  match ← providerForallDomains? fuel depth
                      nestedArgument with
                  | none => return none
                  | some nested => domains := domains ++ nested
            match ← providerForallDomains? fuel depth body with
            | none => pure none
            | some rest => pure (some (domains ++ rest))
      else if body.hasLooseBVars then do
        if ← isTypeKind domain then
          match ← providerForallDomainTag? domain with
          | none => pure none
          | some tag =>
            withLocalDeclD (Name.mkSimple ("s" ++ toString depth))
                domain fun fv => do
              match ← providerForallDomains? fuel (depth + 1)
                  (body.instantiate1 fv) with
              | none => pure none
              | some rest => pure (some (#[tag] ++ rest))
        else pure (some #[])
      else if binderInfo.isExplicit then do
        match ← providerForallDomains? fuel depth domain with
        | none => pure none
        | some left =>
          match ← providerForallDomains? fuel depth body with
          | none => pure none
          | some right => pure (some (left ++ right))
      else if ← isTypeKind domain then
        match ← providerForallDomainTag? domain with
        | none => pure none
        | some tag =>
          match ← providerForallDomains? fuel depth body with
          | none => pure none
          | some rest => pure (some (#[tag] ++ rest))
      else pure none
    | _ =>
      match e.getAppFn with
      | Expr.const name _ => do
        let args := e.getAppArgs
        let collectArguments : MetaM (Option (Array String)) := do
          let resultType ← whnfR (← inferType e)
          if !resultType.isSort || args.isEmpty then pure (some #[])
          else do
            let mut domains := #[]
            for argument in args do
              let argumentType ← whnfR (← inferType argument)
              if !argumentType.isSort then return some #[]
              match ← providerForallDomains? fuel depth argument with
              | none => return none
              | some nested => domains := domains ++ nested
            pure (some domains)
        if args.size == 2 &&
            (name == ``And || name == ``Prod || name == ``PProd
              || name == ``Or || name == ``Sum || name == ``PSum) then
          collectArguments
        else if args.size == 2 && name == ``Iff then do
          match ← providerForallDomains? fuel depth args[0]! with
          | none => pure none
          | some left =>
            match ← providerForallDomains? fuel depth args[1]! with
            | none => pure none
            | some right => pure (some (left ++ right ++ right ++ left))
        else if args.size == 1 && name == ``Not then
          providerForallDomains? fuel depth args[0]!
        else collectArguments
      | Expr.fvar _ => do
        let args := e.getAppArgs
        let resultType ← whnfR (← inferType e)
        if !resultType.isSort || args.isEmpty then pure (some #[])
        else do
          let mut domains := #[]
          for argument in args do
            let argumentType ← whnfR (← inferType argument)
            if !argumentType.isSort then return some #[]
            match ← providerForallDomains? fuel depth argument with
            | none => return none
            | some nested => domains := domains ++ nested
          pure (some domains)
      | _ => pure (some #[])

structure ProviderCandidateFragment where
  kindArity : Nat
  canonical : String
  payload : String
  domains : Array String
  candidate : Expr

def providerCandidateFragment? (fuel : Nat) (candidate : Expr)
    : MetaM (Option ProviderCandidateFragment) := do
  let candidate ← instantiateMVars candidate
  if candidate.hasMVar || candidate.hasLevelMVar
      || candidate.hasFVar || candidate.hasLooseBVars then
    pure none
  else do
    let kind ← whnfR (← inferType candidate)
    match ← typeKindArity? fuel kind with
    | none => pure none
    | some 0 => do
      match ← providerForallDomains? fuel 0 candidate with
      | none => pure none
      | some domains =>
        if domains.size > 128 then pure none
        else do
          let fragment ← go false true fuel 0 [] candidate
          let domainText := String.join
            (domains.toList.map fun domain => " " ++ domain)
          pure (some
            { kindArity := 0
            , canonical := fragment
            , payload := "(exact (domains" ++ domainText ++ ") "
                ++ fragment ++ ")"
            , domains := domains
            , candidate := candidate })
    | some arity =>
      if arity > 64 then
        pure none
      else
        match ← providerNominalCandidateFragment? fuel candidate with
        | none => pure none
        | some fragment => pure (some
            { kindArity := arity
            , canonical := fragment
            , payload := fragment
            , domains := #[]
            , candidate := candidate })

partial def providerCandidateAssignmentsDefEq
    (left right : List ProviderCandidateFragment) : MetaM Bool := do
  match left, right with
  | [], [] => pure true
  | firstLeft :: remainingLeft, firstRight :: remainingRight =>
    if firstLeft.kindArity != firstRight.kindArity
        || firstLeft.canonical != firstRight.canonical
        || firstLeft.domains != firstRight.domains then
      pure false
    else do
      let same ← Lean.withoutModifyingState do
        isDefEq firstLeft.candidate firstRight.candidate
      if same then
        providerCandidateAssignmentsDefEq remainingLeft remainingRight
      else pure false
  | _, _ => pure false

-- Resolve a fixed ordered obligation list by applying active instance
-- heads in the same order as Lean's resolver.  Return the successful
-- metavariable context as data: every branch itself is backtracked, so a
-- failed closure cannot constrain its sibling and the caller can install
-- only the one complete context it selected.  Fuel bounds recursive
-- instance-premise chains independently of the outer inspected-head cap.
-- This counter lives outside the rollbackable Meta state: failed
-- instance branches still consume work. It bounds search, never type
-- arity or the shape of an accepted complete assignment.
def takeProviderResolutionAttempt (remaining : IO.Ref Nat) : MetaM Bool := do
  match ← remaining.get with
  | 0 => pure false
  | Nat.succ count => remaining.set count; pure true

partial def closeProviderConstraints (remaining : IO.Ref Nat)
    (fuel : Nat) (pending : List Expr)
    : MetaM (Option MetavarContext) := do
  match fuel, pending with
  | 0, _ => pure none
  | _, [] => pure (some (← getMCtx))
  | Nat.succ fuel, goal :: rest => do
    let constraint ← instantiateMVars (← inferType goal)
    let instances ← try
      Lean.Meta.SynthInstance.getInstances constraint
    catch _ =>
      pure #[]
    for inst in instances.toList.reverse do
      unless ← takeProviderResolutionAttempt remaining do return none
      let closed? ← Lean.withoutModifyingState do
        match ← Lean.Meta.SynthInstance.tryResolve goal inst with
        | none => pure none
        | some (mctx, subgoals) => withMCtx mctx do
          closeProviderConstraints remaining fuel (subgoals ++ rest)
      match closed? with
      | some mctx => return some mctx
      | none => pure ()
    pure none

-- Match active instance heads independently, in Lean's resolver order,
-- and record each complete ordered ground-kinded assignment they induce.
-- Each attempted head and its complete constraint closure run under a
-- restored metavariable state so one choice cannot constrain a later
-- choice.  The selected head stays fixed while its instance subgoals and
-- every other erased provider constraint are resolved in that same mctx.
-- A head whose closure fails or leaves one opened type argument unresolved
-- contributes no partial candidate pool.
-- The inventory is provider-local and bounded: 32 heads inspected, 16
-- distinct complete assignments, and 128 instance-resolution attempts
-- shared by all heads and all recursive constraint branches.
partial def providerInstantiationAssignments (fuel : Nat) (source : Expr)
    : MetaM (Array (Array ProviderCandidateFragment)) := do
  let binders ← leadingTypeBinderNames fuel source
  let (typeArgs, constraints) ← providerEvidenceSpine fuel binders.size source
  if typeArgs.isEmpty || constraints.isEmpty then return #[]
  let remaining ← IO.mkRef (128 : Nat)
  let mut inspected := 0
  let mut assignments : Array (Array ProviderCandidateFragment) := #[]
  for constraint in constraints, constraintIndex in [:constraints.size] do
    if inspected < 32 && assignments.size < 16 then
      let instances ← try
        Lean.Meta.SynthInstance.getInstances constraint
      catch _ =>
        pure #[]
      for inst in instances.toList.reverse do
        if inspected < 32 && assignments.size < 16 then
          unless ← takeProviderResolutionAttempt remaining do return assignments
          inspected := inspected + 1
          let assignment? ← Lean.withoutModifyingState do
            let goal ← mkFreshExprMVar constraint MetavarKind.synthetic
            match ← Lean.Meta.SynthInstance.tryResolve goal inst with
            | none => pure none
            | some (mctx, subgoals) => withMCtx mctx do
              -- `tryResolve` fixes the seeded head.  Its own subgoals stay
              -- first; every other erased provider constraint follows in
              -- source order under that same assignment context.
              let mut pending := subgoals
              for otherConstraint in constraints,
                  otherIndex in [:constraints.size] do
                if otherIndex != constraintIndex then
                  let otherGoal ← mkFreshExprMVar otherConstraint
                    MetavarKind.synthetic
                  pending := pending ++ [otherGoal]
              match ← closeProviderConstraints remaining fuel pending with
              | none => pure none
              | some closedMCtx => withMCtx closedMCtx do
                let mut arguments : Array ProviderCandidateFragment := #[]
                let mut complete := true
                for candidate in typeArgs do
                  match ← providerCandidateFragment? fuel candidate with
                  | none => complete := false
                  | some fragment => arguments := arguments.push fragment
                if complete && arguments.size == typeArgs.size then
                  pure (some arguments)
                else pure none
          match assignment? with
          | some assignment => do
            let mut duplicate := false
            for previous in assignments do
              if !duplicate then
                let same ← providerCandidateAssignmentsDefEq
                  previous.toList assignment.toList
                if same then duplicate := true
            if assignments.size < 16 && !duplicate then
              assignments := assignments.push assignment
          | none => pure ()
  pure assignments

-- Optional evidence gets at most 2000 additional Lean heartbeats,
-- clamped to the remaining command allowance. This is a local search
-- boundary: it never resets or increases the outer command budget.
def withProviderAssignmentBudget
    (action : MetaM (Array (Array ProviderCandidateFragment)))
    : MetaM (Array (Array ProviderCandidateFragment)) := do
  Core.checkSystem "provider discovery"
  let context ← readThe Core.Context
  let started ← IO.getNumHeartbeats
  let allowance := if context.maxHeartbeats == 0 then 2000000 else
    min 2000000 (context.maxHeartbeats - (started - context.initHeartbeats))
  let result ← tryCatchRuntimeEx
    (withTheReader Core.Context (fun current =>
        { current with initHeartbeats := started, maxHeartbeats := max 1 allowance }) do
      Lean.withoutModifyingState action)
    (fun ex => do
      -- A local timeout is optional evidence failure; exhaustion of the
      -- original command allowance must still propagate. Interrupts are
      -- always rethrown by tryCatchRuntimeEx before reaching this handler.
      Core.checkSystem "provider discovery"
      if ex.isRuntime && !ex.isMaxHeartbeat then throw ex
      pure #[])
  Core.checkSystem "provider discovery"
  pure result

-- Phase-3 vanguard: library premises.  A goal that mentions a
-- recursive inductive brings rated library functions with it,
-- instantiated at the goal's own element types ("recursion via
-- library reuse", SYNTHESIS_PROPOSAL.md § 4).  Offers only - the
-- driver filters them and the backend verifies every candidate, so
-- a useless premise costs search time, never soundness.

def libInventory : List Name :=
  []

-- How many leading type parameters an inventory entry takes: its
-- leading sort-typed binders, the ones the offers instantiate.
def invArity : Expr → Nat
  | Expr.forallE _ t b _ =>
    if t.isSort then 1 + invArity b else 0
  | _ => 0

-- All assignments of `arity` type parameters drawn from `tys`.
def assignments : Nat → List Expr → List (List Expr)
  | 0, _ => [[]]
  | Nat.succ k, tys =>
    (assignments k tys).foldr
      (fun rest acc =>
        tys.foldr (fun t acc2 => (t :: rest) :: acc2) acc)
      []

-- Recursive-inductive occurrences reachable without crossing a
-- binder (an occurrence under a nested quantifier could mention its
-- bound variable, which no top-level premise may reference).
partial def collectSafe (fuel : Nat) (e : Expr)
    : MetaM (Array Expr) := do
  match fuel with
  | 0 => pure #[]
  | Nat.succ fuel => do
    let e ← whnfR e.consumeMData
    match e with
    | Expr.forallE _ t b _ =>
      if b.hasLooseBVars then pure #[]
      else pure ((← collectSafe fuel t) ++ (← collectSafe fuel b))
    | _ =>
      match e.getAppFn with
      | Expr.const n _ => do
        let mut acc := #[]
        if let some (ConstantInfo.inductInfo iv) :=
            (← getEnv).find? n then
          if iv.numIndices == 0 && (iv.isRec || iv.isNested)
              && !iv.isUnsafe && iv.all.length == 1
              && e.getAppNumArgs == iv.numParams then
            acc := acc.push e
        for a in e.getAppArgs do
          acc := acc ++ (← collectSafe fuel a)
        pure acc
      | _ => pure #[]

-- Substitute the leading type parameters of a constant's type.
def instHead : Nat → Expr → List Expr → Option Expr
  | 0, t, _ => some t
  | Nat.succ k, Expr.forallE _ _ b _, a :: as =>
    instHead k (b.instantiate1 a) as
  | _, _, _ => none

-- Instantiate the table's functions at the goal's own types and
-- serialize each instantiated type through `go`, so premise atoms
-- share the goal's display keys.  The instantiation is syntactic
-- (fresh level metavariables, direct substitution, no unification):
-- an auto-implicit goal variable lives at a rigid `Sort u` that a
-- typechecked instantiation could never meet, yet the candidate
-- that uses the premise re-elaborates against the pretty-printed
-- goal, where auto-implicits are flexible again.  Verification is
-- the arbiter; an unusable offer just fails there.
def mkPremises (occs : Array Expr) : MetaM String := do
  let mut okeys : List String := []
  let mut uniq : List Expr := []
  for o in occs do
    let k := toString (← Meta.ppExpr o)
    if !okeys.contains k then
      okeys := okeys ++ [k]
      uniq := uniq ++ [o]
  -- instantiation candidates: the goal's own type variables (the
  -- sort-typed locals - auto-implicits arrive as free fvars, spine
  -- binders as the s-locals premSpine introduced), then the
  -- occurrences' element types
  let mut tkeys : List String := []
  let mut tys : List Expr := []
  for fvarId in (← getLCtx).getFVarIds do
    let d ← fvarId.getDecl
    if !d.isImplementationDetail then
      let t ← whnfR d.type
      if t.isSort then
        let k := toString (← Meta.ppExpr (Expr.fvar fvarId))
        if !tkeys.contains k && tkeys.length < 5 then
          tkeys := tkeys ++ [k]
          tys := tys ++ [Expr.fvar fvarId]
  for o in uniq do
    for a in o.getAppArgs do
      let k := toString (← Meta.ppExpr a)
      if !tkeys.contains k && tkeys.length < 5 then
        tkeys := tkeys ++ [k]
        tys := tys ++ [a]
  let env ← getEnv
  let heads := uniq.map (fun o => o.getAppFn.constName!)
  let mut out := ""
  for fn in libInventory do
    if let some info := env.find? fn then
      let arity := invArity info.type
      -- an entry fires when its type mentions one of the goal's
      -- recursive inductives; the driver's filter then insists the
      -- instantiated type mentions no inductive the goal lacks
      if arity ≤ 3
          && info.type.getUsedConstants.any
               (fun n => heads.contains n) then
        for asg in assignments arity tys do
          try
            let us ← Meta.mkFreshLevelMVars info.numLevelParams
            let ty0 := info.instantiateTypeLevelParams us
            if let some ty := instHead arity ty0 asg then
              let s ← go false false 100 0 [] ty
              out := out ++ " (prem " ++ esc fn.toString
                ++ " " ++ s ++ ")"
          catch _ => pure ()
  pure out

-- Walk the goal's leading spine exactly as `go` does (same binder
-- names, same depth counter, so premise types and the goal agree on
-- variable spellings and occurrence keys), collecting binder-free
-- occurrences from the domains, then emit the premise offers.
partial def premSpine (fuel depth : Nat) (acc : Array Expr)
    (e : Expr) : MetaM String := do
  match fuel with
  | 0 => mkPremises acc
  | Nat.succ fuel => do
    let e ← instantiateMVars e
    let e ← whnfR e.consumeMData
    match e with
    | Expr.forallE _ t b _ =>
      if b.hasLooseBVars then do
        let ts ← whnfR t
        if ts.isSort then
          withLocalDeclD (Name.mkSimple ("s" ++ toString depth)) t
              fun fv =>
            premSpine fuel (depth + 1) acc (b.instantiate1 fv)
        else mkPremises acc
      else do
        let acc := acc ++ (← collectSafe fuel t)
        premSpine fuel depth acc b
    | _ => do
      let acc := acc ++ (← collectSafe fuel e)
      mkPremises acc

end LeantSynth

namespace LeantSynth
open Lean Meta
partial def exhaustAssignmentBudget : MetaM (Array (Array ProviderCandidateFragment)) := do
  Core.checkSystem "injected expensive assignment"
  let _ ← mkFreshExprMVar (mkSort .zero)
  exhaustAssignmentBudget
end LeantSynth

open Lean Meta Elab Command in run_cmd do
  Lean.Elab.Command.liftTermElabM do
    let remaining ← IO.mkRef (1 : Nat)
    Lean.withoutModifyingState do
      unless ← LeantSynth.takeProviderResolutionAttempt remaining do
        throwError "first resolution attempt was rejected"
    if ← LeantSynth.takeProviderResolutionAttempt remaining then
      throwError "Meta rollback replenished the resolution quota"

open Lean Meta Elab Command in
set_option linter.unusedVariables false in
run_cmd do
  Lean.Elab.Command.liftTermElabM do
    let env ← getEnv
    let roots : List String := ["Or"]
    let targetHead : Option String := some "Or"
    let sessions : List String := []
    let aux : List String :=
      ["rec", "recOn", "casesOn", "brecOn", "binductionOn",
       "below", "ibelow", "noConfusion", "noConfusionType",
       "ctorElim", "ctorElimType", "ctorIdx", "sizeOf_spec",
       "injEq", "inj", "eq_def", "decEq"]
    let keep (n : Name) : Bool :=
      !n.isInternalDetail &&
      !n.components.any fun c => match c with
        | .str _ s => s.startsWith "it!" || aux.contains s
        | _ => false
    let implementationWorker (n : Name) : Bool :=
      match n with
      | .str _ s =>
        s == "go" || s == "loop"
          || s.endsWith "TR" || s.endsWith "Impl"
          || s.endsWith "Aux"
      | _ => false
    let names := env.constants.fold (init := #[]) fun a n _ =>
      if keep n && (roots.contains n.getRoot.toString
          || sessions.contains n.toString) then a.push n else a
    let shorter (a b : Name) : Bool :=
      let sa := a.toString
      let sb := b.toString
      if sa.length == sb.length then sa < sb else sa.length < sb.length
    let sorted := names.qsort shorter
    let sessionCandidates := sorted.toList.filter fun n =>
      sessions.contains n.toString
    let otherCandidates := sorted.toList.filter fun n =>
      !sessions.contains n.toString
    let mut sessionPreferred : Array Name := #[]
    let mut preferred : Array Name := #[]
    let mut sessionFallback : Array Name := #[]
    let mut fallback : Array Name := #[]
    let mut workerPreferred : Array Name := #[]
    let mut workerFallback : Array Name := #[]
    -- Exact session declarations bypass the root-pool scan cap.
    for n in sessionCandidates ++ otherCandidates.take 2048 do
      match env.find? n with
      | none => pure ()
      | some info =>
        let typeLevel ← LeantSynth.resultIsSort info.type
        if typeLevel then pure () else
          let head ← LeantSynth.resultHead? info.type
          let exactHead := head.map (fun n => n.toString) == targetHead
          let session := sessions.contains n.toString
          if session then
            if exactHead then
              sessionPreferred := sessionPreferred.push n
            else
              sessionFallback := sessionFallback.push n
          else if implementationWorker n then
            if exactHead then
              workerPreferred := workerPreferred.push n
            else
              workerFallback := workerFallback.push n
          else if exactHead then
            preferred := preferred.push n
          else
            fallback := fallback.push n
    let chosen := (sessionPreferred.toList ++ preferred.toList
      ++ sessionFallback.toList ++ fallback.toList
      ++ workerPreferred.toList ++ workerFallback.toList).take 80
    let mut body := ""
    for n in chosen do
      match env.find? n with
      | none => pure ()
      | some info =>
        let frag ← LeantSynth.go true false 80 0 [] info.type
        let binders ← LeantSynth.leadingTypeBinderNames 80 info.type
        -- Exact assignments are optional evidence. A difficult instance
        -- branch must not erase this provider or earlier inventory entries.
        let assignments ← LeantSynth.withProviderAssignmentBudget do
          LeantSynth.providerInstantiationAssignments 80 info.type
        let binderText := String.join
          (binders.toList.map fun binder =>
            " " ++ LeantSynth.esc binder)
        let assignmentText := String.join
          (assignments.toList.map fun assignment =>
            " (args" ++ String.join
              (assignment.toList.map fun argument =>
                " (kinded " ++ toString argument.kindArity ++ " "
                  ++ argument.payload ++ ")")
              ++ ")")
        let evidenceText := if assignments.isEmpty then "" else
          " (instantiations" ++ assignmentText ++ ")"
        body := body ++ " (provider " ++ LeantSynth.esc n.toString
          ++ " (binders" ++ binderText ++ ")" ++ evidenceText
          ++ " " ++ frag ++ ")"
    logInfo ("(providers" ++ body ++ ")")

