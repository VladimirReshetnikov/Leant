-- Independent source reset segment 0
axiom Demo.Secret : Type
axiom Demo.secretValue : Demo.Secret
inductive Demo.Guard (a : Type 1) : Type 1 where
| mk : Demo.Secret → a → Demo.Guard a

inductive Demo.Phantom2 (a b : Type 1) : Type 1 where
| mk : Demo.Phantom2 a b

def Demo.termByType (_ : Type) : Nat := 0
inductive Demo.Tag (n : Nat) : Type where
| mk : Demo.Tag n

noncomputable def goldenReplayQuery0Candidate1 : ((∀ a : Type 1, Option a) → Option (∀ b : Type, b → b)) :=
  fun x => x _
#print axioms goldenReplayQuery0Candidate1
noncomputable def goldenReplayQuery0Candidate2 : ((∀ a : Type 1, Option a) → Option (∀ b : Type, b → b)) :=
  fun x => match Sum.inr (x _) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery0Candidate2
noncomputable def goldenReplayQuery0Candidate3 : ((∀ a : Type 1, Option a) → Option (∀ b : Type, b → b)) :=
  fun x => match Sum.inr (x _) with | .inl a => Option.some a | .inr b => b
#print axioms goldenReplayQuery0Candidate3
noncomputable def goldenReplayQuery0Candidate4 : ((∀ a : Type 1, Option a) → Option (∀ b : Type, b → b)) :=
  fun x => match Sum.inl (x _) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery0Candidate4
noncomputable def goldenReplayQuery0Candidate5 : ((∀ a : Type 1, Option a) → Option (∀ b : Type, b → b)) :=
  fun x => match Sum.inl (x _) with | .inl a => a | .inr b => Option.some b
#print axioms goldenReplayQuery0Candidate5
noncomputable def goldenReplayQuery1Candidate1 : ((∀ a b : Type 1, Demo.Phantom2 a b) → Demo.Phantom2 (∀ x : Type, x → x) (∀ y : Type, y → y)) :=
  fun x => x _ _
#print axioms goldenReplayQuery1Candidate1
noncomputable def goldenReplayQuery1Candidate2 : ((∀ a b : Type 1, Demo.Phantom2 a b) → Demo.Phantom2 (∀ x : Type, x → x) (∀ y : Type, y → y)) :=
  fun x => match Sum.inr (x _ _) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery1Candidate2
noncomputable def goldenReplayQuery1Candidate3 : ((∀ a b : Type 1, Demo.Phantom2 a b) → Demo.Phantom2 (∀ x : Type, x → x) (∀ y : Type, y → y)) :=
  fun x => match Sum.inl (x _ _) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery1Candidate3
noncomputable def goldenReplayQuery2Candidate1 : ((∀ a : Type 1, Demo.Guard a) → Demo.Guard (∀ b : Type, b → b)) :=
  fun x => x _
#print axioms goldenReplayQuery2Candidate1
noncomputable def goldenReplayQuery2Candidate2 : ((∀ a : Type 1, Demo.Guard a) → Demo.Guard (∀ b : Type, b → b)) :=
  fun x => match Sum.inr (x _) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery2Candidate2
noncomputable def goldenReplayQuery2Candidate3 : ((∀ a : Type 1, Demo.Guard a) → Demo.Guard (∀ b : Type, b → b)) :=
  fun x => match Sum.inl (x _) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery2Candidate3
noncomputable def goldenReplayQuery3Candidate1 : Demo.Secret :=
  Demo.secretValue
#print axioms goldenReplayQuery3Candidate1
noncomputable def goldenReplayQuery3Candidate2 : Demo.Secret :=
  match Sum.inl Demo.secretValue with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery3Candidate2
noncomputable def goldenReplayQuery3Candidate3 : Demo.Secret :=
  match Sum.inr Demo.secretValue with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery3Candidate3
noncomputable def goldenReplayQuery4Candidate1 : (Unit → Demo.Secret) :=
  fun x => let y := x; match y with | _ => Demo.secretValue
#print axioms goldenReplayQuery4Candidate1
noncomputable def goldenReplayQuery4Candidate2 : (Unit → Demo.Secret) :=
  fun x => let y := x; match y with | _ => (match Sum.inr Demo.secretValue with | .inl a => a | .inr b => b)
#print axioms goldenReplayQuery4Candidate2
noncomputable def goldenReplayQuery4Candidate3 : (Unit → Demo.Secret) :=
  fun x => let y := x; match y with | _ => (match Sum.inl Demo.secretValue with | .inl a => a | .inr b => b)
#print axioms goldenReplayQuery4Candidate3
