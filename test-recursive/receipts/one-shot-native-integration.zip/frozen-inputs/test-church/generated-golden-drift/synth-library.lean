set_option linter.unusedVariables false
noncomputable section
def goldenReplayQuery0Candidate1 : ((a → b) → List a → List b) :=
  fun f x => List.map f x
#print axioms goldenReplayQuery0Candidate1
def goldenReplayQuery0Candidate2 : ((a → b) → List a → List b) :=
  fun f x => List.reverse (List.map f x)
#print axioms goldenReplayQuery0Candidate2
def goldenReplayQuery0Candidate3 : ((a → b) → List a → List b) :=
  fun f x => List.map (fun a => a) (List.map f x)
#print axioms goldenReplayQuery0Candidate3
def goldenReplayQuery0Candidate4 : ((a → b) → List a → List b) :=
  fun f x => List.map (fun a => a) (List.reverse (List.map f x))
#print axioms goldenReplayQuery0Candidate4
def goldenReplayQuery0Candidate5 : ((a → b) → List a → List b) :=
  fun f x => List.append (List.map f x) (List.map f x)
#print axioms goldenReplayQuery0Candidate5
def goldenReplayQuery2Candidate1 : (List (List a) → List a) :=
  fun x => List.flatten x
#print axioms goldenReplayQuery2Candidate1
def goldenReplayQuery2Candidate2 : (List (List a) → List a) :=
  fun x => List.reverse (List.flatten x)
#print axioms goldenReplayQuery2Candidate2
def goldenReplayQuery2Candidate3 : (List (List a) → List a) :=
  fun x => List.map (fun a => a) (List.flatten x)
#print axioms goldenReplayQuery2Candidate3
def goldenReplayQuery2Candidate4 : (List (List a) → List a) :=
  fun x => List.append (List.flatten x) (List.flatten x)
#print axioms goldenReplayQuery2Candidate4
def goldenReplayQuery2Candidate5 : (List (List a) → List a) :=
  fun _ => .nil
#print axioms goldenReplayQuery2Candidate5
