set_option linter.unusedVariables false
noncomputable section
namespace FiveBinder
axiom Five : Type → Type → Type → Type → Type → Type
axiom Token : Type
class Choice (one two three four five : Type 1) : Prop where witness : True
instance : Choice (∀ A : Type, A → A) (∀ B : Type, B → B → B) (∀ C : Type, C → C → C → C) (∀ D : Type, D → D → D → D → D) (∀ E : Type, E → E → E → E → E → E) := ⟨True.intro⟩
axiom chosen {one two three four five : Type 1} [Choice one two three four five] : Token
end FiveBinder

def goldenReplayQuery2Candidate1 : FiveBinder.Token :=
  FiveBinder.chosen («one» := (∀ (a0_0 : Type _), a0_0 → a0_0)) («two» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0)) («three» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0)) («four» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0)) («five» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0))
#print axioms goldenReplayQuery2Candidate1
def goldenReplayQuery2Candidate2 : FiveBinder.Token :=
  match Sum.inl (FiveBinder.chosen («one» := (∀ (a0_0 : Type _), a0_0 → a0_0)) («two» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0)) («three» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0)) («four» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0)) («five» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery2Candidate2
def goldenReplayQuery4Candidate1 : FiveBinder.Token :=
  FiveBinder.chosen («one» := (∀ (a0_0 : Type _), a0_0 → a0_0)) («two» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0)) («three» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0)) («four» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0)) («five» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0))
#print axioms goldenReplayQuery4Candidate1
def goldenReplayQuery4Candidate2 : FiveBinder.Token :=
  match Sum.inl (FiveBinder.chosen («one» := (∀ (a0_0 : Type _), a0_0 → a0_0)) («two» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0)) («three» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0)) («four» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0)) («five» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery4Candidate2
def goldenReplayQuery4Candidate3 : FiveBinder.Token :=
  match Sum.inr (FiveBinder.chosen («one» := (∀ (a0_0 : Type _), a0_0 → a0_0)) («two» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0)) («three» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0)) («four» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0)) («five» := (∀ (a0_0 : Type _), a0_0 → a0_0 → a0_0 → a0_0 → a0_0 → a0_0))) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery4Candidate3
