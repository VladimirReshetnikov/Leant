set_option linter.unusedVariables false
noncomputable section
axiom Demo.Seed : Type
axiom Demo.seedValue : Demo.Seed
universe u
inductive Demo.SealedBox (a : Type u) : Type u where
| mk (value : a) (proof : value = value) : Demo.SealedBox a

def Demo.sealedBox {a : Type u} (value : a) : Demo.SealedBox a :=
  .mk value rfl

def Demo.seedIdentity (value : Demo.Seed) : Demo.Seed := value

axiom Demo.Input : Type → Type
axiom Demo.Middle : Type → Type
axiom Demo.Output : Type → Type
axiom Demo.Index : Type
axiom Demo.consume {a : Type} : Demo.Middle a → Demo.Output a
axiom Demo.produce {a : Type} : Demo.Input a → Demo.Middle a

axiom Demo.Token : Type
class Demo.C (a : Type) : Prop where witness : True
instance : Demo.C Nat := ⟨True.intro⟩
axiom Demo.global {a : Type} [Demo.C a] : Demo.Token

def goldenReplayQuery4Candidate1 : ((∀ x : Type, x → x) → Demo.SealedBox (∀ x : Type, x → x)) :=
  fun f => Demo.sealedBox f
#print axioms goldenReplayQuery4Candidate1
def goldenReplayQuery4Candidate2 : ((∀ x : Type, x → x) → Demo.SealedBox (∀ x : Type, x → x)) :=
  fun _ => Demo.sealedBox (fun _ x => x)
#print axioms goldenReplayQuery4Candidate2
def goldenReplayQuery7Candidate1 : (Demo.Seed → Demo.SealedBox Demo.Seed) :=
  Demo.sealedBox
#print axioms goldenReplayQuery7Candidate1
def goldenReplayQuery7Candidate2 : (Demo.Seed → Demo.SealedBox Demo.Seed) :=
  fun x => match Sum.inl x with | .inl a => Demo.sealedBox a | .inr b => b
#print axioms goldenReplayQuery7Candidate2
def goldenReplayQuery7Candidate3 : (Demo.Seed → Demo.SealedBox Demo.Seed) :=
  fun x => match Sum.inr x with | .inl a => a | .inr b => Demo.sealedBox b
#print axioms goldenReplayQuery7Candidate3
def goldenReplayQuery7Candidate4 : (Demo.Seed → Demo.SealedBox Demo.Seed) :=
  fun x => Demo.sealedBox (match Sum.inl x with | .inl a => a | .inr b => b)
#print axioms goldenReplayQuery7Candidate4
def goldenReplayQuery7Candidate5 : (Demo.Seed → Demo.SealedBox Demo.Seed) :=
  fun x => Demo.sealedBox (match Sum.inr x with | .inl a => a | .inr b => b)
#print axioms goldenReplayQuery7Candidate5

def goldenReplayQuery8Candidate1 : (Nat → Demo.Token) :=
  fun x => match x with | .zero => Demo.global («a» := Nat) | .succ _ => Demo.global («a» := Nat)
#print axioms goldenReplayQuery8Candidate1
def goldenReplayQuery8Candidate2 : (Nat → Demo.Token) :=
  fun x => match x with | Nat.zero => Demo.global («a» := Nat) | Nat.succ y => (match Nat.succ y with | Nat.zero => Demo.global («a» := Nat) | Nat.succ _ => Demo.global («a» := Nat))
#print axioms goldenReplayQuery8Candidate2
def goldenReplayQuery8Candidate3 : (Nat → Demo.Token) :=
  fun x => match x with | Nat.zero => (match Sum.inr x with | .inl a => a | .inr _ => Demo.global («a» := Nat)) | Nat.succ _ => Demo.global («a» := Nat)
#print axioms goldenReplayQuery8Candidate3
def goldenReplayQuery8Candidate4 : (Nat → Demo.Token) :=
  fun x => match x with | Nat.zero => (match Nat.succ x with | Nat.zero => Demo.global («a» := Nat) | Nat.succ _ => Demo.global («a» := Nat)) | Nat.succ _ => Demo.global («a» := Nat)
#print axioms goldenReplayQuery8Candidate4
def goldenReplayQuery8Candidate5 : (Nat → Demo.Token) :=
  fun x => match x with | Nat.zero => Demo.global («a» := Nat) | Nat.succ _ => (match Nat.succ x with | Nat.zero => Demo.global («a» := Nat) | Nat.succ _ => Demo.global («a» := Nat))
#print axioms goldenReplayQuery8Candidate5
def goldenReplayQuery10Candidate1 : (Nat → Demo.Token) :=
  fun _ => Demo.global («a» := Nat)
#print axioms goldenReplayQuery10Candidate1
def goldenReplayQuery10Candidate2 : (Nat → Demo.Token) :=
  fun x => match x with | .zero => Demo.global («a» := Nat) | .succ _ => Demo.global («a» := Nat)
#print axioms goldenReplayQuery10Candidate2
def goldenReplayQuery10Candidate3 : (Nat → Demo.Token) :=
  fun x => match x with | Nat.zero => Demo.global («a» := Nat) | Nat.succ y => (match Nat.succ y with | Nat.zero => Demo.global («a» := Nat) | Nat.succ _ => Demo.global («a» := Nat))
#print axioms goldenReplayQuery10Candidate3
def goldenReplayQuery10Candidate4 : (Nat → Demo.Token) :=
  fun x => match x with | Nat.zero => (match Sum.inr x with | .inl a => a | .inr _ => Demo.global («a» := Nat)) | Nat.succ _ => Demo.global («a» := Nat)
#print axioms goldenReplayQuery10Candidate4
def goldenReplayQuery10Candidate5 : (Nat → Demo.Token) :=
  fun x => match x with | Nat.zero => (match Nat.succ x with | Nat.zero => Demo.global («a» := Nat) | Nat.succ _ => Demo.global («a» := Nat)) | Nat.succ _ => Demo.global («a» := Nat)
#print axioms goldenReplayQuery10Candidate5
