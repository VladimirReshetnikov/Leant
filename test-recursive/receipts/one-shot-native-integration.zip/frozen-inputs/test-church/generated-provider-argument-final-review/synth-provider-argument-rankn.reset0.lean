-- Independent source reset segment 0
axiom ProviderLambda.Result : Type
axiom ProviderLambda.consume : (∀ A : Type, A → A) → ProviderLambda.Result
noncomputable def goldenReplayQuery0Candidate1 : ProviderLambda.Result :=
  ProviderLambda.consume (fun _ x => x)
#print axioms goldenReplayQuery0Candidate1
noncomputable def goldenReplayQuery0Candidate2 : ProviderLambda.Result :=
  match Sum.inl (ProviderLambda.consume (fun _ x => x)) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery0Candidate2
noncomputable def goldenReplayQuery0Candidate3 : ProviderLambda.Result :=
  match Sum.inr (ProviderLambda.consume (fun _ x => x)) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery0Candidate3
noncomputable def goldenReplayQuery1Candidate1 : ProviderLambda.Result :=
  ProviderLambda.consume (fun _ x => x)
#print axioms goldenReplayQuery1Candidate1
noncomputable def goldenReplayQuery1Candidate2 : ProviderLambda.Result :=
  match Sum.inl (ProviderLambda.consume (fun _ x => x)) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery1Candidate2
noncomputable def goldenReplayQuery1Candidate3 : ProviderLambda.Result :=
  match Sum.inr (ProviderLambda.consume (fun _ x => x)) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery1Candidate3
