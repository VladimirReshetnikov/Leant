set_option linter.unusedVariables false
namespace ChurchLayered
axiom Seed : Type
axiom seed : Seed
axiom G2 : Type 1 → Type 1 → Type 1
axiom G3 : Type 1 → Type 1 → Type 1 → Type 1
axiom maker2 : Seed → ∀ a : Type 1, a → Seed → ∀ b : Type 1, b → G2 a b
axiom maker3 : Seed → ∀ a b : Type 1, a → b → Seed → ∀ c : Type 1, c → G3 a b c
end ChurchLayered
noncomputable section
