-- Independent source reset segment 0
def double (n : Nat) : Nat := n + n
axiom Wrap : Type 1 → Type
noncomputable def goldenReplayQuery18Candidate1 : (∀ (F : Type 1 → Type), (∀ a : Type 1, F a) → F (∀ b : Type, b → b)) :=
  fun _ x => x _
#print axioms goldenReplayQuery18Candidate1
noncomputable def goldenReplayQuery18Candidate2 : (∀ (F : Type 1 → Type), (∀ a : Type 1, F a) → F (∀ b : Type, b → b)) :=
  fun _ x => match Sum.inr (x _) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery18Candidate2
noncomputable def goldenReplayQuery18Candidate3 : (∀ (F : Type 1 → Type), (∀ a : Type 1, F a) → F (∀ b : Type, b → b)) :=
  fun _ x => match Sum.inl (x _) with | .inl a => a | .inr b => b
#print axioms goldenReplayQuery18Candidate3
noncomputable def goldenReplayQuery21Candidate1 : (Nat → a → List a) :=
  fun x y => List.replicate x y
#print axioms goldenReplayQuery21Candidate1
noncomputable def goldenReplayQuery21Candidate2 : (Nat → a → List a) :=
  fun x y => List.reverse (List.replicate x y)
#print axioms goldenReplayQuery21Candidate2
noncomputable def goldenReplayQuery21Candidate3 : (Nat → a → List a) :=
  fun x y => List.map (fun a => a) (List.replicate x y)
#print axioms goldenReplayQuery21Candidate3
noncomputable def goldenReplayQuery21Candidate4 : (Nat → a → List a) :=
  fun x y => List.append (List.replicate x y) (List.replicate x y)
#print axioms goldenReplayQuery21Candidate4
noncomputable def goldenReplayQuery21Candidate5 : (Nat → a → List a) :=
  fun x y => List.flatMap (fun _ => List.replicate x y) (List.replicate x y)
#print axioms goldenReplayQuery21Candidate5
