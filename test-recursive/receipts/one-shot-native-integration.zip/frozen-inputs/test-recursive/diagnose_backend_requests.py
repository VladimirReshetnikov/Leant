"""Measure the raw Lean REPL boundary independently of Leant and synthesis.

This is a diagnostic, not behavioral acceptance. Each fresh owned process gets
the same startup probe and an exact supplied Lean program. Both requests are
queued before startup; response-file visibility separates startup from the
subsequent request. It does not measure Leant's write/flush or Haskell scheduling.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "lib/Djex/test-church"))
from behavior_runtime import Processes, prepare_output_directory, sha256, write_json


class Responses:
    interval = 0.02

    def __init__(self):
        self.pending = b""
        self.lines = []
        self.events = []
        self.offset = 0

    def poll(self, capture, started, *, final=False):
        self.pending += capture.read()
        while b"\n" in self.pending:
            line, self.pending = self.pending.split(b"\n", 1)
            self.offset += len(line) + 1
            line = line.rstrip(b"\r")
            if line:
                self.lines.append(line)
            elif self.lines:
                self.flush(started)
        if final and (self.pending or self.lines):
            if self.pending:
                self.lines.append(self.pending)
                self.pending = b""
            self.flush(started)

    def flush(self, started):
        raw = b"\n".join(self.lines)
        self.lines = []
        event = {"response_index": len(self.events),
                 "observed_seconds": time.monotonic() - started,
                 "stdout_byte_offset": self.offset,
                 "response_text": raw.decode("utf-8", errors="replace")}
        try:
            event["response"] = json.loads(raw)
        except (ValueError, UnicodeError) as failure:
            event["decode_failure"] = str(failure)
        self.events.append(event)

    def receipt(self):
        return {"clock": "time.monotonic", "poll_interval_seconds": self.interval,
                "measurement": "complete blank-line-delimited response visible in raw stdout capture",
                "origin": "Processes.run entry, including capture setup and process startup",
                "events": self.events}


def success(response):
    return (isinstance(response, dict) and isinstance(response.get("env"), int)
            and not response.get("sorries")
            and not any(m.get("severity") == "error" for m in response.get("messages", [])))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lake", type=Path, required=True)
    parser.add_argument("--repl", type=Path, required=True)
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--program", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--process-timeout", type=int, default=60)
    args = parser.parse_args()
    if not 1 <= args.repeats <= 10 or not 1 <= args.process_timeout <= 300:
        parser.error("repeats must be 1..10 and process timeout 1..300 seconds")
    directory = prepare_output_directory(args.output.resolve())
    program_path = args.program.resolve()
    program = program_path.read_text(encoding="utf-8")
    requests = [{"cmd": "#eval (0 : Nat)"}, {"cmd": program}]
    protocol = "".join(json.dumps(request, ensure_ascii=False) + "\n\n" for request in requests)
    sources = [Path(__file__), ROOT / "lib/Djex/test-church/behavior_runtime.py",
               args.lake.resolve(), args.repl.resolve(), program_path]
    source_hashes = {str(path): sha256(path) for path in sources}
    environment = dict(os.environ)
    environment_digest = hashlib.sha256(json.dumps(sorted(environment.items()),
                                                   ensure_ascii=False).encode("utf-8")).hexdigest()
    report = {"status": "running", "validation_mode": "raw_backend_diagnostic_not_synthesis_acceptance",
              "requests": requests, "program_path": str(program_path),
              "program_raw_sha256": sha256(program_path), "inputs": source_hashes,
              "environment_sha256": environment_digest,
              "thread_settings": {key: environment.get(key) for key in ("GHCRTS", "LEAN_NUM_THREADS")},
              "request_submission": "both JSON requests queued in exact stdin file before startup",
              "request_deadline": None, "process_timeout_seconds": args.process_timeout,
              "runs": []}
    processes = Processes(directory, args.process_timeout)
    try:
        for index in range(args.repeats):
            observed = Responses()
            result = processes.run("raw-" + str(index + 1),
                                   [args.lake.resolve(), "env", args.repl.resolve()],
                                   source=protocol, cwd=args.project.resolve(), env=environment,
                                   observe=observed)
            events = observed.events
            accepted = (result.returncode == 0 and len(events) == 2
                        and all(success(event.get("response")) for event in events))
            report["runs"].append({"index": index + 1, "responses_accepted": accepted,
                "startup_response_seconds": events[0]["observed_seconds"] if events else None,
                "second_response_delta_seconds": (events[1]["observed_seconds"] - events[0]["observed_seconds"]
                                                   if len(events) == 2 else None),
                "events": events, "process": processes.rows[-1]})
            write_json(directory / "results.json", report)
        report["status"] = ("completed_expected_responses" if all(row["responses_accepted"] for row in report["runs"])
                            else "completed_with_discrepancies")
    except Exception as failure:
        report.update(status="failed", failure=str(failure))
    finally:
        after = {str(path): sha256(path) for path in sources}
        report.update(inputs_after=after, inputs_unchanged=source_hashes == after, processes=processes.rows)
        if source_hashes != after:
            report.update(status="failed", failure="diagnostic inputs changed")
        write_json(directory / "results.json", report)
    print(json.dumps({"status": report["status"], "runs": [
        {key: row[key] for key in ("index", "responses_accepted", "startup_response_seconds", "second_response_delta_seconds")}
        for row in report["runs"]]}))
    return 0 if report["status"] == "completed_expected_responses" else 1


if __name__ == "__main__":
    raise SystemExit(main())
