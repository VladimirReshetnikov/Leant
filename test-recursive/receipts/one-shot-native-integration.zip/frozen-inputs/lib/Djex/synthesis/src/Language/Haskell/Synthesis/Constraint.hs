{-# LANGUAGE DeriveTraversable #-}

-- | Backend-independent class-constraint syntax.
--
-- A constraint contains only nominal class identity and backend-owned type
-- arguments.  It deliberately does not embed a class declaration, instance
-- environment, arity, or resolution policy.  This keeps superclass and
-- instance graphs finite values: graph edges mention a 'Name', while each
-- backend resolves that name through its own validated environment.
module Language.Haskell.Synthesis.Constraint
  ( Constraint (..)
  , ConstraintError (..)
  , constraintArity
  , validateKnownConstraintArityWith
  , showsConstraintWith
  , showsConstraintWithName
  , validateConstraintClassName
  , validateConstraint
  ) where

import Data.Maybe (isNothing)
import Control.DeepSeq (NFData (rnf))
import Language.Haskell.Synthesis.Collection (observedListLength)
import Language.Haskell.Synthesis.Name
  ( LexicalClass (ConstructorLike)
  , Name
  , nameLexicalClass
  , nameSpecial
  , renderPrefix
  )

-- | A class name applied to zero or more type arguments.
--
-- The type parameter lets Djinn and Exference retain their current type
-- representations while sharing constraint identity and traversal.
data Constraint ty = Constraint
  { constraintClass :: !Name
    -- ^ Nominal class identity.
  , constraintArguments :: [ty]
    -- ^ Type arguments in source application order.
  }
  deriving (Eq, Ord, Functor, Foldable, Traversable)

-- Render the familiar Haskell surface form.  Argument precedence ensures an
-- application-shaped backend type supplies its own parentheses.
instance Show ty => Show (Constraint ty) where
  showsPrec = showsConstraintWith $ showsPrec 11

instance NFData ty => NFData (Constraint ty) where
  rnf (Constraint className arguments) =
    rnf className `seq` rnf arguments

-- | Lexically malformed class identity.  Arity and declaration lookup remain
-- environment concerns, but every backend can agree that a class occupies the
-- ordinary constructor namespace rather than a value or built-in namespace.
data ConstraintError
  = InvalidConstraintClass Name
    -- ^ The name does not occupy the ordinary constructor namespace.
  deriving (Eq, Ord, Show)

instance NFData ConstraintError where
  rnf (InvalidConstraintClass name) = rnf name

-- | Number of supplied class arguments.  Whether that arity is valid belongs
-- to the declaration environment and may differ for unknown-class policies.
constraintArity :: Constraint ty -> Int
constraintArity = length . constraintArguments

-- | Validate a constraint against a caller-owned table of known class
-- arities. Unknown classes are deliberately retained for the caller's later
-- open- versus closed-world policy. A known argument spine is inspected only
-- through its first impossible cell, so every adapter gets the same bounded
-- behavior for cyclic and oversized caller-built lists.
validateKnownConstraintArityWith
  :: (Name -> Maybe Int)
  -> (Name -> Int -> Int -> error)
  -> Constraint ty
  -> Either error ()
validateKnownConstraintArityWith lookupArity arityFailure constraint =
  case lookupArity name of
    Nothing -> Right ()
    Just expected
      | actual == expected -> Right ()
      | otherwise -> Left $ arityFailure name expected actual
     where
      actual = observedListLength expected $ constraintArguments constraint
 where
  name = constraintClass constraint

-- | Render a constraint once its type layer has supplied the rendering of an
-- argument position. This is the single structural renderer used by both the
-- generic 'Show' instance and the shared source-type renderer; backend type
-- precedence therefore remains a policy of the callback rather than a second
-- constraint traversal.
showsConstraintWith
  :: (ty -> ShowS)
  -> Int
  -> Constraint ty
  -> ShowS
showsConstraintWith = showsConstraintWithName renderPrefix

-- | Generalized 'showsConstraintWith' for a surface that owns its class-name
-- qualification policy.  Separating nominal and argument renderers keeps the
-- constraint traversal shared without forcing either name policy on callers.
showsConstraintWithName
  :: (Name -> String)
  -> (ty -> ShowS)
  -> Int
  -> Constraint ty
  -> ShowS
showsConstraintWithName showClassName showArgument precedence
    (Constraint className arguments) =
  showParen (precedence > 0 && not (null arguments)) $
    showString (showClassName className) . foldr renderArgument id arguments
 where
  renderArgument argument rest =
    showChar ' ' . showArgument argument . rest

-- | Validate a nominal class name without claiming that it is declared.
-- Qualified constructor identifiers and constructor operators are accepted;
-- structural names such as tuples, lists, and function arrows are not classes.
validateConstraintClassName :: Name -> Either ConstraintError ()
validateConstraintClassName name
  | nameLexicalClass name == ConstructorLike
  , isNothing (nameSpecial name) = Right ()
  | otherwise = Left $ InvalidConstraintClass name

-- | Validate the backend-independent part of a constraint.  Type arguments
-- deliberately stay opaque here and are checked by their owning type layer.
validateConstraint :: Constraint ty -> Either ConstraintError ()
validateConstraint = validateConstraintClassName . constraintClass
