open Lean Elab Command in
run_cmd do
  for source in ["∀ (α : Type), Ctx.C α → Nat", "(@global_both_ordinary_cache_legacy_first Nat (@Ctx.C.mk Nat 7) = 14) ∧ (@global_both_ordinary_cache_legacy_first Nat (@Ctx.C.mk Nat 11) = 22) ∧ (@global_both_ordinary_cache_legacy_first Bool (@Ctx.C.mk Bool 11) = 22) ∧ (@global_both_ordinary_cache_legacy_first Bool (@Ctx.C.mk Bool 7) = 14)"] do
    match Parser.runParserCategory (← getEnv) `term source with
    | .ok _ => pure ()
    | .error error => throwError error
