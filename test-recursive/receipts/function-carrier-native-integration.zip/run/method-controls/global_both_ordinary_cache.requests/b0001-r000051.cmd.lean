set_option autoImplicit true in noncomputable example : (∀ (α : Type), Ctx.C α → Nat

) := (fun _ x => let y := x; match y with | ⟨_⟩ => .succ (.zero)
)