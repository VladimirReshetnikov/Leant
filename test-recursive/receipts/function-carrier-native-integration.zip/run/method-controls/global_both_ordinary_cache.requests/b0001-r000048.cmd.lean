set_option autoImplicit true in noncomputable example : (∀ (α : Type), Ctx.C α → Nat

) := (fun _ _ => Nat.zero
)