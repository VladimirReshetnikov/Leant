open Lean Elab Command in
run_cmd do
  for source in ["∀ (α : Type), [Ctx.C α] → Nat", "False"] do
    match Parser.runParserCategory (← getEnv) `term source with
    | .ok _ => pure ()
    | .error error => throwError error
