set_option autoImplicit false in
set_option maxHeartbeats 200000 in
example : ¬ (
let global_both_literal_false : (
∀ (α : Type), [Ctx.C α] → Nat

) := (
((fun (leantType77 : Type) => (fun [leantGiven2x0 : @_root_.«Ctx».«C» (leantType77)] => @(let leantHead44 : (∀ [@_root_.«Ctx».«C» (leantType77)], @_root_.«Nat») := @(let leantHead27 : (∀ (leantBound0x0 : Type) [@_root_.«Ctx».«C» (leantBound0x0)], @_root_.«Nat») := @_root_.«Ctx».«C».«out»; @leantHead27 (leantType77)); @leantHead44 leantGiven2x0))) : (∀ (leantBound0x0 : Type) [@_root_.«Ctx».«C» (leantBound0x0)], @_root_.«Nat»))
); (
False
)) := by decide
