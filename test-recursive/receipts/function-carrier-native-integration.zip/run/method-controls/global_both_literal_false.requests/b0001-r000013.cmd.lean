set_option autoImplicit true in noncomputable example : (∀ (α : Type), [Ctx.C α] → Nat

) := (((fun (leantType6 : Type) => (fun [leantGiven11x0 : @_root_.«Ctx».«C» (leantType6)] => @(let leantHead17 : (∀ [@_root_.«Ctx».«C» (leantType6)], @_root_.«Nat») := @(let leantHead24 : (∀ (leantBound0x0 : Type) [@_root_.«Ctx».«C» (leantBound0x0)], @_root_.«Nat») := @_root_.«Ctx».«C».«out»; @leantHead24 (leantType6)); @leantHead17 leantGiven11x0))) : (∀ (leantBound0x0 : Type) [@_root_.«Ctx».«C» (leantBound0x0)], @_root_.«Nat»))
)