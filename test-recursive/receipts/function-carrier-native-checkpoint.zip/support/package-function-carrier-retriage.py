"""Publish only completed native gates; leave the serial integration running."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import zipfile

ROOT = Path('C:/Leant')
RUN = ROOT / 'dist-newstyle/function-carrier-native-integration-v1'
DEST = ROOT / 'test-recursive/receipts/function-carrier-native-checkpoint'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
assert not DEST.with_suffix('.json').exists()
assert not DEST.with_suffix('.zip').exists()
unit = read(RUN / 'unit/results.json')
methods = read(RUN / 'methods/results.json')
assert unit['status'] == methods['status'] == 'passed'
assert unit['inventory_count'] == unit['suite_summary_count'] == 701
assert unit['sources_unchanged'] and unit['executables_unchanged']
assert len(methods['results']) == 6
assert methods['source_and_input_hashes_unchanged']
assert methods['exact_replay_sources_unchanged']
for path, digest in unit['source_hashes_after'].items():
    assert sha(Path(path).read_bytes()) == digest, path
for path, digest in methods['source_and_input_hashes_after'].items():
    assert sha(Path(path).read_bytes()) == digest, path
dependency = git('-C', 'lib/Djex', 'rev-parse', 'HEAD')
assert dependency == 'bfc3692e891ed2d81846fb2bd6b54ecd51aa7442'
assert not git('-C', 'lib/Djex', 'status', '--porcelain')
checkpoint = {
    'format': 'function-carrier-native-checkpoint-v1',
    'captured_at_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'completed_subset_native_integration_pending',
    'leant_base_revision': git('rev-parse', 'HEAD'),
    'djex_working_revision': dependency,
    'djex_committed_revision': git('ls-tree', 'HEAD', 'lib/Djex').split()[2],
    'completed_gates': {
        'unit': {'tests': 701, 'suite_seconds': unit['suite_seconds'],
                 'archive_member': 'run/unit/results.json'},
        'methods': {'cells': 6, 'archive_member': 'run/methods/results.json'},
    },
    'integration_snapshot': read(RUN / 'results.json'),
    'boundaries': [
        'Only the unit and methods gates contribute accepted coverage here.',
        'The serial integration is still running; this is not its terminal receipt.',
        'No dependency promotion or native tree acceptance is claimed.',
        'The earlier 700/701 failure remains tied to its recorded older revision.',
        'No controlled speedup, worst-case guarantee or full Church behavioral matrix is claimed.',
    ],
}
files = {}
for gate in ['unit', 'methods']:
    for path in (RUN / gate).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts:
            assert path.suffix.lower() not in {'.exe', '.dll', '.olean', '.o'}
            files['run/' + path.relative_to(RUN).as_posix()] = path.read_bytes()
    for suffix in ['stdout.txt', 'stderr.txt']:
        path = RUN / (gate + '.' + suffix)
        if path.exists():
            files['run/' + path.name] = path.read_bytes()
for name in ['validate-function-carrier-native-integration.py',
             'function-carrier-native-build-v1.log',
             'check-function-carrier-native-providers.py']:
    files['support/' + name] = (ROOT / 'dist-newstyle' / name).read_bytes()
for path in (ROOT / 'dist-newstyle/function-carrier-native-providers-v1').rglob('*'):
    if path.is_file():
        assert path.suffix.lower() not in {'.exe', '.dll', '.o'}
        files['focused/' + path.name] = path.read_bytes()
files['support/' + Path(__file__).name] = Path(__file__).read_bytes()
files['checkpoint.json'] = (json.dumps(checkpoint, indent=2) + '\n').encode('utf-8')
manifest = [{'member': name, 'sha256': sha(raw), 'bytes': len(raw)}
            for name, raw in sorted(files.items())]
archive_path = DEST.with_suffix('.zip')
with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, raw in sorted(files.items()):
        archive.writestr(name, raw)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for row in manifest:
        assert sha(archive.read(row['member'])) == row['sha256']
summary = {k: v for k, v in checkpoint.items() if k != 'integration_snapshot'}
summary['archive'] = {'path': archive_path.name, 'sha256': sha(archive_path.read_bytes()),
                      'bytes': archive_path.stat().st_size, 'members': len(manifest),
                      'all_member_hashes_verified': True}
DEST.with_suffix('.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, indent=2))
