from pathlib import Path
import os,re,sys
ROOT=Path('C:/Leant'); sys.path.insert(0,str(ROOT/'lib/Djex/test-church'))
import behavior_runtime as runtime
out=runtime.prepare_output_directory(ROOT/'dist-newstyle/function-carrier-native-providers-v1')
exe=ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/t/leant-synth-tests/build/leant-synth-tests/leant-synth-tests.exe'
paths=[exe,ROOT/'test-unit/Spec.hs',ROOT/'src/Leant/Synth/Engine.hs',ROOT/'lib/Djex/exference/src-core/Language/Haskell/Exference/Core/Internal/Exference.hs',Path(__file__).resolve()]
snapshot=lambda:{str(p):runtime.sha256(p) for p in paths}
report={'status':'running','before':snapshot(),'rows':[]}
processes=runtime.Processes(out,300)
env={k:v for k,v in os.environ.items() if not k.upper().startswith('TASTY_')}
env.update(leant_datadir=str(ROOT),djex_datadir=str(ROOT/'lib/Djex'))
cases=[('layered','recover successive polymorphic layers without unrelated prelude constructors'),('structural','consume canonical structural provider assignments')]
runtime.write_json(out/'results.json',report)
try:
    for label,pattern in cases:
        result=processes.run(label,[exe,'-p',pattern,'-j1','--timeout=180s','--color=never'],cwd=ROOT,env=env)
        passed=result.returncode==0 and re.search(r'^All 1 tests passed ',result.stdout,re.M)
        report['rows'].append({'name':label,'status':'passed' if passed else 'failed','exit_code':result.returncode})
        runtime.write_json(out/'results.json',report)
        print(label,report['rows'][-1]['status'],flush=True)
    report['status']='passed' if all(r['status']=='passed' for r in report['rows']) else 'failed'
finally:
    report.update(after=snapshot(),processes=processes.rows)
    report['unchanged']=report['before']==report['after']
    if not report['unchanged'] or len(report['rows'])!=len(cases):report['status']='failed'
    runtime.write_json(out/'results.json',report)
sys.exit(0 if report['status']=='passed' else 1)
