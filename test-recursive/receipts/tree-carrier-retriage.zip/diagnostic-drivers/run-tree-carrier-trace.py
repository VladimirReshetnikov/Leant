from pathlib import Path
import json,sys
ROOT=Path('C:/Djex');sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as runtime
OUT=ROOT/'dist-newstyle/tree-carrier-branch-trace-v1'
manifest=json.loads((OUT/'sources.json').read_text(encoding='utf-8'))
source=Path(manifest['source'])
assert runtime.sha256(source)==manifest['instrumented_v2_sha256']
probe=Path('C:/Leant/test-recursive/tree-accumulator/TreeAccumulatorProbe.hs')
libraries=list((ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/djex-2026.7.17/build').glob('*HSdjex*.a'))
assert libraries
paths=[source,probe,*libraries,Path(__file__).resolve()]
snapshot=lambda:{str(p):runtime.sha256(p) for p in paths}
report=dict(status='running',scope='temporary reference-shape observer; original public query and search limits; no synthesis guidance supplied',before=snapshot(),processes=[])
processes=runtime.Processes(OUT,180);receipt=OUT/'results.json'
runtime.write_json(receipt,report)
try:
 objects=OUT/'probe-objects';objects.mkdir(exist_ok=False)
 exe=OUT/'TreeAccumulatorProbe.exe'
 compiled=processes.run('probe-build',['cabal','exec','--','ghc','--make','-O0','-Wall','-Werror','-i','-outputdir',objects,probe,'-o',exe,'-package','djex'],cwd=ROOT)
 assert compiled.returncode==0
 report['executable_sha256']=runtime.sha256(exe)
 work=OUT/'exference';work.mkdir(exist_ok=False)
 result=processes.run('exference-trace',[exe,'exference',work],cwd=ROOT)
 assert result.returncode==0
 data=json.loads((work/'candidates.json').read_text(encoding='utf-8'))
 assert data['status']=='checked' and data['observed_count']==1024
 baseline=Path('C:/Leant/dist-newstyle/tree-accumulator-acceptance-v1/matrix/haskell-exference/candidates.json')
 report['candidate_sha256']=runtime.sha256(work/'candidates.json')
 report['baseline_sha256']=runtime.sha256(baseline)
 report['same_candidate_bytes']=report['candidate_sha256']==report['baseline_sha256']
 report['trace_lines']=sum(line.startswith('TREE_BRANCH ') for line in result.stderr.splitlines())
 assert report['same_candidate_bytes']
 assert runtime.sha256(exe)==report['executable_sha256']
 report['status']='completed_diagnostic'
except Exception as failure:
 report.update(status='failed',failure_type=type(failure).__name__,failure=str(failure))
finally:
 report.update(after=snapshot(),processes=processes.rows)
 report['unchanged']=report['before']==report['after']
 if not report['unchanged']:report['status']='failed'
 runtime.write_json(receipt,report)
 print(json.dumps({k:v for k,v in report.items() if k not in ['before','after','processes']}))
