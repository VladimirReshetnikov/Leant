"""Prepare a temporary observer of one expressible tree-fold derivation.

Writes only an ignored diagnostic copy. Does not install instrumentation or
change production source, search choices, priorities, budgets or providers.
"""
from pathlib import Path
import hashlib,json

root=Path('C:/Djex')
out=root/'dist-newstyle/tree-carrier-branch-trace-v1'
out.mkdir(exist_ok=False)
path=root/'exference/src-core/Language/Haskell/Exference/Core/Internal/Exference.hs'
original=path.read_bytes()
(out/'Exference.original.hs').write_bytes(original)
s=original.decode('utf-8').replace('\r\n','\n')
s=s.replace('import Data.Maybe (','import qualified Debug.Trace as BranchTrace\nimport Data.Maybe (',1)
old='''        Unfinished (ScheduledNode nextGoal s) -> runStateStep
          stepRoute allocators casePolicy multiPM relaxConstraints heuristics nextGoal s'''
new='''        Unfinished scheduled@(ScheduledNode nextGoal s) ->
          traceTreeBranch ("pop " ++ show n') (restoreScheduledNode scheduled) $
            runStateStep stepRoute allocators casePolicy multiPM relaxConstraints heuristics nextGoal s'''
assert old in s;s=s.replace(old,new,1)
old='''        [ ( (frontierPriority $ restoreScheduledNode newS, False)
          , Unfinished newS)'''
new='''        [ traceTreeBranch
            ("child " ++ show n' ++ " priority " ++ show (frontierPriority $ restoreScheduledNode newS))
            (restoreScheduledNode newS)
            ( (frontierPriority $ restoreScheduledNode newS, False)
          , Unfinished newS)'''
assert old in s;s=s.replace(old,new,1)
s=s.replace("_ -> admitReadyFrontier (n' + 1 >= maxSteps)","_ -> admitReadyFrontier (show n') (n' + 1 >= maxSteps)",1)
s=s.replace('= admitReadyFrontier True',"= admitReadyFrontier (show n' ++ \" other-lane\") True",1)
s=s.replace('admitReadyFrontier\n  :: Bool','admitReadyFrontier\n  :: String\n  -> Bool',1)
s=s.replace('admitReadyFrontier finalStep maximumSize queued newEntries =','admitReadyFrontier traceStep finalStep maximumSize queued newEntries =',1)
s=s.replace('(retained, capacityPruned) = limitQueue maximumSize pending',
 '''(retained, capacityPruned) = traceTreePruned traceStep maximumSize pending $
        limitQueue maximumSize pending''',1)
s+=r'''

-- TEMPORARY diagnostic. Matching only controls logging, never search.
data TreeTraceShape
  = TreeTraceVariable TVarId
  | TreeTraceFold
  | TreeTraceLambda TVarId TreeTraceShape
  | TreeTraceApplication TreeTraceShape TreeTraceShape

traceTreeBranch :: String -> SearchNode -> a -> a
traceTreeBranch label node result
  | matches [] shape (nodeExpression node) = BranchTrace.trace
      ("TREE_BRANCH " ++ label ++ " depth " ++ show (nodeDepth node)
        ++ " goals " ++ show (map goalBinding $ foldr (:) [] $ nodeGoals node)
        ++ " expression " ++ show (toGeneratedExpression $ nodeExpression node)) result
  | otherwise = result
 where
  matches _ _ ExpHole{} = True
  matches env expected (ExpTypeApply function _) = matches env expected function
  matches _ TreeTraceFold (ExpName name) = qualifiedNameOccurrence name == "foldTree"
  matches env (TreeTraceVariable wanted) (ExpVar actual _) = lookup actual env == Just wanted
  matches env (TreeTraceLambda wanted body) (ExpLambda actual _ actualBody) =
    matches ((actual,wanted):env) body actualBody
  matches env (TreeTraceApplication function argument) (ExpApply actualFunction actualArgument) =
    matches env function actualFunction && matches env argument actualArgument
  matches _ _ _ = False
  v = TreeTraceVariable
  app = TreeTraceApplication
  lam = TreeTraceLambda
  -- \f s tree -> foldTree (\x state -> f state x)
  --   (\left right state -> right (left state)) tree s
  shape = lam 1 $ lam 2 $ lam 3 $
    app (app (app (app TreeTraceFold
      (lam 4 $ lam 5 $ app (app (v 1) (v 5)) (v 4)))
      (lam 6 $ lam 7 $ lam 8 $ app (v 7) $ app (v 6) (v 8))) (v 3)) (v 2)

traceTreePruned :: String -> Maybe Int -> RatedNodes -> a -> a
traceTreePruned label maximumSize pending result = case maximumSize of
  Just capacity | Q.size pending > max 0 capacity ->
    foldr observe result $ drop (max 0 capacity) ordered
   where
    ordered = Q.toDescList pending
    cutoff = if capacity > 0 then show (fst $ ordered !! (capacity - 1)) else "none"
    observe (priority, entry) = traceTreeBranch
      ("pruned " ++ label ++ " priority " ++ show priority ++ " cutoff " ++ cutoff
        ++ " pending " ++ show (Q.size pending)) $ case entry of
          Unfinished scheduled -> restoreScheduledNode scheduled
          Ready (ReadySolution _ _ node) -> node
  _ -> result
'''
(out/'Exference.instrumented.hs').write_text(s,encoding='utf-8',newline='\n')
(out/'sources.json').write_text(json.dumps(dict(status='prepared_not_executed',source=str(path),original_sha256=hashlib.sha256(original).hexdigest(),instrumented_sha256=hashlib.sha256((out/'Exference.instrumented.hs').read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8')
print(out)
