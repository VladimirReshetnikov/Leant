from pathlib import Path
import json
import os
import sys

ROOT=Path('C:/Leant')
sys.path.insert(0,str(ROOT/'lib/Djex/test-church'))
import behavior_runtime as runtime
OUT=ROOT/'dist-newstyle/combined-decision-smoke-v1'
OUT.mkdir(exist_ok=False)
BASE=ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0'
EXE=BASE/'x/leant/build/leant/leant.exe'
TEST=BASE/'t/leant-synth-tests/build/leant-synth-tests/leant-synth-tests.exe'
BACKEND=Path('C:/Users/vresh/AppData/Local/Python/pythoncore-3.14-64/Lib/site-packages/lean_interact/cache/augustepoiroux/repl/repl_v1.3.18_lean-toolchain-v4.32.0/.lake/build/bin/repl.exe')
BIN=Path('C:/Users/vresh/.elan/toolchains/leanprover--lean4---v4.32.0/bin')
paths=[ROOT/'src/Main.hs',ROOT/'src/Leant/Synth/Behavioral.hs',ROOT/'test-unit/Spec.hs',EXE,TEST,BACKEND,BIN/'lean.exe',BIN/'lake.exe',Path(__file__)]
snapshot=lambda:{str(p):runtime.sha256(p) for p in paths}
report=dict(status='running',before=snapshot())
processes=runtime.Processes(OUT,120)
env=dict(os.environ,LEANT_BACKEND=str(BACKEND),leant_datadir=str(ROOT),djex_datadir=str(ROOT/'lib/Djex'))
env['PATH']=str(BIN)+os.pathsep+env.get('PATH','')
source='\n'.join([':set synth-library off',':set synth-providers off',':set synth-classical off',
    ':set synth-debug on',':set synth-engine djinn',':set synth-window 4',':set synth-verify 4',
    ':set synth-timeout 10',
    ':synth f : Nat → Nat where f 11 = 11',
    ':synth f : Nat → Nat where False',
    ':synth f : ∀ α : Type, α → α where ∀ n : Nat, f Nat n = n',':quit',''])
try:
    control=processes.run('tag-controls',[str(TEST),'-j1','--color=never','-p','combined decision tags'],cwd=ROOT,env=env)
    assert control.returncode==0
    result=processes.run('live',[str(EXE),'--plain'],source=source,cwd=ROOT,env=env)
    report['exit_code']=result.returncode
    report['observations']=[line for line in (result.stdout+result.stderr).splitlines()
        if line.startswith(('supplied behavioral assertion:','the engine did not finish','behavioral query rejected'))]
    report['status']='captured' if result.returncode==0 else 'failed'
finally:
    report['after']=snapshot()
    report['unchanged']=report['before']==report['after']
    report['processes']=processes.rows
    if not report['unchanged'] or report['status']=='running':report['status']='failed'
    runtime.write_json(OUT/'results.json',report)
    print(json.dumps({k:report[k] for k in ['status','unchanged','observations'] if k in report}),flush=True)
raise SystemExit(0 if report['status']=='captured' else 1)
