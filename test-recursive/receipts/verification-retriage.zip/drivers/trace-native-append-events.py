"""Observe one original-bound native append query through existing transport tracing."""
from pathlib import Path
from types import SimpleNamespace
import collections
import json
import os
import subprocess
import sys

ROOT = Path('C:/Leant')
sys.path[:0] = [str(ROOT/'test-church'),str(ROOT/'lib/Djex/test-church')]
import behavior_runtime as runtime
import behavior_partial_probe as pins
OUT = ROOT/'dist-newstyle/native-append-phase-trace-v2'
OUT.mkdir(exist_ok=False)
original = ROOT/'dist-newstyle/function-carrier-native-integration-v1/native-recursor'
process = next(row for row in json.loads((original/'processes.json').read_text())
               if row['label']=='recursor_exference_native_append-live')
source_path = Path(process['input_path'])
assert runtime.sha256(source_path)==process['input_sha256']
EXE = Path(process['command'][0])
KERNEL = Path('C:/Users/vresh/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean.exe')
report = dict(status='running',validation_mode='diagnostic_not_synthesis_acceptance',source_hashes={},
    original_input_sha256=runtime.sha256(source_path),
    dependency=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT/'lib/Djex',text=True).strip())
assert report['dependency']=='bfc3692e891ed2d81846fb2bd6b54ecd51aa7442'
args = SimpleNamespace(leant=EXE,lean=str(KERNEL),lean_runtime=KERNEL,toolchain='',backend=None)
exe,backend,lake,runtime_hashes = pins.runtime_identity(args,runtime,report)
paths = {Path(__file__),source_path,EXE,*(Path(p) for p in runtime_hashes),
         *(Path(p) for p in report['source_hashes'])}
for directory in ['src','lib/Djex/src','lib/Djex/djinn','lib/Djex/exference','lib/Djex/synthesis']:
    paths.update(p for p in (ROOT/directory).rglob('*.hs')
                 if not {'dist-newstyle','__pycache__'} & set(p.parts))
snapshot = lambda: {str(p):runtime.sha256(p) for p in sorted(paths)}
report['before'] = snapshot()
trace_path = OUT/'backend-trace.json'
env = dict(os.environ, LEANT_BACKEND=str(backend), leant_datadir=str(ROOT),
           djex_datadir=str(ROOT/'lib/Djex'), LEANT_SYNTH_TIMEOUT='90',
           LEANT_BACKEND_TRACE=str(trace_path), LEANT_BACKEND_TRACE_REQUESTS='0',
           LEANT_BACKEND_TRACE_REQUEST_LIMIT='1024')
env['PATH'] = str(Path(lake).parent)+os.pathsep+env.get('PATH','')
processes = runtime.Processes(OUT,180)
try:
    result = processes.run('native-append',process['command'],
                           source=source_path.read_text(encoding='utf-8'),cwd=ROOT,env=env)
    report['exit_code'] = result.returncode
    transcript = result.stdout+result.stderr
    report['observations'] = [line for line in transcript.splitlines()
        if line.startswith(('supplied behavioral assertion:', 'the engine did not finish'))]
    trace = json.loads(trace_path.read_text(encoding='utf-8'))
    report['trace_sha256'] = runtime.sha256(trace_path)
    capture = trace.get('request_capture', {'requests':[],'omitted_records':0})
    report['trace_omissions'] = dict(events=trace['dropped_events'],requests=capture['omitted_records'])
    annotations = {}
    for row in capture['requests']:
        annotations[(row['backend_id'],row['request_id'])] = (
            json.loads(row['annotation_json']) if row['annotation_json'] else {})
    grouped = collections.defaultdict(list)
    for event in trace['events']:
        if event['request_id'] is not None:
            grouped[(event['backend_id'],event['request_id'])].append(event)
    completed = []
    interrupted = []
    for key,events in grouped.items():
        times = {event['stage']:event['monotonic_ns'] for event in events}
        start = next((event['monotonic_ns'] for event in events
                      if event['stage'].startswith('TraceRequestStarted')),None)
        end = times.get('TraceResponseParsed')
        info = dict(backend_id=key[0],request_id=key[1],role=annotations.get(key,{}).get('role','unlabelled'))
        if start is not None and end is not None:
            info.update(request_seconds=(end-start)/1e9,
                read_seconds=(times['TraceResponseReadCompleted']-times['TraceResponseReadStarted'])/1e9,
                send_seconds=(times['TraceFlushCompleted']-times['TraceWriteStarted'])/1e9)
            completed.append(info)
        else:
            info['stages'] = list(times)
            interrupted.append(info)
    roles = {}
    for role in sorted({row['role'] for row in completed}):
        rows = [row for row in completed if row['role']==role]
        roles[role] = dict(count=len(rows),**{field:sum(row[field] for row in rows)
                          for field in ['request_seconds','read_seconds','send_seconds']})
    report.update(status='captured',completed_requests=completed,incomplete_requests=interrupted,
                  completed_request_totals_by_role=roles,
                  boundaries=['Tracing retains bounded request metadata; the command, inventory and synthesis limits are unchanged.',
                      'Request durations include transport, Lean work and scheduling; they are not kernel CPU time.',
                      'These sums exclude incomplete requests and time outside requests; overlapping requests must not be treated as additive wall time.',
                      'This diagnostic does not advance native integration acceptance.'])
finally:
    report['after'] = snapshot()
    report['unchanged'] = report['before']==report['after']
    report['processes'] = processes.rows
    if not report['unchanged'] or report['status']=='running': report['status']='failed'
    runtime.write_json(OUT/'results.json',report)
    print(json.dumps({key:report[key] for key in ['status','unchanged','observations',
        'trace_omissions','completed_request_totals_by_role'] if key in report}),flush=True)
raise SystemExit(0 if report['status']=='captured' and report['unchanged'] else 1)
