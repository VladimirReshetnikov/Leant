import Lean

set_option autoImplicit false in
set_option maxHeartbeats 200000 in
open Lean Elab Command in
run_cmd do
  for source in [
    "let f : Nat → Nat := fun n => n + 1; f 11 = 12",
    "let f : Nat → Nat := fun n => n; f 11 = 12",
    "let f : Nat → Nat := fun n => n; ∀ p : Prop, p"
  ] do
    let proposition : TSyntax `term ← match Parser.runParserCategory (← getEnv) `term source with
      | .ok parsed => pure ⟨parsed⟩
      | .error message => throwError message
    let name ← liftCoreM <| mkFreshUserName `leantBehaviorCertificate
    let certificate := mkIdent name
    elabCommand (← `(private def $certificate :
      _root_.Option (_root_.Decidable $proposition) := by
      first
      | exact some (.isTrue (by decide))
      | exact some (.isFalse (by decide))
      | exact none))
    elabCommand (← `(#reduce (match $(mkIdent name):term with
      | _root_.Option.none => "LEANT_BEHAVIOR_DECISION:0"
      | _root_.Option.some (_root_.Decidable.isTrue _) => "LEANT_BEHAVIOR_DECISION:1"
      | _root_.Option.some (_root_.Decidable.isFalse _) => "LEANT_BEHAVIOR_DECISION:2")))
