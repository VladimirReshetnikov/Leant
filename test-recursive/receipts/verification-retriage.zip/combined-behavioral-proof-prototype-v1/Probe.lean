-- Feasibility experiment only: not synthesis or production acceptance.
set_option autoImplicit false
set_option maxHeartbeats 200000

namespace CombinedBehaviorProbe

def resultTag {p : Prop} : Option (Decidable p) → Nat
  | none => 0
  | some (.isTrue _) => 1
  | some (.isFalse _) => 2

def accepted : Option (Decidable (
    let f : {α : Type} → (∀ ρ : Type, (α → ρ → ρ) → ρ → List α → ρ) →
        List α → List α → List α :=
      fun {α} fold xs ys => fold (List α) List.cons ys xs
    f (fun ρ => @List.foldr Nat ρ) [11, 29] [37, 41, 53] = [11, 29, 37, 41, 53] ∧
    f (fun ρ => @List.foldr Bool ρ) [true, false] [true] = [true, false, true])) := by
  first
  | exact some (.isTrue (by decide))
  | exact some (.isFalse (by decide))
  | exact none

def rejected : Option (Decidable (
    let f : {α : Type} → (∀ ρ : Type, (α → ρ → ρ) → ρ → List α → ρ) →
        List α → List α → List α := fun _ xs _ => xs
    f (fun ρ => @List.foldr Nat ρ) [11, 29] [37, 41, 53] = [11, 29, 37, 41, 53])) := by
  first
  | exact some (.isTrue (by decide))
  | exact some (.isFalse (by decide))
  | exact none

def undecided (p : Prop) : Option (Decidable p) := by
  first
  | exact some (.isTrue (by decide))
  | exact some (.isFalse (by decide))
  | exact none

example : resultTag accepted = 1 := rfl
example : resultTag rejected = 2 := rfl
example (p : Prop) : resultTag (undecided p) = 0 := rfl

#eval [resultTag accepted, resultTag rejected, resultTag (undecided True)]
#print axioms accepted
#print axioms rejected
#print axioms undecided

end CombinedBehaviorProbe
