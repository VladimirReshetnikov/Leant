"""Serial native integration against the published canonical Djex milestone."""
from pathlib import Path
from types import SimpleNamespace
import hashlib,json,os,subprocess,sys

ROOT=Path('C:/Leant')
sys.path[:0]=[str(ROOT/'test-church'),str(ROOT/'lib/Djex/test-church')]
import behavior_runtime as runtime
import behavior_partial_probe as pins

OUT=ROOT/'dist-newstyle/native-tree-after-integration-v2'
OUT.mkdir(parents=True,exist_ok=False)
BUILD=ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4'
EXE=BUILD/'leant-0.1.0/x/leant/build/leant/leant.exe'
TEST=BUILD/'leant-0.1.0/t/leant-synth-tests/build/leant-synth-tests/leant-synth-tests.exe'
KERNEL=Path('C:/Users/vresh/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean.exe')
report={'status':'running','source_hashes':{},'gates':[],'dependency':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT/'lib/Djex',text=True).strip()}
assert report['dependency']=='bfc3692e891ed2d81846fb2bd6b54ecd51aa7442'
args=SimpleNamespace(leant=EXE,lean=str(KERNEL),lean_runtime=KERNEL,toolchain='',backend=None)
exe,backend,lake,runtime_hashes=pins.runtime_identity(args,runtime,report)
env=dict(os.environ,LEANT_BACKEND=str(backend),leant_datadir=str(ROOT),djex_datadir=str(ROOT/'lib/Djex'))
env['PATH']=str(Path(lake).parent)+os.pathsep+env.get('PATH','')
common=['--leant',str(EXE),'--lean-runtime',str(KERNEL),'--backend',str(backend)]
commands=[
 ('native-tree',[sys.executable,'-B','test-recursive/tree-accumulator/run_acceptance.py','--language','lean','--leant',str(EXE),'--kernel',str(KERNEL)]),
]

paths={Path('C:/Users/vresh/.elan/bin/lean.exe'),Path(__file__).resolve(),ROOT/'cabal.project',ROOT/'leant.cabal',ROOT/'lib/Djex/djex.cabal',EXE,TEST,*(Path(p) for p in runtime_hashes),*(Path(p) for p in report['source_hashes'])}
for folder in ['src','test-unit','test-context','test-recursive','test-church','lib/Djex/src','lib/Djex/djinn/src-core','lib/Djex/djinn/src-internal','lib/Djex/exference/src-core','lib/Djex/exference/src-frontend','lib/Djex/synthesis','lib/Djex/test-church']:
 paths.update(p for p in (ROOT/folder).rglob('*') if p.is_file() and p.suffix in {'.hs','.py','.lean','.inc','.tsv'} and not {'dist-newstyle','__pycache__','receipts','results'}&set(p.parts))
def snapshot():return {str(p):runtime.sha256(p) for p in sorted(paths)}
report['before']=snapshot()
processes=runtime.Processes(OUT,2400)
receipt=OUT/'results.json'
runtime.write_json(receipt,report)
try:
 for label,command in commands:
  if label=='method-controls' and not any(g['gate']=='methods' and g['status']=='passed' for g in report['gates']):
   report['gates'].append({'gate':label,'status':'not_run','reason':'required positive method receipt did not pass'})
   continue
  print('Starting',label,flush=True)
  checked=processes.run(label,command+['--output',str(OUT/label)],cwd=ROOT,env=env)
  path=OUT/label/'results.json'
  result=json.loads(path.read_text(encoding='utf-8')) if path.is_file() else {}
  row={'gate':label,'status':result.get('status','failed'),'exit_code':checked.returncode,'receipt':str(path)}
  if label.startswith('signatures-'):
   row['status']='passed' if (result.get('case_count')==result.get('candidate_count')==result.get('axiom_free_count')==350 and result.get('kernel_replay_passed') and result.get('leant_executable_unchanged')) else 'failed'
  if checked.returncode:row['status']='failed'
  report['gates'].append(row)
  runtime.write_json(receipt,report)
  print(label,row['status'],flush=True)
  if row['status'] != 'passed':
   report['stopped_after_failed_required_gate']=label
   break
finally:
 report['after']=snapshot()
 report['unchanged']=report['before']==report['after']
 report['processes']=processes.rows
 report['status']='passed' if report['unchanged'] and all(g['status']=='passed' for g in report['gates']) and len(report['gates'])==len(commands) else 'incomplete'
 runtime.write_json(receipt,report)
 print(report['status'],flush=True)

sys.exit(0 if report['status']=='passed' else 1)
