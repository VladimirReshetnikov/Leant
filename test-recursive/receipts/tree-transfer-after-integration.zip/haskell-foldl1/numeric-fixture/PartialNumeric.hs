{-# LANGUAGE RankNTypes #-}
module PartialNumeric (partialIntCase) where
partialIntCase :: forall r. Int -> r -> r -> (Int -> r) -> r
partialIntCase = \n negative zero positive -> if n < 0 then negative else if n == 0 then zero else positive (n - 1)
