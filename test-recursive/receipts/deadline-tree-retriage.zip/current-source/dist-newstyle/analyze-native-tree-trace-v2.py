from pathlib import Path
from collections import Counter, defaultdict
import json, re
ROOT = Path('C:/Leant')
OUT = ROOT / 'dist-newstyle/native-tree-owned-trace-v2'
report = json.loads((OUT / 'results.json').read_text(encoding='utf-8'))
assert report['status'] == 'diagnostic_completed' and report['unchanged']
trace = json.loads((OUT / 'backend-trace.json').read_text(encoding='utf-8'))
capture = trace['request_capture']
target = json.loads((ROOT / 'dist-newstyle/native-tree-reached-construction-v1/prepared.json').read_text(encoding='utf-8'))['candidate']
events = defaultdict(list)
for e in trace['events']:
    if e['request_id'] is not None:
        events[(e['backend_id'], e['request_id'])].append(e)
roles = Counter()
routes = Counter()
attempts = []
matched = []
for row in capture['requests']:
    annotation = json.loads(row['annotation_json']) if row['annotation_json'] else {}
    roles[annotation.get('role', 'unlabelled')] += 1
    routes[str(annotation.get('route'))] += 1
    if annotation.get('candidate'):
        es = sorted(events[(row['backend_id'], row['request_id'])], key=lambda e: e['monotonic_ns'])
        entry = dict(backend=row['backend_id'], request=row['request_id'], annotation=annotation,
                     capture_seconds=(row['capture_completed_ns'] - row['capture_started_ns']) / 1e9,
                     request_seconds=(es[-1]['monotonic_ns'] - es[0]['monotonic_ns']) / 1e9 if es else None,
                     stages=[e['stage'] for e in es])
        attempts.append(entry)
        if annotation['candidate'] == target or 'd (c e)' in annotation['candidate']:
            matched.append(entry)
text = (OUT / 'tree-exference.stdout.txt').read_text(encoding='utf-8')
summaries = [line for line in text.splitlines() if any(marker in line for marker in
    ['supplied behavioral assertion:', 'engine did not finish', 'debug behavioral request failure:', 'debug accepted-candidate:'])]
analysis = dict(status='diagnostic_analyzed', recorded_requests=len(capture['requests']),
                effective_row_limit=capture['row_limit'], omitted_records=capture['omitted_records'],
                dropped_events=trace['dropped_events'], roles=dict(roles), routes=dict(routes),
                exact_target_submitted=any(a['annotation']['candidate'] == target for a in matched),
                target_related_requests=matched, attempts=attempts,
                stdout_summaries=summaries,
                boundary='Request annotations identify invocation text and route, not a graph or kernel certificate.')
(OUT / 'analysis.json').write_text(json.dumps(analysis, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in analysis.items() if k not in ['attempts', 'stdout_summaries', 'target_related_requests']}, indent=2))
print(json.dumps({'target_matches': matched, 'summary_tail': [s[:350] for s in summaries[-8:]],
                  'largest_requests': sorted([{'request': a['request'], 'seconds': a['request_seconds'], 'role': a['annotation']['role'], 'candidate': a['annotation']['candidate'][:170]} for a in attempts], key=lambda a: a['seconds'] or 0, reverse=True)[:5]}, ensure_ascii=True, indent=2))
