from pathlib import Path
import json, os, sys
ROOT = Path('C:/Leant')
sys.path.insert(0, str(ROOT / 'lib/Djex/test-church'))
import behavior_runtime as runtime
phase = sys.argv[1]
OUT = runtime.prepare_output_directory(ROOT / ('dist-newstyle/request-deadline-' + phase))
TEST = ROOT / 'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/t/leant-synth-tests/build/leant-synth-tests/leant-synth-tests.exe'
paths = [Path(__file__).resolve(), ROOT / 'src/Leant/Backend.hs', ROOT / 'src/Main.hs',
         ROOT / 'test-unit/BackendTraceSpec.hs', ROOT / 'test-unit/Spec.hs', TEST]
snapshot = lambda: {str(p): runtime.sha256(p) for p in paths}
report = dict(status='running', phase=phase, before=snapshot())
for path in paths:
    if path.suffix in {'.hs', '.py'}:
        target = OUT / 'source' / path.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes())
processes = runtime.Processes(OUT, 60)
try:
    inv = processes.run('inventory', [TEST, '--list-tests', '-p', 'request deadline'], cwd=ROOT)
    names = [line for line in inv.stdout.splitlines() if line.strip()]
    assert inv.returncode == 0 and len(names) == len(set(names)) == 3
    report['inventory'] = names
    result = processes.run('focused', [TEST, '-j1', '--color=never', '--timeout=30s', '-p', 'request deadline'], cwd=ROOT)
    report.update(exit_code=result.returncode,
                  status='passed' if result.returncode == 0 and 'All 3 tests passed' in result.stdout else 'failed')
    print(result.stdout, flush=True)
finally:
    report.update(after=snapshot(), processes=processes.rows)
    report['unchanged'] = report['before'] == report['after']
    if not report['unchanged']:
        report['status'] = 'inputs_changed'
    runtime.write_json(OUT / 'results.json', report)
    print(json.dumps({k: report.get(k) for k in ['status', 'phase', 'unchanged', 'exit_code']}), flush=True)
