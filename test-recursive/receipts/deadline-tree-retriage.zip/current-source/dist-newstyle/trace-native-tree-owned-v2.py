from pathlib import Path
from types import SimpleNamespace
import json, os, subprocess, sys
ROOT = Path('C:/Leant')
sys.path[:0] = [str(ROOT / 'test-church'), str(ROOT / 'lib/Djex/test-church')]
import behavior_runtime as runtime
import behavior_partial_probe as pins

OUT = runtime.prepare_output_directory(ROOT / 'dist-newstyle/native-tree-owned-trace-v2')
EXE = ROOT / 'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/x/leant/build/leant/leant.exe'
KERNEL = Path('C:/Users/vresh/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean.exe')
HERE = ROOT / 'test-recursive/tree-accumulator'
INPUT = HERE / 'commands/tree_accumulator_exference.commands.txt'
TRACE = OUT / 'backend-trace.json'
report = {'status': 'running', 'scope': 'single original-bound diagnostic, not matrix acceptance',
          'source_hashes': {}, 'leant_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
          'dependency': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT / 'lib/Djex', text=True).strip()}
assert report['dependency'] == 'bfc3692e891ed2d81846fb2bd6b54ecd51aa7442'
args = SimpleNamespace(leant=EXE, lean=str(KERNEL), lean_runtime=KERNEL, toolchain='', backend=None)
exe, backend, lake, runtime_hashes = pins.runtime_identity(args, runtime, report)
manifest = json.loads((HERE / 'manifest.json').read_text(encoding='utf-8'))
assert all(runtime.sha256(HERE / item['path']) == item['sha256'] for item in manifest['files'])
paths = {Path(__file__).resolve(), EXE, KERNEL, ROOT / 'cabal.project', ROOT / 'leant.cabal',
         ROOT / 'lib/Djex/djex.cabal', *(Path(p) for p in runtime_hashes), *(Path(p) for p in report['source_hashes'])}
for directory in ['src', 'lib/Djex/src', 'lib/Djex/djinn/src-core', 'lib/Djex/djinn/src-internal',
                  'lib/Djex/exference/src-core', 'lib/Djex/exference/src-frontend', 'lib/Djex/synthesis',
                  'test-recursive/tree-accumulator']:
    paths.update(p for p in (ROOT / directory).rglob('*') if p.is_file()
                 and p.suffix in {'.hs', '.py', '.lean', '.inc', '.json', '.txt'}
                 and not {'dist-newstyle', '__pycache__', 'receipts', 'results'} & set(p.parts))
snapshot = lambda: {str(p): runtime.sha256(p) for p in sorted(paths)}
report['before'] = snapshot()
report['trace'] = {'path': str(TRACE), 'request_rows': 1024, 'event_capacity': 16384,
                   'boundary': 'Invocation annotations and transport events; not a graph or kernel certificate.'}
source = INPUT.read_text(encoding='utf-8')
(OUT / INPUT.name).write_bytes(INPUT.read_bytes())
env = dict(os.environ, LEANT_BACKEND=str(backend), LEANT_SYNTH_TIMEOUT='90',
           LEANT_BACKEND_TRACE=str(TRACE), LEANT_BACKEND_TRACE_REQUESTS='1',
           LEANT_BACKEND_TRACE_REQUEST_LIMIT='1024', leant_datadir=str(ROOT), djex_datadir=str(ROOT / 'lib/Djex'))
env['PATH'] = str(Path(lake).parent) + os.pathsep + env.get('PATH', '')
report['thread_settings'] = {key: env.get(key) for key in ['GHCRTS', 'LEAN_NUM_THREADS']}
processes = runtime.Processes(OUT, 180)
runtime.write_json(OUT / 'results.json', report)
try:
    result = processes.run('tree-exference', [EXE, '--plain'], cwd=ROOT, source=source, env=env)
    report['exit_code'] = result.returncode
    report['trace_present'] = TRACE.is_file()
    report['status'] = 'diagnostic_completed' if TRACE.is_file() else 'missing_trace'
except TimeoutError:
    report['status'] = 'owned_process_timeout'
    report['trace_present'] = TRACE.is_file()
finally:
    report['after'] = snapshot()
    report['unchanged'] = report['before'] == report['after']
    report['processes'] = processes.rows
    if not report['unchanged']:
        report['status'] = 'inputs_changed'
    runtime.write_json(OUT / 'results.json', report)
    print(json.dumps({k: report.get(k) for k in ['status', 'exit_code', 'trace_present', 'unchanged']}), flush=True)
