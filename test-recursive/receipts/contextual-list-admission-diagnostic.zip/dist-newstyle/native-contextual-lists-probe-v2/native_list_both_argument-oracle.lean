set_option autoImplicit false
class Ctx.C (α : Type) where out : Nat
def ListOracle.reference : ∀ (α β : Type), [Ctx.C α] → β → List β := fun (α β : Type) [d : Ctx.C α] (x : β) => [x]
theorem ListOracle.passes : (@ListOracle.reference Nat Nat (@Ctx.C.mk Nat 7) 37 = [37]) ∧ (@ListOracle.reference Nat Bool (@Ctx.C.mk Nat 11) true = [true]) := by decide
#print axioms ListOracle.reference
#print axioms ListOracle.passes
