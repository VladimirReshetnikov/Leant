set_option autoImplicit false
class Ctx.C (α : Type) where out : Nat
def ListOracle.reference : ∀ (α : Type), [Ctx.C α] → List Nat := fun (α : Type) [d : Ctx.C α] => [@Ctx.C.out α d]
theorem ListOracle.passes : (@ListOracle.reference Nat (@Ctx.C.mk Nat 7) = [7]) ∧ (@ListOracle.reference Nat (@Ctx.C.mk Nat 11) = [11]) := by decide
#print axioms ListOracle.reference
#print axioms ListOracle.passes
