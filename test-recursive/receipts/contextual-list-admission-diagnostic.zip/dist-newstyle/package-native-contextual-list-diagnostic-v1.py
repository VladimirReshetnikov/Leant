from pathlib import Path
import hashlib,json,subprocess,zipfile

ROOT=Path('C:/Leant')
OUT=ROOT/'dist-newstyle/native-contextual-lists-probe-v2'
RECEIPT=ROOT/'test-recursive/receipts/contextual-list-admission-diagnostic.json'
ARCHIVE=RECEIPT.with_suffix('.zip')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8'))
result=read(OUT/'results.json')
assert result['status']=='diagnostic_complete'
assert len(result['cases'])==6
expected={(e,k) for e in ['djinn','exference','both'] for k in ['method','argument']}
assert {(c['engine'],c['name'].rsplit('_',1)[1]) for c in result['cases']}==expected
message='context-source: exact lexical-Given source requires'
for case in result['cases']:
    assert case['status']=='unaccepted' and case['exit_code']==0
    assert case['oracle']['status']=='passed'
    assert all(not a for a in case['oracle']['axiom_inventories'].values())
    transcript=(OUT/(case['name']+'.stdout.txt')).read_text(encoding='utf-8')
    assert message in transcript
    case['classification']='source_admission_refusal'
build_dir=ROOT/'dist-newstyle/contextual-list-native-build-v1'
build=read(build_dir/'results.json')
assert build['status']=='passed' and build['sources_unchanged']
assert all(digest(Path(p))==h for p,h in build['sources_after'].items())
dependency=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT/'lib/Djex',text=True).strip()
assert dependency=='c1ad560e106f59df07d1a32c3b51158ef749fc99'
files=[*OUT.rglob('*'),*build_dir.rglob('*'),
       ROOT/'dist-newstyle/probe-native-contextual-lists-v2.py',
       ROOT/'dist-newstyle/build-contextual-list-native-v1.py',Path(__file__),
       ROOT/'test-context/run_production.py',ROOT/'test-church/behavior_partial_probe.py',
       ROOT/'test-church/behavior_runtime.py',ROOT/'lib/Djex/test-church/behavior_runtime.py',
       ROOT/'test-context/global-methods/commands/method_djinn_where.commands.txt',
       ROOT/'src/Leant/Synth/Fragment.hs',ROOT/'src/Leant/Synth/ContextSource.hs']
files=sorted(set(p for p in files if p.is_file()))
assert not RECEIPT.exists() and not ARCHIVE.exists()
manifest={str(p.relative_to(ROOT)).replace('\\','/'):digest(p) for p in files}
with zipfile.ZipFile(ARCHIVE,'w',zipfile.ZIP_DEFLATED) as archive:
    for p in files: archive.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(ARCHIVE) as archive:
    assert archive.testzip() is None
    assert all(hashlib.sha256(archive.read(name)).hexdigest()==h for name,h in manifest.items())
receipt=dict(status='diagnostic_complete',acceptance=False,dependency=dependency,
    leant_source_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    classification='six_source_admission_refusals',cases=result['cases'],
    strict_build='passed',strict_build_sources_still_unchanged=True,
    limitations=['No synthesized candidate was accepted.',
      'The six reference implementations and predicates passed separate kernel checks with empty axiom inventories.',
      'No False controls were run in this diagnostic.',
      'Ten native integration gates for this dependency have not run; no dependency promotion is justified.',
      'Source hashes match the earlier strict build and packaging-time recheck; this is not a full acceptance input freeze.',
      'The first diagnostic attempt stopped on an invalid unused-instance binder in its second oracle; the corrected fresh six-case run is archived here.'],
    runtime_identities=result['runtime_identities'],artifact_count=len(manifest),
    archive=ARCHIVE.name,archive_sha256=digest(ARCHIVE),archive_bytes=ARCHIVE.stat().st_size,
    artifacts=manifest)
RECEIPT.write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({k:receipt[k] for k in ['status','classification','artifact_count','archive_bytes','archive_sha256']}))
