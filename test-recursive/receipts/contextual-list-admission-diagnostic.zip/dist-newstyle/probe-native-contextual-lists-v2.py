"""Diagnostic of native contextual list admission, separate from integration gates."""
from pathlib import Path
from types import SimpleNamespace
import importlib.util,json,os,sys
ROOT=Path('C:/Leant');sys.path[:0]=[str(ROOT/'test-church'),str(ROOT/'lib/Djex/test-church')]
import behavior_runtime as runtime
import behavior_partial_probe as pins
spec=importlib.util.spec_from_file_location('context_parser',ROOT/'test-context/run_production.py')
parser=importlib.util.module_from_spec(spec);spec.loader.exec_module(parser)
OUT=runtime.prepare_output_directory(ROOT/'dist-newstyle/native-contextual-lists-probe-v2')
EXE=ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/x/leant/build/leant/leant.exe'
KERNEL=parser.default_lean_runtime()
report=dict(status='running',source_hashes={},cases=[])
args=SimpleNamespace(leant=EXE,lean=str(KERNEL),lean_runtime=KERNEL,toolchain='',backend=None)
exe,backend,lake,identities=pins.runtime_identity(args,runtime,report)
owned=runtime.Processes(OUT,180)
env=dict(os.environ,LEANT_BACKEND=str(backend),leant_datadir=str(ROOT),djex_datadir=str(ROOT/'lib/Djex'))
kernel=parser.pin_kernel(KERNEL)
base=(ROOT/'test-context/global-methods/commands/method_djinn_where.commands.txt').read_text(encoding='utf-8').splitlines()
base=[line for line in base if not line.startswith(':synth ') and line!=':quit' and not line.startswith(':set synth-engine')]
for engine in ['djinn','exference','both']:
  for kind in ['method','argument']:
    name='native_list_'+engine+'_'+kind
    ty='∀ (α : Type), [Ctx.C α] → List Nat' if kind=='method' else '∀ (α β : Type), [Ctx.C α] → β → List β'
    predicate=(f'(@{name} Nat (@Ctx.C.mk Nat 7) = [7]) ∧ (@{name} Nat (@Ctx.C.mk Nat 11) = [11])' if kind=='method' else
      f'(@{name} Nat Nat (@Ctx.C.mk Nat 7) 37 = [37]) ∧ (@{name} Nat Bool (@Ctx.C.mk Nat 11) true = [true])')
    command=f':synth {name} : {ty} where {predicate}'
    source='\n'.join(base+[f':set synth-engine {engine}',':set synth-providers '+('on' if kind=='method' else 'off'),command,':quit'])+'\n'
    case=dict(name=name,type=ty,predicate=predicate,command=command,engine=engine,expected='candidate',mode='where')
    reference=('fun (α : Type) [d : Ctx.C α] => [@Ctx.C.out α d]' if kind=='method' else
      'fun (α β : Type) [d : Ctx.C α] (x : β) => [x]')
    preflight=OUT/(name+'-oracle.lean')
    preflight.write_text('set_option autoImplicit false\nclass Ctx.C (α : Type) where out : Nat\n'+f'def ListOracle.reference : {ty} := {reference}\ntheorem ListOracle.passes : {predicate.replace(name,"ListOracle.reference")} := by decide\n#print axioms ListOracle.reference\n#print axioms ListOracle.passes\n',encoding='utf-8')
    oracle=parser.kernel_check(owned,name+'-oracle',dict(path=str(preflight),sha256=runtime.sha256(preflight),declarations=['ListOracle.reference','ListOracle.passes']),kernel)
    assert oracle['status']=='passed',oracle
    checked=owned.run(name,[str(exe),'--plain','--lake',str(lake)],cwd=ROOT,env=env,source=source)
    row=dict(case,exit_code=checked.returncode,status='unaccepted',oracle=oracle)
    try:
      block=parser.query_block(checked.stdout,case)
      parsed=parser.candidate_result(block,case);term=parsed['candidate']
      replay=OUT/(name+'.lean')
      accepted='ListProbe.accepted';proof='ListProbe.passes'
      text='set_option autoImplicit false\nclass Ctx.C (α : Type) where out : Nat\n'+f'def {accepted} : {ty} :=\n{term}\ntheorem {proof} : {predicate.replace(name,accepted)} := by decide\n'+f'#print axioms {accepted}\n#print axioms {proof}\n'
      replay.write_text(text,encoding='utf-8')
      result=parser.kernel_check(owned,name+'-replay',dict(path=str(replay),sha256=runtime.sha256(replay),declarations=[accepted,proof]),kernel)
      row.update(candidate=term,replay=result,status='positive_replayed' if result['status']=='passed' and checked.returncode==0 else 'unaccepted')
    except ValueError as error: row['diagnostic']=str(error)
    report['cases'].append(row);runtime.write_json(OUT/'results.json',report)
    print(json.dumps(dict(name=name,status=row['status'],diagnostic=row.get('diagnostic'))),flush=True)
report.update(status='diagnostic_complete',processes=owned.rows,runtime_identities=identities)
runtime.write_json(OUT/'results.json',report)
