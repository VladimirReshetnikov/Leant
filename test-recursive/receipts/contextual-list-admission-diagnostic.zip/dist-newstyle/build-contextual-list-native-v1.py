from pathlib import Path
import hashlib,json,os,shutil,sys
root=Path('C:/Leant')
sys.path.insert(0,str(root/'lib/Djex/test-church'))
import behavior_runtime as runtime
out=root/'dist-newstyle/contextual-list-native-build-v1'
out.mkdir(exist_ok=False)
source_dirs=['src','test-unit','lib/Djex/src','lib/Djex/djinn','lib/Djex/exference','lib/Djex/synthesis','lib/Djex/test-support/fake-z3']
paths={root/'cabal.project',root/'leant.cabal',root/'lib/Djex/djex.cabal'}
for folder in source_dirs:
    paths.update(p for p in (root/folder).rglob('*.hs') if 'dist-newstyle' not in p.parts)
snapshot=lambda:{str(p):runtime.sha256(p) for p in sorted(paths)}
r={'status':'running','sources_before':snapshot(),'dependency':'c1ad560e106f59df07d1a32c3b51158ef749fc99'}
runner=runtime.Processes(out,1800)
runtime.write_json(out/'results.json',r)
try:
    checked=runner.run('strict-build',[shutil.which('cabal'),'build','leant:exe:leant','leant:test:leant-synth-tests','djex:exe:djex-fake-z3','--ghc-options=-Werror','-j1'],cwd=root,env=os.environ.copy())
    r['exit_code']=checked.returncode
finally:
    r['sources_after']=snapshot()
    r['sources_unchanged']=r['sources_before']==r['sources_after']
    r['processes']=runner.rows
    r['status']='passed' if r.get('exit_code')==0 and r['sources_unchanged'] else 'failed'
    runtime.write_json(out/'results.json',r)
print(r['status'],flush=True)
sys.exit(0 if r['status']=='passed' else 1)
