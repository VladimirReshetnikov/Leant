from pathlib import Path
import json,os,subprocess,sys
ROOT=Path.cwd();OUT=ROOT/'dist-newstyle/contextual-use-release-v1'
sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as runtime
unit=json.loads((ROOT/'dist-newstyle/method-tail-required-use-unit-v1/results.json').read_text())
assert unit['status']=='passed'
assert all(runtime.sha256(ROOT/p)==h for p,h in unit['source_sha256'].items())
OUT.mkdir(exist_ok=False)
suites=[('private','djinn-source-graph-private-tests',[]),('synthesis','synthesis-tests',[]),
    ('integration','djex-tests',[]),('source-graph','djinn-source-graph-tests',[]),
    ('cli','djex-cli-tests',[]),('church','djex-church-tests',['--report-dir',str(OUT/'church')]),
    ('scopes','djex-rank-n-scope-tests',[])]
paths=[ROOT/p for p in subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
    if p and (ROOT/p).is_file() and 'receipts/' not in p and (Path(p).suffix in
    ['.hs','.lhs','.cabal','.py','.lean','.json','.tsv','.inc'] or p=='cabal.project')]
report=dict(status='running',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    source_sha256={p.relative_to(ROOT).as_posix():runtime.sha256(p) for p in paths},gates=[])
for p in paths:
    dest=OUT/'source'/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
(OUT/'change.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=ROOT))
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
runner=runtime.Processes(OUT,1800)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',djex_datadir=str(ROOT))
def save(): report['processes']=runner.rows;runtime.write_json(OUT/'results.json',report)
try:
    report['active_gate']='strict-build';save()
    result=runner.run('strict-build',['cabal','build']+['djex:test:'+name for _,name,_ in suites]+['--ghc-options=-Werror','-j1'],cwd=ROOT,env=env)
    report['build_exit_code']=result.returncode;assert result.returncode==0
    binaries={name:Path(subprocess.check_output(['cabal','list-bin','djex:test:'+name],cwd=ROOT).decode().strip()) for _,name,_ in suites}
    report['runtime_sha256']={str(p):runtime.sha256(p) for p in binaries.values()};save()
    for label,name,args in suites:
        report['active_gate']=label;save()
        result=runner.run(label,[str(binaries[name]),'-j1']+args,cwd=ROOT,env=env)
        report['gates'].append(dict(name=label,exit_code=result.returncode));save()
        assert result.returncode==0,label+' failed'
except BaseException as failure: report['failure']=repr(failure)
finally:
    report['sources_unchanged']=all(runtime.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
    report['runtimes_unchanged']=all(runtime.sha256(Path(p))==h for p,h in report.get('runtime_sha256',{}).items())
    report['controller_unchanged']=(OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
    report['status']='passed' if len(report['gates'])==len(suites) and 'failure' not in report and all(report[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged']) else 'failed'
    save()
print(report['status'],flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
