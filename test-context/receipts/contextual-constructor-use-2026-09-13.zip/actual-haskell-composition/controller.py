from pathlib import Path
import json,os,subprocess,sys
ROOT=Path.cwd();OUT=ROOT/'dist-newstyle/method-tail-ghc-v4'
sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as runtime
release=json.loads((ROOT/'dist-newstyle/contextual-use-release-v2/results.json').read_text())
assert release['status']=='passed'
assert all(runtime.sha256(ROOT/p)==h for p,h in release['source_sha256'].items())
OUT.mkdir(exist_ok=False)
original=(ROOT/'djinn/test-unit/Spec.hs').read_text()
driver=original.replace('import Djinn.Core (','import qualified Language.Haskell.Synthesis.TypedGenerated.Haskell as ActualHaskell\nimport Djinn.Core (',1)
begin=driver.index('main = defaultMain');end=driver.index('tests ::',begin)
driver=driver[:begin]+'main = testContextualPolymorphicConstructors\n\n'+driver[end:]
preamble='''{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, AllowAmbiguousTypes #-}
module Main where
data LeantType0 = Token Int deriving (Eq, Show)
newtype LeantType1 a = Chain [a] deriving (Eq, Show)
class LeantContext0 a where contextPayload :: LeantType0
instance LeantContext0 Int where contextPayload = Token 7
instance LeantContext0 Bool where contextPayload = Token 11
leantProvider0 :: forall a. LeantContext0 a => LeantType0
leantProvider0 = contextPayload @a
leantProvider1 :: forall a. LeantType1 a
leantProvider1 = Chain []
leantProvider2 :: forall a. a -> LeantType1 a -> LeantType1 a
leantProvider2 x (Chain xs) = Chain (x : xs)
leantProvider3 :: LeantType0
leantProvider3 = Token 0
leantProvider4 :: LeantType0 -> LeantType0
leantProvider4 (Token x) = Token (x + 1)
'''
statement='''            forM_ compositions $ \\graph -> do
'''
insertion=statement+f'''                actual <- expectShownRight $ ActualHaskell.renderHaskellTermGraphAtSignature
                    (SharedGenerated.defaultRenderOptions id) source graph
                let signature = "candidate :: forall v0. LeantContext0 v0 => " ++
                        (if withTail then "LeantType1 LeantType0 -> " else "") ++ "LeantType1 LeantType0"
                    observation = if withTail then
                        "(candidate @Int (Chain [Token 3, Token 5]) == Chain [Token 7, Token 3, Token 5], candidate @Bool (Chain []) == Chain [Token 11])"
                        else "(candidate @Int == Chain [Token 7], candidate @Bool == Chain [Token 11])"
                writeFile ({json.dumps(OUT.as_posix()+'/candidate-')} ++ show withTail ++ ".hs") $
                    {json.dumps(preamble)} ++ unlines [signature, "candidate = " ++ actual, "main :: IO ()", "main = print " ++ observation]
'''
assert driver.count(statement)==1;driver=driver.replace(statement,insertion)
driver_path=OUT/'Emit.hs';driver_path.write_text(driver)
(OUT/'original-Spec.hs').write_text(original)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
runner=runtime.Processes(OUT,300)
report=dict(status='running',source_sha256=release['source_sha256'],driver_sha256=runtime.sha256(driver_path),gates=[])
runtime.write_json(OUT/'results.json',report)
try:
    plan=json.loads((ROOT/'dist-newstyle/cache/plan.json').read_text())
    ids=next(x['depends'] for x in plan['install-plan'] if x.get('component-name')=='test:djinn-tests')
    report['package_ids']=ids
    emitted=runner.run('emit',['cabal','exec','--','runghc','-hide-all-packages']+['-package-id='+x for x in ids]+['-idjinn/test-unit','-idjinn/src-internal',str(driver_path)],cwd=ROOT,env=dict(os.environ,djex_datadir=str(ROOT)))
    report['gates'].append(dict(name='emit',exit_code=emitted.returncode));assert emitted.returncode==0
    report['generated_sha256']={}
    for suffix in ['False','True']:
        path=OUT/('candidate-'+suffix+'.hs');report['generated_sha256'][path.name]=runtime.sha256(path)
        result=runner.run('ghc-'+suffix,['runghc',str(path)],cwd=ROOT)
        report['gates'].append(dict(name='ghc-'+suffix,exit_code=result.returncode,output=result.stdout.strip()))
        assert result.returncode==0 and result.stdout.strip()=='(True,True)'
except BaseException as failure: report['failure']=repr(failure)
finally:
    report['sources_unchanged']=all(runtime.sha256(ROOT/p)==h for p,h in release['source_sha256'].items())
    report['driver_unchanged']=runtime.sha256(driver_path)==report['driver_sha256']
    report['generated_unchanged']=all(runtime.sha256(OUT/p)==h for p,h in report.get('generated_sha256',{}).items())
    report['controller_unchanged']=(OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
    report['processes']=runner.rows
    report['status']='passed' if len(report['gates'])==3 and 'failure' not in report and all(report[k] for k in ['sources_unchanged','driver_unchanged','generated_unchanged','controller_unchanged']) else 'failed'
    runtime.write_json(OUT/'results.json',report)
print(report['status'],report.get('failure',''),flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)



