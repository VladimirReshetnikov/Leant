{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications, TypeAbstractions, FlexibleContexts, AllowAmbiguousTypes #-}
module Main where
data LeantType0 = Token Int deriving (Eq, Show)
newtype LeantType1 a = Chain [a] deriving (Eq, Show)
class LeantContext0 a where contextPayload :: LeantType0
instance LeantContext0 Int where contextPayload = Token 7
instance LeantContext0 Bool where contextPayload = Token 11
leantProvider0 :: forall a. LeantContext0 a => LeantType0
leantProvider0 = contextPayload @a
leantProvider1 :: forall a. LeantType1 a
leantProvider1 = Chain []
leantProvider2 :: forall a. a -> LeantType1 a -> LeantType1 a
leantProvider2 x (Chain xs) = Chain (x : xs)
leantProvider3 :: LeantType0
leantProvider3 = Token 0
leantProvider4 :: LeantType0 -> LeantType0
leantProvider4 (Token x) = Token (x + 1)
candidate :: forall v0. LeantContext0 v0 => LeantType1 LeantType0
candidate = ((((((leantProvider2 :: forall djexBound0_0. djexBound0_0 -> LeantType1 djexBound0_0 -> LeantType1 djexBound0_0) @(LeantType0))) ((((leantProvider0 @(v0)) :: (LeantContext0 v0) => LeantType0) :: LeantType0) :: LeantType0))) (((leantProvider1 :: forall djexBound0_0. LeantType1 djexBound0_0) @(LeantType0)) :: LeantType1 LeantType0))
main :: IO ()
main = print (candidate @Int == Chain [Token 7], candidate @Bool == Chain [Token 11])
