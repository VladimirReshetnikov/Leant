from pathlib import Path
import json,os,subprocess,sys
ROOT=Path.cwd();OUT=ROOT/'dist-newstyle/contextual-use-release-v2';OLD=ROOT/'dist-newstyle/contextual-use-release-v1'
sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as runtime
prior=json.loads((OLD/'results.json').read_text())
assert prior['build_exit_code']==0
assert all(prior[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged'])
assert all(runtime.sha256(ROOT/p)==h for p,h in prior['source_sha256'].items())
assert all(runtime.sha256(Path(p))==h for p,h in prior['runtime_sha256'].items())
passed=[g for g in prior['gates'] if g['exit_code']==0]
assert [g['name'] for g in passed]==['private','synthesis','integration','source-graph']
OUT.mkdir(exist_ok=False)
def binary(kind,name):return Path(subprocess.check_output(['cabal','list-bin','djex:'+kind+':'+name],cwd=ROOT).decode().strip())
helpers=[binary('exe',name) for name in ['djex','djex-fake-cabal','djex-fake-z3']]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',djex_datadir=str(ROOT))
env['PATH']=os.pathsep.join([str(p.parent) for p in helpers]+[os.environ.get('PATH','')])
report=dict(status='running',source_commit=prior['source_commit'],source_sha256=prior['source_sha256'],
    prior_receipt=dict(path=str(OLD/'results.json'),sha256=runtime.sha256(OLD/'results.json')),
    prior_gates=passed,runtime_sha256=dict(prior['runtime_sha256']),gates=[],path_prefix=[str(p.parent) for p in helpers])
report['runtime_sha256'].update({str(p):runtime.sha256(p) for p in helpers})
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
runner=runtime.Processes(OUT,1800)
def save():report['processes']=runner.rows;runtime.write_json(OUT/'results.json',report)
try:
    for label,name,args in [('cli','djex-cli-tests',[]),('church','djex-church-tests',['--report-dir',str(OUT/'church')]),('scopes','djex-rank-n-scope-tests',[])]:
        report['active_gate']=label;save()
        result=runner.run(label,[str(binary('test',name)),'-j1']+args,cwd=ROOT,env=env)
        report['gates'].append(dict(name=label,exit_code=result.returncode));save()
        assert result.returncode==0,label+' failed'
except BaseException as failure:report['failure']=repr(failure)
finally:
    report['sources_unchanged']=all(runtime.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
    report['runtimes_unchanged']=all(runtime.sha256(Path(p))==h for p,h in report['runtime_sha256'].items())
    report['controller_unchanged']=(OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
    report['status']='passed' if len(report['gates'])==3 and 'failure' not in report and all(report[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged']) else 'failed'
    save()
print(report['status'],report.get('failure',''),flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
