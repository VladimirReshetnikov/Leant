# Contextual constructor use acceptance

Native build/source retains the exact Leant sources at base 3b24ebbd with the
eight-file constructor overlay and Djex ebadbefd plus the three-file dependency
overlay. Canonical source snapshots start at 1481e918 plus the same Djex delta.
Use the retained patches and source hashes, not an assumed clean base build.

Run each retained controller in a fresh output directory, adapting absolute
workspace/runtime paths and snapshot guards. The canonical original query and
native query retain 32 raw candidates and the original choice/time limits.
The initial trace and failed normal-priority experiment are diagnostic only.
The first required-use build failed a type-default warning; the corrected
implementation then passed focused and full gates. The native v1 controller
completed the matrix before refusing a stale 709-test inventory expectation.
The v2 continuation verifies identical source/runtime hashes and runs all 711
tests plus both exact signature replay corpora without repeating that matrix.
The initial canonical CLI attempt lacked built command/helper directories on
PATH; its continuation retains the four passing suites, corrects PATH, and
completes CLI, Church and scope checks on identical source/runtime identities.
Haskell emitter attempts retain package/source-path setup failures and the
signature-free renderer refusal. The passing driver uses the original complete
signature with the existing signature-aware renderer and exact Cabal unit IDs.

Compiler/runtime binaries are identified by hashes, not redistributed.
The construction grammar is generic over existing proof assumptions; it does
not contain the example's implementation, add dictionaries, or refund proofs.
The original search and first-proof prefix remain available.
This acceptance adds no Church behavioral cells by association.
