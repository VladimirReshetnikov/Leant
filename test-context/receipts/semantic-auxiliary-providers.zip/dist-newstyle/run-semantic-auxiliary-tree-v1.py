from pathlib import Path
from types import SimpleNamespace
import json,os,subprocess,sys
ROOT=Path('C:/Leant')
sys.path[:0]=[str(ROOT/'test-church'),str(ROOT/'lib/Djex/test-church')]
import behavior_runtime as runtime
import behavior_partial_probe as pins
OUT=ROOT/'dist-newstyle/tree-accumulator-semantic-auxiliary-v1'
OUT.mkdir(exist_ok=False)
EXE=ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/x/leant/build/leant/leant.exe'
KERNEL=Path('C:/Users/vresh/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean.exe')
report={'status':'running','source_hashes':{},'scope':'prepared priority-2 fixture, independent of incomplete native aggregate integration',
 'dependency':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT/'lib/Djex',text=True).strip(),
 'canonical_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd='C:/Djex',text=True).strip()}
args=SimpleNamespace(leant=EXE,lean=str(KERNEL),lean_runtime=KERNEL,toolchain='',backend=None)
exe,backend,lake,runtime_hashes=pins.runtime_identity(args,runtime,report)
env=dict(os.environ,LEANT_BACKEND=str(backend),leant_datadir=str(ROOT),djex_datadir=str(ROOT/'lib/Djex'),PYTHONDONTWRITEBYTECODE='1')
env['PATH']=str(Path(lake).parent)+os.pathsep+env.get('PATH','')
paths={Path(__file__),EXE,*(Path(p) for p in runtime_hashes),*(Path(p) for p in report['source_hashes'])}
def snapshot():return {str(p):runtime.sha256(p) for p in sorted(paths)}
report['before']=snapshot()
runtime.write_json(OUT/'results.json',report)
processes=runtime.Processes(OUT,2400)
try:
 command=[sys.executable,'-B','test-recursive/tree-accumulator/run_acceptance.py',
  '--language','lean','--output',str(OUT/'matrix'),'--leant',str(EXE),'--kernel',str(KERNEL)]
 checked=processes.run('matrix',command,cwd=ROOT,env=env)
 path=OUT/'matrix/results.json'
 data=json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
 report['matrix_status']=data.get('status','missing_receipt')
 report['status']='passed' if checked.returncode==0 and data.get('status')=='passed' else 'incomplete'
finally:
 report['after']=snapshot();report['unchanged']=report['before']==report['after'];report['processes']=processes.rows
 if not report['unchanged']:report['status']='incomplete'
 runtime.write_json(OUT/'results.json',report)
 print(report['status'],flush=True)
