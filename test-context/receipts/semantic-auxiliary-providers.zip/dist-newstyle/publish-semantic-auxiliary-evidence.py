from pathlib import Path
import hashlib,json,zipfile

ROOT=Path('C:/Leant');DJEX=Path('C:/Djex')
out=ROOT/'test-context/receipts';stem='semantic-auxiliary-providers'
sha=lambda b:hashlib.sha256(b).hexdigest()
paths={}
for directory in ['semantic-auxiliary-inventory-v1','semantic-auxiliary-inventory-v2',
 'tree-accumulator-semantic-auxiliary-v1','tree-deadline-audit-v1','semantic-auxiliary-focused-v1']:
 for p in (ROOT/'dist-newstyle'/directory).rglob('*'):
  if p.is_file() and p.suffix in ['.json','.txt','.lean','.sexp']:
   paths[p.relative_to(ROOT).as_posix()]=p
for rel in ['src/Leant/Synth/Fragment.hs','test-context/ProviderInventoryProbe.hs','test-context/run_provider_inventory.py',
 'test-recursive/tree-accumulator/run_acceptance.py','test-recursive/tree-accumulator/test_deadlines.py',
 'test-recursive/tree-accumulator/audit_deadlines.py','test-recursive/tree-accumulator/manifest.json',
 'dist-newstyle/run-semantic-auxiliary-tree-v1.py','dist-newstyle/semantic-auxiliary-build-v1.log',
 'dist-newstyle/semantic-auxiliary-build-v2.log','dist-newstyle/semantic-auxiliary-sdist-v2.log',
 'dist-newstyle/publish-semantic-auxiliary-evidence.py']:
 paths[rel]=ROOT/rel
archive=out/(stem+'.zip');items=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(paths.items()):
  data=p.read_bytes();z.writestr(name,data);items.append(dict(path=name,sha256=sha(data),bytes=len(data)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for item in items:assert sha(z.read(item['path']))==item['sha256']

def read(path):return json.loads((ROOT/'dist-newstyle'/path/'results.json').read_text(encoding='utf-8'))
discovery=read('semantic-auxiliary-inventory-v2');assert discovery['status']=='passed' and discovery['unchanged']
matrix=read('tree-accumulator-semantic-auxiliary-v1/matrix')
assert all(matrix[k] for k in ['source_integrity','executable_integrity','input_integrity','library_integrity','process_capture_integrity'])
assert len(matrix['results'])==6
allowed={'TreeAccumulatorFixture.foldTree','TreeAccumulatorFixture.Tree.leaf','TreeAccumulatorFixture.Tree.branch'}
for row in matrix['results']:
 names={p['name'] for p in row['provider_inventory']}
 assert names<=allowed
 if not row['name'].endswith('reject_all'):assert names==allowed
audits=read('tree-deadline-audit-v1');assert audits['status']=='passed'
assert audits['audits'][0]['accepted_cells']==[]
assert audits['audits'][1]['accepted_cells']==['lean-tree_accumulator_djinn_reject_all']
focused=read('semantic-auxiliary-focused-v1')
assert focused['unchanged'] and all(x['exit_code']==0 for x in focused['checks'][:2])
sdist=(ROOT/'dist-newstyle/semantic-auxiliary-sdist-v2.log').read_text(encoding='utf-8').replace('\\','/')
for suffix in ['ProviderInventoryProbe.hs','run_provider_inventory.py','tree-accumulator/audit_deadlines.py','tree-accumulator/TreeAccumulatorProbe.hs']:assert suffix in sdist
receipt=dict(status='accepted_semantic_provider_filter_not_accumulator_synthesis',date='2026-09-08',
 source_base='64d5705cbdd3cf7a3a36202d32d21f004e393c19',working_dependency='63a23f58d2e0f6fd1ffcd0532412f049dd29e834',committed_dependency='4a4ed0fc23f76d7b82b06496e03adfadbf374f84',
 implementation='Use Lean.isAuxRecursor env n in shared ordinary/contextual automatic provider admission; retain ordinary user elim declarations.',
 validation=dict(real_kernel_discovery_cells=4,focused_provider_tests=5,deadline_regressions=4,strict_native_build=True,
   source_distribution=dict(command=['cabal','sdist','.','--list-only'],status='passed',earlier_attempt='The leant selector chose an executable and was refused; the explicit package directory succeeds.'),
   native_tree_queries=6,positive_inventories_exact=True,accepted_positive_cells=0,
   corrected_accepted_tree_cells=audits['audits'][1]['accepted_cells'],oracle_controls=8,empty_oracle_axiom_inventories=17),
 correction=dict(scope='Only tree accumulator acceptance claims are reclassified here; actual predicate observations are preserved.',
   reason='The shared parser checked actual False observations but the tree fixture omitted its stronger command deadline gate.',
   prior_receipt='../../test-church/receipts/search-failures-retriage.json',
   prior_accepted_false_engines=['exference','both'],corrected_prior_accepted_cells=[],
   superseding_audit=audits,
   evidence_boundary='The six live queries ran once against the rebuilt filter before the harness correction. The new deadline gate was then applied to their immutable hash-checked captures; this is not a second live run.'),
 limits_unchanged=True,full_native_integration='still incomplete; no new complete 701-test run or dependency promotion',
 archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),artifact_count=len(items),excludes='compiled binaries and object files; identities retained in original receipts'),artifacts=items)
(out/(stem+'.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
erratum=dict(status='acceptance_claim_corrected',original_receipt='search-failures-retriage.json',
 corrected_fields=['findings.tree_lean.accepted_false_engines'],
 correction='The original Exference and Both tree False commands timed out. They produced actual false observations, but no original Lean tree cell passes the full original deadline and inventory contract.',
 superseding_receipt='../../test-context/receipts/semantic-auxiliary-providers.json',original_bytes_unchanged=True)
(ROOT/'test-church/receipts/search-failures-retriage.erratum.json').write_text(json.dumps(erratum,indent=2)+'\n',encoding='utf-8')

doc='''# Semantic auxiliary-provider filtering and tree deadline correction

Leant now excludes Lean-generated auxiliary recursors during automatic provider
discovery, using `Lean.isAuxRecursor env n`. The shared ordinary/contextual
generator previously filtered name components but missed constructor-specific
`.elim` helpers. An ordinary user declaration named `elim` remains eligible.
This repairs provider admission; it does not add an accumulator implementation.

The [evidence receipt](RECEIPT) retains exact emitted programs, inventories,
public commands, runtime hashes, failures and the deadline audit. Tests use the
working Djex `63a23f58`; the committed dependency remains `4a4ed0fc`, and complete
native integration is still open.

## Verification

- Four real-kernel discovery cells pass: ordinary/contextual modes, each through
  namespace roots and explicit session names. Every cell retains exactly the
  generic fold, two constructors and an ordinary user `elim`. The session cases
  explicitly name the generated helpers and still exclude them.
- The strict native executable and test builds pass. All five existing provider
  discovery tests and four new deadline regressions pass. These are focused
  checks, not a new full 701-test integration run.
- The six original public Lean tree queries run against the rebuilt executable
  at unchanged provider, search and time limits. All observed provider names
  satisfy the original allowlist; every positive query discovers exactly the
  supplied fold and two constructors. The oracle still passes eight controls
  with 17 empty axiom inventories.
- The source distribution includes the discovery helper and portable tree
  fixtures. The initially ambiguous Cabal executable selector was corrected to
  the explicit package directory; the failed invocation is retained.

## Corrected tree outcomes

| Engine | Positive accumulator query | False control |
| --- | --- | --- |
| Djinn | No match; 39 false observations, zero inconclusive | Passes within the deadline; 194 actual false observations |
| Exference | Exceeds 90 seconds; 108 false observations, zero inconclusive | Exceeds 90 seconds; 446 actual false observations; failed cell |
| Both | Exceeds 90 seconds; 175 false observations and one inconclusive | Exceeds 90 seconds; 404 actual false observations; failed cell |

These results contain **zero accepted positive accumulator cells**. A bounded
miss or timeout is not a proof of uninhabitation. The inventory change alone does
not establish a causal performance improvement from elapsed-time comparisons.

The shared behavioral parser establishes actual predicate observations, even if
a command subsequently reaches its deadline. The tree fixture promised a
stronger acceptance rule but did not enforce that extra check. It now rejects
the production deadline message before accepting either a positive or False
cell; a successful prefix cannot override cancellation. Four focused regressions
cover false observations, an accepted prefix, completed rejection, and the
distinction between a configured timeout and an actual timeout event.

The [previous receipt's erratum](ERRATUM) corrects the earlier claim that
Exference and Both tree False controls passed. Both commands had timed out.
Their rejection observations remain valid, but **none of that earlier Lean
tree matrix's cells passes the complete inventory/deadline contract**. Original
receipts and captures remain byte-for-byte intact.

The new six-query run finished before the harness correction. The corrected
gate was applied to its exact hash-checked captures and to the earlier matrix;
this transcript audit is not presented as a second live synthesis run. The new
Djinn False cell passes both the original inventory check and the added deadline
check. The audit retains every original status beside the corrected status.

## Reproduction and remaining work

The [discovery runner](DISCOVERY) compiles the actual production generator and
checks its emitted Lean inventories with the production Haskell parser. The
[tree fixture](TREE) retains the original type, 16 observations, fold-only value
inventory and search limits. Its `audit_deadlines.py` accepts one or more
`--receipt` arguments and a fresh `--output` directory; it verifies each original
capture's hash before applying the corrected gate.

The next priority-2 construction remains the function-carrier tree fold. A
state-transformer witness already expresses the requested behavior, so trace
its instantiation and scheduling before expanding recursion machinery. Keep
the recurring layered-provider integration deadline, bounded Haskell frontend
usability, and all 13 extended plus 19 explicit-default behavioral operations
open. This milestone does not alter their acceptance requirements.
'''
for root in [ROOT,DJEX]:
 remote='https://github.com/VladimirReshetnikov/Leant/blob/main/'
 replacements={'RECEIPT':'../../test-context/receipts/semantic-auxiliary-providers.json' if root==ROOT else remote+'test-context/receipts/semantic-auxiliary-providers.json',
 'ERRATUM':'../../test-church/receipts/search-failures-retriage.erratum.json' if root==ROOT else remote+'test-church/receipts/search-failures-retriage.erratum.json',
 'DISCOVERY':'../../test-context/run_provider_inventory.py' if root==ROOT else remote+'test-context/run_provider_inventory.py',
 'TREE':'../../test-recursive/tree-accumulator/README.md' if root==ROOT else remote+'test-recursive/tree-accumulator/README.md'}
 text=doc
 for key,val in replacements.items():text=text.replace(key,val)
 (root/'docs/reports/2026-09-08-semantic-auxiliary-providers.md').write_text(text,encoding='utf-8')
 p=root/'docs/reports/README.md';text=p.read_text(encoding='utf-8')
 text+='\n- 2026-09-08 — [Semantic auxiliary-provider filtering and tree deadline correction](2026-09-08-semantic-auxiliary-providers.md) — four real-kernel discovery cells, public inventory repair, and corrected timeout acceptance.\n'
 p.write_text(text,encoding='utf-8')
 p=root/'docs/reports/2026-09-08-post-integration-priorities.md';text=p.read_text(encoding='utf-8')
 start=text.index('The next work should');end=text.index('The [new evidence receipt]')
 text=text[:start]+'''The [semantic auxiliary-provider filter](2026-09-08-semantic-auxiliary-providers.md)
is now implemented and verified through four real-kernel discovery cells and
the public tree inventories. The remaining concrete gaps are costly layered-
provider search, accumulator composition through a supplied fold, and bounded
Haskell frontend usability. The original priorities 1–4 remain intact.

**Tree acceptance correction:** the earlier Exference and Both False controls
timed out. They produced actual rejection observations, but did not pass the
fixture's full deadline contract. The linked report supersedes those pass
labels. After filtering, only the new Djinn False cell passes; no positive tree
cell is accepted. Original receipts remain unchanged.

'''+text[end:]
 text=text.replace('Exference and Both False controls pass separately; Djinn\'s False outcome fails the inventory gate.',
 'Exference and Both False controls time out; Djinn\'s earlier False outcome fails the inventory gate. The later correction preserves those observations but invalidates the pass labels.')
 lines=text.splitlines()
 for i,line in enumerate(lines):
  if line.startswith('| 1 | **Exclude generated'):
   lines[i]='| 1 — delivered | **Exclude generated auxiliary recursors semantically in Lean provider discovery.** The shared generator now uses `Lean.isAuxRecursor env n`. | Four real-kernel discovery combinations pass, preserving an ordinary user `elim`; the public tree inventories satisfy the original allowlist. See the [implementation and deadline correction](2026-09-08-semantic-auxiliary-providers.md). Accumulator synthesis remains unaccepted. |'
 text='\n'.join(lines)+'\n'
 text=text.replace('production discovery filter is still unchanged.','production discovery filter is now implemented; the linked follow-up records its exact validation.')
 p.write_text(text,encoding='utf-8')
 p=root/'README.md';text=p.read_text(encoding='utf-8')
 if root==ROOT:
  old="  The supplied tree accumulator is now an executed Haskell miss; Lean's positive\n  cells fail the generated-provider inventory gate."
  new="""  The [semantic provider filter](docs/reports/2026-09-08-semantic-auxiliary-providers.md)
  now excludes generated auxiliary eliminators while retaining ordinary user
  `elim` functions. Four real-kernel discovery checks and the public tree
  inventories pass. The accumulator remains an executed synthesis miss;
  Exference/Both timeouts are failed cells, including their False controls."""
 else:
  old="The supplied tree accumulator is now an executed miss in both Haskell engines;\nLean's positive cells fail the generated-provider inventory gate."
  new="""The supplied tree accumulator remains an executed miss in both Haskell engines.
Leant's [semantic provider filter](docs/reports/2026-09-08-semantic-auxiliary-providers.md)
now fixes generated-eliminator admission while retaining ordinary user `elim`
functions. Its public tree inventories pass; positive synthesis remains open.
The report also corrects earlier tree False-control pass labels: the Exference
and Both commands timed out and fail the fixture's deadline contract."""
 assert old in text
 p.write_text(text.replace(old,new),encoding='utf-8')
 p=root/'docs/reports/2026-09-07-synthesis-retriage.md';text=p.read_text(encoding='utf-8')
 text=text.replace("The tree accumulator is now an executed Haskell miss, and Lean's positive tree\ncells expose generated auxiliary eliminators in the provider inventory.",
 "The tree accumulator remains an executed Haskell miss. The later\n[semantic provider filter](2026-09-08-semantic-auxiliary-providers.md) repairs\nLean's generated-eliminator admission and corrects the tree False-control\ntimeout claims; it adds no accepted positive accumulator cell.")
 p.write_text(text,encoding='utf-8')
print(json.dumps(receipt['archive']))
