set_option autoImplicit false
class Ctx.C (α : Type) where out : Nat
def ConstructorOracle.implementation : ∀ ⦃α : Type⦄, [Ctx.C α] → ∀ ⦃β : Type⦄, [Ctx.C β] → List Nat :=
fun ⦃α : Type⦄ [d : Ctx.C α] ⦃β : Type⦄ [e : Ctx.C β] => [@Ctx.C.out α d]
theorem ConstructorOracle.passes : (@ConstructorOracle.implementation Nat (@Ctx.C.mk Nat 7) Bool (@Ctx.C.mk Bool 11) = [7]) ∧ (@ConstructorOracle.implementation Nat (@Ctx.C.mk Nat 11) Bool (@Ctx.C.mk Bool 7) = [11]) := by decide
#print axioms ConstructorOracle.implementation
#print axioms ConstructorOracle.passes
