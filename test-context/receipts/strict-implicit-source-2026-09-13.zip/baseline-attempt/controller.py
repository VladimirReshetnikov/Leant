from pathlib import Path
import json,os,re,subprocess,sys

ROOT=Path.cwd()
assert ROOT==Path('C:/Leant-validation/strict-implicit-source')
OLD=Path('C:/Leant-validation/constructor-closure')
OUT=ROOT/'dist-newstyle/strict-implicit-v1'
sys.path.insert(0,str(ROOT/'lib/Djex/test-church'))
import behavior_runtime as runtime

accepted=json.loads((OLD/'dist-newstyle/acyclic-head-acceptance-v1/results.json').read_text())
assert accepted['status']=='passed'
assert all(runtime.sha256(OLD/p)==h for p,h in accepted['source_sha256'].items())
assert all(runtime.sha256(Path(p))==h for p,h in accepted['runtime_sha256'].items())
OUT.mkdir(exist_ok=False)
paths=[]
for repo in [ROOT,ROOT/'lib/Djex']:
    paths += [repo/p for p in subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0')
        if p and (repo/p).is_file() and (Path(p).suffix in ['.hs','.lhs','.py','.lean','.cabal'] or p=='cabal.project')]
paths.append(ROOT/'test-context/run_strict_implicit.py')
report=dict(status='running',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    dependency_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT/'lib/Djex').decode().strip(),
    source_sha256={p.relative_to(ROOT).as_posix():runtime.sha256(p) for p in paths},gates=[],
    scope='Focused Type-0 strict-implicit contextual source support. No broader universe or dependent-binder acceptance.')
assert report['dependency_commit']=='c2d5530f6951a3b4b81a23372285902bc1ab35ee'
for name in report['source_sha256']:
    dest=OUT/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes((ROOT/name).read_bytes())
(OUT/'change.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=ROOT))
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
kernel=Path('C:/Users/vresh/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean.exe')
backend=Path('C:/Users/vresh/AppData/Local/Python/pythoncore-3.14-64/Lib/site-packages/lean_interact/cache/augustepoiroux/repl/repl_v1.3.18_lean-toolchain-v4.32.0/.lake/build/bin/repl.exe')
old_exe=OLD/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/x/leant/build/leant/leant.exe'
report['runtime_sha256']={str(p):runtime.sha256(p) for p in [kernel,backend,old_exe]}
entry=OUT/'baseline-entry.py'
entry.write_text('import sys,runpy\nfrom pathlib import Path\n'
    +f'sys.path.insert(0,{str(OLD/"test-context")!r})\n'
    +'import run_constructors\n'
    +f'assert run_constructors.ROOT==Path({str(OLD)!r})\n'
    +f'runpy.run_path({str(ROOT/"test-context/run_strict_implicit.py")!r},run_name="__main__")\n',encoding='utf-8')
runner=runtime.Processes(OUT,600)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',LEANT_BACKEND=str(backend),
    leant_datadir=str(ROOT),djex_datadir=str(ROOT/'lib/Djex'))

def save():
    report['processes']=runner.rows;runtime.write_json(OUT/'results.json',report)

def run(label,command,guard):
    report['active_gate']=label;save();runner.timeout=guard
    return runner.run(label,command,cwd=ROOT,env=env)

save()
try:
    base=run('published-baseline',[sys.executable,'-X','utf8','-B',str(entry),
        '--output',str(OUT/'baseline'),'--leant',str(old_exe),'--lean-runtime',str(kernel),
        '--backend',str(backend),'--engine','djinn','--operation','argument'],600)
    baseline=json.loads((OUT/'baseline/results.json').read_text())
    original_refusal=(base.returncode==1 and baseline['status']=='failed'
        and baseline['source_and_input_hashes_unchanged'] and baseline['exact_replay_sources_unchanged']
        and len(baseline['results'])==2 and all(row.get('oracle',{}).get('status')=='passed'
            and 'source admission or provider discovery failed' in row.get('failure','') for row in baseline['results']))
    report['baseline_original_refusal']=original_refusal
    assert original_refusal,'baseline did not establish the expected source-admission boundary'
    build=run('strict-build',['cabal','build','leant:exe:leant','leant:test:leant-synth-tests',
        'djex:exe:djex-fake-z3','--ghc-options=-Werror','-j1'],1800)
    report['build_exit_code']=build.returncode
    assert build.returncode==0,'strict build failed'
    binaries={name:Path(subprocess.check_output(['cabal','list-bin',target],cwd=ROOT).decode().strip())
        for name,target in [('exe','leant:exe:leant'),('unit','leant:test:leant-synth-tests')]}
    report['runtime_sha256'].update({str(p):runtime.sha256(p) for p in binaries.values()})
    unit=run('strict-source-unit',[str(binaries['unit']),'-p','strict implicit','--num-threads','1'],300)
    report['gates'].append(dict(name='strict-source-unit',exit_code=unit.returncode))
    assert unit.returncode==0 and re.search(r'All 8 tests passed',unit.stdout),'strict source unit gate failed or changed inventory'
    live=run('live-replay',[sys.executable,'-X','utf8','-B','test-context/run_strict_implicit.py',
        '--output',str(OUT/'live'),'--leant',str(binaries['exe']),'--lean-runtime',str(kernel),
        '--backend',str(backend)],3600)
    result=json.loads((OUT/'live/results.json').read_text())
    passed=live.returncode==0 and result['status']=='passed' and len(result['results'])==15
    report['gates'].append(dict(name='live-replay',exit_code=live.returncode,complete=passed))
except BaseException as failure:
    report['failure']=repr(failure)
finally:
    report['sources_unchanged']=all(runtime.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
    report['runtimes_unchanged']=all(runtime.sha256(Path(p))==h for p,h in report['runtime_sha256'].items())
    report['controller_unchanged']=(OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
    report['status']='passed' if report.get('baseline_original_refusal') and report.get('build_exit_code')==0 \
        and len(report['gates'])==2 and all(g['exit_code']==0 and g.get('complete',True) for g in report['gates']) \
        and all(report[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged']) else 'failed'
    save()
print(report['status'],report.get('failure',''),flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
