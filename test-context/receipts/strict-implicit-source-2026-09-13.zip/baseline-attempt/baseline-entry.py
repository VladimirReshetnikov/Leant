import sys,runpy
from pathlib import Path
sys.path.insert(0,'C:\\Leant-validation\\constructor-closure\\test-context')
import run_constructors
assert run_constructors.ROOT==Path('C:\\Leant-validation\\constructor-closure')
runpy.run_path('C:\\Leant-validation\\strict-implicit-source\\test-context\\run_strict_implicit.py',run_name="__main__")
