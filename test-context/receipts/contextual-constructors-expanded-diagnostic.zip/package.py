from pathlib import Path
import hashlib, json, zipfile

root = Path('C:/Leant')
out = root / 'dist-newstyle/contextual-constructors-live-v2'
destination = root / 'test-context/receipts'
destination.mkdir(exist_ok=True)
report = json.loads((out / 'results.json').read_text(encoding='utf-8'))
assert report['status'] == 'failed'
assert report['source_and_input_hashes_unchanged'] and report['exact_replay_sources_unchanged']
assert len(report['cases']) == len(report['results']) == 27
assert len({c['name'] for c in report['cases']}) == 27
assert sum(r['status'] == 'candidate' for r in report['results']) == 17
assert sum(r['status'] == 'no_candidate' for r in report['results']) == 6
assert sum(r['status'] == 'failed' for r in report['results']) == 4
assert all(r['oracle']['status'] == 'passed' for r in report['results'])
assert all(r['replay']['status'] == 'passed' for r in report['results'] if r['status'] == 'candidate')

def sha(data): return hashlib.sha256(data).hexdigest()

files = {}
omitted = []
for spelling, expected in report['source_and_input_hashes_before'].items():
    path = Path(spelling)
    data = path.read_bytes()
    assert sha(data) == expected, spelling
    if path.suffix.lower() in {'.exe', '.dll', '.so', '.dylib'}:
        omitted.append(dict(path=spelling, sha256=expected, reason='runtime binary retained by identity, not redistributed'))
        continue
    name = ('sources/' + path.relative_to(root).as_posix() if path.is_relative_to(root)
            else 'external-sources/' + expected + '/' + path.name)
    files[name] = data
for path in out.rglob('*'):
    if path.is_file(): files['run/' + path.relative_to(out).as_posix()] = path.read_bytes()
files['strict-build-v11.log'] = (root / 'dist-newstyle/contextual-constructors-build-v11.log').read_bytes()
files['plan.snapshot.json'] = (root / 'dist-newstyle/cache/plan.json').read_bytes()
files['package.py'] = Path(__file__).read_bytes()
manifest = [dict(path=name, bytes=len(data), sha256=sha(data)) for name, data in sorted(files.items())]
archive = destination / 'contextual-constructors-expanded-diagnostic.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
    for name, data in sorted(files.items()): target.writestr(name, data)
    target.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    for member in manifest: assert sha(check.read(member['path'])) == member['sha256']
cases = {c['name']: c for c in report['cases']}
summary = dict(schema=1, status='diagnostic_complete_acceptance_failed',
    scope='Uncommitted contextual-constructor implementation plus unsuccessful specialized-plan ordering experiment; not a release acceptance.',
    source_and_input_hashes_unchanged=True, exact_replay_sources_unchanged=True,
    positive_count=21, positive_replay_passes=17, false_control_count=6, false_control_passes=6,
    oracle_passes=27, failed_cases=[dict(name=r['name'], engine=cases[r['name']]['engine'],
        operation=cases[r['name']]['operation'], failure=r['failure']) for r in report['results'] if r['status']=='failed'],
    cases=[dict(name=r['name'], engine=cases[r['name']]['engine'], operation=cases[r['name']]['operation'],
        expected=cases[r['name']]['expected'], status=r['status']) for r in report['results']],
    process_count=len(report['processes']), process_exit_codes=[r['exit_code'] for r in report['processes']],
    archive=dict(path=archive.name, sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size,
        artifact_count=len(manifest), manifest_member='manifest.json'), omitted_runtime_binaries=omitted)
(destination / 'contextual-constructors-expanded-diagnostic.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:summary[k] for k in ['status','positive_replay_passes','false_control_passes','oracle_passes','process_count','archive']}))
