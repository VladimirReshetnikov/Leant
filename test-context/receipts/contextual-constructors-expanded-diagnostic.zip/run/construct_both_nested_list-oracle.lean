set_option autoImplicit false
class Ctx.C (α : Type) where out : Nat
def ConstructorOracle.implementation : ∀ (α β : Type), [Ctx.C α] → β → List (List β) :=
fun (α β : Type) [d : Ctx.C α] (x : β) => [[x]]
theorem ConstructorOracle.passes : (@ConstructorOracle.implementation Nat Nat (@Ctx.C.mk Nat 7) 37 = [[37]]) ∧ (@ConstructorOracle.implementation Nat Bool (@Ctx.C.mk Nat 11) true = [[true]]) := by decide
#print axioms ConstructorOracle.implementation
#print axioms ConstructorOracle.passes
