set_option autoImplicit false
class Ctx.C (α : Type) where out : Nat
def ConstructorOracle.implementation : ∀ (α β : Type), [Ctx.C α] → β → List β → List β :=
fun (α β : Type) [d : Ctx.C α] (x : β) (xs : List β) => x :: xs
theorem ConstructorOracle.passes : (@ConstructorOracle.implementation Nat Nat (@Ctx.C.mk Nat 7) 37 [3, 5] = [37, 3, 5]) ∧ (@ConstructorOracle.implementation Nat Bool (@Ctx.C.mk Nat 11) true [false] = [true, false]) := by decide
#print axioms ConstructorOracle.implementation
#print axioms ConstructorOracle.passes
