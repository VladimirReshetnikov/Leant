set_option autoImplicit false
class Ctx.C (α : Type) where out : Nat
def ConstructorReplay.implementation : ∀ (α : Type), [Ctx.C α] → List Nat → List Nat :=
((fun (leantType120 : Type) => (fun [leantGiven137x0 : @_root_.«Ctx».«C» (leantType120)] => @(let leantHead155 : (@_root_.«Nat» → ((@_root_.«List».{0} (@_root_.«Nat»)) → (@_root_.«List».{0} (@_root_.«Nat»)))) := @(let leantHead174 : (∀ {leantBound0x0 : Type}, (leantBound0x0 → ((@_root_.«List».{0} (leantBound0x0)) → (@_root_.«List».{0} (leantBound0x0))))) := @_root_.«List».«cons».{0}; @leantHead174 (@_root_.«Nat»)); @leantHead155 (@(let leantHead215 : (∀ [@_root_.«Ctx».«C» (leantType120)], @_root_.«Nat») := @(let leantHead237 : (∀ (leantBound0x0 : Type) [@_root_.«Ctx».«C» (leantBound0x0)], @_root_.«Nat») := @_root_.«Ctx».«C».«out»; @leantHead237 (leantType120)); @leantHead215 leantGiven137x0) : @_root_.«Nat»)))) : (∀ (leantBound0x0 : Type) [@_root_.«Ctx».«C» (leantBound0x0)], ((@_root_.«List».{0} (@_root_.«Nat»)) → (@_root_.«List».{0} (@_root_.«Nat»)))))
theorem ConstructorReplay.passes : (@ConstructorReplay.implementation Nat (@Ctx.C.mk Nat 7) [3, 5] = [7, 3, 5]) ∧ (@ConstructorReplay.implementation Nat (@Ctx.C.mk Nat 11) [] = [11]) := by decide
#print axioms ConstructorReplay.implementation
#print axioms ConstructorReplay.passes
