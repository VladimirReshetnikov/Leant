set_option autoImplicit false
class Ctx.C (α : Type) where out : Nat
def ConstructorReplay.implementation : ∀ (α β : Type), [Ctx.C α] → β → List β → List β :=
((fun (leantType120 : Type) => (fun (leantType137 : Type) => (fun [leantGiven155x0 : @_root_.«Ctx».«C» (leantType120)] => @(let leantHead174 : (∀ {leantBound0x0 : Type}, (leantBound0x0 → ((@_root_.«List».{0} (leantBound0x0)) → (@_root_.«List».{0} (leantBound0x0))))) := @_root_.«List».«cons».{0}; @leantHead174 (leantType137))))) : (∀ (leantBound0x0 : Type) (leantBound0x1 : Type) [@_root_.«Ctx».«C» (leantBound0x0)], (leantBound0x1 → ((@_root_.«List».{0} (leantBound0x1)) → (@_root_.«List».{0} (leantBound0x1))))))
theorem ConstructorReplay.passes : (@ConstructorReplay.implementation Nat Nat (@Ctx.C.mk Nat 7) 37 [3, 5] = [37, 3, 5]) ∧ (@ConstructorReplay.implementation Nat Bool (@Ctx.C.mk Nat 11) true [false] = [true, false]) := by decide
#print axioms ConstructorReplay.implementation
#print axioms ConstructorReplay.passes
