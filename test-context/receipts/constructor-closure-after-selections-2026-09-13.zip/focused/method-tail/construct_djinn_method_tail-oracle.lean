set_option autoImplicit false
class Ctx.C (α : Type) where out : Nat
def ConstructorOracle.implementation : ∀ (α : Type), [Ctx.C α] → List Nat → List Nat :=
fun (α : Type) [d : Ctx.C α] (xs : List Nat) => @Ctx.C.out α d :: xs
theorem ConstructorOracle.passes : (@ConstructorOracle.implementation Nat (@Ctx.C.mk Nat 7) [3, 5] = [7, 3, 5]) ∧ (@ConstructorOracle.implementation Nat (@Ctx.C.mk Nat 11) [] = [11]) := by decide
#print axioms ConstructorOracle.implementation
#print axioms ConstructorOracle.passes
