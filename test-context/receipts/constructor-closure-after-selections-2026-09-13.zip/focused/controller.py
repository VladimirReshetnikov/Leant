from pathlib import Path
import json, os, subprocess, sys

ROOT = Path(__file__).resolve().parent
BUILD = ROOT/'dist-newstyle/constructor-closure-build-v1'
OUT = ROOT/'dist-newstyle/constructor-closure-focused-v1'
sys.path.insert(0,str(ROOT/'lib/Djex/test-church'))
import behavior_runtime as runtime

build=json.loads((BUILD/'results.json').read_text())
assert build['status']=='passed'
assert all(runtime.sha256(ROOT/p)==h for p,h in build['source_sha256'].items())
def binary(target):
    return Path(subprocess.check_output(['cabal','list-bin',target],cwd=ROOT).decode().strip())
exe=binary('leant:exe:leant')
unit=binary('djex:test:djinn-tests')
kernel=Path('C:/Users/vresh/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean.exe')
backend=Path('C:/Users/vresh/AppData/Local/Python/pythoncore-3.14-64/Lib/site-packages/lean_interact/cache/augustepoiroux/repl/repl_v1.3.18_lean-toolchain-v4.32.0/.lake/build/bin/repl.exe')
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
identities={str(p):runtime.sha256(p) for p in [exe,unit,kernel,backend]}
report=dict(status='running',source_commit=build['source_commit'],dependency_commit=build['dependency_commit'],
    build='constructor-closure-build-v1',source_sha256=build['source_sha256'],runtime_sha256=identities,gates=[])
runner=runtime.Processes(OUT,1200)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',leant_datadir=str(ROOT),djex_datadir=str(ROOT/'lib/Djex'),LEANT_BACKEND=str(backend))
common=[sys.executable,'-X','utf8','-B',str(ROOT/'test-context/run_constructors.py'),
    '--leant',str(exe),'--lean-runtime',str(kernel),'--backend',str(backend)]
runtime.write_json(OUT/'results.json',report)
try:
    for label, options in [('method-tail',['--engine','djinn','--operation','method_tail']),
                           ('nested-context',['--operation','nested_context'])]:
        result=runner.run(label,common+['--output',str(OUT/label)]+options,cwd=ROOT,env=env)
        detail=json.loads((OUT/label/'results.json').read_text())
        report['gates'].append(dict(name=label,exit_code=result.returncode,status=detail['status'],
            results=[{k:r[k] for k in ['name','status','failure'] if k in r} for r in detail['results']]))
        runtime.write_json(OUT/'results.json',report)
        print(json.dumps(report['gates'][-1]),flush=True)
    result=runner.run('canonical-composition',[str(unit),'-p','compose contextual methods with polymorphic values of abstract datatypes'],cwd=ROOT/'lib/Djex',env=env)
    report['gates'].append(dict(name='canonical-composition',exit_code=result.returncode))
except Exception as failure:
    report['failure']=repr(failure)
finally:
    report['sources_unchanged']=all(runtime.sha256(ROOT/p)==h for p,h in build['source_sha256'].items())
    report['runtimes_unchanged']=all(runtime.sha256(Path(p))==h for p,h in identities.items())
    report['controller_unchanged']=(OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
    report['processes']=runner.rows
    report['status']='focused_passed' if len(report['gates'])==3 and all(g['exit_code']==0 for g in report['gates']) and 'failure' not in report and all(report[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged']) else 'focused_failed'
    runtime.write_json(OUT/'results.json',report)
print(report['status'],flush=True)
raise SystemExit(0 if report['status']=='focused_passed' else 1)
