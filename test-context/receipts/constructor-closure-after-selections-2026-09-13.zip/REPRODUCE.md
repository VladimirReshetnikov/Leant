# Bounded constructor closure after lexical-selection acceptance

Start from Leant 3b24ebbd4022255b8e22888408d7e890984f3887, with Djex
ebadbefd175ac98d4f79393d4ed4a4089a1725bf. Apply build/native.patch and
build/dependency.patch. The complete tested source inputs are under build/source.
The build controller originally copies pending files from the root workspaces;
use these retained patches and snapshots for standalone reproduction instead.
Adapt local runtime paths and choose fresh output directories for all runs.

Run the strict build and the four original positive failures via the unchanged
run_constructors.py fixture: method_tail with Djinn, then nested_context with
Djinn, Exference and Both. Run the focused canonical composition regression.
The controllers record exact commands, bounds, owned processes and hashes.

The strict build passes. Three nested-context positives pass exact Lean replay.
Djinn method_tail still misses at 32 candidates; its canonical regression also
fails. This is an unsuccessful closure attempt, not complete constructor release
acceptance. The full 21-positive/six-control matrix and full units were not run.
No Church behavior cells are added. Source and runtime integrity checks pass.
