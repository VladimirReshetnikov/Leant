from pathlib import Path
import json, os, subprocess, sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'dist-newstyle/constructor-closure-build-v1'
sys.path.insert(0, str(ROOT/'lib/Djex/test-church'))
import behavior_runtime as runtime

native = ['src/Leant/Synth/ContextRender.hs', 'src/Leant/Synth/ContextSource.hs',
    'src/Leant/Synth/Engine.hs', 'src/Leant/Synth/Fragment.hs', 'src/Main.hs',
    'test-unit/ContextRenderSpec.hs', 'test-unit/ContextSourceSpec.hs', 'test-unit/Spec.hs']
canonical = ['djinn/src-core/Djinn/Core.hs', 'djinn/test-unit/Spec.hs']
def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])
assert git(ROOT, 'rev-parse', 'HEAD').decode().strip() == '3b24ebbd4022255b8e22888408d7e890984f3887'
assert git(ROOT/'lib/Djex', 'rev-parse', 'HEAD').decode().strip() == 'ebadbefd175ac98d4f79393d4ed4a4089a1725bf'
assert not git(ROOT, 'diff', '--name-only')
assert not git(ROOT/'lib/Djex', 'diff', '--name-only')
assert (Path('C:/Leant/lib/Djex')/canonical[0]).read_bytes() == (Path('C:/Djex')/canonical[0]).read_bytes()
OUT.mkdir(parents=True, exist_ok=False)
for source, destination, names in [(Path('C:/Leant'), ROOT, native), (Path('C:/Djex'), ROOT/'lib/Djex', canonical)]:
    for name in names:
        (destination/name).write_bytes((source/name).read_bytes())
report = dict(status='running', source_commit=git(ROOT,'rev-parse','HEAD').decode().strip(),
    dependency_commit=git(ROOT/'lib/Djex','rev-parse','HEAD').decode().strip(),
    native_overlay=native, dependency_overlay=canonical, source_sha256={})
paths = {Path(__file__)}
for repo in [ROOT, ROOT/'lib/Djex']:
    for name in git(repo,'ls-files','-z').decode().split('\0'):
        p = repo/name
        if name and p.is_file() and (p.suffix in ['.hs','.lhs','.py','.lean','.cabal'] or p.name in ['cabal.project','lean-toolchain']):
            paths.add(p)
for p in sorted(paths):
    rel = p.relative_to(ROOT).as_posix()
    report['source_sha256'][rel] = runtime.sha256(p)
    dest = OUT/'source'/rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(p.read_bytes())
(OUT/'native.patch').write_bytes(git(ROOT,'diff','--binary','--',*native))
(OUT/'dependency.patch').write_bytes(git(ROOT/'lib/Djex','diff','--binary','--',*canonical))
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
runner = runtime.Processes(OUT, 9000)
runtime.write_json(OUT/'results.json', report)
try:
    result = runner.run('strict-build', ['cabal','build','leant:exe:leant',
        'leant:test:leant-synth-tests','djex:exe:djex-fake-z3','djex:test:djinn-tests',
        '--ghc-options=-Werror','-j1'], cwd=ROOT, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
    report['exit_code'] = result.returncode
finally:
    report['sources_unchanged'] = all(runtime.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
    report['controller_unchanged'] = (OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
    report['processes'] = runner.rows
    report['status'] = 'passed' if report.get('exit_code')==0 and report['sources_unchanged'] and report['controller_unchanged'] else 'failed'
    runtime.write_json(OUT/'results.json',report)
print(report['status'],flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
