from pathlib import Path
import json, os, subprocess, sys

ROOT = Path.cwd()
DJEX = Path('C:/Djex-validation/scoped-source-selections')
OUT = ROOT/'dist-newstyle/exference-selection-native-build-v1'
validation = json.loads((DJEX/'dist-newstyle/exference-selections-validation-v2/results.json').read_text())
assert validation['status']=='passed'
sys.path.insert(0,str(ROOT/'lib/Djex/test-church'))
import behavior_runtime as runtime
assert all(runtime.sha256(DJEX/p)==h for p,h in validation['source_sha256'].items())
assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT/'lib/Djex')==b''
overlay = [
 'exference/src-core/Language/Haskell/Exference/Core/ConstraintSolver.hs',
 'exference/src-core/Language/Haskell/Exference/Core/Expression.hs',
 'exference/src-core/Language/Haskell/Exference/Core/Internal/Exference.hs',
 'exference/src-core/Language/Haskell/Exference/Core/Internal/ExpressionCheck.hs',
 'exference/test-engine/EngineSpec.hs',
 'exference/test-unit/Spec.hs',
 'test-integration/ContextEvidenceSpec.hs',
]
OUT.mkdir(exist_ok=False)
for name in overlay:
 (ROOT/'lib/Djex'/name).write_bytes((DJEX/name).read_bytes())
report = {'status':'running',
 'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
 'dependency_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT/'lib/Djex').decode().strip(),
 'canonical_validation':'exference-selections-validation-v2',
 'dependency_overlay':{name:runtime.sha256(DJEX/name) for name in overlay}, 'source_sha256':{}}
paths = {ROOT/'test-context/run_scoped_selections.py'}
for repo in [ROOT,ROOT/'lib/Djex']:
 for name in subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0'):
  p = repo/name
  if name and p.is_file() and (p.suffix in ['.hs','.lhs','.py','.lean','.cabal'] or p.name in ['cabal.project','lean-toolchain']): paths.add(p)
for p in sorted(paths):
 rel = p.relative_to(ROOT).as_posix()
 report['source_sha256'][rel] = runtime.sha256(p)
 dest = OUT/'source'/rel
 dest.parent.mkdir(parents=True,exist_ok=True)
 dest.write_bytes(p.read_bytes())
(OUT/'dependency.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=ROOT/'lib/Djex'))
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
runner = runtime.Processes(OUT,9000)
runtime.write_json(OUT/'results.json',report)
try:
 result = runner.run('strict-build',['cabal','build','leant:exe:leant','leant:test:leant-synth-tests','djex:exe:djex-fake-z3','--ghc-options=-Werror','-j1'],cwd=ROOT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
 report['exit_code'] = result.returncode
finally:
 report['sources_unchanged'] = all(runtime.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
 report['controller_unchanged'] = (OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
 report['processes'] = runner.rows
 report['status'] = 'passed' if report.get('exit_code')==0 and report['sources_unchanged'] and report['controller_unchanged'] else 'failed'
 runtime.write_json(OUT/'results.json',report)
print(report['status'],flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
