set_option autoImplicit false
class Ctx.C (α : Type) where out : Nat
def SelectionReplay.implementation : ∀ (α β : Type), [Ctx.C α] → [Ctx.C β] → Nat :=
((fun (leantType6 : Type) => (fun (leantType11 : Type) => (fun [leantGiven17x0 : @_root_.«Ctx».«C» (leantType6)] [leantGiven17x1 : @_root_.«Ctx».«C» (leantType11)] => @(let leantHead24 : (∀ [@_root_.«Ctx».«C» (leantType6)], @_root_.«Nat») := @(let leantHead32 : (∀ (leantBound0x0 : Type) [@_root_.«Ctx».«C» (leantBound0x0)], @_root_.«Nat») := @_root_.«Ctx».«C».«out»; @leantHead32 (leantType6)); @leantHead24 leantGiven17x0)))) : (∀ (leantBound0x0 : Type) (leantBound0x1 : Type) [@_root_.«Ctx».«C» (leantBound0x0)] [@_root_.«Ctx».«C» (leantBound0x1)], @_root_.«Nat»))
theorem SelectionReplay.passes : (@SelectionReplay.implementation Nat Bool (@Ctx.C.mk Nat 7) (@Ctx.C.mk Bool 11) = 7) ∧ (@SelectionReplay.implementation Nat Bool (@Ctx.C.mk Nat 11) (@Ctx.C.mk Bool 7) = 11) ∧ (@SelectionReplay.implementation Bool Nat (@Ctx.C.mk Bool 13) (@Ctx.C.mk Nat 17) = 13) ∧ (@SelectionReplay.implementation Bool Bool (@Ctx.C.mk Bool 19) (@Ctx.C.mk Bool 23) = 19) := by decide
#print axioms SelectionReplay.implementation
#print axioms SelectionReplay.passes
