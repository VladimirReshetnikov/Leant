# Accepted native scoped-selection integration

The validated checkout starts at Leant d9dfcfad0158092e094e45931d1db0e503e6aded
with Djex a4c1bad92d1c63bb533113a7497a577c418559db plus the seven-file overlay
recorded in build/dependency.patch. The same source repair is published as Djex
ebadbefd175ac98d4f79393d4ed4a4089a1725bf. Build/source retains the exact source
inputs; build/results.json and acceptance/results.json identify their hashes.

Copy reproduction/run_scoped_selections.py to test-context before building.
The controllers record commands, environment, source/runtime identities and
original bounds. Reproduce in a fresh output directory, adapting machine-local
tool paths and snapshot guards. The build controller originally copied its
overlay from the canonical Haskell validation checkout; use the retained source
or published commit for a standalone reproduction. Do not overwrite this archive.

Run the unchanged 18-case matrix, the full 707-test native suite, then both
350-signature corpora with exact kernel replay. Actual False controls require
predicate rejection of proposed candidates, not merely no output. Reference
implementations are confined to separate oracle/replay files. Every positive
replays the exact displayed implementation and checks its source-graph ownership.

All final controller source/runtime checks pass. Binaries are identified by
hash rather than redistributed. This gate excludes the separate pending
constructor patch and adds no Church behavioral cells by association.
