{-# LANGUAGE RankNTypes, ScopedTypeVariables, TypeApplications #-}
module CarrierWitness where
type CList a = forall r. (a -> r -> r) -> r -> r
foldl1C :: forall a. a -> (a -> a -> a) -> CList a -> a
foldl1C d f xs = xs @((a -> a) -> a -> a)
  (\x rest g _ -> rest (f (g x)) (g x))
  (\_ z -> z) (\x -> x) d
foldr1C :: forall a. a -> (a -> a -> a) -> CList a -> a
foldr1C d f xs = xs @((a -> a) -> a -> a)
  (\x rest g _ -> rest (\y -> g (f x y)) (g x))
  (\_ z -> z) (\x -> x) d
