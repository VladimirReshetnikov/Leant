# Native selection diagnostic, not release acceptance

Reconstruct Leant at d9dfcfad0158092e094e45931d1db0e503e6aded and initialize its submodules. Set
lib/Djex to a4c1bad92d1c63bb533113a7497a577c418559db. Copy reproduction/run_scoped_selections.py
to test-context/run_scoped_selections.py before building. No production source
overlay was used. The build/results.json source hash manifest includes the
fixture. Verify these hashes and use the recorded compiler/runtime versions.

The archived build and acceptance controllers record the original commands,
runtime paths, environment, limits and serial ordering. Adapt machine-local
paths for a fresh output directory; do not overwrite these archived outputs.
The acceptance controller expects the completed build report under its original
dist-newstyle/scoped-native-build-v1 name. The fixture also supports --help.

This archive retains only completed build, unit, selection, and Djinn signature
gates. The Exference signature gate was still running at capture and is excluded.
That pending result cannot change the six selection failures in this diagnostic.
All eight positive selection cases have independent exact kernel replay.
The four Both positives originate in Djinn. Exference's False queries have zero
candidate checks, so they do not establish actual predicate rejection.

The provisional-carrier files are design evidence only. The finite-model text
records the prior Python observation count; the model generator is not included.
The Haskell/Lean witnesses have not been compiler-checked or synthesized.
