set_option autoImplicit false
class Ctx.C (α : Type) where out : Nat
def SelectionReplay.implementation : ∀ (α β : Type), [Ctx.C α] → [Ctx.C β] → Nat :=
((fun (leantType118 : Type) => (fun (leantType89 : Type) => (fun [leantGiven8x0 : @_root_.«Ctx».«C» (leantType118)] [leantGiven8x1 : @_root_.«Ctx».«C» (leantType89)] => @(let leantHead53 : (∀ [@_root_.«Ctx».«C» (leantType89)], @_root_.«Nat») := @(let leantHead34 : (∀ (leantBound0x0 : Type) [@_root_.«Ctx».«C» (leantBound0x0)], @_root_.«Nat») := @_root_.«Ctx».«C».«out»; @leantHead34 (leantType89)); @leantHead53 leantGiven8x1)))) : (∀ (leantBound0x0 : Type) (leantBound0x1 : Type) [@_root_.«Ctx».«C» (leantBound0x0)] [@_root_.«Ctx».«C» (leantBound0x1)], @_root_.«Nat»))
theorem SelectionReplay.passes : (@SelectionReplay.implementation Nat Bool (@Ctx.C.mk Nat 7) (@Ctx.C.mk Bool 11) = 11) ∧ (@SelectionReplay.implementation Nat Bool (@Ctx.C.mk Nat 11) (@Ctx.C.mk Bool 7) = 7) ∧ (@SelectionReplay.implementation Bool Nat (@Ctx.C.mk Bool 13) (@Ctx.C.mk Nat 17) = 17) ∧ (@SelectionReplay.implementation Bool Bool (@Ctx.C.mk Bool 19) (@Ctx.C.mk Bool 23) = 23) := by decide
#print axioms SelectionReplay.implementation
#print axioms SelectionReplay.passes
