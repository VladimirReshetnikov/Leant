set_option autoImplicit false
class Ctx.C (α : Type) where out : Nat
def SelectionOracle.implementation : ∀ (α β : Type), [Ctx.C α] → [Ctx.C β] → (∀ (p : Type), [Ctx.C p] → Nat) → Nat :=
fun (α β : Type) [d : Ctx.C α] [e : Ctx.C β] (p : (∀ (p : Type), [Ctx.C p] → Nat)) => @p β e
theorem SelectionOracle.passes : (@SelectionOracle.implementation Nat Bool (@Ctx.C.mk Nat 7) (@Ctx.C.mk Bool 11) (fun (p : Type) [d : Ctx.C p] => @Ctx.C.out p d + 0) = 11) ∧ (@SelectionOracle.implementation Nat Bool (@Ctx.C.mk Nat 11) (@Ctx.C.mk Bool 7) (fun (p : Type) [d : Ctx.C p] => @Ctx.C.out p d + 100) = 107) ∧ (@SelectionOracle.implementation Bool Nat (@Ctx.C.mk Bool 13) (@Ctx.C.mk Nat 17) (fun (p : Type) [d : Ctx.C p] => @Ctx.C.out p d + 100) = 117) ∧ (@SelectionOracle.implementation Bool Bool (@Ctx.C.mk Bool 19) (@Ctx.C.mk Bool 23) (fun (p : Type) [d : Ctx.C p] => @Ctx.C.out p d + 0) = 23) := by decide
#print axioms SelectionOracle.implementation
#print axioms SelectionOracle.passes
