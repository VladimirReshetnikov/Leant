set_option autoImplicit false
class Ctx.C (α : Type) where out : Nat
def SelectionOracle.implementation : ∀ (α β : Type), [Ctx.C α] → [Ctx.C β] → Nat :=
fun (α β : Type) [d : Ctx.C α] [e : Ctx.C β] => @Ctx.C.out β e
theorem SelectionOracle.passes : (@SelectionOracle.implementation Nat Bool (@Ctx.C.mk Nat 7) (@Ctx.C.mk Bool 11) = 11) ∧ (@SelectionOracle.implementation Nat Bool (@Ctx.C.mk Nat 11) (@Ctx.C.mk Bool 7) = 7) ∧ (@SelectionOracle.implementation Bool Nat (@Ctx.C.mk Bool 13) (@Ctx.C.mk Nat 17) = 17) ∧ (@SelectionOracle.implementation Bool Bool (@Ctx.C.mk Bool 19) (@Ctx.C.mk Bool 23) = 23) := by decide
#print axioms SelectionOracle.implementation
#print axioms SelectionOracle.passes
