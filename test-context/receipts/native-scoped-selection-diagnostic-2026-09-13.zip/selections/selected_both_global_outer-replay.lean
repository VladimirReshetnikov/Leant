set_option autoImplicit false
class Ctx.C (α : Type) where out : Nat
def SelectionReplay.implementation : ∀ (α β : Type), [Ctx.C α] → [Ctx.C β] → Nat :=
((fun (leantType104 : Type) => (fun (leantType77 : Type) => (fun [leantGiven5x0 : @_root_.«Ctx».«C» (leantType104)] [leantGiven5x1 : @_root_.«Ctx».«C» (leantType77)] => @(let leantHead44 : (∀ [@_root_.«Ctx».«C» (leantType104)], @_root_.«Nat») := @(let leantHead27 : (∀ (leantBound0x0 : Type) [@_root_.«Ctx».«C» (leantBound0x0)], @_root_.«Nat») := @_root_.«Ctx».«C».«out»; @leantHead27 (leantType104)); @leantHead44 leantGiven5x0)))) : (∀ (leantBound0x0 : Type) (leantBound0x1 : Type) [@_root_.«Ctx».«C» (leantBound0x0)] [@_root_.«Ctx».«C» (leantBound0x1)], @_root_.«Nat»))
theorem SelectionReplay.passes : (@SelectionReplay.implementation Nat Bool (@Ctx.C.mk Nat 7) (@Ctx.C.mk Bool 11) = 7) ∧ (@SelectionReplay.implementation Nat Bool (@Ctx.C.mk Nat 11) (@Ctx.C.mk Bool 7) = 11) ∧ (@SelectionReplay.implementation Bool Nat (@Ctx.C.mk Bool 13) (@Ctx.C.mk Nat 17) = 13) ∧ (@SelectionReplay.implementation Bool Bool (@Ctx.C.mk Bool 19) (@Ctx.C.mk Bool 23) = 19) := by decide
#print axioms SelectionReplay.implementation
#print axioms SelectionReplay.passes
