from pathlib import Path
import hashlib,json,os,subprocess,sys
ROOT=Path.cwd()
OUT=ROOT/'dist-newstyle/scoped-native-build-v1'
sys.path.insert(0,str(ROOT/'lib/Djex/test-church'))
import behavior_runtime as runtime
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='d9dfcfad0158092e094e45931d1db0e503e6aded'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT/'lib/Djex').decode().strip()=='a4c1bad92d1c63bb533113a7497a577c418559db'
assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT/'lib/Djex')==b''
assert subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).decode().splitlines()==['lib/Djex']
OUT.mkdir(exist_ok=False)
report={'status':'running','source_commit':'d9dfcfad0158092e094e45931d1db0e503e6aded','dependency_commit':'a4c1bad92d1c63bb533113a7497a577c418559db','source_sha256':{}}
paths={ROOT/'test-context/run_scoped_selections.py'}
for repo in [ROOT,ROOT/'lib/Djex']:
 for name in subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0'):
  p=repo/name
  if name and p.is_file() and (p.suffix in ['.hs','.lhs','.py','.lean','.cabal'] or p.name in ['cabal.project','lean-toolchain']): paths.add(p)
for p in sorted(paths):
 rel=p.relative_to(ROOT).as_posix();report['source_sha256'][rel]=runtime.sha256(p)
 target=OUT/'source'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
runner=runtime.Processes(OUT,9000)
runtime.write_json(OUT/'results.json',report)
try:
 completed=runner.run('strict-build',['cabal','build','leant:exe:leant','leant:test:leant-synth-tests','djex:exe:djex-fake-z3','--ghc-options=-Werror','-j1'],cwd=ROOT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
 report['exit_code']=completed.returncode
finally:
 report['sources_unchanged']=all(runtime.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
 report['controller_unchanged']=(OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
 report['processes']=runner.rows
 report['status']='passed' if report.get('exit_code')==0 and report['sources_unchanged'] and report['controller_unchanged'] else 'failed'
 runtime.write_json(OUT/'results.json',report)
print(report['status'],flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
