from pathlib import Path
import json,os,subprocess,sys
ROOT=Path.cwd();OUT=ROOT/'dist-newstyle/scoped-native-acceptance-v1'
sys.path.insert(0,str(ROOT/'lib/Djex/test-church'))
import behavior_runtime as runtime
build=json.loads((ROOT/'dist-newstyle/scoped-native-build-v1/results.json').read_text())
assert build['status']=='passed' and build['sources_unchanged'] and build['controller_unchanged']
assert all(runtime.sha256(ROOT/p)==h for p,h in build['source_sha256'].items())
OUT.mkdir(exist_ok=False)
exe=ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/x/leant/build/leant/leant.exe'
unit=ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/leant-0.1.0/t/leant-synth-tests/build/leant-synth-tests/leant-synth-tests.exe'
kernel=Path('C:/Users/vresh/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean.exe')
backend=Path('C:/Users/vresh/AppData/Local/Python/pythoncore-3.14-64/Lib/site-packages/lean_interact/cache/augustepoiroux/repl/repl_v1.3.18_lean-toolchain-v4.32.0/.lake/build/bin/repl.exe')
report={'status':'running','source_commit':build['source_commit'],'dependency_commit':build['dependency_commit'],'source_sha256':build['source_sha256'],'runtime_sha256':{str(p):runtime.sha256(p) for p in [exe,unit,kernel,backend]},'gates':[]}
for p in [ROOT/'lib/Djex/test-church/manifest.json',ROOT/'lib/Djex/test-church/cases.tsv']:
 report['source_sha256'][p.relative_to(ROOT).as_posix()]=runtime.sha256(p)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
runner=runtime.Processes(OUT,1800)
env=dict(os.environ,LEANT_BACKEND=str(backend),PYTHONDONTWRITEBYTECODE='1',leant_datadir=str(ROOT),djex_datadir=str(ROOT/'lib/Djex'))
def save():
 report['processes']=runner.rows;runtime.write_json(OUT/'results.json',report)
def gate(label,command,guard):
 runner.timeout=guard;report['active_gate']=label;save()
 print('Starting '+label,flush=True)
 completed=runner.run(label,command,cwd=ROOT,env=env)
 row={'gate':label,'exit_code':completed.returncode};report['gates'].append(row);save()
 return row
save()
try:
 checked=gate('unit',[sys.executable,'-X','utf8','-B','test-recursive/run_unit.py','--expected-count','707','--output',str(OUT/'unit')],1500)
 if checked['exit_code']!=0: raise RuntimeError('full native unit suite failed')
 gate('selections',[sys.executable,'-X','utf8','-B','test-context/run_scoped_selections.py','--leant',str(exe),'--lean-runtime',str(kernel),'--backend',str(backend),'--output',str(OUT/'selections')],5000)
 for engine in ['djinn','exference']:
  label='signatures-'+engine
  checked=gate(label,[sys.executable,'-X','utf8','-B','test-church/run_corpus.py','--leant',str(exe),'--engine',engine,'--window','1','--lean',str(kernel),'--toolchain','','--output',str(OUT/label)],2400)
  result=json.loads((OUT/label/'results.json').read_text())
  checked['complete_replay']=result['case_count']==result['candidate_count']==result['axiom_free_count']==350 and result['kernel_replay_passed'] and result['kernel_exit_code']==result['leant_exit_code']==0
  save()
 report['status']='passed' if all(g['exit_code']==0 and g.get('complete_replay',True) for g in report['gates']) else 'failed'
except BaseException as failure:
 report.update(status='failed',failure=repr(failure))
finally:
 report['sources_unchanged']=all(runtime.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
 report['runtimes_unchanged']=all(runtime.sha256(Path(p))==h for p,h in report['runtime_sha256'].items())
 report['controller_unchanged']=(OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
 if not all(report[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged']): report['status']='failed'
 save()
print(report['status'],report.get('failure',''),flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
