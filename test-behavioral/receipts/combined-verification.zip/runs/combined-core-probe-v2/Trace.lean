set_option autoImplicit false in
set_option maxHeartbeats 200000 in
example : Option (Decidable (True)) := by
  first
  | exact some (.isTrue (by decide))
    trace "LEANT_BEHAVIOR_DECISION:1"
  | exact some (.isFalse (by decide))
    trace "LEANT_BEHAVIOR_DECISION:2"
  | exact none
    trace "LEANT_BEHAVIOR_DECISION:0"
set_option autoImplicit false in
set_option maxHeartbeats 200000 in
example : Option (Decidable (False)) := by
  first
  | exact some (.isTrue (by decide))
    trace "LEANT_BEHAVIOR_DECISION:1"
  | exact some (.isFalse (by decide))
    trace "LEANT_BEHAVIOR_DECISION:2"
  | exact none
    trace "LEANT_BEHAVIOR_DECISION:0"
set_option autoImplicit false in
set_option maxHeartbeats 200000 in
example : Option (Decidable ((fun p : Prop => p) (1 = 1))) := by
  first
  | exact some (.isTrue (by decide))
    trace "LEANT_BEHAVIOR_DECISION:1"
  | exact some (.isFalse (by decide))
    trace "LEANT_BEHAVIOR_DECISION:2"
  | exact none
    trace "LEANT_BEHAVIOR_DECISION:0"
set_option autoImplicit false in
set_option maxHeartbeats 200000 in
example : Option (Decidable ((∀ p : Prop, p))) := by
  first
  | exact some (.isTrue (by decide))
    trace "LEANT_BEHAVIOR_DECISION:1"
  | exact some (.isFalse (by decide))
    trace "LEANT_BEHAVIOR_DECISION:2"
  | exact none
    trace "LEANT_BEHAVIOR_DECISION:0"
