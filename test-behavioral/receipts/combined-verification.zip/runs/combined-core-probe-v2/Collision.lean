def leantBehaviorCertificate : Nat := 37
private def leantBehaviorCertificate : Option (Decidable True) := by
  first
  | exact some (.isTrue (by decide))
  | exact some (.isFalse (by decide))
  | exact none
set_option pp.all false in
#reduce (match leantBehaviorCertificate with
  | Option.none => "LEANT_BEHAVIOR_DECISION:0"
  | Option.some (Decidable.isTrue _) => "LEANT_BEHAVIOR_DECISION:1"
  | Option.some (Decidable.isFalse _) => "LEANT_BEHAVIOR_DECISION:2")
