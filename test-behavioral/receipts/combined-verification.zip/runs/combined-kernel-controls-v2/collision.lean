def leantBehaviorCertificate : Nat := 37
set_option autoImplicit false in
set_option maxHeartbeats 200000 in
example : _root_.Option (_root_.Decidable (
let f : (
∀ α : Type, α → α
) := (
fun _ x => x
); (
f Nat 11 = 11
))) := by
  first
  | exact _root_.Option.some (_root_.Decidable.isTrue (by decide))
    trace "LEANT_BEHAVIOR_DECISION:1"
  | exact _root_.Option.some (_root_.Decidable.isFalse (by decide))
    trace "LEANT_BEHAVIOR_DECISION:2"
  | exact _root_.Option.none
    trace "LEANT_BEHAVIOR_DECISION:0"
