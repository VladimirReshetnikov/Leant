set_option autoImplicit false
def FoldReplay.accepted : {α : Type} → (∀ ρ : Type, (α → ρ → ρ) → ρ → List α → ρ) → List α → List α → List α :=
fun f x y => f _ (.cons) y x
theorem FoldReplay.accepted_passes : (FoldReplay.accepted (fun ρ => @List.foldr Nat ρ) [] [] = ([] : List Nat)) ∧ (FoldReplay.accepted (fun ρ => @List.foldr Nat ρ) [] [11, 29] = [11, 29]) ∧ (FoldReplay.accepted (fun ρ => @List.foldr Nat ρ) [11, 29] [] = [11, 29]) ∧ (FoldReplay.accepted (fun ρ => @List.foldr Nat ρ) [11, 29] [37, 41, 53] = [11, 29, 37, 41, 53]) ∧ (FoldReplay.accepted (fun ρ => @List.foldr Bool ρ) [true, false] [true] = [true, false, true]) := by decide
#print axioms List.foldr
#print axioms FoldReplay.accepted
#print axioms FoldReplay.accepted_passes
