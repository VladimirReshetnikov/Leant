set_option autoImplicit false
#print axioms List.foldr
