set_option autoImplicit false in
set_option maxHeartbeats 200000 in
example : _root_.PSigma (fun f : (
∀ α : Type, α → α
) => _root_.Option (_root_.Decidable (
∀ p : Prop, p
))) := by
  refine ⟨(
fun _ x => x
  ), ?_⟩
  first
  | exact _root_.Option.some (_root_.Decidable.isTrue (by decide))
    trace "LEANT_BEHAVIOR_DECISION:1"
  | exact _root_.Option.some (_root_.Decidable.isFalse (by decide))
    trace "LEANT_BEHAVIOR_DECISION:2"
  | exact _root_.Option.none
    trace "LEANT_BEHAVIOR_DECISION:0"
