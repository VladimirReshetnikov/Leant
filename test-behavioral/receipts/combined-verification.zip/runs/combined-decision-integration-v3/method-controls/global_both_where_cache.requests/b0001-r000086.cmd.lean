set_option autoImplicit false in
set_option maxHeartbeats 200000 in
noncomputable example : (
∀ (α : Type), [Ctx.C α] → Nat

) → Prop := fun global_both_where_cache_context => (
(@global_both_where_cache_context Nat (@Ctx.C.mk Nat 7) = 7) ∧ (@global_both_where_cache_context Nat (@Ctx.C.mk Nat 11) = 11) ∧ (@global_both_where_cache_context Bool (@Ctx.C.mk Bool 11) = 11) ∧ (@global_both_where_cache_context Bool (@Ctx.C.mk Bool 7) = 7)
)
