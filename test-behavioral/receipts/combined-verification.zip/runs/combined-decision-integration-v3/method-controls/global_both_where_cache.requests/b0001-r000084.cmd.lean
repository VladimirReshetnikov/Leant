open Lean Elab Command in
run_cmd do
  for source in ["∀ (α : Type), [Ctx.C α] → Nat", "(@global_both_where_cache_context Nat (@Ctx.C.mk Nat 7) = 7) ∧ (@global_both_where_cache_context Nat (@Ctx.C.mk Nat 11) = 11) ∧ (@global_both_where_cache_context Bool (@Ctx.C.mk Bool 11) = 11) ∧ (@global_both_where_cache_context Bool (@Ctx.C.mk Bool 7) = 7)"] do
    match Parser.runParserCategory (← getEnv) `term source with
    | .ok _ => pure ()
    | .error error => throwError error
