set_option autoImplicit false in
set_option maxHeartbeats 200000 in
noncomputable example : (
∀ (α : Type), Ctx.C α → Nat

) → Prop := fun global_both_where_cache_legacy_first => (
(@global_both_where_cache_legacy_first Nat (@Ctx.C.mk Nat 7) = 14) ∧ (@global_both_where_cache_legacy_first Nat (@Ctx.C.mk Nat 11) = 22) ∧ (@global_both_where_cache_legacy_first Bool (@Ctx.C.mk Bool 11) = 22) ∧ (@global_both_where_cache_legacy_first Bool (@Ctx.C.mk Bool 7) = 14)
)
