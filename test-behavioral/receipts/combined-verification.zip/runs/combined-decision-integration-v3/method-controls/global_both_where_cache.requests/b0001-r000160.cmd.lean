set_option autoImplicit false in
set_option maxHeartbeats 200000 in
example : _root_.PSigma (fun global_both_where_cache_legacy_hit : (
∀ (α : Type), Ctx.C α → Nat

) => _root_.Option (_root_.Decidable (
(@global_both_where_cache_legacy_hit Nat (@Ctx.C.mk Nat 7) = 14) ∧ (@global_both_where_cache_legacy_hit Nat (@Ctx.C.mk Nat 11) = 22) ∧ (@global_both_where_cache_legacy_hit Bool (@Ctx.C.mk Bool 11) = 22) ∧ (@global_both_where_cache_legacy_hit Bool (@Ctx.C.mk Bool 7) = 14)
))) := by
  refine ⟨(
fun _ x => let y := x; match y with | Ctx.C.mk z => Nat.succ (Nat.succ (Nat.succ (Nat.succ z)))
  ), ?_⟩
  first
  | exact _root_.Option.some (_root_.Decidable.isTrue (by decide))
    trace "LEANT_BEHAVIOR_DECISION:1"
  | exact _root_.Option.some (_root_.Decidable.isFalse (by decide))
    trace "LEANT_BEHAVIOR_DECISION:2"
  | exact _root_.Option.none
    trace "LEANT_BEHAVIOR_DECISION:0"
