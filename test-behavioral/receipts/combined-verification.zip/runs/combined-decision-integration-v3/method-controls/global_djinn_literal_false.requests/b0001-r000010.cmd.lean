set_option autoImplicit false in
set_option maxHeartbeats 200000 in
example : _root_.PSigma (fun global_djinn_literal_false : (
∀ (α : Type), [Ctx.C α] → Nat

) => _root_.Option (_root_.Decidable (
False
))) := by
  refine ⟨(
((fun (leantType77 : Type) => (fun [leantGiven2x0 : @_root_.«Ctx».«C» (leantType77)] => @(let leantHead44 : (∀ [@_root_.«Ctx».«C» (leantType77)], @_root_.«Nat») := @(let leantHead27 : (∀ (leantBound0x0 : Type) [@_root_.«Ctx».«C» (leantBound0x0)], @_root_.«Nat») := @_root_.«Ctx».«C».«out»; @leantHead27 (leantType77)); @leantHead44 leantGiven2x0))) : (∀ (leantBound0x0 : Type) [@_root_.«Ctx».«C» (leantBound0x0)], @_root_.«Nat»))
  ), ?_⟩
  first
  | exact _root_.Option.some (_root_.Decidable.isTrue (by decide))
    trace "LEANT_BEHAVIOR_DECISION:1"
  | exact _root_.Option.some (_root_.Decidable.isFalse (by decide))
    trace "LEANT_BEHAVIOR_DECISION:2"
  | exact _root_.Option.none
    trace "LEANT_BEHAVIOR_DECISION:0"
