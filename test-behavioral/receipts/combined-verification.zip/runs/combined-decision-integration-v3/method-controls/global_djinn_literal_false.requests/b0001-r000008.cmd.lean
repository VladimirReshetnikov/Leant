set_option autoImplicit false in
set_option maxHeartbeats 200000 in
noncomputable example : (
∀ (α : Type), [Ctx.C α] → Nat

) → Prop := fun global_djinn_literal_false => (
False
)
