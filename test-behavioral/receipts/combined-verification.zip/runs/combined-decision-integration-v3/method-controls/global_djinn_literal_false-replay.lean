set_option autoImplicit false
class Ctx.C (α : Type) where out : Nat
def RejectedReplay.candidate0 : ∀ (α : Type), [Ctx.C α] → Nat :=
((fun (leantType77 : Type) => (fun [leantGiven2x0 : @_root_.«Ctx».«C» (leantType77)] => @(let leantHead44 : (∀ [@_root_.«Ctx».«C» (leantType77)], @_root_.«Nat») := @(let leantHead27 : (∀ (leantBound0x0 : Type) [@_root_.«Ctx».«C» (leantBound0x0)], @_root_.«Nat») := @_root_.«Ctx».«C».«out»; @leantHead27 (leantType77)); @leantHead44 leantGiven2x0))) : (∀ (leantBound0x0 : Type) [@_root_.«Ctx».«C» (leantBound0x0)], @_root_.«Nat»))
theorem RejectedReplay.literalFalse : ¬ False := by decide
#print axioms Ctx.C
#print axioms Ctx.C.mk
#print axioms Ctx.C.out
#print axioms RejectedReplay.candidate0
#print axioms RejectedReplay.literalFalse
