open Lean Meta Elab Command in
set_option linter.unusedVariables false in
run_cmd do
  Lean.Elab.Command.liftTermElabM do
    let env ← getEnv
    let roots : List String := ["Ctx", "Nat"]
    let targetHead : Option String := some "Nat"
    let sessions : List String := ["Ctx.C"]
    let sessionMethods : Array Name := #[]
    let isSession (n : Name) : Bool :=
      sessions.contains n.toString || sessionMethods.contains n
    let aux : List String :=
      ["rec", "recOn", "casesOn", "brecOn", "binductionOn",
       "below", "ibelow", "noConfusion", "noConfusionType",
       "ctorElim", "ctorElimType", "ctorIdx", "sizeOf_spec",
       "injEq", "inj", "eq_def", "decEq"]
    let keep (n : Name) : Bool :=
      !Lean.isAuxRecursor env n &&
      !n.isInternalDetail &&
      !n.components.any fun c => match c with
        | .str _ s => s.startsWith "it!" || aux.contains s
        | _ => false
    let implementationWorker (n : Name) : Bool :=
      match n with
      | .str _ s =>
        s == "go" || s == "loop"
          || s.endsWith "TR" || s.endsWith "Impl"
          || s.endsWith "Aux"
      | _ => false
    let names := env.constants.fold (init := #[]) fun a n _ =>
      if keep n && (roots.contains n.getRoot.toString
          || isSession n) then a.push n else a
    let shorter (a b : Name) : Bool :=
      let sa := a.toString
      let sb := b.toString
      if sa.length == sb.length then sa < sb else sa.length < sb.length
    let sorted := names.qsort shorter
    let sessionCandidates := sorted.toList.filter fun n =>
      isSession n
    let otherCandidates := sorted.toList.filter fun n =>
      !isSession n
    let mut sessionPreferred : Array Name := #[]
    let mut preferred : Array Name := #[]
    let mut sessionFallback : Array Name := #[]
    let mut fallback : Array Name := #[]
    let mut workerPreferred : Array Name := #[]
    let mut workerFallback : Array Name := #[]
    -- Exact session declarations bypass the root-pool scan cap.
    for n in sessionCandidates ++ otherCandidates.take 2048 do
      match env.find? n with
      | none => pure ()
      | some info =>
        let typeLevel ← LeantSynth.resultIsSort info.type
        if typeLevel then pure () else
          let head ← LeantSynth.resultHead? info.type
          let exactHead := head.map (fun n => n.toString) == targetHead
          let session := isSession n
          if session then
            if exactHead then
              sessionPreferred := sessionPreferred.push n
            else
              sessionFallback := sessionFallback.push n
          else if implementationWorker n then
            if exactHead then
              workerPreferred := workerPreferred.push n
            else
              workerFallback := workerFallback.push n
          else if exactHead then
            preferred := preferred.push n
          else
            fallback := fallback.push n
    let chosen := (sessionPreferred.toList ++ preferred.toList
      ++ sessionFallback.toList ++ fallback.toList
      ++ workerPreferred.toList ++ workerFallback.toList).take 1
    let mut body := ""
    for n in chosen do
      match env.find? n with
      | none => pure ()
      | some info =>
        let frag ← LeantSynth.go true false 80 0 [] info.type
        let binders ← LeantSynth.leadingTypeBinderNames 80 info.type
        -- Exact assignments are optional evidence. A difficult instance
        -- branch must not erase this provider or earlier inventory entries.
        let assignments ← LeantSynth.withProviderAssignmentBudget do
          LeantSynth.providerInstantiationAssignments 80 info.type
        let binderText := String.join
          (binders.toList.map fun binder =>
            " " ++ LeantSynth.esc binder)
        let assignmentText := String.join
          (assignments.toList.map fun assignment =>
            " (args" ++ String.join
              (assignment.toList.map fun argument =>
                " (kinded " ++ toString argument.kindArity ++ " "
                  ++ argument.payload ++ ")")
              ++ ")")
        let evidenceText := if assignments.isEmpty then "" else
          " (instantiations" ++ assignmentText ++ ")"
        body := body ++ " (provider " ++ LeantSynth.esc n.toString
          ++ " (binders" ++ binderText ++ ")" ++ evidenceText
          ++ " " ++ frag ++ ")"
    logInfo ("(providers" ++ body ++ ")")
