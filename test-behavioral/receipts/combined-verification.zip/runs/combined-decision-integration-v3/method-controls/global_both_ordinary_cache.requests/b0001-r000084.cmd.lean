open Lean Meta Elab Tactic in
set_option autoImplicit true in
set_option linter.unusedVariables false in
example : (∀ (α : Type), [Ctx.C α] → Nat) := by
  run_tac withMainContext do
    let tgt ← getMainTarget
    let isP ← Meta.isProp tgt
    let s ← LeantSynth.go false false 100 0 [] tgt
    let prems ← LeantSynth.premSpine 100 0 #[] tgt
    let contextSource ← LeantSynth.contextSourcePacket tgt
    let roots := tgt.getUsedConstants.toList.map Name.getRoot
    let rootText := String.intercalate " " (roots.map fun n =>
      LeantSynth.esc n.toString)
    let head ← LeantSynth.resultHead? tgt
    let headText := match head with
      | some n => "(head " ++ LeantSynth.esc n.toString ++ ")"
      | none => "(head)"
    logInfo ("(goal " ++ (if isP then "prop" else "type")
      ++ " (query (roots " ++ rootText ++ ") " ++ headText
      ++ ") " ++ s ++ prems ++ contextSource ++ ")")
  sorry
