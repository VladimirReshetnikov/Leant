set_option autoImplicit true in def «it!3» : (∀ (α : Type), Ctx.C α → Nat
) := (fun _ x => Nat.add ((fun a => match a with | ⟨b⟩ => b) x) ((fun c => match c with | ⟨d⟩ => d) x))