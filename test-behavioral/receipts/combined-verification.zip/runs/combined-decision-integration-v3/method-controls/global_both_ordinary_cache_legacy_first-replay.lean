set_option autoImplicit false
class Ctx.C (α : Type) where out : Nat
def MethodReplay.accepted : ∀ (α : Type), Ctx.C α → Nat :=
fun _ x => Nat.add ((fun a => match a with | ⟨b⟩ => b) x) ((fun c => match c with | ⟨d⟩ => d) x)
theorem MethodReplay.passes : (@MethodReplay.accepted Nat (@Ctx.C.mk Nat 7) = 14) ∧ (@MethodReplay.accepted Nat (@Ctx.C.mk Nat 11) = 22) ∧ (@MethodReplay.accepted Bool (@Ctx.C.mk Bool 11) = 22) ∧ (@MethodReplay.accepted Bool (@Ctx.C.mk Bool 7) = 14) := by decide
#print axioms Ctx.C
#print axioms Ctx.C.mk
#print axioms Ctx.C.out
#print axioms MethodReplay.accepted
#print axioms MethodReplay.passes
